<?php
class Dashboard extends MysqlFns
{
   /********************* DashBoard Constructor Starts *************************/
	function DashBoard()
	{
		$this->LDDisplayPath= $config['SiteGlobalPath']."class.DashBoard.php";
		global $config;
		global $objSmarty;
		global $nowDate;
		$this->Limit = 20;
		$ConLink1 = mysql_connect($config['DBHost'],$config['DBUser'],$config['DBPassword']) or die("Database Connection Failed<br>". mysql_error());
		mysql_select_db($config['DBName'], $ConLink1);
		if($config['DBUser'] != 'root')
		{
			$nowDate= 'NOW()';
		}
		else{
			$nowDate= 'NOW()';
		}
	}
   /********************* DashBoard Constructor Ends *************************/
  /********************* companyDashoard Functions Starts *************************/
		function companyDashoard()
		{
		   global $objSmarty,$config,$nowDate;
		   $tbl = $config['DBPrefix'];
		
		if($_GET['companyId'] <> '')
		{
		   $comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		   $comId = $_SESSION['CustomerId'];
		}
		
		$ldc=date("Y", strtotime("first day of previous month"));
            $ldl=date("n", strtotime("last day of previous month"));
		
		$selQry ='SELECT IFNULL(last_month.TOTAL_KWH,0) AS last_month_kwh,IFNULL(curr_month.TOTAL_KWH,0) AS this_month_kwh,IFNULL(curr_month.cost,0) AS this_month_cost,IFNULL(last_month.cost,0) AS last_month_cost,IFNULL(curr_month.branch_id,last_month.branch_id) AS branch_id ,last_month.branch_id FROM (SELECT SUM(`consuption_kwh`) AS TOTAL_KWH,SUM(`consuption_cost`) AS cost,branch_id,recorded_date FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND MONTH(recorded_date)=MONTH(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE)) AND feeder_type="Main Meter" GROUP BY branch_id) AS curr_month , (SELECT SUM(`consuption_kwh`) AS TOTAL_KWH,SUM(`consuption_cost`) AS cost,branch_id,recorded_date FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND MONTH(recorded_date)=MONTH(DATE_SUB(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE),INTERVAL "1" MONTH)) AND feeder_type="Main Meter" GROUP BY branch_id) AS last_month';
		$MonthCostKWH		= $this->ExecuteQuery($selQry, "select");
		$objSmarty->assign('MonthCostKWH', $MonthCostKWH);
		
		$selQryCurr ='SELECT SUM(consuption_kwh+dg_consuption_kwh) AS TOTAL_KWH,SUM(consuption_cost+dg_consuption_cost) AS cost,branch_id,recorded_date FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND MONTH(recorded_date)=MONTH(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE)) AND YEAR(recorded_date)=YEAR('.$nowDate.') AND feeder_type="Main Meter" GROUP BY branch_id';
		$currMonthCostKWH		= $this->ExecuteQuery($selQryCurr, "select");
		$objSmarty->assign('currMonthCostKWH', $currMonthCostKWH);
		
		$selQryLast ='SELECT SUM(consuption_kwh+dg_consuption_kwh) AS TOTAL_KWH,SUM(consuption_cost+dg_consuption_cost) AS cost,branch_id,recorded_date FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND MONTH(recorded_date)="'.$ldl.'" AND YEAR(recorded_date)="'.$ldc.'" AND feeder_type="Main Meter" GROUP BY branch_id';
		$lastMonthCostKWH		= $this->ExecuteQuery($selQryLast, "select");
		$objSmarty->assign('lastMonthCostKWH', $lastMonthCostKWH);
		
		$selQry2='SELECT * from arka_branch_master WHERE company_id="'.$comId.'"'; 
		$branchList		= $this->ExecuteQuery($selQry2, "select");
		$objSmarty->assign('branchList', $branchList);
	
		}
     /********************* companyDashoard Functions Ends *************************/
 /**********************************          Company Dashboard  Multi Line Graph *******************************************/
 
	function GetMultiLineGraph(){
	global $objSmarty,$config,$nowDate;
	
	$cm = date('m');
		$cmon = date('m');//echo $cmon;echo "<br>";
	    $lmon = date('m', strtotime('-5 month'));//echo $lmon;echo "<br>";
			$pyr = date('Y')-1;
			$cyr = date('Y');
			$nyr = date('Y')+1;
			if($cm >= '06')
			{
			$sd=$cyr.'-'.$lmon.'-01';
			$ed=$cyr.'-'.$cmon.'-31';
			}
			else
			{
		    $sd=$pyr.'-'.$lmon.'-01';
			$ed=$cyr.'-'.$cmon.'-31';
			}
	
	if($_GET['companyId'] <> '')
	{
	$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
	$comId = $_SESSION['CustomerId'];
	}
	 $selBranch='SELECT * from arka_branch_master WHERE company_id="'.$comId.'" AND is_active="1"';  
	$branchDet		= $this->ExecuteQuery($selBranch, "select");
	
	$branchParmCost='';
	//$branchParmKwh='';
	foreach($branchDet as $key=>$value)
	{
	$branchParmCost .='{
	"title": "'.$branchDet[$key]["branch_name"].'",
	"balloonText": "[[title]]: <b>Rs.[[value]]</b>",
	"bullet": "round",
	"bulletSize": 10,
	"bulletBorderColor": "#ffffff",
	"bulletBorderAlpha": 1,
	"bulletBorderThickness": 2,
	"type": "smoothedLine",
	"valueField": "'.$branchDet[$key]["branch_name"].'"
	},';
	
	/*$branchParmKwh .='{
	"title": "'.$branchDet[$key]["branch_name"].'",
	"balloonText": "[[title]]: <b>[[value]] kwh</b>",
	"bullet": "round",
	"bulletSize": 10,
	"bulletBorderColor": "#ffffff",
	"bulletBorderAlpha": 1,
	"bulletBorderThickness": 2,
	"type": "smoothedLine",
	"valueField": "'.$branchDet[$key]["branch_name"].'"
	},';*/
	
	}
	$multiLineGraphsCost="[".rtrim($branchParmCost, ",")."]";
	//echo $multiLineGraphs; exit;
	$objSmarty->assign('multiLineGraphsCost',$multiLineGraphsCost);
	
	//$multiLineGraphsKwh="[".rtrim($branchParmKwh, ",")."]";
	//echo $multiLineGraphs; exit;
	//$objSmarty->assign('multiLineGraphsKwh',$multiLineGraphsKwh);

	
	
	
//	 $selMonth='SELECT DATE_FORMAT(recorded_date,"%b") AS month_data,recorded_date,consuption_cost  FROM cron_monthly_energy_data WHERE company_id="'.$comId.'" AND MONTH(recorded_date)<=MONTH('.$nowDate.') AND recorded_date BETWEEN "'.$sd.'" AND "'.$ed.'" GROUP BY recorded_date ';
$selMonth='SELECT DATE_FORMAT(recorded_date,"%b") AS month_data,recorded_date,consuption_cost  FROM cron_monthly_energy_data WHERE company_id="'.$comId.'" AND recorded_date BETWEEN "'.$sd.'" AND "'.$ed.'" GROUP BY recorded_date '; 
	$getMonth= $this->ExecuteQuery($selMonth, "select");
	//echo $getMonth[0]["recorded_date"];exit;
//	$ExeBarGraphCount		= $this->ExecuteQuery($getMonth, "numrows");
	$catCost='';
	//$catkwh='';
	foreach($getMonth as $month=>$value2)
	{
		$branchCost='';
		//$branchKwh='';
	 	foreach($branchDet as $branch=>$value)
		{
	//	 $selMonth='SELECT DATE_FORMAT(recorded_date,"%b") AS month_data, SUM(consuption_cost) AS consuption_cost , SUM(consuption_kwh) AS consuption_kwh FROM cron_monthly_energy_data WHERE company_id="'.$comId.'" AND branch_id="'.$branchDet[$branch]["sl_no"].'" AND feeder_type="Main Meter" AND recorded_date="'.$getMonth[$month]["recorded_date"].'" '; 
		 $selMonth='SELECT DATE_FORMAT(recorded_date,"%b") AS month_data, SUM(consuption_cost+dg_consuption_cost) AS consuption_cost , SUM(consuption_kwh+dg_consuption_kwh) AS consuption_kwh FROM cron_monthly_energy_data WHERE company_id="'.$comId.'" AND branch_id="'.$branchDet[$branch]["sl_no"].'" AND feeder_type="Main Meter" AND MONTH(recorded_date)=MONTH("'.$getMonth[$month]["recorded_date"].'") AND YEAR(recorded_date)=YEAR("'.$getMonth[$month]["recorded_date"].'") '; 
			 $costDet		= $this->ExecuteQuery($selMonth, "select");
 						if($costDet[0]['consuption_cost'] == '')
						{
						$va = '0.00';
						}
						else
						{
						$va = $costDet[0]['consuption_cost'];
						}
			 $branchCost .= ',"'.$branchDet[$branch]["branch_name"].'":'.$va; 
			// $branchKwh.= ',"'.$branchDet[$branch]["branch_name"].'":'.$costDet[0]['consuption_kwh']; ;
		}
		$catCost .='{"month": "'.$getMonth[$month]["month_data"].'"'.$branchCost.'},';
		//$catkwh .='{"category": "'.$getMonth[$month]["month_data"].'"'.$branchKwh.'},';
	
	}
	$multiLineDataProviderCost="[".rtrim($catCost, ",")."]";
	$objSmarty->assign('multiLineDataProviderCost',$multiLineDataProviderCost);
	
/*	$multiLineDataProviderKwh="[".rtrim($catkwh, ",")."]";
	$objSmarty->assign('multiLineDataProviderKwh',$multiLineDataProviderKwh);
*/	

	
	
}
      /********************* GetMultiLineGraph Functions Ends **********************/
	 
	  /******************** IncidentLog Functions Starts **************************/
		function IncidentLog()
		{
		global $objSmarty,$config,$nowDate;
		$tbl = $config['DBPrefix'];
		
		if($_GET['companyId'] <> '')
		{
		   $comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		   $comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		   $branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		   $branchId = $_SESSION['branch_id'];
		}
		if($branchId =='0')
		{
		   $whrClass='company_id="'.$comId.'"';
		}else
		{
		   $whrClass='company_id="'.$comId.'" AND branch_id="'.$branchId.'"';
		
		}
			$selIncidentLog = 'SELECT * FROM `alert_log_master` WHERE '.$whrClass.' ORDER BY recorded_date_time DESC LIMIT 0,3'; 
			$incidentList		= $this->ExecuteQuery($selIncidentLog, "select");
			$objSmarty->assign('incidentList', $incidentList);
		}
         /******************** IncidentLog Functions Ends **************************/
          /******************** IncidentLog Functions Starts **************************/
		function recentIncidentLog()
		{
		global $objSmarty,$config,$nowDate;
		$tbl = $config['DBPrefix'];
		
		if($_GET['companyId'] <> '')
		{
		   $comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		   $comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		   $branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		   $branchId = $_SESSION['branch_id'];
		}
		if($branchId =='0')
		{
		   $whrClass='company_id="'.$comId.'"';
		}else
		{
		   $whrClass='company_id="'.$comId.'" AND branch_id="'.$branchId.'"';
		
		}
		
			if(isset($_POST['date1']) && isset($_POST['date2']))
	{
		$date1 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		$date2 = date("Y-m-d",strtotime(trim(addslashes($_POST['date2']))));
		$selIncidentLog = 'SELECT * FROM `alert_log_master` WHERE '.$whrClass.' AND DATE(recorded_date_time) BETWEEN "'.$date1.'" AND "'.$date2.'" ORDER BY recorded_date_time DESC'; 
	}
	else
	{
	    $selIncidentLog = 'SELECT * FROM `alert_log_master` WHERE '.$whrClass.' ORDER BY recorded_date_time DESC'; 
	}
		//	echo $selIncidentLog;
			$incidentList		= $this->ExecuteQuery($selIncidentLog, "select");
			$objSmarty->assign('incidentList', $incidentList);
		}
         /******************** IncidentLog Functions Ends **************************/
	     /******************** GetDashboardDetails Functions Starts ****************/
		function GetDashboardDetails($objArray='')
		{
		    global $objSmarty;
		if($_GET['companyId'] <> '')
		{
		   $comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		   $comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		   $branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		   $branchId = $_SESSION['branch_id'];
		}
		   $SelQuery_loc = 'SELECT arka_company_master.companyName,arka_branch_master.branch_name,arka_sensor_master.* FROM arka_company_master,arka_branch_master,arka_sensor_master WHERE arka_sensor_master.gateway_id="'.base64_decode($_GET["gatewayCode"]).'" AND arka_sensor_master.sensorCode="'.base64_decode($_GET["sensorCode"]).'" AND  arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.company_id=arka_company_master.slNo AND arka_branch_master.company_id=arka_sensor_master.company_id AND arka_branch_master.company_id=arka_company_master.slNo AND arka_branch_master.sl_no=arka_sensor_master.branch_id' ;
		   $LoctList		= $this->ExecuteQuery($SelQuery_loc, "select");
		   $objSmarty->assign('LoctList', $LoctList);
		   
		  // $SelQuery_mod = 'SELECT sensor_model_master.* FROM sensor_model_master  WHERE sensor_model_master.model_id="'.$LoctList[0]["sensorModel"].'" AND is_active="1" AND status="1"' ;
		    $SelQuery_mod = 'SELECT sensor_model_master.*,power_factor_step_capcitor_value_mapping.* FROM sensor_model_master,power_factor_step_capcitor_value_mapping  WHERE sensor_model_master.model_id="'.$LoctList[0]["sensorModel"].'" AND power_factor_step_capcitor_value_mapping.sensorCode="'.$LoctList[0]['sensorCode'].'"  AND power_factor_step_capcitor_value_mapping.gatewayCode="'.$LoctList[0]['gateway_id'].'" AND power_factor_step_capcitor_value_mapping.isActive="1" AND power_factor_step_capcitor_value_mapping.status="1" AND sensor_model_master.is_active="1" AND sensor_model_master.status="1" AND sensor_model_master.model_id=power_factor_step_capcitor_value_mapping.sensorModel' ;

		   $ModList		= $this->ExecuteQuery($SelQuery_mod, "select");
		   $objSmarty->assign('ModList', $ModList);
		   
		//   $SelQuery='SELECT max(ping_log_id) AS ping_log_id, max(gateway_code) AS gateway_code,max(gateway_date_time) AS gateway_date_time FROM `gateway_ping_log` WHERE gateway_code="'.base64_decode($_GET["gatewayCode"]).'" GROUP BY gateway_code ORDER BY ping_log_id';
	        $SelQuery='SELECT * FROM `gateway_ping_log_view` WHERE gateway_code="'.base64_decode($_GET["gatewayCode"]).'"';
	       $gateList= $this->ExecuteQuery($SelQuery, "select");
	       $objSmarty->assign('gateList', $gateList);
		}	
	/******************** GetDashboardDetails Functions Ends ****************/
	 /*********************  GetCostKwhAll Functions Starts ******************/ 
		function GetCostKwhAll()
		{
			global $objSmarty,$config,$nowDate;
			$tbl = $config['DBPrefix'];
		
		if($_GET['companyId'] <> '')
		{
		   $comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		   $comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		   $branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		   $branchId = $_SESSION['branch_id'];
		}
		
		$ldc=date("Y", strtotime("first day of previous month"));
            $ldl=date("n", strtotime("last day of previous month"));
		
	   $selQry = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND DATE(recorded_date)=DATE('.$nowDate.') AND MONTH(recorded_date)=MONTH('.$nowDate.') AND YEAR(recorded_date)=YEAR('.$nowDate.') AND feeder_type="Main Meter" '; 
		  $todayCostKWH		= $this->ExecuteQuery($selQry, "select");
		  $objSmarty->assign('todayCostKWH', $todayCostKWH);
		
		  $selQry2 = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND MONTH(recorded_date)=MONTH('.$nowDate.') AND YEAR(recorded_date)=YEAR('.$nowDate.') AND feeder_type="Main Meter" '; 
		  $monthCostKWH		= $this->ExecuteQuery($selQry2, "select");
		  $objSmarty->assign('monthCostKWH', $monthCostKWH);
		
		  $selQry3 = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND MONTH(recorded_date)="'.$ldl.'" AND YEAR(recorded_date)="'.$ldc.'" AND feeder_type="Main Meter" ';
		  $LastMonthCostKWH		= $this->ExecuteQuery($selQry3, "select");
		  $objSmarty->assign('LastMonthCostKWH', $LastMonthCostKWH);
		}
		/*********************  GetCostKwhAll Functions Ends ******************/ 
		/*********************  Test2 Functions Starts *************************/ 
		function Test2()  
		{
		   global $objSmarty,$config,$nowDate;
		
		if($_GET['companyId'] <> '')
		{
		   $comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		   $comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		   $branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		   $branchId = $_SESSION['branch_id'];
		}
		
		   $SelQuery = 'SELECT energy_data_master_view.*,arka_sensor_master.*,arka_sensor_master.kw_max_value,(arka_sensor_master.kw_max_value/5) AS KW_INT, feeder_name FROM energy_data_master_view,arka_sensor_master WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.sensorCode=energy_data_master_view.sensor_code arka_sensor_master.gateway_id=energy_data_master_view.gateway_code ORDER BY arka_sensor_master.feeder_type'; 
		  $MeterList= $this->ExecuteQuery($SelQuery, "select");
		  $objSmarty->assign('MeterList', $MeterList);	
		
		
		 $selQryC = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,sensor_code FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND DATE(recorded_date)=DATE('.$nowDate.') AND MONTH(recorded_date)=MONTH('.$nowDate.') AND YEAR(recorded_date)=YEAR('.$nowDate.') GROUP BY sensor_code'; 
		 $CostKWH = $this->ExecuteQuery($selQryC, "select");
		 $objSmarty->assign('CostKWH', $CostKWH);		
		}	
        /*********************  Test2 Functions Ends *************************/ 
/************************************************************************************/
function ListDashboardTest()  
{
		global $objSmarty,$config,$nowDate;
				
		if($_GET['companyId'] <> '')
		{
		$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		$branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		$branchId = $_SESSION['branch_id'];
		}
		$SelQuery = 'SELECT SUM(cron_daily_energy_data.`consuption_kwh`) AS TOTAL_KWH ,SUM(cron_daily_energy_data.`consuption_cost`) AS cost,SUM(cron_daily_energy_data.`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(cron_daily_energy_data.`dg_consuption_cost`) AS dg_cost,cron_daily_energy_data.sensor_code,gateway_ping_log_view.*,energy_data_master_view.*,arka_sensor_master.*,arka_sensor_master.sensorName AS feeder_name,(arka_sensor_master.kw_max_value/5) AS KW_INT,TIMESTAMPDIFF(SECOND, recorded_date_time, NOW()) AS secs FROM cron_daily_energy_data,gateway_ping_log_view,energy_data_master_view,arka_sensor_master WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.sensorCode=energy_data_master_view.sensor_code AND arka_sensor_master.gateway_id=gateway_ping_log_view.gateway_code AND arka_sensor_master.feeder_type="Main Meter" AND arka_sensor_master.sensorCode=cron_daily_energy_data.sensor_code AND cron_daily_energy_data.company_id="'.$comId.'" AND cron_daily_energy_data.branch_id="'.$branchId.'" AND DATE(cron_daily_energy_data.recorded_date)=DATE('.$nowDate.') AND MONTH(cron_daily_energy_data.recorded_date)=MONTH('.$nowDate.') AND YEAR(cron_daily_energy_data.recorded_date)=YEAR('.$nowDate.') GROUP BY cron_daily_energy_data.sensor_code';
	
	//$SelQuery = 'SELECT energy_data_master_view.*,arka_sensor_master.*,arka_sensor_master.sensorName AS feeder_name,(arka_sensor_master.kw_max_value/5) AS KW_INT,TIMESTAMPDIFF(SECOND, recorded_date_time, NOW()) AS secs FROM energy_data_master_view,arka_sensor_master WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.sensorCode=energy_data_master_view.sensor_code  AND arka_sensor_master.feeder_type="Main Meter"  '; 
	       $MeterList= $this->ExecuteQuery($SelQuery, "select");//print_r($MeterList);
	       $objSmarty->assign('MeterList', $MeterList);	
	       
	/*echo"<br> <br>PMeterList: "; echo   */    	$SelQuery = 'SELECT power_factor_energy_data_view.*,arka_sensor_master.*,arka_sensor_master.sensorName AS feeder_name,(arka_sensor_master.kw_max_value/5) AS KW_INT,TIMESTAMPDIFF(SECOND, recorded_date_time, NOW()) AS secs FROM power_factor_energy_data_view,arka_sensor_master WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.sensorCode=power_factor_energy_data_view.sensor_code  AND arka_sensor_master.feeder_type="Main Meter"  '; 
	       $PMeterList= $this->ExecuteQuery($SelQuery, "select");//print_r($PMeterList);
	       $objSmarty->assign('PMeterList', $PMeterList);	
/*	       
echo"<br> <br>CostKWH :"; echo 	    $selQryC = 'SELECT SUM(cron_daily_energy_data.`consuption_kwh`) AS TOTAL_KWH ,SUM(cron_daily_energy_data.`consuption_cost`) AS cost,SUM(cron_daily_energy_data.`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(cron_daily_energy_data.`dg_consuption_cost`) AS dg_cost,cron_daily_energy_data.sensor_code FROM `cron_daily_energy_data` WHERE cron_daily_energy_data.company_id="'.$comId.'" AND cron_daily_energy_data.branch_id="'.$branchId.'" AND DATE(cron_daily_energy_data.recorded_date)=DATE('.$nowDate.') AND MONTH(cron_daily_energy_data.recorded_date)=MONTH('.$nowDate.') AND YEAR(cron_daily_energy_data.recorded_date)=YEAR('.$nowDate.') GROUP BY cron_daily_energy_data.sensor_code';	       
	    $CostKWH		= $this->ExecuteQuery($selQryC, "select");
	    $objSmarty->assign('CostKWH', $CostKWH);*/
		
	/*echo"<br><br> gateList :"; echo    $SelQuery='SELECT * FROM gateway_ping_log_view';
	       $gateList= $this->ExecuteQuery($SelQuery, "select");//print_r($MeterList);
	       $objSmarty->assign('gateList', $gateList);*/
	       
	  	/*echo"<br><br> selQryS: "; echo */    $selQryS = 'SELECT * FROM `arka_sensor_master` WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.feeder_type="Sub Meter" GROUP BY sensorCode';
	       $selQryS		= $this->ExecuteQuery($selQryS, "select");
	    $objSmarty->assign('selQryS', $selQryS);
}	
/***********************Sub Dashboard List*************************************************/
function GetSubDashboard()  {
			global $objSmarty,$config,$nowDate;
		
			if($_GET['companyId'] <> '')
			{
			$comId = base64_decode($_GET['companyId']);
			}	
			else
			{
			$comId = $_SESSION['CustomerId'];
			}
			if($_GET['branchId'] <> '')
			{
			$branchId = base64_decode($_GET['branchId']);
			}	
			else
			{
			$branchId = $_SESSION['branch_id'];
			}
			$parent_id=base64_decode($_GET['parent_id']);

$senDashboard = 'SELECT * FROM arka_sensor_master WHERE slNo="'.$parent_id.'" AND status="1" AND isActive="1"';
			$senDashboard		= $this->ExecuteQuery($senDashboard, "select");
			$objSmarty->assign('senDashboard', $senDashboard);

 			$SelQuery = 'SELECT energy_data_master_view.*,arka_sensor_master.*,(arka_sensor_master.kw_max_value/5) AS KW_INT,arka_sensor_master.sensorName AS feeder_name,TIMESTAMPDIFF(SECOND, recorded_date_time, NOW()) AS secs FROM energy_data_master_view,arka_sensor_master WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.parent_id="'.$parent_id.'" AND arka_sensor_master.feeder_type="Sub Meter" AND arka_sensor_master.sensorCode=energy_data_master_view.sensor_code AND arka_sensor_master.gateway_id=energy_data_master_view.gateway_code '; 
 		//   $SelQuery = 'SELECT energy_data_master_view.*,arka_sensor_master.*,(arka_sensor_master.kw_max_value/5) AS KW_INT,arka_sensor_master.sensorName AS feeder_name,TIMESTAMPDIFF(SECOND, recorded_date_time, NOW()) AS secs FROM energy_data_master_view,arka_sensor_master WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.parent_id="'.$parent_id.'" AND arka_sensor_master.sensorCode=energy_data_master_view.sensor_code AND arka_sensor_master.gateway_id=energy_data_master_view.gateway_code '; 
	       $MeterList= $this->ExecuteQuery($SelQuery, "select");//echo $SelQuery;
	       $objSmarty->assign('MeterList', $MeterList);	
	       
	       	$selQryC = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,sensor_code FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND DATE(recorded_date)=DATE('.$nowDate.') AND MONTH(recorded_date)=MONTH('.$nowDate.') AND YEAR(recorded_date)=YEAR('.$nowDate.') AND cron_daily_energy_data.feeder_type="Sub Meter" AND gateway_code="'.$senDashboard[0]['gateway_id'].'" GROUP BY sensor_code'; 
	        $CostKWH		= $this->ExecuteQuery($selQryC, "select");
	        $objSmarty->assign('CostKWH', $CostKWH);

$SelQuery='SELECT max(ping_log_id) AS ping_log_id, max(gateway_code) AS gateway_code,max(gateway_date_time) AS gateway_date_time FROM `gateway_ping_log` GROUP BY gateway_code ORDER BY ping_log_id';
	       $gateList= $this->ExecuteQuery($SelQuery, "select");//print_r($MeterList);
	       $objSmarty->assign('gateList', $gateList);

}	
/************************************************************************************/
/***********************************       Get Cost KwhAllSub Meter                  *************************************************/
function GetCostKwhAllSubMeter()
{
  global $objSmarty,$config,$nowDate;
  $tbl = $config['DBPrefix'];
  
  if($_GET['companyId'] <> '')
{
	$comId = base64_decode($_GET['companyId']);
}	
else
{
	$comId = $_SESSION['CustomerId'];
}
if($_GET['branchId'] <> '')
{
$branchId = base64_decode($_GET['branchId']);
}	
else
{
$branchId = $_SESSION['branch_id'];
}

$parent_id=base64_decode($_GET['parent_id']);
    $selQry = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost,arka_sensor_master.feeder_type,arka_sensor_master.sensorCode,arka_sensor_master.parent_id FROM `cron_daily_energy_data`,arka_sensor_master WHERE arka_sensor_master.parent_id="'.$parent_id.'" AND arka_sensor_master.sensorCode=cron_daily_energy_data.sensor_code AND  cron_daily_energy_data.company_id="'.$comId.'" AND cron_daily_energy_data.branch_id="'.$branchId.'" AND DATE(recorded_date)=DATE('.$nowDate.') AND MONTH(recorded_date)=MONTH('.$nowDate.') AND YEAR(recorded_date)=YEAR('.$nowDate.') AND cron_daily_energy_data.feeder_type="Sub Meter" '; 
	$todayCostKWHSub		= $this->ExecuteQuery($selQry, "select");
	$objSmarty->assign('todayCostKWHSub', $todayCostKWHSub);
	
	$selQry2 = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost,arka_sensor_master.feeder_type,arka_sensor_master.sensorCode,arka_sensor_master.parent_id FROM `cron_daily_energy_data`,arka_sensor_master WHERE arka_sensor_master.parent_id="'.$parent_id.'" AND arka_sensor_master.sensorCode=cron_daily_energy_data.sensor_code AND cron_daily_energy_data.company_id="'.$comId.'" AND cron_daily_energy_data.branch_id="'.$branchId.'" AND MONTH(recorded_date)=MONTH('.$nowDate.') AND YEAR(recorded_date)=YEAR('.$nowDate.') AND cron_daily_energy_data.feeder_type="Sub Meter" '; 
	$monthCostKWHSub		= $this->ExecuteQuery($selQry2, "select");
	$objSmarty->assign('monthCostKWHSub', $monthCostKWHSub);
	
	$selQry3 = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost,arka_sensor_master.feeder_type,arka_sensor_master.sensorCode,arka_sensor_master.parent_id  FROM `cron_daily_energy_data` ,arka_sensor_master WHERE arka_sensor_master.parent_id="'.$parent_id.'" AND arka_sensor_master.sensorCode=cron_daily_energy_data.sensor_code AND cron_daily_energy_data.company_id="'.$comId.'" AND cron_daily_energy_data.branch_id="'.$branchId.'" AND MONTH(recorded_date)=MONTH(DATE_SUB('.$nowDate.',INTERVAL "1" MONTH)) AND cron_daily_energy_data.feeder_type="Sub Meter" ';
	$LastMonthCostKWHSub		= $this->ExecuteQuery($selQry3, "select");
	$objSmarty->assign('LastMonthCostKWHSub', $LastMonthCostKWHSub);
}
/***************************************************************/
	    /*********************  Test2 Functions Starts *************************/
		function GetSegmentsList()
		{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		$parId = base64_decode($_GET['parent_id']);
		if($_GET['companyId'] <> '')
		{
		   $comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		   $comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		   $branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		   $branchId = $_SESSION['branch_id'];
		}
			$Dashboard = 'SELECT * FROM arka_platform_mapping LEFT JOIN arka_iot_platform ON arka_platform_mapping.segmentCode=arka_iot_platform.slNo WHERE arka_platform_mapping.companyName="'.$comId.'" AND arka_platform_mapping.branch_id="'.$branchId.'" ORDER BY arka_iot_platform.slNo ASC';
			$Dashboard		= $this->ExecuteQuery($Dashboard, "select");
			$objSmarty->assign('Dashboard', $Dashboard);
			
			$senDashboard = 'SELECT * FROM arka_sensor_master WHERE slNo="'.$parId.'" AND status="1" AND isActive="1"';
			$senDashboard		= $this->ExecuteQuery($senDashboard, "select");
			$objSmarty->assign('senDashboard', $senDashboard);
		}
       /*********************  Test2 Functions Ends *************************/
	   /********************* GetFeederList Functions Starts **************************/
	function GetFeederList()  
	{
		global $objSmarty;	
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}	
		$gatewayCode=base64_decode($_GET['gatewayCode']);
		$sensorCode=base64_decode($_GET['sensorCode']);
		
	    $SelFeederName = 'SELECT * FROM arka_sensor_master WHERE company_id ="'.$comId.'" AND branch_id ="'.$branchId.'" AND segmentName="Energy Meter" AND isActive="1"'; 
		$ListFeeder		= $this->ExecuteQuery($SelFeederName, "select");
		$objSmarty->assign('ListFeeder', $ListFeeder);	

		$SelSenso = 'SELECT * FROM arka_sensor_master WHERE company_id ="'.$comId.'" AND branch_id ="'.$branchId.'" AND sensorCode="'.$sensorCode.'" AND isActive="1"'; 
		$ListSenso	= $this->ExecuteQuery($SelSenso, "select");
		$objSmarty->assign('ListSenso', $ListSenso);
	
	
		$senMod =  explode("-",$sensorCode); 
		
		if($senMod[0]=="RGA20S")
		{
		    
	    $objSmarty->assign('KW_MAX', 0);
		$objSmarty->assign('KW_INT', 0);
		$objSmarty->assign('KVA_MAX', 0);
		$objSmarty->assign('KVA_INT', 0);
		$objSmarty->assign('KVAR_MAX', 0);
		$objSmarty->assign('KVAR_INT',0);
	}
	else
	{
		$objSmarty->assign('KW_MAX', $ListSenso[0]['kw_max_value']);
		$objSmarty->assign('KW_INT', $ListSenso[0]['kw_max_value']/5);
		$objSmarty->assign('KVA_MAX', $ListSenso[0]['kva_max_value']);
		$objSmarty->assign('KVA_INT', $ListSenso[0]['kva_max_value']/5);
		$objSmarty->assign('KVAR_MAX', $ListSenso[0]['kvar_max_value']);
		$objSmarty->assign('KVAR_INT', $ListSenso[0]['kvar_max_value']/5);
	}
	
	
	    $objSmarty->assign('KWH_MAX', $ListSenso[0]['kwh_max_value']);
		$objSmarty->assign('KWH_INT', $ListSenso[0]['kwh_max_value']/5);
		$objSmarty->assign('KVAH_MAX', $ListSenso[0]['kvah_max_value']);
		$objSmarty->assign('KVAH_INT', $ListSenso[0]['kvah_max_value']/5);
		$objSmarty->assign('KVARH_MAX', $ListSenso[0]['kvarh_max_value']);
		$objSmarty->assign('KVARH_INT', $ListSenso[0]['kvarh_max_value']/5);
	
	
		$SelFeederDet ='SELECT energy_data_master_view.energy_data_id,energy_data_master_view.`gateway_code`, energy_data_master_view.`sensor_code`, energy_data_master_view.`sensor_model`, energy_data_master_view.`METER_ID`, energy_data_master_view.`R_VOLTAGE`, energy_data_master_view.`Y_VOLTAGE`, energy_data_master_view.`B_VOLTAGE`, energy_data_master_view.`RY_VOLTAGE`, energy_data_master_view.`YB_VOLTAGE`, energy_data_master_view.`BR_VOLTAGE`, energy_data_master_view.`R_CURRENT`, energy_data_master_view.`Y_CURRENT`, energy_data_master_view.`B_CURRENT`, energy_data_master_view.`SUM_KVA`, energy_data_master_view.`SUM_KW`, energy_data_master_view.`SUM_KVAR`, energy_data_master_view.`DG_KVAH`, energy_data_master_view.`DG_KWH`, energy_data_master_view.`DG_KVARH`, energy_data_master_view.`SUM_PF`, energy_data_master_view.`FREQUENCY`, energy_data_master_view.`KWH_MSB`, energy_data_master_view.`KWH_LSB`, energy_data_master_view.`KWH`, energy_data_master_view.`METER_TYPE_RUN_HOUR_MSB`, energy_data_master_view.`RUN_HOUR_LSB`, energy_data_master_view.`RUN_HOUR`, energy_data_master_view.`IMPORT_EXPORT`,energy_data_master_view.`recorded_date_time`,arka_sensor_master.* FROM energy_data_master_view,arka_sensor_master WHERE arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND energy_data_master_view.sensor_code="'.$sensorCode.'" AND energy_data_master_view.gateway_code="'.$gatewayCode.'" AND arka_sensor_master.sensorCode=energy_data_master_view.sensor_code AND arka_sensor_master.gateway_id=energy_data_master_view.gateway_code ';
		$ListFeederDet		= $this->ExecuteQuery($SelFeederDet, "select");
		$ListFeederDet2		= $this->ExecuteQuery($SelFeederDet, "numrows");
		$objSmarty->assign('ListFeederDet', $ListFeederDet);
		$objSmarty->assign('ListFeederDet2', $ListFeederDet2);	
		
	    $SelFeederDetP ='SELECT power_factor_energy_data_view.power_factor_id,power_factor_energy_data_view.`gateway_code`, power_factor_energy_data_view.`sensor_code`, power_factor_energy_data_view.`sensor_model`, power_factor_energy_data_view.`voltage_l1_n` AS `R_VOLTAGE`, power_factor_energy_data_view.`voltage_l2_n` AS `Y_VOLTAGE`, power_factor_energy_data_view.`voltage_l3_n` AS `B_VOLTAGE`, power_factor_energy_data_view.voltage_l1_l2 AS `RY_VOLTAGE`, power_factor_energy_data_view.voltage_l2_l3 AS `YB_VOLTAGE`, power_factor_energy_data_view. voltage_l3_l1 AS `BR_VOLTAGE`, power_factor_energy_data_view.current_l1 AS `R_CURRENT`, power_factor_energy_data_view.current_l2 AS `Y_CURRENT`, power_factor_energy_data_view.current_l3 AS `B_CURRENT`, power_factor_energy_data_view.apparent_power_l1_n AS `SUM_KVA`, power_factor_energy_data_view.total_active_power AS `SUM_KW`, power_factor_energy_data_view.total_reactive_power AS `SUM_KVAR`, power_factor_energy_data_view.measured_frequency AS `FREQUENCY`,power_factor_energy_data_view.power_factor_total_import AS `SUM_PF`,power_factor_energy_data_view.`step1_actual_steps_value`, power_factor_energy_data_view.`step2_actual_steps_value`, power_factor_energy_data_view.`step3_actual_steps_value`, power_factor_energy_data_view.`step4_actual_steps_value`, power_factor_energy_data_view.`step5_actual_steps_value`, power_factor_energy_data_view.`step6_actual_steps_value`, power_factor_energy_data_view.`step7_actual_steps_value`, power_factor_energy_data_view.`step8_actual_steps_value`, power_factor_energy_data_view.`step9_actual_steps_value`, power_factor_energy_data_view.`step10_actual_steps_value`, power_factor_energy_data_view.`step11_actual_steps_value`, power_factor_energy_data_view.`step12_actual_steps_value`, power_factor_energy_data_view.`step13_actual_steps_value`, power_factor_energy_data_view.`step14_actual_steps_value`, power_factor_energy_data_view.`step15_actual_steps_value`, power_factor_energy_data_view.`step16_actual_steps_value`, power_factor_energy_data_view.`step17_actual_steps_value`, power_factor_energy_data_view.`step18_actual_steps_value`, power_factor_energy_data_view.`step19_actual_steps_value`, power_factor_energy_data_view.`step20_actual_steps_value`, power_factor_energy_data_view.power_factor_total_import AS `IMPORT_EXPORT`,power_factor_energy_data_view.`recorded_date_time`,arka_sensor_master.* FROM power_factor_energy_data_view,arka_sensor_master WHERE arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND power_factor_energy_data_view.sensor_code="'.$sensorCode.'" AND power_factor_energy_data_view.gateway_code="'.$gatewayCode.'" AND arka_sensor_master.sensorCode=power_factor_energy_data_view.sensor_code AND arka_sensor_master.gateway_id=power_factor_energy_data_view.gateway_code ';
		$ListFeederDetP		= $this->ExecuteQuery($SelFeederDetP, "select");
		$ListFeederDetP2		= $this->ExecuteQuery($SelFeederDetP, "numrows");
		$objSmarty->assign('ListFeederDetP', $ListFeederDetP);
		$objSmarty->assign('ListFeederDetP2', $ListFeederDetP2);	
	}	
	/********************* GetFeederList Functions Ends **************************/
	/********************* GetCostKwhSingle Functions Starts **************************/
	function GetCostKwhSingle()
	{
		global $objSmarty,$config,$nowDate;
		$tbl = $config['DBPrefix'];
	
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}
		$sensorCode = base64_decode($_GET['sensorCode']);
		$gatewayCode = base64_decode($_GET['gatewayCode']);
		
		$ldc=date("Y", strtotime("first day of previous month"));
        $ldl=date("n", strtotime("last day of previous month"));
		
		$selQry = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND DATE(recorded_date)=DATE('.$nowDate.') AND MONTH(recorded_date)=MONTH('.$nowDate.') AND YEAR(recorded_date)=YEAR('.$nowDate.') AND gateway_code="'.$gatewayCode.'" AND `sensor_code`="'.$sensorCode.'"'; 
		$todayCostKWH		= $this->ExecuteQuery($selQry, "select");
		$objSmarty->assign('todayCostKWH', $todayCostKWH);
	
		$selQry2 = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND `gateway_code`="'.$gatewayCode.'" AND `sensor_code`="'.$sensorCode.'" AND Month(recorded_date)=MONTH('.$nowDate.') AND YEAR(recorded_date)=YEAR('.$nowDate.')';
		$monthCostKWH		= $this->ExecuteQuery($selQry2, "select");
		$objSmarty->assign('monthCostKWH', $monthCostKWH);
	
		$selQry3 = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND `gateway_code`="'.$gatewayCode.'" AND `sensor_code`="'.$sensorCode.'" AND MONTH(recorded_date)="'.$ldl.'" AND YEAR(recorded_date)="'.$ldc.'" ';
		$LastMonthCostKWH		= $this->ExecuteQuery($selQry3, "select");
		$objSmarty->assign('LastMonthCostKWH', $LastMonthCostKWH);
	
	}
     /********************* GetCostKwhSingle Functions Ends **************************/
	 /********************* GetBarGraph Functions Starts **************************/
	function GetBarGraph(){
		global $objSmarty,$config,$nowDate;
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}
		$sensorCode = base64_decode($_GET['sensorCode']);
		$gatewayCode = base64_decode($_GET['gatewayCode']);
		
		$selBarGraph='SELECT DATE_FORMAT(recorded_date,"%b") AS month_data, consuption_cost, dg_consuption_cost  FROM cron_monthly_energy_data WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND gateway_code="'.$gatewayCode.'" AND sensor_code="'.$sensorCode.'" AND DATE(recorded_date)>= DATE(DATE_SUB('.$nowDate.',INTERVAL 12 MONTH)) AND DATE(recorded_date)<= DATE('.$nowDate.') order by recorded_date ASC'; 
		$ExeBarGraph		= $this->ExecuteQuery($selBarGraph, "select");
		$ExeBarGraphCount		= $this->ExecuteQuery($selBarGraph, "numrows");
		
	$objParm='';
	$objParmDg='';
	foreach($ExeBarGraph as $key=>$value)
	{
		$objParm .='{"month": "'.$ExeBarGraph[$key]["month_data"].'","cost": '.$ExeBarGraph[$key]["consuption_cost"].',"dgcost": '.$ExeBarGraph[$key]["dg_consuption_cost"].'},';
		$objParmDg .='{
		"month": "'.$ExeBarGraph[$key]["month_data"].'",
		"cost": '.$ExeBarGraph[$key]["dg_consuption_cost"].'
		},';
	}
	
		$BarGraphData="[".rtrim($objParm, ",")."]";
		$dgBarGraphData="[".rtrim($objParmDg, ",")."]";
		$objSmarty->assign('BarGraphData',$BarGraphData);
		$objSmarty->assign('dgBarGraphData',$dgBarGraphData);
	
		$selLineGraph='SELECT DATE_FORMAT(recorded_date,"%b") AS month_data, consuption_kwh, dg_consuption_kwh  FROM cron_monthly_energy_data WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND gateway_code="'.$gatewayCode.'" AND sensor_code="'.$sensorCode.'"  AND DATE(recorded_date)>= DATE(DATE_SUB('.$nowDate.',INTERVAL 12 MONTH)) AND DATE(recorded_date)<= DATE('.$nowDate.') order by recorded_date ASC';
		$ExeLineGraph		= $this->ExecuteQuery($selLineGraph, "select");
		$ExeLineGraphCount		= $this->ExecuteQuery($selLineGraph, "numrows");
		
	$objParm2='';
	$objParm2Dg='';
	foreach($ExeLineGraph as $key2=>$value2)
	{
		$objParm2 .='{"month": "'.$ExeLineGraph[$key2]["month_data"].'","EB": '.$ExeLineGraph[$key2]["consuption_kwh"].',"DG": '.$ExeLineGraph[$key2]["dg_consuption_kwh"].'},';
		$objParm2Dg .='{
		"month": "'.$ExeLineGraph[$key2]["month_data"].'",
		"kwh": '.$ExeLineGraph[$key2]["dg_consuption_kwh"].'
		},';
	}
	
	$objGraph2='{
	"title": "EB Kwh",
	"balloonText": "[[title]]: <b>[[value]]</b>",
	"bullet": "round",
	"bulletSize": 10,
	"bulletBorderColor": "#ffffff",
	"bulletBorderAlpha": 1,
	"bulletBorderThickness": 2,
	"type": "smoothedLine",
	"valueField": "EB"
	},{
	"title": "DG Kwh",
	"balloonText": "[[title]]: <b>[[value]]</b>",
	"bullet": "round",
	"bulletSize": 10,
	"bulletBorderColor": "#ffffff",
	"bulletBorderAlpha": 1,
	"bulletBorderThickness": 2,
	"type": "smoothedLine",
	"valueField": "DG"
	}';
	
		$LineGraphData="[".rtrim($objParm2, ",")."]";
		$LineGraphData2="[".rtrim($objGraph2, ",")."]";
		$dgLineGraphData="[".rtrim($objParm2Dg, ",")."]";
		$objSmarty->assign('LineGraphData',$LineGraphData);
		$objSmarty->assign('LineGraphData2',$LineGraphData2);
		$objSmarty->assign('dgLineGraphData',$dgLineGraphData);
	}
    /********************* GetBarGraph Functions Ends **************************/
	 /********************* GetMeterLogGraph Functions Ends **************************/
	 function GetMeterLogGraph()
 {
	global $objSmarty,$config,$nowDate;
	$pf='';
	$gatewayCode = base64_decode($_GET['gatewayCode']);
	$sensorCode = base64_decode($_GET['sensorCode']);
	if(isset($_POST['date1']) && isset($_POST['date2']))
	{
		$date1 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		$date2 = date("Y-m-d",strtotime(trim(addslashes($_POST['date2']))));
		$yaxis = @$_POST['yAxis'];
	if($yaxis== 'VOLTAGE' || $yaxis== 'CURRENT')
	{
		$yaxis_par="R_".$yaxis.",Y_".$yaxis.",B_".$yaxis;
		$pf=0;
	}
	else if($yaxis== 'SUM_PF'){
		$yaxis_par="TRUNCATE(IF(`SUM_PF` >= 1 AND `SUM_PF` < 2 , '-0.99', IF(`SUM_PF` >= 2 , '1', `SUM_PF`)),2) AS SUM_PF ";
		$pf=1;
	}
	else
	{
		$yaxis_par =$yaxis;
		$pf=2;
	}
		$query_rs1 =  "SELECT ".$yaxis_par.",recorded_date_time AS TM FROM energy_data_master WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND (DATE(recorded_date_time) BETWEEN '".$date1."' AND '".$date2."') ORDER BY TM ASC";
	}
	else
	{
		$yaxis_par="R_VOLTAGE,Y_VOLTAGE,B_VOLTAGE";
		$query_rs1 = "SELECT ".$yaxis_par.",recorded_date_time AS TM FROM energy_data_master WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND DATE(recorded_date_time) = DATE(CONVERT_TZ(NOW(),'+00:00' ,'+00:00')) ORDER BY TM ASC";
	}
		$GetTemp = $this->ExecuteQuery($query_rs1, "select");
		$objSmarty->assign('GetTemp', $GetTemp);
	if($pf!=1)
	{
		$splVar= explode(",",$yaxis_par);
	}
	else
	{
		$splVar=array("SUM_PF");
	}
		$arrData = array();
	foreach ($GetTemp as $key => $value) 
	{
		$orgDate =$GetTemp[$key]['TM'];  
		$GDate = date("d-M-Y h:i A", strtotime($orgDate));
	if($splVar[1]!='')
	{
		array_push($arrData, array(
		$splVar[0] => $GetTemp[$key][$splVar[0]],
		$splVar[1] => $GetTemp[$key][$splVar[1]],
		$splVar[2] => $GetTemp[$key][$splVar[2]],
		"tm" => $GDate
		));
	}
	else
	{
		array_push($arrData, array(
		$splVar[0] => $GetTemp[$key][$splVar[0]],
		"tm" => $GDate
		));
	}
	}
		$ChartData = json_encode($arrData);
		$objSmarty->assign('ChartData', $ChartData);
	}
        /********************* GetMeterLogGraph Functions Ends **************************/
         /********************* GetPowerMeterLogGraph Functions Ends **************************/
	 function GetPowerMeterLogGraph()
 {
	global $objSmarty,$config,$nowDate;
	$pf='';
	$gatewayCode = base64_decode($_GET['gatewayCode']);
	$sensorCode = base64_decode($_GET['sensorCode']);
	if(isset($_POST['date1']) && isset($_POST['date2']))
	{
		$date1 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		$date2 = date("Y-m-d",strtotime(trim(addslashes($_POST['date2']))));
		$yaxis = @$_POST['yAxis'];
	if($yaxis== 'VOLTAGE')
	{
		$yaxis_par="R_VOLTAGE,Y_VOLTAGE,B_VOLTAGE";
		$yaxis_par1="voltage_l1_n AS R_VOLTAGE,voltage_l2_n AS Y_VOLTAGE,voltage_l3_n AS B_VOLTAGE";
		$pf=0;
	}
	else if($yaxis== 'CURRENT')
	{
	    $yaxis_par="R_CURRENT,Y_CURRENT,B_CURRENT";
		$yaxis_par1="current_l1 AS R_CURRENT,current_l2 AS Y_CURRENT,current_l3 AS B_CURRENT";
		$pf=0;
	}
	else if($yaxis== 'SUM_PF')
	{
	    $yaxis_par="SUM_PF";
		$yaxis_par1="power_factor_total_import AS SUM_PF ";
		$pf=1;
	}
	else if($yaxis == 'SUM_KVA')
	{
		$yaxis_par ="SUM_KVA";
		$yaxis_par1 ="(apparent_power_l1_n/1000) AS SUM_KVA";
		$pf=2;
	}
	else if($yaxis == 'SUM_KW')
	{
		$yaxis_par ="SUM_KW";
		$yaxis_par1 ="(total_active_power/1000) AS SUM_KW";
		$pf=2;
	}
	else if($yaxis == 'SUM_KVAR')
	{
		$yaxis_par ="SUM_KVAR";
		$yaxis_par1 ="(total_reactive_power/1000) AS SUM_KVAR";
		$pf=2;
	}
		$query_rs1 =  "SELECT ".$yaxis_par1.",recorded_date_time AS TM FROM power_factor_energy_data WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND (DATE(recorded_date_time) BETWEEN '".$date1."' AND '".$date2."') ORDER BY TM ASC";
	}
	else
	{
	    	$yaxis_par="R_VOLTAGE,Y_VOLTAGE,B_VOLTAGE";
		$yaxis_par1="voltage_l1_n AS R_VOLTAGE,voltage_l2_n AS Y_VOLTAGE,voltage_l3_n AS B_VOLTAGE";
		$query_rs1 = "SELECT ".$yaxis_par1.",recorded_date_time AS TM FROM power_factor_energy_data WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND DATE(recorded_date_time) = DATE(CONVERT_TZ(NOW(),'+00:00' ,'+00:00')) ORDER BY TM ASC";
	}
//	echo $query_rs1;
		$GetTemp = $this->ExecuteQuery($query_rs1, "select");
		$objSmarty->assign('GetTemp', $GetTemp);
	if($pf!=1)
	{
		$splVar= explode(",",$yaxis_par);
	}
	else
	{
		$splVar=array("SUM_PF");
	}
		$arrData = array();
	foreach ($GetTemp as $key => $value) 
	{
		$orgDate =$GetTemp[$key]['TM'];  
		$GDate = date("d-M-Y h:i A", strtotime($orgDate));
	if($splVar[1]!='')
	{
		array_push($arrData, array(
		$splVar[0] => $GetTemp[$key][$splVar[0]],
		$splVar[1] => $GetTemp[$key][$splVar[1]],
		$splVar[2] => $GetTemp[$key][$splVar[2]],
		"tm" => $GDate
		));
	}
	else
	{
		array_push($arrData, array(
		$splVar[0] => $GetTemp[$key][$splVar[0]],
		"tm" => $GDate
		));
	}
	}
		$ChartData = json_encode($arrData);
		$objSmarty->assign('ChartData', $ChartData);
	}
        /********************* GetPowerMeterLogGraph Functions Ends **************************/
		/********************* GetIcdLog Functions Starts **************************/
	function GetIcdLog()
	{
		global $objSmarty,$config,$nowDate;
		$gatewayCode = base64_decode($_GET['gatewayCode']);
		$sensorCode = base64_decode($_GET['sensorCode']);
		$senMod =  explode("-",base64_decode($_GET['sensorCode'])); 
	if(isset($_POST['date1']) && isset($_POST['date2']))
	{
		$date1 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		$date2 = date("Y-m-d",strtotime(trim(addslashes($_POST['date2']))));
		$query_rs1 =  "SELECT recorded_date_time AS TM,posted_date_time,linux_date_time,teltonika_date_time,gateway_code,sensor_code,sensor_model,`METER_ID`, `R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`, `SUM_PF`, `FREQUENCY`, `KWH_MSB`, `KWH_LSB`, `KWH`, `METER_TYPE_RUN_HOUR_MSB`, `RUN_HOUR_LSB`, `RUN_HOUR`, `IMPORT_EXPORT` FROM energy_data_master WHERE gateway_code='".$gatewayCode."' AND EB_DG_STATUS<>'1' AND sensor_code='".$sensorCode."' AND (DATE(recorded_date_time) BETWEEN '".$date1."' AND '".$date2."') ORDER BY TM DESC";
	}
	else
	{
		$query_rs1 = "SELECT recorded_date_time AS TM,posted_date_time,linux_date_time,teltonika_date_time,gateway_code,sensor_code,sensor_model,`METER_ID`, `R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`, `SUM_PF`, `FREQUENCY`, `KWH_MSB`, `KWH_LSB`, `KWH`, `METER_TYPE_RUN_HOUR_MSB`, `RUN_HOUR_LSB`, `RUN_HOUR`, `IMPORT_EXPORT` FROM energy_data_master WHERE  gateway_code='".$gatewayCode."' AND EB_DG_STATUS<>'1' AND sensor_code='".$sensorCode."' AND  DATE(recorded_date_time) = DATE(CONVERT_TZ(NOW(),'+00:00' ,'+00:00'))  ORDER BY TM DESC";
	}//echo $query_rs1;exit;
		$GetICD = $this->ExecuteQuery($query_rs1, "select");
		$objSmarty->assign('GetICD', $GetICD);
	}
     /********************* GetIcdLog Functions Ends **************************/
     	/********************* GetIcdLog Functions Starts **************************/
	function GetPowerIcdLog()
	{
		global $objSmarty,$config,$nowDate;
		$gatewayCode = base64_decode($_GET['gatewayCode']);
		$sensorCode = base64_decode($_GET['sensorCode']);
		$senMod =  explode("-",base64_decode($_GET['sensorCode'])); 
	if(isset($_POST['date1']) && isset($_POST['date2']))
	{
		$date1 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		$date2 = date("Y-m-d",strtotime(trim(addslashes($_POST['date2']))));
		$query_rs1 =  "SELECT recorded_date_time AS TM,posted_date_time,linux_date_time,teltonika_date_time,gateway_code,sensor_code,sensor_model,`power_factor_id` AS METER_ID,voltage_l1_n AS `R_VOLTAGE`,voltage_l2_n AS `Y_VOLTAGE`,voltage_l3_n AS `B_VOLTAGE`,voltage_l1_l2 AS `RY_VOLTAGE`,voltage_l2_l3 AS `YB_VOLTAGE`,voltage_l3_l1 AS `BR_VOLTAGE`,current_l1 AS `R_CURRENT`,current_l2 AS `Y_CURRENT`,current_l3 AS `B_CURRENT`,apparent_power_l1_n AS `SUM_KVA`,total_active_power AS `SUM_KW`,total_reactive_power AS `SUM_KVAR`,power_factor_total_import AS `SUM_PF`,measured_frequency AS `FREQUENCY`,cospi_total_import AS `IMPORT_EXPORT` FROM power_factor_energy_data WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND (DATE(recorded_date_time) BETWEEN '".$date1."' AND '".$date2."') ORDER BY TM DESC";
	}
	else
	{
		$query_rs1 =  "SELECT recorded_date_time AS TM,posted_date_time,linux_date_time,teltonika_date_time,gateway_code,sensor_code,sensor_model,`power_factor_id` AS METER_ID,voltage_l1_n AS `R_VOLTAGE`,voltage_l2_n AS `Y_VOLTAGE`,voltage_l3_n AS `B_VOLTAGE`,voltage_l1_l2 AS `RY_VOLTAGE`,voltage_l2_l3 AS `YB_VOLTAGE`,voltage_l3_l1 AS `BR_VOLTAGE`,current_l1 AS `R_CURRENT`,current_l2 AS `Y_CURRENT`,current_l3 AS `B_CURRENT`,apparent_power_l1_n AS `SUM_KVA`,total_active_power AS `SUM_KW`,total_reactive_power AS `SUM_KVAR`,power_factor_total_import AS `SUM_PF`,measured_frequency AS `FREQUENCY`,cospi_total_import AS `IMPORT_EXPORT` FROM power_factor_energy_data WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND DATE(recorded_date_time) = DATE(CONVERT_TZ(NOW(),'+00:00' ,'+00:00')) ORDER BY TM DESC";
	}//echo $query_rs1;
		$GetICD = $this->ExecuteQuery($query_rs1, "select");
		$objSmarty->assign('GetICD', $GetICD);
	}
     /********************* GetIcdLog Functions Ends **************************/
	 /********************* GetDailyLog Functions Starts **************************/
	function GetDailyLog()
	{
		global $objSmarty,$config,$nowDate;
		$gatewayCode = base64_decode($_GET['gatewayCode']);
		$sensorCode = base64_decode($_GET['sensorCode']);
		$nowDate= "NOW()";
	if(isset($_POST['date1']) && isset($_POST['date2']))
	{
		$date1 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		$date2 = date("Y-m-d",strtotime(trim(addslashes($_POST['date2']))));
		$query_rs1 =  "SELECT * FROM cron_daily_energy_data WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND recorded_date < ".$nowDate." AND  (DATE(recorded_date) BETWEEN '".$date1."' AND '".$date2."') ORDER BY recorded_date DESC";
	}
	else
	{
		$query_rs1 = "SELECT * FROM cron_daily_energy_data WHERE  gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."'  AND YEAR(recorded_date) = YEAR(".$nowDate.") AND  MONTH(recorded_date) = MONTH(".$nowDate.") AND recorded_date < DATE(".$nowDate.")  ORDER BY recorded_date DESC";
	}
//	echo $query_rs1;
		$GetDLog = $this->ExecuteQuery($query_rs1, "select");
		$objSmarty->assign('GetDLog', $GetDLog);
	}
      /********************* GetDailyLog Functions Ends **************************/
       /********************* GetDailyLog Functions Starts **************************/
	function GetPowerDailyLog()
	{
		global $objSmarty,$config,$nowDate;
		$gatewayCode = base64_decode($_GET['gatewayCode']);
		$sensorCode = base64_decode($_GET['sensorCode']);
		$nowDate= "NOW()";
		if(isset($_POST['date1']) && isset($_POST['date2']))
	{
		$date1 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		$date2 = date("Y-m-d",strtotime(trim(addslashes($_POST['date2']))));
		$query_rs1 =  "SELECT recorded_date_time AS TM,DATE(recorded_date_time) AS recorded_date,posted_date_time,linux_date_time,teltonika_date_time,gateway_code,sensor_code,sensor_model,`power_factor_id` AS METER_ID,voltage_l1_n AS `R_VOLTAGE`,voltage_l2_n AS `Y_VOLTAGE`,voltage_l3_n AS `B_VOLTAGE`,voltage_l1_l2 AS `RY_VOLTAGE`,voltage_l2_l3 AS `YB_VOLTAGE`,voltage_l3_l1 AS `BR_VOLTAGE`,current_l1 AS `R_CURRENT`,current_l2 AS `Y_CURRENT`,current_l3 AS `B_CURRENT`,apparent_power_l1_n AS `SUM_KVA`,total_active_power AS `SUM_KW`,total_reactive_power AS `SUM_KVAR`,power_factor_total_import AS `SUM_PF`,measured_frequency AS `FREQUENCY`,cospi_total_import AS `IMPORT_EXPORT` FROM power_factor_energy_data WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND (DATE(recorded_date_time) BETWEEN '".$date1."' AND '".$date2."') ORDER BY TM DESC";
	}
	else
	{
		$query_rs1 =  "SELECT recorded_date_time AS TM,DATE(recorded_date_time) AS recorded_date,posted_date_time,linux_date_time,teltonika_date_time,gateway_code,sensor_code,sensor_model,`power_factor_id` AS METER_ID,voltage_l1_n AS `R_VOLTAGE`,voltage_l2_n AS `Y_VOLTAGE`,voltage_l3_n AS `B_VOLTAGE`,voltage_l1_l2 AS `RY_VOLTAGE`,voltage_l2_l3 AS `YB_VOLTAGE`,voltage_l3_l1 AS `BR_VOLTAGE`,current_l1 AS `R_CURRENT`,current_l2 AS `Y_CURRENT`,current_l3 AS `B_CURRENT`,apparent_power_l1_n AS `SUM_KVA`,total_active_power AS `SUM_KW`,total_reactive_power AS `SUM_KVAR`,power_factor_total_import AS `SUM_PF`,measured_frequency AS `FREQUENCY`,cospi_total_import AS `IMPORT_EXPORT` FROM power_factor_energy_data WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND  MONTH(recorded_date_time) = MONTH(".$nowDate.") AND DATE(recorded_date_time) < DATE(".$nowDate.") ORDER BY TM DESC";
	}
//	echo $query_rs1;
		$GetDLog = $this->ExecuteQuery($query_rs1, "select");
		$objSmarty->assign('GetDLog', $GetDLog);
	}
      /********************* GetDailyLog Functions Ends **************************/
            /********* ListBranch Functions Starts ********************************/
	function ListBranch($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> '')
		{
			$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
			$comId = $_SESSION['CustomerId'];
		}
			$SelQuery = 'SELECT * FROM  `'.$tbl.'branch_master` WHERE company_id="'.$comId.'" AND record_status="1"';  
			$ListView = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListView', $ListView);
		
			$SelQuery2 = 'SELECT `'.$tbl.'platform_mapping`.*,`'.$tbl.'iot_platform`.segmentName FROM  `'.$tbl.'platform_mapping`,`'.$tbl.'iot_platform` WHERE `'.$tbl.'platform_mapping`.segmentCode=`'.$tbl.'iot_platform`.slNo AND `'.$tbl.'platform_mapping`.companyName="'.$comId.'" AND `'.$tbl.'platform_mapping`.status="1" AND `'.$tbl.'platform_mapping`.isActive="1"';  
			$platformView = $this->ExecuteQuery($SelQuery2, 'select');
			$objSmarty->assign('platformView', $platformView);
	}
    /********* ListBranch Functions End ********************************/
    /*************Get Unitrate function Starts****************************************/
	function GetUnitRate()
		{
			global $objSmarty,$config,$nowDate;
			$tbl = $config['DBPrefix'];
		$sensorCode=base64_decode($_GET['sensorCode']);
		$gatewayCode=base64_decode($_GET['gatewayCode']);
		if($_GET['companyId'] <> '')
		{
		   $comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		   $comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		   $branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		   $branchId = $_SESSION['branch_id'];
		}
		
		if($branchId =='0')
		{
			$whrClass='cron_monthly_energy_data.company_id="'.$comId.'"';
		}else
		{
			$whrClass='cron_monthly_energy_data.company_id="'.$comId.'" AND cron_monthly_energy_data.branch_id="'.$branchId.'"';
		}
		
		
		$query_rs1 = "SELECT * FROM cron_monthly_energy_data WHERE  gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND  MONTH(recorded_date) = MONTH(NOW()) AND YEAR(recorded_date) = YEAR(NOW())";
		$ThisPostData = $this->ExecuteQuery($SelQuery, 'select');
	    $objSmarty->assign('ThisPostData', $ThisPostData);
		
		$query_rs1 = "SELECT * FROM cron_monthly_energy_data WHERE  gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND  MONTH(recorded_date) = MONTH(NOW())-1 AND YEAR(recorded_date) = YEAR(NOW())";
		$LastPostData = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('LastPostData', $LastPostData);
		
		}
	/*******************Get Unitrate function Ends***********************************/
	   /********************* Current Month Daily GetMultiLineGraph Branch Functions starts **********************/
	  function currMonthDailygraph()
	  {
	  
global $objSmarty;
			$cm = date('m');
		$cmon = date('m');//echo $cmon;echo "<br>";
	    $lmon = date('m', strtotime('-5 month'));//echo $lmon;echo "<br>";
			$pyr = date('Y')-1;
			$cyr = date('Y');
			$nyr = date('Y')+1;
			if($cm >= '06')
			{
			$sd=$cyr.'-'.$lmon.'-01';
			$ed=$cyr.'-'.$cmon.'-31';
			}
			else
			{
		    $sd=$pyr.'-'.$lmon.'-01';
			$ed=$cyr.'-'.$cmon.'-31';
			}
			//echo $sd;echo $ed;
			  if($_GET['companyId'] <> '')
{
	$comId = base64_decode($_GET['companyId']);
}	
else
{
	$comId = $_SESSION['CustomerId'];
}
if($_GET['branchId'] <> '')
{
$branchId = base64_decode($_GET['branchId']);
}	
else
{
$branchId = $_SESSION['branch_id'];
}
if($_GET['sensorCode'] <> '')
{
$sensorCode = base64_decode($_GET['sensorCode']);
$wherCls = ' AND sensor_code="'.$sensorCode.'" ';
}	
else
{
$wherCls = '';

}

	
	 $colors2 =array("#C2272D", "#F8931F", "#FFFF01", "#009245", "#0193D9", "#0C04ED", 

"#612F90","#F8DC70", "#EA7A2C", "#32A6F4", "#EB34F9", "#12896E", "#0EF1C1" , "#6F6653", "#F60720" , 

"#5A0E7E" ,"#2337D1" ,"#DAF7A6", "#33FFE6","#33C1FF","#DA33FF", "#EA99B0", "#6D7C78", "#FAE7AC", 

"#F5A399");

 //$SelQuery1	= 'SELECT SUM(consuption_kwh+dg_consuption_kwh) AS skwh,SUM(consuption_cost+dg_consuption_cost) AS scost,MONTHNAME(`recorded_date`) AS rec_month,company_id,branch_id,recorded_date FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND feeder_type="Main Meter" AND recorded_date BETWEEN "'.$sd.'" AND "'.$ed.'" GROUP BY MONTH(`recorded_date`) ORDER BY recorded_date ASC';
  $SelQuery1= 'SELECT SUM(consuption_kwh+dg_consuption_kwh) AS skwh,SUM(consuption_cost+dg_consuption_cost) AS scost,DATE_FORMAT(`recorded_date`, "%d-%M-%Y") AS rec_month,company_id,branch_id,recorded_date,sensor_code FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND feeder_type="Main Meter" AND recorded_date BETWEEN "'.$sd.'" AND "'.$ed.'" '.$wherCls.' GROUP BY `recorded_date` ORDER BY recorded_date ASC'; 


	  $graphMasterlist = $this->ExecuteQuery($SelQuery1,"select");
	  $objSmarty->assign('graphMasterlist', $graphMasterlist);
	  $test2 = array_values($graphMasterlist);
	  $loopArray2 ='';
      $countItemWiseCurMonSalQty = count($graphMasterlist);

for($k2=0; $k2<$countItemWiseCurMonSalQty; $k2++)
{
if($k2==0){
	$loopArray2 .= '{"dateM":"'.$test2[$k2][rec_month].'","value":"'.$test2[$k2][skwh].'","value1":"'.$test2[$k2][scost].'","color":"'.$colors2[$k2].'"}';
	}
	else
	{
	$loopArray2 .= ',{"dateM":"'.$test2[$k2][rec_month].'","value":"'.$test2[$k2][skwh].'","value1":"'.$test2[$k2][scost].'","color":"'.$colors2[$k2].'"}';
	}
}

$getCurMonSalDaily ="[".$loopArray2."]";	
$objSmarty->assign('getCurMonSalDaily', $getCurMonSalDaily);

	  }
	  /**********************Current Month Daily GetMultiLineGraph Branch Functions starts***************************************************/
	    /********************* GetMultiLineGraph Branch Functions starts **********************/
	  function Multilinegraph()
	  {
	  
global $objSmarty;
			$cm = date('m');
		$cmon = date('m');//echo $cmon;echo "<br>";
	    $lmon = date('m', strtotime('-5 month'));//echo $lmon;echo "<br>";
			$pyr = date('Y')-1;
			$cyr = date('Y');
			$nyr = date('Y')+1;
			if($cm >= '06')
			{
			$sd=$cyr.'-'.$lmon.'-01';
			$ed=$cyr.'-'.$cmon.'-31';
			}
			else
			{
		    $sd=$pyr.'-'.$lmon.'-01';
			$ed=$cyr.'-'.$cmon.'-31';
			}
			//echo $sd;echo $ed;
			  if($_GET['companyId'] <> '')
{
	$comId = base64_decode($_GET['companyId']);
}	
else
{
	$comId = $_SESSION['CustomerId'];
}
if($_GET['branchId'] <> '')
{
$branchId = base64_decode($_GET['branchId']);
}	
else
{
$branchId = $_SESSION['branch_id'];
}
	
	 $colors2 =array("#C2272D", "#F8931F", "#FFFF01", "#009245", "#0193D9", "#0C04ED", 

"#612F90","#F8DC70", "#EA7A2C", "#32A6F4", "#EB34F9", "#12896E", "#0EF1C1" , "#6F6653", "#F60720" , 

"#5A0E7E" ,"#2337D1" ,"#DAF7A6", "#33FFE6","#33C1FF","#DA33FF", "#EA99B0", "#6D7C78", "#FAE7AC", 

"#F5A399");

 $SelQuery1	= 'SELECT SUM(consuption_kwh+dg_consuption_kwh) AS skwh,SUM(consuption_cost+dg_consuption_cost) AS scost,MONTHNAME(`recorded_date`) AS rec_month,company_id,branch_id,recorded_date FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND feeder_type="Main Meter" AND recorded_date BETWEEN "'.$sd.'" AND "'.$ed.'" GROUP BY MONTH(`recorded_date`) ORDER BY recorded_date ASC';


	  $graphMasterlist = $this->ExecuteQuery($SelQuery1,"select");
	  $objSmarty->assign('graphMasterlist', $graphMasterlist);
	  $test2 = array_values($graphMasterlist);
	  $loopArray2 ='';
      $countItemWiseCurMonSalQty = count($graphMasterlist);

for($k2=0; $k2<$countItemWiseCurMonSalQty; $k2++)
{
if($k2==0){
	$loopArray2 .= '{"month":"'.$test2[$k2][rec_month].'","value":"'.$test2[$k2][skwh].'","value1":"'.$test2[$k2][scost].'","color":"'.$colors2[$k2].'"}';
	}
	else
	{
	$loopArray2 .= ',{"month":"'.$test2[$k2][rec_month].'","value":"'.$test2[$k2][skwh].'","value1":"'.$test2[$k2][scost].'","color":"'.$colors2[$k2].'"}';
	}
}

$getCurMonSal ="[".$loopArray2."]";	
$objSmarty->assign('getCurMonQut', $getCurMonSal);

	  }
	  /**********************GetMultiLineGraph Branch Functions starts***************************************************/
	  /********************* GetDGIcdLog Functions Starts **************************/
	function GetDGIcdLog()
	{
		global $objSmarty,$config,$nowDate;
		$gatewayCode = base64_decode($_GET['gatewayCode']);
		$sensorCode = base64_decode($_GET['sensorCode']);
		$senMod =  explode("-",base64_decode($_GET['sensorCode'])); 
	if(isset($_POST['date1']) && isset($_POST['date2']))
	{
		$date1 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		$date2 = date("Y-m-d",strtotime(trim(addslashes($_POST['date2']))));
		$query_rs1 =  "SELECT recorded_date_time AS TM,posted_date_time,linux_date_time,teltonika_date_time,gateway_code,sensor_code,sensor_model,`METER_ID`, `R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`,`DG_KVAH`, `DG_KWH`, `DG_KVARH`, `SUM_PF`, `FREQUENCY`, `KWH_MSB`, `KWH_LSB`, `KWH`, `METER_TYPE_RUN_HOUR_MSB`, `RUN_HOUR_LSB`, `RUN_HOUR`, `IMPORT_EXPORT` FROM energy_data_master WHERE gateway_code='".$gatewayCode."' AND EB_DG_STATUS='1' AND sensor_code='".$sensorCode."' AND (DATE(recorded_date_time) BETWEEN '".$date1."' AND '".$date2."') ORDER BY TM DESC";
	}
	else
	{
		$query_rs1 = "SELECT recorded_date_time AS TM,posted_date_time,linux_date_time,teltonika_date_time,gateway_code,sensor_code,sensor_model,`METER_ID`, `R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`,`DG_KVAH`, `DG_KWH`, `DG_KVARH`, `SUM_PF`, `FREQUENCY`, `KWH_MSB`, `KWH_LSB`, `KWH`, `METER_TYPE_RUN_HOUR_MSB`, `RUN_HOUR_LSB`, `RUN_HOUR`, `IMPORT_EXPORT` FROM energy_data_master WHERE  gateway_code='".$gatewayCode."' AND EB_DG_STATUS='1' AND sensor_code='".$sensorCode."' AND  DATE(recorded_date_time) = DATE(CONVERT_TZ(NOW(),'+00:00' ,'+00:00'))  ORDER BY TM DESC";
	}
		$GetDGICD = $this->ExecuteQuery($query_rs1, "select");
		$objSmarty->assign('GetDGICD', $GetDGICD);
	}
     /********************* GetDGIcdLog Functions Ends **************************/
	 /********************* GetDailyLog Functions Starts **************************/
	function GetDGDailyLog()
	{
		global $objSmarty,$config,$nowDate;
		$gatewayCode = base64_decode($_GET['gatewayCode']);
		$sensorCode = base64_decode($_GET['sensorCode']);
		$nowDate= "NOW()";
	if(isset($_POST['date1']) && isset($_POST['date2']))
	{
		$date1 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		$date2 = date("Y-m-d",strtotime(trim(addslashes($_POST['date2']))));
		$query_rs1 =  "SELECT * FROM cron_daily_energy_data WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND recorded_date < ".$nowDate." AND  (DATE(recorded_date) BETWEEN '".$date1."' AND '".$date2."') ORDER BY recorded_date DESC";
	}
	else
	{
		$query_rs1 = "SELECT * FROM cron_daily_energy_data WHERE  gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND  MONTH(recorded_date) = MONTH(".$nowDate.") AND recorded_date < DATE(".$nowDate.")  ORDER BY recorded_date DESC";
	}
		$GetDGDLog = $this->ExecuteQuery($query_rs1, "select");
		$objSmarty->assign('GetDGDLog', $GetDGDLog);
	}
      /********************* GetDailyLog Functions Ends **************************/
       /*************************Dashboard Piechart Function Starts*************************************/
	    function MultiBarChart()
	  {
	  
global $objSmarty;
		$cdd = date('d');
		$cmon = date('m');
	    $lmon = date('m', strtotime('-1 month'));
		$cyr = date('Y');
		$lyr = date('Y')-1;
		
	
		
		    $ld = date('t',strtotime('last month'));
			$ldc=$cyr.'-'.$lmon.'-01';
			$ldl=$cyr.'-'.$lmon.'-'.$ld;
			$ldc=date("Y-n-j", strtotime("first day of previous month"));
            $ldl=date("Y-n-j", strtotime("last day of previous month"));
	
			
			$ld1 = date('t');
		    $cdc=$cyr.'-'.$cmon.'-01';
			$cdl=$cyr.'-'.$cmon.'-'.$ld1;
			
			$cd=$cyr.'-'.$cmon.'-'.$cdd;
			
			  if($_GET['companyId'] <> '')
{
	$comId = base64_decode($_GET['companyId']);
}	
else
{
	$comId = $_SESSION['CustomerId'];
}
if($_GET['branchId'] <> '')
{
$branchId = base64_decode($_GET['branchId']);
}	
else
{
$branchId = $_SESSION['branch_id'];
}
	
	 $colors2 =array("#C2272D", "#F8931F", "#FFFF01", "#009245", "#0193D9", "#0C04ED", 

"#612F90","#F8DC70", "#EA7A2C", "#32A6F4", "#EB34F9", "#12896E", "#0EF1C1" , "#6F6653", "#F60720" , 

"#5A0E7E" ,"#2337D1" ,"#DAF7A6", "#33FFE6","#33C1FF","#DA33FF", "#EA99B0", "#6D7C78", "#FAE7AC", 

"#F5A399");

// $SelQuery1	= 'SELECT SUM(`consuption_kwh`) AS skwh,SUM(`consuption_cost`) AS scost,MONTHNAME(`recorded_date`) AS rec_month,company_id,branch_id,sensor_code FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND feeder_type="Main Meter" AND recorded_date BETWEEN "'.$ldc.'" AND "'.$ldl.'" GROUP BY sensor_code';

// $SelQuery2	= 'SELECT SUM(`consuption_kwh`) AS skwh,SUM(`consuption_cost`) AS scost,MONTHNAME(`recorded_date`) AS rec_month,company_id,branch_id,sensor_code FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND feeder_type="Main Meter" AND recorded_date BETWEEN "'.$cdc.'" AND "'.$cdl.'" GROUP BY sensor_code';

//$SelQuery3	= 'SELECT SUM(`consuption_kwh`) AS skwh,SUM(`consuption_cost`) AS scost,MONTHNAME(`recorded_date`) AS rec_month,company_id,branch_id,sensor_code FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND feeder_type="Main Meter" AND recorded_date BETWEEN "'.$cd.'" AND "'.$cd.'" GROUP BY sensor_code';

 $SelQuery1	= 'SELECT SUM(consuption_kwh+dg_consuption_kwh) AS skwh,SUM(consuption_cost+dg_consuption_cost) AS scost,MONTHNAME(`recorded_date`) AS rec_month,company_id,branch_id,sensor_code FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND feeder_type="Main Meter" AND recorded_date BETWEEN "'.$ldc.'" AND "'.$ldl.'" GROUP BY sensor_code';

 $SelQuery2	= 'SELECT SUM(consuption_kwh+dg_consuption_kwh) AS skwh,SUM(consuption_cost+dg_consuption_cost) AS scost,MONTHNAME(`recorded_date`) AS rec_month,company_id,branch_id,sensor_code FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND feeder_type="Main Meter" AND recorded_date BETWEEN "'.$cdc.'" AND "'.$cdl.'" GROUP BY sensor_code';

$SelQuery3	= 'SELECT SUM(consuption_kwh+dg_consuption_kwh) AS skwh,SUM(consuption_cost+dg_consuption_cost) AS scost,MONTHNAME(`recorded_date`) AS rec_month,company_id,branch_id,sensor_code FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND feeder_type="Main Meter" AND recorded_date BETWEEN "'.$cd.'" AND "'.$cd.'" GROUP BY sensor_code';


	  $graphMasterlist1 = $this->ExecuteQuery($SelQuery1,"select");
	  $objSmarty->assign('graphMasterlist1', $graphMasterlist1);
	  $test1 = array_values($graphMasterlist1);
	  $loopArray1 ='';
      $countItemWiseCurMonSalQty1 = count($graphMasterlist1);
	  
	  
	  $graphMasterlist2 = $this->ExecuteQuery($SelQuery2,"select");
	  $objSmarty->assign('graphMasterlist2', $graphMasterlist2);
	  $test2 = array_values($graphMasterlist2);
	  $loopArray2 ='';
      $countItemWiseCurMonSalQty2 = count($graphMasterlist2);
	  
	  $graphMasterlist3 = $this->ExecuteQuery($SelQuery3,"select");
	  $objSmarty->assign('graphMasterlist3', $graphMasterlist3);
	  $test3 = array_values($graphMasterlist3);
	  $loopArray3 ='';
      $countItemWiseCurMonSalQty3 = count($graphMasterlist3);


for($k1=0; $k1<$countItemWiseCurMonSalQty1; $k1++)
{
$SelQuery = 'SELECT * FROM  `arka_sensor_master` WHERE sensorCode="'.$test1[$k1][sensor_code].'" AND isActive="1" AND status="1"';  
			$ListView = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListView', $ListView);


if($k1==0){
	$loopArray1 .= '{"sensorcode":"'.$ListView[0][sensorName].'","kwh":"'.$test1[$k1][skwh].'","cost":"'.$test1[$k1][scost].'","color":"'.$colors2[$k1].'"}';
	}
	else
	{
	$loopArray1 .= ',{"sensorcode":"'.$ListView[0][sensorName].'","kwh":"'.$test1[$k1][skwh].'","cost":"'.$test1[$k1][scost].'","color":"'.$colors2[$k1].'"}';
	}
}

for($k2=0; $k2<$countItemWiseCurMonSalQty2; $k2++)
{
$SelQuery = 'SELECT * FROM  `arka_sensor_master` WHERE sensorCode="'.$test2[$k2][sensor_code].'" AND isActive="1" AND status="1"';  
			$ListView = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListView', $ListView);


if($k2==0){
	$loopArray2 .= '{"sensorcode":"'.$ListView[0][sensorName].'","kwh":"'.$test2[$k2][skwh].'","cost":"'.$test2[$k2][scost].'","color":"'.$colors2[$k2].'"}';
	}
	else
	{
	$loopArray2 .= ',{"sensorcode":"'.$ListView[0][sensorName].'","kwh":"'.$test2[$k2][skwh].'","cost":"'.$test2[$k2][scost].'","color":"'.$colors2[$k2].'"}';
	}
}

for($k3=0; $k3<$countItemWiseCurMonSalQty3; $k3++)
{
$SelQuery = 'SELECT * FROM  `arka_sensor_master` WHERE sensorCode="'.$test3[$k3][sensor_code].'" AND isActive="1" AND status="1"';  
			$ListView = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListView', $ListView);


if($k3==0){
	$loopArray3 .= '{"sensorcode":"'.$ListView[0][sensorName].'","kwh":"'.$test3[$k3][skwh].'","cost":"'.$test3[$k3][scost].'","color":"'.$colors2[$k3].'"}';
	}
	else
	{
	$loopArray3 .= ',{"sensorcode":"'.$ListView[0][sensorName].'","kwh":"'.$test3[$k3][skwh].'","cost":"'.$test3[$k3][scost].'","color":"'.$colors2[$k3].'"}';
	}
}

$getCurMonSal1 ="[".$loopArray1."]";	
$objSmarty->assign('getCurMonQut1', $getCurMonSal1);


$getCurMonSal2 ="[".$loopArray2."]";	
$objSmarty->assign('getCurMonQut2', $getCurMonSal2);


$getCurMonSal3 ="[".$loopArray3."]";	
$objSmarty->assign('getCurMonQut3', $getCurMonSal3);

	  }
	  /*******************Dashboard Piechart Function Ends*****************************************/
	   /*********************  GetCostKwhAll Functions Starts ******************/ 
		function GetCostKwhAllForSubDashboard()
		{
			global $objSmarty,$config,$nowDate;
			$tbl = $config['DBPrefix'];
		
		if($_GET['companyId'] <> '')
		{
		   $comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		   $comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		   $branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		   $branchId = $_SESSION['branch_id'];
		}
		$pid = base64_decode($_GET['parent_id']);
		
		$ldc=date("Y", strtotime("first day of previous month"));
            $ldl=date("n", strtotime("last day of previous month"));
		
		$senDashboard = 'SELECT * FROM arka_sensor_master WHERE slNo="'.$pid.'" AND status="1" AND isActive="1"';
			$senDashboard		= $this->ExecuteQuery($senDashboard, "select");
			$objSmarty->assign('senDashboard', $senDashboard);
		
	   $selQry = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND DATE(recorded_date)=DATE('.$nowDate.') AND MONTH(recorded_date)=MONTH('.$nowDate.') AND YEAR(recorded_date)=YEAR('.$nowDate.') AND feeder_type="Sub Meter" AND gateway_code="'.$senDashboard[0]['gateway_id'].'"'; 
		  $todayCostKWH		= $this->ExecuteQuery($selQry, "select");
		  $objSmarty->assign('todayCostKWH', $todayCostKWH);
		
		  $selQry2 = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND MONTH(recorded_date)=MONTH('.$nowDate.') AND YEAR(recorded_date)=YEAR('.$nowDate.') AND feeder_type="Sub Meter" AND gateway_code="'.$senDashboard[0]['gateway_id'].'"'; 
		  $monthCostKWH		= $this->ExecuteQuery($selQry2, "select");
		  $objSmarty->assign('monthCostKWH', $monthCostKWH);
		
		  $selQry3 = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND MONTH(recorded_date)="'.$ldl.'" AND YEAR(recorded_date)="'.$ldc.'" AND feeder_type="Sub Meter" AND gateway_code="'.$senDashboard[0]['gateway_id'].'"';
		  $LastMonthCostKWH		= $this->ExecuteQuery($selQry3, "select");
		  $objSmarty->assign('LastMonthCostKWH', $LastMonthCostKWH);
		}
		/*********************  GetCostKwhAll Functions Ends ******************/ 
		
}
?>