<?php
class ReportsMgmt extends MysqlFns
{    
      /********* ReportsMgmt Constructor Starts ********************************/
	function ReportsMgmt()
	{
		$this->LDDisplayPath= $config['SiteGlobalPath']."class.ReportsMgmt.php";
		global $config;
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$this->MysqlFns();
		$this->Limit = 25;
	} 
     /********* ReportsMgmt Constructor Ends ********************************/
     /********* SensorList Functions Starts ********************************/

	function SensorList($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}
	if($branchId=='0')
	{
		$whrCl='AND company_id="'.$comId.'"';
	}
	else{
		$whrCl='AND company_id="'.$comId.'" AND branch_id="'.$branchId.'"';
	}
		$SelQuery = 'SELECT * from arka_sensor_master WHERE status="1" AND isActive="1" AND segmentName="Energy Meter"'.$whrCl.'' ;  
		$ListSensorShift = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListSensorShift', $ListSensorShift);
	if(!isset($_POST['sensorName']) || !isset($_POST['fromDate']) || !isset($_POST['toDate'])){
	/*if( basename($_SERVER['PHP_SELF']) == 'shiftWiseReports.php')
	{
		$this->ShiftWiseReports($ListSensorShift[0]["sensorCode"],$branchId);
	}
	elseif( basename($_SERVER['PHP_SELF']) == 'dailyReports.php')
	{
		$this->DailyReports($branchId);
	}
	elseif( basename($_SERVER['PHP_SELF']) == 'logReports.php')
	{
		$this->LogReports($ListSensorShift[0]["sensorCode"]);
	}*/
	}
	}
      /********* SensorList Functions Ends ********************************/
	   /********* DailyReports Functions Starts ********************************/
	function DailyReports($objArray1)
	{
		global $objSmarty,$config,$_POST;
		$tbl = $config['DBPrefix'];
		
		if($_POST['branchName'] <> '')
{
$branchId = $_POST['branchName'];
}	
else
{
$branchId = $_SESSION['branch_id'];
}
//echo $_POST['sensorName'];exit;
		
	if($_POST['sensorName']<>'' && $branchId=='' && $_POST['fromDate']=='' && $_POST['toDate']==''){
		$whereClause='`sensor_code`="'.$_POST['sensorName'].'" ';
	}
	elseif($branchId <>'' && $_POST['sensorName']=='' && $_POST['fromDate']=='' && $_POST['toDate']==''){
		$whereClause='`branch_id`="'.$branchId.'" ';
	}
	else if($_POST['sensorName']<>'' && $branchId=='' && isset($_POST['fromDate']) && isset($_POST['toDate'])){
		$whereClause='`sensor_code`="'.$_POST['sensorName'].'" AND recorded_date BETWEEN  "'.$_POST['fromDate'].'" AND "'.$_POST['toDate'].'"';
	}
	else if($branchId<>'' && $_POST['sensorName']<>'' && isset($_POST['fromDate']) && isset($_POST['toDate'])){
		$whereClause='`branch_id`="'.$branchId.'" AND `sensor_code`="'.$_POST['sensorName'].'" AND recorded_date BETWEEN  "'.$_POST['fromDate'].'" AND "'.$_POST['toDate'].'"';
	}
	else if($branchId=='' && $_POST['sensorName']<>'' && isset($_POST['fromDate']) && isset($_POST['toDate'])){
		$whereClause='`sensor_code`="'.$_POST['sensorName'].'" AND recorded_date BETWEEN  "'.$_POST['fromDate'].'" AND "'.$_POST['toDate'].'"';
	}
	else if($branchId <>'' && $_POST['sensorName']=='' && isset($_POST['fromDate']) && isset($_POST['toDate'])){
		$whereClause='`branch_id`="'.$branchId.'" AND recorded_date BETWEEN  "'.$_POST['fromDate'].'" AND "'.$_POST['toDate'].'"';
	}
	else{
	if($branchId <> '0')
	{
	    $whereClause='`branch_id`="'.$branchId.'" AND recorded_date BETWEEN  DATE_FORMAT(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE), "%Y-%m-%d") AND DATE_FORMAT(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE), "%Y-%m-%d")';
	}
		$whereClause='recorded_date BETWEEN  DATE_FORMAT(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE), "%Y-%m-%d") AND DATE_FORMAT(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE), "%Y-%m-%d")';
	}
		$SelQuery = 'SELECT * FROM cron_daily_energy_data WHERE '.$whereClause.' ORDER BY recorded_date DESC';//echo $SelQuery;
		$ListDailyRep = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListDailyRep', $ListDailyRep);
		return $ListDailyRep;
	}
	 /********* DailyReports Functions Ends ********************************/
	  /********* GetGatewayName Functions Starts ********************************/
	function GetGatewayName()
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$bId = base64_decode($_GET['branchId']);
		$comId = base64_decode($_GET['companyId']);
		$gId = base64_decode($_GET['gatewayId']);
		
		$SelQuery = 'SELECT * FROM  `'.$tbl.'gateway_master` WHERE branch_id="'.$bId.'" AND company_id="'.$comId.'" AND sl_no="'.$gId.'" AND record_status="1"';  
		$GetGateView = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('GetGateView', $GetGateView);
		return $GetGateView;
	}
      /********* GetGatewayName Functions Ends ********************************/
	  /********* ShiftWiseReportsold Functions Starts ********************************/
	function ShiftWiseReportsold($objArray,$objArray1)
	{
		global $objSmarty,$config,$_POST;
		$tbl = $config['DBPrefix'];
	
	if(isset($_POST['sensorName']) && $_POST['branchName']=='' && $_POST['fromDate']=='' && $_POST['toDate']==''){
		$whereClause='`sensor_code`="'.$_POST['sensorName'].'" ';
	}
	elseif(isset($_POST['branchName']) && $_POST['sensorName']=='' && $_POST['fromDate']=='' && $_POST['toDate']==''){
		$whereClause='``branch_id`="'.$_POST['branchName'].'" ';
	}
	else if(isset($_POST['sensorName']) && $_POST['branchName']=='' && isset($_POST['fromDate']) && isset($_POST['toDate'])){
		$whereClause='`sensor_code`="'.$_POST['sensorName'].'" AND recorded_date BETWEEN  "'.$_POST['fromDate'].'" AND "'.$_POST['toDate'].'"';
	}
	else if(isset($_POST['branchName']) && isset($_POST['sensorName']) && isset($_POST['fromDate']) && isset($_POST['toDate'])){
		$whereClause='`branch_id`="'.$_POST['branchName'].'" AND `sensor_code`="'.$_POST['sensorName'].'" AND recorded_date BETWEEN  "'.$_POST['fromDate'].'" AND "'.$_POST['toDate'].'"';
	}
	else if($_POST['branchName']=='' && isset($_POST['sensorName']) && isset($_POST['fromDate']) && isset($_POST['toDate'])){
		$whereClause='`sensor_code`="'.$_POST['sensorName'].'" AND recorded_date BETWEEN  "'.$_POST['fromDate'].'" AND "'.$_POST['toDate'].'"';
	}
	else if(isset($_POST['branchName']) && $_POST['sensorName']=='' && isset($_POST['fromDate']) && isset($_POST['toDate'])){
		$whereClause='`branch_id`="'.$_POST['branchName'].'" AND recorded_date BETWEEN  "'.$_POST['fromDate'].'" AND "'.$_POST['toDate'].'"';
	}
	else{
	if($objArray1 <> '0')
	{
	    $whereClause='`sensor_code`="'.$objArray.'" AND `branch_id`="'.$objArray1.'" AND recorded_date BETWEEN  DATE_FORMAT(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE), "%Y-%m-01") AND DATE_FORMAT(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE), "%Y-%m-%d")';
	}
		$whereClause='`sensor_code`="'.$objArray.'" AND recorded_date BETWEEN  DATE_FORMAT(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE), "%Y-%m-01") AND DATE_FORMAT(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE), "%Y-%m-%d")';
	}
	$SelQuery = 'SELECT A.`recorded_date` AS recorded_date ,A.consuption_kwh AS firstShiftKWH,A.consuption_cost AS firstShiftCost,B.consuption_kwh AS secondShiftKWH,B.consuption_cost AS secondShiftCost,C.consuption_kwh AS thirdShiftKWH,C.consuption_cost AS thirdShiftCost FROM (SELECT cron_daily_shift_wise_data.`consuption_kwh`, cron_daily_shift_wise_data.`consuption_cost`,cron_daily_shift_wise_data.recorded_date
		FROM cron_daily_shift_wise_data WHERE '.$whereClause.' AND TIME(`from_date_time`)="00:00:00" AND TIME(`to_date_time`)="08:00:00" ) AS A,(SELECT cron_daily_shift_wise_data.`consuption_kwh`, cron_daily_shift_wise_data.`consuption_cost`,recorded_date
		FROM cron_daily_shift_wise_data WHERE '.$whereClause.' AND TIME(`from_date_time`)="08:00:00" AND TIME(`to_date_time`)="16:00:00" ) AS B,(SELECT cron_daily_shift_wise_data.`consuption_kwh`, cron_daily_shift_wise_data.`consuption_cost`,recorded_date
		FROM cron_daily_shift_wise_data WHERE '.$whereClause.' AND TIME(`from_date_time`)="16:00:00" AND TIME(`to_date_time`)="00:00:00" ) AS C  WHERE A.recorded_date=B.recorded_date AND B.recorded_date=C.recorded_date AND C.recorded_date=A.recorded_date  GROUP BY A.`recorded_date` ORDER BY A.`recorded_date` DESC ';
		$ListShiftWiseRep = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListShiftWiseRep', $ListShiftWiseRep);
		return $ListShiftWiseRep;
	
	}
      /********* ShiftWiseReportsold Functions Ends ********************************/
       /********* ShiftWiseReports Functions Starts ********************************/
	function ShiftWiseReports($objArray,$objArray1)
	{
		global $objSmarty,$config,$_POST;
		$tbl = $config['DBPrefix'];
//	echo $_POST['branchName'];echo "<br>";echo $objArray['branchName'];echo $objArray['branchnameid'];exit;

if($_POST['branchName'] <> '')
{
$branchId = $_POST['branchName'];
}	
else
{
$branchId = $_SESSION['branch_id'];
}

	if($_POST['fromDate']=='' && $_POST['toDate']=='')
	{
		$whereClause='recorded_date BETWEEN  DATE_FORMAT(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE), "%Y-%m-01") AND DATE_FORMAT(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE), "%Y-%m-%d")';
		}
		else
		{
		$whereClause='recorded_date BETWEEN  "'.$_POST['fromDate'].'" AND "'.$_POST['toDate'].'"';
		}
	
	if($branchId<>'' && $_POST['sensorName']=='')
	{
	$SelQuery = 'SELECT A.`recorded_date` AS recorded_date ,A.consuption_kwh AS firstShiftKWH,A.consuption_cost AS firstShiftCost,B.consuption_kwh AS secondShiftKWH,B.consuption_cost AS secondShiftCost,C.consuption_kwh AS thirdShiftKWH,C.consuption_cost AS thirdShiftCost FROM (SELECT SUM(cron_daily_shift_wise_data.`consuption_kwh`) AS consuption_kwh, SUM(cron_daily_shift_wise_data.`consuption_cost`) AS consuption_cost,cron_daily_shift_wise_data.recorded_date
		FROM cron_daily_shift_wise_data WHERE '.$whereClause.' AND `branch_id`="'.$branchId.'" AND TIME(`from_date_time`)="00:00:00" AND TIME(`to_date_time`)="08:00:00" GROUP BY recorded_date) AS A,(SELECT SUM(cron_daily_shift_wise_data.`consuption_kwh`) AS consuption_kwh, SUM(cron_daily_shift_wise_data.`consuption_cost`) AS consuption_cost,recorded_date
		FROM cron_daily_shift_wise_data WHERE '.$whereClause.' AND `branch_id`="'.$branchId.'" AND TIME(`from_date_time`)="08:00:00" AND TIME(`to_date_time`)="16:00:00" GROUP BY recorded_date) AS B,(SELECT SUM(cron_daily_shift_wise_data.`consuption_kwh`) AS consuption_kwh, SUM(cron_daily_shift_wise_data.`consuption_cost`) AS consuption_cost,recorded_date
		FROM cron_daily_shift_wise_data WHERE '.$whereClause.' AND `branch_id`="'.$branchId.'" AND TIME(`from_date_time`)="16:00:00" AND TIME(`to_date_time`)="00:00:00" GROUP BY recorded_date) AS C  WHERE A.recorded_date=B.recorded_date AND B.recorded_date=C.recorded_date AND C.recorded_date=A.recorded_date  GROUP BY A.`recorded_date` ORDER BY A.`recorded_date` DESC ';
		}
		elseif($branchId<>'' && $_POST['sensorName']<>'')
		{
		$SelQuery = 'SELECT A.`recorded_date` AS recorded_date ,A.consuption_kwh AS firstShiftKWH,A.consuption_cost AS firstShiftCost,B.consuption_kwh AS secondShiftKWH,B.consuption_cost AS secondShiftCost,C.consuption_kwh AS thirdShiftKWH,C.consuption_cost AS thirdShiftCost FROM (SELECT cron_daily_shift_wise_data.`consuption_kwh`, cron_daily_shift_wise_data.`consuption_cost`,cron_daily_shift_wise_data.recorded_date
		FROM cron_daily_shift_wise_data WHERE '.$whereClause.' AND `branch_id`="'.$branchId.'" AND sensor_code="'.$_POST['sensorName'].'" AND TIME(`from_date_time`)="00:00:00" AND TIME(`to_date_time`)="08:00:00" ) AS A,(SELECT cron_daily_shift_wise_data.`consuption_kwh`, cron_daily_shift_wise_data.`consuption_cost`,recorded_date
		FROM cron_daily_shift_wise_data WHERE '.$whereClause.' AND `branch_id`="'.$branchId.'" AND sensor_code="'.$_POST['sensorName'].'" AND TIME(`from_date_time`)="08:00:00" AND TIME(`to_date_time`)="16:00:00" ) AS B,(SELECT cron_daily_shift_wise_data.`consuption_kwh`, cron_daily_shift_wise_data.`consuption_cost`,recorded_date
		FROM cron_daily_shift_wise_data WHERE '.$whereClause.' AND `branch_id`="'.$branchId.'" AND sensor_code="'.$_POST['sensorName'].'" AND TIME(`from_date_time`)="16:00:00" AND TIME(`to_date_time`)="00:00:00" ) AS C  WHERE A.recorded_date=B.recorded_date AND B.recorded_date=C.recorded_date AND C.recorded_date=A.recorded_date  GROUP BY A.`recorded_date` ORDER BY A.`recorded_date` DESC ';
		}
		else
		{
		$SelQuery = 'SELECT A.`recorded_date` AS recorded_date ,A.consuption_kwh AS firstShiftKWH,A.consuption_cost AS firstShiftCost,B.consuption_kwh AS secondShiftKWH,B.consuption_cost AS secondShiftCost,C.consuption_kwh AS thirdShiftKWH,C.consuption_cost AS thirdShiftCost FROM (SELECT SUM(cron_daily_shift_wise_data.`consuption_kwh`) AS consuption_kwh, SUM(cron_daily_shift_wise_data.`consuption_cost`) AS consuption_cost,cron_daily_shift_wise_data.recorded_date
		FROM cron_daily_shift_wise_data WHERE '.$whereClause.' AND `branch_id`="'.$branchId.'" AND TIME(`from_date_time`)="00:00:00" AND TIME(`to_date_time`)="08:00:00" GROUP BY recorded_date) AS A,(SELECT SUM(cron_daily_shift_wise_data.`consuption_kwh`) AS consuption_kwh, SUM(cron_daily_shift_wise_data.`consuption_cost`) AS consuption_cost,recorded_date
		FROM cron_daily_shift_wise_data WHERE '.$whereClause.' AND `branch_id`="'.$branchId.'" AND TIME(`from_date_time`)="08:00:00" AND TIME(`to_date_time`)="16:00:00" GROUP BY recorded_date) AS B,(SELECT SUM(cron_daily_shift_wise_data.`consuption_kwh`) AS consuption_kwh, SUM(cron_daily_shift_wise_data.`consuption_cost`) AS consuption_cost,recorded_date
		FROM cron_daily_shift_wise_data WHERE '.$whereClause.' AND `branch_id`="'.$branchId.'" AND TIME(`from_date_time`)="16:00:00" AND TIME(`to_date_time`)="00:00:00" GROUP BY recorded_date) AS C  WHERE A.recorded_date=B.recorded_date AND B.recorded_date=C.recorded_date AND C.recorded_date=A.recorded_date  GROUP BY A.`recorded_date` ORDER BY A.`recorded_date` DESC ';
		}
		//echo $SelQuery;
		$ListShiftWiseRep = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListShiftWiseRep', $ListShiftWiseRep);
		return $ListShiftWiseRep;
	
	}
      /********* ShiftWiseReports Functions Ends ********************************/
      /************************Shift Time function starts*************************************************/
    	function ShiftTimeList()
	{
		global $objSmarty,$config,$_POST;
		$tbl = $config['DBPrefix'];
      if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}
	if($branchId=='0')
	{
		$whrCl='company_id="'.$comId.'"';
	}
	else{
		$whrCl='company_id="'.$comId.'" AND branch_id="'.$branchId.'"';
	}

		$SelQuery = 'SELECT * FROM arka_branch_shift_master WHERE '.$whrCl.' AND is_active="1" AND status="1"';
		$ListShiftTime = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListShiftTime', $ListShiftTime);
	}
      /************************Shift Time function ends***************************************************/
	   /********* LogReports Functions Starts ********************************/	
	function LogReports($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];

	if(isset($_POST['sensorName']) && $_POST['fromDate']=='' && $_POST['toDate']==''){
		$whereClause='`sensor_code`="'.$_POST['sensorName'].'" AND DATE(recorded_date_time)=DATE(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTES))';
	}
	elseif(isset($_POST['sensorName']) && isset($_POST['fromDate']) && isset($_POST['toDate'])){
		$whereClause='`sensor_code`="'.$_POST['sensorName'].'" AND DATE(recorded_date_time) BETWEEN  "'.$_POST['fromDate'].'" AND "'.$_POST['toDate'].'"';
	}
	else{
		$whereClause='`sensor_code`="'.$objArray.'" AND DATE(recorded_date_time)=DATE(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE))';
	}
		$SelQuery = 'SELECT recorded_date_time AS TM,posted_date_time,linux_date_time,teltonika_date_time,gateway_code,sensor_code,sensor_model,`METER_ID`, `R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`,SUM_PF AS PF, `FREQUENCY`, `KWH_MSB`, `KWH_LSB`, `KWH`, `METER_TYPE_RUN_HOUR_MSB`, `RUN_HOUR_LSB`, `RUN_HOUR`, `IMPORT_EXPORT` FROM energy_data_master WHERE '.$whereClause.' ORDER BY recorded_date_time DESC '; 
		$ListLogRep = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListLogRep', $ListLogRep);
		return $ListLogRep;
	
	}
	    /********* LogReports Functions Ends ********************************/	
		/********* ListIncidentLog Functions Starts ********************************/	
	function ListIncidentLog($objArray)
	{
		global $objSmarty,$config,$_POST;
		$tbl = $config['DBPrefix'];
	
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}
	if($branchId =='0')
	{
		$whrClass='company_id="'.$comId.'"';
	}else
	{
		$whrClass='company_id="'.$comId.'" AND branch_id="'.$branchId.'"';
	}
	if($_POST['sensorName']<>'' && $_POST['fromDate']==''){
		$whereClause='`sensor_code`="'.$_POST['sensorName'].'"  AND '.$whrClass;
	}
	else if($_POST['sensorName']<>'' && isset($_POST['fromDate'])){
		$whereClause='`sensor_code`="'.$_POST['sensorName'].'" AND DATE(recorded_date_time)="'.$_POST['fromDate'].'" AND '.$whrClass;
	}
	else{
		$whereClause = 'recorded_date_time >= CURDATE() AND recorded_date_time < CURDATE() + INTERVAL 1 DAY AND ' . $whrClass;
	}
		$SelQuery = 'SELECT * FROM `alert_log_master` WHERE '.$whereClause.' ORDER BY recorded_date_time DESC';  //echo $SelQuery; exit;
		$ListIncidentLog = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListIncidentLog', $ListIncidentLog);
		return $ListIncidentLog;
	}
      /********* ListIncidentLog Functions Ends ********************************/
       /********* BranchList Functions Starts ********************************/

	function BranchList($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	
		$SelQuery = 'SELECT * from '.$tbl.'branch_master WHERE record_status="1" AND is_active="1" AND company_id="'.$comId.'" ' ;  
		$ListBranch = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListBranch', $ListBranch);
	}
      /********* BranchList Functions Ends ********************************/
        /********* BranchListNew Functions Starts ********************************/

	function BranchListNew($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_SESSION['USER_GROUP'] == 'Branch Admin' || $_SESSION['USER_GROUP'] == 'Branch User')
	{
	$branchId = $_SESSION['branch_id'];
	$SelQuery = 'SELECT * from '.$tbl.'branch_master WHERE record_status="1" AND is_active="1" AND sl_no="'.$branchId.'" AND company_id="'.$comId.'" ' ;  
	}
	else
	{
	$SelQuery = 'SELECT * from '.$tbl.'branch_master WHERE record_status="1" AND is_active="1" AND company_id="'.$comId.'" ' ;  
	}
	//echo $SelQuery;
		//$SelQuery = 'SELECT * from '.$tbl.'branch_master WHERE record_status="1" AND is_active="1" AND company_id="'.$comId.'" ' ;  
		$ListBranch = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListBranch', $ListBranch);
	}
      /********* BranchListNew Functions Ends ********************************/
         /********* ShiftList Functions Starts ********************************/

	function ShiftList()
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}
	if($branchId=='0')
	{
		$whrCl='AND company_id="'.$comId.'"';
	}
	else{
		$whrCl='AND company_id="'.$comId.'" AND branch_id="'.$branchId.'"';
	}
		$SelQuery = 'SELECT * from arka_branch_shift_master WHERE status="1" AND is_active="1" AND  status="1"'.$whrCl.' GROUP BY shift_name ORDER BY shift_master_id' ;  
		$ListShift = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListShift', $ListShift);
	}
      /********* ShiftList Functions Ends ********************************/
      	    /********* ListCustomizeReport Functions Starts ********************************/
	function ListCustomizeReport()
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_POST['branchName'] <> '')
	{
		$branchId = $_POST['branchName'];
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}
	if($branchId =='0')
	{
		$whrClass='company_id="'.$comId.'"';
	}else
	{
		$whrClass='company_id="'.$comId.'" AND branch_id="'.$branchId.'"';
	}
		
		$SelQuery = 'SELECT * FROM  `'.$tbl.'customize_report_master` WHERE '.$whrClass.' AND status="1" AND isActive="1"';  
		$GetReportList = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('GetReportList', $GetReportList);
		return $GetReportList;
	}
      /********* ListCustomizeReport Functions Ends ********************************/ 
      /********* DeleteCustomizeReport Functions Starts ********************************/
	function DeleteCustomizeReport($CatIdent)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$sid = $_GET['slNo'];  
		$sid = base64_decode($sid);     
	
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branchId'];
	}
		$DelQuery = 'DELETE FROM `'.$tbl.'customize_report_master`  WHERE `slNo` ="'.$sid.'"'; 
		$this->ExecuteQuery($DelQuery, 'update');
		
		$DelQuery = 'DELETE FROM `'.$tbl.'customize_report_mapping`  WHERE `reportName` ="'.$sid.'"'; 
		$this->ExecuteQuery($DelQuery, 'update');
		header('Location:' .$_SERVER['PHP_SELF'].'?companyId='.base64_decode($comId).'&branchId='.base64_decode($branchId).'&succs_msg_for_del');  
	}
    /********** DeleteCustomizeReport Functions Ends ********************************************************************/
      /********* GetSensorName Functions Starts ********************************/
	function GetSensorName()
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_POST['branchName'] <> '')
	{
		$branchId = $_POST['branchName'];
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}
	if($branchId =='0')
	{
		$whrClass='company_id="'.$comId.'"';
	}else
	{
		$whrClass='company_id="'.$comId.'" AND branch_id="'.$branchId.'"';
	}
		
		$SelQuery = 'SELECT * FROM  `'.$tbl.'sensor_master` WHERE '.$whrClass.' AND status="1" AND isActive="1" AND segmentName="Energy Meter"';  
		$GetSensorView = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('GetSensorView', $GetSensorView);
		return $GetSensorView;
	}
      /********* GetSensorName Functions Ends ********************************/
      /************************************ ChkDuplicateCustomizeReport Functions Starts ***************************************************************/   
	function ChkDuplicateCustomizeReport($ug_no)
	{
		global $objSmarty,$config,$_POST;
		$tbl = $config['DBPrefix'];
			if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_POST['branchName'] <> '')
	{
		$branchId = $_POST['branchName'];
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}
	if($branchId =='0')
	{
		$whrClass='company_id="'.$comId.'"';
	}else
	{
		$whrClass='company_id="'.$comId.'" AND branch_id="'.$branchId.'"';
	}
		$SelQuery	= 'SELECT * FROM `'.$tbl.'customize_report_master` WHERE  '.$whrClass.' AND `reportName` = "'.$ug_no.'" and status="1" AND isActive="1" Limit 0,1';
		$UGDetail = $this->ExecuteQuery($SelQuery, 'select');
	if(!empty($UGDetail) && is_array($UGDetail))
		return false;
	else
		return true;
	}
     /************************************ ChkDuplicateCustomizeReport Functions Ends ***************************************************************/ 
       /************************************ InsertCustomizeReport Functions Starts ***************************************************************/
	function InsertCustomizeReport($objArray="")
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		
				if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_POST['branchName'] <> '')
	{
		$branchId = $_POST['branchName'];
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}
		
	if(!$objArray['reportName']){
		$objSmarty->assign('ErrorMessage', 'Report Name should not be blank');
		return false;
	}
$arrs = $objArray["item_id"];
$myArray = explode(',', $arrs);
	
	if($this->ChkDuplicateCustomizeReport(trim(addslashes($objArray['reportName']))))
	{
		$InsQuery = 'INSERT INTO `'.$tbl.'customize_report_master`
		(
		`company_id`,
		`branch_id`,
		`reportName`,
		`createdBy`,
		`isActive`,
		`status`) 
		VALUES
		(
		"'.$comId.'",
		"'.$branchId.'",
		"'.trim(addslashes($objArray['reportName'])).'",
		"'.trim(addslashes($objArray['created_by'])).'",
		"'.trim(addslashes($objArray['checkVal'])).'",
		"1"
		)';
		$this->ExecuteQuery($InsQuery, 'insert');
	
		$SelQuery = 'select * from `'.$tbl.'customize_report_master` where slNo=(SELECT LAST_INSERT_ID())';
		$sView = $this->ExecuteQuery($SelQuery, "select");
		$objSmarty->assign('sView', $sView);
		
	
	foreach($myArray as $key=>$value)
	{
		$InsQuery = 'INSERT INTO `'.$tbl.'customize_report_mapping`(
		`reportName`,
		`sensorName`) 
		VALUES(
		"'.$sView[0]['slNo'].'",
		"'.$value.'"
		)';
		$this->ExecuteQuery($InsQuery, 'insert');
	}
		header('Location:customizeReportList.php?success_msg_for_insert');  
	}
	else
	{
	   $objSmarty->assign('ErrorMessage', 'This Report Number is already Exist');
return false;  
	}
	}
     /************************************ InsertCustomizeReport Functions Ends ***************************************************************/ 
      /************************************************* CustomizeReportEditView Functions Starts ***********************************************************/

	function CustomizeReportEditView($objArray)
	{
	    global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
    	$sid = $_GET['slNo'];  
		$sid = base64_decode($sid);
	
		$SelQuery = 'SELECT * FROM `'.$tbl.'customize_report_master` WHERE slNo="'.$sid.'" AND status="1"'; 
		$ListEditMaster = $this->ExecuteQuery($SelQuery, "select");		
		$objSmarty->assign('ListEditMaster', $ListEditMaster);
		
		$SelQuery = 'SELECT * FROM `'.$tbl.'customize_report_mapping` WHERE reportName="'.$sid.'" AND status="1"'; 
		$ListEditDetail = $this->ExecuteQuery($SelQuery, "select");		
		$objSmarty->assign('ListEditDetail', $ListEditDetail);
		return $ListEditDetail;
	}
      /************************************************* CustomizeReportEditView Functions Ends ***********************************************************/
        /************************************ UpdateCustomizeReport Functions Starts ***************************************************************/ 
	function UpdateCustomizeReport($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		
		$UpQuery = 'UPDATE 
		`'.$tbl.'customize_report_master` 
		SET 
		`reportName` = "'.trim($objArray['reportName']).'",
		`branch_id` = "'.trim($objArray['branchName']).'",
		`status` = "1",
		`isActive` = "'.trim($objArray['checkVal']).'",
		`createdBy` = "'.trim($objArray['created_by']).'"
		WHERE 
		`slNo` ="'.trim($objArray['slNoReport']).'"';
		$this->ExecuteQuery($UpQuery, 'update');
	
		$DelQuery = 'DELETE FROM `'.$tbl.'customize_report_mapping` WHERE `reportName` ="'.trim($objArray['slNoReport']).'"';
		$this->ExecuteQuery($DelQuery, 'delete');
		
		$arrs = $objArray["item_id"];
        $myArray = explode(',', $arrs);
	
	foreach($myArray as $key=>$value)
	{
		$InsQuery = 'INSERT INTO `'.$tbl.'customize_report_mapping`(
		`reportName`,
		`sensorName`
		) 
		VALUES(
		"'.trim($objArray['slNoReport']).'",
		"'.$value.'"
		)';
		$this->ExecuteQuery($InsQuery, 'insert');
	}	
		header('Location:customizeReportList.php?success_msg_for_update');  
	}
     /************************************ UpdateCustomizeReport Functions Ends ***************************************************************/
     	  /********* GetReportName Functions Starts ********************************/
	function GetReportName()
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$bId = base64_decode($_GET['branchId']);
		$comId = base64_decode($_GET['companyId']);
		$gId = base64_decode($_GET['gatewayId']);
		
		$SelQuery = 'SELECT * FROM `'.$tbl.'customize_report_master` WHERE slNo="'.base64_decode($_GET['slNo']).'" AND status="1"'; 
		$ListMaster = $this->ExecuteQuery($SelQuery, "select");		
		$objSmarty->assign('ListMaster', $ListMaster);
		return $ListMaster;
	}
/************************************** GetGatewayName Functions Ends ********************************/
/**********************************CustomizeReports Function Starts *******************************************/
function CustomizeReports()
{
global $objSmarty,$config,$nowDate;
$tbl = $config['DBPrefix'];
if($_GET['companyId'] <> '')
{
$comId = base64_decode($_GET['companyId']);
}	
else
{
$comId = $_SESSION['CustomerId'];
}
if($_POST['branchName'] <> '')
{
$branchId = $_POST['branchName'];
}	
else
{
$branchId = $_SESSION['branch_id'];
}
if($branchId =='0')
{
if($_POST['shiftName'] <> '')
{
$whrClass='cron_daily_shift_wise_data.company_id="'.$comId.'"';
}
else
{
$whrClass='cron_daily_energy_data.company_id="'.$comId.'"';
}
}
else
{
if($_POST['shiftName'] <> '')
{
$whrClass='cron_daily_shift_wise_data.company_id="'.$comId.'" AND cron_daily_shift_wise_data.branch_id="'.$branchId.'"';
}
else
{
$whrClass='cron_daily_energy_data.company_id="'.$comId.'" AND cron_daily_energy_data.branch_id="'.$branchId.'"';
}
}

$SelQuery = 'SELECT * FROM `'.$tbl.'branch_shift_master` WHERE shift_master_id="'.$_POST['shiftName'].'" AND status="1" AND is_active="1"'; 
		$ListTime = $this->ExecuteQuery($SelQuery, "select");		
		$objSmarty->assign('ListTime', $ListTime);

if($_POST['shiftName'] <> '')
{
$SelQuery ='SELECT cron_daily_shift_wise_data.company_id,cron_daily_shift_wise_data.branch_id,cron_daily_shift_wise_data.recorded_date,sum(cron_daily_shift_wise_data.consuption_cost) AS ccost,`'.$tbl.'customize_report_mapping`.reportName,`'.$tbl.'sensor_master`.sensorCode,`'.$tbl.'sensor_master`.sensorName,`'.$tbl.'sensor_master`.slNo,`'.$tbl.'sensor_master`.segmentName,A.start_cum_kwh,B.end_cum_kwh FROM (SELECT cron_daily_shift_wise_data.start_cum_kwh,cron_daily_shift_wise_data.sensor_code FROM `cron_daily_shift_wise_data`,`'.$tbl.'customize_report_mapping`,`'.$tbl.'sensor_master` WHERE `'.$tbl.'sensor_master`.slNo=`'.$tbl.'customize_report_mapping`.sensorName AND `'.$tbl.'sensor_master`.sensorCode=cron_daily_shift_wise_data.sensor_code AND `'.$tbl.'customize_report_mapping`.reportName="'.base64_decode($_GET['slNo'] ).'" AND cron_daily_shift_wise_data.shift_master_id="'.$_POST['shiftName'].'" AND TIME(cron_daily_shift_wise_data.from_date_time)="'.$ListTime[0]['start_time'].'" AND TIME(cron_daily_shift_wise_data.to_date_time)="'.$ListTime[0]['end_time'].'" AND '.$tbl.'sensor_master.status="1"  AND arka_sensor_master.segmentName="Energy Meter" AND '.$whrClass.' AND recorded_date =  "'.$_POST['fromDate'].'" GROUP BY sensorCode ORDER BY recorded_date ASC) AS A,(SELECT cron_daily_shift_wise_data.end_cum_kwh,cron_daily_shift_wise_data.sensor_code FROM `cron_daily_shift_wise_data`,`'.$tbl.'customize_report_mapping`,`'.$tbl.'sensor_master` WHERE `'.$tbl.'sensor_master`.slNo=`'.$tbl.'customize_report_mapping`.sensorName AND `'.$tbl.'sensor_master`.sensorCode=cron_daily_shift_wise_data.sensor_code AND `'.$tbl.'customize_report_mapping`.reportName="'.base64_decode($_GET['slNo'] ).'" AND cron_daily_shift_wise_data.shift_master_id="'.$_POST['shiftName'].'" AND TIME(cron_daily_shift_wise_data.from_date_time)="'.$ListTime[0]['start_time'].'" AND TIME(cron_daily_shift_wise_data.to_date_time)="'.$ListTime[0]['end_time'].'" AND '.$tbl.'sensor_master.status="1" AND '.$whrClass.' AND recorded_date = "'.$_POST['toDate'].'"  GROUP BY sensorCode ORDER BY recorded_date DESC) AS B , `cron_daily_shift_wise_data`,`'.$tbl.'customize_report_mapping`,`'.$tbl.'sensor_master` WHERE `'.$tbl.'sensor_master`.slNo=`'.$tbl.'customize_report_mapping`.sensorName AND `'.$tbl.'sensor_master`.slNo=`'.$tbl.'customize_report_mapping`.sensorName AND `'.$tbl.'sensor_master`.sensorCode=cron_daily_shift_wise_data.sensor_code AND A.sensor_code=cron_daily_shift_wise_data.sensor_code AND B.sensor_code=cron_daily_shift_wise_data.sensor_code AND `'.$tbl.'customize_report_mapping`.reportName="'.base64_decode($_GET['slNo'] ).'" AND cron_daily_shift_wise_data.shift_master_id="'.$_POST['shiftName'].'" AND TIME(cron_daily_shift_wise_data.from_date_time)="'.$ListTime[0]['start_time'].'" AND TIME(cron_daily_shift_wise_data.to_date_time)="'.$ListTime[0]['end_time'].'" AND '.$tbl.'sensor_master.status="1" AND '.$whrClass.' AND recorded_date BETWEEN "'.$_POST['fromDate'].'" AND "'.$_POST['toDate'].'"  GROUP BY sensorCode ORDER BY `'.$tbl.'sensor_master`.feeder_type ASC';
}
else
{
$SelQuery= 'SELECT cron_daily_energy_data.company_id,cron_daily_energy_data.branch_id,cron_daily_energy_data.recorded_date,sum(cron_daily_energy_data.consuption_cost) AS ccost,`'.$tbl.'customize_report_mapping`.reportName,`'.$tbl.'sensor_master`.sensorCode,`'.$tbl.'sensor_master`.sensorName,`'.$tbl.'sensor_master`.slNo,`'.$tbl.'sensor_master`.segmentName,A.start_cum_kwh,B.end_cum_kwh FROM (SELECT cron_daily_energy_data.start_cum_kwh,cron_daily_energy_data.sensor_code FROM `cron_daily_energy_data`,`'.$tbl.'customize_report_mapping`,`'.$tbl.'sensor_master` WHERE `'.$tbl.'sensor_master`.slNo=`'.$tbl.'customize_report_mapping`.sensorName AND `'.$tbl.'sensor_master`.sensorCode=cron_daily_energy_data.sensor_code AND `'.$tbl.'customize_report_mapping`.reportName="'.base64_decode($_GET['slNo'] ).'" AND '.$tbl.'sensor_master.status="1" AND arka_sensor_master.segmentName="Energy Meter" AND '.$whrClass.' AND recorded_date =  "'.$_POST['fromDate'].'" GROUP BY sensorCode ORDER BY recorded_date ASC) AS A,(SELECT cron_daily_energy_data.end_cum_kwh,cron_daily_energy_data.sensor_code FROM `cron_daily_energy_data`,`'.$tbl.'customize_report_mapping`,`'.$tbl.'sensor_master` WHERE `'.$tbl.'sensor_master`.slNo=`'.$tbl.'customize_report_mapping`.sensorName AND `'.$tbl.'sensor_master`.sensorCode=cron_daily_energy_data.sensor_code AND `'.$tbl.'customize_report_mapping`.reportName="'.base64_decode($_GET['slNo'] ).'" AND '.$tbl.'sensor_master.status="1" AND '.$whrClass.' AND recorded_date = "'.$_POST['toDate'].'"  GROUP BY sensorCode ORDER BY recorded_date DESC) AS B , `cron_daily_energy_data`,`'.$tbl.'customize_report_mapping`,`'.$tbl.'sensor_master` WHERE `'.$tbl.'sensor_master`.slNo=`'.$tbl.'customize_report_mapping`.sensorName AND `'.$tbl.'sensor_master`.slNo=`'.$tbl.'customize_report_mapping`.sensorName AND `'.$tbl.'sensor_master`.sensorCode=cron_daily_energy_data.sensor_code AND A.sensor_code=cron_daily_energy_data.sensor_code AND B.sensor_code=cron_daily_energy_data.sensor_code AND `'.$tbl.'customize_report_mapping`.reportName="'.base64_decode($_GET['slNo'] ).'" AND '.$tbl.'sensor_master.status="1" AND '.$whrClass.' AND recorded_date BETWEEN "'.$_POST['fromDate'].'" AND "'.$_POST['toDate'].'"  GROUP BY sensorCode ORDER BY `'.$tbl.'sensor_master`.feeder_type ASC';
}
//echo $SelQuery;
$ListDataMaster = $this->ExecuteQuery($SelQuery, "select");		
$objSmarty->assign('ListDataMaster', $ListDataMaster);
}
/********************* CustomizeReports Function Starts Ends **********************/
/**********************************EnergyConstructionReports Function Starts *******************************************/
function EnergyConstructionReports()
{
global $objSmarty,$config,$nowDate;
$tbl = $config['DBPrefix'];
if($_GET['companyId'] <> '')
{
$comId = base64_decode($_GET['companyId']);
}	
else
{
$comId = $_SESSION['CustomerId'];
}
if($_POST['branchName'] <> '')
{
$branchId = $_POST['branchName'];
}	
else
{
$branchId = $_SESSION['branch_id'];
}
if($branchId =='0')
{
if($_POST['shiftName'] <> '')
{
$whrClass='cron_daily_shift_wise_data.company_id="'.$comId.'"';
}
else
{
$whrClass='cron_daily_energy_data.company_id="'.$comId.'"';
}
}
else
{
if($_POST['shiftName'] <> '')
{
$whrClass='cron_daily_shift_wise_data.company_id="'.$comId.'" AND cron_daily_shift_wise_data.branch_id="'.$branchId.'"';
}
else
{
$whrClass='cron_daily_energy_data.company_id="'.$comId.'" AND cron_daily_energy_data.branch_id="'.$branchId.'"';
}
}

$SelQuery = 'SELECT * FROM `'.$tbl.'branch_shift_master` WHERE shift_master_id="'.$_POST['shiftName'].'" AND status="1" AND is_active="1"'; 
		$ListTime = $this->ExecuteQuery($SelQuery, "select");		
		$objSmarty->assign('ListTime', $ListTime);



if($branchId <> '' && $_POST['gatewayName'] == '')
{
if($_POST['shiftName'] == '')
{
$SelQuery= 'SELECT cron_daily_energy_data.company_id,cron_daily_energy_data.branch_id,cron_daily_energy_data.recorded_date,sum(cron_daily_energy_data.consuption_cost) AS ccost,`'.$tbl.'sensor_master`.sensorCode,`'.$tbl.'sensor_master`.sensorName,`'.$tbl.'sensor_master`.slNo,A.start_cum_kwh,B.end_cum_kwh FROM (SELECT cron_daily_energy_data.start_cum_kwh,cron_daily_energy_data.sensor_code,arka_sensor_master.sensorCode,`'.$tbl.'sensor_master`.sensorName,arka_sensor_master.segmentName,arka_sensor_master.status,arka_sensor_master.isActive FROM `cron_daily_energy_data`,`arka_sensor_master` WHERE `arka_sensor_master`.sensorCode=cron_daily_energy_data.sensor_code AND arka_sensor_master.status="1" AND arka_sensor_master.isActive="1" AND arka_sensor_master.segmentName="Energy Meter" AND '.$whrClass.' AND recorded_date = "'.$_POST['fromDate'].'" GROUP BY sensorCode ORDER BY recorded_date ASC) AS A,(SELECT cron_daily_energy_data.end_cum_kwh,cron_daily_energy_data.sensor_code,arka_sensor_master.sensorCode,arka_sensor_master.segmentName,arka_sensor_master.status,arka_sensor_master.isActive FROM `cron_daily_energy_data`,`arka_sensor_master` WHERE `arka_sensor_master`.sensorCode=cron_daily_energy_data.sensor_code AND arka_sensor_master.status="1" AND arka_sensor_master.isActive="1" AND arka_sensor_master.segmentName="Energy Meter" AND '.$whrClass.' AND recorded_date = "'.$_POST['toDate'].'" GROUP BY sensorCode ORDER BY recorded_date DESC) AS B , `cron_daily_energy_data`,`'.$tbl.'sensor_master` WHERE  `arka_sensor_master`.sensorCode=cron_daily_energy_data.sensor_code AND A.sensorCode=cron_daily_energy_data.sensor_code AND B.sensorCode=cron_daily_energy_data.sensor_code AND arka_sensor_master.status="1" AND '.$whrClass.' AND recorded_date BETWEEN "'.$_POST['fromDate'].'" AND "'.$_POST['toDate'].'" GROUP BY sensorCode ORDER BY `'.$tbl.'sensor_master`.slNo ASC';
}
else
{
$SelQuery= 'SELECT cron_daily_shift_wise_data.company_id,cron_daily_shift_wise_data.branch_id,cron_daily_shift_wise_data.recorded_date,sum(cron_daily_shift_wise_data.consuption_cost) AS ccost,`'.$tbl.'sensor_master`.sensorCode,`'.$tbl.'sensor_master`.sensorName,`'.$tbl.'sensor_master`.slNo,A.start_cum_kwh,B.end_cum_kwh FROM (SELECT cron_daily_shift_wise_data.start_cum_kwh,cron_daily_shift_wise_data.sensor_code,arka_sensor_master.sensorCode,`'.$tbl.'sensor_master`.sensorName,arka_sensor_master.segmentName,arka_sensor_master.status,arka_sensor_master.isActive FROM `cron_daily_shift_wise_data`,`arka_sensor_master` WHERE `arka_sensor_master`.sensorCode=cron_daily_shift_wise_data.sensor_code AND arka_sensor_master.status="1" AND cron_daily_shift_wise_data.shift_master_id="'.$_POST['shiftName'].'" AND TIME(cron_daily_shift_wise_data.from_date_time)="'.$ListTime[0]['start_time'].'" AND TIME(cron_daily_shift_wise_data.to_date_time)="'.$ListTime[0]['end_time'].'" AND arka_sensor_master.isActive="1" AND arka_sensor_master.segmentName="Energy Meter" AND '.$whrClass.' AND recorded_date = "'.$_POST['fromDate'].'" GROUP BY sensorCode ORDER BY recorded_date ASC) AS A,(SELECT cron_daily_shift_wise_data.end_cum_kwh,cron_daily_shift_wise_data.sensor_code,arka_sensor_master.sensorCode,arka_sensor_master.segmentName,arka_sensor_master.status,arka_sensor_master.isActive FROM `cron_daily_shift_wise_data`,`arka_sensor_master` WHERE `arka_sensor_master`.sensorCode=cron_daily_shift_wise_data.sensor_code AND arka_sensor_master.status="1" AND cron_daily_shift_wise_data.shift_master_id="'.$_POST['shiftName'].'" AND TIME(cron_daily_shift_wise_data.from_date_time)="'.$ListTime[0]['start_time'].'" AND TIME(cron_daily_shift_wise_data.to_date_time)="'.$ListTime[0]['end_time'].'" AND arka_sensor_master.isActive="1" AND arka_sensor_master.segmentName="Energy Meter" AND '.$whrClass.' AND recorded_date = "'.$_POST['toDate'].'" GROUP BY sensorCode ORDER BY recorded_date DESC) AS B , `cron_daily_shift_wise_data`,`'.$tbl.'sensor_master` WHERE  `arka_sensor_master`.sensorCode=cron_daily_shift_wise_data.sensor_code AND A.sensorCode=cron_daily_shift_wise_data.sensor_code AND B.sensorCode=cron_daily_shift_wise_data.sensor_code AND arka_sensor_master.status="1" AND cron_daily_shift_wise_data.shift_master_id="'.$_POST['shiftName'].'" AND TIME(cron_daily_shift_wise_data.from_date_time)="'.$ListTime[0]['start_time'].'" AND TIME(cron_daily_shift_wise_data.to_date_time)="'.$ListTime[0]['end_time'].'" AND '.$whrClass.' AND recorded_date BETWEEN "'.$_POST['fromDate'].'" AND "'.$_POST['toDate'].'" GROUP BY sensorCode ORDER BY `'.$tbl.'sensor_master`.slNo ASC';
}
}
else
{
if($_POST['shiftName'] <> '')
{
$SelQuery= 'SELECT cron_daily_shift_wise_data.company_id,cron_daily_shift_wise_data.branch_id,cron_daily_shift_wise_data.recorded_date,sum(cron_daily_shift_wise_data.consuption_cost) AS ccost,`gateway_group_mapping`.groupName,`gateway_group_mapping`.gatewayId,`'.$tbl.'gateway_master`.gateway_id,`'.$tbl.'gateway_master`.sl_no,`'.$tbl.'sensor_master`.sensorCode,`'.$tbl.'sensor_master`.sensorName,`'.$tbl.'sensor_master`.slNo,A.start_cum_kwh,B.end_cum_kwh FROM (SELECT cron_daily_shift_wise_data.start_cum_kwh,cron_daily_shift_wise_data.sensor_code,`arka_gateway_master`.sl_no FROM `cron_daily_shift_wise_data`,`gateway_group_mapping`,`arka_sensor_master`,`arka_gateway_master` WHERE `gateway_group_mapping`.groupName="'.$_POST['gatewayName'].'" AND cron_daily_shift_wise_data.shift_master_id="'.$_POST['shiftName'].'" AND TIME(cron_daily_shift_wise_data.from_date_time)="'.$ListTime[0]['start_time'].'" AND TIME(cron_daily_shift_wise_data.to_date_time)="'.$ListTime[0]['end_time'].'" AND `gateway_group_mapping`.gatewayId=`arka_gateway_master`.sl_no AND `arka_gateway_master`.gateway_id=`arka_sensor_master`.gateway_id AND `arka_sensor_master`.sensorCode=cron_daily_shift_wise_data.sensor_code AND arka_sensor_master.status="1" AND '.$whrClass.' AND recorded_date = "'.$_POST['fromDate'].'" GROUP BY sensorCode ORDER BY recorded_date ASC) AS A,(SELECT cron_daily_shift_wise_data.end_cum_kwh,cron_daily_shift_wise_data.sensor_code,`arka_gateway_master`.sl_no FROM `cron_daily_shift_wise_data`,`gateway_group_mapping`,`arka_sensor_master`,`arka_gateway_master` WHERE `gateway_group_mapping`.groupName="'.$_POST['gatewayName'].'" AND cron_daily_shift_wise_data.shift_master_id="'.$_POST['shiftName'].'" AND TIME(cron_daily_shift_wise_data.from_date_time)="'.$ListTime[0]['start_time'].'" AND TIME(cron_daily_shift_wise_data.to_date_time)="'.$ListTime[0]['end_time'].'"  AND `gateway_group_mapping`.gatewayId=`arka_gateway_master`.sl_no AND  `arka_gateway_master`.gateway_id=`arka_sensor_master`.gateway_id  AND `arka_sensor_master`.sensorCode=cron_daily_shift_wise_data.sensor_code AND arka_sensor_master.status="1" AND '.$whrClass.' AND recorded_date = "'.$_POST['toDate'].'" GROUP BY sensorCode ORDER BY recorded_date DESC) AS B , `cron_daily_shift_wise_data`,`gateway_group_mapping`,`'.$tbl.'sensor_master`,'.$tbl.'gateway_master WHERE `gateway_group_mapping`.groupName="'.$_POST['gatewayName'].'"  AND `gateway_group_mapping`.gatewayId=`arka_gateway_master`.sl_no AND  `arka_gateway_master`.gateway_id=`arka_sensor_master`.gateway_id  AND `arka_sensor_master`.sensorCode=cron_daily_shift_wise_data.sensor_code AND A.sensor_code=cron_daily_shift_wise_data.sensor_code AND B.sensor_code=cron_daily_shift_wise_data.sensor_code AND arka_sensor_master.status="1" AND arka_sensor_master.segmentName="Energy Meter" AND cron_daily_shift_wise_data.shift_master_id="'.$_POST['shiftName'].'" AND TIME(cron_daily_shift_wise_data.from_date_time)="'.$ListTime[0]['start_time'].'" AND TIME(cron_daily_shift_wise_data.to_date_time)="'.$ListTime[0]['end_time'].'" AND '.$whrClass.' AND recorded_date BETWEEN "'.$_POST['fromDate'].'" AND "'.$_POST['toDate'].'" GROUP BY sensorCode ORDER BY `'.$tbl.'sensor_master`.slNo ASC';
}
else
{
$SelQuery= 'SELECT cron_daily_energy_data.company_id,cron_daily_energy_data.branch_id,cron_daily_energy_data.recorded_date,sum(cron_daily_energy_data.consuption_cost) AS ccost,`gateway_group_mapping`.groupName,`gateway_group_mapping`.gatewayId,`'.$tbl.'gateway_master`.gateway_id,`'.$tbl.'gateway_master`.sl_no,`'.$tbl.'sensor_master`.sensorCode,`'.$tbl.'sensor_master`.sensorName,`'.$tbl.'sensor_master`.slNo,A.start_cum_kwh,B.end_cum_kwh FROM (SELECT cron_daily_energy_data.start_cum_kwh,cron_daily_energy_data.sensor_code,`arka_gateway_master`.sl_no FROM `cron_daily_energy_data`,`gateway_group_mapping`,`arka_sensor_master`,`arka_gateway_master` WHERE `gateway_group_mapping`.groupName="'.$_POST['gatewayName'].'" AND `gateway_group_mapping`.gatewayId=`arka_gateway_master`.sl_no AND `arka_gateway_master`.gateway_id=`arka_sensor_master`.gateway_id AND `arka_sensor_master`.sensorCode=cron_daily_energy_data.sensor_code AND arka_sensor_master.status="1" AND '.$whrClass.' AND recorded_date = "'.$_POST['fromDate'].'" GROUP BY sensorCode ORDER BY recorded_date ASC) AS A,(SELECT cron_daily_energy_data.end_cum_kwh,cron_daily_energy_data.sensor_code,`arka_gateway_master`.sl_no FROM `cron_daily_energy_data`,`gateway_group_mapping`,`arka_sensor_master`,`arka_gateway_master` WHERE `gateway_group_mapping`.groupName="'.$_POST['gatewayName'].'"  AND `gateway_group_mapping`.gatewayId=`arka_gateway_master`.sl_no AND  `arka_gateway_master`.gateway_id=`arka_sensor_master`.gateway_id  AND `arka_sensor_master`.sensorCode=cron_daily_energy_data.sensor_code AND arka_sensor_master.status="1" AND '.$whrClass.' AND recorded_date = "'.$_POST['toDate'].'" GROUP BY sensorCode ORDER BY recorded_date DESC) AS B , `cron_daily_energy_data`,`gateway_group_mapping`,`'.$tbl.'sensor_master`,'.$tbl.'gateway_master WHERE `gateway_group_mapping`.groupName="'.$_POST['gatewayName'].'"  AND `gateway_group_mapping`.gatewayId=`arka_gateway_master`.sl_no AND  `arka_gateway_master`.gateway_id=`arka_sensor_master`.gateway_id  AND `arka_sensor_master`.sensorCode=cron_daily_energy_data.sensor_code AND A.sensor_code=cron_daily_energy_data.sensor_code AND B.sensor_code=cron_daily_energy_data.sensor_code AND arka_sensor_master.status="1" AND arka_sensor_master.segmentName="Energy Meter" AND '.$whrClass.' AND recorded_date BETWEEN "'.$_POST['fromDate'].'" AND "'.$_POST['toDate'].'" GROUP BY sensorCode ORDER BY `'.$tbl.'sensor_master`.slNo ASC';
}
}
//echo $SelQuery;
$ListDataMaster = $this->ExecuteQuery($SelQuery, "select");		
$objSmarty->assign('ListDataMaster', $ListDataMaster);
}
/********************* EnergyConstructionReports Functions Ends **********************/
	   /********* AcReports Functions Starts ********************************/
	function AcReports($objArray1)
	{
		global $objSmarty,$config,$_POST;
		$tbl = $config['DBPrefix'];
		
		if($_POST['branchName'] <> '')
{
$branchId = $_POST['branchName'];
}	
else
{
$branchId = $_SESSION['branch_id'];
}
//echo $_POST['sensorName'];exit;
		
/*	if($_POST['sensorName']<>'' && $branchId=='' && $_POST['fromDate']=='' && $_POST['toDate']==''){
		$whereClause='`sensor_code`="'.$_POST['sensorName'].'" ';
	}
	elseif($branchId <>'' && $_POST['sensorName']=='' && $_POST['fromDate']=='' && $_POST['toDate']==''){
		$whereClause='`branch_id`="'.$branchId.'" ';
	}
	else if($_POST['sensorName']<>'' && $branchId=='' && isset($_POST['fromDate']) && isset($_POST['toDate'])){
		$whereClause='`sensor_code`="'.$_POST['sensorName'].'" AND recorded_date BETWEEN  "'.$_POST['fromDate'].'" AND "'.$_POST['toDate'].'"';
	}
	else if($branchId<>'' && $_POST['sensorName']<>'' && isset($_POST['fromDate']) && isset($_POST['toDate'])){
		$whereClause='`branch_id`="'.$branchId.'" AND `sensor_code`="'.$_POST['sensorName'].'" AND recorded_date BETWEEN  "'.$_POST['fromDate'].'" AND "'.$_POST['toDate'].'"';
	}
	else if($branchId=='' && $_POST['sensorName']<>'' && isset($_POST['fromDate']) && isset($_POST['toDate'])){
		$whereClause='`sensor_code`="'.$_POST['sensorName'].'" AND recorded_date BETWEEN  "'.$_POST['fromDate'].'" AND "'.$_POST['toDate'].'"';
	}
	else if($branchId <>'' && $_POST['sensorName']=='' && isset($_POST['fromDate']) && isset($_POST['toDate'])){
		$whereClause='`branch_id`="'.$branchId.'" AND recorded_date BETWEEN  "'.$_POST['fromDate'].'" AND "'.$_POST['toDate'].'"';
	}
	else{
	if($branchId <> '0')
	{
	    $whereClause='`branch_id`="'.$branchId.'" AND recorded_date BETWEEN  DATE_FORMAT(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE), "%Y-%m-%d") AND DATE_FORMAT(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE), "%Y-%m-%d")';
	}
		$whereClause='recorded_date BETWEEN  DATE_FORMAT(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE), "%Y-%m-%d") AND DATE_FORMAT(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE), "%Y-%m-%d")';
	}*/
		$SelQuery = 'SELECT * FROM hvac_temperature_data_master WHERE DATE(recorded_date_time) BETWEEN  "'.$_POST['fromDate'].'" AND "'.$_POST['toDate'].'" ORDER BY recorded_date_time DESC';//echo $SelQuery;
		$ListDailyRep = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListDailyRep', $ListDailyRep);
		return $ListDailyRep;
	}
	 /********* AcReports Functions Ends ********************************/
	 
	 /*****************      Hour Wise Report *******************************/
function HourwiseReport($objArray){
global $objSmarty,$config,$_POST;

if(isset($_POST['toDate']))
		{
			$yesDay='DATE("'.$_POST['toDate'].'")';
			$dayBefYesDay='DATE(DATE_SUB("'.$_POST['toDate'].'",INTERVAL "1" DAY))';
		//	$userName =$_POST['userName'];
		//	$manualUpdate=1;
		}
		else
		{
			$yesDay='DATE(NOW())';
			$dayBefYesDay='DATE(DATE_SUB(NOW(),INTERVAL "1" DAY))';
		//	$userName='Cron';
		//	$manualUpdate=0;
		}
		
		$selYes='SELECT energy_data_master.*,arka_sensor_master.unit_rate,arka_sensor_master.company_id,arka_sensor_master.branch_id FROM energy_data_master,arka_sensor_master WHERE energy_data_master.`sensor_code`="'.$_POST["sensorName"].'" AND energy_data_master.sensor_code=arka_sensor_master.sensorCode AND energy_data_master.`recorded_date_time` IN (SELECT MAX(`recorded_date_time`) FROM energy_data_master WHERE `sensor_code`="'.$_POST["sensorName"].'" AND DATE(`recorded_date_time`)='.$dayBefYesDay.' )  ';
			$ListDailyRep = $this->ExecuteQuery($selYes, 'select');
			echo $selYes;
	echo	$ListDailyRep[0]["unit_rate"]."<>".$ListDailyRep[0]["sensor_code"]; exit;
		
			//echo "<br>$yesDay".$yesDay."<br>$dayBefYesDay".$dayBefYesDay."<br>$userName".$userName."<br>Max_Min".$max_min;

	//	echo $selQry = 'SELECT FLOOR(UNIX_TIMESTAMP(recorded_date_time)/(60 * 60)) AS timekey, A.KWH AS Yesterday,A.DG_KWH AS DG_Yesterday,B.KWH AS Today,B.DG_KWH AS DG_Today,A.recorded_date_time AS Min_Date,B.recorded_date_time AS Max_date,DATE(B.recorded_date_time) AS recorded_date,A.unit_rate AS unit_rate,(B.KWH-A.KWH)AS TOTAL_KWH ,(B.DG_KWH-A.DG_KWH)AS TOTAL_DG_KWH ,(B.KWH-A.KWH)*A.unit_rate AS cost,(B.DG_KWH-A.DG_KWH)*A.unit_rate AS dg_cost FROM (SELECT energy_data_master.KWH,energy_data_master.DG_KWH,energy_data_master.recorded_date_time,arka_sensor_master.unit_rate FROM `energy_data_master`,arka_sensor_master WHERE energy_data_master.sensor_code=arka_sensor_master.sensorCode AND arka_sensor_master.company_id="'.$ListDailyRep[0]["company_id"].'" AND arka_sensor_master.branch_id="'.$ListDailyRep[0]["branch_id"].'"  AND  energy_data_master.`sensor_code`="'.$ListDailyRep[0]["sensor_code"].'" AND energy_data_master.`recorded_date_time` IN (SELECT '.$max_min.'(`recorded_date_time`) FROM energy_data_master WHERE energy_data_master.`sensor_code`="'.$ListDailyRep[0]["sensor_code"].'" AND DATE(`recorded_date_time`)='.$dayBefYesDay.' )) AS A ,(SELECT energy_data_master.KWH,energy_data_master.DG_KWH,energy_data_master.recorded_date_time,arka_sensor_master.unit_rate FROM `energy_data_master`,arka_sensor_master WHERE energy_data_master.sensor_code=arka_sensor_master.sensorCode AND arka_sensor_master.company_id="'.$ListDailyRep[0]["company_id"].'" AND arka_sensor_master.branch_id="'.$ListDailyRep[0]["branch_id"].'" AND  energy_data_master.`sensor_code`="'.$ListDailyRep[0]["sensor_code"].'" AND`recorded_date_time` IN (SELECT MAX(`recorded_date_time`) FROM energy_data_master WHERE energy_data_master.`sensor_code`="'.$ListDailyRep[0]["sensor_code"].'" AND DATE(`recorded_date_time`)='.$yesDay.' )) AS B GROUP BY timekey';  exit;
		$selQry = 'SELECT FLOOR(UNIX_TIMESTAMP(DATE_ADD(recorded_date_time, INTERVAL 60 MINUTE))/(60 * 60)) AS timekey, "'.$ListDailyRep[0]["unit_rate"].'" AS unit_rate, MIN(recorded_date_time) AS start_date_time, MAX(recorded_date_time) AS end_date_time, (MAX(energy_data_master.KWH)-MIN(energy_data_master.KWH)) AS consuption_kwh,MAX(energy_data_master.KWH) AS end_cum_kwh,MIN(energy_data_master.KWH) AS start_cum_kwh, ((MAX(energy_data_master.KWH)-MIN(energy_data_master.KWH)) * '.$ListDailyRep[0]["unit_rate"].') AS consuption_cost FROM energy_data_master WHERE sensor_code="'.$ListDailyRep[0]["sensor_code"].'" AND DATE(recorded_date_time)='.$yesDay.' GROUP BY timekey';  
			//	echo $selQry; exit;
					$ListHourlyRep = $this->ExecuteQuery($selQry, 'select');
					$objSmarty->assign('ListHourlyRep', $ListHourlyRep);
					

}	
/****************       Hour Wise Report       **********/
}
?>