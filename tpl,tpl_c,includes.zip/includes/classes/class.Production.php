<?php
 class Production extends MysqlFns
{
      /********* Production Constructor Starts ********************************/
	function Production()
	{
		$this->LDDisplayPath= $config['SiteGlobalPath']."class.Production.php";
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		
		
	}
     /********* Production Constructor Ends ********************************/
    /********* ListSensor Functions Starts ********************************/
	function ListSensor($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> '')
		{
			$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
			$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
			$brId = base64_decode($_GET['branchId']);
		}	
		else
		{
			$brId = $_SESSION['branch_id'];
		}
		
		
		$SelQrySen = 'SELECT * FROM `arka_sensor_master`	 WHERE company_id="'.$comId.'" AND branch_id="'.$brId.'" AND isActive=1 AND status=1 AND segmentName="Energy Meter"'; 
		$ListSens = $this->ExecuteQuery($SelQrySen, 'select');
		$objSmarty->assign('ListSens', $ListSens);

	}
    /********* ListSensor Functions End ********************************/
  /********* ListSensor Functions Starts ********************************/
	function productionDate($senCode)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
				
		$SelQryProdDate = 'SELECT * FROM `cron_daily_shift_wise_data` WHERE sensor_code="'.base64_decode($senCode).'" AND production_status=0 GROUP BY recorded_date ORDER BY recorded_date DESC'; 
		$ListProductionDate = $this->ExecuteQuery($SelQryProdDate, 'select');
		$objSmarty->assign('ListProductionDate', $ListProductionDate);

	}
    /********* ListSensor Functions End ********************************/
	 /********* ListProductionShift Functions Starts ********************************/
	function productionShift($senCode,$prodDate)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
				
		$SelQryProdShift = 'SELECT * FROM `cron_daily_shift_wise_data` WHERE sensor_code="'.base64_decode($senCode).'" AND recorded_date="'.base64_decode($prodDate).'"'; 
		$prodShiftList = $this->ExecuteQuery($SelQryProdShift, 'select');
		$objSmarty->assign('prodShiftList', $prodShiftList);

	}
    /********* ListProductionShift Functions End ********************************/
	
		 /********* productionForm Functions Starts ********************************/
	function productionForm($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$shiftLoopCount=$objArray["shiftCount"];
		for($j=1; $j<= $shiftLoopCount; $j++){

	//	 echo ", <br>production : > ".$objArray["production".$j].", <br> id : > ".$objArray["cronShift".$j];
		 $shiftProductUpdate="UPDATE cron_daily_shift_wise_data SET production='".$objArray["production".$j]."', production_status=1 WHERE shift_wise_data_id='".$objArray["cronShift".$j]."'";
		 $this->ExecuteQuery($shiftProductUpdate, 'update');
		}
		 header('Location:listProductionShift.php?success_msg_for_insert');  
     // header('Location:AddEditProduction.php?success_msg_for_insert');  
	}
  
		 /********* productionForm Functions Ends ********************************/
		 
		          /********* ShiftList Functions Starts ********************************/

	function ShiftList()
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}
	if($branchId=='0')
	{
		$whrCl='AND company_id="'.$comId.'"';
	}
	else{
		$whrCl='AND company_id="'.$comId.'" AND branch_id="'.$branchId.'"';
	}
		$SelQuery = 'SELECT * from arka_branch_shift_master WHERE is_active="1" AND  status="1"'.$whrCl.' GROUP BY shift_name ORDER BY shift_master_id' ;  
		$ListShift = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListShift', $ListShift);
	}
      /********* ShiftList Functions Ends ********************************/
	    /********* ShiftWiseReports Functions Starts ********************************/
	function ShiftWiseProduction($objArray)
	{
		global $objSmarty,$config,$_POST;
		$tbl = $config['DBPrefix'];
//	echo $_POST['branchName'];echo "<br>";echo $objArray['branchName'];echo $objArray['branchnameid'];exit;

if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}
	if($branchId=='0')
	{
		$whrCl='AND company_id="'.$comId.'"';
	}
	else{
		$whrCl='AND company_id="'.$comId.'" AND branch_id="'.$branchId.'"';
	}
	
		if($_POST['fromDate']=='' && $_POST['toDate']=='')
	{
		$whereClause='recorded_date BETWEEN  DATE_FORMAT(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE), "%Y-%m-01") AND DATE_FORMAT(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE), "%Y-%m-%d")';
		}
		else
		{
		$whereClause='recorded_date BETWEEN  "'.$_POST['fromDate'].'" AND "'.$_POST['toDate'].'"';
		}
		
		$SelQuery = 'SELECT * from arka_branch_shift_master WHERE is_active="1" AND  status="1"'.$whrCl.' GROUP BY shift_name ORDER BY shift_master_id' ;  
		$ListShift = $this->ExecuteQuery($SelQuery, 'select');
		$ListShiftCount = $this->ExecuteQuery($SelQuery, 'numrows');
	//	$objSmarty->assign('ListShift', $ListShift);
		
		//echo $ListShiftCount; exit;
		$shiftCond;
		$selCon;
		$c='A';
		for($sh=0; $sh<$ListShiftCount; $sh++){
		if($sh==0){
		$parStart="firstShift";
		}
		if($sh==1){
		$parStart="secondShift";
		}
		if($sh==2){
		$parStart="thirdShift";
		}
		if($sh==3){
		$parStart="fourthShift";
		}
	  
		$selCon .=''.$c.'.`sensor_code` AS sensor_code, '.$c.'.`recorded_date` AS recorded_date, '.$c.'.consuption_kwh AS '.$parStart.'KWH,'.$c.'.consuption_cost AS '.$parStart.'Cost,'.$c.'.production AS '.$parStart.'Production,';
		
		$shiftCond .='(SELECT cron_daily_shift_wise_data.`sensor_code` AS sensor_code,cron_daily_shift_wise_data.`consuption_kwh` AS consuption_kwh, cron_daily_shift_wise_data.`consuption_cost` AS consuption_cost,cron_daily_shift_wise_data.recorded_date,cron_daily_shift_wise_data.`production` AS production
		FROM cron_daily_shift_wise_data WHERE '.$whereClause.' AND shift_master_id="'.$ListShift[$sh]['shift_master_id'].'" AND sensor_code="'.$_POST['sensorName'].'" GROUP BY recorded_date) AS '.$c.',';
		
		$c++;
		
		}
		
		$feilds11= rtrim($selCon, ",");
		$tabeles11= rtrim($shiftCond, ",");
	
	
		$SelQuery = 'SELECT '.$feilds11.' FROM '.$tabeles11.' WHERE  A.recorded_date=B.recorded_date AND B.recorded_date=C.recorded_date AND C.recorded_date=A.recorded_date GROUP BY A.`recorded_date` ORDER BY A.`recorded_date` DESC';
	//echo $SelQuery; exit;
		$ListShiftWiseRep = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListShiftWiseRep', $ListShiftWiseRep);
		return $ListShiftWiseRep;
	
	}
      /********* ShiftWiseReports Functions Ends ********************************/
	  
}

?>