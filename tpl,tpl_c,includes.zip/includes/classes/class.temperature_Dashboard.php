<?php
class temperature_Dashboard extends MysqlFns
{
   /********************* temperature_DashBoard Constructor Starts *************************/
	function temperature_Dashboard()
	{
		$this->LDDisplayPath= $config['SiteGlobalPath']."class.temperature_Dashboard.php";
		global $config;
		global $objSmarty;
		global $nowDate;
		$this->Limit = 20;
		$ConLink1 = mysql_connect($config['DBHost'],$config['DBUser'],$config['DBPassword']) or die("Database Connection Failed<br>". mysql_error());
		mysql_select_db($config['DBName'], $ConLink1);
		if($config['DBUser'] != 'root')
		{
			$nowDate= 'NOW()';
		}
		else{
			$nowDate= 'NOW()';
		}
	}
   /********************* temperature_Dashboard Constructor Ends *************************/
 	     /******************** GetDashboardDetails Functions Starts ****************/
		function GetDashboardDetails($objArray='')
		{
		    global $objSmarty;
		if($_GET['companyId'] <> '')
		{
		   $comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		   $comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		   $branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		   $branchId = $_SESSION['branch_id'];
		}
		   $SelQuery_loc = 'SELECT arka_company_master.companyName,arka_branch_master.branch_name,arka_sensor_master.* FROM arka_company_master,arka_branch_master,arka_sensor_master WHERE arka_sensor_master.gateway_id="'.base64_decode($_GET["gatewayCode"]).'" AND arka_sensor_master.sensorCode="'.base64_decode($_GET["sensorCode"]).'" AND  arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.company_id=arka_company_master.slNo AND arka_branch_master.company_id=arka_sensor_master.company_id AND arka_branch_master.company_id=arka_company_master.slNo AND arka_branch_master.sl_no=arka_sensor_master.branch_id' ;
		   $LoctList		= $this->ExecuteQuery($SelQuery_loc, "select");
		   $objSmarty->assign('LoctList', $LoctList);
		   
		      //$SelQuery='select * from gateway_ping_log_view where `ping_log_id` = (Select max(`ping_log_id`) from gateway_ping_log_view WHERE gateway_code="'.base64_decode($_GET["gatewayCode"]).'") GROUP BY gateway_code ORDER BY ping_log_id'; 
			  $SelQuery='select * from gateway_ping_log_view where gateway_code="'.base64_decode($_GET["gatewayCode"]).'"'; 
			  //$SelQuery = $this->ExecuteQuery($SelQuery,"SELECT REPLACE(@@sql_mode,'ONLY_FULL_GROUP_BY','')"); 
	       $gateList= $this->ExecuteQuery($SelQuery, "select");//print_r($MeterList);
	       $objSmarty->assign('gateList', $gateList);
	       
		}	
	/******************** GetDashboardDetails Functions Ends ****************/
	    /*********************  Segment Functions Starts *************************/
		function GetSegmentsList()
		{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		
		if($_GET['companyId'] <> '')
		{
		   $comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		   $comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		   $branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		   $branchId = $_SESSION['branch_id'];
		}
			$Dashboard = 'SELECT * FROM arka_platform_mapping LEFT JOIN arka_iot_platform ON arka_platform_mapping.segmentCode=arka_iot_platform.slNo WHERE arka_platform_mapping.companyName="'.$comId.'" AND arka_platform_mapping.branch_id="'.$branchId.'" ORDER BY arka_iot_platform.slNo ASC';
			$Dashboard		= $this->ExecuteQuery($Dashboard, "select");
			$objSmarty->assign('Dashboard', $Dashboard);
		}
       /*********************  Segment Functions Ends *************************/
	   /********************* GetFeederList Functions Starts **************************/
	function GetFeederList()  
	{
		global $objSmarty;	
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}	
		$gatewayCode=base64_decode($_GET['gatewayCode']);
		$sensorCode=base64_decode($_GET['sensorCode']);
		
	    $SelFeederName = 'SELECT * FROM arka_sensor_master WHERE company_id ="'.$comId.'" AND branch_id ="'.$branchId.'" AND segmentName="Temperature" AND isActive="1"'; 
		$ListFeeder		= $this->ExecuteQuery($SelFeederName, "select");
		$objSmarty->assign('ListFeeder', $ListFeeder);	

		$SelSenso = 'SELECT * FROM feeder_master WHERE company_id ="'.$comId.'" AND branch_id ="'.$branchId.'" AND sensor_code="'.$sensorCode.'" AND is_active="1"'; 
		$ListSenso	= $this->ExecuteQuery($SelSenso, "select");
		$objSmarty->assign('ListSenso', $ListSenso);
	
	
	
	}	
	/********************* GetFeederList Functions Ends **************************/
	function GetTemperatureNew() 
	{
		global $objSmarty,$config;
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}

	$ConfigDBName = $config['DBName'];

	
	   $SelCompanyQuery = 'SELECT companyCode FROM arka_company_master WHERE slNo="'.$comId.'" AND status="1"';  
		$SelCompanyQueryView = $this->ExecuteQuery($SelCompanyQuery, 'select');
		$comCode = $SelCompanyQueryView[0]['companyCode'];

		$SelBranchQuery = 'SELECT branch_id FROM arka_branch_master WHERE sl_no="'.$branchId.'" AND record_status="1"';  
		$SelBranchQueryView = $this->ExecuteQuery($SelBranchQuery, 'select');
		$branchCode = $SelBranchQueryView[0]['branch_id'];
		//echo "Company Code".$comCode."<br>";
		//echo "Branch Code".$branchCode."<br>"; 
		

		   $SelPlatformMapQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';  
			$ListPlatformMapView = $this->ExecuteQuery($SelPlatformMapQuery, 'select');

			$TempPF = "Temperature";

			$SelEnergyPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$TempPF.'" AND status="1"';  
		$ListEnergyPlatformView = $this->ExecuteQuery($SelEnergyPlatformQuery, 'select');

		$tempSegCode = $ListEnergyPlatformView[0]['segmentCode'];
		$tempSegId = $ListEnergyPlatformView[0]['slNo'];
		$objSmarty->assign('tempSegId', $tempSegId);	
		
		$dailyTableTemp = $comCode."_".$branchCode."_".$tempSegCode."_cron_daily";

        //echo $dailyTableTemp; exit;
			$selQryIotTemp = 'SELECT * FROM `arka_iot_platform` WHERE segmentName="Temperature" AND status="1"';
	       $selQryIotTemp		= $this->ExecuteQuery($selQryIotTemp, "select");
		   $tempIotId = $selQryIotTemp[0]['slNo'];
	    



	/*echo"<br><br> selQryS: "; echo */    
		$selQryTemp = 'SELECT arka_sensor_master.*,sensor_model_master.TemHum
FROM arka_sensor_master
INNER JOIN sensor_model_master
    ON sensor_model_master.model_id = arka_sensor_master.sensorModel
WHERE arka_sensor_master.isActive = 1
AND arka_sensor_master.company_id = "'.$comId.'"
AND arka_sensor_master.branch_id = "'.$branchId.'"
AND arka_sensor_master.sensorModel = "MD02"
AND sensor_model_master.platform_id = "3"
GROUP BY arka_sensor_master.sensorCode';
		
		//echo $selQryTemp; exit;
	    $selQryTemp		= $this->ExecuteQuery($selQryTemp, "select");
	    $objSmarty->assign('selQryTemp', $selQryTemp);
      
$TempList = array();
foreach ($selQryTemp as $tempDetail)
{
    $result = array();      // Reset every iteration
    $SelSpecificQuery = "";

    $feederName      = $tempDetail['sensorName'];
    $gatewayCode     = $tempDetail['gateway_id'];
    $sensorCode      = $tempDetail['sensorCode'];
    $sensorCodeTable = str_replace("-", "_", $sensorCode);

    //echo $sensorCode."<br>";

     $selModelQry = 'SELECT sl_no,model_id
                    FROM sensor_model_master
                    WHERE model_id = (
                        SELECT sensorModel
                        FROM arka_sensor_master
                        WHERE sensorCode="'.$sensorCode.'"
                        AND company_id="'.$comId.'"
                        AND branch_id="'.$branchId.'"
                        AND status="1"
                    )
                    AND status="1"'; 

    $selModelQryExe = $this->ExecuteQuery($selModelQry, "select");

    $senModelId = isset($selModelQryExe[0]['sl_no']) ? $selModelQryExe[0]['sl_no'] : "";

     $selTableQry = 'SELECT TABLE_NAME
                    FROM INFORMATION_SCHEMA.TABLES
                    WHERE TABLE_NAME LIKE "'.$comCode.'_'.$branchCode.'\_%_'.$sensorCodeTable.'"'; 

    $selTableQryExe = $this->ExecuteQuery($selTableQry, "select");
    $selTableQryExeCount = $this->ExecuteQuery($selTableQry, "numrows");

    if ($selTableQryExeCount > 0)
    {
        $sensorTableName = $selTableQryExe[0]['TABLE_NAME'];

         $selOffQry = 'SELECT *
                      FROM '.$ConfigDBName.'.'.$sensorTableName.'
                      WHERE status="1"
                      AND sensor_code="'.$sensorCode.'"
                      AND posted_date_time >= DATE_SUB(NOW(),INTERVAL 10 MINUTE)
                      ORDER BY slNo DESC
                      LIMIT 1';

        $selOffQryExe = $this->ExecuteQuery($selOffQry, "select");
        $selOffQryExeCount = $this->ExecuteQuery($selOffQry, "numrows");

            $DBSensorTableName = $ConfigDBName.'.'.$sensorTableName;

             $SelSpecificQuery = '
                SELECT
                    '.$DBSensorTableName.'.posted_date_time,
                    '.$DBSensorTableName.'.sensor_code,
                    '.$DBSensorTableName.'.gateway_code,
                    '.$DBSensorTableName.'.sensor_model,
                    '.$DBSensorTableName.'.temperature_c,
                    '.$DBSensorTableName.'.temperature_f,
                    '.$DBSensorTableName.'.humidity,
                    '.$DBSensorTableName.'.posted_date_time AS TZ,
                    arka_sensor_master.sensorName AS feeder_name,
                    arka_sensor_master.slNo,
                    arka_sensor_master.feeder_type,
                    arka_sensor_master.company_id,
                    arka_sensor_master.branch_id,
                    TIMESTAMPDIFF(SECOND, '.$DBSensorTableName.'.posted_date_time, NOW()) AS secs,
                    sensor_model_master.TemHum
                FROM '.$DBSensorTableName.',
                     arka_sensor_master,
                     sensor_model_master
                WHERE '.$DBSensorTableName.'.gateway_code = arka_sensor_master.gateway_id
                  AND '.$DBSensorTableName.'.sensor_code = arka_sensor_master.sensorCode
                  AND arka_sensor_master.company_id="'.$comId.'"
                  AND arka_sensor_master.branch_id="'.$branchId.'"
                  AND arka_sensor_master.isActive="1"
                  AND arka_sensor_master.status="1"
                  AND sensor_model_master.model_id=arka_sensor_master.sensorModel
                ORDER BY '.$DBSensorTableName.'.slNo DESC
                LIMIT 1';

            //echo $SelSpecificQuery."<br>";

            $result = $this->ExecuteQuery($SelSpecificQuery, "select");
        
    }
	if (!empty($result))
    {
		$result[0]['sensor_table'] = $DBSensorTableName;
        $TempList[] = $result[0];
    }else{
    $TempList[] = array(
        'posted_date_time' => '',
        'sensor_code'      => $sensorCode,
        'gateway_code'     => $gatewayCode,
        'sensor_model'     => $tempDetail['sensorModel'],
        'temperature_c'    => '',
        'temperature_f'    => '',
        'humidity'         => '',
        'TZ'               => '',
        'feeder_name'      => $feederName,
        'slNo'             => $tempDetail['slNo'],
        'feeder_type'      => $tempDetail['feeder_type'],
        'company_id'       => $comId,
        'branch_id'        => $branchId,
        'secs'             => '',
        'TemHum'           => $tempDetail['TemHum'],
		'sensor_table'     => $DBSensorTableName
    );

	}

   
}
	//print_r($TempList); exit;

$objSmarty->assign('TempList', $TempList);
//echo $TempList[1]['TemHum']."<br>";exit;	
		
		$allincidentList = array();
		 foreach ($TempList as $key => $value) 
	{
	      $lDateSec = $value["secs"];
		  $gateway_code = $value["gateway_code"];
			
	 $objSmarty->assign('lDateSec', $lDateSec);

		   $SelQuery='select * from gateway_ping_log_view where gateway_code="'.$gateway_code.'"'; 
		  // $SelQuery='select * from gateway_ping_log_view where `ping_log_id` = (Select max(`ping_log_id`) from gateway_ping_log_view WHERE gateway_code="'.$gateway_code.'")'; 
	       $gateList= $this->ExecuteQuery($SelQuery, "select");//print_r($MeterList);
	       $objSmarty->assign('gateList', $gateList);
		   
		    $sensorTable = $value["sensor_table"];
		   $sensor_code = $value["sensor_code"];
		   $sensor_sec = $value["secs"];
		  
		   $selAllIncidentLog = '
        SELECT temperature_c,
               sensor_code,
               slNo,
               humidity,
               posted_date_time
        FROM
        (
            SELECT temperature_c,
                   sensor_code,
                   slNo,
                   humidity,
                   posted_date_time,
                   @rn:=IF(@prev=sensor_code,@rn+1,1) rn,
                   @prev:=sensor_code
            FROM '.$sensorTable.'
            JOIN (SELECT @prev:=NULL,@rn:=0) vars
            ORDER BY sensor_code, slNo DESC
        ) T1
        WHERE sensor_code="'.$sensor_code.'"
        AND rn<=3';

		
			$allincidentList[$sensor_code]= $this->ExecuteQuery($selAllIncidentLog, "select");		
// 			echo "<pre>";
// print_r($this->ExecuteQuery($selAllIncidentLog, "select"));
// echo "</pre>";
// exit;	

	    }   

		$objSmarty->assign('allincidentList', $allincidentList);

		 $selQryS = 'SELECT * FROM `arka_sensor_master` WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.feeder_type="Sub Meter" GROUP BY sensorCode';	 
		  //$selQryS = $this->ExecuteQuery($selQryS,"SELECT REPLACE(@@sql_mode,'ONLY_FULL_GROUP_BY','')");        
	       $selQryS		= $this->ExecuteQuery($selQryS, "select");
		   
	    $objSmarty->assign('selQryS', $selQryS);
		
	if($_SESSION['CustomerId'] =='CUS1001')
	{ 
		$SelQueryAll = 'SELECT  '.$DBSensorTableName.'.* FROM  '.$DBSensorTableName.' ORDER BY  '.$DBSensorTableName.'.slNo DESC Limit 0,1' ;  
	}
	else
	{
		$SelQueryAll = 'SELECT  '.$DBSensorTableName.'.* FROM  '.$DBSensorTableName.' ORDER BY  '.$DBSensorTableName.'.slNo DESC Limit 0,1' ;
	}
		$TemperatureList		= $this->ExecuteQuery($SelQueryAll, "select");
		$objSmarty->assign('TemperatureList', $TemperatureList);

			  
		
	}
	/********************* GetTemperature Functions Starts **************************/
	function GetTemperature() 
	{
		global $objSmarty;
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}
	
		$SelQuery = 'SELECT  `temperature_data_master_view`.recorded_date_time,`temperature_data_master_view`.sensor_code,`temperature_data_master_view`.gateway_code,`temperature_data_master_view`.sensor_model,`temperature_data_master_view`.temperature_c,`temperature_data_master_view`.temperature_f,`temperature_data_master_view`.humidity,`temperature_data_master_view`.recorded_date_time AS TZ,`arka_sensor_master`.sensorName AS feeder_name,`arka_sensor_master`.company_id,`arka_sensor_master`.branch_id,TIMESTAMPDIFF(SECOND, recorded_date_time, NOW()) AS secs FROM  `temperature_data_master_view`,`arka_sensor_master` WHERE  `temperature_data_master_view`.gateway_code =`arka_sensor_master`.gateway_id AND `temperature_data_master_view`.sensor_code =`arka_sensor_master`.sensorCode AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.isActive="1" AND arka_sensor_master.status="1" ' ;  		
		$TempList		= $this->ExecuteQuery($SelQuery, "select");
		$objSmarty->assign('TempList', $TempList);
		
		   $SelQuery='SELECT max(ping_log_id) AS ping_log_id, max(gateway_code) AS gateway_code,max(gateway_date_time) AS gateway_date_time FROM `gateway_ping_log` GROUP BY gateway_code ORDER BY ping_log_id';  
		   //$SelQuery = $this->ExecuteQuery($SelQuery,"SELECT REPLACE(@@sql_mode,'ONLY_FULL_GROUP_BY','')"); 
		 $gateList= $this->ExecuteQuery($SelQuery, "select");//print_r($MeterList);
	       $objSmarty->assign('gateList', $gateList);
		/* foreach ($TempList as $key => $value) 
	{
	    $gateway_code = $TempList[0]["gateway_code"];
		   $SelQuery='select * from gateway_ping_log where `ping_log_id` = (Select max(`ping_log_id`) from gateway_ping_log WHERE gateway_code="'.$gateway_code.'")'; 
	       $gateList= $this->ExecuteQuery($SelQuery, "select");//print_r($MeterList);
	       $objSmarty->assign('gateList', $gateList);
	    }   */
	       $selQryS = 'SELECT * FROM `arka_sensor_master` WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.feeder_type="Sub Meter" GROUP BY sensorCode';	
		   //$selQryS = $this->ExecuteQuery($selQryS,"SELECT REPLACE(@@sql_mode,'ONLY_FULL_GROUP_BY','')");          
	       $selQryS		= $this->ExecuteQuery($selQryS, "select");
		   
	    $objSmarty->assign('selQryS', $selQryS);
		
	if($_SESSION['CustomerId'] =='CUS1001')
	{ 
		$SelQueryAll = 'SELECT  `temperature_data_master`.* FROM  `temperature_data_master` ORDER BY  `temperature_data_master`.temperature_data_id DESC Limit 0,1' ;  
	}
	else
	{
		$SelQueryAll = 'SELECT  `temperature_data_master`.* FROM  `temperature_data_master` ORDER BY  `temperature_data_master`.temperature_data_id DESC Limit 0,1' ;
	}
		$TemperatureList		= $this->ExecuteQuery($SelQueryAll, "select");
		$objSmarty->assign('TemperatureList', $TemperatureList);		
	}
      /********************* GetTemperature Functions Ends **************************/
	  /********************* GetTempLogGraph Functions Starts **************************/
	function GetTempLogGraph()
	{
		global $objSmarty,$config,$nowDate;
		$pf='';
	if(isset($_POST['date1']) && isset($_POST['date2']))
	{
		$date1 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		$date2 = date("Y-m-d",strtotime(trim(addslashes($_POST['date2']))));
		$yaxis_par="temperature_c,temperature_f,humidity";
	
		$query_rs1 =  "SELECT ".$yaxis_par.",recorded_date_time AS TM FROM temperature_data_master WHERE gateway_code='".base64_decode($_GET['gatewayCode'])."' AND sensor_code='".base64_decode($_GET['sensorCode'])."' AND (DATE(recorded_date_time) BETWEEN '".$date1."' AND '".$date2."') ORDER BY TM ASC";
	}
	else
	{
		$yaxis_par="temperature_c,temperature_f,humidity";
		
		$query_rs1 = "SELECT ".$yaxis_par.",recorded_date_time AS TM FROM temperature_data_master WHERE gateway_code='".base64_decode($_GET['gatewayCode'])."' AND sensor_code='".base64_decode($_GET['sensorCode'])."' AND DATE(recorded_date_time) = DATE(CONVERT_TZ(NOW(),'+00:00' ,'+00:00')) ORDER BY TM ASC";
	}
		//echo $query_rs1;
		$GetTemp = $this->ExecuteQuery($query_rs1, "select");
		$objSmarty->assign('GetTemp', $GetTemp);
		$splVar= explode(",",$yaxis_par);
		$arrData = array();
	
	foreach ($GetTemp as $key => $value) 
	{
		$orgDate =$GetTemp[$key]['TM'];  
		$GDate = date("d-M-Y h:i A", strtotime($orgDate));
		array_push($arrData, array(
		$splVar[0] => $GetTemp[$key][$splVar[0]],
		$splVar[1] => $GetTemp[$key][$splVar[1]],
		$splVar[2] => $GetTemp[$key][$splVar[2]],
		"tm" => $GDate
	));
	}
		$ChartData = json_encode($arrData);
		$objSmarty->assign('ChartData', $ChartData);
	} 
     /********************* GetTempLogGraph Functions Ends **************************/
	 /********************* GetTempLog Functions Starts **************************/
	function GetTempLog()
	{
		global $objSmarty,$config,$nowDate;

		$ConfigDBName = $config['DBName'];

		
		$comId = base64_decode($_GET['companyId']);
		$branchId = base64_decode($_GET['branchId']);
		$sensorCode = base64_decode($_GET['sensorCode']);
		 $sensorCodeTable = str_replace("-", "_", $sensorCode);
	
    

	   $SelCompanyQuery = 'SELECT companyCode FROM arka_company_master WHERE slNo="'.$comId.'" AND status="1"';  
		$SelCompanyQueryView = $this->ExecuteQuery($SelCompanyQuery, 'select');
		$comCode = $SelCompanyQueryView[0]['companyCode'];

		$SelBranchQuery = 'SELECT branch_id FROM arka_branch_master WHERE sl_no="'.$branchId.'" AND record_status="1"';  
		$SelBranchQueryView = $this->ExecuteQuery($SelBranchQuery, 'select');
		$branchCode = $SelBranchQueryView[0]['branch_id'];
		//echo "Company Code".$comCode."<br>";
		//echo "Branch Code".$branchCode."<br>"; 
		

		   $SelPlatformMapQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';  
			$ListPlatformMapView = $this->ExecuteQuery($SelPlatformMapQuery, 'select');

			$TempPF = "Temperature";

			$SelEnergyPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$TempPF.'" AND status="1"';  
		$ListEnergyPlatformView = $this->ExecuteQuery($SelEnergyPlatformQuery, 'select');

		$tempSegCode = $ListEnergyPlatformView[0]['segmentCode'];
		$tempSegId = $ListEnergyPlatformView[0]['slNo'];
		$objSmarty->assign('tempSegId', $tempSegId);	
		
		/*echo"<br><br> selQryS: "; echo */    
		  $selQrySenTemp = 'SELECT arka_sensor_master.*,sensor_model_master.TemHum
FROM arka_sensor_master
INNER JOIN sensor_model_master
    ON sensor_model_master.model_id = arka_sensor_master.sensorModel
WHERE arka_sensor_master.isActive = 1
AND arka_sensor_master.company_id = "'.$comId.'"
AND arka_sensor_master.branch_id = "'.$branchId.'"
AND arka_sensor_master.sensorCode = "'.$sensorCode.'"
AND sensor_model_master.platform_id = "3"'; 
		
		//echo $selQryTemp; exit;
	    $selQrySenTemp		= $this->ExecuteQuery($selQrySenTemp, "select");
	    $objSmarty->assign('selQrySenTemp', $selQrySenTemp);
      
  $TempSenTableList = array();
    $result = array();      // Reset every iteration
// foreach ($selQryTemp as $tempDetail)
// {


		$dailyTableTemp = $comCode."_".$branchCode."_".$tempSegCode."_cron_daily";

        //echo $dailyTableTemp; exit;
			$selQryIotTemp = 'SELECT * FROM `arka_iot_platform` WHERE segmentName="Temperature" AND status="1"';
	       $selQryIotTemp		= $this->ExecuteQuery($selQryIotTemp, "select");
		   $tempIotId = $selQryIotTemp[0]['slNo'];
	    


    //echo $sensorCode."<br>";


     $selTableQry = 'SELECT TABLE_NAME
                    FROM INFORMATION_SCHEMA.TABLES
                    WHERE TABLE_NAME LIKE "'.$comCode.'_'.$branchCode.'\_%_'.$sensorCodeTable.'"'; 

    $selTableQryExe = $this->ExecuteQuery($selTableQry, "select");
    $selTableQryExeCount = $this->ExecuteQuery($selTableQry, "numrows");

    if ($selTableQryExeCount > 0)
    {
        $sensorTableName = $selTableQryExe[0]['TABLE_NAME'];

         $selOffQry = 'SELECT *
                      FROM '.$ConfigDBName.'.'.$sensorTableName.'
                      WHERE status="1"
                      AND sensor_code="'.$sensorCode.'"
                      AND posted_date_time >= DATE_SUB(NOW(),INTERVAL 10 MINUTE)
                      ORDER BY slNo DESC
                      LIMIT 1';

        $selOffQryExe = $this->ExecuteQuery($selOffQry, "select");
        $selOffQryExeCount = $this->ExecuteQuery($selOffQry, "numrows");

            $DBSensorTableName = $ConfigDBName.'.'.$sensorTableName;
//echo $DBSensorTableName; exit;
// 			 $SelQuery = '
// SELECT
//     '.$DBSensorTableName.'.posted_date_time,
//     '.$DBSensorTableName.'.sensor_code,
//     '.$DBSensorTableName.'.gateway_code,
//     '.$DBSensorTableName.'.sensor_model,
//     '.$DBSensorTableName.'.temperature_c,
//     '.$DBSensorTableName.'.temperature_f,
//     '.$DBSensorTableName.'.humidity,
//     '.$DBSensorTableName.'.posted_date_time AS TZ,
//     arka_sensor_master.sensorName,
//     arka_sensor_master.company_id,
//     arka_sensor_master.branch_id,
//     TIMESTAMPDIFF(SECOND, '.$DBSensorTableName.'.posted_date_time, NOW()) AS secs
// FROM '.$DBSensorTableName.',
//      arka_sensor_master
// WHERE '.$DBSensorTableName.'.gateway_code = arka_sensor_master.gateway_id
//   AND '.$DBSensorTableName.'.sensor_code = arka_sensor_master.sensorCode
//   AND arka_sensor_master.company_id = "'.$comId.'"
//   AND arka_sensor_master.branch_id = "'.$branchId.'"
//   AND arka_sensor_master.sensorCode = "'.$sensorCode.'"
//   AND arka_sensor_master.isActive = "1"
//   AND arka_sensor_master.status = "1" ORDER BY '.$DBSensorTableName.'.slNo DESC LIMIT 1';  



			// echo $SelQuery = 'SELECT  `temperature_data_master_view`.recorded_date_time,`temperature_data_master_view`.sensor_code,`temperature_data_master_view`.gateway_code,`temperature_data_master_view`.sensor_model,`temperature_data_master_view`.temperature_c,`temperature_data_master_view`.temperature_f,`temperature_data_master_view`.humidity,`temperature_data_master_view`.recorded_date_time AS TZ,`arka_sensor_master`.sensorName,`arka_sensor_master`.company_id,`arka_sensor_master`.branch_id,TIMESTAMPDIFF(SECOND, recorded_date_time, NOW()) AS secs FROM  `temperature_data_master_view`,`arka_sensor_master` WHERE  `temperature_data_master_view`.gateway_code =`arka_sensor_master`.gateway_id AND `temperature_data_master_view`.sensor_code =`arka_sensor_master`.sensorCode AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.sensorCode="'.$sensorCode.'" AND  arka_sensor_master.isActive="1" AND arka_sensor_master.status="1" ' ;  	exit;	


           // $result = $this->ExecuteQuery($SelQuery, "select");
        
    }

	
	if(@$_POST['date1']!='' && @$_POST['date2'] !='')
	{
		$fDate = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		$tDate = date("Y-m-d",strtotime(trim(addslashes($_POST['date2']))));	

		
		$GetQuery1 = 'SELECT posted_date_time AS M_TIMESTAMP,posted_date_time,linux_date_time,teltonika_date_time,'.$DBSensorTableName.'.gateway_code,'.$DBSensorTableName.'.sensor_code,'.$DBSensorTableName.'.temperature_c,'.$DBSensorTableName.'.temperature_f,'.$DBSensorTableName.'.humidity FROM '.$DBSensorTableName.' WHERE gateway_code="'.base64_decode($_GET["gatewayCode"]).'" AND sensor_code="'.base64_decode($_GET["sensorCode"]).'" AND DATE(posted_date_time) BETWEEN "'.$fDate.'" AND "'.$tDate.'" GROUP BY M_TIMESTAMP ORDER BY slNo DESC';
	}
	else
	{	
		$GetQuery1 = 'SELECT posted_date_time AS M_TIMESTAMP,posted_date_time,linux_date_time,teltonika_date_time,'.$DBSensorTableName.'.gateway_code,'.$DBSensorTableName.'.sensor_code,'.$DBSensorTableName.'.temperature_c,'.$DBSensorTableName.'.temperature_f,'.$DBSensorTableName.'.humidity FROM '.$DBSensorTableName.' WHERE gateway_code="'.base64_decode($_GET["gatewayCode"]).'" AND sensor_code="'.base64_decode($_GET["sensorCode"]).'" AND DATE(posted_date_time)=DATE(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE)) ORDER BY slNo DESC';	
	}
		$GetTemp = $this->ExecuteQuery($GetQuery1, "select");
		$objSmarty->assign('GetTemp', $GetTemp);
	} 
     /********************* GetTempLog Functions Ends **************************/
      /******************** IncidentLog Functions Starts **************************/
		function TemperatureIncidentLog()
		{
		global $objSmarty,$config;
		
	$selAllIncidentLog = 'SELECT temperature_c, sensor_code, temperature_data_id,humidity,recorded_date_time FROM ( SELECT temperature_c, sensor_code, temperature_data_id,humidity,recorded_date_time, @rn := IF(@prev = sensor_code, @rn + 1, 1) AS rn, @prev := sensor_code FROM temperature_data_master JOIN (SELECT @prev := NULL, @rn := 0) AS vars WHERE temperature_c NOT BETWEEN "21.0" AND "28.0" OR humidity NOT BETWEEN "55.0" AND "60.0" ORDER BY sensor_code, temperature_data_id DESC, temperature_c ) AS T1 WHERE rn <= 3';
			$allincidentList= $this->ExecuteQuery($selAllIncidentLog, "select");
			$objSmarty->assign('allincidentList', $allincidentList);
		}
		/*****************************Get Temperature Sensor**************************************************/
		
		function GetTemperatureSensor() 
	{
		global $objSmarty,$config;
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}
	$gatewayCode=base64_decode($_GET['gatewayCode']);
	$sensorCode = base64_decode($_GET['sensorCode']);
	 $sensorCodeTable = str_replace("-", "_", $sensorCode);
	 $ConfigDBName = $config['DBName'];
    

	   $SelCompanyQuery = 'SELECT companyCode FROM arka_company_master WHERE slNo="'.$comId.'" AND status="1"';  
		$SelCompanyQueryView = $this->ExecuteQuery($SelCompanyQuery, 'select');
		$comCode = $SelCompanyQueryView[0]['companyCode'];

		$SelBranchQuery = 'SELECT branch_id FROM arka_branch_master WHERE sl_no="'.$branchId.'" AND record_status="1"';  
		$SelBranchQueryView = $this->ExecuteQuery($SelBranchQuery, 'select');
		$branchCode = $SelBranchQueryView[0]['branch_id'];
		//echo "Company Code".$comCode."<br>";
		//echo "Branch Code".$branchCode."<br>"; 
		

		   $SelPlatformMapQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';  
			$ListPlatformMapView = $this->ExecuteQuery($SelPlatformMapQuery, 'select');

			$TempPF = "Temperature";

			$SelEnergyPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$TempPF.'" AND status="1"';  
		$ListEnergyPlatformView = $this->ExecuteQuery($SelEnergyPlatformQuery, 'select');

		$tempSegCode = $ListEnergyPlatformView[0]['segmentCode'];
		$tempSegId = $ListEnergyPlatformView[0]['slNo'];
		$objSmarty->assign('tempSegId', $tempSegId);	
		
		/*echo"<br><br> selQryS: "; echo */    
		 $selQrySenTemp = 'SELECT arka_sensor_master.*,sensor_model_master.TemHum
FROM arka_sensor_master
INNER JOIN sensor_model_master
    ON sensor_model_master.model_id = arka_sensor_master.sensorModel
WHERE arka_sensor_master.isActive = 1
AND arka_sensor_master.company_id = "'.$comId.'"
AND arka_sensor_master.branch_id = "'.$branchId.'"
AND arka_sensor_master.sensorCode = "'.$sensorCode.'"
AND sensor_model_master.platform_id = "3"';
		
		//echo $selQryTemp; exit;
	    $selQrySenTemp		= $this->ExecuteQuery($selQrySenTemp, "select");
	    $objSmarty->assign('selQrySenTemp', $selQrySenTemp);
      
  $TempSenList = array();
    $result = array();      // Reset every iteration
// foreach ($selQryTemp as $tempDetail)
// {


		$dailyTableTemp = $comCode."_".$branchCode."_".$tempSegCode."_cron_daily";

        //echo $dailyTableTemp; exit;
			$selQryIotTemp = 'SELECT * FROM `arka_iot_platform` WHERE segmentName="Temperature" AND status="1"';
	       $selQryIotTemp		= $this->ExecuteQuery($selQryIotTemp, "select");
		   $tempIotId = $selQryIotTemp[0]['slNo'];
	    


    //echo $sensorCode."<br>";


     $selTableQry = 'SELECT TABLE_NAME
                    FROM INFORMATION_SCHEMA.TABLES
                    WHERE TABLE_NAME LIKE "'.$comCode.'_'.$branchCode.'\_%_'.$sensorCodeTable.'"'; 

    $selTableQryExe = $this->ExecuteQuery($selTableQry, "select");
    $selTableQryExeCount = $this->ExecuteQuery($selTableQry, "numrows");

    if ($selTableQryExeCount > 0)
    {
        $sensorTableName = $selTableQryExe[0]['TABLE_NAME'];

         $selOffQry = 'SELECT *
                      FROM '.$ConfigDBName.'.'.$sensorTableName.'
                      WHERE status="1"
                      AND sensor_code="'.$sensorCode.'"
                      AND posted_date_time >= DATE_SUB(NOW(),INTERVAL 10 MINUTE)
                      ORDER BY slNo DESC
                      LIMIT 1';

        $selOffQryExe = $this->ExecuteQuery($selOffQry, "select");
        $selOffQryExeCount = $this->ExecuteQuery($selOffQry, "numrows");

            $DBSensorTableName = $ConfigDBName.'.'.$sensorTableName;

			 $SelQuery = '
SELECT
    '.$DBSensorTableName.'.posted_date_time,
    '.$DBSensorTableName.'.sensor_code,
    '.$DBSensorTableName.'.gateway_code,
    '.$DBSensorTableName.'.sensor_model,
    '.$DBSensorTableName.'.temperature_c,
    '.$DBSensorTableName.'.temperature_f,
    '.$DBSensorTableName.'.humidity,
    '.$DBSensorTableName.'.posted_date_time AS TZ,
    arka_sensor_master.sensorName,
    arka_sensor_master.company_id,
    arka_sensor_master.branch_id,
    TIMESTAMPDIFF(SECOND, '.$DBSensorTableName.'.posted_date_time, NOW()) AS secs
FROM '.$DBSensorTableName.',
     arka_sensor_master
WHERE '.$DBSensorTableName.'.gateway_code = arka_sensor_master.gateway_id
  AND '.$DBSensorTableName.'.sensor_code = arka_sensor_master.sensorCode
  AND arka_sensor_master.company_id = "'.$comId.'"
  AND arka_sensor_master.branch_id = "'.$branchId.'"
  AND arka_sensor_master.sensorCode = "'.$sensorCode.'"
  AND arka_sensor_master.isActive = "1"
  AND arka_sensor_master.status = "1" ORDER BY '.$DBSensorTableName.'.slNo DESC LIMIT 1';  



			// echo $SelQuery = 'SELECT  `temperature_data_master_view`.recorded_date_time,`temperature_data_master_view`.sensor_code,`temperature_data_master_view`.gateway_code,`temperature_data_master_view`.sensor_model,`temperature_data_master_view`.temperature_c,`temperature_data_master_view`.temperature_f,`temperature_data_master_view`.humidity,`temperature_data_master_view`.recorded_date_time AS TZ,`arka_sensor_master`.sensorName,`arka_sensor_master`.company_id,`arka_sensor_master`.branch_id,TIMESTAMPDIFF(SECOND, recorded_date_time, NOW()) AS secs FROM  `temperature_data_master_view`,`arka_sensor_master` WHERE  `temperature_data_master_view`.gateway_code =`arka_sensor_master`.gateway_id AND `temperature_data_master_view`.sensor_code =`arka_sensor_master`.sensorCode AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.sensorCode="'.$sensorCode.'" AND  arka_sensor_master.isActive="1" AND arka_sensor_master.status="1" ' ;  	exit;	


            $result = $this->ExecuteQuery($SelQuery, "select");
        
    }
	
   if (!empty($result))
    {
		$result[0]['sensor_table'] = $DBSensorTableName;
        $TempSenList[] = $result[0];
    }else{
		//echo"am in else".$sensorCode; exit;
    $TempSenList[] = array(
        'posted_date_time' => '',
        'sensor_code'      => $sensorCode,
        'gateway_code'     => $gatewayCode,
		'sensorName'       => $selQrySenTemp[0]['sensorName'],
        'sensor_model'     => $selQrySenTemp[0]['sensorModel'],
        'temperature_c'    => '',
        'temperature_f'    => '',
        'humidity'         => '',
        'TZ'               => '',
        'feeder_name'      => $feederName,
        'slNo'             => $selQrySenTemp[0]['slNo'],
        'feeder_type'      => $selQrySenTemp[0]['feeder_type'],
        'company_id'       => $comId,
        'branch_id'        => $branchId,
        'secs'             => '',
        'TemHum'           => $selQrySenTemp[0]['TemHum'],
		'sensor_table'     => $DBSensorTableName
    );

	}

// 	echo "<pre>";
// print_r($this->ExecuteQuery($SelQuery, "select"));
// echo "</pre>";
// exit;

//$TempSenList		= $this->ExecuteQuery($SelQuery, "select");
$objSmarty->assign('TempSenList', $TempSenList);



		
		// echo $SelQuery = 'SELECT  `temperature_data_master_view`.recorded_date_time,`temperature_data_master_view`.sensor_code,`temperature_data_master_view`.gateway_code,`temperature_data_master_view`.sensor_model,`temperature_data_master_view`.temperature_c,`temperature_data_master_view`.temperature_f,`temperature_data_master_view`.humidity,`temperature_data_master_view`.recorded_date_time AS TZ,`arka_sensor_master`.sensorName,`arka_sensor_master`.company_id,`arka_sensor_master`.branch_id,TIMESTAMPDIFF(SECOND, recorded_date_time, NOW()) AS secs FROM  `temperature_data_master_view`,`arka_sensor_master` WHERE  `temperature_data_master_view`.gateway_code =`arka_sensor_master`.gateway_id AND `temperature_data_master_view`.sensor_code =`arka_sensor_master`.sensorCode AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.sensorCode="'.$sensorCode.'" AND  arka_sensor_master.isActive="1" AND arka_sensor_master.status="1" ' ;  	exit;	
		// $TempSenList		= $this->ExecuteQuery($SelQuery, "select");
		// $objSmarty->assign('TempSenList', $TempSenList);
		
			//$selIncidentLog = 'SELECT * FROM `temperature_data_master` where sensor_code="'.$sensorCode.'" AND (temperature_c NOT BETWEEN "21.0" AND "28.0" OR humidity NOT BETWEEN "55.0" AND "60.0") ORDER BY recorded_date_time DESC LIMIT 0,15'; 
			$selIncidentLog = 'SELECT * FROM '.$DBSensorTableName.' where sensor_code="'.$sensorCode.'" ORDER BY posted_date_time DESC LIMIT 0,15'; 
			$incidentList		= $this->ExecuteQuery($selIncidentLog, "select");
			$objSmarty->assign('incidentList', $incidentList);
		}
		/****************************************************************************************/
			 /********************* GetLineGraph Functions Starts **************************/
	function GetLineGraph(){
		global $objSmarty,$config,$nowDate;
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}
		$sensorCode = base64_decode($_GET['sensorCode']);
		$gatewayCode = base64_decode($_GET['gatewayCode']);
	
		//$selLineGraph='SELECT DATE_FORMAT(recorded_date_time,"%h:%i %p") AS month_data, DATE_FORMAT(recorded_date_time,"%e-%b-%Y") AS recDate,sensor_code, gateway_code, temperature_c, humidity  FROM temperature_data_master WHERE gateway_code="'.$gatewayCode.'" AND sensor_code="'.$sensorCode.'" order by recorded_date_time DESC Limit 0,60';
		 $selLineGraph='SELECT tab1.* FROM (SELECT DATE_FORMAT(recorded_date_time,"%h:%i %p") AS month_data, DATE_FORMAT(recorded_date_time,"%e-%b-%Y") AS recDate,sensor_code, gateway_code, temperature_c, humidity ,recorded_date_time FROM temperature_data_master WHERE gateway_code="'.$gatewayCode.'" AND sensor_code="'.$sensorCode.'"  ORDER BY recorded_date_time DESC LIMIT 0,60 ) AS tab1 ORDER BY tab1.recorded_date_time ASC'; 
		$ExeLineGraph		= $this->ExecuteQuery($selLineGraph, "select");
		$ExeLineGraphCount		= $this->ExecuteQuery($selLineGraph, "numrows");
		
	$objParmT='';
	$objParmH='';
	foreach($ExeLineGraph as $key2=>$value2)
	{
		$objParmT .='{"month": "'.$ExeLineGraph[$key2]["month_data"].'","rdate": "'.$ExeLineGraph[$key2]["recDate"].'","T": '.$ExeLineGraph[$key2]["temperature_c"].'},';
		$objParmH .='{"month": "'.$ExeLineGraph[$key2]["month_data"].'","rdate": "'.$ExeLineGraph[$key2]["recDate"].'","H": '.$ExeLineGraph[$key2]["humidity"].'},';
	}
	
	$objGraph='{
	"title": "Temperature",
	"balloonText": "[[title]]: <b>[[value]] </b> Time:<b> [[category]]</b>",
	"bullet": "round",
	"bulletSize": 6,
	"bulletBorderColor": "#ffffff",
	"bulletBorderAlpha": 1,
	"bulletBorderThickness": 2,
	"type": "smoothedLine",
	"valueField": "T"
	}';
	$objGraph2='{
	"title": "Humidity",
	"balloonText": "[[title]]: <b>[[value]] </b> Time:<b> [[category]]</b>",
	"bullet": "round",
	"bulletSize": 6,
	"bulletBorderColor": "#ffffff",
	"bulletBorderAlpha": 1,
	"bulletBorderThickness": 2,
	"type": "smoothedLine",
	"valueField": "H"
	}';
	
		
		$LineGraphData="[".rtrim($objGraph, ",")."]";
		$LineGraphData2="[".rtrim($objGraph2, ",")."]";
		$LineGraphDataT="[".rtrim($objParmT, ",")."]";
		$LineGraphDataH="[".rtrim($objParmH, ",")."]";
		
		$objSmarty->assign('LineGraphData',$LineGraphData);
		$objSmarty->assign('LineGraphData2',$LineGraphData2);
		$objSmarty->assign('LineGraphDataT',$LineGraphDataT);
		$objSmarty->assign('LineGraphDataH',$LineGraphDataH);
	}
    /********************* GetLineGraph Functions Ends **************************/
	/********************* GetTempMultiLineGraph Branch Functions starts **********************/
	  function TempMultilinegraph()
	  {
		global $objSmarty,$config,$nowDate;
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}
		$ConfigDBName = $config['DBName'];
		$sensorCode = base64_decode($_GET['sensorCode']);
		$gatewayCode = base64_decode($_GET['gatewayCode']);
	    $sensorCodeTable = str_replace("-", "_", $sensorCode);
		//$selLineGraph='SELECT DATE_FORMAT(recorded_date_time,"%h:%i %p") AS month_data, DATE_FORMAT(recorded_date_time,"%e-%b-%Y") AS recDate,sensor_code, gateway_code, temperature_c, humidity  FROM temperature_data_master WHERE gateway_code="'.$gatewayCode.'" AND sensor_code="'.$sensorCode.'" order by recorded_date_time DESC Limit 0,60';
		
		 $selDashGraph='SELECT arka_sensor_master.* ,sensor_model_master.TemHum FROM arka_sensor_master,sensor_model_master WHERE arka_sensor_master.sensorCode="'.base64_decode($_GET["sensorCode"]).'" AND sensor_model_master.model_id=arka_sensor_master.sensorModel AND arka_sensor_master.isActive="1" AND arka_sensor_master.status="1"';  
		$ExeDashGraph		= $this->ExecuteQuery($selDashGraph, "select");
		$objSmarty->assign('ExeDashGraph',$ExeDashGraph);
       
		  

		 $SelCompanyQuery = 'SELECT companyCode FROM arka_company_master WHERE slNo="'.$comId.'" AND status="1"';  
		$SelCompanyQueryView = $this->ExecuteQuery($SelCompanyQuery, 'select');
		$comCode = $SelCompanyQueryView[0]['companyCode'];

		$SelBranchQuery = 'SELECT branch_id FROM arka_branch_master WHERE sl_no="'.$branchId.'" AND record_status="1"';  
		$SelBranchQueryView = $this->ExecuteQuery($SelBranchQuery, 'select');
		$branchCode = $SelBranchQueryView[0]['branch_id'];
		//echo "Company Code".$comCode."<br>";
		//echo "Branch Code".$branchCode."<br>"; 
	    


     $selTableQry = 'SELECT TABLE_NAME
                    FROM INFORMATION_SCHEMA.TABLES
                    WHERE TABLE_NAME LIKE "'.$comCode.'_'.$branchCode.'\_%_'.$sensorCodeTable.'"'; 

    $selTableQryExe = $this->ExecuteQuery($selTableQry, "select");
    $selTableQryExeCount = $this->ExecuteQuery($selTableQry, "numrows");

    if ($selTableQryExeCount > 0)
    {
        $sensorTableName = $selTableQryExe[0]['TABLE_NAME'];

         $selOffQry = 'SELECT *
                      FROM '.$ConfigDBName.'.'.$sensorTableName.'
                      WHERE status="1"
                      AND sensor_code="'.$sensorCode.'"
                      AND posted_date_time >= DATE_SUB(NOW(),INTERVAL 10 MINUTE)
                      ORDER BY slNo DESC
                      LIMIT 1';

        $selOffQryExe = $this->ExecuteQuery($selOffQry, "select");
        $selOffQryExeCount = $this->ExecuteQuery($selOffQry, "numrows");

            $DBSensorTableName = $ConfigDBName.'.'.$sensorTableName;

// $selLineGraph='SELECT tab1.* FROM (SELECT DATE_FORMAT(recorded_date_time,"%e-%b-%y %h:%i %p") AS x_axis_data,DATE_FORMAT(recorded_date_time,"%h:%i %p") AS month_data, DATE_FORMAT(recorded_date_time,"%e-%b-%Y") AS recDate,sensor_code, gateway_code, temperature_c, humidity ,recorded_date_time FROM temperature_data_master WHERE gateway_code="'.$gatewayCode.'" AND sensor_code="'.$sensorCode.'"  ORDER BY recorded_date_time DESC LIMIT 0,48 ) AS tab1 ORDER BY tab1.recorded_date_time ASC'; 

			 $selLineGraph='SELECT tab1.* FROM (SELECT DATE_FORMAT(posted_date_time,"%e-%b-%y %h:%i %p") AS x_axis_data,DATE_FORMAT(posted_date_time,"%h:%i %p") AS month_data, DATE_FORMAT(posted_date_time,"%e-%b-%Y") AS recDate,sensor_code, gateway_code, temperature_c, humidity ,posted_date_time FROM '.$DBSensorTableName.' WHERE gateway_code="'.$gatewayCode.'" AND sensor_code="'.$sensorCode.'"  ORDER BY posted_date_time DESC LIMIT 0,48 ) AS tab1 ORDER BY tab1.posted_date_time ASC'; 
            


        
    }
	

	
		$ExeLineGraph		= $this->ExecuteQuery($selLineGraph, "select");
		$objSmarty->assign('ExeLineGraph',$ExeLineGraph);
		$ExeLineGraphCount		= $this->ExecuteQuery($selLineGraph, "numrows");
		
	$objParmT='';
	$objParmDT='';
	
	foreach($ExeLineGraph as $key2=>$value2)
	{
		$objParmT .=$ExeLineGraph[$key2]["temperature_c"].",";
		$objParmDT .= "'".$ExeLineGraph[$key2]["month_data"]."',";
		
		$objParmH .=$ExeLineGraph[$key2]["humidity"].",";
		
	}
	

		$LineGraphData="[".rtrim($objParmT, ",")."]";
		$LineGraphDataDT="[".rtrim($objParmDT, ",")."]";
		$LineGraphDataH="[".rtrim($objParmH, ",")."]";
	//	echo $LineGraphData; exit;
		
		$objSmarty->assign('LineGraphData',$LineGraphData);
		$objSmarty->assign('LineGraphDataDT',$LineGraphDataDT);
		$objSmarty->assign('LineGraphDataH',$LineGraphDataH);
		
	}
	  /**********************GetMultiLineGraph Branch Functions starts***************************************************/
	  function ListGatewayStatus()  
{
		global $objSmarty,$config,$nowDate;
				
		if($_GET['companyId'] <> '')
		{
		$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		$branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		$branchId = $_SESSION['branch_id'];
		}
		 $SelQuery = 'SELECT * FROM arka_gateway_master WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND record_status="1"'; 

	
	//$SelQuery = 'SELECT energy_data_master_view.*,arka_sensor_master.*,arka_sensor_master.sensorName AS feeder_name,(arka_sensor_master.kw_max_value/5) AS KW_INT,TIMESTAMPDIFF(SECOND, recorded_date_time, NOW()) AS secs FROM energy_data_master_view,arka_sensor_master WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.sensorCode=energy_data_master_view.sensor_code  AND arka_sensor_master.feeder_type="Main Meter"  '; 
	       $GatewaySts= $this->ExecuteQuery($SelQuery, "select");//print_r($MeterList);
	       $objSmarty->assign('GatewaySts', $GatewaySts);	
	       
	
	       
	  	/*echo"<br><br> selQryS: "; echo */    $selQryS = 'SELECT * FROM `arka_sensor_master` WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.feeder_type="Sub Meter" GROUP BY sensorCode';
	       $selQryS		= $this->ExecuteQuery($selQryS, "select");
	    $objSmarty->assign('selQryS', $selQryS);
}
}
?>