<?php
class Platform extends MysqlFns
{
	

     /********* GetPlatformList Functions Starts ********************************/
	function GetPlatformList($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$sId = base64_decode($_GET['companyId']);
		$bId = base64_decode($_GET['branchId']);
	
		$SelQueryA = 'SELECT * FROM arka_platform_mapping LEFT JOIN arka_iot_platform ON arka_platform_mapping.segmentCode=arka_iot_platform.slNo where companyName="'.$sId.'" AND branch_id="'.$bId.'" AND arka_iot_platform.isActive="1" AND arka_iot_platform.status="1"';
		$PlatformList = $this->ExecuteQuery($SelQueryA, 'select');
		$objSmarty->assign('PlatformList', $PlatformList);
	
		$SelQueryB = 'SELECT DISTINCT slNo,segmentCode,segmentName FROM '.$tbl.'iot_platform where isActive="1" AND status="1" AND slNo not in(SELECT segmentCode FROM '.$tbl.'platform_mapping where companyName="'.$sId.'" AND branch_id="'.$bId.'" ) order by '.$tbl.'iot_platform.slNo';
		$APlatformList = $this->ExecuteQuery($SelQueryB, 'select');
		$objSmarty->assign('APlatformList', $APlatformList);
		return $APlatformList;
	}
     /********* GetPlatformList Functions Ends ********************************/
	/**********InsertPlatformSegment Functions Starts ***************************/
	function InsertPlatformSegment($objArray="")
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];

			$comId = base64_decode($_GET['companyId']);
			$bid = base64_decode($_GET['branchId']);

		    $SelCompQuerys	= 'SELECT companyCode FROM `arka_company_master` WHERE slNo="'.$comId.'" AND status=1';
			$SelCompData	= $this->ExecuteQuery($SelCompQuerys, 'select');
			$com_code = $SelCompData[0]['companyCode'];

			$SelBranchQuerys	= 'SELECT branch_id FROM `arka_branch_master` WHERE sl_no="'.$bid.'" AND record_status=1';
			$SelBranchData	= $this->ExecuteQuery($SelBranchQuerys, 'select');
            $branch_code = $SelBranchData[0]['branch_id'];

			$com_branch_code = $com_code."_".$branch_code; 

			


	if($this->ChkDuplicateCustomerID(trim(addslashes($objArray['company_id'])),trim(addslashes($objArray['branch_id']))))
	{
		$checkbox1 = $_POST['customCheckbox2'];
	for ($i=0; $i<sizeof($checkbox1);$i++) {  
     
		/**** For Get Selected IOT platform details and table format in Create page Start ****/ 

		$SelIotQuerys	= 'SELECT * FROM `arka_iot_platform` WHERE slNo="'.$checkbox1[$i].'" AND status=1';
		$SelIotData	= $this->ExecuteQuery($SelIotQuerys, 'select');

		$segment_code = $SelIotData[0]['segmentCode'];
		$segment_name = $SelIotData[0]['segmentName'];

		$SelMonthQuerys	= "SELECT DATE_FORMAT(CURDATE(), '%b') AS month_short_code";
		$SelMonthData	= $this->ExecuteQuery($SelMonthQuerys, 'select');
		$monthShortCode = $SelMonthData[0]['month_short_code'];

        $com_branch_segment_monthly_code = $com_branch_code."_".$segment_code."_cron_monthly";
		$com_branch_segment_daily_code = $com_branch_code."_".$segment_code."_cron_daily";
		$com_branch_segment_hourly_code = $com_branch_code."_".$segment_code."_cron_hourly_".$monthShortCode;

		$monthlyTable = $com_branch_segment_monthly_code;
		$dailyTable = $com_branch_segment_daily_code;
		$hourlyTable = $com_branch_segment_hourly_code;


		$platformFields = [

    "Temperature" => "
        min_temperature_c DOUBLE(25,2) NOT NULL,
        max_temperature_c DOUBLE(25,2) NOT NULL,
        avg_temperature_c DOUBLE(25,2) NOT NULL,
        min_temperature_f DOUBLE(25,2) NOT NULL,
        max_temperature_f DOUBLE(25,2) NOT NULL,
        avg_temperature_f DOUBLE(25,2) NOT NULL,
        min_humidity DOUBLE(25,2) NOT NULL,
        max_humidity DOUBLE(25,2) NOT NULL,
        avg_humidity DOUBLE(25,2) NOT NULL
    ",

    "Flow Meter" => "
        flow DOUBLE(25,2) NOT NULL,
        totalizer DOUBLE(25,2) NOT NULL
    ",

    "Water Level" => "
        water_level DOUBLE(25,2) NOT NULL,
        totalizer DOUBLE(25,2) NOT NULL
    ",

    "Bus Bar Temperature" => "
        set_point DOUBLE(25,2) NOT NULL,
        break_point DOUBLE(25,2) NOT NULL,
        sensor_temp DOUBLE(25,2) NOT NULL,
        sensor_bat DOUBLE(25,2) NOT NULL
    ",

    "Energy Meter" => "
       start_kwh DOUBLE(25,2) NOT NULL,
        end_kwh DOUBLE(25,2) NOT NULL,
		start_cum_date datetime NOT NULL,
		end_cum_date datetime NOT NULL,
        consuption_kwh DOUBLE(25,2) NOT NULL,
        consuption_cost DOUBLE(25,2) NOT NULL,
        dg_start_kwh DOUBLE(25,2) NOT NULL,
        dg_end_kwh DOUBLE(25,2) NOT NULL,
		dg_start_cum_date datetime NOT NULL,
		dg_end_cum_date datetime NOT NULL,
        dg_consuption_kwh DOUBLE(25,2) NOT NULL,
        dg_consuption_cost DOUBLE(25,2) NOT NULL
    ",

    "Solar Inverter" => "
        dc_power DOUBLE(25,2) NOT NULL,
        ac_power DOUBLE(25,2) NOT NULL,
        energy_today DOUBLE(25,2) NOT NULL,
        energy_total DOUBLE(25,2) NOT NULL
    ",

    "Electric Vehicle" => "
        charging_status INT(2) NOT NULL,
        voltage DOUBLE(25,2) NOT NULL,
        current DOUBLE(25,2) NOT NULL,
        power DOUBLE(25,2) NOT NULL,
        energy DOUBLE(25,2) NOT NULL
    ",

    "Power Factor" => "
        r_phase_pf DOUBLE(10,2) NOT NULL,
        y_phase_pf DOUBLE(10,2) NOT NULL,
        b_phase_pf DOUBLE(10,2) NOT NULL,
        avg_pf DOUBLE(10,2) NOT NULL
    ",

    "Battery Monitoring System" => "
        battery_voltage DOUBLE(25,2) NOT NULL,
        battery_current DOUBLE(25,2) NOT NULL,
        soc DOUBLE(10,2) NOT NULL,
        soh DOUBLE(10,2) NOT NULL,
        temperature DOUBLE(10,2) NOT NULL
    ",

    "Heinn IoT" => "
        parameter_1 DOUBLE(25,2) NOT NULL,
        parameter_2 DOUBLE(25,2) NOT NULL,
        parameter_3 DOUBLE(25,2) NOT NULL
    "
];

$tableField = isset($platformFields[$segment_name])
    ? $platformFields[$segment_name]
    : "
        start_kwh DOUBLE(25,2) NOT NULL,
        end_kwh DOUBLE(25,2) NOT NULL,
		start_cum_date datetime NOT NULL,
		end_cum_date datetime NOT NULL,
        consuption_kwh DOUBLE(25,2) NOT NULL,
        consuption_cost DOUBLE(25,2) NOT NULL
      ";


$this->createDynamicTable($monthlyTable, $tableField, "monthly");
$this->createDynamicTable($dailyTable, $tableField, "daily");
$this->createDynamicTable($hourlyTable, $tableField, "hourly");

		
/**** For Get Selected IOT platform details and table format in Create page End ****/ 

 
		//echo "am here working"; exit;


		 $InsQuery = 'INSERT INTO `'.$tbl.'platform_mapping`(
		`companyName`,
		`branch_id`,
		`segmentCode`,
		`status`,
		`isActive`) 
		VALUES(
		"'.$objArray['company_id'].'",
		"'.$objArray['branch_id'].'",
		"'.$checkbox1[$i].'",
		"1",
		"1")';
		$this->ExecuteQuery($InsQuery, 'insert');
	}  
		header('Location:branchList.php?companyId='.$_GET["companyId"].'&success_msg_for_insert');  
	}
	else
	{
		  $DelQuery = 'DELETE FROM `'.$tbl.'platform_mapping` WHERE `companyName` ="'.$objArray['company_id'].'" AND `branch_id` ="'.$objArray['branch_id'].'"';  
		$this->ExecuteQuery($DelQuery, 'delete');
		$checkbox1 = $_POST['customCheckbox2'];
	for ($i=0; $i<sizeof($checkbox1);$i++) {  

/**** For Get Selected IOT platform details and table format in Update page Start ****/ 

		$SelIotQuerys	= 'SELECT * FROM `arka_iot_platform` WHERE slNo="'.$checkbox1[$i].'" AND status=1';
		$SelIotData	= $this->ExecuteQuery($SelIotQuerys, 'select');

		$segment_code = $SelIotData[0]['segmentCode'];
		$segment_name = $SelIotData[0]['segmentName'];


		$SelMonthQuerys	= "SELECT DATE_FORMAT(CURDATE(), '%b') AS month_short_code, YEAR(CURDATE()) AS current_year";
		$SelMonthData	= $this->ExecuteQuery($SelMonthQuerys, 'select');
		$monthShortCode = $SelMonthData[0]['month_short_code'];
		$yearShortCode = $SelMonthData[0]['current_year'];

		
		$SelNextMonthQuerys	= "SELECT DATE_FORMAT(DATE_ADD(CURDATE(), INTERVAL 1 MONTH), '%b') AS month_short_code";
		$SelNextMonthData	= $this->ExecuteQuery($SelNextMonthQuerys, 'select');
		$nextmonthShortCode = $SelNextMonthData[0]['month_short_code'];

		$com_branch_segment_code = $com_branch_code."_".$segment_code;
        $com_branch_segment_monthly_code = $com_branch_code."_".$segment_code."_cron_monthly";
		$com_branch_segment_daily_code = $com_branch_code."_".$segment_code."_cron_daily";
		$com_branch_segment_hourly_code = $com_branch_code."_".$segment_code."_cron_hourly_".$monthShortCode."_".$yearShortCode;

		$monthlyTable = $com_branch_segment_monthly_code;
		$dailyTable = $com_branch_segment_daily_code;
		$hourlyTable = $com_branch_segment_hourly_code;


		$platformFields = [

    "Temperature" => "
        min_temperature_c DOUBLE(25,2) NOT NULL,
        max_temperature_c DOUBLE(25,2) NOT NULL,
        avg_temperature_c DOUBLE(25,2) NOT NULL,
        min_temperature_f DOUBLE(25,2) NOT NULL,
        max_temperature_f DOUBLE(25,2) NOT NULL,
        avg_temperature_f DOUBLE(25,2) NOT NULL,
        min_humidity DOUBLE(25,2) NOT NULL,
        max_humidity DOUBLE(25,2) NOT NULL,
        avg_humidity DOUBLE(25,2) NOT NULL
    ",

    "Flow Meter" => "
        flow DOUBLE(25,2) NOT NULL,
        totalizer DOUBLE(25,2) NOT NULL
    ",

    "Water Level" => "
        water_level DOUBLE(25,2) NOT NULL,
        totalizer DOUBLE(25,2) NOT NULL
    ",

    "Bus Bar Temperature" => "
        set_point DOUBLE(25,2) NOT NULL,
        break_point DOUBLE(25,2) NOT NULL,
        sensor_temp DOUBLE(25,2) NOT NULL,
        sensor_bat DOUBLE(25,2) NOT NULL
    ",

   "Energy Meter" => "
       start_kwh DOUBLE(25,2) NOT NULL,
        end_kwh DOUBLE(25,2) NOT NULL,
		start_cum_date datetime NOT NULL,
		end_cum_date datetime NOT NULL,
        consuption_kwh DOUBLE(25,2) NOT NULL,
        consuption_cost DOUBLE(25,2) NOT NULL,
        dg_start_kwh DOUBLE(25,2) NOT NULL,
        dg_end_kwh DOUBLE(25,2) NOT NULL,
		dg_start_cum_date datetime NOT NULL,
		dg_end_cum_date datetime NOT NULL,
        dg_consuption_kwh DOUBLE(25,2) NOT NULL,
        dg_consuption_cost DOUBLE(25,2) NOT NULL
    ",

    "Solar Inverter" => "
        dc_power DOUBLE(25,2) NOT NULL,
        ac_power DOUBLE(25,2) NOT NULL,
        energy_today DOUBLE(25,2) NOT NULL,
        energy_total DOUBLE(25,2) NOT NULL
    ",

    "Electric Vehicle" => "
        charging_status INT(2) NOT NULL,
        voltage DOUBLE(25,2) NOT NULL,
        current DOUBLE(25,2) NOT NULL,
        power DOUBLE(25,2) NOT NULL,
        energy DOUBLE(25,2) NOT NULL
    ",

    "Power Factor" => "
        r_phase_pf DOUBLE(10,2) NOT NULL,
        y_phase_pf DOUBLE(10,2) NOT NULL,
        b_phase_pf DOUBLE(10,2) NOT NULL,
        avg_pf DOUBLE(10,2) NOT NULL
    ",

    "Battery Monitoring System" => "
        battery_voltage DOUBLE(25,2) NOT NULL,
        battery_current DOUBLE(25,2) NOT NULL,
        soc DOUBLE(10,2) NOT NULL,
        soh DOUBLE(10,2) NOT NULL,
        temperature DOUBLE(10,2) NOT NULL
    ",

    "Heinn IoT" => "
        parameter_1 DOUBLE(25,2) NOT NULL,
        parameter_2 DOUBLE(25,2) NOT NULL,
        parameter_3 DOUBLE(25,2) NOT NULL
    "
];

$tableField = isset($platformFields[$segment_name])
    ? $platformFields[$segment_name]
    : "
        start_kwh DOUBLE(25,2) NOT NULL,
        end_kwh DOUBLE(25,2) NOT NULL,
		start_cum_date datetime NOT NULL,
		end_cum_date datetime NOT NULL,
        consuption_kwh DOUBLE(25,2) NOT NULL,
        consuption_cost DOUBLE(25,2) NOT NULL
      ";


$this->createDynamicTable($monthlyTable, $tableField, "monthly");
$this->createDynamicTable($dailyTable, $tableField, "daily");
$this->createDynamicTable($hourlyTable, $tableField, "hourly");

/**** For Get Selected IOT platform details and table format in Create page End ****/ 

/**** For Update Cron Hourly Table Month Starts  ****/

		$SelHourlyTableQuerys = "SELECT *,DATE_FORMAT(CURDATE(), '%b') AS month_short_code,YEAR(CURDATE()) AS current_year FROM cron_table_details WHERE cron_table_name = CONCAT('".$com_branch_segment_code."_cron_hourly_',DATE_FORMAT(CURDATE(), '%b'),'_',YEAR(CURDATE()))";
		$SelHourlyTableData	= $this->ExecuteQuery($SelHourlyTableQuerys, 'select');
		$SelHourlyTableDataCount	= $this->ExecuteQuery($SelHourlyTableQuerys, 'numrows');
  
		if($SelHourlyTableDataCount == 0){

		$SelCronHourlyQuerys = "SELECT * FROM cron_table_details WHERE cron_table_name LIKE '".$com_branch_segment_code."_cron_hourly_%' AND short_by='hourly'";
		$SelCronHourlyData	= $this->ExecuteQuery($SelCronHourlyQuerys, 'select');
	    $oldHourTable = $SelCronHourlyData[0]["cron_table_name"];
		$oldHourTableId = $SelCronHourlyData[0]["slNo"];
		$newHourTable = $com_branch_segment_hourly_code;

		$UpdateQuery = "update cron_table_details  set `cron_table_name` = '".$newHourTable."' WHERE `slNo` ='".$oldHourTableId."'";
		$this->ExecuteQuery($UpdateQuery, 'update');

		}

/**** For Update Cron Hourly Table Month Ends  ****/

//echo "am here update working"; exit;

		$InsQuery = 'INSERT INTO `'.$tbl.'platform_mapping`(
		`companyName`,
		`branch_id`,
		`segmentCode`,
		`status`,
		`isActive`) 
		VALUES(
		"'.$objArray['company_id'].'",
		"'.$objArray['branch_id'].'",
		"'.$checkbox1[$i].'",
		"1",
		"1")';
		$this->ExecuteQuery($InsQuery, 'insert');
	}  
		header('Location:branchList.php?companyId='.$_GET["companyId"].'&success_msg_for_update');  
	}
	}
     /**********InsertPlatformSegment Functions Ends ***************************/

	 /**** For Create Cron Table Start ****/ 

	 function createDynamicTable($tableName, $tableField,$shortby)
    {        
		$comId = base64_decode($_GET['companyId']);
		$braId = base64_decode($_GET['branchId']);

		// Add hour_data only for hourly table
    $hourField = '';
    if ($shortby === 'hourly') {
        $hourField = "hour_data VARCHAR(55) NOT NULL,";
    }

   // Add avg_data only for monthly table
    $avgField = '';
    if ($shortby === 'monthly') {
        $avgField = "avg_data DOUBLE(25,2) NOT NULL,
		              last_six_month_avg_data DOUBLE(25,2) NOT NULL,";
    }

		
        $InsQuery = "CREATE TABLE IF NOT EXISTS `$tableName` (
            slNo INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            company_id INT(6) NOT NULL,
            branch_id INT(6) NOT NULL,
            location_code VARCHAR(155) NOT NULL,
            gateway_code VARCHAR(155) NOT NULL,
            sensor_code VARCHAR(155) NOT NULL,
            sensor_name VARCHAR(155) NOT NULL,
            sensor_model VARCHAR(155) NOT NULL,
            feeder_type VARCHAR(155) NOT NULL,
            unit_rate FLOAT(11,2) NOT NULL,
            $tableField,
			$hourField
			$avgField
            linux_date_time VARCHAR(55) NOT NULL,
            teltonika_date_time VARCHAR(55) NOT NULL,
            recorded_date DATETIME,
            posted_date_time DATETIME,
            M_TIMESTAMP TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            is_active INT(6) DEFAULT 1 NOT NULL,
            status INT(6) DEFAULT 1 NOT NULL
        ) ENGINE=InnoDB"; 
		$this->ExecuteQuery($InsQuery, 'insert');
      if($tableName != ''){
		
			$InsQuery = 'INSERT IGNORE INTO cron_table_details(
		`company_id`,
		`branch_id`,
		`short_by`,
		`cron_table_name`,
		`is_active`,
		`status`) 
		VALUES(
		"'.$comId.'",
		"'.$braId.'",
		"'.$shortby.'",
		"'.$tableName.'",
		"1",
		"1")';
		$this->ExecuteQuery($InsQuery, 'insert');
    }		
        
    }

	/**** For Create Cron Table End ****/ 

	 /******************* ChkDuplicateCustomerID Functions Starts ****************/
	function ChkDuplicateCustomerID($comp_id,$bran_id)
	{
		global $objSmarty,$config,$_POST;
		$tbl = $config['DBPrefix'];
		$SelQuery	= 'SELECT * FROM `'.$tbl.'platform_mapping` WHERE `companyName` = "'.$comp_id.'" AND `branch_id` = "'.$bran_id.'" '; 
		$UGDetail = $this->ExecuteQuery($SelQuery, 'select');
		if(!empty($UGDetail) && is_array($UGDetail))
			return false;
		else
			return true;
	}
     /********* ChkDuplicateCustomerID Functions Ends *********************/
     /********* ListPlatform Functions Starts ********************************/
	function ListPlatform($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
		$SelQuery = 'SELECT * FROM  `'.$tbl.'iot_platform` WHERE status="1"';  
		$ListView = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListView', $ListView);
		return $ListView;
	}
      /********* ListPlatform Functions Ends********************************/
	  /********* DeletePlatform Functions Starts********************************/
	function DeletePlatform($CatIdent)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$sId = base64_decode($_GET['slNo']);
		
		$DelQuery = 'update `'.$tbl.'iot_platform`  set `isActive` = "0" WHERE `slNo` ="'.$sId.'"';
		$this->ExecuteQuery($DelQuery, 'update');
		header('Location:' .$_SERVER['PHP_SELF'].'?succs_msg_for_del');  
	}
    /********* DeletePlatform Functions Ends********************************/
	 /********* InsertPlatform Functions Starts********************************/
	function InsertPlatform($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if(!$objArray['segmentCode']){
		$objSmarty->assign('ErrorMessage', 'Segment Code should not be blank');
		return false;
	}elseif(!$objArray['segmentName']){
		$objSmarty->assign('ErrorMessage', 'Segment Name should not be blank');
		return false;
	}
	if($objArray['segmentCode'] && $objArray['segmentName'])
	{
		$InsQuery = 'INSERT INTO `'.$tbl.'iot_platform`
		(`segmentCode`,`segmentName`,`isActive`,`createdBy`,`status`)
		VALUES(
		"'.trim(addslashes($objArray['segmentCode'])).'","'.trim(addslashes($objArray['segmentName'])).'","'.trim(addslashes($objArray['checkVal'])).'","'.trim(addslashes($objArray['created_by'])).'","1")';  
		$this->ExecuteQuery($InsQuery, 'insert');
		header('Location:PlatformList.php?success_msg_for_insert');
	}
	}	
     /********* InsertPlatform Functions Ends********************************/
	 /********* ListEditView Functions Starts********************************/
	function ListEditView($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$sId = base64_decode($_GET['slNo']);
		$SelQuery = 'SELECT * FROM  `'.$tbl.'iot_platform` WHERE slNo="'.$sId.'" AND status="1"';  
		$ListEditView = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListEditView', $ListEditView);
		return $ListEditView;
	}
     /********* ListEditView Functions Ends********************************/
	 /********* EditPlatform Functions Starts********************************/
	function EditPlatform($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
	if(!$objArray['segmentCode']){
		$objSmarty->assign('ErrorMessage', 'Segment Code Id should not be blank');
		return false;
	}elseif(!$objArray['segmentName']){
		$objSmarty->assign('ErrorMessage', 'Segment Name should not be blank');
		return false;
	}
	
	if($objArray['segmentCode'] && $objArray['segmentName'])
	{
		$UpdateQuery = 'UPDATE 
		`'.$tbl.'iot_platform` 
		SET 
		`segmentCode`="'.trim(addslashes($objArray['segmentCode'])).'",
		`segmentName`="'.trim(addslashes($objArray['segmentName'])).'",
		`isActive`="'.trim(addslashes($objArray['checkVal'])).'",
		`status`="1",
		`createdBy`="'.trim(addslashes($objArray['created_by'])).'"
		WHERE 
		slNo="'.$objArray['platId'].'"';
		$this->ExecuteQuery($UpdateQuery, 'update');
		header('Location:PlatformList.php?success_msg_for_update');
	}
	}
     /********* EditPlatform Functions Ends********************************/



}
?>