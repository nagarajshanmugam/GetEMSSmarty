<?php
class LocationMaster extends MysqlFns
{ 
     /********* LocationMaster Constructor Starts ********************************/
	function LocationMaster()
	{
		$this->LDDisplayPath= $config['SiteGlobalPath']."class.LocationMaster.php";
		global $config;
		global $objSmarty;
		global $nowDate;
		$this->Limit = 20;
		$ConLink1 = mysql_connect($config['DBHost'],$config['DBUser'],$config['DBPassword']) or die("Database Connection Failed<br>". mysql_error());
		mysql_select_db($config['DBName'], $ConLink1);
		if($config['DBUser'] != 'root')
		{
			$nowDate= 'DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE)';
		}
		else{
			$nowDate= 'NOW()';
		}
	}
      /********* LocationMaster Constructor Ends ********************************/
     /********* ListSensor Functions Starts ********************************/
	function ListSensor($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> '')
		{
			$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
			$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
			$branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
			$branchId = $_SESSION['branch_id'];
		}
		$gateId = base64_decode($_GET['gatewayId']);
		if(isset($_GET['gatewayId']))
		{
			$SelQuery = 'SELECT `'.$tbl.'sensor_master`.*,`'.$tbl.'company_master`.companyName,sensor_model_master.json_format AS json_data_format,sensor_model_master.api_url AS api_url,sensor_model_master.model_name FROM `'.$tbl.'sensor_master`,`'.$tbl.'company_master`,sensor_model_master WHERE `'.$tbl.'sensor_master`.company_id="'.$comId.'" AND `'.$tbl.'sensor_master`.branch_id="'.$branchId.'" AND `'.$tbl.'sensor_master`.gateway_id="'.$gateId.'" AND `'.$tbl.'sensor_master`.status="1" AND `arka_company_master`.slNo=`arka_sensor_master`.company_id AND `'.$tbl.'sensor_master`.sensorModel=sensor_model_master.model_id'; 
			$ListSensorView = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListSensorView', $ListSensorView);
			return $ListSensorView;
		}
		else
		{
			 $SelQuery = 'SELECT `'.$tbl.'sensor_master`.*,`'.$tbl.'company_master`.companyName,sensor_model_master.json_format AS json_data_format,sensor_model_master.api_url AS api_url,sensor_model_master.model_name FROM `'.$tbl.'sensor_master`,`'.$tbl.'company_master`,sensor_model_master WHERE `'.$tbl.'sensor_master`.company_id="'.$comId.'" AND `'.$tbl.'sensor_master`.branch_id="'.$branchId.'" AND `'.$tbl.'sensor_master`.status="1" AND `arka_company_master`.slNo=`arka_sensor_master`.company_id AND `'.$tbl.'sensor_master`.sensorModel=sensor_model_master.model_id';  
			$ListSensorView = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListSensorView', $ListSensorView);
			return $ListSensorView;
		}
	}
      /********* ListSensor Functions Ends ********************************/
	  /********* ListGateway Functions Starts ********************************/
	function ListGateway($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> '')
		{
			$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
			$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
			$branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
			$branchId = $_SESSION['branch_id'];
		}
			 $SelQuery = 'SELECT `'.$tbl.'gateway_master`.*,(`'.$tbl.'gateway_master`.sl_no) AS gateway_sl_no,model_master.model_name FROM  `'.$tbl.'gateway_master`,model_master WHERE `'.$tbl.'gateway_master`.company_id="'.$comId.'" AND `'.$tbl.'gateway_master`.branch_id="'.$branchId.'" AND `'.$tbl.'gateway_master`.record_status="1" AND `'.$tbl.'gateway_master`.model=model_master.model_code';  
			$ListGatewayView = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListGatewayView', $ListGatewayView);
			return $ListGatewayView;
	}
     /********* ListGateway Functions Ends ********************************/
	 /********* ListBranch Functions Starts ********************************/
	function ListBranch($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> '')
		{
			$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
			$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
			$branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
			$branchId = $_SESSION['branch_id'];
		}
			$SelQuery = 'SELECT * FROM  `'.$tbl.'branch_master` WHERE company_id="'.$comId.'" AND record_status="1"';  
			$ListBranchView = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListBranchView', $ListBranchView);

			 $SelQueryGet = 'SELECT * FROM  `'.$tbl.'branch_master` WHERE company_id="'.$comId.'" AND sl_no="'.$branchId.'" AND record_status="1"';  
			$ListBranchGet = $this->ExecuteQuery($SelQueryGet, 'select');
			$objSmarty->assign('ListBranchGet', $ListBranchGet);
		
	}
    /********* ListBranch Functions End ********************************/
	 /********* List Location Functions Starts ********************************/
	function ListLocation()
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$bId = base64_decode($_GET['branchId']);
		$comId = base64_decode($_GET['companyId']);
		$SelQuery = 'SELECT location_master.*,arka_sensor_master.*,arka_gateway_master.gateway_id FROM  `location_master`,arka_sensor_master,arka_gateway_master WHERE arka_sensor_master.slNo=location_master.sensor_id AND arka_sensor_master.status="1" AND arka_gateway_master.sl_no=location_master.iot_id AND arka_gateway_master.record_status="1" AND location_master.branch_id="'.$bId.'" AND location_master.company_id="'.$comId.'" AND location_master.status="1"';  
		$GetLocation = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('GetLocation', $GetLocation);//print_r($GetLocation);exit;
		return $GetLocation;
	}

      /********* List Location Functions Ends ********************************/
	   /********* List Location Details Functions Starts ********************************/
	function LocationMasterDetails()
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$lId = base64_decode($_GET['locId']);
		$bId = base64_decode($_GET['branchId']);
		$comId = base64_decode($_GET['companyId']);
		 $SelQuery = 'SELECT location_details.*,location_master.location_code,location_master.location_name,arka_sensor_master.sensorName,arka_gateway_master.gateway_id  FROM `location_details`,location_master,arka_sensor_master,arka_gateway_master  WHERE location_details.location_master_id =location_master.location_master_id AND location_details.location_master_id = "'.$lId.'" AND location_details.sensor_id=arka_sensor_master.slNo AND arka_sensor_master.status="1" AND location_details.iot_id=arka_gateway_master.sl_no AND location_master.company_id="'.$comId.'" AND location_master.branch_id="'.$bId.'" AND arka_gateway_master.record_status="1" AND location_master.status="1" AND location_details.status="1" ORDER BY location_details.location_details_id DESC';
		$GetLocationData = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('GetLocationData', $GetLocationData);//print_r($GetLocation);exit;
		return $GetLocationData;
	}

      /********* List Location Details Functions Ends ********************************/
	  /********* ListEditView Functions Starts ********************************/
	function ListEditView($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$lid = base64_decode($_GET['locId']);
		$comId = base64_decode($_GET['companyId']);
		$bId = base64_decode($_GET['branchId']);
	
		$SelQuery = 'SELECT location_master.*,arka_sensor_master.sensorName,arka_gateway_master.model FROM  `location_master`,arka_sensor_master,arka_gateway_master WHERE location_master.location_master_id="'.$lid.'" AND arka_sensor_master.slNo=location_master.sensor_id AND arka_sensor_master.status="1" AND arka_gateway_master.sl_no=location_master.iot_id AND arka_gateway_master.record_status="1" AND location_master.branch_id="'.$bId.'" AND location_master.company_id="'.$comId.'" AND location_master.status="1"';      
		$ListEditView = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListEditView', $ListEditView);
		
		  $SelQueryP = 'SELECT (`'.$tbl.'sensor_master`.sensorName) AS parentMeter FROM  `'.$tbl.'sensor_master` WHERE `'.$tbl.'sensor_master`.slNo="'.$ListEditView[0]["parent_id"].'"'; 
		$SelQueryPExe = $this->ExecuteQuery($SelQueryP, 'select');
		$objSmarty->assign('SelQueryPExe', $SelQueryPExe);
		return $ListEditView;
	}
     /********* ListEditView Functions Ends ********************************/
	/********* ListCompany Functions Starts ********************************/
	function ListCompany($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$SelQuery = 'SELECT * FROM  `'.$tbl.'company_master` WHERE isActive="1"';  
		$ListCompanyView = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListCompanyView', $ListCompanyView);
		return $ListCompanyView;
	}
     /********* ListCompany Functions Ends ********************************/
	 /********* ListSensorModel Functions Starts *************************/
	function ListSensorModel()
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		 $SelSesn = 'SELECT sensor_model_master.*,arka_iot_platform.segmentName AS platformName FROM  `sensor_model_master`,arka_iot_platform WHERE sensor_model_master.platform_id=arka_iot_platform.slNo AND sensor_model_master.status="1" ORDER BY sensor_model_master.model_name ';  
		$GetModel = $this->ExecuteQuery($SelSesn, 'select');
		$objSmarty->assign('GetModel', $GetModel);
		return $GetModel;
	}
	/********* ListSensorModel Functions Ends *******************************/
	/********* ListSensorModel Functions Starts *************************/
	function ListSensorModelPlatform()
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
	    $SelSesnPlat = 'SELECT arka_sensor_master.* FROM  `arka_sensor_master` WHERE arka_sensor_master.slNo="'.base64_decode($_GET["sl_no"]).'"'; 
		$GetModelPlat = $this->ExecuteQuery($SelSesnPlat, 'select');
		$objSmarty->assign('GetModelPlat', $GetModelPlat);
		return $GetModelPlat;
	}
	/********* ListSensorModel Functions Ends *******************************/
	/********* AjaxListSensorModel Functions Starts *************************/
	function AjaxListSensorModel($platform)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		 $SelSesn = 'SELECT sensor_model_master.*,(arka_iot_platform.segmentName) AS platformName,(arka_iot_platform.slNo) AS platformId FROM  `sensor_model_master`,arka_iot_platform WHERE arka_iot_platform.slNo="'.$platform.'" AND sensor_model_master.platform_id=arka_iot_platform.slNo AND sensor_model_master.status="1" ORDER BY sensor_model_master.model_name ';  
		$GetModel = $this->ExecuteQuery($SelSesn, 'select');
		echo json_encode($GetModel);
		
	//	$objSmarty->assign('GetModel', $GetModel);
	//	return $GetModel;
	}
    /********* AjaxListSensorModel Functions Ends ********************************/
	/********* ListPlatform Functions Starts ********************************/
	function ListPlatform()
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> '')
		{
			$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
			$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
			$branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
			$branchId = $_SESSION['branch_id'];
		}
			 $SelQuery = 'SELECT arka_platform_mapping.*,arka_iot_platform.segmentName,(arka_iot_platform.slNo) AS platformId FROM `arka_platform_mapping`,arka_iot_platform WHERE arka_iot_platform.status="1" AND arka_iot_platform.isActive="1" AND arka_platform_mapping.companyName="'.$comId.'" AND arka_platform_mapping.branch_id="'.$branchId.'" AND arka_platform_mapping.segmentCode =arka_iot_platform.slNo ';  
			$ListPlatform = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListPlatform', $ListPlatform);
			return $ListPlatform;
	}
	function Platform()
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
	
			$SelQuery = 'SELECT * FROM arka_iot_platform WHERE isActive=1';  
			$Platform = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('Platform', $Platform);
			return $Platform;
	}
    /********* ListPlatform Functions Ends ********************************/
	/********* Ajax Location Sensor Check Functions Starts *************************/
	function AjaxLocationSensorCheck($sensorId,$locMasId)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		  $SelAjaxOtherLocationDevice	= 'SELECT location_master_id,location_code FROM `location_master` WHERE location_master_id!="'.$locMasId.'" AND sensor_id="'.$sensorId.'" AND status=1'; 
		 $GetSensorData = $this->ExecuteQuery($SelAjaxOtherLocationDevice, 'select');
            
			//$other_location_master_id = $SelOtherLocationData[0]["location_master_id"];  
		
		echo json_encode($GetSensorData);
		
	//	$objSmarty->assign('GetModel', $GetModel);
	//	return $GetModel;
	}
    /********* Ajax Location Sensor Check Functions Ends ********************************/
	/********* InsertLocation Functions Starts ********************************/
	function InsertLocationMaster($objArray)
	{ 
			global $objSmarty,$config,$nowDate;
			$tbl = $config['DBPrefix'];
			$comId = base64_decode($_GET['companyId']);
			$bid = base64_decode($_GET['branchId']);
			$gid = base64_decode($_GET['gatewayId']);
			$sid = base64_decode($_GET['sl_no']);
			
		/*if(!$objArray['locationCode']){
			$objSmarty->assign('ErrorMessage', 'Location Code should not be blank');
			return false;
		}else */
		if(!$objArray['locationName']){
			$objSmarty->assign('ErrorMessage', 'Location name should not be blank');
			return false;
		}
		elseif(!$objArray['sensor']){
			$objSmarty->assign('ErrorMessage', 'Sensor should not be blank');
			return false;
		}
		elseif(!$objArray['iotDevice']){
			$objSmarty->assign('ErrorMessage', 'IOT Device should not be blank');
			return false;
		}
		elseif(!$objArray['branch']){
			$objSmarty->assign('ErrorMessage', 'Branch should not be blank');
			return false;
		}
		if($objArray['locationName'])
		{	 

			$sensorId = $objArray['sensor'];
			$iotId = $objArray['iotDevice'];

			$SelCompQuerys	= 'SELECT companyCode FROM `arka_company_master` WHERE slNo="'.$comId.'" AND status=1';
			$SelCompData	= $this->ExecuteQuery($SelCompQuerys, 'select');
			$com_code = $SelCompData[0]['companyCode'];

			$SelBranchQuerys	= 'SELECT branch_id FROM `arka_branch_master` WHERE sl_no="'.$bid.'" AND record_status=1';
			$SelBranchData	= $this->ExecuteQuery($SelBranchQuerys, 'select');
            $branch_code = $SelBranchData[0]['branch_id'];

			$SelIotQuerys	= 'SELECT gateway_id FROM `arka_gateway_master` WHERE sl_no="'.$iotId.'" AND record_status=1';
			$SelIotData	= $this->ExecuteQuery($SelIotQuerys, 'select');
            $iot_code = $SelIotData[0]['gateway_id'];


			$SelSensorQuerys	= 'SELECT sensorCode FROM `arka_sensor_master` WHERE slNo="'.$sensorId.'" AND status=1';
			$SelSensorData	= $this->ExecuteQuery($SelSensorQuerys, 'select');
            $sensor_code = $SelSensorData[0]['sensorCode'];


			$com_branch_code = $com_code."_".$branch_code."_"; 
			
            
			    $SelLocationSenIotQuerys	= 'SELECT * FROM `location_details` WHERE company_id="'.$comId.'" AND branch_id="'.$bid.'" AND sensor_id="'.$objArray['sensor'].'" AND is_active=1 AND status=1 AND (end_date_time="" OR `end_date_time` = "0000-00-00 00:00:00")';  
			$SelLocationSenIotData	= $this->ExecuteQuery($SelLocationSenIotQuerys, 'select');
			$SelLocationSenIotCount	= $this->ExecuteQuery($SelLocationSenIotQuerys, 'numrows');

           if($SelLocationSenIotCount == 0){
			//echo "am in if";exit;
		  
				$SelLocationMasQuerys	= 'SELECT location_code FROM `location_master` WHERE location_code LIKE "%'.$com_branch_code.'%" AND status=1'; 
				$SelLocationMasData	= $this->ExecuteQuery($SelLocationMasQuerys, 'select');
				$SelLocationMasCount	= $this->ExecuteQuery($SelLocationMasQuerys, 'numrows');

				if($SelLocationMasCount > 0 ){

					//$SelLocationDetQuerys	= 'SELECT count(location_details_id) AS last FROM location_details WHERE  location_details.company_id="'.$comId.'" AND location_details.branch_id="'.$bid.'" AND sensor_id ="'.$sensorId.'" AND iot_id="'.$iotId.'" AND location_details.status=1';
					 $SelLocationDetQuerys	= 'SELECT location_code AS last FROM location_master WHERE  location_master.company_id="'.$comId.'" AND location_master.branch_id="'.$bid.'" AND location_master.status=1 ORDER BY location_master_id DESC LIMIT 0,1';
					$SelLocstionDetData	= $this->ExecuteQuery($SelLocationDetQuerys, 'select');

				//$SelLocstionDetData[0]['location_code'] = stripslashes($SensDetail[0]['last']);
				$split = explode("_",$SelLocstionDetData[0]['last']);
				$lastval = end($split);
				$autoInc = $lastval + 1;
				$split2 = explode("_".$lastval,$SelLocstionDetData[0]['last']);
				$locationCode = $split2[0]."_".$autoInc;
				}else{
					$locationCode = $com_branch_code."1";

				}


				//echo "Location Code ".$locationCode; exit;


				 $InsMasQuery = 'INSERT INTO `location_master`(`company_id`,`branch_id`,`location_name`,`location_code`,`sensor_id`,`iot_id`,`is_active`,`status`) VALUES("'.$comId.'","'.$bid.'","'.trim(addslashes($objArray['locationName'])).'","'.$locationCode.'","'.trim(addslashes($objArray['sensor'])).'","'.trim(addslashes($objArray['iotDevice'])).'","'.trim(addslashes($objArray['checkVal'])).'","1")';  
				$this->ExecuteQuery($InsMasQuery, 'insert');

				$locationMasterLastQuery = "SELECT * FROM location_master WHERE status='1' ORDER BY location_master_id DESC LIMIT 0,1";
				$locationMasterLastData=$this->ExecuteQuery($locationMasterLastQuery, 'select');
				$locMasId = $locationMasterLastData[0]['location_master_id'];
				$locMasSensorId = $locationMasterLastData[0]['sensor_id'];
				$locMasIotId = $locationMasterLastData[0]['iot_id'];
				$locMasTime = $locationMasterLastData[0]['timestamp'];

				 $InsDetQuery = 'INSERT INTO `location_details`(`location_master_id`,`company_id`,`branch_id`,`sensor_id`,`iot_id`,`start_date_time`,`is_active`,`status`) VALUES("'.$locMasId.'","'.$comId.'","'.$bid.'","'.$locMasSensorId.'","'.$locMasIotId.'","'.$locMasTime.'","'.trim(addslashes($objArray['checkVal'])).'","1")'; 
				$this->ExecuteQuery($InsDetQuery, 'insert');


				/************* Create Specific Sensor Table if its's not present in Database Starts*********************/

			// Fetch the Specific Field Data from the Existing Table
			//$SelSensorQuerys	= 'SELECT sensorCode FROM `arka_sensor_master` WHERE slNo="'.$sensorId.'" AND status=1';
			$specificSensorSql = "SELECT sensorCode,sensorModel FROM arka_sensor_master WHERE slNo='".$sensorId."' AND status='1'";
            $specificSensorData=$this->ExecuteQuery($specificSensorSql, 'select');
			$specificSensorDataCount=$this->ExecuteQuery($specificSensorSql, 'numrows');
			$modelId = $specificSensorData[0]['sensorModel'];
			//$data = array();
			$senModelQuery = "SELECT sl_no FROM sensor_model_master WHERE model_id='".$modelId."' AND status='1'";
            $senModelQueryData=$this->ExecuteQuery($senModelQuery, 'select');
			$senModelId = $senModelQueryData[0]['sl_no'];

			$senModelParamQuery = "SELECT * FROM sensor_model_parameter_master WHERE sensor_model_id='".$senModelId."' AND status='1' ORDER BY priority";
            $senModelParamQueryData=$this->ExecuteQuery($senModelParamQuery, 'select');

			foreach($senModelParamQueryData as $key=>$value)
				{
					$param = $senModelParamQueryData[$key]["parameter_name"]; //R_VOLTAGE
					$datat = $senModelParamQueryData[$key]["data_type"]; //VARACHAR
					$datal = $senModelParamQueryData[$key]["data_length"]; //255
					//Output: R_VOLTAGE VARACHAR(255),
					if($datal == ''){
                    
					$tableField .=$param." ".$datat.",";
					
					}else{
						
					$tableField .=$param." ".$datat."(".$datal."),";	
					
					}
					

				}

			//echo  $tableField; exit;
			$tableField = trim($tableField,",");
			//echo $tableField; exit;
			if($specificSensorDataCount > 0 ){

							foreach($specificSensorData as $key=>$value)
				{
							$specificSensorCode = str_replace("-","_",$specificSensorData[$key]["sensorCode"]);

							$new_table_name = $locationCode."_".$specificSensorCode;

				            //$data[] = $specificSensorData['sensorCode'];

						// Create a New Table
						$new_table = $new_table_name;
						 $insertNewTableSql = "CREATE TABLE IF NOT EXISTS $new_table (
						slNo INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
						company_id int(6) NOT NULL,
						branch_id int(6) NOT NULL,
						location_code varchar(155) NOT NULL,
						gateway_code varchar(155) NOT NULL,
						sensor_code varchar(155) NOT NULL,
						sensor_name varchar(155) NOT NULL,
						sensor_model varchar(155) NOT NULL,
						feeder_type varchar(155) NOT NULL,
						unit_rate float(11,2) NOT NULL,
						$tableField,
						raw_data LONGTEXT,
						linux_date_time varchar(55) NOT NULL,
						teltonika_date_time varchar(55) NOT NULL,
						recorded_date DATE NOT NULL,
						posted_date_time DATETIME,
						M_TIMESTAMP TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
						is_active int(6) DEFAULT 1 NOT NULL,
						status int(6) DEFAULT 1 NOT NULL
						)";
						$this->ExecuteQuery($insertNewTableSql, 'insert');

							// Fetch current master data
 $getLastMasterSql = "SELECT * FROM location_master WHERE is_active='1' AND status='1' ORDER BY location_master_id DESC LIMIT 0,1"; 
 $lastLocationMaster = $this->ExecuteQuery($getLastMasterSql, 'select');

 $locationId = $lastLocationMaster[0]['location_master_id'];
 

 // 🔹 Update Other location_master with new sensor and iot 
        $updateLocationMaster = "UPDATE location_master 
                         SET table_name = '".$new_table."'
                         WHERE location_master_id = '".$locationId."'";
        $this->ExecuteQuery($updateLocationMaster, 'update');



				// echo $Insert= "INSERT INTO $new_table (company_id,branch_id,gateway_id,sensor_code,sensor_name,sensor_model,feeder_type,unit_rate,created_date) VALUES ('".$comId."','".$bid."','".trim(addslashes($objArray['gateway_id']))."','".$s_id."','".trim(addslashes($objArray['sensorName']))."','".trim(addslashes($objArray['model']))."','".$feederType."','".$unit_rate."','".trim(addslashes($objArray['timestamp']))."')";  
				// $this->ExecuteQuery($Insert, 'insert');


			}

			//echo $new_table."created successfully";
			

		}



		  /************* Create Specific Sensor Table if its's not present in Database Ends*********************/



		 }else{
                
			   //echo "am in else";exit;
				$objSmarty->assign('ErrorMessage', 'This Sensor already active in this branch');
				return false;

			}

		header('Location:locationList.php?branchId='.$_GET["branchId"].'&companyId='.$_GET["companyId"].'&success_msg_for_insert');
			
		}
	}
	      /********* InsertLocation Functions Ends ********************************/
		  /********* UpdateLocation Functions Starts ********************************/
	function EditLocationMaster($objArray)
	{ 
			global $objSmarty,$config,$nowDate;
			$tbl = $config['DBPrefix'];
			$comId = base64_decode($_GET['companyId']);
			$bid = base64_decode($_GET['branchId']);
			$lid = base64_decode($_GET['locId']);
			
			
		if(!$objArray['locationCode']){
			$objSmarty->assign('ErrorMessage', 'Location Code should not be blank');
			return false;
		}elseif(!$objArray['locationName']){
			$objSmarty->assign('ErrorMessage', 'Location name should not be blank');
			return false;
		}
		elseif(!$objArray['sensor']){
			$objSmarty->assign('ErrorMessage', 'Sensor should not be blank');
			return false;
		}
		elseif(!$objArray['iotDevice']){
			$objSmarty->assign('ErrorMessage', 'IOT Device should not be blank');
			return false;
		}
		elseif(!$objArray['branch']){
			$objSmarty->assign('ErrorMessage', 'Branch should not be blank');
			return false;
		}
		if($objArray['locationName'])
		{	 

 
		$location_master_id = base64_decode($_GET['locId']);
		$location_code = trim(addslashes($objArray['locationCode']));
		$location_name = trim(addslashes($objArray['locationName']));
		$company_id = base64_decode($_GET['companyId']);
		$branch_id = base64_decode($_GET['branchId']);
		$new_sensor_id = trim(addslashes($objArray['sensor']));
		$new_iot_id = trim(addslashes($objArray['iotDevice']));
		$new_is_active = trim(addslashes($objArray['checkVal']));
		$currentDateTime = date("Y-m-d H:i:s");



		// Fetch current master data
 $getMasterSql = "SELECT * FROM location_master WHERE location_master_id = '".$location_master_id."' AND status='1'"; 
$existingMaster = $this->ExecuteQuery($getMasterSql, 'select');

if (!empty($existingMaster)) {

    $old_sensor_id = $existingMaster[0]['sensor_id'];
    $old_iot_id = $existingMaster[0]['iot_id'];
    $old_loc_code = $existingMaster[0]['location_code'];
    $old_loc_name = $existingMaster[0]['location_name'];
	$old_table_name = $existingMaster[0]['table_name'];
	$old_is_active = $existingMaster[0]['is_active'];

    // ✅ CASE 1: If sensor_id or iot_id changed → Update both tables
    if ($old_sensor_id != $new_sensor_id || $old_iot_id != $new_iot_id) {


		$sensorId = $objArray['sensor'];
			$iotId = $objArray['iotDevice'];

			$SelCompQuerys	= 'SELECT companyCode FROM `arka_company_master` WHERE slNo="'.$comId.'" AND status=1';
			$SelCompData	= $this->ExecuteQuery($SelCompQuerys, 'select');
			$com_code = $SelCompData[0]['companyCode'];

			$SelBranchQuerys	= 'SELECT branch_id FROM `arka_branch_master` WHERE sl_no="'.$bid.'" AND record_status=1';
			$SelBranchData	= $this->ExecuteQuery($SelBranchQuerys, 'select');
            $branch_code = $SelBranchData[0]['branch_id'];

			$SelIotQuerys	= 'SELECT gateway_id FROM `arka_gateway_master` WHERE sl_no="'.$iotId.'" AND record_status=1';
			$SelIotData	= $this->ExecuteQuery($SelIotQuerys, 'select');
            $iot_code = $SelIotData[0]['gateway_id'];


			$SelSensorQuerys	= 'SELECT sensorCode FROM `arka_sensor_master` WHERE slNo="'.$sensorId.'" AND status=1';
			$SelSensorData	= $this->ExecuteQuery($SelSensorQuerys, 'select');
            $sensor_code = $SelSensorData[0]['sensorCode'];

            $com_branch_code = $com_code."_".$branch_code."_"; 
			//$com_branch_code = $com_code."_".$branch_code."_".$iot_code."_".$sensor_code; 
			
			  $SelLocationMasterQry	= 'SELECT location_code FROM `location_master` WHERE location_master_id="'.$location_master_id.'" AND status=1'; 
			$SelLocationMasGet	= $this->ExecuteQuery($SelLocationMasterQry, 'select');
			$loc_mas_code = $SelLocationMasGet[0]["location_code"];


			  $SelLocationMasQuerys	= 'SELECT location_code FROM `location_master` WHERE location_code="'.$loc_mas_code.'" AND status=1'; 
			$SelLocationMasData	= $this->ExecuteQuery($SelLocationMasQuerys, 'select');
			$SelLocationMasCount	= $this->ExecuteQuery($SelLocationMasQuerys, 'numrows');

			if($SelLocationMasCount < 0 ){

				 $SelLocationDetQuerys	= 'SELECT count(location_details_id) AS last FROM location_details WHERE  location_details.company_id="'.$comId.'" AND location_details.branch_id="'.$bid.'" AND sensor_id ="'.$sensorId.'" AND iot_id="'.$iotId.'" AND location_details.is_active=1 AND location_details.status=1'; 
			     $SelLocstionDetData	= $this->ExecuteQuery($SelLocationDetQuerys, 'select');
                 $locCount = $SelLocstionDetData[0]["last"];
				 $autoInc = $locCount + 1;
				 $locationCode = $com_branch_code."".$autoInc;


			}else{
                $locationCode = $loc_mas_code;

			}


			//echo "Location Code ".$locationCode; exit;

 		// 🔹 Checking post sensor is in active with some other location or not Start 
			    $SelOtherLocationDevice	= 'SELECT * FROM `location_master` WHERE location_master_id!="'.$location_master_id.'" AND sensor_id="'.$new_sensor_id.'" AND status=1';  
			$SelOtherLocationData	= $this->ExecuteQuery($SelOtherLocationDevice, 'select');
			$SelOtherLocationCount	= $this->ExecuteQuery($SelOtherLocationDevice, 'numrows');
            
			$other_location_master_id = $SelOtherLocationData[0]["location_master_id"];
            $otherLocDeatLastLocCode = $SelOtherLocationData[0]["location_code"];
			$objSmarty->assign('otherLocationId', $other_location_master_id);
            
			if($SelOtherLocationCount > 0){

				  $otherLocationDetLstQuery = "SELECT * FROM location_details WHERE location_master_id='".$other_location_master_id."' AND status='1' ORDER BY location_details_id DESC LIMIT 0,1"; ;
		$otherLocationDetLstData=$this->ExecuteQuery($otherLocationDetLstQuery, 'select');

		 $locationDetLstQuery = "SELECT * FROM location_details WHERE location_master_id='".$location_master_id."' AND status='1' ORDER BY location_details_id DESC LIMIT 0,1"; ;
		$locationDetLstData=$this->ExecuteQuery($locationDetLstQuery, 'select');

        $locDeatLastRecordId = $locationDetLstData[0]["location_details_id"];
        $otherLocDeatLastRecordId = $otherLocationDetLstData[0]["location_details_id"];
		$otherLocDeatLastIotId = $otherLocationDetLstData[0]["iot_id"];
		

//echo $otherLocDeatLastIotId; exit;

				 // 🔹 Close the previous Current location_details record
         $updateCurrentDetailsEnd = "UPDATE location_details 
                             SET end_date_time = '".$currentDateTime."',is_active = 0
                             WHERE location_master_id = '".$location_master_id."'
                             AND end_date_time IS NULL AND location_details_id='".$locDeatLastRecordId."'"; 
        $this->ExecuteQuery($updateCurrentDetailsEnd, 'update');
		

		// 🔹 Insert new Current location_details record
        $insertCurrentDetails = "INSERT INTO location_details
                         (location_master_id, company_id, branch_id, sensor_id, iot_id, start_date_time, is_active, status)
                         VALUES ('".$location_master_id."', '".$company_id."', '".$branch_id."', '".$new_sensor_id."', '".$new_iot_id."', '".$currentDateTime."', 1, 1)";
        $this->ExecuteQuery($insertCurrentDetails, 'insert');


		 // 🔹 Close the previous other location_details record
         $updateOtherDetailsEnd = "UPDATE location_details 
                             SET end_date_time = '".$currentDateTime."',is_active = 0
                             WHERE location_master_id = '".$other_location_master_id."'
                             AND end_date_time IS NULL AND location_details_id='".$otherLocDeatLastRecordId."'";
        $this->ExecuteQuery($updateOtherDetailsEnd, 'update');
		

		// 🔹 Insert new Other location_details record
         $insertOtherDetails = "INSERT INTO location_details
                         (location_master_id, company_id, branch_id, sensor_id, iot_id, start_date_time, is_active, status)
                         VALUES ('".$other_location_master_id."', '".$company_id."', '".$branch_id."', '".$old_sensor_id."', '".$otherLocDeatLastIotId."', '".$currentDateTime."', 1, 1)"; 
        $this->ExecuteQuery($insertOtherDetails, 'insert');


		// 🔹 Table Name Selection Start

			$oldSensorTableSql = "SELECT sensorCode FROM arka_sensor_master WHERE slNo='".$old_sensor_id."' AND status='1'"; 
            $oldSensorTableData=$this->ExecuteQuery($oldSensorTableSql, 'select');
			$oldSensorTableDataCount=$this->ExecuteQuery($oldSensorTableSql, 'numrows');
			$oldSenCode = $oldSensorTableData[0]['sensorCode'];

			$oldSpecificSenCode = str_replace("-","_",$oldSenCode);

			$newOldTableName = $otherLocDeatLastLocCode."_".$oldSpecificSenCode;


			$existingOldTable = $newOldTableName;

			 $sensorTableSql = "SELECT sensorCode FROM arka_sensor_master WHERE slNo='".$new_sensor_id."' AND status='1'"; 
            $sensorTableData=$this->ExecuteQuery($sensorTableSql, 'select');
			$sensorTableDataCount=$this->ExecuteQuery($sensorTableSql, 'numrows');
			$senCode = $sensorTableData[0]['sensorCode'];

			$specificSenCode = str_replace("-","_",$senCode);

			$newTableName = $old_loc_code."_".$specificSenCode;

			$existingTable = $newTableName;
		

		// 🔹 Table Name Selection End


		// 🔹 Update Other location_master with new sensor and iot 
        $updateOtherMaster = "UPDATE location_master 
                         SET sensor_id = '".$old_sensor_id."',
                             iot_id = '".$otherLocDeatLastIotId."',
							 table_name = '".$existingOldTable."',
							 is_active = '".trim(addslashes($objArray['checkVal']))."'
                         WHERE location_master_id = '".$other_location_master_id."'";
        $this->ExecuteQuery($updateOtherMaster, 'update');

		

		// 🔹 Update Current location_master with other sensor and iot 
        $updateOtherMaster = "UPDATE location_master 
                         SET sensor_id = '".$new_sensor_id."',
                             iot_id = '".$new_iot_id."',
							 location_name = '".$location_name."',
							 table_name = '".$existingTable."',
							 is_active = '".trim(addslashes($objArray['checkVal']))."'
                         WHERE location_master_id = '".$location_master_id."'"; 
        $this->ExecuteQuery($updateOtherMaster, 'update');


		/************* Create Specific Sensor Table if its's not present in Database Edit Location Method Starts*********************/

			// Fetch the Specific Field Data from the Existing Table
			 $specificSensorSql = "SELECT sensorCode,sensorModel FROM arka_sensor_master WHERE slNo='".$new_sensor_id."' AND status='1'"; 
            $specificSensorData=$this->ExecuteQuery($specificSensorSql, 'select');
			$specificSensorDataCount=$this->ExecuteQuery($specificSensorSql, 'numrows');
			$modelId = $specificSensorData[0]['sensorModel'];
			//$data = array();
			 $senModelQuery = "SELECT sl_no FROM sensor_model_master WHERE model_id='".$modelId."' AND status='1'"; 
            $senModelQueryData=$this->ExecuteQuery($senModelQuery, 'select');
			$senModelId = $senModelQueryData[0]['sl_no'];

			$senModelParamQuery = "SELECT * FROM sensor_model_parameter_master WHERE sensor_model_id='".$senModelId."' AND status='1' ORDER BY priority";
            $senModelParamQueryData=$this->ExecuteQuery($senModelParamQuery, 'select');

			foreach($senModelParamQueryData as $key=>$value)
				{
					$param = $senModelParamQueryData[$key]["parameter_name"]; //R_VOLTAGE
					$datat = $senModelParamQueryData[$key]["data_type"]; //VARACHAR
					$datal = $senModelParamQueryData[$key]["data_length"]; //255
					//Output: R_VOLTAGE VARACHAR(255),
					if($datal == ''){
                    
					$tableField .=$param." ".$datat.",";
					
					}else{
						
					$tableField .=$param." ".$datat."(".$datal."),";	
					
					}
					

				}

			//echo  $tableField; exit;
			$tableField = trim($tableField,",");
			//echo $tableField; exit;
			if($specificSensorDataCount > 0 ){

							foreach($specificSensorData as $key=>$value)
				{
							$specificSensorCode = str_replace("-","_",$specificSensorData[$key]["sensorCode"]);

							$new_table_name = $locationCode."_".$specificSensorCode;

				            //$data[] = $specificSensorData['sensorCode'];

						// Create a New Table
						$new_table = $new_table_name;
						// echo "Location Code = ".$locationCode."</br>";
						// echo "Sensor Specifiation Code = ".$specificSensorCode."</br>";
						// echo $new_table; 
						$dbName    = $config['DBName'];

						// Check table exists or not
						 $checkSql = "SELECT table_name 
								FROM information_schema.tables 
								WHERE table_schema = '$dbName'
								AND table_name = '$new_table'"; 
						$checkResult = $this->ExecuteQuery($checkSql, 'select');

						if ($checkResult && count($checkResult) > 0) {
							// Table already exists — do nothing
							// echo "Table already exists.";
						} else {
							// Table not exists — create new table
						  $insertNewTableSql = "CREATE TABLE IF NOT EXISTS $new_table (
						slNo INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
						company_id int(6) NOT NULL,
						branch_id int(6) NOT NULL,
						location_code varchar(155) NOT NULL,
						gateway_code varchar(155) NOT NULL,
						sensor_code varchar(155) NOT NULL,
						sensor_name varchar(155) NOT NULL,
						sensor_model varchar(155) NOT NULL,
						feeder_type varchar(155) NOT NULL,
						unit_rate float(11,2) NOT NULL,
						$tableField,
						raw_data LONGTEXT,
						linux_date_time varchar(55) NOT NULL,
						teltonika_date_time varchar(55) NOT NULL,
						recorded_date DATE NOT NULL,
						posted_date_time DATETIME,
						M_TIMESTAMP TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
						is_active int(6) DEFAULT 1 NOT NULL,
						status int(6) DEFAULT 1 NOT NULL
						)";
						$this->ExecuteQuery($insertNewTableSql, 'insert');

						}
				// echo $Insert= "INSERT INTO $new_table (company_id,branch_id,gateway_id,sensor_code,sensor_name,sensor_model,feeder_type,unit_rate,created_date) VALUES ('".$comId."','".$bid."','".trim(addslashes($objArray['gateway_id']))."','".$s_id."','".trim(addslashes($objArray['sensorName']))."','".trim(addslashes($objArray['model']))."','".$feederType."','".$unit_rate."','".trim(addslashes($objArray['timestamp']))."')";  
				// $this->ExecuteQuery($Insert, 'insert');


			}

			//echo $new_table."created successfully";
			

		}

          //echo "First Table Created"."<br/>"; 
     		/***** Create Specific Old Sensor Table if its's not present in Database Edit Location Method Start *******/



		// Fetch the Specific Field Data from the Existing Table
			 $specificOldSensorSql = "SELECT sensorCode,sensorModel FROM arka_sensor_master WHERE slNo='".$old_sensor_id."' AND status='1'"; 
            $specificOldSensorData=$this->ExecuteQuery($specificOldSensorSql, 'select');
			$specificOldSensorDataCount=$this->ExecuteQuery($specificOldSensorSql, 'numrows');
			$oldModelId = $specificOldSensorData[0]['sensorModel'];
			//$data = array();
			 $oldSenModelQuery = "SELECT sl_no FROM sensor_model_master WHERE model_id='".$oldModelId."' AND status='1'"; 
            $oldSenModelQueryData=$this->ExecuteQuery($oldSenModelQuery, 'select');
			$oldSenModelId = $oldSenModelQueryData[0]['sl_no'];

			$oldSenModelParamQuery = "SELECT * FROM sensor_model_parameter_master WHERE sensor_model_id='".$oldSenModelId."' AND status='1' ORDER BY priority";
            $oldSenModelParamQueryData=$this->ExecuteQuery($oldSenModelParamQuery, 'select');

			foreach($oldSenModelParamQueryData as $key=>$value)
				{
					$paramOld = $oldSenModelParamQueryData[$key]["parameter_name"]; //R_VOLTAGE
					$datatOld = $oldSenModelParamQueryData[$key]["data_type"]; //VARACHAR
					$datalOld = $oldSenModelParamQueryData[$key]["data_length"]; //255
					//Output: R_VOLTAGE VARACHAR(255),
					if($datalOld == ''){
                    
					$tableFieldOld .=$paramOld." ".$datatOld.",";
					
					}else{
						
					$tableFieldOld .=$paramOld." ".$datatOld."(".$datalOld."),";	
					
					}
					

				}

			//echo  $tableField; exit;
			$tableFieldOld = trim($tableFieldOld,",");
			//echo $tableFieldOld; exit;
			if($specificOldSensorDataCount > 0 ){

							foreach($specificOldSensorData as $key=>$value)
				{
							$specificOldSensorCode = str_replace("-","_",$specificOldSensorData[$key]["sensorCode"]);

							$new_old_table_name = $otherLocDeatLastLocCode."_".$specificOldSensorCode;

				            //$data[] = $specificOldSensorData['sensorCode'];

						// Create a New Table
						$new_old_table = $new_old_table_name;
						// echo "Location Code = ".$otherLocDeatLastLocCode."</br>";
						// echo "Sensor Specifiation Code = ".$specificOldSensorCode."</br>";
						// echo $new_old_table; 
						$dbName    = $config['DBName'];

						// Check table exists or not
						 $checkSqlOld = "SELECT table_name 
								FROM information_schema.tables 
								WHERE table_schema = '$dbName'
								AND table_name = '$new_old_table'"; 
						$checkResultOld = $this->ExecuteQuery($checkSqlOld, 'select');

						if ($checkResultOld && count($checkResultOld) > 0) {
							// Table already exists — do nothing
							 //echo "Table already exists.";
						} else {
							// Table not exists — create new table
						  $insertNewOldTableSql = "CREATE TABLE IF NOT EXISTS $new_old_table (
						slNo INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
						company_id int(6) NOT NULL,
						branch_id int(6) NOT NULL,
						location_code varchar(155) NOT NULL,
						gateway_code varchar(155) NOT NULL,
						sensor_code varchar(155) NOT NULL,
						sensor_name varchar(155) NOT NULL,
						sensor_model varchar(155) NOT NULL,
						feeder_type varchar(155) NOT NULL,
						unit_rate float(11,2) NOT NULL,
						$tableFieldOld,
						raw_data LONGTEXT,
						linux_date_time varchar(55) NOT NULL,
						teltonika_date_time varchar(55) NOT NULL,
						recorded_date_time DATETIME,
						posted_date_time DATETIME,
						M_TIMESTAMP TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
						is_active int(6) DEFAULT 1 NOT NULL,
						status int(6) DEFAULT 1 NOT NULL
						)"; 
						$this->ExecuteQuery($insertNewOldTableSql, 'insert');

						}
				// echo $Insert= "INSERT INTO $new_table (company_id,branch_id,gateway_id,sensor_code,sensor_name,sensor_model,feeder_type,unit_rate,created_date) VALUES ('".$comId."','".$bid."','".trim(addslashes($objArray['gateway_id']))."','".$s_id."','".trim(addslashes($objArray['sensorName']))."','".trim(addslashes($objArray['model']))."','".$feederType."','".$unit_rate."','".trim(addslashes($objArray['timestamp']))."')";  
				// $this->ExecuteQuery($Insert, 'insert');


			}

			//echo $new_old_table."created successfully";
			

		}
       /***** Create Specific Old Sensor Table if its's not present in Database Edit Location Method End *******/

     //echo"Second Table created";


		  /************* Create Specific Sensor Table if its's not present in Database Edit Location Method Ends*********************/


			}else{
                //echo"am in else"; exit;

				 $locationDetLstQuery = "SELECT * FROM location_details WHERE location_master_id='".$location_master_id."' AND status='1' ORDER BY location_details_id DESC LIMIT 0,1"; ;
		    $locationDetLstData=$this->ExecuteQuery($locationDetLstQuery, 'select');

        $locDeatLastRecordId = $locationDetLstData[0]["location_details_id"];
        $otherLocDeatLastRecordId = $otherLocationDetLstData[0]["location_details_id"];
		$otherLocDeatLastIotId = $otherLocationDetLstData[0]["iot_id"];
		

//echo $otherLocDeatLastIotId; exit;

				 // 🔹 Close the previous Current location_details record
         $updateCurrentDetailsEnd = "UPDATE location_details 
                             SET end_date_time = '".$currentDateTime."',is_active = 0
                             WHERE location_master_id = '".$location_master_id."'
                             AND end_date_time IS NULL AND location_details_id='".$locDeatLastRecordId."'"; 
        $this->ExecuteQuery($updateCurrentDetailsEnd, 'update');
		

		// 🔹 Insert new Current location_details record
        $insertCurrentDetails = "INSERT INTO location_details
                         (location_master_id, company_id, branch_id, sensor_id, iot_id, start_date_time, is_active, status)
                         VALUES ('".$location_master_id."', '".$company_id."', '".$branch_id."', '".$new_sensor_id."', '".$new_iot_id."', '".$currentDateTime."', 1, 1)";
        $this->ExecuteQuery($insertCurrentDetails, 'insert');


		// 🔹 Table Name Selection Start
		
		if($old_sensor_id == $new_sensor_id){

			$existingTable = $old_table_name;

		}else{
			 $sensorTableSql = "SELECT sensorCode FROM arka_sensor_master WHERE slNo='".$new_sensor_id."' AND status='1'"; 
            $sensorTableData=$this->ExecuteQuery($sensorTableSql, 'select');
			$sensorTableDataCount=$this->ExecuteQuery($sensorTableSql, 'numrows');
			$senCode = $sensorTableData[0]['sensorCode'];

			$specificSenCode = str_replace("-","_",$senCode);

							$newTableName = $old_loc_code."_".$specificSenCode;

			$existingTable = $newTableName;
		}

		// 🔹 Table Name Selection End



		// 🔹 Update Current location_master with other sensor and iot 
        $updateOtherMaster = "UPDATE location_master 
                         SET sensor_id = '".$new_sensor_id."',
                             iot_id = '".$new_iot_id."',
							 location_name = '".$location_name."',
							 table_name = '".$existingTable."',
							 is_active = '".trim(addslashes($objArray['checkVal']))."'
                         WHERE location_master_id = '".$location_master_id."'"; 
        $this->ExecuteQuery($updateOtherMaster, 'update');

		

		/************* Create Specific Sensor Table if its's not present in Database Edit Location Method Starts*********************/

			// Fetch the Specific Field Data from the Existing Table
			 $specificSensorSql = "SELECT sensorCode,sensorModel FROM arka_sensor_master WHERE slNo='".$new_sensor_id."' AND status='1'"; 
            $specificSensorData=$this->ExecuteQuery($specificSensorSql, 'select');
			$specificSensorDataCount=$this->ExecuteQuery($specificSensorSql, 'numrows');
			$modelId = $specificSensorData[0]['sensorModel'];
			//$data = array();
			 $senModelQuery = "SELECT sl_no FROM sensor_model_master WHERE model_id='".$modelId."' AND status='1'"; 
            $senModelQueryData=$this->ExecuteQuery($senModelQuery, 'select');
			$senModelId = $senModelQueryData[0]['sl_no'];

			$senModelParamQuery = "SELECT * FROM sensor_model_parameter_master WHERE sensor_model_id='".$senModelId."' AND status='1' ORDER BY priority";
            $senModelParamQueryData=$this->ExecuteQuery($senModelParamQuery, 'select');

			foreach($senModelParamQueryData as $key=>$value)
				{
					$param = $senModelParamQueryData[$key]["parameter_name"]; //R_VOLTAGE
					$datat = $senModelParamQueryData[$key]["data_type"]; //VARACHAR
					$datal = $senModelParamQueryData[$key]["data_length"]; //255
					//Output: R_VOLTAGE VARACHAR(255),
					if($datal == ''){
                    
					$tableField .=$param." ".$datat.",";
					
					}else{
						
					$tableField .=$param." ".$datat."(".$datal."),";	
					
					}
					

				}

			//echo  $tableField; exit;
			$tableField = trim($tableField,",");
			//echo $tableField; exit;
			if($specificSensorDataCount > 0 ){

							foreach($specificSensorData as $key=>$value)
				{
							$specificSensorCode = str_replace("-","_",$specificSensorData[$key]["sensorCode"]);

							$new_table_name = $locationCode."_".$specificSensorCode;

				            //$data[] = $specificSensorData['sensorCode'];

						// Create a New Table
						$new_table = $new_table_name;
						// echo "Location Code = ".$locationCode."</br>";
						// echo "Sensor Specifiation Code = ".$specificSensorCode."</br>";
						// echo $new_table; 
						$dbName    = $config['DBName'];

						// Check table exists or not
						 $checkSql = "SELECT table_name 
								FROM information_schema.tables 
								WHERE table_schema = '$dbName'
								AND table_name = '$new_table'"; 
						$checkResult = $this->ExecuteQuery($checkSql, 'select');

						if ($checkResult && count($checkResult) > 0) {
							// Table already exists — do nothing
							// echo "Table already exists.";
						} else {
							// Table not exists — create new table
						  $insertNewTableSql = "CREATE TABLE IF NOT EXISTS $new_table (
						slNo INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
						company_id int(6) NOT NULL,
						branch_id int(6) NOT NULL,
						location_code varchar(155) NOT NULL,
						gateway_code varchar(155) NOT NULL,
						sensor_code varchar(155) NOT NULL,
						sensor_name varchar(155) NOT NULL,
						sensor_model varchar(155) NOT NULL,
						feeder_type varchar(155) NOT NULL,
						unit_rate float(11,2) NOT NULL,
						$tableField,
						raw_data LONGTEXT,
						linux_date_time varchar(55) NOT NULL,
						teltonika_date_time varchar(55) NOT NULL,
						recorded_date_time DATETIME,
						posted_date_time DATETIME,
						M_TIMESTAMP TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
						is_active int(6) DEFAULT 1 NOT NULL,
						status int(6) DEFAULT 1 NOT NULL
						)";
						$this->ExecuteQuery($insertNewTableSql, 'insert');

						}
				// echo $Insert= "INSERT INTO $new_table (company_id,branch_id,gateway_id,sensor_code,sensor_name,sensor_model,feeder_type,unit_rate,created_date) VALUES ('".$comId."','".$bid."','".trim(addslashes($objArray['gateway_id']))."','".$s_id."','".trim(addslashes($objArray['sensorName']))."','".trim(addslashes($objArray['model']))."','".$feederType."','".$unit_rate."','".trim(addslashes($objArray['timestamp']))."')";  
				// $this->ExecuteQuery($Insert, 'insert');


			}

			//echo $new_table."created successfully";
			

		}

          //echo "First Table Created"."<br/>"; 

		  /************* Create Specific Sensor Table if its's not present in Database Edit Location Method End*********************/

				/* $objSmarty->assign('ErrorMessage', 'Both Sensor and IOT already active in this branch');
				return false; */

			}	
			
		


    }
    // ✅ CASE 2: If only location_code or location_name changed → Update master only //location_code = '".$location_code."',
    elseif ($old_loc_code != $location_code || $old_loc_name != $location_name || $old_is_active != $new_is_active) {

        $updateMaster = "UPDATE location_master 
                         SET location_name = '".$location_name."',
							 is_active = '".trim(addslashes($objArray['checkVal']))."'
                         WHERE location_master_id = '".$location_master_id."'";
        $this->ExecuteQuery($updateMaster, 'update');
    }
}

	}

	header('Location:locationList.php?branchId='.$_GET["branchId"].'&companyId='.$_GET["companyId"].'&success_msg_for_insert');
//echo "am in else"; exit;
}
	      /********* UpdateLocation Functions Ends ********************************/

	  /********* DeleteLocation Functions Starts ********************************/
	function DeleteLocationMaster($CatIdent)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$location_master_id = base64_decode($_GET['locId']);  
		$company_id = base64_decode($_GET['companyId']);
		$branch_id = base64_decode($_GET['branchId']);

		$DelMasQuery = 'update location_master set `status` = "0" WHERE `location_master_id` ="'.$location_master_id.'"'; 
		$this->ExecuteQuery($DelMasQuery, 'update');

		$DelDetQuery = 'update location_details set `status` = "0" WHERE `location_master_id` ="'.$location_master_id.'"'; 
		$this->ExecuteQuery($DelDetQuery, 'update');

		header('Location:' .$_SERVER['PHP_SELF'].'?companyId='.$_GET['companyId'].'&branchId='.$_GET['branchId'].'&succs_msg_for_del');  
	}
     /********* DeleteLocation Functions Ends ********************************/
	 /********* InsertSensorModel Functions Starts ********************************/
	function InsertSensorModel($objArray)
	{ 
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if(!$objArray['modelName']){
			$objSmarty->assign('ErrorMessage', 'Model Name should not be blank');
			return false;
		}elseif(!$objArray['commType']){
			$objSmarty->assign('ErrorMessage', 'Coommuniication Type should not be blank');
			return false;
		}elseif(!$objArray['apiUrl']){
			$objSmarty->assign('ErrorMessage', 'Api Url Type should not be blank');
			return false;
		}elseif(!$objArray['jsonFormat']){
			$objSmarty->assign('ErrorMessage', 'json Format Type should not be blank');
			return false;
		}
		if($objArray['modelName'])
		{
			$InsQuery = 'INSERT INTO `sensor_model_master`(`model_id`, `model_name`, `communication_type`,`platform_id`,`TemHum`,`api_url`,`is_active`,`json_format`,`max_kwh`,`segment_count`,`make`,`no_of_steps`,`capacity`,`level1`,`level2`,`created_date_time`,`status`) VALUES ("'.trim(addslashes($objArray['modelCode'])).'","'.trim(addslashes($objArray['modelName'])).'","'.trim(addslashes($objArray['commType'])).'","'.trim(addslashes($objArray['platform'])).'","'.trim(addslashes($objArray['temHum'])).'","'.trim(addslashes($objArray['apiUrl'])).'","'.trim(addslashes($objArray['checkVal'])).'","'.base64_encode(trim(addslashes($objArray['jsonFormat']))).'","'.trim(addslashes($objArray['maxKWH'])).'","'.trim(addslashes($objArray['segCount'])).'","'.trim(addslashes($objArray['make'])).'","'.trim(addslashes($objArray['noOfSteps'])).'","'.trim(addslashes($objArray['capacity'])).'","'.trim(addslashes($objArray['level1'])).'","'.trim(addslashes($objArray['level2'])).'","'.trim(addslashes($objArray['created_date_time'])).'","1")';  
			$this->ExecuteQuery($InsQuery, 'insert');
            
			$selSenModelLastInsertQry = 'SELECT * FROM sensor_model_master WHERE status="1" ORDER BY sl_no DESC LIMIT 0,1';
			$selSenModelLastInsertQryExe = $this->ExecuteQuery($selSenModelLastInsertQry, 'select');
			$senModelId = $selSenModelLastInsertQryExe[0]['sl_no'];
			$segCount = $objArray['segCount'];

			for($sr=0;$sr<$segCount;$sr++)
		{
			$priority = $sr+1;
		   
			 $Insert= "INSERT INTO arka_sensor_model_segment_details (sensor_model_id,priority,start_register_value,status) VALUES ('".$senModelId."','".$priority."','".trim(addslashes($objArray['startRegister_'.$sr]))."','1')";
			$this->ExecuteQuery($Insert, 'insert');
		}
            //exit;
			header('Location:sensorModelList.php?success_msg_for_insert');
		}
	}
       /********* InsertSensorModel Functions Ends ********************************/
	   /********* EditSensorModelView Functions Starts ********************************/
	function EditSensorModelView($slNo)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$SelQuery = 'SELECT * FROM  `sensor_model_master` WHERE sl_no="'.base64_decode($slNo).'" ';
		$ListEditView = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListEditView', $ListEditView);
		return $ListEditView;
	}
     /********* EditSensorModelView Functions Ends ********************************/
	 /********* EditSensorModel Functions Starts ********************************/
	function EditSensorModel($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		if(!$objArray['modelName']){
			$objSmarty->assign('ErrorMessage', 'Model Name should not be blank');
			return false;
		}elseif(!$objArray['commType']){
			$objSmarty->assign('ErrorMessage', 'Coommuniication Type should not be blank');
			return false;
		}elseif(!$objArray['apiUrl']){
			$objSmarty->assign('ErrorMessage', 'Api Url Type should not be blank');
			return false;
		}elseif(!$objArray['jsonFormat']){
			$objSmarty->assign('ErrorMessage', 'json Format Type should not be blank');
			return false;
		}
		if($objArray['modelName'])
		{
			$UpdateQuery = 'UPDATE `sensor_model_master` SET `model_id`="'.trim(addslashes($objArray['modelCode'])).'",`model_name`="'.trim(addslashes($objArray['modelName'])).'",`communication_type`="'.trim(addslashes($objArray['commType'])).'",`temHum`="'.trim(addslashes($objArray['temHum'])).'",`api_url`="'.trim(addslashes($objArray['apiUrl'])).'",`is_active`="'.trim(addslashes($objArray['checkVal'])).'",`json_format`="'.base64_encode(trim($objArray['jsonFormat'])).'",`max_kwh`="'.trim(addslashes($objArray['maxKWH'])).'",`segment_count`="'.trim(addslashes($objArray['segCount'])).'",`make`="'.trim(addslashes($objArray['make'])).'",`no_of_steps`="'.trim(addslashes($objArray['noOfSteps'])).'",`capacity`="'.trim(addslashes($objArray['capacity'])).'",`level1`="'.trim(addslashes($objArray['level1'])).'",`level2`="'.trim(addslashes($objArray['level2'])).'" WHERE sl_no="'.base64_decode($_GET["sl_no"]).'"';  
			$this->ExecuteQuery($UpdateQuery, 'update');

			 $DelSegment= "DELETE FROM arka_sensor_model_segment_details WHERE sensor_model_id='".base64_decode($_GET['sl_no'])."'"; 
			$this->ExecuteQuery($DelSegment, 'delete');
           
			$senModelId = base64_decode($_GET['sl_no']);
			$segCount = $objArray['segCount'];

			for($sr=0;$sr<$segCount;$sr++)
		{
			$priority = $sr+1;
		   
			  $Insert= "INSERT INTO arka_sensor_model_segment_details (sensor_model_id,priority,start_register_value,status) VALUES ('".$senModelId."','".$priority."','".trim(addslashes($objArray['startRegister_'.$sr]))."','1')";
			$this->ExecuteQuery($Insert, 'insert');
		}
          
		
			header('Location:sensorModelList.php?success_msg_for_update');
		}
	}
     /********* EditSensorModel Functions Ends ********************************/  
	 /********* DeleteSensorModel Functions Starts ********************************/  
	function DeleteSensorModel($CatIdent)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$sid = base64_decode($CatIdent);  
		$DelQuery = 'update `sensor_model_master` set `status` = "0" WHERE `sl_no` ="'.$sid.'" '; 
		$this->ExecuteQuery($DelQuery, 'update');
		header('Location:' .$_SERVER['PHP_SELF'].'?succs_msg_for_del');  
	}
      /********* DeleteSensorModel Functions Ends ********************************/ 
	  /********* GetPlatformList Functions Starts ********************************/  
	function GetPlatformList($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$SelSensorModel = 'SELECT * FROM `sensor_model_master` WHERE sl_no="'.base64_decode($_GET["sl_no"]).'"'; 
		$SensorModel = $this->ExecuteQuery($SelSensorModel, 'select');
		$objSmarty->assign('SensorModel', $SensorModel);	
		
		$SelPlat = 'SELECT * FROM `arka_iot_platform`'; 
		$GetPlatform = $this->ExecuteQuery($SelPlat, 'select');
		$objSmarty->assign('GetPlatform', $GetPlatform);
	}
	 /********* GetPlatformList Functions Ends ********************************/ 
	  /********* ParameterDetailView Functions Starts ********************************/ 
	function ParameterDetailView()
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$SelAssignParm = 'SELECT * FROM `sensor_model_parameter_mapping` WHERE sensor_model_id="'.base64_decode($_GET["sl_no"]).'" '; 
		$GetParmDet = $this->ExecuteQuery($SelAssignParm, 'select');
		$objSmarty->assign('GetParmDet', $GetParmDet);		
	}
      /********* ParameterDetailView Functions Ends ********************************/ 
	  /********* GetSensorModelParameter Functions Starts ********************************/ 
	function GetSensorModelParameter($sensorType,$senModId)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if($sensorType=='Energy Meter')
		{
		$whrclause='energy_data_master_view WHERE Field!="energy_data_id" AND Field!="gateway_code" AND Field!="sensor_code" AND Field!="sensor_model" AND Field!="METER_ID" AND Field!="VR_ARRAY_VALUE" AND Field!="linux_date_time" AND Field!="teltonika_date_time" AND Field!="recorded_date_time" AND Field!="posted_date_time" AND Field!="M_TIMESTAMP" AND Field NOT IN (SELECT parameter_name FROM sensor_model_parameter_mapping WHERE sensor_model_id="'.$senModId.'") ';
		}
		elseif($sensorType=='Temperature')
		{
		$whrclause='temperature_data_master WHERE Field!="temperature_data_id" AND Field!="gateway_code" AND Field!="sensor_code" AND Field!="sensor_model" AND Field!="linux_date_time" AND Field!="recorded_date_time" AND Field!="posted_date_time" AND Field NOT IN (SELECT parameter_name FROM sensor_model_parameter_mapping WHERE sensor_model_id="'.$senModId.'")';
		}
		elseif($sensorType=='Water Level')
		{
		$whrclause='water_level WHERE Field!="sl_no" AND Field!="device_id" AND Field!="M_TIMESTAMP" AND Field NOT IN (SELECT parameter_name FROM sensor_model_parameter_mapping WHERE sensor_model_id="'.$senModId.'")';
		}
		elseif($sensorType=='Heinn IoT')
		{
	    $whrclause='heinn_iot_data_master_view WHERE Field!="heinn_data_master_id" AND Field!="gateway_code" AND Field!="sensor_code" AND Field!="sensor_model" AND Field!="json_data" AND Field!="linux_date_time" AND Field!="teltonika_date_time" AND Field!="recorded_date_time" AND Field!="posted_date_time" AND Field!="M_TIMESTAMP" AND Field NOT IN (SELECT parameter_name FROM sensor_model_parameter_mapping WHERE sensor_model_id="'.$senModId.'") ';
		}
		elseif($sensorType=='Power Factor')
		{
		$whrclause='power_factor_energy_data_view WHERE Field!="power_factor_id" AND Field!="gateway_code" AND Field!="sensor_code" AND Field!="sensor_model" AND Field!="VR_ARRAY_VALUE" AND Field!="linux_date_time" AND Field!="teltonika_date_time" AND Field!="recorded_date_time" AND Field!="posted_date_time" AND Field!="M_TIMESTAMP" AND Field NOT IN (SELECT parameter_name FROM sensor_model_parameter_mapping WHERE sensor_model_id="'.$senModId.'") ';
		}
			$SelQuery = 'SHOW COLUMNS FROM '.$whrclause.''; 
			$GetParameter = $this->ExecuteQuery($SelQuery, 'select');
			echo json_encode($GetParameter);
	}
       /********* GetSensorModelParameter Functions Ends ********************************/ 
	   /********* AssignedParameter Functions Starts ********************************/ 
	function AssignedParameter($sensorType,$senModId)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		
		$SelAssignParm = 'SELECT * FROM `sensor_model_parameter_mapping` WHERE sensor_model_id="'.$senModId.'" '; 
		$GetAssignParm = $this->ExecuteQuery($SelAssignParm, 'select');
		echo json_encode($GetAssignParm);
	}
	/********* AssignedParameter Functions Ends ********************************/ 
	/********* InsertsensorModelMapping Functions Starts ********************************/ 
	function InsertsensorModelMapping($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if(!$objArray['sensorModId']){
			$objSmarty->assign('ErrorMessage', 'Sensor Model Id should not be blank');
			return false;
		}
			$DelQuery = 'DELETE FROM `sensor_model_parameter_mapping` WHERE `sensor_model_id` ="'.$objArray['sensorModId'].'"';
			$this->ExecuteQuery($DelQuery, 'delete');
			$arrs = $objArray["dexam16"];
		
		foreach($arrs as $key=>$value)
		{
			$InsQuery = 'INSERT INTO `sensor_model_parameter_mapping`(
			`sensor_model_id`,
			`platform_type`,
			`parameter_name`
			) 
			VALUES(
			"'.$objArray['sensorModId'].'",
			"'.$objArray['platformType'].'",
			"'.$value.'"
			)';
			$this->ExecuteQuery($InsQuery, 'insert');
		}
			header('Location:sensorModelList.php?success_msg_for_insert');  
	}
     /********* InsertsensorModelMapping Functions Ends ********************************/ 
	 /********* ListFeederForm Functions Starts ********************************/ 
	 function ListFeederForm($objArray)
    {
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> '')
		{
			$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
			$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
			$branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
			$branchId = $_SESSION['branch_id'];
		}
		$gatewayId = base64_decode($_GET['gatewayId']);
		//echo $gatewayId;
		//	$SelQuery = 'SELECT feeder_master.*,arka_sensor_master.gateway_id,arka_sensor_master.sensorModel FROM `feeder_master`,arka_sensor_master WHERE feeder_master.sensor_code=arka_sensor_master.sensorCode AND feeder_master.company_id="'.$comId.'" AND feeder_master.branch_id="'.$branchId.'" AND feeder_master.status="1"';
			 $SelQuery = 'SELECT * FROM arka_sensor_master WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND isActive="1"'; 
			$ListFeedForm = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListFeedForm', $ListFeedForm);
	}
	   /********* InsertsensorModelMapping Functions Ends ********************************/ 
	   /********* ListFeeder Functions Ends ********************************/ 
	function ListFeeder($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> '')
		{
			$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
			$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
			$branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
			$branchId = $_SESSION['branch_id'];
		}
			$SelQuery = 'SELECT * FROM `'.$tbl.'sensor_master` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'"  AND feeder_status="0" AND isActive="1" AND status="1"';
			$ListFeeder = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListFeeder', $ListFeeder);
			return $ListFeeder;
	}
     /********* ListFeeder Functions Ends ********************************/ 
	 /********* EditViewFeederForm Functions Starts ********************************/ 
	function EditViewFeederForm($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> '')
		{
			$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
			$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
			$branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
			$branchId = $_SESSION['branch_id'];
		}
		
		if($_SESSION["USER_GROUP"]=="Heinn Admin"){
		    
		   $sens= 'arka_sensor_master.sensorCode ="YMN-1"';
		}else{
		    $sens= 'arka_sensor_master.slNo ="'.base64_decode($objArray).'"';
		    
		}
		
    		$SelQuery = 'SELECT arka_sensor_master . * , sensor_model_master . * 
			FROM `arka_sensor_master` , sensor_model_master
			WHERE arka_sensor_master.sensorModel = sensor_model_master.model_id
			AND '.$sens.''; 
			$EditViewFeedForm = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('EditViewFeedForm', $EditViewFeedForm);
		
	     	$SelAlertPar = 'SELECT * from alert_parameter_mapping WHERE sensor_code="'.$EditViewFeedForm[0]["sensorCode"].'"';
			$alertParameterList = $this->ExecuteQuery($SelAlertPar, 'select');
			$objSmarty->assign('alertParameterList', $alertParameterList);
		
		    $SelSensPar = 'SELECT * FROM `sensor_model_parameter_mapping` WHERE sensor_model_id="'.$EditViewFeedForm[0]["sl_no"].'"'; 
			$sensorParam = $this->ExecuteQuery($SelSensPar, 'select');
			$objSmarty->assign('sensorParam', $sensorParam);
	}
	  /********* EditViewFeederForm Functions Ends ********************************/ 
	  /********* ListFeederTree Functions Starts ********************************/ 
	function ListFeederTree($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> '')
		{
			$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
			$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
			$branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
			$branchId = $_SESSION['branch_id'];
		}
		
			$SelMain = 'SELECT * FROM `feeder_master` WHERE feeder_type="Main Meter" AND company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND is_active="1" AND status="1"';
			$ListMainMeter = $this->ExecuteQuery($SelMain, 'select');
			$objSmarty->assign('ListMainMeter', $ListMainMeter);
		
			$SelSub = 'SELECT * FROM `feeder_master` WHERE feeder_type="Sub Meter" AND company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND is_active="1" AND status="1"';
			$ListSubMeter = $this->ExecuteQuery($SelSub, 'select');
			$objSmarty->assign('ListSubMeter', $ListSubMeter);
		
			$SelSubSub = 'SELECT * FROM `feeder_master` WHERE feeder_type="Sub Sub Meter" AND company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND is_active="1" AND status="1"'; 
			$ListSubSubMeter = $this->ExecuteQuery($SelSubSub, 'select');
			$objSmarty->assign('ListSubSubMeter', $ListSubSubMeter);
	}
	 /********* ListFeederTree Functions Ends ********************************/ 
/*** EditFeederForm Functions Starts ************/ 
	function EditFeederForm($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		
		if(!$objArray['sensorName']){
			$objSmarty->assign('ErrorMessage', 'sensor Name should not be blank');
			return false;
		}/*elseif(!$objArray['feederType']){
			$objSmarty->assign('ErrorMessage', 'Feeder Type should not be blank');
			return false;
		}*/
		
		if($_GET['companyId'] <> '')
		{
			$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
			$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
			$branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
			$branchId = $_SESSION['branch_id'];
		}
		//	$updQuery = 'UPDATE `feeder_master` SET feeder_name="'.trim(addslashes($objArray['feederName'])).'",unit_rate="'.trim(addslashes($objArray['unitRate'])).'",kw_max_value="'.trim(addslashes($objArray['kwMaxValue'])).'",kva_max_value="'.trim(addslashes($objArray['kvaMaxValue'])).'",kvar_max_value="'.trim(addslashes($objArray['kvarMaxValue'])).'",`contact_person`="'.trim(addslashes($objArray['contact_person'])).'",`contact_no`="'.trim(addslashes($objArray['contact_no'])).'",`email_id`="'.trim(addslashes($objArray['email_id'])).'",is_active="'.trim(addslashes($objArray['checkVal'])).'"  WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1" AND feeder_master_id="'.base64_decode($_GET["sl_no"]).'"';  
			$updQuery = 'UPDATE `arka_sensor_master` SET sensorName="'.trim(addslashes($objArray['sensorName'])).'",level1="'.trim(addslashes($objArray['level1'])).'",level2="'.trim(addslashes($objArray['level2'])).'",unit_rate="'.trim(addslashes($objArray['unitRate'])).'",dg_unit_rate="'.trim(addslashes($objArray['dgunitRate'])).'",kw_max_value="'.trim(addslashes($objArray['kwMaxValue'])).'",kva_max_value="'.trim(addslashes($objArray['kvaMaxValue'])).'",kvar_max_value="'.trim(addslashes($objArray['kvarMaxValue'])).'",kwh_max_value="'.trim(addslashes($objArray['kwhMaxValue'])).'",kvah_max_value="'.trim(addslashes($objArray['kvahMaxValue'])).'",kvarh_max_value="'.trim(addslashes($objArray['kvarhMaxValue'])).'",`contact_person`="'.trim(addslashes($objArray['contact_person'])).'",`contact_no`="'.trim(addslashes($objArray['contact_no'])).'",`email_id`="'.trim(addslashes($objArray['email_id'])).'"  WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND slNo="'.base64_decode($_GET["sl_no"]).'"';  
			$UpdateFeedForm = $this->ExecuteQuery($updQuery, 'update');
			header('Location:feederList.php?companyId='.$_GET["companyId"].'&branchId='.$_GET["branchId"].'&success_msg_for_update');
	}
	
	 /********* EditFeederForm Functions Ends ********************************/ 
	 /**************************         Ajax Feeder Type Starts       **************************************/
	 function ListFeederType($objArray)
    {
        global $objSmarty,$config;
        $tbl = $config['DBPrefix'];

        if($_GET['companyId'] <> '')
        {
            $comId = base64_decode($_GET['companyId']);
        }elseif($_POST['companyId'] <> '')
        {
            $comId = $_POST['companyId'];
        }	
        else
        {
            $comId = $_SESSION['CustomerId'];
        }
        if($_GET['branchId'] <> '')
        {
            $branchId = base64_decode($_GET['branchId']);
        }elseif($_POST['branchId'] <> '')
        {
            $branchId = $_POST['branchId'];
        }	
        else
        {
            $branchId = $_SESSION['branch_id'];
        }

        if($objArray=='Sub Meter'){
            $feederType="Main Meter";
        }
        else if($objArray=='Sub Sub Meter'){
            $feederType="Sub Meter";
        }
        //$SelQuery = 'SELECT * FROM `feeder_master` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND feeder_type="'.$feederType.'"';
         $SelQuery = 'SELECT * FROM `arka_sensor_master` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND feeder_type="'.$feederType.'" AND status="1" AND isActive="1"';

        $ListFeedType = $this->ExecuteQuery($SelQuery, 'selectassoc');
        $objSmarty->assign('ListFeedType', $ListFeedType);//print_r($ListView);exit;
        echo json_encode($ListFeedType);
		//	return $ListFeedType;
    }

	 /**************************         Ajax Feeder Type Ends         ***********************/
	 /********* InsertAlertParameter Functions starts ********************************/ 
	function InsertAlertParameter($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$selalertPar='SELECT * FROM alert_parameter_mapping WHERE sensor_code="'.$objArray['sensor_id'].'" AND parameter_name="'.$objArray['parameterName'].'"';
		$checkDuplicate=$this->ExecuteQuery($selalertPar, 'numrows');

		if($checkDuplicate==0){
		$InsQuery = 'INSERT INTO `alert_parameter_mapping`(
		`sensor_code`,
		`gateway_code`,
		`sensor_model_id`,
		`company_id`,
		`branch_id`,
		`feeder_name`,
		`parameter_name`,
		`min_alert_value`,
		`max_alert_value`,
		`mail_alert_status`
		) 
		VALUES(
		"'.$objArray['sensor_id'].'",
		"'.$objArray['gateway_id'].'",
		"'.$objArray['sensor_model_id'].'",
		"'.$objArray['company_id'].'",
		"'.$objArray['branch_id'].'",
		"'.$objArray['feederName'].'",
		"'.$objArray['parameterName'].'",
		"'.$objArray['minAlertValue'].'",
		"'.$objArray['maxAlertValue'].'",
		"Normal"
		)';
		$this->ExecuteQuery($InsQuery, 'insert');
		$currentUrl=$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING']; 
		$splitURL=explode("&succ", $currentUrl);
		header('Location:' .$splitURL[0].'&success_msg_for_insert');
		}else{
		$currentUrl=$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING']; 
		if(isset($_GET['ErrorMessage'])){
		$expVal="&ErrorMessage";
		}
		else{
			$expVal="&succ";
		}
		$splitURL=explode($expVal, $currentUrl); 
		header('Location:' .$splitURL[0].'&ErrorMessage');
		$objSmarty->assign('ErrorMessage', 'Parameter Already Exist.Insert Function');
		return false;
		}
	}
	  /********* InsertAlertParameter Functions Ends ********************************/ 
	 /********* DeleteAlertParameter Functions Starts ********************************/ 
	function DeleteAlertParameter($CatIdent)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$sid = base64_decode($CatIdent);  
		$DelQuery = 'Delete FROM `alert_parameter_mapping` WHERE `alert_parameter_id` ="'.$sid.'"'; 
		$this->ExecuteQuery($DelQuery, 'update');
		$currentUrl=$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING']; 
		$splitURL=explode("&Delete", $currentUrl); 
		header('Location:' .$splitURL[0].'&succs_msg_for_del');  
	}
     /********* DeleteAlertParameter Functions Ends ********************************/ 
      /********* ListCapacitorValue Functions Starts ********************************/
	function ListCapacitorValue($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> '')
		{
			$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
			$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
			$branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
			$branchId = $_SESSION['branch_id'];
		}
		$gateId = base64_decode($_GET['gatewayId']);
		$sensorCode = base64_decode($_GET['sensorCode']);
	
	    	$SelQuery = 'SELECT `arka_sensor_master`.* FROM `arka_sensor_master` WHERE sensorCode="'.$sensorCode.'" AND gateway_id="'.$gateId.'" AND status="1" AND isActive="1"';  
			$sensorView = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('sensorView', $sensorView);
	
			$SelQuery = 'SELECT `power_factor_step_capcitor_value_mapping`.* FROM `power_factor_step_capcitor_value_mapping` WHERE sensorCode="'.$sensorCode.'" AND gatewayCode="'.$gateId.'" AND status="1" AND isActive="1"';  
			$ListCapacityView = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListCapacityView', $ListCapacityView);
			return $ListCapacityView;
		
	}
      /********* ListCapacitorValue Functions Ends ********************************/
     	/********* InsertCapacitorValue Functions Starts ********************************/
	function InsertCapacitorValue($objArray)
	{ 
			global $objSmarty,$config,$nowDate;
			$tbl = $config['DBPrefix'];
			$comId = base64_decode($_GET['companyId']);
			$bid = base64_decode($_GET['branchId']);
			$gid = base64_decode($_GET['gatewayId']);
			$sid = base64_decode($_GET['slNo']);
			$scode = base64_decode($_GET['sensorCode']);
			$split = explode("-",$scode);

			$SelModSens	= 'SELECT * FROM `sensor_model_master` WHERE model_id ="'.$split[0].'" AND status="1" AND is_active="1"';
			$SensMod	= $this->ExecuteQuery($SelModSens, 'select');
		
		for($d=1;$d<=$SensMod[0]['no_of_steps'];$d++)
		{		
		    $sn='step'.$d.'_actual_steps_value';
			$Insert= "INSERT INTO power_factor_step_capcitor_value_mapping (sensorCode,gatewayCode,sensorModel,stepNumber,capacityValue,createdBy,isActive,status) VALUES ('".$scode."','".$gid."','".$split[0]."','".$sn."','','".$_SESSION['UserName']."','1','1')";
			$this->ExecuteQuery($Insert, 'insert');
		}
				/************* Cron Table date insert for a sensor Ends*********************/
		header('Location:capacityList.php?slNo='.$_GET["slNo"].'&sensorCode='.$_GET["sensorCode"].'&branchId='.$_GET["branchId"].'&companyId='.$_GET["companyId"].'&gatewayId='.$_GET["gatewayId"].'&success_msg_for_insert');
		}
	
	      /********* InsertCapacitorValue Functions Ends ********************************/
	      	/********* UpdateCapacitorValue Functions Starts ********************************/
	function UpdateCapacitorValue($objArray)
	{ 
			global $objSmarty,$config,$nowDate;
			$tbl = $config['DBPrefix'];
	    	$gid = $objArray['gatewayCode'];
			$scode = $objArray['sensorCode'];
			$split = explode("-",$scode);
			
			$SelModSens	= 'SELECT * FROM `sensor_model_master` WHERE model_id ="'.$split[0].'" AND status="1" AND is_active="1"';
			$SensMod	= $this->ExecuteQuery($SelModSens, 'select');
		
		for($d=1;$d<=$SensMod[0]['no_of_steps'];$d++)
		{
		    $sn='step'.$d.'_actual_steps_value';
		    
			$UpQuery = 'UPDATE `power_factor_step_capcitor_value_mapping` 
            SET 
            `capacityValue`=  "'.trim(addslashes($objArray["capacityValue"][$d])).'"
	        WHERE 
            `stepNumber`="'.trim(addslashes($objArray["stepNumber"][$d])).'" AND sensorCode="'.$scode.'" AND gatewayCode="'.$gid.'" AND sensorModel="'.$split[0].'" and status = "1" and isActive="1" AND slNo="'.trim(addslashes($objArray["sno"][$d])).'"';
             $this->ExecuteQuery($UpQuery, 'update');
		}
		
		    $gid = base64_encode($objArray['gatewayCode']);
			$scode = base64_encode($objArray['sensorCode']);
			header('Location:capacityList.php?slNo='.$_GET["slNo"].'&sensorCode='.$scode.'&branchId='.$_GET["branchId"].'&companyId='.$_GET["companyId"].'&gatewayId='.$gid.'&success_msg_for_update');
	}
	/********* ListSensorModelParameter Functions Starts *************************/
	function ListSensorParameterList()
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$sensor_model_id = base64_decode($_GET['sen_model']);
		
		$SelSesn = 'SELECT * FROM  `sensor_model_parameter_master` WHERE sensor_model_id= "'.$sensor_model_id.'" AND status="1" ORDER BY priority';  
		$GetModelParameter = $this->ExecuteQuery($SelSesn, 'select');
		$objSmarty->assign('GetModelParameter', $GetModelParameter);

		$SelSesnLastQuery = 'SELECT * FROM  `sensor_model_parameter_master` WHERE sensor_model_id= "'.$sensor_model_id.'" AND status="1" ORDER BY priority DESC';  
		$GetModelLastPriority = $this->ExecuteQuery($SelSesnLastQuery, 'select');
		$objSmarty->assign('GetModelLastPriority', $GetModelLastPriority);
		
	}
	/********* ListSensorModelParameter Functions Ends *******************************/
	/********* Get Sensor Model Name Functions Starts *************************/
	function GetSensorModelName()
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$sensor_model_id = base64_decode($_GET['sen_model']);
		
		 $SelSenName = 'SELECT * FROM  `sensor_model_master` WHERE sl_no= "'.$sensor_model_id.'" AND status="1" '; 
		$GetModelName = $this->ExecuteQuery($SelSenName, 'select');
		$objSmarty->assign('GetModelName', $GetModelName);
		return $GetModelName;
	}
	/********* Get Sensor Model Name Functions Ends *******************************/
	/********* List Data Type Functions Starts *************************/
	function ListDataType()
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$sensor_model_id = base64_decode($_GET['sl_no']);
		
		$SelDataQuery = 'SELECT * FROM  `data_type_master` WHERE status="1" ';  
		$DataTypeExe = $this->ExecuteQuery($SelDataQuery, 'select');
		$objSmarty->assign('DataTypeExe', $DataTypeExe);
		return $DataTypeExe;
	}
	/********* List Data Type Functions Ends *******************************/
/********* Insert Sensor Model Parameter Functions Starts *************************/
function InsertSensorModelParameter($objArray)
{
	global $objSmarty,$config;
	$tbl = $config['DBPrefix'];
	 $sensor_model_id = base64_decode($_GET['sen_model']);
	   $selalertPara='SELECT * FROM sensor_model_parameter_master WHERE sensor_model_id="'.$sensor_model_id.'" AND parameter_name="'.$objArray['parameterName'].'" AND status=1'; 
		$checkDuplicate=$this->ExecuteQuery($selalertPara, 'numrows');

		$dataType = $objArray['dataType'];
		$dataTypeArr = (explode("|",$dataType));

		$priority = $objArray['priority'];

		$selDataTypeQuery='SELECT data_type FROM data_type_master WHERE sl_no="'.$dataTypeArr[0].'" AND status=1';  
		$selDataTypeQuery=$this->ExecuteQuery($selDataTypeQuery, 'select');

		if($checkDuplicate==0){
         //For Creating a new colum name if not exist in particular sensor table Start
			$newParam = $objArray['parameterName']; // Set your new parameter name here
			$newParamType = $selDataTypeQuery[0]["data_type"]; // Adjust the data type as needed

			// Step 1: Get the sensor model ID
			$selSenModelMas = 'SELECT model_id FROM sensor_model_master WHERE sl_no="'.$sensor_model_id.'" AND status=1';
			$selSenModelMasQuery = $this->ExecuteQuery($selSenModelMas, 'select');
			$senModelMasterId = $selSenModelMasQuery[0]['model_id'];

			// Step 2: Get all table names matching the model
			$selTableQuery = "SHOW TABLES LIKE '%$senModelMasterId%'";
			$selTableQueryCount = $this->ExecuteQuery($selTableQuery, 'select');

			// Step 3: Loop through each matching table and check for the new column
			foreach ($selTableQueryCount as $tableRow) {
			// Each result will have column name like "Tables_in_univa_ems (%DEV6435%)"
			$tableName = reset($tableRow); // Get actual table name like dev6435_1, dev6435_2

			// Step 4: Check if column exists in the table
			$checkColQuery = "SHOW COLUMNS FROM `$tableName` LIKE '$newParam'";
			$colResult = $this->ExecuteQuery($checkColQuery, 'select');

			if (empty($colResult)) {
			// Column doesn't exist, so we add it
			$alterQuery = "ALTER TABLE `$tableName` ADD `$newParam` $newParamType";
			$this->ExecuteQuery($alterQuery, 'update');
			//echo "Added column `$newParam` to `$tableName`.<br>";
			} else {
			//echo "Column `$newParam` already exists in `$tableName`.<br>";
			}
			}
        //For Creating a new colum name if not exist in particular sensor table End

	       $InsQuery = 'INSERT INTO `sensor_model_parameter_master`(
		`sensor_model_id`,
		`data_type`,
		`data_length`,
		`priority`,
		`parameter_name`,
		`is_active`,
		`status`
		) 
		VALUES(
		"'.$sensor_model_id.'",
		"'.$selDataTypeQuery[0]["data_type"].'",
		"'.$objArray['parameterLength'].'",
		"'.$priority.'",
		"'.$objArray['parameterName'].'",
		"'.trim(addslashes($objArray['checkVal'])).'",
		"1"
		)';  
		$this->ExecuteQuery($InsQuery, 'insert');
		$currentUrl=$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING']; 
		$splitURL=explode("&succ", $currentUrl);
		header('Location:sensorModelParameterList.php?sen_model='.$_GET["sen_model"].'&success_msg_for_insert');
		}else{
		$objSmarty->assign('ErrorMessage', 'Parameter Already Exist');
		return false;
		}

}		

/********* Insert Sensor Model Parameter Functions Ends *************************/

  /********* EditSensorModelView Functions Starts ********************************/
  function EditSensorModelParameterView($objArray)
  {
	$sl_no = base64_decode($_GET['sl_no']);
	echo $sensor_model_id;
	  global $objSmarty,$config;
	  $tbl = $config['DBPrefix'];
	   $SelQuery = 'SELECT * FROM  `sensor_model_parameter_master` WHERE sl_no="'.$sl_no.'" '; 
	  $ListParameterEditView = $this->ExecuteQuery($SelQuery, 'select');
	  $objSmarty->assign('ListParameterEditView', $ListParameterEditView);
	  return $ListParameterEditView;
  }
   /********* EditSensorModelView Functions Ends ********************************/

   /********* Edit Sensor Model Parameter Functions Starts *************************/
function EditSensorModelParameter($objArray)
{
	global $objSmarty,$config;
	$tbl = $config['DBPrefix'];
	 $sensor_model_parameter_id = base64_decode($_GET['sl_no']);
	 $sensor_model_id = base64_decode($_GET['sen_model']);
	   $selSensorPara='SELECT * FROM sensor_model_parameter_master WHERE sl_no!="'.$sensor_model_parameter_id.'" AND sensor_model_id="'.$sensor_model_id.'" AND parameter_name="'.$objArray['parameterName'].'" AND status=1';
		$checkDuplicate=$this->ExecuteQuery($selSensorPara, 'numrows');

		$dataType = $objArray['dataType'];
		$dataTypeArr = (explode("|",$dataType));

		$priority = $objArray['priority'];

		$selDataTypeQuery='SELECT data_type FROM data_type_master WHERE sl_no="'.$dataTypeArr[0].'" AND status=1';  
		$selDataTypeQuery=$this->ExecuteQuery($selDataTypeQuery, 'select');

		if($checkDuplicate==0){

			//For Creating a new colum name if not exist in particular sensor table Start
			$newParam = $objArray['parameterName']; // Set your new parameter name here
			$newParamType = $selDataTypeQuery[0]["data_type"]; // Adjust the data type as needed

			// Step 1: Get the sensor model ID
			$selSenModelMas = 'SELECT model_id FROM sensor_model_master WHERE sl_no="'.$sensor_model_id.'" AND status=1';
			$selSenModelMasQuery = $this->ExecuteQuery($selSenModelMas, 'select');
			$senModelMasterId = $selSenModelMasQuery[0]['model_id'];

			// Step 2: Get all table names matching the model
			$selTableQuery = "SHOW TABLES LIKE '%$senModelMasterId%'";
			$selTableQueryCount = $this->ExecuteQuery($selTableQuery, 'select');

			// Step 3: Loop through each matching table and check for the new column
			foreach ($selTableQueryCount as $tableRow) {
			// Each result will have column name like "Tables_in_univa_ems (%DEV6435%)"
			$tableName = reset($tableRow); // Get actual table name like dev6435_1, dev6435_2

			// Step 4: Check if column exists in the table
			$checkColQuery = "SHOW COLUMNS FROM `$tableName` LIKE '$newParam'";
			$colResult = $this->ExecuteQuery($checkColQuery, 'select');

			if (empty($colResult)) {
			// Column doesn't exist, so we add it
			$alterQuery = "ALTER TABLE `$tableName` ADD `$newParam` $newParamType";
			$this->ExecuteQuery($alterQuery, 'update');
			//echo "Added column `$newParam` to `$tableName`.<br>";
			} else {
			//echo "Column `$newParam` already exists in `$tableName`.<br>";
			}
			}
        //For Creating a new colum name if not exist in particular sensor table End
		
	     $UpdateQuery = 'UPDATE `sensor_model_parameter_master` SET
		`sensor_model_id` = "'.$sensor_model_id.'",
		`data_type` = "'.$selDataTypeQuery[0]["data_type"].'",
		`data_length` = "'.$objArray['parameterLength'].'",
		`priority` = "'.trim(addslashes($priority)).'",
		`parameter_name` = "'.$objArray['parameterName'].'",
		`is_active` = "'.trim(addslashes($objArray['checkVal'])).'",
		`status` = "1" WHERE sl_no = "'.$sensor_model_parameter_id.'"';  
		$this->ExecuteQuery($UpdateQuery, 'update');
		header('Location:sensorModelParameterList.php?sen_model='.$_GET["sen_model"].'&success_msg_for_update');
		}else{
		$objSmarty->assign('ErrorMessage', 'Parameter Already Exist.Update Function');
		return false;
		}

}		

/********* Edit Sensor Model Parameter Functions Ends *************************/

 /********* Delete Sensor Model Parameter Functions Starts ********************************/  
 function DeleteSensorModelParameter($CatIdent, $senIdent, $parIdent)
 {
	 global $objSmarty,$config;
	 $tbl = $config['DBPrefix'];
	 $sid = base64_decode($CatIdent);  
	 $sModelid = base64_decode($senIdent);  
	 $paraName = base64_decode($parIdent);  


	        //For Deleting a colum name if exist in particular sensor table Start	

			// Step 1: Get the sensor model ID and parameter name
             $deleteParam = $paraName; // Check your parameter name here
			 $sensorModelID = $sModelid; // Check your Sensor Model Id here

			// Step 2: Get all table names matching the model
			$selSenModelMas = 'SELECT model_id FROM sensor_model_master WHERE sl_no="'.$sensorModelID.'" AND status=1';
			$selSenModelMasQuery = $this->ExecuteQuery($selSenModelMas, 'select');
			$senModelMasterId = $selSenModelMasQuery[0]['model_id'];

			$selTableQuery = "SHOW TABLES LIKE '%$senModelMasterId%'"; 
			$selTableQueryCount = $this->ExecuteQuery($selTableQuery, 'select');

			// Step 3: Loop through each matching table and check for the new column
			foreach ($selTableQueryCount as $tableRow) {
			// Each result will have column name like "Tables_in_univa_ems (%DEV6435%)"
			$tableName = reset($tableRow); // Get actual table name like dev6435_1, dev6435_2

			// Step 4: Check if column exists in the table
			 $checkColQuery = "SHOW COLUMNS FROM `$tableName` LIKE '$deleteParam'";
			$colResult = $this->ExecuteQuery($checkColQuery, 'select');

			if (!empty($colResult)) {

               
				 $checkLinkQuery = "SELECT * FROM `$tableName`
					WHERE sensor_model = '$senModelMasterId'";
				$linkResult = $this->ExecuteQuery($checkLinkQuery, 'select');

				if (!empty($linkResult)) {

					// Column exist, so we delete it
			 $alterQuery = "ALTER TABLE `$tableName` DROP COLUMN `$deleteParam`;"; 
			$this->ExecuteQuery($alterQuery, 'update');
			//echo "Deleted column `$deleteParam` to `$tableName`.<br>";

				//echo "Cannot delete. Parameter is linked to sensor model.";
				} else {
				//echo "Column exists and is safe to delete.";
				// You can run your DROP COLUMN query here
				}
            
			} else {
			//echo "Column `$deleteParam` already exists in `$tableName`.<br>";
			}
			}
        //For Deleting a colum name if exist in particular sensor table Start

	  $DelQuery = 'update `sensor_model_parameter_master` set `status` = "0" WHERE `sl_no` ="'.$sid.'" ';  
	 $this->ExecuteQuery($DelQuery, 'update');
	 header('Location:' .$_SERVER['PHP_SELF'].'?&sen_model='.$senIdent.'&succs_msg_for_del');  
 }
   /********* Delete Sensor Model Parameter Functions Ends ********************************/ 
    /********* SensorModelSegment Functions Starts ********************************/
  function GetSensorModelSegment($objArray)
  {
	$sl_no = base64_decode($_GET['sl_no']);
	echo $sensor_model_id;
	  global $objSmarty,$config;
	  $tbl = $config['DBPrefix'];
	  $SelQuery = 'SELECT * FROM  `arka_sensor_model_segment_details` WHERE sensor_model_id="'.$sl_no.'" ORDER BY priority '; 
	  $ListSensorSegment = $this->ExecuteQuery($SelQuery, 'select');
	  $objSmarty->assign('ListSensorSegment', $ListSensorSegment);
	  return $ListSensorSegment;
  }
   /********* SensorModelSegment Functions Ends ********************************/

   

    /********* SensorModelSegment Functions Starts ********************************/
  function GetSensorModelSegmentList($objArray)
  {
	$sl_no = base64_decode($_GET['sen_model']);
	echo $sensor_model_id;
	  global $objSmarty,$config;
	  $tbl = $config['DBPrefix'];
	  $SelQuery = 'SELECT * FROM  `arka_sensor_model_segment_details` WHERE sensor_model_id="'.$sl_no.'" ORDER BY priority '; 
	  $SensorSegmentList = $this->ExecuteQuery($SelQuery, 'select');
	  $objSmarty->assign('SensorSegmentList', $SensorSegmentList);
	  return $SensorSegmentList;
  }
   /********* SensorModelSegment Functions Ends ********************************/

   /********* Insert Sensor Model Parameter Functions Starts *************************/
function SegmentParameterMapping($objArray)
{
	global $objSmarty,$config;
	$tbl = $config['DBPrefix'];
	 $sensor_model_id = base64_decode($_GET['sen_model']);
  
	 /******************************* Check Only Parameter Present or Not *************************************/

	 $selStartMapParameter='SELECT * FROM start_register_parameter_mapping WHERE parameter_id="'.$objArray['parameter_id'].'" AND status=1'; 
	 $checkDuplicateStParameter=$this->ExecuteQuery($selStartMapParameter, 'numrows');

	 if($checkDuplicateStParameter!=0){

		/******************* Check Parameter,Start Register,Register Order Present or Not *****************/

		 $selStartMapPSR='SELECT * FROM start_register_parameter_mapping WHERE parameter_id="'.$objArray['parameter_id'].'" AND segment_id="'.$objArray['start_register'].'" AND register_order="'.$objArray['register_order'].'" AND status=1'; 
	 $checkDuplicateStPSR=$this->ExecuteQuery($selStartMapPSR, 'numrows');

	 		if($checkDuplicateStPSR!=0){ 

				$UpdateQuery = 'update `start_register_parameter_mapping` set `register_order` = "'.$objArray['register_order'].'", segment_id="'.$objArray['start_register'].'", `map_priority`="'.$objArray['mapPriority'].'", formula_type="'.$objArray['formula_type'].'",multiplication_factor="'.$objArray['m_factor'].'" WHERE `parameter_id` ="'.$objArray['parameter_id'].'" '; 
				$this->ExecuteQuery($UpdateQuery, 'update');
				header('Location:sensorModelParameterList.php?sen_model='.$_GET["sen_model"].'&success_msg_for_insert');

			}else{

				/******************* Check Parameter,Start Register,New Register Order Present or Not *****************/

				 echo $selStartMapPSNewR='SELECT * FROM start_register_parameter_mapping WHERE segment_id="'.$objArray['start_register'].'" AND register_order="'.$objArray['register_order'].'" AND status=1'; 
	 $checkDuplicateStPSNewR=$this->ExecuteQuery($selStartMapPSNewR, 'numrows');

					if($checkDuplicateStPSNewR ==0){
						//echo "am in update";exit;

						$UpdateQuery = 'update `start_register_parameter_mapping` set `register_order` = "'.$objArray['register_order'].'", segment_id="'.$objArray['start_register'].'", `map_priority`="'.$objArray['mapPriority'].'", formula_type="'.$objArray['formula_type'].'",multiplication_factor="'.$objArray['m_factor'].'" WHERE `parameter_id` ="'.$objArray['parameter_id'].'" '; 
						$this->ExecuteQuery($UpdateQuery, 'update');
						header('Location:sensorModelParameterList.php?sen_model='.$_GET["sen_model"].'&success_msg_for_insert');

					}else{

						$objSmarty->assign('ErrorMessage', 'Start Register Order Already Exist');
						return false;
					}

				 /************** Check Other Parameter,Start Register,Register Order Present or Not ***********/

					$selStartMapOtherPSR='SELECT * FROM start_register_parameter_mapping WHERE parameter_id!="'.$objArray['parameter_id'].'" AND segment_id="'.$objArray['start_register'].'" AND register_order="'.$objArray['register_order'].'" AND status=1'; 
					$checkDuplicateStOtherPSR=$this->ExecuteQuery($selStartMapOtherPSR, 'numrows');

					if($checkDuplicateStOtherPSR!=0){

						$objSmarty->assign('ErrorMessage', 'Start Register Order Already Exist');
						return false;

					}

			}	

	 }else{

		 /************** Check Start Register,Register Order Present or Not ***********/
		$selStartMapSR='SELECT * FROM start_register_parameter_mapping WHERE segment_id="'.$objArray['start_register'].'" AND register_order="'.$objArray['register_order'].'" AND status=1';
		$checkDuplicateStSR=$this->ExecuteQuery($selStartMapSR, 'numrows');

		if($checkDuplicateStSR ==0){

		$InsQuery = 'INSERT INTO `start_register_parameter_mapping`(
			`segment_id`,
			`parameter_id`,
			`register_order`,
			`map_priority`,
			`formula_type`,
			`multiplication_factor`,
			`status`
			) 
			VALUES(
			"'.$objArray['start_register'].'",
			"'.$objArray['parameter_id'].'",
			"'.$objArray['register_order'].'",
			"'.$objArray['mapPriority'].'",
			"'.$objArray['formula_type'].'",
			"'.$objArray['m_factor'].'",
			"1"
			)';  
			$this->ExecuteQuery($InsQuery, 'insert');
			$currentUrl=$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING']; 
			$splitURL=explode("&succ", $currentUrl);
			header('Location:sensorModelParameterList.php?sen_model='.$_GET["sen_model"].'&success_msg_for_insert');

		}else{

			$objSmarty->assign('ErrorMessage', 'Start Register Order Already Exist');
			return false;

		}

	 }	   

}		

/********* Insert Sensor Model Parameter Functions Ends *************************/

/********* EditSensorModelView Functions Starts ********************************/
function EditSensorParameterView($objArray)
{
  $sl_no = base64_decode($_GET['sl_no']);
  echo $sensor_model_id;
	global $objSmarty,$config;
	$tbl = $config['DBPrefix'];
	 $SelQuery = 'SELECT * FROM  `sensor_model_parameter_master` WHERE sl_no="'.$sl_no.'" '; 
	$ListStRegisterEditView = $this->ExecuteQuery($SelQuery, 'select');
	$objSmarty->assign('ListStRegisterEditView', $ListStRegisterEditView);
	return $ListStRegisterEditView;
}
 /********* EditSensorModelView Functions Ends ********************************/
 /********* EditSensorModelView Functions Starts ********************************/
function EditStRegisterMapView($objArray)
{
  $sl_no = base64_decode($_GET['sl_no']);
	global $objSmarty,$config;
	$tbl = $config['DBPrefix'];
	$SelQuery = 'SELECT * FROM  `start_register_parameter_mapping` WHERE parameter_id="'.$sl_no.'" AND status="1"'; 
	$StRegisterMapEditView = $this->ExecuteQuery($SelQuery, 'select');
	$objSmarty->assign('StRegisterMapEditView', $StRegisterMapEditView);
	return $StRegisterMapEditView;
}
 /********* EditSensorModelView Functions Ends ********************************/

 /********* EditSensorModelView Functions Starts ********************************/
function GetStartRegisterMapping()
{
	$sen_model = base64_decode($_GET['sen_model']);
	global $objSmarty,$config;
	$tbl = $config['DBPrefix'];
	 $SelQuery = 'SELECT start_register_parameter_mapping.*,arka_sensor_model_segment_details.start_register_value FROM  `start_register_parameter_mapping`,arka_sensor_model_segment_details WHERE start_register_parameter_mapping.segment_id=arka_sensor_model_segment_details.segment_id AND arka_sensor_model_segment_details.sensor_model_id="'.$sen_model.'" AND start_register_parameter_mapping.status="1" AND arka_sensor_model_segment_details.status="1"'; 
	$StRegisterMapAll = $this->ExecuteQuery($SelQuery, 'select');

	//$register_order_split = explode(",",$scode);

	$objSmarty->assign('StRegisterMapAll', $StRegisterMapAll);
	return $StRegisterMapAll;
}
 /********* EditSensorModelView Functions Ends ********************************/

 /********* ListSensorModelParameter Functions Starts *************************/
 function ListSensorStratRegisterList()
 {
	 global $objSmarty,$config;
	 $tbl = $config['DBPrefix'];
	 $sensor_model_id = base64_decode($_GET['sen_model']);
	 
	 $SelStReg = 'SELECT * FROM  `arka_sensor_model_segment_details` WHERE sensor_model_id= "'.$sensor_model_id.'" AND status="1" ORDER BY priority';  
	 $GetStartRegister = $this->ExecuteQuery($SelStReg, 'select');
	 $objSmarty->assign('GetStartRegister', $GetStartRegister);
	 
 }
 /********* ListSensorModelParameter Functions Ends *******************************/
	
}
?>