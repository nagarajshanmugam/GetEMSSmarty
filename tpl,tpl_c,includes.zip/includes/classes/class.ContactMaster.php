<?php
     class ContactMaster extends MysqlFns
	{
	
     /********* ListContactMaster Functions Starts ********************************/
	function ListContactMaster($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branId = $_SESSION['branch_id'];
	}
		$SelQuery = 'SELECT * FROM  `'.$tbl.'alert_contact_master` WHERE company_id="'.$comId.'" AND branch_id="'.$branId.'" AND record_status="1"';  
		$ListView = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListView', $ListView);//print_r($ListView);exit;
		return $ListView;
	}
     /********* ListContactMaster Functions Ends ********************************/
	 /********* InsertContact Functions Ends ********************************/

	function InsertContact($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}
	if(!$objArray['personName']){
		$objSmarty->assign('ErrorMessage', 'Person Name should not be blank');
		return false;
	}elseif(!$objArray['mobile']){
		$objSmarty->assign('ErrorMessage', 'Mobile should not be blank');
		return false;
	}elseif((!$objArray['email'])){
		$objSmarty->assign('ErrorMessage', 'Email should not be blank');
		return false;
	}
	if($objArray['personName'] && $objArray['mobile'])
	{
		$InsQuery = 'INSERT INTO `'.$tbl.
		'alert_contact_master`(`company_id`,`branch_id`,`person_name`,`mobile`,`email`,`sms_alert`,`email_alert`,`is_active`,`created_by`,`record_status`) VALUES("'.$comId.'","'.$branchId.'","'.trim(addslashes($objArray['personName'])).'","'.trim(addslashes($objArray['mobile'])).'","'.trim(addslashes($objArray['email'])).'","'.trim(addslashes($objArray['checkSms'])).'","'.trim(addslashes($objArray['checkEmail'])).'","'.trim(addslashes($objArray['checkVal'])).'","'.trim(addslashes($objArray['created_by'])).'","1")'; 
		$this->ExecuteQuery($InsQuery, 'insert');
		header('Location:contactMasterList.php?companyId='.base64_encode($comId).'&branchId='.base64_encode($branchId).'&success_msg_for_insert');
	}
	}
       /********* InsertContact Functions Ends ********************************/
	   /********* ListEditView Functions Starts ********************************/
	  function ListEditView($objArray)
    {
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$sid = $_GET['sl_no'];  
		$sid = base64_decode($sid);     
		$pid = $_GET['person_name'];
		$pid = base64_decode($pid);
		$mid = $_GET['mobile']; 
		$mid = base64_decode($mid);
		
		$SelQuery = 'SELECT * FROM  `'.$tbl.'alert_contact_master` WHERE person_name="'.$pid.'" AND sl_no="'.$sid.'" AND record_status="1"';  
		$ListEditView = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListEditView', $ListEditView);
		return $ListEditView;
    }
      /********* ListEditView Functions Ends ********************************/
	 /********* EditContactMaster Functions Starts ********************************/
	function EditContactMaster($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branchId'];
	}
	if(!$objArray['personName']){
		$objSmarty->assign('ErrorMessage', 'Person Name should not be blank');
		return false;
	}elseif(!$objArray['mobile']){
		$objSmarty->assign('ErrorMessage', 'Mobile should not be blank');
		return false;
	}elseif((!$objArray['email'])){
		$objSmarty->assign('ErrorMessage', 'Email should not be blank');
		return false;
	}
		$sid = $_GET['sl_no'];  
		$sid = base64_decode($sid);     
		$pid = $_GET['person_name'];
		$pid = base64_decode($pid);
		$mid = $_GET['mobile']; 
		$mid = base64_decode($mid);
	
	if($pid && $mid)
	{
	
		$UpdateQuery = 'UPDATE `'.$tbl.
		'alert_contact_master` SET `person_name`="'.trim(addslashes($objArray['personName'])).'",`mobile`="'.trim(addslashes($objArray['mobile'])).'",`email`="'.trim(addslashes($objArray['email'])).'",`is_active`="'.trim(addslashes($objArray['checkVal'])).'" ,`sms_alert`="'.trim(addslashes($objArray['checkSms'])).'" ,`email_alert`="'.trim(addslashes($objArray['checkEmail'])).'",`created_by`="'.trim(addslashes($objArray['created_by'])).'",`record_status`="1" WHERE person_name="'.$pid.'" AND sl_no="'.$sid.'"';    
		$this->ExecuteQuery($UpdateQuery, 'update');
		header('Location:contactMasterList.php?companyId='.base64_encode($comId).'&branchId='.base64_encode($branchId).'&success_msg_for_update');
	}
	}
      /********* EditContactMaster Functions Ends ********************************/
	   /********* DeleteContactMaster Functions Starts ********************************/
	function DeleteContactMaster($CatIdent)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$sid = $_GET['sl_no'];  
		$sid = base64_decode($sid);     
	
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branchId'];
	}
		$DelQuery = 'DELETE FROM `'.$tbl.'alert_contact_master`  WHERE `sl_no` ="'.$sid.'"'; 
		$this->ExecuteQuery($DelQuery, 'update');
		header('Location:' .$_SERVER['PHP_SELF'].'?companyId='.base64_decode($comId).'&branchId='.base64_decode($branchId).'&succs_msg_for_del');  
	}
    /********** DeleteContactMaster Functions Ends ********************************************************************/

  /********* ListAlertContactMaster Functions Starts ********************************/
	function ListAlertContactMaster($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branId = $_SESSION['branch_id'];
	}
		$SelQuery = 'SELECT * FROM  `'.$tbl.'alert_contact_master` WHERE company_id="'.$comId.'" AND branch_id="'.$branId.'" AND record_status="1" AND is_active="1"';  
		$ListView = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListView', $ListView);//print_r($ListView);exit;
		
		$SelQuery = 'SELECT * FROM  `alert_contact_mapping` WHERE company_id="'.$comId.'" AND branch_id="'.$branId.'" AND sensor_id="'.base64_decode($_GET['slNo']).'" AND record_status="1" AND is_active="1"';  
		$ListView1 = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListView1', $ListView1);
		
		$SelQuery = 'SELECT * FROM  `'.$tbl.'sensor_master` WHERE company_id="'.$comId.'" AND branch_id="'.$branId.'" AND slNo="'.base64_decode($_GET['slNo']).'" AND status="1"';  
		$ListView2 = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListView2', $ListView2);
		return $ListView2;
	}
     /********* ListAlertContactMaster Functions Ends ********************************/
/********* InsertAlertContactMaster Functions Ends ********************************/

	function InsertAlertContactMaster($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branchId'];
	}
	
	$DelQuery = 'DELETE FROM `alert_contact_mapping`  WHERE `company_id`="'.$objArray['companyId'].'" AND `branch_id`="'.$objArray['branchId'].'" AND `sensor_id` ="'.$objArray['sensorId'].'" AND record_status="1" AND is_active="1"'; 
		$this->ExecuteQuery($DelQuery, 'update');
	
$arrs = $objArray["item_id"];
$myArray = explode(',', $arrs);

	foreach($myArray as $key=>$value)
	{
		
	
		$InsQuery = 'INSERT INTO alert_contact_mapping(
		`company_id`,
		`branch_id`,
		`sensor_id`,
		`contact_id`) 
		VALUES(
		"'.$objArray['companyId'].'",
		"'.$objArray['branchId'].'",
		"'.$objArray['sensorId'].'",
		"'.$value.'"
		)';
		$this->ExecuteQuery($InsQuery, 'insert');
	}
	header('Location:sensorList.php?companyId='.base64_encode($objArray['companyId']).'&branchId='.base64_encode($objArray['branchId']).'&succs_msg_for_insert');  
	}

       /********* InsertAlertContactMaster Functions Ends ********************************/


	
	 }



?>