<?php
class temperature_Dashboard extends MysqlFns
{
   /********************* temperature_DashBoard Constructor Starts *************************/
	function temperature_Dashboard()
	{
		$this->LDDisplayPath= $config['SiteGlobalPath']."class.temperature_Dashboard.php";
		global $config;
		global $objSmarty;
		global $nowDate;
		$this->Limit = 20;
		$ConLink1 = mysql_connect($config['DBHost'],$config['DBUser'],$config['DBPassword']) or die("Database Connection Failed<br>". mysql_error());
		mysql_select_db($config['DBName'], $ConLink1);
		if($config['DBUser'] != 'root')
		{
			$nowDate= 'NOW()';
		}
		else{
			$nowDate= 'NOW()';
		}
	}
   /********************* temperature_Dashboard Constructor Ends *************************/
 	     /******************** GetDashboardDetails Functions Starts ****************/
		function GetDashboardDetails($objArray='')
		{
		    global $objSmarty;
		if($_GET['companyId'] <> '')
		{
		   $comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		   $comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		   $branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		   $branchId = $_SESSION['branch_id'];
		}
		   $SelQuery_loc = 'SELECT arka_company_master.companyName,arka_branch_master.branch_name,arka_sensor_master.* FROM arka_company_master,arka_branch_master,arka_sensor_master WHERE arka_sensor_master.gateway_id="'.base64_decode($_GET["gatewayCode"]).'" AND arka_sensor_master.sensorCode="'.base64_decode($_GET["sensorCode"]).'" AND  arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.company_id=arka_company_master.slNo AND arka_branch_master.company_id=arka_sensor_master.company_id AND arka_branch_master.company_id=arka_company_master.slNo AND arka_branch_master.sl_no=arka_sensor_master.branch_id' ;
		   $LoctList		= $this->ExecuteQuery($SelQuery_loc, "select");
		   $objSmarty->assign('LoctList', $LoctList);
		   
		     $SelQuery='SELECT max(ping_log_id) AS ping_log_id, max(gateway_code) AS gateway_code,max(gateway_date_time) AS gateway_date_time FROM `gateway_ping_log` WHERE gateway_code="'.base64_decode($_GET["gatewayCode"]).'" GROUP BY gateway_code ORDER BY ping_log_id';
	       $gateList= $this->ExecuteQuery($SelQuery, "select");//print_r($MeterList);
	       $objSmarty->assign('gateList', $gateList);
	       
		}	
	/******************** GetDashboardDetails Functions Ends ****************/
	    /*********************  Segment Functions Starts *************************/
		function GetSegmentsList()
		{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		
		if($_GET['companyId'] <> '')
		{
		   $comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		   $comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		   $branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		   $branchId = $_SESSION['branch_id'];
		}
			$Dashboard = 'SELECT * FROM arka_platform_mapping LEFT JOIN arka_iot_platform ON arka_platform_mapping.segmentCode=arka_iot_platform.slNo WHERE arka_platform_mapping.companyName="'.$comId.'" AND arka_platform_mapping.branch_id="'.$branchId.'" ORDER BY arka_iot_platform.slNo ASC';
			$Dashboard		= $this->ExecuteQuery($Dashboard, "select");
			$objSmarty->assign('Dashboard', $Dashboard);
		}
       /*********************  Segment Functions Ends *************************/
	   /********************* GetFeederList Functions Starts **************************/
	function GetFeederList()  
	{
		global $objSmarty;	
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}	
		$gatewayCode=base64_decode($_GET['gatewayCode']);
		$sensorCode=base64_decode($_GET['sensorCode']);
		
	    $SelFeederName = 'SELECT * FROM arka_sensor_master WHERE company_id ="'.$comId.'" AND branch_id ="'.$branchId.'" AND segmentName="Temperature" AND isActive="1"'; 
		$ListFeeder		= $this->ExecuteQuery($SelFeederName, "select");
		$objSmarty->assign('ListFeeder', $ListFeeder);	

		$SelSenso = 'SELECT * FROM feeder_master WHERE company_id ="'.$comId.'" AND branch_id ="'.$branchId.'" AND sensor_code="'.$sensorCode.'" AND is_active="1"'; 
		$ListSenso	= $this->ExecuteQuery($SelSenso, "select");
		$objSmarty->assign('ListSenso', $ListSenso);
	
	
	
	}	
	/********************* GetFeederList Functions Ends **************************/
	/********************* GetTemperature Functions Starts **************************/
	function GetTemperature() 
	{
		global $objSmarty;
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}
	
		$SelQuery = 'SELECT  `temperature_data_master_view`.recorded_date_time,`temperature_data_master_view`.sensor_code,`temperature_data_master_view`.gateway_code,`temperature_data_master_view`.sensor_model,`temperature_data_master_view`.temperature_c,`temperature_data_master_view`.temperature_f,`temperature_data_master_view`.humidity,`temperature_data_master_view`.recorded_date_time AS TZ,`arka_sensor_master`.sensorName AS feeder_name,`arka_sensor_master`.company_id,`arka_sensor_master`.branch_id,TIMESTAMPDIFF(SECOND, recorded_date_time, NOW()) AS secs FROM  `temperature_data_master_view`,`arka_sensor_master` WHERE  `temperature_data_master_view`.gateway_code =`arka_sensor_master`.gateway_id AND `temperature_data_master_view`.sensor_code =`arka_sensor_master`.sensorCode AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.isActive="1" AND arka_sensor_master.status="1" ' ;  		
		$TempList		= $this->ExecuteQuery($SelQuery, "select");
		$objSmarty->assign('TempList', $TempList);
		
		 $SelQuery='SELECT max(ping_log_id) AS ping_log_id, max(gateway_code) AS gateway_code,max(gateway_date_time) AS gateway_date_time FROM `gateway_ping_log` GROUP BY gateway_code ORDER BY ping_log_id';
	       $gateList= $this->ExecuteQuery($SelQuery, "select");//print_r($MeterList);
	       $objSmarty->assign('gateList', $gateList);
	       
	       $selQryS = 'SELECT * FROM `arka_sensor_master` WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.feeder_type="Sub Meter" GROUP BY sensorCode';	        
	       $selQryS		= $this->ExecuteQuery($selQryS, "select");
	    $objSmarty->assign('selQryS', $selQryS);
		
	if($_SESSION['CustomerId'] =='CUS1001')
	{ 
		$SelQueryAll = 'SELECT  `temperature_data_master`.* FROM  `temperature_data_master` ORDER BY  `temperature_data_master`.temperature_data_id DESC Limit 0,1' ;  
	}
	else
	{
		$SelQueryAll = 'SELECT  `temperature_data_master`.* FROM  `temperature_data_master` ORDER BY  `temperature_data_master`.temperature_data_id DESC Limit 0,1' ;
	}
		$TemperatureList		= $this->ExecuteQuery($SelQueryAll, "select");
		$objSmarty->assign('TemperatureList', $TemperatureList);		
	}
      /********************* GetTemperature Functions Ends **************************/
	  /********************* GetTempLogGraph Functions Starts **************************/
	function GetTempLogGraph()
	{
		global $objSmarty,$config,$nowDate;
		$pf='';
	if(isset($_POST['date1']) && isset($_POST['date2']))
	{
		$date1 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		$date2 = date("Y-m-d",strtotime(trim(addslashes($_POST['date2']))));
		$yaxis_par="temperature_c,temperature_f,humidity";
	
		$query_rs1 =  "SELECT ".$yaxis_par.",recorded_date_time AS TM FROM temperature_data_master WHERE gateway_code='".base64_decode($_GET['gatewayCode'])."' AND sensor_code='".base64_decode($_GET['sensorCode'])."' AND (DATE(recorded_date_time) BETWEEN '".$date1."' AND '".$date2."') ORDER BY TM ASC";
	}
	else
	{
		$yaxis_par="temperature_c,temperature_f,humidity";
		
		$query_rs1 = "SELECT ".$yaxis_par.",recorded_date_time AS TM FROM temperature_data_master WHERE gateway_code='".base64_decode($_GET['gatewayCode'])."' AND sensor_code='".base64_decode($_GET['sensorCode'])."' AND DATE(recorded_date_time) = DATE(CONVERT_TZ(NOW(),'+00:00' ,'+00:00')) ORDER BY TM ASC";
	}
		//echo $query_rs1;
		$GetTemp = $this->ExecuteQuery($query_rs1, "select");
		$objSmarty->assign('GetTemp', $GetTemp);
		$splVar= explode(",",$yaxis_par);
		$arrData = array();
	
	foreach ($GetTemp as $key => $value) 
	{
		$orgDate =$GetTemp[$key]['TM'];  
		$GDate = date("d-M-Y h:i A", strtotime($orgDate));
		array_push($arrData, array(
		$splVar[0] => $GetTemp[$key][$splVar[0]],
		$splVar[1] => $GetTemp[$key][$splVar[1]],
		$splVar[2] => $GetTemp[$key][$splVar[2]],
		"tm" => $GDate
	));
	}
		$ChartData = json_encode($arrData);
		$objSmarty->assign('ChartData', $ChartData);
	} 
     /********************* GetTempLogGraph Functions Ends **************************/
	 /********************* GetTempLog Functions Starts **************************/
	function GetTempLog()
	{
		global $objSmarty,$config,$nowDate;
	
	if(@$_POST['date1']!='' && @$_POST['date2'] !='')
	{
		$fDate = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		$tDate = date("Y-m-d",strtotime(trim(addslashes($_POST['date2']))));
		$GetQuery1 = 'SELECT posted_date_time AS M_TIMESTAMP,recorded_date_time,linux_date_time,teltonika_date_time,temperature_data_master.gateway_code,temperature_data_master.sensor_code,temperature_data_master.temperature_c,temperature_data_master.temperature_f,temperature_data_master.humidity FROM temperature_data_master WHERE gateway_code="'.base64_decode($_GET["gatewayCode"]).'" AND sensor_code="'.base64_decode($_GET["sensorCode"]).'" AND DATE(posted_date_time) BETWEEN "'.$fDate.'" AND "'.$tDate.'" GROUP BY M_TIMESTAMP ORDER BY temperature_data_id DESC';
	}
	else
	{	
		$GetQuery1 = 'SELECT posted_date_time AS M_TIMESTAMP,recorded_date_time,linux_date_time,teltonika_date_time,temperature_data_master.gateway_code,temperature_data_master.sensor_code,temperature_data_master.temperature_c,temperature_data_master.temperature_f,temperature_data_master.humidity FROM temperature_data_master WHERE gateway_code="'.base64_decode($_GET["gatewayCode"]).'" AND sensor_code="'.base64_decode($_GET["sensorCode"]).'" AND DATE(posted_date_time)=DATE(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE)) ORDER BY temperature_data_id DESC';	
	}
		$GetTemp = $this->ExecuteQuery($GetQuery1, "select");
		$objSmarty->assign('GetTemp', $GetTemp);
	} 
     /********************* GetTempLog Functions Ends **************************/
      /******************** IncidentLog Functions Starts **************************/
		function TemperatureIncidentLog()
		{
		global $objSmarty,$config;
		
	$selAllIncidentLog = 'SELECT temperature_c, sensor_code, temperature_data_id,humidity,recorded_date_time FROM ( SELECT temperature_c, sensor_code, temperature_data_id,humidity,recorded_date_time, @rn := IF(@prev = sensor_code, @rn + 1, 1) AS rn, @prev := sensor_code FROM temperature_data_master JOIN (SELECT @prev := NULL, @rn := 0) AS vars WHERE temperature_c NOT BETWEEN "21.0" AND "28.0" OR humidity NOT BETWEEN "55.0" AND "60.0" ORDER BY sensor_code, temperature_data_id DESC, temperature_c ) AS T1 WHERE rn <= 3';
			$allincidentList= $this->ExecuteQuery($selAllIncidentLog, "select");
			$objSmarty->assign('allincidentList', $allincidentList);
		}
		/*****************************Get Temperature Sensor**************************************************/
		
		function GetTemperatureSensor() 
	{
		global $objSmarty;
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}
	$senId = base64_decode($_GET['sensorCode']);
		$SelQuery = 'SELECT  `temperature_data_master_view`.recorded_date_time,`temperature_data_master_view`.sensor_code,`temperature_data_master_view`.gateway_code,`temperature_data_master_view`.sensor_model,`temperature_data_master_view`.temperature_c,`temperature_data_master_view`.temperature_f,`temperature_data_master_view`.humidity,`temperature_data_master_view`.recorded_date_time AS TZ,`arka_sensor_master`.sensorName,`arka_sensor_master`.company_id,`arka_sensor_master`.branch_id,TIMESTAMPDIFF(SECOND, recorded_date_time, NOW()) AS secs FROM  `temperature_data_master_view`,`arka_sensor_master` WHERE  `temperature_data_master_view`.gateway_code =`arka_sensor_master`.gateway_id AND `temperature_data_master_view`.sensor_code =`arka_sensor_master`.sensorCode AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.sensorCode="'.$senId.'" AND  arka_sensor_master.isActive="1" AND arka_sensor_master.status="1" ' ;  		
		$TempSenList		= $this->ExecuteQuery($SelQuery, "select");
		$objSmarty->assign('TempSenList', $TempSenList);
		
			$selIncidentLog = 'SELECT * FROM `temperature_data_master` where sensor_code="'.$senId.'" AND (temperature_c NOT BETWEEN "21.0" AND "28.0" OR humidity NOT BETWEEN "55.0" AND "60.0") ORDER BY recorded_date_time DESC LIMIT 0,11'; 
			$incidentList		= $this->ExecuteQuery($selIncidentLog, "select");
			$objSmarty->assign('incidentList', $incidentList);
		}
		/****************************************************************************************/
			 /********************* GetLineGraph Functions Starts **************************/
	function GetLineGraph(){
		global $objSmarty,$config,$nowDate;
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}
		$sensorCode = base64_decode($_GET['sensorCode']);
		$gatewayCode = base64_decode($_GET['gatewayCode']);
	
		$selLineGraph='SELECT DATE_FORMAT(recorded_date_time,"%h:%i %p") AS month_data, DATE_FORMAT(recorded_date_time,"%e-%b-%Y") AS recDate,sensor_code, gateway_code, temperature_c, humidity  FROM temperature_data_master WHERE gateway_code="'.$gatewayCode.'" AND sensor_code="'.$sensorCode.'" order by recorded_date_time DESC Limit 0,60';
		$ExeLineGraph		= $this->ExecuteQuery($selLineGraph, "select");
		$ExeLineGraphCount		= $this->ExecuteQuery($selLineGraph, "numrows");
		
	$objParmT='';
	$objParmH='';
	foreach($ExeLineGraph as $key2=>$value2)
	{
		$objParmT .='{"month": "'.$ExeLineGraph[$key2]["month_data"].'","rdate": "'.$ExeLineGraph[$key2]["recDate"].'","T": '.$ExeLineGraph[$key2]["temperature_c"].'},';
		$objParmH .='{"month": "'.$ExeLineGraph[$key2]["month_data"].'","rdate": "'.$ExeLineGraph[$key2]["recDate"].'","H": '.$ExeLineGraph[$key2]["humidity"].'},';
	}
	
	$objGraph='{
	"title": "Temperature",
	"balloonText": "[[title]]: <b>[[value]] </b> Time:<b> [[category]]</b>",
	"bullet": "round",
	"bulletSize": 6,
	"bulletBorderColor": "#ffffff",
	"bulletBorderAlpha": 1,
	"bulletBorderThickness": 2,
	"type": "smoothedLine",
	"valueField": "T"
	}';
	$objGraph2='{
	"title": "Humidity",
	"balloonText": "[[title]]: <b>[[value]] </b> Time:<b> [[category]]</b>",
	"bullet": "round",
	"bulletSize": 6,
	"bulletBorderColor": "#ffffff",
	"bulletBorderAlpha": 1,
	"bulletBorderThickness": 2,
	"type": "smoothedLine",
	"valueField": "H"
	}';
	
		
		$LineGraphData="[".rtrim($objGraph, ",")."]";
		$LineGraphData2="[".rtrim($objGraph2, ",")."]";
		$LineGraphDataT="[".rtrim($objParmT, ",")."]";
		$LineGraphDataH="[".rtrim($objParmH, ",")."]";
		
		$objSmarty->assign('LineGraphData',$LineGraphData);
		$objSmarty->assign('LineGraphData2',$LineGraphData2);
		$objSmarty->assign('LineGraphDataT',$LineGraphDataT);
		$objSmarty->assign('LineGraphDataH',$LineGraphDataH);
	}
    /********************* GetLineGraph Functions Ends **************************/
}
?>