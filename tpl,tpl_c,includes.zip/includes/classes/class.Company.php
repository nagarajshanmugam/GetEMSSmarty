<?php
     class Company extends MysqlFns
	{
       /********* Company Constructor Starts ********************************/
function Company()
{
	$this->LDDisplayPath= $config['SiteGlobalPath']."class.Company.php";
	global $config;
	global $objSmarty,$config;
	$tbl = $config['DBPrefix'];
	$this->MysqlFns();
	$this->Limit = 20;			
} 
     /********* Company Constructor Ends ********************************/
    /************************************************* ListCompany Functions Start ***************************************************************/

   function ListCompany($objArray)
    {
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$i=$_SESSION['USER_GROUP'];
		
		if($_POST['table_search'] <> '')
		{
			 $SelQuery='SELECT  * FROM `'.$tbl.'company_master` WHERE status="1" AND slNo<>"0" AND (companyMaster like "%'.$_POST['table_search'].'%" OR companyCode like "%'.$_POST['table_search'].'%" OR phone like "%'.$_POST['table_search'].'%" OR email like "%'.$_POST['table_search'].'%" OR companyLogo like "%'.$_POST['table_search'].'%" OR userLimit like "%'.$_POST['table_search'].'%" OR smsLimit like "%'.$_POST['table_search'].'%" OR address like "%'.$_POST['table_search'].'%" OR area like "%'.$_POST['table_search'].'%" OR city like "%'.$_POST['table_search'].'%" OR pincode like "%'.$_POST['table_search'].'%" OR state like "%'.$_POST['table_search'].'%" OR panNo like "%'.$_POST['table_search'].'%" OR gstin like "%'.$_POST['table_search'].'%" OR isActive like "%'.$_POST['table_search'].'%") ORDER BY userName DESC';
		}
		else
		{
		   $SelQuery = 'SELECT  * FROM `'.$tbl.'company_master` WHERE status="1" AND slNo<>"0" ';
		}	 
		$ListView = $this->ExecuteQuery($SelQuery, "select");
		$objSmarty->assign('ListView', $ListView);
		return $ListView;
    }		
     /************************************************* ListCompany Functions Ends ***************************************************************/
	 /************************************************* CompanyEditView Functions Starts ***********************************************************/

	function CompanyEditView($objArray)
	
	{
	    global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
    	if(isset($_GET['companyId'])){
    	$comId = base64_decode($_GET['companyId']);
		}else{
		$comId = $_SESSION['COMPANY_ID'];
		}
	
		$SelQuery = 'SELECT * FROM `'.$tbl.'company_master` WHERE slNo="'.$comId.'" AND status="1"'; 
		$ListEditView = $this->ExecuteQuery($SelQuery, "select");		
		$objSmarty->assign('ListEditView', $ListEditView);
		return $ListEditView;
	
	}
      /************************************************* CompanyEditView Functions Ends ***********************************************************/ 
	  /************************************************* EditCompany Functions Starts ***************************************************************/
	function EditCompany($objArray,$objFiles)
	{
			global $objSmarty,$config,$_POST,$objFiles;
			$tbl = $config['DBPrefix'];
		
		if((!$objArray['companyMaster'])){
			$objSmarty->assign('ErrorMessage', 'Company Master should not be blank');
			return false;
		}elseif(!$objArray['companyCode']){
			$objSmarty->assign('ErrorMessage', 'Company Code should not be blank');
			return false;
		}elseif(!$objArray['email']){
			$objSmarty->assign('ErrorMessage', 'Email should not be blank');
			return false;
		}elseif(!$objArray['userLimit']){
			$objSmarty->assign('ErrorMessage', 'User Limit should not be blank');
			return false;
		}elseif(!$objArray['smsLimit']){
			$objSmarty->assign('ErrorMessage', 'SMS Limit should not be blank');
			return false;
		}elseif(!$objArray['address']){
			$objSmarty->assign('ErrorMessage', 'Address should not be blank');
			return false;
		}elseif(!$objArray['city']){
			$objSmarty->assign('ErrorMessage', 'City should not be blank');
			return false;
		}elseif(!$objArray['pincode']){
			$objSmarty->assign('ErrorMessage', 'Pincode should not be blank');
			return false;
		}elseif(!$objArray['state']){
			$objSmarty->assign('ErrorMessage', 'State should not be blank');
			return false;
		}
		
		list ($name,$format) = split("[.]", $_FILES['image']['name'],2);
		$uploadpath = $config['CompanyImageUpload']; 
		if($_FILES['image']["name"] <> "")
		{	
			$errors     = array();
			$maxsize    = 5242880;
			$fileinfo = getimagesize($_FILES["image"]["tmp_name"]);
			$width = $fileinfo[0];
			$height = $fileinfo[1];
			$acceptable = array('jpg','png');
			$target_file = $uploadpath . basename($_FILES["image"]["name"]);
			$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
		/* Check Image Type */		
		if($imageFileType != "jpg" && $imageFileType != "png" ) 
		{
			$errors3[] =  "Only  JPG and PNG types are accepted"; 
		}
		/* Check Image Size */	
		if(($_FILES['image']['size'] >= $maxsize) || ($_FILES["image"]["size"] == 0)) 
		{
			$errors2[] = 'File is too large. File must be less than 1 MB';
		}
		/* Check Image Width and Height */	
		if($width > 250 && $height > 55 ) 
		{
			$errors4[] = "Image Width and Height Should be 250 * 55";  		
		}
		if(count($errors2)  === 0 && count($errors3)  === 0 && count($errors4)  === 0) 
		{
			if((!file_exists($config['CompanyImageUpload'] . $_FILES["image"]["name"])))
			{  
				$f1 = $_FILES['image']['name'];
				if(move_uploaded_file($_FILES['image']['tmp_name'], $uploadpath.$f1))
				chmod($uploadpath.$f1,0755);
			}
			elseif((file_exists($config['CompanyImageUpload'] . $_FILES["image"]["name"]))) 
			{	
				$f1 = explode(".", $_FILES['image']['name']);
				$newfilename = round(microtime(true)) . '.' . end($f1);
				if(move_uploaded_file($_FILES['image']['tmp_name'], $uploadpath.$newfilename))
				chmod($uploadpath.$newfilename,0755);
				$f1=$newfilename;  
			}
		}
		else 
		{	
		if (is_array($errors2) || is_object($error2))
		{
		foreach($errors2 as $error2) 
		{
			$objSmarty->assign('ErrorMessage', $error2);
			return false;			
		}
		}
		if (is_array($errors3) || is_object($error3))
		{
		foreach($errors3 as $error3) 
		{
			$objSmarty->assign('ErrorMessage', $error3);
			return false;
		}
		}
		if (is_array($errors4) || is_object($error4))
		{
		foreach($errors4 as $error4) 
		{
			$objSmarty->assign('ErrorMessage', $error4);
			return false;
		}
		}	
		}
		}
		else
		{
			$f1=$objArray['imageName'];
		}
			list ($name,$format) = split("[.]", $_FILES['smallImage']['name'],2);
			$uploadpath = $config['CompanyImageSmallUpload'];  
		if($_FILES['smallImage']["name"] <> "")
		{	
			$errors     = array();
			$maxsize    = 40000;
			$fileinfo = getimagesize($_FILES["smallImage"]["tmp_name"]);
			$width = $fileinfo[0];
			$height = $fileinfo[1];
			$acceptable = array('jpg','png');
			$target_file = $uploadpath . basename($_FILES["smallImage"]["name"]);
			$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
		/* Check Image Type */		
		if($imageFileType != "jpg" && $imageFileType != "png" ) 
		{
			$error3smalls[] =  "Only  JPG and PNG types are accepted"; 
		}
		/* Check Image Size */	
		if(($_FILES['smallImage']['size'] >= $maxsize) || ($_FILES["smallImage"]["size"] == 0)) 
		{
			$error2smalls[] = 'File is too large. File must be less than 1 MB';
		}
		/* Check Image Width and Height */	
		if($width > 75 && $height > 60 ) 
		{
			$errors4smalls[] = "Image Width and Height Should be 75 * 60";  
		}
		if(count($error2smalls)  === 0 && count($error3smalls)  === 0 && count($errors4smalls)  === 0) 
		{
		if((!file_exists($config['CompanyImageSmallUpload'] . $_FILES["smallImage"]["name"])))
		{  
			$f2 = $_FILES['smallImage']['name'];
		if(move_uploaded_file($_FILES['smallImage']['tmp_name'], $uploadpath.$f2))
			chmod($uploadpath.$f2,0755);		
		}
		elseif((file_exists($config['CompanyImageSmallUpload'] . $_FILES["smallImage"]["name"]))) 
		{	
			$f2 = explode(".", $_FILES['smallImage']['name']);
			$newfilename = round(microtime(true)) . '.' . end($f2);
			if(move_uploaded_file($_FILES['smallImage']['tmp_name'], $uploadpath.$newfilename))
			chmod($uploadpath.$newfilename,0755);
			$f2=$newfilename;  
		}
		}
		else{
		if (is_array($error2smalls) || is_object($error2small))
		{
		foreach($error2smalls as $error2small) 
		{
			$objSmarty->assign('ErrorMessage', $error2small);
			return false;			
		}
		}
		if (is_array($error3smalls) || is_object($error3small))
		{
		foreach($error3smalls as $error3small) 
		{
			$objSmarty->assign('ErrorMessage', $error3small);
			return false;
		}
		}
		if (is_array($errors4smalls) || is_object($error4small))
		{
		foreach($errors4smalls as $error4small) 
		{
			$objSmarty->assign('ErrorMessage', $error4small);
			return false;
		}
		}
		}
		}
		else
		{
			$f2=$objArray['smallImageName'];
		}
			$objSmarty->assign('companyId', $objArray['companyId']);
		if($objArray['companyId'] && $objArray['companyMaster'])
		{
		
			$UpQuery = 'UPDATE `'.$tbl.'company_master` SET 
			`companyName`="'.trim($objArray['companyMaster']).'",
			`companyCode`="'.trim($objArray['companyCode']).'",
			`contactPerson`="'.trim($objArray['contactPerson']).'",
			`phone`="'.trim($objArray['phone']).'",
			`email`="'.trim($objArray['email']).'",
			`companyLogo`="'.$f1.'",
			`companyLogoSmall`="'.$f2.'",
			`userLimit`="'.trim($objArray['userLimit']).'",
			`smsLimit`="'.trim($objArray['smsLimit']).'",
			`address`="'.trim($objArray['address']).'",
			`area`="'.trim($objArray['area']).'",
			`city`="'.trim($objArray['city']).'",
			`pincode`="'.trim($objArray['pincode']).'",
			`state`="'.trim($objArray['state']).'",
			`panNo`="'.trim($objArray['panNo']).'",
			`gstin`="'.trim($objArray['gstNo']).'",
			`billing_module`="'.trim($objArray['billModVal']).'",
			`isActive`="'.trim($objArray['checkVal']).'",
			`createdBy`="'.trim($objArray['created_by']).'"
			WHERE 
			`slNo` ="'.trim($objArray['companyId']).'"'; 
			$this->ExecuteQuery($UpQuery, 'update');
		}
			header('Location:companyList.php?success_msg_for_update');  
	}

      /************************************************* EditCompany Functions Ends ***************************************************************/
	  /*************************************************InsertCompany Functions Starts ***************************************************************/

	function InsertCompany($objArray,$objFiles)
	{
		global $objSmarty,$config,$_POST,$objFiles;
		$tbl = $config['DBPrefix'];
		
		if((!$objArray['companyMaster'])){
			$objSmarty->assign('ErrorMessage', 'Company Master should not be blank');
			return false;
		}elseif(!$objArray['companyCode']){
			$objSmarty->assign('ErrorMessage', 'Company Code should not be blank');
			return false;
		}elseif(!$objArray['contactPerson']){
			$objSmarty->assign('ErrorMessage', 'Contact Person should not be blank');
			return false;
		}elseif(!$objArray['email']){
			$objSmarty->assign('ErrorMessage', 'Email should not be blank');
			return false;
		}elseif(!$objArray['userLimit']){
			$objSmarty->assign('ErrorMessage', 'User Limit should not be blank');
			return false;
		}elseif(!$objArray['smsLimit']){
			$objSmarty->assign('ErrorMessage', 'SMS Limit should not be blank');
			return false;
		}elseif(!$objArray['address']){
			$objSmarty->assign('ErrorMessage', 'Address should not be blank');
			return false;
		}elseif(!$objArray['city']){
			$objSmarty->assign('ErrorMessage', 'City should not be blank');
			return false;
		}elseif(!$objArray['pincode']){
			$objSmarty->assign('ErrorMessage', 'Pincode should not be blank');
			return false;
		}elseif(!$objArray['state']){
			$objSmarty->assign('ErrorMessage', 'State should not be blank');
			return false;
		}
			list ($name,$format) = split("[.]", $_FILES['image']['name'],2);
				$uploadpath = $config['CompanyImageUpload']; 
				if($_FILES['image']["name"] <> "")
				{	
						$errors     = array();
						$maxsize    = 5242880;
						$fileinfo = getimagesize($_FILES["image"]["tmp_name"]);
						$width = $fileinfo[0];
						$height = $fileinfo[1];
						$acceptable = array('jpg','png');
						$target_file = $uploadpath . basename($_FILES["image"]["name"]);
						$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
						/* Check Image Type */		
						if($imageFileType != "jpg" && $imageFileType != "png" ) 
						{
							   $errors3[] =  "Only  JPG and PNG types are accepted"; 
						}
						/* Check Image Size */	
						if(($_FILES['image']['size'] >= $maxsize) || ($_FILES["image"]["size"] == 0))
						 {
							 $errors2[] = 'File is too large. File must be less than 1 MB';
						}
						/* Check Image Width and Height */	
						if($width > 250 && $height > 55 ) 
						{
							$errors4[] = "Image Width and Height Should be 250 * 55";  
						}
				
			if(count($errors2)  === 0 && count($errors3)  === 0 && count($errors4)  === 0) 
				{
					if((!file_exists($config['CompanyImageUpload'] . $_FILES["image"]["name"])))
					{  
						$f1 = $_FILES['image']['name'];
						if(move_uploaded_file($_FILES['image']['tmp_name'], $uploadpath.$f1))
						chmod($uploadpath.$f1,0755);
					}
					elseif((file_exists($config['CompanyImageUpload'] . $_FILES["image"]["name"]))) 
					{	
						$f1 = explode(".", $_FILES['image']['name']);
						$newfilename = round(microtime(true)) . '.' . end($f1);
						if(move_uploaded_file($_FILES['image']['tmp_name'], $uploadpath.$newfilename))
						chmod($uploadpath.$newfilename,0755);
						$f1=$newfilename;  
					}
				}
					else 
					{	
						if (is_array($errors2) || is_object($error2))
				   {
					foreach($errors2 as $error2) 
					{
						$objSmarty->assign('ErrorMessage', $error2);
						return false;			
					}
				 }
					if (is_array($errors3) || is_object($error3))
			  {
					foreach($errors3 as $error3) 
					{
						$objSmarty->assign('ErrorMessage', $error3);
						return false;
					}
			 }
				if (is_array($errors4) || is_object($error4))
			  {
					foreach($errors4 as $error4) 
					{
						$objSmarty->assign('ErrorMessage', $error4);
						return false;
					}
			 }	
				}
			}
			else
			{
				$f1="";
			}
			
			list ($name,$format) = split("[.]", $_FILES['smallImage']['name'],2);
			
				 $uploadpath = $config['CompanyImageSmallUpload'];  
				if($_FILES['smallImage']["name"] <> "")
				{	
						$errors     = array();
						$maxsize    = 40000;
						$fileinfo = getimagesize($_FILES["smallImage"]["tmp_name"]);
						$width = $fileinfo[0];
						$height = $fileinfo[1];
						$acceptable = array('jpg','png');
						$target_file = $uploadpath . basename($_FILES["smallImage"]["name"]);
						$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
				/* Check Image Type */		
						if($imageFileType != "jpg" && $imageFileType != "png" ) 
						{
							   $error3smalls[] =  "Only  JPG and PNG types are accepted"; 
						}
				/* Check Image Size */	
						if(($_FILES['smallImage']['size'] >= $maxsize) || ($_FILES["smallImage"]["size"] == 0))
						 {
							 $error2smalls[] = 'File is too large. File must be less than 1 MB';
						}
				/* Check Image Width and Height */	
						if($width > 75 && $height > 60 ) 
						{
							$errors4smalls[] = "Image Width and Height Should be 75 * 60";  
						}
					   if(count($error2smalls)  === 0 && count($error3smalls)  === 0 && count($errors4smalls)  === 0) 
					   {
							if((!file_exists($config['CompanyImageSmallUpload'] . $_FILES["smallImage"]["name"])))
							{  
								$f2 = $_FILES['smallImage']['name'];
								if(move_uploaded_file($_FILES['smallImage']['tmp_name'], $uploadpath.$f2))
								chmod($uploadpath.$f2,0755);
							}
							elseif((file_exists($config['CompanyImageSmallUpload'] . $_FILES["smallImage"]["name"]))) 
							{	
							   $f2 = explode(".", $_FILES['smallImage']['name']);
								$newfilename = round(microtime(true)) . '.' . end($f2);
								if(move_uploaded_file($_FILES['smallImage']['tmp_name'], $uploadpath.$newfilename))
								chmod($uploadpath.$newfilename,0755);
								$f2=$newfilename;  
							}
					}
				else{
				if (is_array($error2smalls) || is_object($error2small))
			  {
					foreach($error2smalls as $error2small) 
					{
						$objSmarty->assign('ErrorMessage', $error2small);
						return false;			
					}
			 }
			 
			 if (is_array($error3smalls) || is_object($error3small))
			  {
					foreach($error3smalls as $error3small) 
					{
						$objSmarty->assign('ErrorMessage', $error3small);
						return false;
					}
			}
			if (is_array($errors4smalls) || is_object($error4small))
			  {
					foreach($errors4smalls as $error4small) 
					{
						$objSmarty->assign('ErrorMessage', $error4small);
						return false;
					}
				}
				}
			}
			else
			{
				$f2="";
			}
		if($objArray['companyCode'] && $objArray['companyMaster'])
		{
			  $InsQuery = 'INSERT INTO `'.$tbl.'company_master`
			(
			`companyName`,
			`companyCode`,
			`contactPerson`,
			`phone`,
			`email`,
			`companyLogo`,
			`companyLogoSmall`,
			`userLimit`,
			`smsLimit`,
			`address`,
			`area`,
			`city`,
			`pincode`,
			`state`,
			`panNo`,
			`gstin`,
			`billing_module`,
			`isActive`,
			`createdBy`
			) 
			VALUES(
			"'.trim(addslashes($objArray['companyMaster'])).'",
			"'.trim(addslashes($objArray['companyCode'])).'",
			"'.trim(addslashes($objArray['contactPerson'])).'",
			"'.trim(addslashes($objArray['phone'])).'",
			"'.trim(addslashes($objArray['email'])).'",
			"'.$f1.'",
			"'.$f2.'",
			"'.trim(addslashes($objArray['userLimit'])).'",
			"'.trim(addslashes($objArray['smsLimit'])).'",
			"'.trim(addslashes($objArray['address'])).'",
			"'.trim(addslashes($objArray['area'])).'",
			"'.trim(addslashes($objArray['city'])).'",
			"'.trim(addslashes($objArray['pincode'])).'",
			"'.trim(addslashes($objArray['state'])).'",
			"'.trim(addslashes($objArray['panNo'])).'",
			"'.trim(addslashes($objArray['gstin'])).'",
			"'.trim(addslashes($objArray['billModVal'])).'",
			"'.trim(addslashes($objArray['checkVal'])).'",
			"'.trim(addslashes($objArray['created_by'])).'")'; 
			$this->ExecuteQuery($InsQuery, 'insert');
		}
			header('Location:companyList.php?success_msg_for_insert');
	}

     /*************************************************InsertCompany Functions Ends ***************************************************************/
     /************************************************* Company Update Functions Starts ***************************************************************/
	function CompanyUpdate($objArray,$objFiles)
	{
		global $objSmarty,$config,$_POST,$objFiles;
		$tbl = $config['DBPrefix'];
		if((!$objArray['companyMaster'])){
			$objSmarty->assign('ErrorMessage', 'Company Master should not be blank');
			return false;
		}elseif(!$objArray['email']){
			$objSmarty->assign('ErrorMessage', 'Email should not be blank');
			return false;
		}elseif(!$objArray['address']){
			$objSmarty->assign('ErrorMessage', 'Address should not be blank');
			return false;
		}elseif(!$objArray['city']){
			$objSmarty->assign('ErrorMessage', 'City should not be blank');
			return false;
		}elseif(!$objArray['pincode']){
			$objSmarty->assign('ErrorMessage', 'Pincode should not be blank');
			return false;
		}elseif(!$objArray['state']){
			$objSmarty->assign('ErrorMessage', 'State should not be blank');
			return false;
		}
		
		list ($name,$format) = split("[.]", $_FILES['image']['name'],2);
		$uploadpath = $config['CompanyImageUpload']; 
		if($_FILES['image']["name"] <> "")
		{	
			$errors     = array();
			$maxsize    = 5242880;
			$fileinfo = getimagesize($_FILES["image"]["tmp_name"]);
			$width = $fileinfo[0];
			$height = $fileinfo[1];
			$acceptable = array('jpg','png');
			$target_file = $uploadpath . basename($_FILES["image"]["name"]);
			$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
		/* Check Image Type */		
		if($imageFileType != "jpg" && $imageFileType != "png" ) 
		{
			$errors3[] =  "Only  JPG and PNG types are accepted"; 
		}
		/* Check Image Size */	
		if(($_FILES['image']['size'] >= $maxsize) || ($_FILES["image"]["size"] == 0)) 
		{
			$errors2[] = 'File is too large. File must be less than 1 MB';
		}
		/* Check Image Width and Height */	
		if($width > 250 && $height > 55 ) 
		{
			$errors4[] = "Image Width and Height Should be 250 * 55";  		
		}
		if(count($errors2)  === 0 && count($errors3)  === 0 && count($errors4)  === 0) 
		{
			if((!file_exists($config['CompanyImageUpload'] . $_FILES["image"]["name"])))
			{  
				$f1 = $_FILES['image']['name'];
				if(move_uploaded_file($_FILES['image']['tmp_name'], $uploadpath.$f1))
				chmod($uploadpath.$f1,0755);
			}
			elseif((file_exists($config['CompanyImageUpload'] . $_FILES["image"]["name"]))) 
			{	
				$f1 = explode(".", $_FILES['image']['name']);
				$newfilename = round(microtime(true)) . '.' . end($f1);
				if(move_uploaded_file($_FILES['image']['tmp_name'], $uploadpath.$newfilename))
				chmod($uploadpath.$newfilename,0755);
				$f1=$newfilename;  
			}
		}
		else 
		{	
		if (is_array($errors2) || is_object($error2))
		{
		foreach($errors2 as $error2) 
		{
			$objSmarty->assign('ErrorMessage', $error2);
			return false;			
		}
		}
		if (is_array($errors3) || is_object($error3))
		{
		foreach($errors3 as $error3) 
		{
			$objSmarty->assign('ErrorMessage', $error3);
			return false;
		}
		}
		if (is_array($errors4) || is_object($error4))
		{
		foreach($errors4 as $error4) 
		{
			$objSmarty->assign('ErrorMessage', $error4);
			return false;
		}
		}	
		}
		}
		else
		{
			$f1=$objArray['imageName'];
		}
			list ($name,$format) = split("[.]", $_FILES['smallImage']['name'],2);
			$uploadpath = $config['CompanyImageSmallUpload'];  
		if($_FILES['smallImage']["name"] <> "")
		{	
			$errors     = array();
			$maxsize    = 40000;
			$fileinfo = getimagesize($_FILES["smallImage"]["tmp_name"]);
			$width = $fileinfo[0];
			$height = $fileinfo[1];
			$acceptable = array('jpg','png');
			$target_file = $uploadpath . basename($_FILES["smallImage"]["name"]);
			$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
		/* Check Image Type */		
		if($imageFileType != "jpg" && $imageFileType != "png" ) 
		{
			$error3smalls[] =  "Only  JPG and PNG types are accepted"; 
		}
		/* Check Image Size */	
		if(($_FILES['smallImage']['size'] >= $maxsize) || ($_FILES["smallImage"]["size"] == 0)) 
		{
			$error2smalls[] = 'File is too large. File must be less than 1 MB';
		}
		/* Check Image Width and Height */	
		if($width > 75 && $height > 60 ) 
		{
			$errors4smalls[] = "Image Width and Height Should be 75 * 60";  
		}
		if(count($error2smalls)  === 0 && count($error3smalls)  === 0 && count($errors4smalls)  === 0) 
		{
		if((!file_exists($config['CompanyImageSmallUpload'] . $_FILES["smallImage"]["name"])))
		{  
			$f2 = $_FILES['smallImage']['name'];
		if(move_uploaded_file($_FILES['smallImage']['tmp_name'], $uploadpath.$f2))
			chmod($uploadpath.$f2,0755);		
		}
		elseif((file_exists($config['CompanyImageSmallUpload'] . $_FILES["smallImage"]["name"]))) 
		{	
			$f2 = explode(".", $_FILES['smallImage']['name']);
			$newfilename = round(microtime(true)) . '.' . end($f2);
			if(move_uploaded_file($_FILES['smallImage']['tmp_name'], $uploadpath.$newfilename))
			chmod($uploadpath.$newfilename,0755);
			$f2=$newfilename;  
		}
		}
		else{
		if (is_array($error2smalls) || is_object($error2small))
		{
		foreach($error2smalls as $error2small) 
		{
			$objSmarty->assign('ErrorMessage', $error2small);
			return false;			
		}
		}
		if (is_array($error3smalls) || is_object($error3small))
		{
		foreach($error3smalls as $error3small) 
		{
			$objSmarty->assign('ErrorMessage', $error3small);
			return false;
		}
		}
		if (is_array($errors4smalls) || is_object($error4small))
		{
		foreach($errors4smalls as $error4small) 
		{
			$objSmarty->assign('ErrorMessage', $error4small);
			return false;
		}
		}
		}
		}
		else
		{
			$f2=$objArray['smallImageName'];
		}
			$objSmarty->assign('companyId', $objArray['companyId']);
			//echo $objArray['companyMaster']; //exit;
		if(isset($objArray['companyId']) && isset($objArray['companyMaster']))
		{
		
			 $UpQuery = 'UPDATE `'.$tbl.'company_master` SET 
			`companyName`="'.trim($objArray['companyMaster']).'",
			`contactPerson`="'.trim($objArray['contactPerson']).'",
			`phone`="'.trim($objArray['phone']).'",
			`email`="'.trim($objArray['email']).'",
			`companyLogo`="'.$f1.'",
			`companyLogoSmall`="'.$f2.'",
			`address`="'.trim($objArray['address']).'",
			`area`="'.trim($objArray['area']).'",
			`city`="'.trim($objArray['city']).'",
			`pincode`="'.trim($objArray['pincode']).'",
			`state`="'.trim($objArray['state']).'",
			`panNo`="'.trim($objArray['panNo']).'",
			`gstin`="'.trim($objArray['gstNo']).'" WHERE 
			`slNo` ="'.trim($objArray['companyId']).'"';  
			$this->ExecuteQuery($UpQuery, 'update');
		}
		header('Location:AddEditcompanyUpdate.php?success_msg_for_update');  
	}

      /************************************************* Company Update Functions Ends ***************************************************************/

	 /*************************************************DeleteMaster Functions Starts ***************************************************************/
	function DeleteMaster($CatIdent)
	{
		global $objSmarty,$config;	
		$tbl = $config['DBPrefix'];
		
		$DelQuery = 'update `'.$tbl.'company_master` set `status`= 0 WHERE `slNo` ="'.$CatIdent.'"';
		$this->ExecuteQuery($DelQuery, 'update');
		header('Location:' .$_SERVER['PHP_SELF'].'?succs_msg_for_del');  
	}
    /*************************************************DeleteMaster Functions Ends ***************************************************************/
  }


?>