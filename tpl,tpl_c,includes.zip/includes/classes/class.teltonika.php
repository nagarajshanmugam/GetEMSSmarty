<?php
class teltonika extends MysqlFns
{
      /********* teltonika Constructor Starts ********************************/
	function teltonika()
	{
		$this->LDDisplayPath= $config['SiteGlobalPath']."class.teltonika.php";
		global $config;
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$this->MysqlFns();
		$this->Limit = 20;			
	}    
     /********* teltonika Constructor Ends ********************************/
     /*************************************** ListTeltonika Functions Starts *************************/

	function ListTeltonika()
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$i=$_SESSION['USER_GROUP'];
	
		$SelQuery = 'SELECT json_data,CONVERT_TZ(M_timestamp,"+00:00","+00:00") AS M_timestamp FROM `teltonika_json_data` ORDER BY sl_no DESC ';
		$ListView = $this->ExecuteQuery($SelQuery, "select");	
		$objSmarty->assign('ListView', $ListView);
		return $ListView;
	}		
     /*************************************** ListTeltonika Functions Ends *************************/
	 /*************************************** DeleteMaster Functions Starts *************************/
	function DeleteMaster()
	{
	global $objSmarty,$config;
	$tbl = $config['DBPrefix'];
	$DelQuery = 'TRUNCATE TABLE teltonika_json_data';
	$this->ExecuteQuery($DelQuery, 'update');
	header('Location:' .$_SERVER['PHP_SELF'].'?succs_msg_for_del');  
	
	}
     /*************************************** DeleteMaster Functions Ends *************************/
}
?>