<?php
 class ShiftMaster extends MysqlFns
 {
      /********* ShiftMaster Constructor Starts ********************************/
	function ShiftMaster()
	{
		$this->LDDisplayPath= $config['SiteGlobalPath']."class.ShiftMaster.php";
		global $config;
		global $objSmarty;
		global $nowDate;
		$this->Limit = 20;
		$ConLink1 = mysql_connect($config['DBHost'],$config['DBUser'],$config['DBPassword']) or die("Database Connection Failed<br>". mysql_error());
		mysql_select_db($config['DBName'], $ConLink1);
		if($config['DBUser'] != 'root')
		{
			$nowDate= 'DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE)';
		}
		else{
			$nowDate= 'NOW()';
		}
	}   
     /********* ShiftMaster Constructor Ends ********************************/
    /********* ListShiftMaster Functions Starts ********************************/
	function ListShiftMaster($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}
		$SelQuery = 'SELECT * FROM arka_branch_shift_master WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'"'; 
		$ListShiftView = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListShiftView', $ListShiftView);
		return $ListShiftView;
	}
     /********* ListShiftMaster Functions Ends ********************************/
	 /********* GetBranchName Functions Starts**********************************/
	function GetBranchName($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
	if($_GET['companyId'] <> ''){
		$comId = base64_decode($_GET['companyId']);
	}
	else{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$lId = base64_decode($_GET['branchId']);
	}else
	{
		$lId = $_SESSION['branch_id'];
	}
		$SelQuery = 'SELECT * FROM  `'.$tbl.'branch_master` WHERE company_id="'.$comId.'" AND sl_no="'.$lId.'" AND record_status="1"';  
		$BranchView = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('BranchView', $BranchView);
		return $BranchView;
	}
      /********* GetBranchName Functions Ends**********************************/
	  /********* ListEditView Functions Starts ********************************/
	function ListEditView($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$sid = base64_decode($_GET['shift_master_id']);
		$comId = base64_decode($_GET['companyId']);
		$bId = base64_decode($_GET['branchId']);
	
		$SelQuery = 'SELECT  * FROM `'.$tbl.'branch_shift_master` WHERE company_id="'.$comId.'" AND branch_id="'.$bId.'" AND shift_master_id="'.$sid.'"';      
		$ListEditView = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListEditView', $ListEditView);
		return $ListEditView;
	}
    /********* ListEditView Functions Ends ********************************/
	/********* EditShiftmaster Functions Starts ********************************/
	function EditShiftmaster($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}
		$shift_master_id = base64_decode($_GET['shift_master_id']);
	if(!$objArray['shiftNameTxt']){
		$objSmarty->assign('ErrorMessage', 'Shift Name should not be blank');
		return false;
	}
	elseif(!$objArray['startTimeTxt']){
		$objSmarty->assign('ErrorMessage', 'Start Time should not be blank');
		return false;
	}
	elseif(!$objArray['endTimeTxt']){
		$objSmarty->assign('ErrorMessage', 'End Time should not be blank');
		return false;
	}
	if($objArray['shiftNameTxt'])
	{
		$UpdateQuery = 'UPDATE `'.$tbl.
		'branch_shift_master` SET `shift_name`="'.trim(addslashes($objArray['shiftNameTxt'])).'",`start_time`="'.trim(addslashes($objArray['startTimeTxt'])).'",`end_time`="'.trim(addslashes($objArray['endTimeTxt'])).'",`is_active`="'.trim(addslashes($objArray['checkVal'])).'" WHERE shift_master_id="'.$shift_master_id.'"'; 
		$this->ExecuteQuery($UpdateQuery, 'update');
		header('Location:shiftList.php?companyId='.$_GET["companyId"].'&branchId='.$_GET["branchId"].'&success_msg_for_update');
	}
	}
     /********* EditShiftmaster Functions Ends ********************************/
	 /********* InsertShiftmaster Functions Starts ********************************/
	function InsertShiftmaster($objArray)
	{ 
		global $objSmarty,$config,$nowDate;
		$tbl = $config['DBPrefix'];
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}
	if(!$objArray['shiftNameTxt']){
		$objSmarty->assign('ErrorMessage', 'Shift Name should not be blank');
		return false;
	}
	elseif(!$objArray['startTimeTxt']){
		$objSmarty->assign('ErrorMessage', 'Start Time should not be blank');
		return false;
	}
	elseif(!$objArray['endTimeTxt']){
		$objSmarty->assign('ErrorMessage', 'End Time should not be blank');
		return false;
	}
	if($objArray['shiftNameTxt']){
	$InsQuery = 'INSERT INTO `'.$tbl.
		'branch_shift_master`(`shift_name`,`start_time`,`end_time`,`branch_id`,`company_id`,`is_active`,`status`) VALUES("'.trim(addslashes($objArray['shiftNameTxt'])).'","'.trim(addslashes($objArray['startTimeTxt'])).'","'.trim(addslashes($objArray['endTimeTxt'])).'","'.$branchId.'","'.$comId.'","'.trim(addslashes($objArray['checkVal'])).'","1")';
		$this->ExecuteQuery($InsQuery, 'insert');
		header('Location:shiftList.php?branchId='.$_GET["branchId"].'&companyId='.$_GET["companyId"].'&success_msg_for_insert');
	}
	}

     /********* InsertShiftmaster Functions Ends ********************************/
	 /********* DeleteShift Functions Starts ********************************/
	function DeleteShift($CatIdent)
	{
	global $objSmarty,$config;
	$tbl = $config['DBPrefix'];
	$shift_master_id = base64_decode($_GET['shift_master_id']);  
	
	$DelQuery = 'DELETE FROM  `'.$tbl.'branch_shift_master` WHERE `shift_master_id` ="'.$shift_master_id.'"'; 
	$this->ExecuteQuery($DelQuery, 'update');
	header('Location:' .$_SERVER['PHP_SELF'].'?companyId='.$_GET['companyId'].'&branchId='.$_GET['branchId'].'&succs_msg_for_del');  
	}
    /********* DeleteShift Functions Ends ********************************/

     }

?>