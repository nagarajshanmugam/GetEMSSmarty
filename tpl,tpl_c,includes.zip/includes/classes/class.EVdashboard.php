<?php
class EVdashboard extends mysqlFns
{
      /********* EVdashboard Constructor Starts ********************************/
	function EVdashboard()
	{
		$this->LDDisplayPath= $config['SiteGlobalPath']."class.EVdashboard.php";
		global $config;
		global $objSmarty;
		global $nowDate;
		$this->Limit = 20;
		$ConLink1 = mysql_connect($config['DBHost'],$config['DBUser'],$config['DBPassword']) or die("Database Connection Failed<br>". mysql_error());
		mysql_select_db($config['DBName'], $ConLink1);
		if($config['DBUser'] != 'root')
		{
			$nowDate= 'DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE)';
		}
		else{
			$nowDate= 'NOW()';
		}
	}
     /********* EVdashboard Constructor Ends ********************************/
     /********* evData Functions Starts ********************************/
 function  evData()
 {
	global $objSmarty,$config,$nowDate;
	$tbl = $config['DBPrefix'];
	$sqlSel='SELECT * FROM ev_meter_data_view WHERE gateway_code="TRB145-3"AND sensor_code="EVDC-1"';
	$evDatList		= $this->ExecuteQuery($sqlSel, "select");
	$objSmarty->assign('evDatList', $evDatList);
  }
     /********* evData Functions Ends ********************************/
}
?>