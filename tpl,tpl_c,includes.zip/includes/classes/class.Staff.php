<?php
	class Staff extends MysqlFns
	{
		/****************************************   Staff Function Starts    ********************************/
	function Staff()
	{
		global $objSmarty, $config;
		include_once "class.split_page_results.php";
		$this->MysqlFns();
		date_default_timezone_set('Asia/Kolkata');	
		if(!isset($_SESSION['UserName']) && !isset($_POST["username"]))
		{
			if(!isset($_COOKIE['UserName']) && !isset($_POST["username"]))
			{
				if( basename($_SERVER['PHP_SELF'])!="index.php")
				{
					Redirect("index.php");
				}
			}
		}	
	}
        /****************************************   Staff Function Ends    ********************************/
		/****************************************   chkStaffLogin Function Starts    ********************************/
		function chkStaffLogin($objArray)
		{
			global $objSmarty, $config;
			global $_SESSION;
			$tbl = $config['DBPrefix'];
			if ($_POST["emailId"] &&  $_POST["password"])
			{
				$Login	= $_POST["emailId"];
				$Password	= $_POST["password"];
				
				$SelQuery	= "SELECT * FROM ".$tbl."user_master WHERE `emailId` = '".($_POST["emailId"])."' AND `password` = '" .($_POST["password"]). "' AND isActive='1' LIMIT 0,1";
				$SelResult	= $this->ExecuteQuery($SelQuery, "select");
				
				$SelPlat	= 'SELECT * FROM `'.$tbl.'platform_mapping` WHERE `companyName` = "'.$SelResult[0]['company_id'].'" AND `branch_id` = "'.$SelResult[0]['branch_id'].'" AND isActive="1" AND status="1" ORDER BY segmentCode';
				$platList		= $this->ExecuteQuery($SelPlat, "select");
	
				$SelQueryU	= 'SELECT * FROM `'.$tbl.'user_group_master` WHERE `usergroupName` = "'.$SelResult[0]['userGroup'].'" AND isActive="1" AND status="1"';
				$GList		= $this->ExecuteQuery($SelQueryU, "select");
				
				$SelQueryC	= 'SELECT * FROM `'.$tbl.'company_master` WHERE `slNo` = "'.$SelResult[0]['company_id'].'" AND isActive="1" AND status="1"';
				$CList		= $this->ExecuteQuery($SelQueryC, "select");
				
				if(!empty($SelResult) && !empty($GList) && !empty($CList)) {
					$_SESSION['platformCode']	= $StaffLogin	= $platList[0]["segmentCode"];
					$_SESSION['User_ID']	= $StaffLogin	= $SelResult[0]['slNo'];
					$_SESSION['CustomerId']	= $StaffLogin	= $SelResult[0]['company_id'];
					$_SESSION['branch_id']	= $StaffLogin	= $SelResult[0]['branch_id'];
					$_SESSION['COMPANY_ID']	= $StaffLogin	= $SelResult[0]['company_id'];
					$_SESSION['billing_module']	= $StaffLogin	= $CList[0]['billing_module'];
					$_SESSION['UserImage']	= $StaffLogin	= $SelResult[0]['userImage'];
					$_SESSION['CompanyLogo']	= $StaffLogin	= $CList[0]['companyLogo'];
					$_SESSION['CompanyLogoSmall']	= $StaffLogin	= $CList[0]['companyLogoSmall'];
					$_SESSION['CompanyName']	= $StaffLogin	= $CList[0]['companyName'];
					$_SESSION['ChannelPartner']	= $StaffLogin	= $CList[0]['channel_partner'];
					$_SESSION['USER_GROUP']	= $StaffGroup	= $SelResult[0]['userGroup'];
					$_SESSION['USER_GROUPID']	= $StaffGroup	= $GList[0]['slNo'];
					$_SESSION['UserName']	= $StaffGroup	= $SelResult[0]['userName'];
					$_SESSION['Mobile']		= $StaffLogin	= $SelResult[0]['mobileNo'];
					$_SESSION['Email']	    = $StaffLogin	= $SelResult[0]['emailId'];
					$_SESSION['Phone']		= $StaffLogin	= $SelResult[0]['phone'];
					$_SESSION['Password']	= $StaffLogin	= $SelResult[0]['password'];
				
					if(!empty($_POST["remember"])) {
					
						setcookie ("UserName",$_SESSION['UserName'],time()+ (10 * 365 * 24 * 60 * 60));
						
						setcookie ("USER_GROUP",$_SESSION['USER_GROUP'],time()+ (10 * 365 * 24 * 60 * 60));
						
						setcookie ("CustomerId",$_SESSION['CustomerId'],time()+ (10 * 365 * 24 * 60 * 60));
						
						setcookie ("User_ID",$_SESSION['User_ID'],time()+ (10 * 365 * 24 * 60 * 60));
						
						setcookie ("Mobile",$_SESSION['Mobile'],time()+ (10 * 365 * 24 * 60 * 60));
						
						setcookie ("Email",$_SESSION['Email'],time()+ (10 * 365 * 24 * 60 * 60));
						
						setcookie ("Phone",$_SESSION['Phone'],time()+ (10 * 365 * 24 * 60 * 60));
						
						setcookie ("Password",$_SESSION['Password'],time()+ (10 * 365 * 24 * 60 * 60));
					
					}
					else{
						if(isset($_COOKIE["UserName"])) {
							setcookie ("UserName","");
						}
						if(isset($_COOKIE["USER_GROUP"])) {
							setcookie ("USER_GROUP","");
						}
						if(isset($_COOKIE["CustomerId"])) {
							setcookie ("CustomerId","");
						}
						if(isset($_COOKIE["User_ID"])) {
							setcookie ("User_ID","");
						}
						if(isset($_COOKIE["Mobile"])) {
							setcookie ("Mobile","");
						}
						if(isset($_COOKIE["Email"])) {
							setcookie ("Email","");
						}																
						if(isset($_COOKIE["Phone"])) {
							setcookie ("Phone","");
						}
						if(isset($_COOKIE["Password"])) {
							setcookie ("Password","");
						}								
					}
					$objSmarty->assign('SelResult', $SelResult);
					return true;
				}
				else{
					$objSmarty->assign('ErrorMessage', "Invalid User Name or Password !");
					return false;
				}
			}
		}
		/****************************************   chkStaffLogin Function Ends    ********************************/
		 /*********************  GetCompanyName Functions Starts ******************/ 
		function GetCompanyName()
		{
		   global $objSmarty;
		if($_GET['companyId'] <> '')
		{
		   $comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		    $comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		    $branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		    $branchId = $_SESSION['branch_id'];
		}
			$companyList = "SELECT * FROM arka_company_master WHERE slNo='".$comId."' AND status='1'";
			$companyDetail		= $this->ExecuteQuery($companyList, "select");
			$objSmarty->assign('companyDetail', $companyDetail);
		
			$branchList = "SELECT * FROM arka_branch_master WHERE sl_no='".$branchId."' AND record_status='1'";
			$branchDetail		= $this->ExecuteQuery($branchList, "select");
			$objSmarty->assign('branchDetail', $branchDetail);
		}
    /*********************  GetCompanyName Functions Ends ******************/ 
		/****************************************   RolesLists Function Starts    ********************************/
		
		function RolesLists()
		{
			global $objSmarty, $config;
			$tbl = $config['DBPrefix'];

			$SelQueryU	= 'SELECT * FROM `'.$tbl.'user_group_master` WHERE `usergroupName` = "'.$_SESSION['USER_GROUP'].'" AND status="1"';
			$GList		= $this->ExecuteQuery($SelQueryU, "select");
			$objSmarty->assign('GList', $GList);
		 $SelQueryM	= 'SELECT arka_user_group_mapping.menuType,arka_user_group_mapping.url,arka_user_group_mapping.faIcon,arka_user_role_master.menuName,arka_user_role_master.slNo FROM `arka_user_group_mapping`,`arka_user_role_master` WHERE groupName="'.$GList[0]['slNo'].'" AND arka_user_group_mapping.menuName= arka_user_role_master.slNo AND  arka_user_group_mapping.menuType="Main Menu" AND arka_user_group_mapping.isActive = 1 ORDER BY arka_user_group_mapping.priority ASC';
      /*  This comment  By Vishal On 11-June-2021   ******   Due to menu mapping concept issue arka_menu_platform_mapping
	  
	  if($_SESSION['USER_GROUP'] !='Branch Admin')
	   {
	   
	    $SelQueryM	= 'SELECT arka_user_group_mapping.menuType,arka_user_group_mapping.url,arka_user_group_mapping.faIcon,arka_user_role_master.menuName,arka_user_role_master.slNo FROM `arka_user_group_mapping`,`arka_user_role_master` WHERE groupName="'.$GList[0]['slNo'].'" AND arka_user_group_mapping.menuName= arka_user_role_master.slNo AND  arka_user_group_mapping.menuType="Main Menu" AND arka_user_group_mapping.isActive = 1 ORDER BY arka_user_group_mapping.priority ASC';
       }else{
	   
      $SelQueryM	= 'SELECT arka_user_role_master.menuType,arka_user_role_master.url,arka_user_role_master.faIcon,arka_user_role_master.menuName,arka_user_role_master.slNo FROM `arka_menu_platform_mapping`,`arka_user_role_master` WHERE company_id="'.$_SESSION['COMPANY_ID'].'" AND branch_id="'.$_SESSION['branch_id'].'" AND arka_menu_platform_mapping.role_id= arka_user_role_master.slNo GROUP BY arka_menu_platform_mapping.role_id ORDER BY arka_user_role_master.priority ASC';
      }*/
		$MainList		= $this->ExecuteQuery($SelQueryM, "select");
		$objSmarty->assign('MainList', $MainList);

     $SelQueryS	= 'SELECT arka_user_group_mapping.menuType,arka_user_group_mapping.url,arka_user_group_mapping.faIcon,arka_user_role_master.menuName,arka_user_role_master.parent_id FROM `arka_user_group_mapping`,`arka_user_role_master` WHERE groupName="'.$GList[0]['slNo'].'" AND arka_user_group_mapping.menuName= arka_user_role_master.slNo AND  arka_user_group_mapping.menuType="Sub Menu" AND arka_user_group_mapping.isActive = 1 ORDER BY arka_user_role_master.priority ASC';
        $SubList		= $this->ExecuteQuery($SelQueryS, "select");
		$objSmarty->assign('SubList', $SubList);

     $SelQueryI	= 'SELECT arka_user_group_mapping.menuType,arka_user_group_mapping.url,arka_user_group_mapping.faIcon,arka_user_role_master.menuName FROM `arka_user_group_mapping`,`arka_user_role_master` WHERE groupName="'.$GList[0]['slNo'].'" AND arka_user_group_mapping.menuName= arka_user_role_master.slNo AND  arka_user_group_mapping.menuType="Icon" AND arka_user_group_mapping.isActive = 1 ORDER BY arka_user_role_master.menuName DESC';
       $IconList		= $this->ExecuteQuery($SelQueryI, "select");//print_r($IconList);
       $objSmarty->assign('IconList', $IconList);

      $SelQueryB	= 'SELECT arka_user_group_mapping.menuType,arka_user_group_mapping.url,arka_user_group_mapping.faIcon,arka_user_role_master.menuName FROM `arka_user_group_mapping`,`arka_user_role_master` WHERE groupName="'.$GList[0]['slNo'].'" AND arka_user_group_mapping.menuName= arka_user_role_master.slNo AND  arka_user_group_mapping.menuType="Button" AND arka_user_group_mapping.isActive = 1';

		$ButtonList		= $this->ExecuteQuery($SelQueryB, "select");
		$objSmarty->assign('ButtonList', $ButtonList);
		
	

     }

		/****************************************   RolesLists Function Ends    ********************************/

	}
?>