<?php
class gatewayModel extends MysqlFns
{    
      /********* gatewayModel Constructor Starts ********************************/
	function gatewayModel()
	{
		$this->LDDisplayPath= $config['SiteGlobalPath']."class.gatewayModel.php";
		global $config;
		global $objSmarty;
		global $nowDate;
		$this->Limit = 20;
		$ConLink1 = mysql_connect($config['DBHost'],$config['DBUser'],$config['DBPassword']) or die("Database Connection Failed<br>". mysql_error());
		mysql_select_db($config['DBName'], $ConLink1);
		if($config['DBUser'] != 'root')
		{
			$nowDate= 'NOW()';
		}
		else{
			$nowDate= 'NOW()';
		}
	}
     /********* gatewayModel Constructor Ends ********************************/
     /********* ListGatewayModel Functions Starts ********************************/
	function ListGatewayModel($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
	
		$SelQuery = 'SELECT * FROM  model_master WHERE status="1"';  
		$ListView = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListView', $ListView);//print_r($ListView);exit;
		return $ListView;
	}
    /********* ListGatewayModel Functions Ends ********************************/
	/********* InsertGatewayModel Functions Starts ********************************/
	function InsertGatewayModel($objArray)
	{
			global $objSmarty,$config,$nowDate;
			$tbl = $config['DBPrefix'];
		if(!$objArray['modelCode']){
			$objSmarty->assign('ErrorMessage', 'Gateway Model Code should not be blank');
			return false;
		}elseif(!$objArray['modelName']){
			$objSmarty->assign('ErrorMessage', 'Gateway Model Name should not be blank');
			return false;
		}
		if($objArray['modelCode'] && $objArray['modelName']){
			$InsQuery = 'INSERT INTO `model_master`
			(`model_code`,`model_name`,`is_active`,`created_date_time`,`status`)
			VALUES(
			"'.trim(addslashes($objArray['modelCode'])).'","'.trim(addslashes($objArray['modelName'])).'","'.trim(addslashes($objArray['checkVal'])).'",'.$nowDate.',"1")';  
			$this->ExecuteQuery($InsQuery, 'insert');
			header('Location:gatewayModelList.php?success_msg_for_insert');
		}
	}	
     /********* InsertGatewayModel Functions Ends ********************************/
	 /********* ListEditView Functions Starts ********************************/
	function ListEditView($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$sId = base64_decode($_GET['slNo']);
		$SelQuery = 'SELECT * FROM  `model_master` WHERE sl_no="'.$sId.'" AND status="1"';  
		$ListEditView = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListEditView', $ListEditView);
		return $ListEditView;
	}
    /********* ListEditView Functions Ends ********************************/
	/********* EditGatewayModel Functions Starts ********************************/
	function EditGatewayModel($objArray)
	{
			 global $objSmarty,$config,$nowDate;
			 $tbl = $config['DBPrefix'];
		if(!$objArray['modelCode']){
			$objSmarty->assign('ErrorMessage', 'Gateway Model Code should not be blank');
			return false;
		}elseif(!$objArray['modelName']){
			$objSmarty->assign('ErrorMessage', 'Gateway Model should not be blank');
			return false;
		}
		if($objArray['modelCode'] && $objArray['modelName'])
		{
			  $UpdateQuery = 'UPDATE 
			  `model_master` 
			  SET 
			  `model_code`="'.trim(addslashes($objArray['modelCode'])).'",
			  `model_name`="'.trim(addslashes($objArray['modelName'])).'",
			  `is_active`="'.trim(addslashes($objArray['checkVal'])).'"  WHERE 
			  sl_no="'.$objArray['modelSlNo'].'"';
			 $this->ExecuteQuery($UpdateQuery, 'update');
			 header('Location:gatewayModelList.php?success_msg_for_update');
		}
	}
    /********* EditGatewayModel Functions Ends ********************************/





}

?>