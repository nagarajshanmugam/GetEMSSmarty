<?php
class Heinn_Dashboard extends MysqlFns
{
   /********************* DashBoard Constructor Starts *************************/
	function Heinn_Dashboard()
	{
		$this->LDDisplayPath= $config['SiteGlobalPath']."class.Heinn_Dashboard.php";
		global $config;
		global $objSmarty;
		global $nowDate;
		$this->Limit = 20;
		$ConLink1 = mysql_connect($config['DBHost'],$config['DBUser'],$config['DBPassword']) or die("Database Connection Failed<br>". mysql_error());
		mysql_select_db($config['DBName'], $ConLink1);
		if($config['DBUser'] != 'root')
		{
			$nowDate= 'NOW()';
		}
		else{
			$nowDate= 'NOW()';
		}
	}
   /********************* DashBoard Constructor Ends *************************/
   /********************* Heinn Lehman Dashboard  Starts  ***************************/
   function heinnDashboardLive(){
    global $objSmarty,$config,$nowDate;
	$tbl = $config['DBPrefix'];
	if($_GET['companyId'] <> '')
		{
		   $comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		   $comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		   $branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		   $branchId = $_SESSION['branch_id'];
		}
		if($branchId =='0')
		{
		   $whrClass='company_id="'.$comId.'"';
		}else
		{
		   $whrClass='company_id="'.$comId.'" AND branch_id="'.$branchId.'"';
		
		}
	$selDashboard='SELECT heinn_iot_data_master_view.*, arka_sensor_master.sensorName FROM heinn_iot_data_master_view,arka_sensor_master WHERE heinn_iot_data_master_view.sensor_code=arka_sensor_master.sensorCode AND '.$whrClass.' ';
	$exeDashboard= $this->ExecuteQuery($selDashboard, "select");
	$objSmarty->assign('exeDashboard', $exeDashboard);
   
   }
   /********************* Heinn Lehman Dashboard  Starts  ***************************/
  /******************** IncidentLog Functions Starts **************************/
		function IncidentLog()
		{
		global $objSmarty,$config,$nowDate;
		$tbl = $config['DBPrefix'];
		
		if($_GET['companyId'] <> '')
		{
		   $comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		   $comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		   $branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		   $branchId = $_SESSION['branch_id'];
		}
		if($branchId =='0')
		{
		   $whrClass='company_id="'.$comId.'"';
		}else
		{
		   $whrClass='company_id="'.$comId.'" AND branch_id="'.$branchId.'"';
		
		}
			$selIncidentLog = 'SELECT * FROM `alert_log_master` WHERE '.$whrClass.' ORDER BY recorded_date_time DESC LIMIT 0,3'; 
			$incidentList		= $this->ExecuteQuery($selIncidentLog, "select");
			$objSmarty->assign('incidentList', $incidentList);
		}
         /******************** IncidentLog Functions Ends **************************/
		   /********* LogReports Functions Starts ********************************/	
	function LogReports($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];

	if( isset($_POST['fromDate']) && isset($_POST['toDate'])){
		$whereClause='DATE(recorded_date_time) BETWEEN  "'.$_POST['fromDate'].'" AND "'.$_POST['toDate'].'"';
	}
	else{
		$whereClause='DATE(recorded_date_time)=DATE(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE))';
	}
		$SelQuery = 'SELECT recorded_date_time AS TM,machine_status,bearing_1_temperature FROM heinn_iot_data_master WHERE '.$whereClause.' ORDER BY recorded_date_time DESC '; 
		$ListLogRep = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListLogRep', $ListLogRep);
		return $ListLogRep;
	
	}
	    /********* LogReports Functions Ends ********************************/	
}
?>