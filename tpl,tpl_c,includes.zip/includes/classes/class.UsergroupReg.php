<?php
 class UsergroupReg extends MysqlFns
{
      /********* UsergroupReg Constructor Starts ********************************/
	function UsergroupReg()
	{
		$this->LDDisplayPath= $config['SiteGlobalPath']."class.UsergroupReg.php";
		global $config;
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$this->MysqlFns();
		$this->Limit = 20;
		$usrgroup_id = base64_decode($_GET["group_id"]);
	} 
     /********* UsergroupReg Constructor Ends ********************************/
     /************************************ ListGroup Functions Starts ***************************************************************/
	function ListGroup($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$i=$_SESSION['USER_GROUP'];
	if($_POST['table_search'] <> '')
	{
		$SelQuery='SELECT  * FROM `'.$tbl.'user_group_master` WHERE status = "1" AND (usergroupName like "%'.$_POST['table_search'].'%") ORDER BY usergroupName DESC';
	}
	else
	{
		$SelQuery = 'SELECT  * FROM `'.$tbl.'user_group_master` WHERE status = "1"';
	}	 
		$ListView = $this->ExecuteQuery($SelQuery, "select");
		$objSmarty->assign('ListView', $ListView);
		return $ListView;
	}	
        /************************************ ListGroup Functions Ends ***************************************************************/
		/************************************ RoleList Functions Starts ***************************************************************/
	function RoleList($objArray="")
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		
		$SelQuery = 'SELECT  * FROM `'.$tbl.'user_role_master` WHERE isActive = "1"';
		$RoleList = $this->ExecuteQuery($SelQuery, "select");
		$objSmarty->assign('RoleList', $RoleList);
		return $RoleList;
	}
     /************************************ RoleList Functions Ends ***************************************************************/
	 /************************************ GroupDetailview Functions Starts ***************************************************************/
	function GroupDetailview($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		
		$SelQuery = 'SELECT * FROM `'.$tbl.'user_group_master` WHERE slNo="'.$_GET['groupId'].'"';
		$ListEditView = $this->ExecuteQuery($SelQuery, "select");
		$objSmarty->assign('ListEditView', $ListEditView);
	
		$SelQuery = 'SELECT arka_user_group_mapping.menuType,arka_user_group_mapping.url,arka_user_group_mapping.menuName as slNo,arka_user_group_mapping.faIcon,arka_user_role_master.menuName FROM `arka_user_group_mapping`,`arka_user_role_master` WHERE groupName="'.$_GET['groupId'].'" AND arka_user_group_mapping.menuName= arka_user_role_master.slNo ORDER BY arka_user_group_mapping.menuName' ;
		$groupMapping		= $this->ExecuteQuery($SelQuery, "select");
		$objSmarty->assign('groupMapping',$groupMapping);
	
		$SelQuery1 = 'SELECT DISTINCT slNo,menuName,menuType FROM '.$tbl.'user_role_master where slNo not in(SELECT menuName FROM '.$tbl.'user_group_mapping where groupName="'.$_GET['groupId'].'") order by '.$tbl.'user_role_master.menuName';
		$uRoleList = $this->ExecuteQuery($SelQuery1, 'selectassoc');
		$objSmarty->assign('uRoleList',$uRoleList);
		return $uRoleList;
	}
    /************************************ GroupDetailview Functions Ends ***************************************************************/
	/************************************ InsertUserGroup Functions Starts ***************************************************************/
	function InsertUserGroup($objArray="")
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
	if(!$objArray['usergroupName']){
		$objSmarty->assign('ErrorMessage', 'Group Name should not be blank');
		return false;
	}
	if($this->ChkDuplicateUserGroup(trim(addslashes($objArray['usergroupName']))))
	{
		$InsQuery = 'INSERT INTO `'.$tbl.'user_group_master`
		(`usergroupName`,
		`isActive`,
		`status`,
		`createdBy`) 
		VALUES
		("'.trim(addslashes($objArray['usergroupName'])).'",
		"'.trim(addslashes($objArray['checkVal'])).'",
		"1",
		"'.trim(addslashes($objArray['created_by'])).'")';
		$this->ExecuteQuery($InsQuery, 'insert');
	
		$SelQuery = 'select * from `'.$tbl.'user_group_master` where slNo=(SELECT LAST_INSERT_ID())';
		$sView = $this->ExecuteQuery($SelQuery, "select");
		$objSmarty->assign('sView', $sView);
		$arrs = $objArray["dexam16"];
	
	foreach($arrs as $key=>$value)
	{
		$SelQuery = 'SELECT * FROM `'.$tbl.'user_role_master` WHERE slNo="'.$value.'"';
		$ListView = $this->ExecuteQuery($SelQuery, "select");
		$objSmarty->assign('ListView', $ListView);
	
		$InsQuery = 'INSERT INTO `'.$tbl.'user_group_mapping`(
		`groupName`,
		`menuName`,
		`menuType`,
		`faIcon`,
		`url`,
		`priority`,
		`isActive`) 
		VALUES(
		"'.$sView[0]['slNo'].'",
		"'.$value.'",
		"'.$ListView[0]['menuType'].'",
		"'.$ListView[0]['faIcon'].'",
		"'.$ListView[0]['url'].'",
		"'.$ListView[0]['priority'].'",
		"1")';
		$this->ExecuteQuery($InsQuery, 'insert');
	}
		header('Location:userGroupList.php?success_msg_for_insert');  
	}
	}
     /************************************ InsertUserGroup Functions Ends ***************************************************************/    
	 /************************************ ChkDuplicateUserGroup Functions Starts ***************************************************************/   
	function ChkDuplicateUserGroup($ug_no)
	{
		global $objSmarty,$config,$_POST;
		$tbl = $config['DBPrefix'];
		
		$SelQuery	= 'SELECT * FROM `'.$tbl.'user_group_master` WHERE `usergroupName` = "'.$ug_no.'" and status="1" Limit 0,1';
		$UGDetail = $this->ExecuteQuery($SelQuery, 'select');
	if(!empty($UGDetail) && is_array($UGDetail))
		return false;
	else
		return true;
	}
     /************************************ ChkDuplicateUserGroup Functions Ends ***************************************************************/   
	 /************************************ UpdateUserGroup Functions Starts ***************************************************************/ 
	function UpdateUserGroup($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$UpQuery = 'UPDATE 
		`'.$tbl.'user_group_master` 
		SET 
		`usergroupName` = "'.trim($objArray['usergroupName']).'",
		`status` = "1",
		`isActive` = "'.trim($objArray['checkVal']).'",
		`createdBy` = "'.trim($objArray['created_by']).'"
		WHERE 
		`slNo` ="'.trim($objArray['group']).'"';
		$this->ExecuteQuery($UpQuery, 'update');
	
		$DelQuery = 'DELETE FROM `'.$tbl.'user_group_mapping` WHERE `groupName` ="'.trim($objArray['group']).'"';
		$this->ExecuteQuery($DelQuery, 'delete');
		$objSmarty->assign('SuccessMessage', 'Group Deleted Successfully');
		$arrs = $objArray["dexam16"];
	
		$SelQuery = 'select * from `'.$tbl.'user_group_master` where slNo="'.trim($objArray['group']).'"';
		$sView = $this->ExecuteQuery($SelQuery, "select");
		$objSmarty->assign('sView', $sView);
	
	foreach($arrs as $key=>$value)
	{
		$SelQuery = 'SELECT * FROM `'.$tbl.'user_role_master` WHERE slNo="'.$value.'"';
		$ListView = $this->ExecuteQuery($SelQuery, "select");
		$objSmarty->assign('ListView', $ListView);
	
		$InsQuery = 'INSERT INTO `'.$tbl.'user_group_mapping`(
		`groupName`,
		`menuName`,
		`menuType`,
		`faIcon`,
		`url`,
		`priority`,
		`isActive`) 
		VALUES(
		"'.trim($objArray['group']).'",
		"'.$value.'",
		"'.$ListView[0]['menuType'].'",
		"'.$ListView[0]['faIcon'].'",
		"'.$ListView[0]['url'].'",
		"'.$ListView[0]['priority'].'",
		"1")';
		$this->ExecuteQuery($InsQuery, 'insert');
	}	
		header('Location:userGroupList.php?success_msg_for_update');  
	}
     /************************************ UpdateUserGroup Functions Ends ***************************************************************/
	 /************************************ DeleteMaster Functions Starts ***************************************************************/
function DeleteMaster($CatIdent)
{
	global $objSmarty,$config;
	$tbl = $config['DBPrefix'];
	$DelQuery = 'update `'.$tbl.'user_group_master` set `status` = 0 WHERE `slNo` ="'.$CatIdent.'"';
	$this->ExecuteQuery($DelQuery, 'update');
	header('Location:' .$_SERVER['PHP_SELF'].'?succs_msg_for_del');  
}
     /************************************ DeleteMaster Functions Ends ***************************************************************/
}
?>