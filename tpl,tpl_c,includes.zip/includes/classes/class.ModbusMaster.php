<?php
class ModbusMaster extends MysqlFns
{ 
     /********* ModbusMaster Constructor Starts ********************************/
	function ModbusMaster()
	{
		$this->LDDisplayPath= $config['SiteGlobalPath']."class.ModbusMaster.php";
		global $config;
		global $objSmarty;
		global $nowDate;
		$this->Limit = 20;
		$ConLink1 = mysql_connect($config['DBHost'],$config['DBUser'],$config['DBPassword']) or die("Database Connection Failed<br>". mysql_error());
		mysql_select_db($config['DBName'], $ConLink1);
		if($config['DBUser'] != 'root')
		{
			$nowDate= 'DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE)';
		}
		else{
			$nowDate= 'NOW()';
		}
	}
      /********* ModbusMaster Constructor Ends ********************************/
    
	 /********* ListSensorModel Functions Starts *************************/
	 function ListSensorModel()
	 {
		 global $objSmarty,$config;
		 $tbl = $config['DBPrefix'];
		  $SelSenMod = 'SELECT * FROM  `sensor_model_master` WHERE status="1" ORDER BY sensor_model_master.sl_no ';  
		 $SenModelList = $this->ExecuteQuery($SelSenMod, 'select');
		 $objSmarty->assign('SenModelList', $SenModelList);
		 return $SenModelList;
	 }
	 /********* ListSensorModel Functions Ends *******************************/
	
	
	
	
}
?>