<?php
 class Branch extends MysqlFns
{
      /********* Branch Constructor Starts ********************************/
	function Branch()
	{
		$this->LDDisplayPath= $config['SiteGlobalPath']."class.Branch.php";
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$comId = base64_decode($_GET['companyId']);
		$f2 = "locationCode.txt";
		$uploadpath = $config['QuotePath'];
		$myfile1 = fopen($f2, "w") or die("Unable to open file!");
		$SelQuery2	= 'SELECT DISTINCT branch_id  FROM `'.$tbl.'branch_master` WHERE company_id="'.$comId.'" AND record_status="1"';
		$LocList	= $this->ExecuteQuery($SelQuery2, 'select');
		if(!empty($LocList) && is_array($LocList))
		foreach($LocList as $key=>$value)
		{
			$LocList[$key]['LId'] = stripslashes($LocList[$key]['branch_id']);
			$names1 = $names1.$LocList[$key]['LId'].",";
		}
		fwrite($myfile1, $names1);
		fclose($myfile1);	
	}
     /********* Branch Constructor Ends ********************************/
    /********* ListBranch Functions Starts ********************************/
	function ListBranch($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> '')
		{
			$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
			$comId = $_SESSION['CustomerId'];
		}
			$SelQuery = 'SELECT * FROM  `'.$tbl.'branch_master` WHERE company_id="'.$comId.'" AND record_status="1"';  
			$ListView = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListView', $ListView);
		
			$SelQuery2 = 'SELECT `'.$tbl.'platform_mapping`.*,`'.$tbl.'iot_platform`.segmentName FROM  `'.$tbl.'platform_mapping`,`'.$tbl.'iot_platform` WHERE `'.$tbl.'platform_mapping`.segmentCode=`'.$tbl.'iot_platform`.slNo AND `'.$tbl.'platform_mapping`.companyName="'.$comId.'" AND `'.$tbl.'platform_mapping`.status="1" AND `'.$tbl.'platform_mapping`.isActive="1"';  
			$platformView = $this->ExecuteQuery($SelQuery2, 'select');
			$objSmarty->assign('platformView', $platformView);
	}
    /********* ListBranch Functions End ********************************/
	/*********ListEditView Functions Starts ********************************/
	  function ListEditView($objArray)
    {
		$sid = base64_decode($_GET['sl_no']);
		$mid = base64_decode($_GET['meter_id']);
		$comId = base64_decode($_GET['companyId']);
		$lId = base64_decode($_GET['branch_id']);
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		
		$SelQuery = 'SELECT * FROM  `'.$tbl.'branch_master` WHERE branch_id="'.$lId.'" AND sl_no="'.$sid.'"';    
		$ListEditView = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListEditView', $ListEditView);
		return $ListEditView;
    }
   /*********ListEditView Functions End ********************************/
   /********* EditBranch Functions Starts ********************************/
	function EditBranch($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
			$sid = base64_decode($_GET['sl_no']);
			$comId = base64_decode($_GET['companyId']);
			$bId = base64_decode($_GET['branch_id']);  
		
		if(!$objArray['branchId']){
			$objSmarty->assign('ErrorMessage', 'Branch Id should not be blank');
			return false;
		}elseif(!$objArray['branchName']){
			$objSmarty->assign('ErrorMessage', 'Branch Name should not be blank');
			return false;
		}
		
			if($objArray['branchId'] && $objArray['branchName'])
			{
	
				 $UpdateQuery = 'UPDATE `'.$tbl.
				'branch_master` SET `branch_id`="'.trim(addslashes($objArray['branchId'])).'",`branch_name`="'.trim(addslashes($objArray['branchName'])).'",`EB`="'.trim(addslashes($objArray['checkValEbMeter'])).'",`DG`="'.trim(addslashes($objArray['checkValDgMeter'])).'",`Solar`="'.trim(addslashes($objArray['checkValSolarMeter'])).'",`is_active`="'.trim(addslashes($objArray['checkVal'])).'",`created_by`="'.trim(addslashes($objArray['created_by'])).'", `record_status`="1" WHERE branch_id="'.$bId.'" AND company_id="'.$comId.'" AND sl_no="'.$sid.'"';   
				$this->ExecuteQuery($UpdateQuery, 'update');
				header('Location:branchList.php?companyId='.$_GET["companyId"].'&success_msg_for_update');
			}
	}
     /********* EditBranch Functions End ********************************/
	 /********* InsertBranch Functions Starts ********************************/
	function InsertBranch($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
			$sid = base64_decode($_GET['sl_no']);
			$mid = base64_decode($_GET['meter_id']);
			$comId = base64_decode($_GET['companyId']);
			$lId = base64_decode($_GET['branch_id']);
		if(!$objArray['branchId']){
			$objSmarty->assign('ErrorMessage', 'Branch Id should not be blank');
			return false;
		}elseif(!$objArray['branchName']){
			$objSmarty->assign('ErrorMessage', 'Branch Name should not be blank');
			return false;
		}
		if($objArray['branchId'] && $objArray['branchName']){
	
			 $InsQuery = 'INSERT INTO `'.$tbl.
			'branch_master`(`branch_id`,`branch_name`,`company_id`,`EB`,`DG`,`Solar`,`is_active`,`created_by`,`record_status`) VALUES("'.trim(addslashes($objArray['branchId'])).'","'.trim(addslashes($objArray['branchName'])).'","'.$comId.'","'.trim(addslashes($objArray['checkValEbMeter'])).'","'.trim(addslashes($objArray['checkValDgMeter'])).'","'.trim(addslashes($objArray['checkValSolarMeter'])).'","'.trim(addslashes($objArray['checkVal'])).'","'.trim(addslashes($objArray['created_by'])).'","1")';  
			$this->ExecuteQuery($InsQuery, 'insert');
			header('Location:branchList.php?companyId='.$_GET["companyId"].'&success_msg_for_insert');
		}
	}
      /********* InsertBranch Functions End ********************************/
	  /********* DeleteBranch Functions Starts ********************************/
	function DeleteBranch($CatIdent)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$comId = base64_encode($_GET['companyId']);
		echo $DelQuery = 'update `'.$tbl.'branch_master` set `record_status` = "0" WHERE `sl_no` ="'.$CatIdent.'"';
		$this->ExecuteQuery($DelQuery, 'update');
		header('Location:' .$_SERVER['PHP_SELF'].'?companyId='.$comId.'&success_msg_for_del');  
	}
     /********* DeleteBranch Functions End ********************************/
     /************************************************* BranchEditView Functions Starts ***********************************************************/

	function BranchEditView($objArray)
	
	{
	    global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
    	if(isset($_GET['companyId'])){
    	$comId = base64_decode($_GET['companyId']);
		}else{
		$comId = $_SESSION['COMPANY_ID'];
		}
		if($_GET['branchId'] <> '')
{
$branchId = base64_decode($_GET['branchId']);
}	
else
{
$branchId = $_SESSION['branch_id'];
}
	
		$SelQuery = 'SELECT * FROM `'.$tbl.'branch_master` WHERE sl_no="'.$branchId.'" AND company_id="'.$comId.'" AND record_status="1" AND is_active="1"'; 
		$ListEditView = $this->ExecuteQuery($SelQuery, "select");		
		$objSmarty->assign('ListEditView', $ListEditView);
		return $ListEditView;
	
	}
      /************************************************* BranchEditView Functions Ends ***********************************************************/ 
	  /********* EditBranchName Functions Starts ********************************/
	function EditBranchName($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
			$sid = base64_decode($_GET['sl_no']);
			$comId = base64_decode($_GET['companyId']);
			$bId = base64_decode($_GET['branch_id']);  
		
		if(!$objArray['branchId']){
			$objSmarty->assign('ErrorMessage', 'Branch Id should not be blank');
			return false;
		}elseif(!$objArray['branchName']){
			$objSmarty->assign('ErrorMessage', 'Branch Name should not be blank');
			return false;
		}
		
			if($objArray['branchId'] && $objArray['branchName'])
			{
	
				$UpdateQuery = 'UPDATE `'.$tbl.
				'branch_master` SET `branch_name`="'.trim(addslashes($objArray['branchName'])).'" WHERE sl_no="'.$objArray['branchId'].'" AND company_id="'.$objArray['companyId'].'"';  
				$this->ExecuteQuery($UpdateQuery, 'update');
					header('Location:branchAddEditUpdate.php?success_msg_for_update');  
			}
	}
     /********* EditBranchName Functions End ********************************/

}

?>