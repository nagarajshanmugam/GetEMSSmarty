<?php
class GatewayGroup extends mysqlFns
{
       /********* GatewayGroup Constructor Starts ********************************/
	function GatewayGroup()
	{
		$this->LDDisplayPath= $config['SiteGlobalPath']."class.GatewayGroup.php";
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$comId = base64_decode($_GET['companyId']);
		$f2 = "locationCode.txt";
		$uploadpath = $config['QuotePath'];
		$myfile1 = fopen($f2, "w") or die("Unable to open file!");
		$SelQuery2	= 'SELECT DISTINCT branch_id  FROM `'.$tbl.'branch_master` WHERE company_id="'.$comId.'" AND record_status="1"';
		$LocList	= $this->ExecuteQuery($SelQuery2, 'select');
		if(!empty($LocList) && is_array($LocList))
		foreach($LocList as $key=>$value)
		{
			$LocList[$key]['LId'] = stripslashes($LocList[$key]['branch_id']);
			$names1 = $names1.$LocList[$key]['LId'].",";
		}
		fwrite($myfile1, $names1);
		fclose($myfile1);
	}
      /********* GatewayGroup Constructor Ends ********************************/
     /********* ListGatewayGroup Functions Starts ********************************/
	function ListGatewayGroup($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> '')
		{
			$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
			$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
			$branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
			$branchId = $_SESSION['branch_id'];
		}
			$SelQuery = 'SELECT * FROM  `gateway_group_mapping` WHERE companyId="'.$comId.'" AND branchId="'.$branchId.'" AND status="1" GROUP BY groupName';  
			$ListView = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListView', $ListView);//print_r($ListView);exit;
			return $ListView;
	}
     /********* ListGatewayGroup Functions Ends ********************************/
	 /********* GetGatewayName Functions Starts ********************************/
	function GetGatewayName()
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
			if($_GET['companyId'] <> '')
		{
			$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
			$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
			$branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
			$branchId = $_SESSION['branch_id'];
		}

		$SelQuery = 'SELECT * FROM  `'.$tbl.'gateway_master` WHERE record_status="1" AND is_active="1" AND company_id="'.$comId
.'" AND branch_id="'.$branchId.'" AND sl_no NOT IN (SELECT DISTINCT gatewayId FROM gateway_group_mapping WHERE status="1" AND isActive="1" AND companyId="'.$comId.'" AND branchId="'.$branchId.'")';  
		$GetGatewayView = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('GetGatewayView', $GetGatewayView);//print_r($ListView);exit;
		return $GetGatewayView;
	}
      /********* GetGatewayName Functions Ends ********************************/
	  /********* ListEditView Functions Starts ********************************/
	function ListEditView($objArray)
	{
		$gid = base64_decode($_GET['groupName']);
		$comId = base64_decode($_GET['companyId']);
		$lId = base64_decode($_GET['branchId']);
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		
		$SelQuery = 'SELECT gateway_group_mapping.*,'.$tbl.'gateway_master.sl_no,'.$tbl.'gateway_master.place_of_installation,'.$tbl.'gateway_master.model FROM  `gateway_group_mapping`,`'.$tbl.'gateway_master` WHERE groupName="'.$gid.'" AND companyId="'.$comId.'" AND branchId="'.$lId.'" AND `'.$tbl.'gateway_master`.sl_no=gateway_group_mapping.gatewayId AND status="1"';    
		$ListEditView = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListEditView', $ListEditView);//print_r($ListView);exit;
		return $ListEditView;
	}
     /********* ListEditView Functions Ends ********************************/
	/********* InsertGatewayGroup Functions Starts ********************************/
	function InsertGatewayGroup($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
			$comId = base64_decode($_GET['companyId']);
			$branchId = base64_decode($_GET['branchId']);
		
		if(!$objArray['groupName']){
			$objSmarty->assign('ErrorMessage', 'Group Name should not be blank');
			return false;
		}
		if($objArray['groupName']){
			$role = $objArray['dexam16'];
		foreach($role as $key=>$value){
			$InsQuery = 'INSERT INTO `gateway_group_mapping`(`groupName`, `gatewayId`,`companyId`,`branchId`,`isActive`) VALUES("'.trim(addslashes($objArray['groupName'])).'","'.$value.'","'.trim(addslashes($objArray['companyId'])).'","'.trim(addslashes($objArray['branchId'])).'","'.trim(addslashes($objArray['checkVal'])).'")';
			$this->ExecuteQuery($InsQuery, 'insert');
		}
			header('Location:gatewayGroupList.php?companyId='.$_GET["companyId"].'&'.'branchId='.$_GET["branchId"].'&success_msg_for_insert');
		}
	}
     /********* InsertGatewayGroup Functions Ends ********************************/
	 /********* EditBranch Functions Starts ********************************/
	function EditBranch($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
			$sid = base64_decode($_GET['groupName']);
			$comId = base64_decode($_GET['companyId']);
			$bId = base64_decode($_GET['branchId']);  
		
		if(!$objArray['groupName']){
			$objSmarty->assign('ErrorMessage', 'Group Name should not be blank');
			return false;
		}
		if($objArray['groupName']){
		
			$DelQuery = 'DELETE FROM `gateway_group_mapping` WHERE `groupName` ="'.trim($objArray['groupName']).'"';
			$this->ExecuteQuery($DelQuery, 'delete');
			$role = $objArray['dexam16'];
		foreach($role as $key=>$value){
			$InsQuery = 'INSERT INTO `gateway_group_mapping`(`groupName`, `gatewayId`,`companyId`,`branchId`,`isActive`) VALUES("'.trim(addslashes($objArray['groupName'])).'","'.$value.'","'.trim(addslashes($objArray['companyId'])).'","'.trim(addslashes($objArray['branchId'])).'","'.trim(addslashes($objArray['checkVal'])).'")';
			$this->ExecuteQuery($InsQuery, 'insert');
		}
			header('Location:gatewayGroupList.php?companyId='.$_GET["companyId"].'&'.'branchId='.$_GET["branchId"].'&success_msg_for_update');
		}
	}
     /********* EditBranch Functions Ends ********************************/
	 /********* DeleteGatewayGroup Functions Starts ********************************/
function DeleteGatewayGroup($CatIdent)
{
	global $objSmarty,$config;
	$tbl = $config['DBPrefix'];
	$comId = base64_decode($_GET['companyId']);
	$branchId = base64_decode($_GET['branchId']);
	$gId = base64_decode($_GET['deleteName']);
	$DelQuery = 'update `gateway_group_mapping` set `status` = "0" WHERE `groupName` ="'.$gId.'" AND companyId="'.$comId.'" AND branchId="'.$branchId.'"';
	$this->ExecuteQuery($DelQuery, 'update');
	header('Location:gatewayGroupList.php?companyId='.$_GET["companyId"].'&'.'branchId='.$_GET["branchId"].'&success_msg_for_del');
}
 /********* DeleteGatewayGroup Functions Ends ********************************/



}
?>