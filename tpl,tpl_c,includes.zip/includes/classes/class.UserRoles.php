<?php
class UserRoles extends mysqlFns
{
     /********* UserRoles Constructor Starts ********************************/
	function UserRoles()
	{
		$this->LDDisplayPath= $config['SiteGlobalPath']."class.UserRoles.php";
		global $config;
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$this->MysqlFns();
		$this->Limit = 20;
	} 
      /********* UserRoles Constructor Ends ********************************/
     /************************ ListUserRole Functions Starts ***************************************************************/
	function ListUserRole($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$i=$_SESSION['USER_GROUP'];
		
		if($_POST['table_search'] <> '')
		{
			$SelQuery='SELECT  * FROM `'.$tbl.'user_role_master` WHERE status="1" AND (menuName like "%'.$_POST['table_search'].'%" OR menuType like "%'.$_POST['table_search'].'%" OR faIcon like "%'.$_POST['table_search'].'%" OR url like "%'.$_POST['table_search'].'%" OR priority like "%'.$_POST['table_search'].'%" OR isActive like "%'.$_POST['table_search'].'%") ORDER BY menuName DESC';
		}
		else
		{
			$SelQuery = 'SELECT  * FROM `'.$tbl.'user_role_master` WHERE status="1"';
		}	 
		
			$ListView = $this->ExecuteQuery($SelQuery, "select");
			$objSmarty->assign('ListView', $ListView);
			return $ListView;
	}	
      /************************ ListUserRole Functions Ends ***************************************************************/
	  /************************ ParentMenuList Functions Starts ***************************************************************/
	function ParentMenuList()
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
	
		$SelQuery = 'SELECT * FROM `'.$tbl.'user_role_master` WHERE menuType="Main Menu" AND status="1" AND isActive="1"';
		$ListparMenu = $this->ExecuteQuery($SelQuery, "select");
		$objSmarty->assign('ListparMenu', $ListparMenu);
		return $ListparMenu;
	}
    /************************ ParentMenuList Functions Ends ***************************************************************/
	/************************ InsertUserRole Functions Starts ***************************************************************/
	function InsertUserRole($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if(!$objArray['menuName']){
			$objSmarty->assign('ErrorMessage', 'Menu Name should not be blank');
			return false;
		}elseif((!$objArray['menuType'])){
			$objSmarty->assign('ErrorMessage', 'Menu Type should not be blank');
			return false;
		}elseif(!$objArray['faIcon']){
			$objSmarty->assign('ErrorMessage', 'Favourite Icon should not be blank');
			return false;
		}elseif(!$objArray['url']){
			$objSmarty->assign('ErrorMessage', 'URL should not be blank');
			return false;
		}elseif(!$objArray['priority']){
			$objSmarty->assign('ErrorMessage', 'Priority should not be blank');
			return false;
		}
		$objSmarty->assign('menuName', $objArray['menuName']);
		if($objArray['menuName'] && $objArray['menuType'])
		{
			$InsQuery = 'INSERT INTO `'.$tbl.'user_role_master`(
			`menuName`,
			`menuType`,
			`faIcon`,
			`url`,
			`priority`,
			`parent_id`,
			`isActive`,
			`createdBy`) 
			VALUES(
			"'.trim(addslashes($objArray['menuName'])).'",
			"'.trim(addslashes($objArray['menuType'])).'",
			"'.trim(addslashes($objArray['faIcon'])).'",
			"'.trim(addslashes($objArray['url'])).'",
			"'.trim(addslashes($objArray['priority'])).'",
			"'.trim(addslashes($objArray['parentMenu'])).'",
			"'.trim(addslashes($objArray['checkVal'])).'",
			"'.trim(addslashes($objArray['created_by'])).'")';
			$this->ExecuteQuery($InsQuery, 'insert');
		}
			header('Location:userRoleList.php?succs_msg_for_insert');
	}
    /************************ InsertUserRole Functions Ends ***************************************************************/
	 /************************ RoleDetailview Functions Starts ***************************************************************/
	function RoleDetailview($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		
		$SelQuery = 'SELECT * FROM `'.$tbl.'user_role_master` WHERE slNo="'.$_GET['roleId'].'" AND status="1"';
		$ListEditView = $this->ExecuteQuery($SelQuery, "select");
		$objSmarty->assign('ListEditView', $ListEditView);
		return $ListEditView;
	}
    /************************ RoleDetailview Functions Ends ***************************************************************/
	/************************ EditUserRole Functions Ends ***************************************************************/
	
	function EditUserRole($objArray="")
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if(!$objArray['menuName']){
			$objSmarty->assign('ErrorMessage', 'Menu Name should not be blank');
			return false;
		}elseif((!$objArray['menuType'])){
			$objSmarty->assign('ErrorMessage', 'Menu Type should not be blank');
			return false;
		}elseif(!$objArray['faIcon']){
			$objSmarty->assign('ErrorMessage', 'Favourite Icon should not be blank');
			return false;
		}elseif(!$objArray['url']){
			$objSmarty->assign('ErrorMessage', 'URL should not be blank');
			return false;
		}elseif(!$objArray['priority']){
			$objSmarty->assign('ErrorMessage', 'Priority should not be blank');
			return false;
		}
			$objSmarty->assign('roleId', $objArray['roleId']);
		if($objArray['roleId'] && $objArray['menuName'])
		{
			$UpQuery = 'UPDATE 
			`'.$tbl.'user_role_master` 
			SET 
			`menuName` = "'.trim($objArray['menuName']).'", 
			`menuType` = "'.trim($objArray['menuType']).'", 
			`faIcon` = "'.trim($objArray['faIcon']).'",
			`url` = "'.trim($objArray['url']).'",
			`priority` = "'.trim($objArray['priority']).'",
			`parent_id` = "'.trim($objArray['parentMenu']).'",
			`isActive` = "'.trim($objArray['checkVal']).'",
			`createdBy` = "'.trim($objArray['created_by']).'"
			WHERE 
			`slNo` ="'.trim($objArray['roleId']).'"'; 
			$this->ExecuteQuery($UpQuery, 'update');
			$UpQuery = 'UPDATE `'.$tbl.'user_group_mapping` SET  `menuType`="'.trim($objArray['menuType']).'",`faIcon`="'.trim($objArray['faIcon']).'",`url`="'.trim($objArray['url']).'",`priority`="'.trim($objArray['priority']).'",`isActive`="'.trim($objArray['checkVal']).'" WHERE `menuName` ="'.$_GET['roleId'].'"'; 
			$this->ExecuteQuery($UpQuery, 'update');
		}
			header('Location:userRoleList.php?success_msg_for_update');  
	
	}
     /************************ EditUserRole Functions Ends ***************************************************************/
	  /************************ DeleteMaster Functions Starts ***************************************************************/
	function DeleteMaster($CatIdent)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		
		$DelQuery = 'update `'.$tbl.'user_role_master` set `isActive` = 0 ,`status` = 0 WHERE `slNo` ="'.$CatIdent.'"';
		$this->ExecuteQuery($DelQuery, 'update');
		header('Location:' .$_SERVER['PHP_SELF'].'?succs_msg_for_del');  
	}
/************************ DeleteMaster Functions Ends ***************************************************************/

}
?>