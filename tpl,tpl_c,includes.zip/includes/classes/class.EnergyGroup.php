<?php
 class EnergyGroup extends MysqlFns
{
      /********* UsergroupReg Constructor Starts ********************************/
	function EnergyGroup()
	{
		$this->LDDisplayPath= $config['SiteGlobalPath']."class.EnergyGroup.php";
		global $config;
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$this->MysqlFns();
		$this->Limit = 20;
		$usrgroup_id = base64_decode($_GET["group_id"]);
		$ConLink1 = mysql_connect($config['DBHost'],$config['DBUser'],$config['DBPassword']) or die("Database Connection Failed<br>". mysql_error());
		mysql_select_db($config['DBName'], $ConLink1);
		if($config['DBUser'] != 'root')
		{
			$nowDate= 'NOW()';
		}
		else{
			$nowDate= 'NOW()';
		}

	} 
     /********* UsergroupReg Constructor Ends ********************************/
     /************************************ ListEnergyGroup Functions Starts ***************************************************************/
	function ListEnergyGroup($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$i=$_SESSION['USER_GROUP'];
	if($_POST['table_search'] <> '')
	{
		$SelQuery='SELECT  * FROM `'.$tbl.'energy_meter_group` WHERE status = "1" AND (energyMetergroupName like "%'.$_POST['table_search'].'%") ORDER BY energyMetergroupName DESC';
	}
	else
	{
		$SelQuery = 'SELECT  * FROM `'.$tbl.'energy_meter_group` WHERE status = "1"';
	}	 
		$ListView = $this->ExecuteQuery($SelQuery, "select");
		$objSmarty->assign('ListView', $ListView);
		return $ListView;
	}	
        /************************************ ListEnergyGroup Functions Ends ***************************************************************/
		/************************************ SensorList Functions Starts ***************************************************************/
	function SensorList($objArray="")
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		
		$SelQuery = 'SELECT  `'.$tbl.'sensor_master`.*,arka_gateway_master.place_of_installation FROM `'.$tbl.'sensor_master`,arka_gateway_master WHERE arka_sensor_master.gateway_id=arka_gateway_master.gateway_id AND arka_sensor_master.isActive = "1" AND arka_sensor_master.status="1" AND arka_gateway_master.is_active="1" AND arka_gateway_master.record_status="1"';
		$SensorList = $this->ExecuteQuery($SelQuery, "select");
		$objSmarty->assign('SensorList', $SensorList);
		
		$SelQuery2 = 'SELECT  `'.$tbl.'sensor_master`.*,arka_gateway_master.place_of_installation FROM `'.$tbl.'sensor_master`,arka_gateway_master WHERE arka_sensor_master.slNo NOT IN (SELECT arka_energy_meter_group_details.sensor_id FROM arka_energy_meter_group_details WHERE  arka_energy_meter_group_details.meter_group_id="'.$_GET['groupId'].'") AND arka_sensor_master.gateway_id=arka_gateway_master.gateway_id AND arka_sensor_master.isActive = "1" AND arka_sensor_master.status="1" AND arka_gateway_master.is_active="1" AND arka_gateway_master.record_status="1"';
		$SensorList2 = $this->ExecuteQuery($SelQuery2, "select");
		$objSmarty->assign('SensorList2', $SensorList2);
		//return $SensorList;
	}
     /************************************ SensorList Functions Ends ***************************************************************/
	 /************************************ GroupDetailview Functions Starts ***************************************************************/
	function GroupDetailview($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		
		$SelQuery = 'SELECT * FROM `'.$tbl.'energy_meter_group` WHERE meter_group_id="'.$_GET['groupId'].'"';
		$ListEditView = $this->ExecuteQuery($SelQuery, "select");
		$objSmarty->assign('ListEditView', $ListEditView);
	
		$SelQuery = 'SELECT arka_energy_meter_group_details.sensor_id as slNo,arka_sensor_master.sensorName,arka_sensor_master.modbus_slave_id,arka_gateway_master.place_of_installation FROM `arka_energy_meter_group_details`,`arka_sensor_master`,arka_gateway_master WHERE arka_energy_meter_group_details.meter_group_id="'.$_GET['groupId'].'" AND arka_sensor_master.gateway_id=arka_gateway_master.gateway_id AND arka_gateway_master.is_active="1" AND arka_gateway_master.record_status="1" AND arka_energy_meter_group_details.sensor_id= arka_sensor_master.slNo ORDER BY arka_energy_meter_group_details.meter_group_details_id' ;
		$groupMapping		= $this->ExecuteQuery($SelQuery, "select");
		$objSmarty->assign('groupMapping',$groupMapping);
	
		$SelQuery1 = 'SELECT DISTINCT slNo,sensorName,modbus_slave_id FROM '.$tbl.'sensor_master where slNo not in(SELECT sensor_id FROM '.$tbl.'energy_meter_group_details where meter_group_id="'.$_GET['groupId'].'") order by '.$tbl.'sensor_master.sensorName';
		$uRoleList = $this->ExecuteQuery($SelQuery1, 'selectassoc');
		$objSmarty->assign('uRoleList',$uRoleList);
		return $uRoleList;
	}
    /************************************ GroupDetailview Functions Ends ***************************************************************/
	/************************************ InsertEnergyMeterGroup Functions Starts ***************************************************************/
	function InsertEnergyMeterGroup($objArray="")
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
	if(!$objArray['energyMeterGroupName']){
		$objSmarty->assign('ErrorMessage', 'Energy Meter Group Name should not be blank');
		return false;
	}
	if($this->ChkDuplicateEnergyMeterGroup(trim(addslashes($objArray['energyMeterGroupName']))))
	{
		$InsQuery = 'INSERT INTO `'.$tbl.'energy_meter_group`
		(`energy_meter_group_name`,
		`isActive`,
		`status`,
		`createdBy`) 
		VALUES
		("'.trim(addslashes($objArray['energyMeterGroupName'])).'",
		"'.trim(addslashes($objArray['checkVal'])).'",
		"1",
		"'.trim(addslashes($objArray['created_by'])).'")';
		$this->ExecuteQuery($InsQuery, 'insert');
	
		$SelQuery = 'select * from `'.$tbl.'energy_meter_group` where meter_group_id=(SELECT LAST_INSERT_ID())';
		$sView = $this->ExecuteQuery($SelQuery, "select");
		$objSmarty->assign('sView', $sView);
		$arrs = $objArray["dexam16"];
	
	foreach($arrs as $key=>$value)
	{
		$SelQuery = 'SELECT * FROM `'.$tbl.'sensor_master` WHERE slNo="'.$value.'"';
		$ListView = $this->ExecuteQuery($SelQuery, "select");
		$objSmarty->assign('ListView', $ListView);
	
		$InsQuery = 'INSERT INTO `'.$tbl.'energy_meter_group_details`(
		`meter_group_id`,
		`sensor_id`,
		`status`) 
		VALUES(
		"'.$sView[0]['meter_group_id'].'",
		"'.$value.'",
		"1")';
		$this->ExecuteQuery($InsQuery, 'insert');
	}
		header('Location:energyMeterGroupList.php?success_msg_for_insert');  
	}
	}
     /************************************ InsertEnergyMeterGroup Functions Ends ***************************************************************/    
	 /************************************ ChkDuplicateEnergyMeterGroup Functions Starts ***************************************************************/   
	function ChkDuplicateEnergyMeterGroup($ug_no)
	{
		global $objSmarty,$config,$_POST;
		$tbl = $config['DBPrefix'];
		
		$SelQuery	= 'SELECT * FROM `'.$tbl.'energy_meter_group` WHERE `energy_meter_group_name` = "'.$ug_no.'" and status="1" Limit 0,1';
		$EGDetail = $this->ExecuteQuery($SelQuery, 'select');
	if(!empty($EGDetail) && is_array($EGDetail)){
	$objSmarty->assign('ErrorMessage', 'Energy Meter Group Name Already Existing');
	return false;
	}	
	else{
		return true;
		}
	}
     /************************************ ChkDuplicateEnergyMeterGroup Functions Ends ***************************************************************/   
	 /************************************ UpdateEnergyMeterGroup Functions Starts ***************************************************************/ 
	function UpdateEnergyMeterGroup($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$UpQuery = 'UPDATE 
		`'.$tbl.'energy_meter_group` 
		SET 
		`energy_meter_group_name` = "'.trim($objArray['energyMeterGroupName']).'",
		`status` = "1",
		`isActive` = "'.trim($objArray['checkVal']).'",
		`createdBy` = "'.trim($objArray['created_by']).'"
		WHERE 
		`meter_group_id` ="'.trim($objArray['group']).'"';
		$this->ExecuteQuery($UpQuery, 'update');
	
		$DelQuery = 'DELETE FROM `'.$tbl.'energy_meter_group_details` WHERE `meter_group_id` ="'.trim($objArray['group']).'"';
		$this->ExecuteQuery($DelQuery, 'delete');
		$objSmarty->assign('SuccessMessage', 'Group Deleted Successfully');
		$arrs = $objArray["dexam16"];
	
		$SelQuery = 'select * from `'.$tbl.'energy_meter_group` where meter_group_id="'.trim($objArray['group']).'"';
		$sView = $this->ExecuteQuery($SelQuery, "select");
		$objSmarty->assign('sView', $sView);
	
	foreach($arrs as $key=>$value)
	{
		$SelQuery = 'SELECT * FROM `'.$tbl.'sensor_master` WHERE slNo="'.$value.'"';
		$ListView = $this->ExecuteQuery($SelQuery, "select");
		$objSmarty->assign('ListView', $ListView);
	
		$InsQuery = 'INSERT INTO `'.$tbl.'energy_meter_group_details`(
		`meter_group_id`,
		`sensor_id`,
		`status`) 
		VALUES(
		"'.trim($objArray['group']).'",
		"'.$value.'",
		"1")';
		$this->ExecuteQuery($InsQuery, 'insert');
	}	
		header('Location:energyMeterGroupList.php?success_msg_for_update');  
	}
     /************************************ UpdateEnergyMeterGroup Functions Ends ***************************************************************/
	 /************************************ DeleteMaster Functions Starts ***************************************************************/
function DeleteMaster($CatIdent)
{
	global $objSmarty,$config;
	$tbl = $config['DBPrefix'];
	$DelQuery = 'update `'.$tbl.'energy_meter_group` set `status` = 0 WHERE `meter_group_id` ="'.$CatIdent.'"';
	$this->ExecuteQuery($DelQuery, 'update');
	header('Location:' .$_SERVER['PHP_SELF'].'?succs_msg_for_del');  
}
     /************************************ DeleteMaster Functions Ends ***************************************************************/
	 
	 	     /******************** GetDashboardDetails Functions Starts ****************/
		function GetDashboardDetails($objArray='')
		{
		    global $objSmarty;
		if($_GET['companyId'] <> '')
		{
		   $comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		   $comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		   $branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		   $branchId = $_SESSION['branch_id'];
		}
		   $SelQuery_loc = 'SELECT arka_company_master.companyName,arka_branch_master.branch_name,arka_sensor_master.* ,arka_gateway_master.place_of_installation FROM arka_company_master,arka_branch_master,arka_sensor_master,arka_gateway_master WHERE arka_sensor_master.gateway_id="'.base64_decode($_GET["gatewayCode"]).'" AND arka_sensor_master.sensorCode="'.base64_decode($_GET["sensorCode"]).'" AND arka_sensor_master.gateway_id=arka_gateway_master.gateway_id AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.company_id=arka_company_master.slNo AND arka_branch_master.company_id=arka_sensor_master.company_id AND arka_branch_master.company_id=arka_company_master.slNo AND arka_branch_master.sl_no=arka_sensor_master.branch_id' ;
		   $LoctList		= $this->ExecuteQuery($SelQuery_loc, "select");
		   $objSmarty->assign('LoctList', $LoctList);
		   
		  // $SelQuery_mod = 'SELECT sensor_model_master.* FROM sensor_model_master  WHERE sensor_model_master.model_id="'.$LoctList[0]["sensorModel"].'" AND is_active="1" AND status="1"' ;
		    $SelQuery_mod = 'SELECT sensor_model_master.*,power_factor_step_capcitor_value_mapping.* FROM sensor_model_master,power_factor_step_capcitor_value_mapping  WHERE sensor_model_master.model_id="'.$LoctList[0]["sensorModel"].'" AND power_factor_step_capcitor_value_mapping.sensorCode="'.$LoctList[0]['sensorCode'].'"  AND power_factor_step_capcitor_value_mapping.gatewayCode="'.$LoctList[0]['gateway_id'].'" AND power_factor_step_capcitor_value_mapping.isActive="1" AND power_factor_step_capcitor_value_mapping.status="1" AND sensor_model_master.is_active="1" AND sensor_model_master.status="1" AND sensor_model_master.model_id=power_factor_step_capcitor_value_mapping.sensorModel' ;

		   $ModList		= $this->ExecuteQuery($SelQuery_mod, "select");
		   $objSmarty->assign('ModList', $ModList);
		   
		//   $SelQuery='SELECT max(ping_log_id) AS ping_log_id, max(gateway_code) AS gateway_code,max(gateway_date_time) AS gateway_date_time FROM `gateway_ping_log` WHERE gateway_code="'.base64_decode($_GET["gatewayCode"]).'" GROUP BY gateway_code ORDER BY ping_log_id';
	        $SelQuery='SELECT * FROM `gateway_ping_log_view` WHERE gateway_code="'.base64_decode($_GET["gatewayCode"]).'"';
	       $gateList= $this->ExecuteQuery($SelQuery, "select");
	       $objSmarty->assign('gateList', $gateList);
		}	
	/******************** GetDashboardDetails Functions Ends ****************/
	/***********************Sub Dashboard List*************************************************/
function GetSubDashboard()  {
			global $objSmarty,$config,$nowDate;
		
			if($_GET['companyId'] <> '')
			{
			$comId = base64_decode($_GET['companyId']);
			}	
			else
			{
			$comId = $_SESSION['CustomerId'];
			}
			if($_GET['branchId'] <> '')
			{
			$branchId = base64_decode($_GET['branchId']);
			}	
			else
			{
			$branchId = $_SESSION['branch_id'];
			}
			$parent_id=base64_decode($_GET['parent_id']);

$senDashboard = 'SELECT * FROM arka_energy_meter_group WHERE meter_group_id="'.$parent_id.'"';
			$senDashboard		= $this->ExecuteQuery($senDashboard, "select");
			$objSmarty->assign('senDashboard', $senDashboard);

 			$SelQuery = 'SELECT energy_data_master_view.*,arka_sensor_master.*,arka_gateway_master.*,(arka_sensor_master.kw_max_value/5) AS KW_INT,arka_sensor_master.sensorName AS feeder_name,TIMESTAMPDIFF(SECOND, recorded_date_time, NOW()) AS secs FROM energy_data_master_view,arka_sensor_master,arka_energy_meter_group_details,arka_gateway_master WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_energy_meter_group_details.meter_group_id="'.$parent_id.'" AND arka_energy_meter_group_details.sensor_id=arka_sensor_master.slNo AND arka_sensor_master.sensorCode=energy_data_master_view.sensor_code AND arka_sensor_master.gateway_id=energy_data_master_view.gateway_code AND energy_data_master_view.gateway_code=arka_gateway_master.gateway_id'; 
 		//   $SelQuery = 'SELECT energy_data_master_view.*,arka_sensor_master.*,(arka_sensor_master.kw_max_value/5) AS KW_INT,arka_sensor_master.sensorName AS feeder_name,TIMESTAMPDIFF(SECOND, recorded_date_time, NOW()) AS secs FROM energy_data_master_view,arka_sensor_master WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.parent_id="'.$parent_id.'" AND arka_sensor_master.sensorCode=energy_data_master_view.sensor_code AND arka_sensor_master.gateway_id=energy_data_master_view.gateway_code '; 
	       $MeterList= $this->ExecuteQuery($SelQuery, "select");//echo $SelQuery;
	       $objSmarty->assign('MeterList', $MeterList);	
		   
		   if(isset($_POST['fromDate']) && isset($_POST['toDate'])){
		   
		   	$dateWhr=' AND ( cron_daily_energy_data.recorded_date BETWEEN "'.$_POST['fromDate'].'" AND "'.$_POST['toDate'].'")';
		   
		   }else{
		   	$dateWhr=' AND DATE(cron_daily_energy_data.recorded_date)=DATE(NOW()) AND MONTH(cron_daily_energy_data.recorded_date)=MONTH(NOW()) AND YEAR(cron_daily_energy_data.recorded_date)=YEAR(NOW())';
		   }
	       
	      	$selQryC = 'SELECT SUM(cron_daily_energy_data.`consuption_kwh`) AS TOTAL_KWH ,SUM(cron_daily_energy_data.`consuption_cost`) AS cost,cron_daily_energy_data.sensor_code FROM `cron_daily_energy_data`,arka_sensor_master,arka_energy_meter_group_details WHERE cron_daily_energy_data.company_id="'.$comId.'" AND cron_daily_energy_data.branch_id="'.$branchId.'" AND arka_energy_meter_group_details.meter_group_id="'.$parent_id.'" AND arka_energy_meter_group_details.sensor_id=arka_sensor_master.slNo AND arka_sensor_master.sensorCode=cron_daily_energy_data.sensor_code '.$dateWhr.' GROUP BY cron_daily_energy_data.sensor_code'; 
	       	$CostKWHRows		= $this->ExecuteQuery($selQryC, "numrows");
	        $CostKWH		= $this->ExecuteQuery($selQryC, "select");
	        $objSmarty->assign('CostKWH', $CostKWH);

//$SelQuery='SELECT max(ping_log_id) AS ping_log_id, max(gateway_code) AS gateway_code,max(gateway_date_time) AS gateway_date_time FROM `gateway_ping_log	` GROUP BY gateway_code ORDER BY ping_log_id';
$SelQuery='SELECT ping_log_id, gateway_code, gateway_date_time FROM `gateway_ping_log_view` ORDER BY gateway_code';

	       $gateList= $this->ExecuteQuery($SelQuery, "select");//print_r($MeterList);
	       $objSmarty->assign('gateList', $gateList);

}	
/************************************************************************************/
	/***********************Sub Dashboard List*************************************************/
function GetMainMeterDashboard()  {
			global $objSmarty,$config,$nowDate;
		
			if($_GET['companyId'] <> '')
			{
			$comId = base64_decode($_GET['companyId']);
			}	
			else
			{
			$comId = $_SESSION['CustomerId'];
			}
			if($_GET['branchId'] <> '')
			{
			$branchId = base64_decode($_GET['branchId']);
			}	
			else
			{
			$branchId = $_SESSION['branch_id'];
			}
			$parent_id=base64_decode($_GET['parent_id']);

$senDashboard = 'SELECT * FROM arka_energy_meter_group WHERE meter_group_id="'.$parent_id.'"';
			$senDashboard		= $this->ExecuteQuery($senDashboard, "select");
			$objSmarty->assign('senDashboard', $senDashboard);

 			$SelQuery = 'SELECT energy_data_master_view.*,arka_sensor_master.*,arka_gateway_master.*,(arka_sensor_master.kw_max_value/5) AS KW_INT,arka_sensor_master.sensorName AS feeder_name,TIMESTAMPDIFF(SECOND, recorded_date_time, NOW()) AS secs FROM energy_data_master_view,arka_sensor_master,arka_gateway_master WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.feeder_type="Main Meter" AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.sensorCode=energy_data_master_view.sensor_code AND arka_sensor_master.gateway_id=energy_data_master_view.gateway_code AND energy_data_master_view.gateway_code=arka_gateway_master.gateway_id  ORDER BY arka_sensor_master.priority'; 
 		//   $SelQuery = 'SELECT energy_data_master_view.*,arka_sensor_master.*,(arka_sensor_master.kw_max_value/5) AS KW_INT,arka_sensor_master.sensorName AS feeder_name,TIMESTAMPDIFF(SECOND, recorded_date_time, NOW()) AS secs FROM energy_data_master_view,arka_sensor_master WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.parent_id="'.$parent_id.'" AND arka_sensor_master.sensorCode=energy_data_master_view.sensor_code AND arka_sensor_master.gateway_id=energy_data_master_view.gateway_code '; 
	       $MeterList= $this->ExecuteQuery($SelQuery, "select");//echo $SelQuery;
	       $objSmarty->assign('MeterList', $MeterList);	
		   
		   if(isset($_POST['fromDate']) && isset($_POST['toDate'])){
		   
		   	$dateWhr=' AND ( cron_daily_energy_data.recorded_date BETWEEN "'.$_POST['fromDate'].'" AND "'.$_POST['toDate'].'")';
		   
		   }else{
		   	$dateWhr=' AND DATE(cron_daily_energy_data.recorded_date)=DATE(NOW()) AND MONTH(cron_daily_energy_data.recorded_date)=MONTH(NOW()) AND YEAR(cron_daily_energy_data.recorded_date)=YEAR(NOW())';
		   }
	       
	      	$selQryC = 'SELECT SUM(cron_daily_energy_data.`consuption_kwh`) AS TOTAL_KWH ,SUM(cron_daily_energy_data.`consuption_cost`) AS cost,cron_daily_energy_data.sensor_code FROM `cron_daily_energy_data`,arka_sensor_master WHERE cron_daily_energy_data.feeder_type="Main Meter" AND cron_daily_energy_data.company_id="'.$comId.'" AND cron_daily_energy_data.branch_id="'.$branchId.'"  AND arka_sensor_master.sensorCode=cron_daily_energy_data.sensor_code '.$dateWhr.' GROUP BY cron_daily_energy_data.sensor_code  ORDER BY arka_sensor_master.priority'; 
	       	$CostKWHRows		= $this->ExecuteQuery($selQryC, "numrows");
	        $CostKWH		= $this->ExecuteQuery($selQryC, "select");
	        $objSmarty->assign('CostKWH', $CostKWH);

//$SelQuery='SELECT max(ping_log_id) AS ping_log_id, max(gateway_code) AS gateway_code,max(gateway_date_time) AS gateway_date_time FROM `gateway_ping_log	` GROUP BY gateway_code ORDER BY ping_log_id';
$SelQuery='SELECT ping_log_id, gateway_code, gateway_date_time FROM `gateway_ping_log_view` ORDER BY gateway_code';

	       $gateList= $this->ExecuteQuery($SelQuery, "select");//print_r($MeterList);
	       $objSmarty->assign('gateList', $gateList);

}	
/************************************************************************************/

}
?>