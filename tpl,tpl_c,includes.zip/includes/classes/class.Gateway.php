<?php
class Gateway extends MysqlFns
{
     /********* ListGateway Functions Starts ********************************/
	function ListGateway($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> '')
		{
			$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
			$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
			$branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
			$branchId = $_SESSION['branch_id'];
		}
			$SelQuery = 'SELECT `'.$tbl.'gateway_master`.*,model_master.model_name FROM  `'.$tbl.'gateway_master`,model_master WHERE `'.$tbl.'gateway_master`.company_id="'.$comId.'" AND `'.$tbl.'gateway_master`.branch_id="'.$branchId.'" AND `'.$tbl.'gateway_master`.record_status="1" AND `'.$tbl.'gateway_master`.model=model_master.model_code';  
			$ListView = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListView', $ListView);
			return $ListView;
	}
     /********* ListGateway Functions Ends ********************************/
	 /********* ListLocation Functions Starts ********************************/
	function ListLocation($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$comId = base64_decode($_GET['companyId']);
	
		$SelQuery = 'SELECT * FROM  `'.$tbl.'location_master` WHERE company_id="'.$comId.'" AND record_status="1"';  
		$ListLocationView = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListLocationView', $ListLocationView);
		return $ListLocationView;
	}
    /********* ListLocation Functions Ends ********************************/
	/********* ListAlertGateway Functions Starts ********************************/
	function ListAlertGateway($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$comId = base64_decode($_GET['companyId']);
		$gid = base64_decode($_GET['gateway_id']);
		
		$SelQuery = 'SELECT `'.$tbl.'meter_master`.*,`'.$tbl.'gateway_master`.* FROM `'.$tbl.'meter_master`,`'.$tbl.'gateway_master` WHERE `'.$tbl.'gateway_master`.gateway_id=`'.$tbl.'meter_master`.gateway_id AND `'.$tbl.'gateway_master`.gateway_id IN(SELECT `'.$tbl.'meter_master`.gateway_id FROM `'.$tbl.'meter_master` WHERE `'.$tbl.'meter_master`.is_active="1" AND `'.$tbl.'meter_master`.company_id=`'.$tbl.'gateway_master`.company_id AND `'.$tbl.'gateway_master`.company_id="'.$comId.'" AND `'.$tbl.'meter_master`.record_status="1" )AND `'.$tbl.'gateway_master`.gateway_id="'.$gid.'" AND `'.$tbl.'gateway_master`.record_status="1" AND `'.$tbl.'gateway_master`.is_active="1"';  
		$ListAlertGatewayView = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListAlertGatewayView', $ListAlertGatewayView);
		return $ListAlertGatewayView;
	}
     /********* ListAlertGateway Functions Ends ********************************/
	  /********* ListModelMas Functions Starts ********************************/
	 function ListModelMas()
	 {
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		
		$selMod='SELECT * FROM model_master';
		$exeMod=$this->ExecuteQuery($selMod, 'select');
		$objSmarty->assign('exeMod', $exeMod);
	}
      /********* ListModelMas Functions Ends ********************************/
	  /********* ListEditView Functions Starts ********************************/
	function ListEditView($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$sid = base64_decode($_GET['sl_no']);
		$gid = base64_decode($_GET['gateway_id']);
		$comId = base64_decode($_GET['companyId']);
		$lId = base64_decode($_GET['location_id']);
	
		$SelQuery = 'SELECT * FROM  `'.$tbl.'gateway_master` WHERE gateway_id="'.$gid.'" AND sl_no="'.$sid.'" AND company_id="'.$comId.'" AND record_status="1"';    
		$ListEditView = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListEditView', $ListEditView);
		return $ListEditView;
	}
      /********* ListEditView Functions Ends ********************************/
	  /********* InsertGateway Functions Starts ********************************/
	function InsertGateway($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> '')
		{
			$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
			$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
			$branId = base64_decode($_GET['branchId']);
		}	
		else
		{
			$branId = $_SESSION['branchId'];
		}
		if(!$objArray['model']){
			$objSmarty->assign('ErrorMessage', 'Model should not be blank');
			return false;
		}elseif((!$objArray['instPlace'])){
			$objSmarty->assign('ErrorMessage', 'Installation Place should not be blank');
			return false;
		}
		if($objArray['model'] && $objArray['instPlace'])
		{
			$SelQuerys	= 'SELECT gateway_id as last FROM `arka_gateway_master` WHERE model LIKE "%'.$objArray['model'].'%" AND record_status="1" ORDER BY sl_no DESC Limit 0,1';
			$CusDetail	= $this->ExecuteQuery($SelQuerys, 'select');
		
		if($CusDetail[0]['last']!="")
		{ 
			$CusDetail[0]['gateway_id'] = stripslashes($CusDetail[0]['last']);
			$split = explode("-",$CusDetail[0]['gateway_id']);
			$lastval = end($split);//echo $lastval;echo "<br>";
			$autoInc = $lastval + 1;//echo $autoInc;echo "<br>";
			$split2 = explode($lastval,$CusDetail[0]['gateway_id']);//print_r($split2);echo "<br>";
			$g_id = $split[0]."-".$autoInc;echo $g_id;echo "<br>";
		} else
		{
			$g_id = $objArray['model']."-1";
		}
		
			$InsQuery = 'INSERT INTO `'.$tbl.
			'gateway_master`(`gateway_id`,`company_id`,`branch_id`,`model`,`place_of_installation`,`serial_no`,`internet_type`,`description`,`is_active`,`created_by`,`record_status`) VALUES("'.$g_id.'","'.$comId.'","'.$branId.'","'.trim(addslashes($objArray['model'])).'","'.trim(addslashes($objArray['instPlace'])).'","'.trim(addslashes($objArray['serialNo'])).'","'.trim(addslashes($objArray['internet_type'])).'","'.trim(addslashes($objArray['description'])).'","'.trim(addslashes($objArray['checkVal'])).'","'.trim(addslashes($objArray['created_by'])).'","1")';
			$this->ExecuteQuery($InsQuery, 'insert');
			header('Location:gatewayList.php?companyId='.$objArray['company_id'].'&branchId='.$objArray['branch_id'].'&success_msg_for_insert');
		
		}
	}
	
	   /********* InsertGateway Functions Ends ********************************/
	   /********* EditGateway Functions Starts ********************************/
	function EditGateway($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
			$sid = base64_decode($_GET['sl_no']);
			$gid = base64_decode($_GET['gateway_id']);
			$comId = base64_decode($_GET['companyId']);
			$lId = base64_decode($_GET['location_id']);
		
		if(!$objArray['model']){
			$objSmarty->assign('ErrorMessage', 'Model should not be blank');
			return false;
		}elseif((!$objArray['instPlace'])){
			$objSmarty->assign('ErrorMessage', 'Installation Place should not be blank');
			return false;
		}
		if($objArray['model'] && $objArray['instPlace']){	
		
		if($objArray['model'] != $objArray['oldModel'])
		{
		
		$SelQuerys	= 'SELECT gateway_id as last FROM `arka_gateway_master` WHERE model LIKE "%'.$objArray['model'].'%" ORDER BY sl_no DESC Limit 0,1';
		$CusDetail	= $this->ExecuteQuery($SelQuerys, 'select');
		if($CusDetail[0]['last']!="")
		{ 
			$CusDetail[0]['gateway_id'] = stripslashes($CusDetail[0]['last']);
			$split = explode("-",$CusDetail[0]['gateway_id']);
			$lastval = end($split);
			$autoInc = $lastval + 1;
			$split2 = explode($lastval,$CusDetail[0]['gateway_id']);
			$g_id = $split2[0].$autoInc;
		} else
		{
			$g_id = $objArray['model']."-1";
		}
		}
		else
		{
			$g_id=$objArray['gateWayId'];
		}
		
		
			$UpdateQuery = 'UPDATE `'.$tbl.
			'gateway_master` SET `gateway_id`="'.$g_id.'",`model`="'.trim(addslashes($objArray['model'])).'",`place_of_installation`="'.trim(addslashes($objArray['instPlace'])).'",`serial_no`="'.trim(addslashes($objArray['serialNo'])).'",`internet_type`="'.trim(addslashes($objArray['internet_type'])).'",`is_active`="'.trim(addslashes($objArray['checkVal'])).'",`description`="'.trim(addslashes($objArray['description'])).'",`created_by`="'.trim(addslashes($objArray['created_by'])).'" WHERE gateway_id="'.$gid.'" AND sl_no="'.$sid.'"';   
			$this->ExecuteQuery($UpdateQuery, 'update');
			header('Location:gatewayList.php?companyId='.$_GET['companyId'].'&branchId='.$_GET['branchId'].'&success_msg_for_update');
		}
	}
      /********* EditGateway Functions Ends ********************************/
	   /********* DeleteGateway Functions Starts ********************************/
	function DeleteGateway($CatIdent)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$comId = $_GET['company_id'];
		$bId = $_GET['branch_id'];
		
		$DelQuery = 'update `'.$tbl.'gateway_master` set `record_status` = "0" WHERE `sl_no` ="'.$CatIdent.'"';
		$this->ExecuteQuery($DelQuery, 'update');
		header('Location:' .$_SERVER['PHP_SELF'].'?companyId='.$comId.'&branchId='.$bId.'&succs_msg_for_del');  
	}
      /********* DeleteGateway Functions Ends ********************************/


}
?>