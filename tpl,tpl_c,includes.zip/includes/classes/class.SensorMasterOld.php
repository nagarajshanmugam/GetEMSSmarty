<?php
class SensorMaster extends MysqlFns
{ 
     /********* SensorMaster Constructor Starts ********************************/
	function SensorMaster()
	{
		$this->LDDisplayPath= $config['SiteGlobalPath']."class.SensorMaster.php";
		global $config;
		global $objSmarty;
		global $nowDate;
		$this->Limit = 20;
		$ConLink1 = mysql_connect($config['DBHost'],$config['DBUser'],$config['DBPassword']) or die("Database Connection Failed<br>". mysql_error());
		mysql_select_db($config['DBName'], $ConLink1);
		if($config['DBUser'] != 'root')
		{
			$nowDate= 'DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE)';
		}
		else{
			$nowDate= 'NOW()';
		}
	}
      /********* SensorMaster Constructor Ends ********************************/
     /********* ListSensor Functions Starts ********************************/
	function ListSensor($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> '')
		{
			$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
			$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
			$branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
			$branchId = $_SESSION['branch_id'];
		}
		$gateId = base64_decode($_GET['gatewayId']);
		if(isset($_GET['gatewayId']))
		{
			$SelQuery = 'SELECT `'.$tbl.'sensor_master`.*,`'.$tbl.'company_master`.companyName,sensor_model_master.json_format AS json_data_format,sensor_model_master.api_url AS api_url,sensor_model_master.model_name FROM `'.$tbl.'sensor_master`,`'.$tbl.'company_master`,sensor_model_master WHERE `'.$tbl.'sensor_master`.company_id="'.$comId.'" AND `'.$tbl.'sensor_master`.branch_id="'.$branchId.'" AND `'.$tbl.'sensor_master`.gateway_id="'.$gateId.'" AND `'.$tbl.'sensor_master`.status="1" AND `arka_company_master`.slNo=`arka_sensor_master`.company_id AND `'.$tbl.'sensor_master`.sensorModel=sensor_model_master.model_id';
			$ListSensorView = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListSensorView', $ListSensorView);
			return $ListSensorView;
		}
		else
		{
			$SelQuery = 'SELECT `'.$tbl.'sensor_master`.*,`'.$tbl.'company_master`.companyName,sensor_model_master.json_format AS json_data_format,sensor_model_master.api_url AS api_url,sensor_model_master.model_name FROM `'.$tbl.'sensor_master`,`'.$tbl.'company_master`,sensor_model_master WHERE `'.$tbl.'sensor_master`.company_id="'.$comId.'" AND `'.$tbl.'sensor_master`.branch_id="'.$branchId.'" AND `'.$tbl.'sensor_master`.status="1" AND `arka_company_master`.slNo=`arka_sensor_master`.company_id AND `'.$tbl.'sensor_master`.sensorModel=sensor_model_master.model_id';  
			$ListSensorView = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListSensorView', $ListSensorView);
			return $ListSensorView;
		}
	}
      /********* ListSensor Functions Ends ********************************/
	 /********* GetGatewayName Functions Starts ********************************/
	function GetGatewayName()
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$bId = base64_decode($_GET['branchId']);
		$comId = base64_decode($_GET['companyId']);
		$gId = base64_decode($_GET['gatewayId']);
		$SelQuery = 'SELECT * FROM  `'.$tbl.'gateway_master` WHERE branch_id="'.$bId.'" AND company_id="'.$comId.'" AND sl_no="'.$gId.'" AND record_status="1"';  
		$GetGateView = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('GetGateView', $GetGateView);//print_r($ListView);exit;
		return $GetGateView;
	}

      /********* GetGatewayName Functions Ends ********************************/
	  /********* ListEditView Functions Starts ********************************/
	function ListEditView($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$sid = base64_decode($_GET['sl_no']);
		$mid = base64_decode($_GET['sensor_id']);
		$comId = base64_decode($_GET['companyId']);
		$bId = base64_decode($_GET['branchId']);
	
		$SelQuery = 'SELECT `'.$tbl.'sensor_master`.*,sensor_model_master.json_format AS json_data_format,sensor_model_master.api_url AS api_post_url FROM  `'.$tbl.'sensor_master`,sensor_model_master WHERE `'.$tbl.'sensor_master`.company_id="'.$comId.'" AND `'.$tbl.'sensor_master`.branch_id="'.$bId.'" AND `'.$tbl.'sensor_master`.slNo="'.$sid.'" AND `'.$tbl.'sensor_master`.sensorCode="'.$mid.'" AND `'.$tbl.'sensor_master`.status="1" AND `'.$tbl.'sensor_master`.sensorModel=sensor_model_master.model_id';      
		$ListEditView = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListEditView', $ListEditView);
		return $ListEditView;
	}
     /********* ListEditView Functions Ends ********************************/
	/********* ListCompany Functions Starts ********************************/
	function ListCompany($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$SelQuery = 'SELECT * FROM  `'.$tbl.'company_master` WHERE isActive="1"';  
		$ListCompanyView = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListCompanyView', $ListCompanyView);
		return $ListCompanyView;
	}
     /********* ListCompany Functions Ends ********************************/
	 /********* ListSensorModel Functions Starts *************************/
	function ListSensorModel()
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$SelSesn = 'SELECT sensor_model_master.*,arka_iot_platform.segmentName AS platformName FROM  `sensor_model_master`,arka_iot_platform WHERE sensor_model_master.platform_id=arka_iot_platform.slNo AND sensor_model_master.status="1" ORDER BY sensor_model_master.model_name ';  
		$GetModel = $this->ExecuteQuery($SelSesn, 'select');
		$objSmarty->assign('GetModel', $GetModel);
		return $GetModel;
	}
	/********* ListSensorModel Functions Ends *******************************/
	/********* ListSensorModel Functions Starts *************************/
	function ListSensorModelPlatform()
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
	    $SelSesnPlat = 'SELECT arka_sensor_master.* FROM  `arka_sensor_master` WHERE arka_sensor_master.slNo="'.base64_decode($_GET["sl_no"]).'"'; 
		$GetModelPlat = $this->ExecuteQuery($SelSesnPlat, 'select');
		$objSmarty->assign('GetModelPlat', $GetModelPlat);
		return $GetModelPlat;
	}
	/********* ListSensorModel Functions Ends *******************************/
	/********* AjaxListSensorModel Functions Starts *************************/
	function AjaxListSensorModel($platform)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$SelSesn = 'SELECT sensor_model_master.*,arka_iot_platform.segmentName AS platformName FROM  `sensor_model_master`,arka_iot_platform WHERE arka_iot_platform.segmentName="'.$platform.'" AND sensor_model_master.platform_id=arka_iot_platform.slNo AND sensor_model_master.status="1" ORDER BY sensor_model_master.model_name ';  
		$GetModel = $this->ExecuteQuery($SelSesn, 'select');
		echo json_encode($GetModel);
		
	//	$objSmarty->assign('GetModel', $GetModel);
	//	return $GetModel;
	}
    /********* AjaxListSensorModel Functions Ends ********************************/
	/********* ListPlatform Functions Starts ********************************/
	function ListPlatform()
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> '')
		{
			$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
			$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
			$branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
			$branchId = $_SESSION['branch_id'];
		}
			$SelQuery = 'SELECT arka_platform_mapping.*,arka_iot_platform.segmentName FROM `arka_platform_mapping`,arka_iot_platform WHERE arka_iot_platform.status="1" AND arka_iot_platform.isActive="1" AND arka_platform_mapping.companyName="'.$comId.'" AND arka_platform_mapping.branch_id="'.$branchId.'" AND arka_platform_mapping.segmentCode =arka_iot_platform.slNo ';  
			$ListPlatform = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListPlatform', $ListPlatform);
			return $ListPlatform;
	}
	function Platform()
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
	
			$SelQuery = 'SELECT * FROM arka_iot_platform WHERE isActive=1';  
			$Platform = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('Platform', $Platform);
			return $Platform;
	}
    /********* ListPlatform Functions Ends ********************************/
	/********* InsertSensor Functions Starts ********************************/
	function InsertSensor($objArray)
	{ 
			global $objSmarty,$config,$nowDate;
			$tbl = $config['DBPrefix'];
			$comId = base64_decode($_GET['companyId']);
			$bid = base64_decode($_GET['branchId']);
			$gid = base64_decode($_GET['gatewayId']);
			$sid = base64_decode($_GET['sl_no']);
			
		if(!$objArray['sensorName']){
			$objSmarty->assign('ErrorMessage', 'Sensor Name should not be blank');
			return false;
		}elseif(!$objArray['model']){
			$objSmarty->assign('ErrorMessage', 'Model should not be blank');
			return false;
		}
		elseif(!$objArray['specification']){
			$objSmarty->assign('ErrorMessage', 'Specification should not be blank');
			return false;
		}
		elseif(!$objArray['setValue']){
			$objSmarty->assign('ErrorMessage', 'Set Value should not be blank');
			return false;
		}
		if($objArray['sensorName'])
		{
			$SelQuerys	= 'SELECT sensorCode as last FROM `arka_sensor_master` WHERE sensorModel LIKE "%'.$objArray['model'].'%" ORDER BY slNo DESC Limit 0,1';
			$SensDetail	= $this->ExecuteQuery($SelQuerys, 'select');
		if($SensDetail[0]['last']!="")
		{ 
			$SensDetail[0]['sensorCode'] = stripslashes($SensDetail[0]['last']);
			$split = explode("-",$SensDetail[0]['sensorCode']);
			$lastval = end($split);
			$autoInc = $lastval + 1;
			$split2 = explode("-".$lastval,$SensDetail[0]['sensorCode']);
			$s_id = $split2[0]."-".$autoInc;
		} else
		{
			$s_id = $objArray['model']."-1";
		}
			$SelModSens	= 'SELECT * FROM `sensor_model_master` WHERE model_id ="'.trim(addslashes($objArray['model'])).'"';
			$SensMod	= $this->ExecuteQuery($SelModSens, 'select');
			$concData="GW:".trim(addslashes($objArray['gateway_id']))."/SI:".$s_id."/SMODEL:".trim(addslashes($objArray['model']));
			$apikey=base64_encode($concData);
		
			$InsQuery = 'INSERT INTO `'.$tbl.
			'sensor_master`(`segmentCode`,`segmentName`,`sensorCode`,`sensorName`,`sensorType`,`sensorModel`,`sensorSpecification`,`setValue`,`modbus_slave_id`,`branch_id`,`gateway_id`,`company_id`,`isActive`,`api_key`,`json_format`,`api_url`,`createdBy`,`status`) VALUES("'.trim(addslashes($objArray['platform'])).'","'.trim(addslashes($objArray['platform'])).'","'.$s_id.'","'.trim(addslashes($objArray['sensorName'])).'","'.$SensMod[0]["communication_type"].'","'.trim(addslashes($objArray['model'])).'","'.trim(addslashes($objArray['specification'])).'","'.trim(addslashes($objArray['setValue'])).'","'.trim(addslashes($objArray['modbusSlaveId'])).'","'.$bid.'","'.trim(addslashes($objArray['gateway_id'])).'","'.$comId.'","'.trim(addslashes($objArray['checkVal'])).'","'.$apikey.'","'.$SensMod[0]['json_format'].'","'.$SensMod[0]['api_url'].'","'.trim(addslashes($objArray['created_by'])).'","1")';
			$this->ExecuteQuery($InsQuery, 'insert');
		
			/************* Cron Table date insert for a sensor Starts*********************/
			$first = "SELECT DAY(LAST_DAY('".$nowDate."')) AS LastDay, DAY('".$nowDate."') AS FirstDay, DATE('".$nowDate."') AS startDate";
			$selDate=$this->ExecuteQuery($first, 'select');
			$i=0;
		for($d=$selDate[0]['FirstDay'];$d<=$selDate[0]['LastDay'];$d++)
		{		
			$date= "SELECT DATE_ADD('".$selDate[0]['startDate']."',INTERVAL '".$i."' DAY) AS DT";
			$da=$this->ExecuteQuery($date, 'select');
			$sql = "SELECT * FROM cron_daily_energy_data WHERE recorded_date='".$da[0]['DT']."' AND sensor_code='".$s_id."'";
			$Day=$this->ExecuteQuery($sql, 'select');
			$count = $this->ExecuteQuery($sql, 'numrows');
		if($count=="0")
		{
			$Insert= "INSERT INTO cron_daily_energy_data (company_id,branch_id,gateway_code,sensor_code,recorded_date) VALUES ('".$comId."','".$bid."','".trim(addslashes($objArray['gateway_id']))."','".$s_id."','".$da[0]['DT']."')"; 
			$this->ExecuteQuery($Insert, 'insert');
			$i++;
		}
		else
		{	
		}
		}
				/************* Cron Table date insert for a sensor Ends*********************/
		header('Location:sensorList.php?branchId='.$_GET["branchId"].'&companyId='.$_GET["companyId"].'&gatewayId='.$_GET["gatewayId"].'&success_msg_for_insert');
		}
	}
	      /********* InsertSensor Functions Ends ********************************/
		  /********* EditSensor Functions Starts ********************************/
	function EditSensor($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
			$comId = base64_decode($_GET['companyId']);
			$bid = base64_decode($_GET['branchId']);
			$gid = base64_decode($_GET['gatewayId']);
			$sid = base64_decode($_GET['sl_no']);
			$mid= base64_decode($_GET['sensor_id']);
		if(!$objArray['sensorName']){
			$objSmarty->assign('ErrorMessage', 'Sensor Name should not be blank');
			return false;
		}
		elseif(!$objArray['model']){
			$objSmarty->assign('ErrorMessage', 'Model should not be blank');
			return false;
		}
		elseif(!$objArray['specification']){
			$objSmarty->assign('ErrorMessage', 'Specification should not be blank');
			return false;
		}
		if($_GET['sensor_id'] && $objArray['sensorName'])
		{
			$UpdateQuery = 'UPDATE `'.$tbl.
			'sensor_master` SET `sensorName`="'.trim(addslashes($objArray['sensorName'])).'",`sensorSpecification`="'.trim(addslashes($objArray['specification'])).'",`modbus_slave_id`="'.trim(addslashes($objArray['modbusSlaveId'])).'",`isActive`="'.trim(addslashes($objArray['checkVal'])).'" WHERE sensorCode="'.$mid.'" AND slNo="'.$sid.'"'; 
			$this->ExecuteQuery($UpdateQuery, 'update');
			header('Location:sensorList.php?gatewayId='.$_GET["gatewayId"].'&companyId='.$_GET["companyId"].'&branchId='.$_GET["branchId"].'&success_msg_for_update');
		}
	}
      /********* EditSensor Functions Ends ********************************/
	  /********* DeleteSensor Functions Starts ********************************/
	function DeleteSensor($CatIdent)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$sid = base64_decode($_GET['sl_no']);  
		$senid = base64_decode($_GET['sen_code']);  
		$DelQuery = 'update `'.$tbl.'sensor_master` set `status` = "0" WHERE `slNo` ="'.$sid.'" AND `sensorCode` = "'.$senid.'"'; 
		$this->ExecuteQuery($DelQuery, 'update');
		header('Location:' .$_SERVER['PHP_SELF'].'?gatewayId='.$_GET["gatewayId"].'&companyId='.$_GET['companyId'].'&branchId='.$_GET['branchId'].'&succs_msg_for_del');  
	}
     /********* DeleteSensor Functions Ends ********************************/
	 /********* InsertSensorModel Functions Starts ********************************/
	function InsertSensorModel($objArray)
	{ 
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if(!$objArray['modelName']){
			$objSmarty->assign('ErrorMessage', 'Model Name should not be blank');
			return false;
		}elseif(!$objArray['commType']){
			$objSmarty->assign('ErrorMessage', 'Coommuniication Type should not be blank');
			return false;
		}elseif(!$objArray['apiUrl']){
			$objSmarty->assign('ErrorMessage', 'Api Url Type should not be blank');
			return false;
		}elseif(!$objArray['jsonFormat']){
			$objSmarty->assign('ErrorMessage', 'json Format Type should not be blank');
			return false;
		}
		if($objArray['modelName'])
		{
			$InsQuery = 'INSERT INTO `sensor_model_master`(`model_id`, `model_name`, `communication_type`,`platform_id`,`TemHum`,`api_url`,`is_active`,`json_format`,`make`,`no_of_steps`,`capacity`,`level1`,`level2`,`created_date_time`,`status`) VALUES ("'.trim(addslashes($objArray['modelCode'])).'","'.trim(addslashes($objArray['modelName'])).'","'.trim(addslashes($objArray['commType'])).'","'.trim(addslashes($objArray['platform'])).'","'.trim(addslashes($objArray['temHum'])).'","'.trim(addslashes($objArray['apiUrl'])).'","'.trim(addslashes($objArray['checkVal'])).'","'.base64_encode(trim(addslashes($objArray['jsonFormat']))).'","'.trim(addslashes($objArray['make'])).'","'.trim(addslashes($objArray['noOfSteps'])).'","'.trim(addslashes($objArray['capacity'])).'","'.trim(addslashes($objArray['level1'])).'","'.trim(addslashes($objArray['level2'])).'","'.trim(addslashes($objArray['created_date_time'])).'","1")';  
			$this->ExecuteQuery($InsQuery, 'insert');
			header('Location:sensorModelList.php?success_msg_for_insert');
		}
	}
       /********* InsertSensorModel Functions Ends ********************************/
	   /********* EditSensorModelView Functions Starts ********************************/
	function EditSensorModelView($slNo)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$SelQuery = 'SELECT * FROM  `sensor_model_master` WHERE sl_no="'.base64_decode($slNo).'" ';
		$ListEditView = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('ListEditView', $ListEditView);
		return $ListEditView;
	}
     /********* EditSensorModelView Functions Ends ********************************/
	 /********* EditSensorModel Functions Starts ********************************/
	function EditSensorModel($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		if(!$objArray['modelName']){
			$objSmarty->assign('ErrorMessage', 'Model Name should not be blank');
			return false;
		}elseif(!$objArray['commType']){
			$objSmarty->assign('ErrorMessage', 'Coommuniication Type should not be blank');
			return false;
		}elseif(!$objArray['apiUrl']){
			$objSmarty->assign('ErrorMessage', 'Api Url Type should not be blank');
			return false;
		}elseif(!$objArray['jsonFormat']){
			$objSmarty->assign('ErrorMessage', 'json Format Type should not be blank');
			return false;
		}
		if($objArray['modelName'])
		{
			$UpdateQuery = 'UPDATE `sensor_model_master` SET `model_id`="'.trim(addslashes($objArray['modelCode'])).'",`model_name`="'.trim(addslashes($objArray['modelName'])).'",`communication_type`="'.trim(addslashes($objArray['commType'])).'",`temHum`="'.trim(addslashes($objArray['temHum'])).'",`api_url`="'.trim(addslashes($objArray['apiUrl'])).'",`is_active`="'.trim(addslashes($objArray['checkVal'])).'",`json_format`="'.base64_encode(trim($objArray['jsonFormat'])).'",`make`="'.trim(addslashes($objArray['make'])).'",`no_of_steps`="'.trim(addslashes($objArray['noOfSteps'])).'",`capacity`="'.trim(addslashes($objArray['capacity'])).'",`level1`="'.trim(addslashes($objArray['level1'])).'",`level2`="'.trim(addslashes($objArray['level2'])).'" WHERE sl_no="'.base64_decode($_GET["sl_no"]).'"';  
			$this->ExecuteQuery($UpdateQuery, 'update');
			header('Location:sensorModelList.php?success_msg_for_update');
		}
	}
     /********* EditSensorModel Functions Ends ********************************/  
	 /********* DeleteSensorModel Functions Starts ********************************/  
	function DeleteSensorModel($CatIdent)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$sid = base64_decode($CatIdent);  
		$DelQuery = 'update `sensor_model_master` set `status` = "0" WHERE `sl_no` ="'.$sid.'" '; 
		$this->ExecuteQuery($DelQuery, 'update');
		header('Location:' .$_SERVER['PHP_SELF'].'?succs_msg_for_del');  
	}
      /********* DeleteSensorModel Functions Ends ********************************/ 
	  /********* GetPlatformList Functions Starts ********************************/  
	function GetPlatformList($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$SelSensorModel = 'SELECT * FROM `sensor_model_master` WHERE sl_no="'.base64_decode($_GET["sl_no"]).'"'; 
		$SensorModel = $this->ExecuteQuery($SelSensorModel, 'select');
		$objSmarty->assign('SensorModel', $SensorModel);	
		
		$SelPlat = 'SELECT * FROM `arka_iot_platform`'; 
		$GetPlatform = $this->ExecuteQuery($SelPlat, 'select');
		$objSmarty->assign('GetPlatform', $GetPlatform);
	}
	 /********* GetPlatformList Functions Ends ********************************/ 
	  /********* ParameterDetailView Functions Starts ********************************/ 
	function ParameterDetailView()
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$SelAssignParm = 'SELECT * FROM `sensor_model_parameter_mapping` WHERE sensor_model_id="'.base64_decode($_GET["sl_no"]).'" '; 
		$GetParmDet = $this->ExecuteQuery($SelAssignParm, 'select');
		$objSmarty->assign('GetParmDet', $GetParmDet);		
	}
      /********* ParameterDetailView Functions Ends ********************************/ 
	  /********* GetSensorModelParameter Functions Starts ********************************/ 
	function GetSensorModelParameter($sensorType,$senModId)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if($sensorType=='Energy Meter')
		{
		$whrclause='energy_data_master_view WHERE Field!="energy_data_id" AND Field!="gateway_code" AND Field!="sensor_code" AND Field!="sensor_model" AND Field!="METER_ID" AND Field!="VR_ARRAY_VALUE" AND Field!="linux_date_time" AND Field!="teltonika_date_time" AND Field!="recorded_date_time" AND Field!="posted_date_time" AND Field!="M_TIMESTAMP" AND Field NOT IN (SELECT parameter_name FROM sensor_model_parameter_mapping WHERE sensor_model_id="'.$senModId.'") ';
		}
		elseif($sensorType=='Temperature')
		{
		$whrclause='temperature_data_master WHERE Field!="temperature_data_id" AND Field!="gateway_code" AND Field!="sensor_code" AND Field!="sensor_model" AND Field!="linux_date_time" AND Field!="recorded_date_time" AND Field!="posted_date_time" AND Field NOT IN (SELECT parameter_name FROM sensor_model_parameter_mapping WHERE sensor_model_id="'.$senModId.'")';
		}
		elseif($sensorType=='Water Level')
		{
		$whrclause='water_level WHERE Field!="sl_no" AND Field!="device_id" AND Field!="M_TIMESTAMP" AND Field NOT IN (SELECT parameter_name FROM sensor_model_parameter_mapping WHERE sensor_model_id="'.$senModId.'")';
		}
		elseif($sensorType=='Heinn IoT')
		{
	    $whrclause='heinn_iot_data_master_view WHERE Field!="heinn_data_master_id" AND Field!="gateway_code" AND Field!="sensor_code" AND Field!="sensor_model" AND Field!="json_data" AND Field!="linux_date_time" AND Field!="teltonika_date_time" AND Field!="recorded_date_time" AND Field!="posted_date_time" AND Field!="M_TIMESTAMP" AND Field NOT IN (SELECT parameter_name FROM sensor_model_parameter_mapping WHERE sensor_model_id="'.$senModId.'") ';
		}
		elseif($sensorType=='Power Factor')
		{
		$whrclause='power_factor_energy_data_view WHERE Field!="power_factor_id" AND Field!="gateway_code" AND Field!="sensor_code" AND Field!="sensor_model" AND Field!="VR_ARRAY_VALUE" AND Field!="linux_date_time" AND Field!="teltonika_date_time" AND Field!="recorded_date_time" AND Field!="posted_date_time" AND Field!="M_TIMESTAMP" AND Field NOT IN (SELECT parameter_name FROM sensor_model_parameter_mapping WHERE sensor_model_id="'.$senModId.'") ';
		}
			$SelQuery = 'SHOW COLUMNS FROM '.$whrclause.''; 
			$GetParameter = $this->ExecuteQuery($SelQuery, 'select');
			echo json_encode($GetParameter);
	}
       /********* GetSensorModelParameter Functions Ends ********************************/ 
	   /********* AssignedParameter Functions Starts ********************************/ 
	function AssignedParameter($sensorType,$senModId)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		
		$SelAssignParm = 'SELECT * FROM `sensor_model_parameter_mapping` WHERE sensor_model_id="'.$senModId.'" '; 
		$GetAssignParm = $this->ExecuteQuery($SelAssignParm, 'select');
		echo json_encode($GetAssignParm);
	}
	/********* AssignedParameter Functions Ends ********************************/ 
	/********* InsertsensorModelMapping Functions Starts ********************************/ 
	function InsertsensorModelMapping($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if(!$objArray['sensorModId']){
			$objSmarty->assign('ErrorMessage', 'Sensor Model Id should not be blank');
			return false;
		}
			$DelQuery = 'DELETE FROM `sensor_model_parameter_mapping` WHERE `sensor_model_id` ="'.$objArray['sensorModId'].'"';
			$this->ExecuteQuery($DelQuery, 'delete');
			$arrs = $objArray["dexam16"];
		
		foreach($arrs as $key=>$value)
		{
			$InsQuery = 'INSERT INTO `sensor_model_parameter_mapping`(
			`sensor_model_id`,
			`platform_type`,
			`parameter_name`
			) 
			VALUES(
			"'.$objArray['sensorModId'].'",
			"'.$objArray['platformType'].'",
			"'.$value.'"
			)';
			$this->ExecuteQuery($InsQuery, 'insert');
		}
			header('Location:sensorModelList.php?success_msg_for_insert');  
	}
     /********* InsertsensorModelMapping Functions Ends ********************************/ 
	 /********* ListFeederForm Functions Starts ********************************/ 
	 function ListFeederForm($objArray)
    {
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> '')
		{
			$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
			$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
			$branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
			$branchId = $_SESSION['branch_id'];
		}
		//	$SelQuery = 'SELECT feeder_master.*,arka_sensor_master.gateway_id,arka_sensor_master.sensorModel FROM `feeder_master`,arka_sensor_master WHERE feeder_master.sensor_code=arka_sensor_master.sensorCode AND feeder_master.company_id="'.$comId.'" AND feeder_master.branch_id="'.$branchId.'" AND feeder_master.status="1"';
			$SelQuery = 'SELECT * FROM arka_sensor_master WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND isActive="1"';
			$ListFeedForm = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListFeedForm', $ListFeedForm);
	}
	   /********* InsertsensorModelMapping Functions Ends ********************************/ 
	   /********* ListFeeder Functions Ends ********************************/ 
	function ListFeeder($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> '')
		{
			$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
			$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
			$branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
			$branchId = $_SESSION['branch_id'];
		}
			$SelQuery = 'SELECT * FROM `'.$tbl.'sensor_master` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'"  AND feeder_status="0" AND isActive="1" AND status="1"';
			$ListFeeder = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListFeeder', $ListFeeder);
			return $ListFeeder;
	}
     /********* ListFeeder Functions Ends ********************************/ 
	 /********* EditViewFeederForm Functions Starts ********************************/ 
	function EditViewFeederForm($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> '')
		{
			$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
			$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
			$branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
			$branchId = $_SESSION['branch_id'];
		}
		
		if($_SESSION["USER_GROUP"]=="Heinn Admin"){
		    
		   $sens= 'arka_sensor_master.sensorCode ="YMN-1"';
		}else{
		    $sens= 'arka_sensor_master.slNo ="'.base64_decode($objArray).'"';
		    
		}
		
    		$SelQuery = 'SELECT arka_sensor_master . * , sensor_model_master . * 
			FROM `arka_sensor_master` , sensor_model_master
			WHERE arka_sensor_master.sensorModel = sensor_model_master.model_id
			AND '.$sens.''; 
			$EditViewFeedForm = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('EditViewFeedForm', $EditViewFeedForm);
		
	     	$SelAlertPar = 'SELECT * from alert_parameter_mapping WHERE sensor_code="'.$EditViewFeedForm[0]["sensorCode"].'"';
			$alertParameterList = $this->ExecuteQuery($SelAlertPar, 'select');
			$objSmarty->assign('alertParameterList', $alertParameterList);
		
		    $SelSensPar = 'SELECT * FROM `sensor_model_parameter_mapping` WHERE sensor_model_id="'.$EditViewFeedForm[0]["sl_no"].'"'; 
			$sensorParam = $this->ExecuteQuery($SelSensPar, 'select');
			$objSmarty->assign('sensorParam', $sensorParam);
	}
	  /********* EditViewFeederForm Functions Ends ********************************/ 
	  /********* ListFeederTree Functions Starts ********************************/ 
	function ListFeederTree($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> '')
		{
			$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
			$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
			$branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
			$branchId = $_SESSION['branch_id'];
		}
		
			$SelMain = 'SELECT * FROM `feeder_master` WHERE feeder_type="Main Meter" AND company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND is_active="1" AND status="1"';
			$ListMainMeter = $this->ExecuteQuery($SelMain, 'select');
			$objSmarty->assign('ListMainMeter', $ListMainMeter);
		
			$SelSub = 'SELECT * FROM `feeder_master` WHERE feeder_type="Sub Meter" AND company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND is_active="1" AND status="1"';
			$ListSubMeter = $this->ExecuteQuery($SelSub, 'select');
			$objSmarty->assign('ListSubMeter', $ListSubMeter);
		
			$SelSubSub = 'SELECT * FROM `feeder_master` WHERE feeder_type="Sub Sub Meter" AND company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND is_active="1" AND status="1"'; 
			$ListSubSubMeter = $this->ExecuteQuery($SelSubSub, 'select');
			$objSmarty->assign('ListSubSubMeter', $ListSubSubMeter);
	}
	 /********* ListFeederTree Functions Ends ********************************/ 
/*** EditFeederForm Functions Starts ************/ 
	function EditFeederForm($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		
		if(!$objArray['sensorName']){
			$objSmarty->assign('ErrorMessage', 'sensor Name should not be blank');
			return false;
		}/*elseif(!$objArray['feederType']){
			$objSmarty->assign('ErrorMessage', 'Feeder Type should not be blank');
			return false;
		}*/
		
		if($_GET['companyId'] <> '')
		{
			$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
			$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
			$branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
			$branchId = $_SESSION['branch_id'];
		}
		//	$updQuery = 'UPDATE `feeder_master` SET feeder_name="'.trim(addslashes($objArray['feederName'])).'",unit_rate="'.trim(addslashes($objArray['unitRate'])).'",kw_max_value="'.trim(addslashes($objArray['kwMaxValue'])).'",kva_max_value="'.trim(addslashes($objArray['kvaMaxValue'])).'",kvar_max_value="'.trim(addslashes($objArray['kvarMaxValue'])).'",`contact_person`="'.trim(addslashes($objArray['contact_person'])).'",`contact_no`="'.trim(addslashes($objArray['contact_no'])).'",`email_id`="'.trim(addslashes($objArray['email_id'])).'",is_active="'.trim(addslashes($objArray['checkVal'])).'"  WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1" AND feeder_master_id="'.base64_decode($_GET["sl_no"]).'"';  
			$updQuery = 'UPDATE `arka_sensor_master` SET sensorName="'.trim(addslashes($objArray['sensorName'])).'",level1="'.trim(addslashes($objArray['level1'])).'",level2="'.trim(addslashes($objArray['level2'])).'",unit_rate="'.trim(addslashes($objArray['unitRate'])).'",dg_unit_rate="'.trim(addslashes($objArray['dgunitRate'])).'",kw_max_value="'.trim(addslashes($objArray['kwMaxValue'])).'",kva_max_value="'.trim(addslashes($objArray['kvaMaxValue'])).'",kvar_max_value="'.trim(addslashes($objArray['kvarMaxValue'])).'",kwh_max_value="'.trim(addslashes($objArray['kwhMaxValue'])).'",kvah_max_value="'.trim(addslashes($objArray['kvahMaxValue'])).'",kvarh_max_value="'.trim(addslashes($objArray['kvarhMaxValue'])).'",`contact_person`="'.trim(addslashes($objArray['contact_person'])).'",`contact_no`="'.trim(addslashes($objArray['contact_no'])).'",`email_id`="'.trim(addslashes($objArray['email_id'])).'"  WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND slNo="'.base64_decode($_GET["sl_no"]).'"';  
			$UpdateFeedForm = $this->ExecuteQuery($updQuery, 'update');
			header('Location:sensorList.php?companyId='.$_GET["companyId"].'&branchId='.$_GET["branchId"].'&success_msg_for_update');
	}
	
	 /********* EditFeederForm Functions Ends ********************************/ 
	 /**************************         Ajax Feeder Type Starts       **************************************/
	 function ListFeederType($objArray)
    {
        global $objSmarty,$config;
        $tbl = $config['DBPrefix'];

        if($_GET['companyId'] <> '')
        {
            $comId = base64_decode($_GET['companyId']);
        }	
        else
        {
            $comId = $_SESSION['CustomerId'];
        }
        if($_GET['branchId'] <> '')
        {
            $branchId = base64_decode($_GET['branchId']);
        }elseif($_POST['branchId'] <> '')
        {
            $branchId = $_POST['branchId'];
        }	
        else
        {
            $branchId = $_SESSION['branch_id'];
        }

        if($objArray=='Sub Meter'){
            $feederType="Main Meter";
        }
        else if($objArray=='Sub Sub Meter'){
            $feederType="Sub Meter";
        }
        //$SelQuery = 'SELECT * FROM `feeder_master` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND feeder_type="'.$feederType.'"';
        $SelQuery = 'SELECT * FROM `arka_sensor_master` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND feeder_type="'.$feederType.'"';

        $ListFeedType = $this->ExecuteQuery($SelQuery, 'selectassoc');
        $objSmarty->assign('ListFeedType', $ListFeedType);//print_r($ListView);exit;
        echo json_encode($ListFeedType);
		//	return $ListFeedType;
    }

	 /**************************         Ajax Feeder Type Ends         ***********************/
	 /********* InsertAlertParameter Functions starts ********************************/ 
	function InsertAlertParameter($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$selalertPar='SELECT * FROM alert_parameter_mapping WHERE sensor_code="'.$objArray['sensor_id'].'" AND parameter_name="'.$objArray['parameterName'].'"';
		$checkDuplicate=$this->ExecuteQuery($selalertPar, 'numrows');

		if($checkDuplicate==0){
		$InsQuery = 'INSERT INTO `alert_parameter_mapping`(
		`sensor_code`,
		`gateway_code`,
		`sensor_model_id`,
		`company_id`,
		`branch_id`,
		`feeder_name`,
		`parameter_name`,
		`min_alert_value`,
		`max_alert_value`,
		`mail_alert_status`
		) 
		VALUES(
		"'.$objArray['sensor_id'].'",
		"'.$objArray['gateway_id'].'",
		"'.$objArray['sensor_model_id'].'",
		"'.$objArray['company_id'].'",
		"'.$objArray['branch_id'].'",
		"'.$objArray['feederName'].'",
		"'.$objArray['parameterName'].'",
		"'.$objArray['minAlertValue'].'",
		"'.$objArray['maxAlertValue'].'",
		"Normal"
		)';
		$this->ExecuteQuery($InsQuery, 'insert');
		$currentUrl=$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING']; 
		$splitURL=explode("&succ", $currentUrl);
		header('Location:' .$splitURL[0].'&success_msg_for_insert');
		}else{
		$currentUrl=$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING']; 
		if(isset($_GET['ErrorMessage'])){
		$expVal="&ErrorMessage";
		}
		else{
			$expVal="&succ";
		}
		$splitURL=explode($expVal, $currentUrl); 
		header('Location:' .$splitURL[0].'&ErrorMessage');
		$objSmarty->assign('ErrorMessage', 'Parameter Already Exist');
		return false;
		}
	}
	  /********* InsertAlertParameter Functions Ends ********************************/ 
	 /********* DeleteAlertParameter Functions Starts ********************************/ 
	function DeleteAlertParameter($CatIdent)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$sid = base64_decode($CatIdent);  
		$DelQuery = 'Delete FROM `alert_parameter_mapping` WHERE `alert_parameter_id` ="'.$sid.'"'; 
		$this->ExecuteQuery($DelQuery, 'update');
		$currentUrl=$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING']; 
		$splitURL=explode("&Delete", $currentUrl); 
		header('Location:' .$splitURL[0].'&succs_msg_for_del');  
	}
     /********* DeleteAlertParameter Functions Ends ********************************/ 
      /********* ListCapacitorValue Functions Starts ********************************/
	function ListCapacitorValue($objArray)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> '')
		{
			$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
			$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
			$branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
			$branchId = $_SESSION['branch_id'];
		}
		$gateId = base64_decode($_GET['gatewayId']);
		$sensorCode = base64_decode($_GET['sensorCode']);
	
	    	$SelQuery = 'SELECT `arka_sensor_master`.* FROM `arka_sensor_master` WHERE sensorCode="'.$sensorCode.'" AND gateway_id="'.$gateId.'" AND status="1" AND isActive="1"';  
			$sensorView = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('sensorView', $sensorView);
	
			$SelQuery = 'SELECT `power_factor_step_capcitor_value_mapping`.* FROM `power_factor_step_capcitor_value_mapping` WHERE sensorCode="'.$sensorCode.'" AND gatewayCode="'.$gateId.'" AND status="1" AND isActive="1"';  
			$ListCapacityView = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListCapacityView', $ListCapacityView);
			return $ListCapacityView;
		
	}
      /********* ListCapacitorValue Functions Ends ********************************/
     	/********* InsertCapacitorValue Functions Starts ********************************/
	function InsertCapacitorValue($objArray)
	{ 
			global $objSmarty,$config,$nowDate;
			$tbl = $config['DBPrefix'];
			$comId = base64_decode($_GET['companyId']);
			$bid = base64_decode($_GET['branchId']);
			$gid = base64_decode($_GET['gatewayId']);
			$sid = base64_decode($_GET['slNo']);
			$scode = base64_decode($_GET['sensorCode']);
			$split = explode("-",$scode);

			$SelModSens	= 'SELECT * FROM `sensor_model_master` WHERE model_id ="'.$split[0].'" AND status="1" AND is_active="1"';
			$SensMod	= $this->ExecuteQuery($SelModSens, 'select');
		
		for($d=1;$d<=$SensMod[0]['no_of_steps'];$d++)
		{		
		    $sn='step'.$d.'_actual_steps_value';
			$Insert= "INSERT INTO power_factor_step_capcitor_value_mapping (sensorCode,gatewayCode,sensorModel,stepNumber,capacityValue,createdBy,isActive,status) VALUES ('".$scode."','".$gid."','".$split[0]."','".$sn."','','".$_SESSION['UserName']."','1','1')";
			$this->ExecuteQuery($Insert, 'insert');
		}
				/************* Cron Table date insert for a sensor Ends*********************/
		header('Location:capacityList.php?slNo='.$_GET["slNo"].'&sensorCode='.$_GET["sensorCode"].'&branchId='.$_GET["branchId"].'&companyId='.$_GET["companyId"].'&gatewayId='.$_GET["gatewayId"].'&success_msg_for_insert');
		}
	
	      /********* InsertCapacitorValue Functions Ends ********************************/
	      	/********* UpdateCapacitorValue Functions Starts ********************************/
	function UpdateCapacitorValue($objArray)
	{ 
			global $objSmarty,$config,$nowDate;
			$tbl = $config['DBPrefix'];
	    	$gid = $objArray['gatewayCode'];
			$scode = $objArray['sensorCode'];
			$split = explode("-",$scode);
			
			$SelModSens	= 'SELECT * FROM `sensor_model_master` WHERE model_id ="'.$split[0].'" AND status="1" AND is_active="1"';
			$SensMod	= $this->ExecuteQuery($SelModSens, 'select');
		
		for($d=1;$d<=$SensMod[0]['no_of_steps'];$d++)
		{
		    $sn='step'.$d.'_actual_steps_value';
		    
			$UpQuery = 'UPDATE `power_factor_step_capcitor_value_mapping` 
            SET 
            `capacityValue`=  "'.trim(addslashes($objArray["capacityValue"][$d])).'"
	        WHERE 
            `stepNumber`="'.trim(addslashes($objArray["stepNumber"][$d])).'" AND sensorCode="'.$scode.'" AND gatewayCode="'.$gid.'" AND sensorModel="'.$split[0].'" and status = "1" and isActive="1" AND slNo="'.trim(addslashes($objArray["sno"][$d])).'"';
             $this->ExecuteQuery($UpQuery, 'update');
		}
		
		    $gid = base64_encode($objArray['gatewayCode']);
			$scode = base64_encode($objArray['sensorCode']);
			header('Location:capacityList.php?slNo='.$_GET["slNo"].'&sensorCode='.$scode.'&branchId='.$_GET["branchId"].'&companyId='.$_GET["companyId"].'&gatewayId='.$gid.'&success_msg_for_update');
	}
}
?>