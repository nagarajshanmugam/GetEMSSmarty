<?php
class Dashboard extends MysqlFns
{
   /********************* DashBoard Constructor Starts *************************/
	function DashBoard()
	{
		$this->LDDisplayPath= $config['SiteGlobalPath']."class.DashBoard.php";
		global $config;
		global $objSmarty;
		global $nowDate;
		$this->Limit = 20;
		$ConLink1 = mysql_connect($config['DBHost'],$config['DBUser'],$config['DBPassword']) or die("Database Connection Failed<br>". mysql_error());
		mysql_select_db($config['DBName'], $ConLink1);
		
		$deliverytime = new DateTime(date('Y-m-d H:i:s'));
		$hour = $deliverytime->format('H');
		$hour=intval($hour);
		//echo $hour; 
		if ($hour >=0 && $hour <8) {
		
			$nowDate='DATE_SUB(NOW(), INTERVAL 1 DAY)';
		} else {
			$nowDate='NOW()';
		}
	}
   /********************* DashBoard Constructor Ends *************************/
  /********************* companyDashoard Functions Starts *************************/
		function companyDashoard()
		{
		   global $objSmarty,$config,$nowDate;
		   $tbl = $config['DBPrefix'];
		
		if($_GET['companyId'] <> '')
		{
		   $comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		   $comId = $_SESSION['CustomerId'];
		}
		
		$ldc=date("Y", strtotime("first day of previous month"));
            $ldl=date("n", strtotime("last day of previous month"));



		
		$gatewayCode=base64_decode($_GET['gatewayCode']);
		$sensorCode=base64_decode($_GET['sensorCode']);
		//echo "am here"; exit;

		$SelCompanyQuery = 'SELECT companyCode FROM arka_company_master WHERE slNo="'.$comId.'" AND status="1"';  
		$SelCompanyQueryView = $this->ExecuteQuery($SelCompanyQuery, 'select');
		$comCode = $SelCompanyQueryView[0]['companyCode'];

		$SelBranchQuery = 'SELECT branch_id FROM arka_branch_master WHERE sl_no="'.$branchId.'" AND record_status="1"';  
		$SelBranchQueryView = $this->ExecuteQuery($SelBranchQuery, 'select');
		$branchCode = $SelBranchQueryView[0]['branch_id'];
		//echo "Company Code".$comCode."<br>";
		//echo "Branch Code".$branchCode."<br>"; 
		



		   $SelPlatformMapQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';  
			$ListPlatformMapView = $this->ExecuteQuery($SelPlatformMapQuery, 'select');

			$energyPF = "Energy Meter";
		    $solarPF = "Solar Inverter";
			$TempPF = "Temperature";

/*********************************   Today Total Energy  Start ********************************************/
		$SelEnergyPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$energyPF.'" AND status="1"';  
		$ListEnergyPlatformView = $this->ExecuteQuery($SelEnergyPlatformQuery, 'select');

		$energySegCode = $ListEnergyPlatformView[0]['segmentCode'];
		$energySegId = $ListEnergyPlatformView[0]['slNo'];
		$objSmarty->assign('energySegId', $energySegId);	


		$SelSolarPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$solarPF.'" AND status="1"';  
		$ListSolarPlatformView = $this->ExecuteQuery($SelSolarPlatformQuery, 'select');
        $solarSegId = $ListSolarPlatformView[0]['slNo'];
		$solarSegCode = $ListSolarPlatformView[0]['segmentCode'];


		   $SelPlatformMapSolarQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE segmentCode="'.$solarSegId.'" AND companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';   
		 $ListPlatformMapSolarView = $this->ExecuteQuery($SelPlatformMapSolarQuery, 'select');
		 $ListPlatformMapSolarViewCount = $this->ExecuteQuery($SelPlatformMapSolarQuery, 'numrows');
		 $objSmarty->assign('solarPlatformCount', $ListPlatformMapSolarViewCount);

		 


		$dailyTableEB = $comCode . "_%" . $branchCode . "%_" . $energySegCode . "_cron_daily";
		$dailyTableSolar = $comCode."_".$branchCode."_".$solarSegCode."_cron_daily";
//echo "Daily Table".$dailyTableEB; 

	   $dailyTable = "TPL_AMBT_E1001_cron_daily";
       $monthlyTable = "TPL_AMBT_E1001_cron_monthly";
       $hourlyTable = "TPL_AMBT_E1001_cron_hourly_".$monthShortCode."_".$yearShortCode;

	       $selDailyTableQry='SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE "'.$dailyTableEB.'"'; 
			// echo'<br/>';
			  $selDailyTableQryExe		= $this->ExecuteQuery($selDailyTableQry, "select");
			  $selDailyTableQryExeCount		= $this->ExecuteQuery($selDailyTableQry, "numrows");
			  //echo $selDailyTableQryExeCount;
			  $dailyTableName = $selDailyTableQryExe[0]['TABLE_NAME'];
			  //$selTableQryExeCount = $selTableQryExe[0]['TOTALNUMBEROFTABLES'];
			  if($selDailyTableQryExeCount <= 0){

			  //echo"am in if"; exit;

			  }else{

			$comDailyEBTable = $selDailyTableQryExe[0]['TABLE_NAME'];

			//echo $comDailyEBTable; exit;

			 $selQry ='SELECT IFNULL(last_month.TOTAL_KWH,0) AS last_month_kwh,IFNULL(curr_month.TOTAL_KWH,0) AS this_month_kwh,IFNULL(curr_month.cost,0) AS this_month_cost,IFNULL(last_month.cost,0) AS last_month_cost,IFNULL(curr_month.branch_id,last_month.branch_id) AS branch_id ,last_month.branch_id FROM (SELECT SUM(`consuption_kwh`) AS TOTAL_KWH,SUM(`consuption_cost`) AS cost,branch_id,recorded_date FROM '.$comDailyEBTable.' WHERE company_id="'.$comId.'" AND MONTH(recorded_date)=MONTH(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE)) AND feeder_type="Main Meter" GROUP BY branch_id) AS curr_month , (SELECT SUM(`consuption_kwh`) AS TOTAL_KWH,SUM(`consuption_cost`) AS cost,branch_id,recorded_date FROM '.$comDailyEBTable.' WHERE company_id="'.$comId.'" AND MONTH(recorded_date)=MONTH(DATE_SUB(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE),INTERVAL "1" MONTH)) AND feeder_type="Main Meter" GROUP BY branch_id) AS last_month'; 

			
		
		//$selQry ='SELECT IFNULL(last_month.TOTAL_KWH,0) AS last_month_kwh,IFNULL(curr_month.TOTAL_KWH,0) AS this_month_kwh,IFNULL(curr_month.cost,0) AS this_month_cost,IFNULL(last_month.cost,0) AS last_month_cost,IFNULL(curr_month.branch_id,last_month.branch_id) AS branch_id ,last_month.branch_id FROM (SELECT SUM(`consuption_kwh`) AS TOTAL_KWH,SUM(`consuption_cost`) AS cost,branch_id,recorded_date FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND MONTH(recorded_date)=MONTH(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE)) AND feeder_type="Main Meter" GROUP BY branch_id) AS curr_month , (SELECT SUM(`consuption_kwh`) AS TOTAL_KWH,SUM(`consuption_cost`) AS cost,branch_id,recorded_date FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND MONTH(recorded_date)=MONTH(DATE_SUB(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE),INTERVAL "1" MONTH)) AND feeder_type="Main Meter" GROUP BY branch_id) AS last_month';
		$MonthCostKWH		= $this->ExecuteQuery($selQry, "select");
		$objSmarty->assign('MonthCostKWH', $MonthCostKWH);
		
		$selQryCurr ='SELECT SUM(consuption_kwh+dg_consuption_kwh) AS TOTAL_KWH,SUM(consuption_cost+dg_consuption_cost) AS cost,branch_id,recorded_date FROM '.$comDailyEBTable.' WHERE company_id="'.$comId.'" AND MONTH(recorded_date)=MONTH(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE)) AND YEAR(recorded_date)=YEAR('.$nowDate.') AND feeder_type="Main Meter" GROUP BY branch_id';
		$currMonthCostKWH		= $this->ExecuteQuery($selQryCurr, "select");
		$objSmarty->assign('currMonthCostKWH', $currMonthCostKWH);
		
		 $selQryLast ='SELECT SUM(consuption_kwh+dg_consuption_kwh) AS TOTAL_KWH,SUM(consuption_cost+dg_consuption_cost) AS cost,branch_id,recorded_date FROM '.$comDailyEBTable.' WHERE company_id="'.$comId.'" AND MONTH(recorded_date)="'.$ldl.'" AND YEAR(recorded_date)="'.$ldc.'" AND feeder_type="Main Meter" GROUP BY branch_id'; 
		$lastMonthCostKWH		= $this->ExecuteQuery($selQryLast, "select");
		$objSmarty->assign('lastMonthCostKWH', $lastMonthCostKWH);

			  }
		
		$selQry2='SELECT * from arka_branch_master WHERE company_id="'.$comId.'"'; 
		$branchList		= $this->ExecuteQuery($selQry2, "select");
		$objSmarty->assign('branchList', $branchList);
	
		}
     /********************* companyDashoard Functions Ends *************************/
 /**********************************          Company Dashboard  Multi Line Graph *******************************************/
 
	function GetMultiLineGraph(){
	global $objSmarty,$config,$nowDate;
	
	$cm = date('m');
		$cmon = date('m');//echo $cmon;echo "<br>";
	    $lmon = date('m', strtotime('-5 month'));//echo $lmon;echo "<br>";
			$pyr = date('Y')-1;
			$cyr = date('Y');
			$nyr = date('Y')+1;
			if($cm >= '06')
			{
			$sd=$cyr.'-'.$lmon.'-01';
			$ed=$cyr.'-'.$cmon.'-31';
			}
			else
			{
		    $sd=$pyr.'-'.$lmon.'-01';
			$ed=$cyr.'-'.$cmon.'-31';
			}
	
	if($_GET['companyId'] <> '')
	{
	$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
	$comId = $_SESSION['CustomerId'];
	}
	 $selBranch='SELECT * from arka_branch_master WHERE company_id="'.$comId.'" AND is_active="1"';  
	$branchDet		= $this->ExecuteQuery($selBranch, "select");
	
	$branchParmCost='';
	//$branchParmKwh='';
	foreach($branchDet as $key=>$value)
	{
	$branchParmCost .='{
	"title": "'.$branchDet[$key]["branch_name"].'",
	"balloonText": "[[title]]: <b>Rs.[[value]]</b>",
	"bullet": "round",
	"bulletSize": 10,
	"bulletBorderColor": "#ffffff",
	"bulletBorderAlpha": 1,
	"bulletBorderThickness": 2,
	"type": "smoothedLine",
	"valueField": "'.$branchDet[$key]["branch_name"].'"
	},';
	
	/*$branchParmKwh .='{
	"title": "'.$branchDet[$key]["branch_name"].'",
	"balloonText": "[[title]]: <b>[[value]] kwh</b>",
	"bullet": "round",
	"bulletSize": 10,
	"bulletBorderColor": "#ffffff",
	"bulletBorderAlpha": 1,
	"bulletBorderThickness": 2,
	"type": "smoothedLine",
	"valueField": "'.$branchDet[$key]["branch_name"].'"
	},';*/
	
	}
	$multiLineGraphsCost="[".rtrim($branchParmCost, ",")."]";
	//echo $multiLineGraphs; exit;
	$objSmarty->assign('multiLineGraphsCost',$multiLineGraphsCost);
	
	//$multiLineGraphsKwh="[".rtrim($branchParmKwh, ",")."]";
	//echo $multiLineGraphs; exit;
	//$objSmarty->assign('multiLineGraphsKwh',$multiLineGraphsKwh);

	
	
	
//	 $selMonth='SELECT DATE_FORMAT(recorded_date,"%b") AS month_data,recorded_date,consuption_cost  FROM cron_monthly_energy_data WHERE company_id="'.$comId.'" AND MONTH(recorded_date)<=MONTH('.$nowDate.') AND recorded_date BETWEEN "'.$sd.'" AND "'.$ed.'" GROUP BY recorded_date ';

$SelCompanyQuery = 'SELECT companyCode FROM arka_company_master WHERE slNo="'.$comId.'" AND status="1"';  
		$SelCompanyQueryView = $this->ExecuteQuery($SelCompanyQuery, 'select');
		$comCode = $SelCompanyQueryView[0]['companyCode'];

		$SelBranchQuery = 'SELECT branch_id FROM arka_branch_master WHERE sl_no="'.$branchId.'" AND record_status="1"';  
		$SelBranchQueryView = $this->ExecuteQuery($SelBranchQuery, 'select');
		$branchCode = $SelBranchQueryView[0]['branch_id'];
		//echo "Company Code".$comCode."<br>";
		//echo "Branch Code".$branchCode."<br>"; 
		



		   $SelPlatformMapQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';  
			$ListPlatformMapView = $this->ExecuteQuery($SelPlatformMapQuery, 'select');

			$energyPF = "Energy Meter";
		    $solarPF = "Solar Inverter";
			$TempPF = "Temperature";

/*********************************   Today Total Energy  Start ********************************************/
		$SelEnergyPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$energyPF.'" AND status="1"';  
		$ListEnergyPlatformView = $this->ExecuteQuery($SelEnergyPlatformQuery, 'select');

		$energySegCode = $ListEnergyPlatformView[0]['segmentCode'];
		$energySegId = $ListEnergyPlatformView[0]['slNo'];
		$objSmarty->assign('energySegId', $energySegId);	


		$SelSolarPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$solarPF.'" AND status="1"';  
		$ListSolarPlatformView = $this->ExecuteQuery($SelSolarPlatformQuery, 'select');
        $solarSegId = $ListSolarPlatformView[0]['slNo'];
		$solarSegCode = $ListSolarPlatformView[0]['segmentCode'];


		   $SelPlatformMapSolarQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE segmentCode="'.$solarSegId.'" AND companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';   
		 $ListPlatformMapSolarView = $this->ExecuteQuery($SelPlatformMapSolarQuery, 'select');
		 $ListPlatformMapSolarViewCount = $this->ExecuteQuery($SelPlatformMapSolarQuery, 'numrows');
		 $objSmarty->assign('solarPlatformCount', $ListPlatformMapSolarViewCount);

		 


		$dailyTableEB = $comCode . "_%" . $branchCode . "%_" . $energySegCode . "_cron_daily";
		$dailyTableSolar = $comCode."_".$branchCode."_".$solarSegCode."_cron_daily";
//echo "Daily Table".$dailyTableEB; 

	   $dailyTable = "TPL_AMBT_E1001_cron_daily";
       $monthlyTable = "TPL_AMBT_E1001_cron_monthly";
       $hourlyTable = "TPL_AMBT_E1001_cron_hourly_".$monthShortCode."_".$yearShortCode;

	       $selDailyTableQry='SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE "'.$dailyTableEB.'"'; 
			// echo'<br/>';
			  $selDailyTableQryExe		= $this->ExecuteQuery($selDailyTableQry, "select");
			  $selDailyTableQryExeCount		= $this->ExecuteQuery($selDailyTableQry, "numrows");
			  //echo $selDailyTableQryExeCount;
			  $dailyTableName = $selDailyTableQryExe[0]['TABLE_NAME'];
			  //$selTableQryExeCount = $selTableQryExe[0]['TOTALNUMBEROFTABLES'];
			  if($selDailyTableQryExeCount <= 0){

			  //echo"am in if"; exit;

			  }else{

			$comDailyEBTable = $selDailyTableQryExe[0]['TABLE_NAME'];


 //$selMonth='SELECT DATE_FORMAT(recorded_date,"%b") AS month_data,recorded_date,consuption_cost  FROM '.$comDailyEBTable.' WHERE company_id="'.$comId.'" AND recorded_date BETWEEN "'.$sd.'" AND "'.$ed.'" GROUP BY recorded_date '; 

 $selMonth = 'SELECT DATE_FORMAT(recorded_date,"%b") AS month_data,MONTH(recorded_date) AS month_no,YEAR(recorded_date) AS year_no
FROM '.$comDailyEBTable.' WHERE company_id="'.$comId.'" AND recorded_date BETWEEN "'.$sd.'" AND "'.$ed.'" GROUP BY YEAR(recorded_date), MONTH(recorded_date) ORDER BY YEAR(recorded_date), MONTH(recorded_date)';
	$getMonth= $this->ExecuteQuery($selMonth, "select");
	//echo $getMonth[0]["recorded_date"];exit;
//	$ExeBarGraphCount		= $this->ExecuteQuery($getMonth, "numrows");
	$catCost='';
	//$catkwh='';
	foreach($getMonth as $month=>$value2)
	{
		$branchCost='';
		//$branchKwh='';
	 	foreach($branchDet as $branch=>$value)
		{
	//	 $selMonth='SELECT DATE_FORMAT(recorded_date,"%b") AS month_data, SUM(consuption_cost) AS consuption_cost , SUM(consuption_kwh) AS consuption_kwh FROM cron_monthly_energy_data WHERE company_id="'.$comId.'" AND branch_id="'.$branchDet[$branch]["sl_no"].'" AND feeder_type="Main Meter" AND recorded_date="'.$getMonth[$month]["recorded_date"].'" '; 
		  //$selMonth='SELECT DATE_FORMAT(recorded_date,"%b") AS month_data, SUM(consuption_cost+dg_consuption_cost) AS consuption_cost , SUM(consuption_kwh+dg_consuption_kwh) AS consuption_kwh FROM '.$comDailyEBTable.' WHERE company_id="'.$comId.'" AND branch_id="'.$branchDet[$branch]["sl_no"].'" AND feeder_type="Main Meter" AND MONTH(recorded_date)=MONTH("'.$getMonth[$month]["recorded_date"].'") AND YEAR(recorded_date)=YEAR("'.$getMonth[$month]["recorded_date"].'") '; 

		  $selMonth = 'SELECT COALESCE(SUM(consuption_cost + dg_consuption_cost),0) AS consuption_cost,SUM(consuption_kwh + dg_consuption_kwh) AS consuption_kwh FROM '.$comDailyEBTable.' WHERE company_id="'.$comId.'" AND branch_id="'.$branchDet[$branch]["sl_no"].'"
AND feeder_type="Main Meter" AND MONTH(recorded_date)="'.$getMonth[$month]["month_no"].'" AND YEAR(recorded_date)="'.$getMonth[$month]["year_no"].'"';

			 $costDet		= $this->ExecuteQuery($selMonth, "select");
 			 $va = number_format($costDet[0]['consuption_cost'], 2, '.', '');
			 $branchCost .= ',"'.$branchDet[$branch]["branch_name"].'":'.$va; 
			// $branchKwh.= ',"'.$branchDet[$branch]["branch_name"].'":'.$costDet[0]['consuption_kwh']; ;
		}
		$catCost .='{"month": "'.$getMonth[$month]["month_data"].'"'.$branchCost.'},';
		//$catkwh .='{"category": "'.$getMonth[$month]["month_data"].'"'.$branchKwh.'},';
	
	}
	$multiLineDataProviderCost="[".rtrim($catCost, ",")."]";
	$objSmarty->assign('multiLineDataProviderCost',$multiLineDataProviderCost);
	
/*	$multiLineDataProviderKwh="[".rtrim($catkwh, ",")."]";
	$objSmarty->assign('multiLineDataProviderKwh',$multiLineDataProviderKwh);
*/	
			  }

	
	
}
      /********************* GetMultiLineGraph Functions Ends **********************/
	 
	  /******************** IncidentLog Functions Starts **************************/
		function IncidentLog()
		{
		global $objSmarty,$config,$nowDate;
		$tbl = $config['DBPrefix'];
		
		if($_GET['companyId'] <> '')
		{
		   $comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		   $comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		   $branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		   $branchId = $_SESSION['branch_id'];
		}
		if($branchId =='0')
		{
		   $whrClass=' AND alert_log_master.company_id="'.$comId.'"';
		}else
		{
		   $whrClass=' AND alert_log_master.company_id="'.$comId.'" AND alert_log_master.branch_id="'.$branchId.'"';
		
		}
			$selIncidentLog = 'SELECT alert_log_master.*,arka_sensor_master.sensorName FROM `alert_log_master`,arka_sensor_master WHERE alert_log_master.sensor_code=arka_sensor_master.sensorCode'.$whrClass.' ORDER BY recorded_date_time DESC LIMIT 0,3'; 
			$incidentList		= $this->ExecuteQuery($selIncidentLog, "select");
			$objSmarty->assign('incidentList', $incidentList);
		}
         /******************** IncidentLog Functions Ends **************************/
          /******************** IncidentLog Functions Starts **************************/
		function recentIncidentLog()
		{
		global $objSmarty,$config,$nowDate;
		$tbl = $config['DBPrefix'];
		
		if($_GET['companyId'] <> '')
		{
		   $comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		   $comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		   $branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		   $branchId = $_SESSION['branch_id'];
		}
		if($branchId =='0')
		{
		   $whrClass=' AND alert_log_master.company_id="'.$comId.'"';
		}else
		{
		   $whrClass=' AND alert_log_master.company_id="'.$comId.'" AND alert_log_master.branch_id="'.$branchId.'"';
		
		}
		
			if(isset($_POST['date1']) && isset($_POST['date2']))
	{
		$date1 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		$date2 = date("Y-m-d",strtotime(trim(addslashes($_POST['date2']))));
		$selIncidentLog = 'SELECT alert_log_master.*,arka_sensor_master.sensorName  FROM `alert_log_master`,arka_sensor_master WHERE alert_log_master.sensor_code=arka_sensor_master.sensorCode'.$whrClass.' AND DATE(recorded_date_time) BETWEEN "'.$date1.'" AND "'.$date2.'" ORDER BY recorded_date_time DESC'; 
	}
	else
	{
	     $selIncidentLog = 'SELECT alert_log_master.*,arka_sensor_master.sensorName  FROM `alert_log_master`,arka_sensor_master WHERE alert_log_master.sensor_code=arka_sensor_master.sensorCode'.$whrClass.' ORDER BY recorded_date_time DESC'; 
	}
		//	echo $selIncidentLog;
			$incidentList		= $this->ExecuteQuery($selIncidentLog, "select");
			$objSmarty->assign('incidentList', $incidentList);
		}
         /******************** IncidentLog Functions Ends **************************/
	     /******************** GetDashboardDetails Functions Starts ****************/
		function GetDashboardDetails($objArray='')
		{
		    global $objSmarty;
		if($_GET['companyId'] <> '')
		{
		   $comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		   $comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		   $branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		   $branchId = $_SESSION['branch_id'];
		}
		   $SelQuery_loc = 'SELECT arka_company_master.companyName,arka_branch_master.branch_name,arka_sensor_master.* ,arka_gateway_master.place_of_installation FROM arka_company_master,arka_branch_master,arka_sensor_master,arka_gateway_master WHERE arka_sensor_master.gateway_id="'.base64_decode($_GET["gatewayCode"]).'" AND arka_sensor_master.sensorCode="'.base64_decode($_GET["sensorCode"]).'" AND arka_sensor_master.gateway_id=arka_gateway_master.gateway_id AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.company_id=arka_company_master.slNo AND arka_branch_master.company_id=arka_sensor_master.company_id AND arka_branch_master.company_id=arka_company_master.slNo AND arka_branch_master.sl_no=arka_sensor_master.branch_id' ;
		   $LoctList		= $this->ExecuteQuery($SelQuery_loc, "select");
		   $objSmarty->assign('LoctList', $LoctList);
		   
		  // $SelQuery_mod = 'SELECT sensor_model_master.* FROM sensor_model_master  WHERE sensor_model_master.model_id="'.$LoctList[0]["sensorModel"].'" AND is_active="1" AND status="1"' ;
		    $SelQuery_mod = 'SELECT sensor_model_master.*,power_factor_step_capcitor_value_mapping.* FROM sensor_model_master,power_factor_step_capcitor_value_mapping  WHERE sensor_model_master.model_id="'.$LoctList[0]["sensorModel"].'" AND power_factor_step_capcitor_value_mapping.sensorCode="'.$LoctList[0]['sensorCode'].'"  AND power_factor_step_capcitor_value_mapping.gatewayCode="'.$LoctList[0]['gateway_id'].'" AND power_factor_step_capcitor_value_mapping.isActive="1" AND power_factor_step_capcitor_value_mapping.status="1" AND sensor_model_master.is_active="1" AND sensor_model_master.status="1" AND sensor_model_master.model_id=power_factor_step_capcitor_value_mapping.sensorModel' ;

		   $ModList		= $this->ExecuteQuery($SelQuery_mod, "select");
		   $objSmarty->assign('ModList', $ModList);
		   
		//   $SelQuery='SELECT max(ping_log_id) AS ping_log_id, max(gateway_code) AS gateway_code,max(gateway_date_time) AS gateway_date_time FROM `gateway_ping_log` WHERE gateway_code="'.base64_decode($_GET["gatewayCode"]).'" GROUP BY gateway_code ORDER BY ping_log_id';
	        $SelQuery='SELECT * FROM `gateway_ping_log_view` WHERE gateway_code="'.base64_decode($_GET["gatewayCode"]).'"';
	       $gateList= $this->ExecuteQuery($SelQuery, "select");
	       $objSmarty->assign('gateList', $gateList);
		}	
	/******************** GetDashboardDetails Functions Ends ****************/
	 /*********************  GetCostKwhAll Functions Starts ******************/ 
		function GetCostKwhAll()
		{
			global $objSmarty,$config,$nowDate;
			$tbl = $config['DBPrefix'];
		
		if($_GET['companyId'] <> '')
		{
		   $comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		   $comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		   $branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		   $branchId = $_SESSION['branch_id'];
		}
		
		$ldc=date("Y", strtotime("first day of previous month"));
            $ldl=date("n", strtotime("last day of previous month"));
		
	 	  $selQry = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND DATE(recorded_date)=DATE('.$nowDate.') AND MONTH(recorded_date)=MONTH('.$nowDate.') AND YEAR(recorded_date)=YEAR('.$nowDate.') AND feeder_type="Main Meter" ';
		  //$selQry = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND DATE(recorded_date)=DATE('.$nowDate.') AND MONTH(recorded_date)=MONTH('.$nowDate.') AND YEAR(recorded_date)=YEAR('.$nowDate.') AND feeder_type="Overall Main Meter" '; 
		  $todayCostKWH		= $this->ExecuteQuery($selQry, "select");
		  $objSmarty->assign('todayCostKWH', $todayCostKWH);
		  
		  $selQryYes = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND DATE(recorded_date)=DATE_SUB(DATE('.$nowDate.'), INTERVAL 1 DAY) AND MONTH(recorded_date)=MONTH(DATE_SUB(DATE('.$nowDate.'), INTERVAL 1 DAY)) AND YEAR(recorded_date)=YEAR(DATE_SUB(DATE('.$nowDate.'), INTERVAL 1 DAY)) AND feeder_type="Main Meter" '; 
		 // $selQryYes = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND DATE(recorded_date)=DATE_SUB(DATE('.$nowDate.'), INTERVAL 1 DAY) AND MONTH(recorded_date)=MONTH(DATE_SUB(DATE('.$nowDate.'), INTERVAL 1 DAY)) AND YEAR(recorded_date)=YEAR(DATE_SUB(DATE('.$nowDate.'), INTERVAL 1 DAY)) AND feeder_type="Overall Main Meter" ';
		  $yesterdayCostKWH		= $this->ExecuteQuery($selQryYes, "select");
		  $objSmarty->assign('yesterdayCostKWH', $yesterdayCostKWH);
		
		  $selQry2 = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND MONTH(recorded_date)=MONTH('.$nowDate.') AND YEAR(recorded_date)=YEAR('.$nowDate.') AND feeder_type="Main Meter" '; 
		  //$selQry2 = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND MONTH(recorded_date)=MONTH('.$nowDate.') AND YEAR(recorded_date)=YEAR('.$nowDate.') AND feeder_type="Overall Main Meter" '; 
		  $monthCostKWH		= $this->ExecuteQuery($selQry2, "select");
		  $objSmarty->assign('monthCostKWH', $monthCostKWH);
		
		 $selQry3 = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND MONTH(recorded_date)="'.$ldl.'" AND YEAR(recorded_date)="'.$ldc.'" AND feeder_type="Main Meter" ';
		//$selQry3 = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND MONTH(recorded_date)="'.$ldl.'" AND YEAR(recorded_date)="'.$ldc.'" AND feeder_type="Overall Main Meter" ';
		  $LastMonthCostKWH		= $this->ExecuteQuery($selQry3, "select");
		  $objSmarty->assign('LastMonthCostKWH', $LastMonthCostKWH);
		}
		/*********************  GetCostKwhAll Functions Ends ******************/ 
		/*********************  Test2 Functions Starts *************************/ 
		function Test2()  
		{
		   global $objSmarty,$config,$nowDate;
		
		if($_GET['companyId'] <> '')
		{
		   $comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		   $comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		   $branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		   $branchId = $_SESSION['branch_id'];
		}
		
		   $SelQuery = 'SELECT energy_data_master_view.*,arka_sensor_master.*,arka_sensor_master.kw_max_value,(arka_sensor_master.kw_max_value/5) AS KW_INT, feeder_name FROM energy_data_master_view,arka_sensor_master WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.sensorCode=energy_data_master_view.sensor_code arka_sensor_master.gateway_id=energy_data_master_view.gateway_code ORDER BY arka_sensor_master.feeder_type'; 
		  $MeterList= $this->ExecuteQuery($SelQuery, "select");
		  $objSmarty->assign('MeterList', $MeterList);	
		
		
		 $selQryC = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,sensor_code FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND DATE(recorded_date)=DATE('.$nowDate.') AND MONTH(recorded_date)=MONTH('.$nowDate.') AND YEAR(recorded_date)=YEAR('.$nowDate.') GROUP BY sensor_code'; 
		 $CostKWH = $this->ExecuteQuery($selQryC, "select");
		 $objSmarty->assign('CostKWH', $CostKWH);
		 		
		}	
        /*********************  Test2 Functions Ends *************************/ 
/************************************************************************************/
function ListDashboardTest()  
{
		global $objSmarty,$config,$nowDate;
				
		if($_GET['companyId'] <> '')
		{
		$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		$branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		$branchId = $_SESSION['branch_id'];
		}
		 $SelQuery = 'SELECT SUM(cron_daily_energy_data.`consuption_kwh`) AS TOTAL_KWH ,SUM(cron_daily_energy_data.`consuption_cost`) AS cost,SUM(cron_daily_energy_data.`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(cron_daily_energy_data.`dg_consuption_cost`) AS dg_cost,cron_daily_energy_data.sensor_code,gateway_ping_log_view.*,energy_data_master_view.*,arka_sensor_master.*,arka_sensor_master.sensorName AS feeder_name,(arka_sensor_master.kw_max_value/5) AS KW_INT,arka_gateway_master.place_of_installation, TIMESTAMPDIFF(SECOND, recorded_date_time, NOW()) AS secs FROM cron_daily_energy_data,gateway_ping_log_view,energy_data_master_view,arka_sensor_master,arka_gateway_master WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.gateway_id=arka_gateway_master.gateway_id AND arka_sensor_master.sensorCode=energy_data_master_view.sensor_code AND arka_sensor_master.gateway_id=gateway_ping_log_view.gateway_code AND arka_sensor_master.feeder_type="Main Meter" AND arka_sensor_master.sensorCode=cron_daily_energy_data.sensor_code AND cron_daily_energy_data.company_id="'.$comId.'" AND cron_daily_energy_data.branch_id="'.$branchId.'" AND DATE(cron_daily_energy_data.recorded_date)=DATE('.$nowDate.') AND MONTH(cron_daily_energy_data.recorded_date)=MONTH('.$nowDate.') AND YEAR(cron_daily_energy_data.recorded_date)=YEAR('.$nowDate.') GROUP BY cron_daily_energy_data.sensor_code ORDER BY arka_sensor_master.priority'; 
	
	//$SelQuery = 'SELECT energy_data_master_view.*,arka_sensor_master.*,arka_sensor_master.sensorName AS feeder_name,(arka_sensor_master.kw_max_value/5) AS KW_INT,TIMESTAMPDIFF(SECOND, recorded_date_time, NOW()) AS secs FROM energy_data_master_view,arka_sensor_master WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.sensorCode=energy_data_master_view.sensor_code  AND arka_sensor_master.feeder_type="Main Meter"  '; 
	       $MeterList= $this->ExecuteQuery($SelQuery, "select");//print_r($MeterList);
	       $objSmarty->assign('MeterList', $MeterList);	
	       
	/*echo"<br> <br>PMeterList: "; echo   */    	$SelQuery = 'SELECT power_factor_energy_data_view.*,arka_sensor_master.*,arka_sensor_master.sensorName AS feeder_name,(arka_sensor_master.kw_max_value/5) AS KW_INT,TIMESTAMPDIFF(SECOND, recorded_date_time, NOW()) AS secs FROM power_factor_energy_data_view,arka_sensor_master WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.sensorCode=power_factor_energy_data_view.sensor_code  AND arka_sensor_master.feeder_type="Main Meter"  '; 
	       $PMeterList= $this->ExecuteQuery($SelQuery, "select");//print_r($PMeterList);
	       $objSmarty->assign('PMeterList', $PMeterList);	
/*	       
echo"<br> <br>CostKWH :"; echo 	    $selQryC = 'SELECT SUM(cron_daily_energy_data.`consuption_kwh`) AS TOTAL_KWH ,SUM(cron_daily_energy_data.`consuption_cost`) AS cost,SUM(cron_daily_energy_data.`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(cron_daily_energy_data.`dg_consuption_cost`) AS dg_cost,cron_daily_energy_data.sensor_code FROM `cron_daily_energy_data` WHERE cron_daily_energy_data.company_id="'.$comId.'" AND cron_daily_energy_data.branch_id="'.$branchId.'" AND DATE(cron_daily_energy_data.recorded_date)=DATE('.$nowDate.') AND MONTH(cron_daily_energy_data.recorded_date)=MONTH('.$nowDate.') AND YEAR(cron_daily_energy_data.recorded_date)=YEAR('.$nowDate.') GROUP BY cron_daily_energy_data.sensor_code';	       
	    $CostKWH		= $this->ExecuteQuery($selQryC, "select");
	    $objSmarty->assign('CostKWH', $CostKWH);*/
		
	/*echo"<br><br> gateList :"; echo    $SelQuery='SELECT * FROM gateway_ping_log_view';
	       $gateList= $this->ExecuteQuery($SelQuery, "select");//print_r($MeterList);
	       $objSmarty->assign('gateList', $gateList);*/
	       
	  	/*echo"<br><br> selQryS: "; echo */    
		$selQryS = 'SELECT * FROM `arka_sensor_master` WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND (arka_sensor_master.feeder_type="Sub Meter" OR arka_sensor_master.feeder_type="Sub Sub Meter" ) GROUP BY sensorCode';
		
	//	echo $selQryS; exit;
	    $selQryS		= $this->ExecuteQuery($selQryS, "select");
	    $objSmarty->assign('selQryS', $selQryS);
}	
/***********************Sub Dashboard List*************************************************/
function GetSubDashboard()  {
			global $objSmarty,$config,$nowDate;
		
			if($_GET['companyId'] <> '')
			{
			$comId = base64_decode($_GET['companyId']);
			}	
			else
			{
			$comId = $_SESSION['CustomerId'];
			}
			if($_GET['branchId'] <> '')
			{
			$branchId = base64_decode($_GET['branchId']);
			}	
			else
			{
			$branchId = $_SESSION['branch_id'];
			}
			$parent_id=base64_decode($_GET['parent_id']);

$senDashboard = 'SELECT * FROM arka_sensor_master WHERE slNo="'.$parent_id.'" AND status="1" AND isActive="1"';
			$senDashboard		= $this->ExecuteQuery($senDashboard, "select");
			$objSmarty->assign('senDashboard', $senDashboard);

 			$SelQuery = 'SELECT energy_data_master_view.*,arka_sensor_master.*,(arka_sensor_master.kw_max_value/5) AS KW_INT,arka_sensor_master.sensorName AS feeder_name,TIMESTAMPDIFF(SECOND, recorded_date_time, NOW()) AS secs,SUM(cron_daily_energy_data.`consuption_kwh`) AS TOTAL_KWH ,SUM(cron_daily_energy_data.`consuption_cost`) AS cost,arka_gateway_master.place_of_installation AS gateway_name FROM energy_data_master_view,arka_sensor_master,cron_daily_energy_data,arka_gateway_master WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.parent_id="'.$parent_id.'" AND arka_sensor_master.feeder_type="Sub Meter" AND arka_sensor_master.sensorCode=energy_data_master_view.sensor_code AND energy_data_master_view.sensor_code=cron_daily_energy_data.sensor_code AND arka_sensor_master.gateway_id=energy_data_master_view.gateway_code AND DATE(cron_daily_energy_data.recorded_date)=DATE('.$nowDate.') AND MONTH(cron_daily_energy_data.recorded_date)=MONTH(DATE('.$nowDate.')) AND YEAR(cron_daily_energy_data.recorded_date)=YEAR(DATE('.$nowDate.')) AND energy_data_master_view.gateway_code=arka_gateway_master.gateway_id GROUP BY cron_daily_energy_data.sensor_code'; 
 		//   $SelQuery = 'SELECT energy_data_master_view.*,arka_sensor_master.*,(arka_sensor_master.kw_max_value/5) AS KW_INT,arka_sensor_master.sensorName AS feeder_name,TIMESTAMPDIFF(SECOND, recorded_date_time, NOW()) AS secs FROM energy_data_master_view,arka_sensor_master WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.parent_id="'.$parent_id.'" AND arka_sensor_master.sensorCode=energy_data_master_view.sensor_code AND arka_sensor_master.gateway_id=energy_data_master_view.gateway_code '; 
	       $MeterList= $this->ExecuteQuery($SelQuery, "select");//echo $SelQuery;
	       $objSmarty->assign('MeterList', $MeterList);	
	       
	       	$selQryC = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,sensor_code FROM `cron_daily_energy_data`,arka_sensor_master WHERE arka_sensor_master.sensorCode=cron_daily_energy_data.sensor_code AND cron_daily_energy_data.company_id="'.$comId.'" AND cron_daily_energy_data.branch_id="'.$branchId.'" AND DATE(recorded_date)=DATE('.$nowDate.') AND MONTH(recorded_date)=MONTH(DATE('.$nowDate.')) AND YEAR(recorded_date)=YEAR(DATE('.$nowDate.')) AND arka_sensor_master.feeder_type="Sub Meter" AND cron_daily_energy_data.gateway_code="'.$senDashboard[0]['gateway_id'].'" GROUP BY cron_daily_energy_data.sensor_code'; 
	       	$CostKWHRows		= $this->ExecuteQuery($selQryC, "numrows");
	        $CostKWH		= $this->ExecuteQuery($selQryC, "select");
	        $objSmarty->assign('CostKWH', $CostKWH);

$SelQuery='SELECT max(ping_log_id) AS ping_log_id, max(gateway_code) AS gateway_code,max(gateway_date_time) AS gateway_date_time FROM `gateway_ping_log_view` GROUP BY gateway_code ORDER BY ping_log_id';
	       $gateList= $this->ExecuteQuery($SelQuery, "select");//print_r($MeterList);
	       $objSmarty->assign('gateList', $gateList);

}	
/************************************************************************************/
/***********************************       Get Cost KwhAllSub Meter                  *************************************************/
function GetCostKwhAllSubMeter()
{
  global $objSmarty,$config,$nowDate;
  $tbl = $config['DBPrefix'];
  
  if($_GET['companyId'] <> '')
{
	$comId = base64_decode($_GET['companyId']);
}	
else
{
	$comId = $_SESSION['CustomerId'];
}
if($_GET['branchId'] <> '')
{
$branchId = base64_decode($_GET['branchId']);
}	
else
{
$branchId = $_SESSION['branch_id'];
}

$parent_id=base64_decode($_GET['parent_id']);
    $selQry = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost,arka_sensor_master.feeder_type,arka_sensor_master.sensorCode,arka_sensor_master.parent_id FROM `cron_daily_energy_data`,arka_sensor_master WHERE arka_sensor_master.parent_id="'.$parent_id.'" AND arka_sensor_master.sensorCode=cron_daily_energy_data.sensor_code AND  cron_daily_energy_data.company_id="'.$comId.'" AND cron_daily_energy_data.branch_id="'.$branchId.'" AND DATE(recorded_date)=DATE('.$nowDate.') AND MONTH(recorded_date)=MONTH('.$nowDate.') AND YEAR(recorded_date)=YEAR('.$nowDate.') AND cron_daily_energy_data.feeder_type="Sub Meter" '; 
	$todayCostKWHSub		= $this->ExecuteQuery($selQry, "select");
	$objSmarty->assign('todayCostKWHSub', $todayCostKWHSub);
	
	$selQry2 = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost,arka_sensor_master.feeder_type,arka_sensor_master.sensorCode,arka_sensor_master.parent_id FROM `cron_daily_energy_data`,arka_sensor_master WHERE arka_sensor_master.parent_id="'.$parent_id.'" AND arka_sensor_master.sensorCode=cron_daily_energy_data.sensor_code AND cron_daily_energy_data.company_id="'.$comId.'" AND cron_daily_energy_data.branch_id="'.$branchId.'" AND MONTH(recorded_date)=MONTH('.$nowDate.') AND YEAR(recorded_date)=YEAR('.$nowDate.') AND cron_daily_energy_data.feeder_type="Sub Meter" '; 
	$monthCostKWHSub		= $this->ExecuteQuery($selQry2, "select");
	$objSmarty->assign('monthCostKWHSub', $monthCostKWHSub);
	
	$selQry3 = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost,arka_sensor_master.feeder_type,arka_sensor_master.sensorCode,arka_sensor_master.parent_id  FROM `cron_daily_energy_data` ,arka_sensor_master WHERE arka_sensor_master.parent_id="'.$parent_id.'" AND arka_sensor_master.sensorCode=cron_daily_energy_data.sensor_code AND cron_daily_energy_data.company_id="'.$comId.'" AND cron_daily_energy_data.branch_id="'.$branchId.'" AND MONTH(recorded_date)=MONTH(DATE_SUB('.$nowDate.',INTERVAL "1" MONTH)) AND cron_daily_energy_data.feeder_type="Sub Meter" ';
	$LastMonthCostKWHSub		= $this->ExecuteQuery($selQry3, "select");
	$objSmarty->assign('LastMonthCostKWHSub', $LastMonthCostKWHSub);
}
/***************************************************************/
	    /*********************  Test2 Functions Starts *************************/
		function GetSegmentsList()
		{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		$parId = base64_decode($_GET['parent_id']);
		if($_GET['companyId'] <> '')
		{
		   $comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		   $comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		   $branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		   $branchId = $_SESSION['branch_id'];
		}
			$Dashboard = 'SELECT * FROM arka_platform_mapping LEFT JOIN arka_iot_platform ON arka_platform_mapping.segmentCode=arka_iot_platform.slNo WHERE arka_platform_mapping.companyName="'.$comId.'" AND arka_platform_mapping.branch_id="'.$branchId.'" ORDER BY arka_iot_platform.slNo ASC';
			$Dashboard		= $this->ExecuteQuery($Dashboard, "select");
			$objSmarty->assign('Dashboard', $Dashboard);
			
			$senDashboard = 'SELECT * FROM arka_sensor_master WHERE slNo="'.$parId.'" AND status="1" AND isActive="1"';
			$senDashboard		= $this->ExecuteQuery($senDashboard, "select");
			$objSmarty->assign('senDashboard', $senDashboard);
		}
       /*********************  Test2 Functions Ends *************************/
	   /********************* GetFeederList Functions Starts **************************/
	function GetFeederList()  
	{
		global $objSmarty;	
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}	
		$gatewayCode=base64_decode($_GET['gatewayCode']);
		$sensorCode=base64_decode($_GET['sensorCode']);
		
	    $SelFeederName = 'SELECT * FROM arka_sensor_master WHERE company_id ="'.$comId.'" AND branch_id ="'.$branchId.'" AND segmentName="Energy Meter" AND isActive="1"'; 
		$ListFeeder		= $this->ExecuteQuery($SelFeederName, "select");
		$objSmarty->assign('ListFeeder', $ListFeeder);	

		$SelSenso = 'SELECT * FROM arka_sensor_master WHERE company_id ="'.$comId.'" AND branch_id ="'.$branchId.'" AND sensorCode="'.$sensorCode.'" AND isActive="1"'; 
		$ListSenso	= $this->ExecuteQuery($SelSenso, "select");
		$objSmarty->assign('ListSenso', $ListSenso);
	
	
		$senMod =  explode("-",$sensorCode); 
		
		if($senMod[0]=="RGA20S")
		{
		    
	    $objSmarty->assign('KW_MAX', 0);
		$objSmarty->assign('KW_INT', 0);
		$objSmarty->assign('KVA_MAX', 0);
		$objSmarty->assign('KVA_INT', 0);
		$objSmarty->assign('KVAR_MAX', 0);
		$objSmarty->assign('KVAR_INT',0);
	}
	else
	{
		$objSmarty->assign('KW_MAX', $ListSenso[0]['kw_max_value']);
		$objSmarty->assign('KW_INT', $ListSenso[0]['kw_max_value']/5);
		$objSmarty->assign('KVA_MAX', $ListSenso[0]['kva_max_value']);
		$objSmarty->assign('KVA_INT', $ListSenso[0]['kva_max_value']/5);
		$objSmarty->assign('KVAR_MAX', $ListSenso[0]['kvar_max_value']);
		$objSmarty->assign('KVAR_INT', $ListSenso[0]['kvar_max_value']/5);
	}
	
	
	    $objSmarty->assign('KWH_MAX', $ListSenso[0]['kwh_max_value']);
		$objSmarty->assign('KWH_INT', $ListSenso[0]['kwh_max_value']/5);
		$objSmarty->assign('KVAH_MAX', $ListSenso[0]['kvah_max_value']);
		$objSmarty->assign('KVAH_INT', $ListSenso[0]['kvah_max_value']/5);
		$objSmarty->assign('KVARH_MAX', $ListSenso[0]['kvarh_max_value']);
		$objSmarty->assign('KVARH_INT', $ListSenso[0]['kvarh_max_value']/5);
	
	
		 $SelFeederDet ='SELECT energy_data_master_view.energy_data_id,energy_data_master_view.`gateway_code`, energy_data_master_view.`sensor_code`, energy_data_master_view.`sensor_model`, energy_data_master_view.`METER_ID`, energy_data_master_view.`R_VOLTAGE`, energy_data_master_view.`Y_VOLTAGE`, energy_data_master_view.`B_VOLTAGE`, energy_data_master_view.`RY_VOLTAGE`, energy_data_master_view.`YB_VOLTAGE`, energy_data_master_view.`BR_VOLTAGE`, energy_data_master_view.`R_CURRENT`, energy_data_master_view.`Y_CURRENT`, energy_data_master_view.`B_CURRENT`, energy_data_master_view.`SUM_KVA`, energy_data_master_view.`SUM_KW`, energy_data_master_view.`SUM_KVAR`, energy_data_master_view.`DG_KVAH`, energy_data_master_view.`DG_KWH`, energy_data_master_view.`DG_KVARH`, energy_data_master_view.`SUM_PF`, energy_data_master_view.`FREQUENCY`, energy_data_master_view.`KWH_MSB`, energy_data_master_view.`KWH_LSB`, energy_data_master_view.`KWH`, energy_data_master_view.`METER_TYPE_RUN_HOUR_MSB`, energy_data_master_view.`RUN_HOUR_LSB`, energy_data_master_view.`RUN_HOUR`, energy_data_master_view.`IMPORT_EXPORT`,energy_data_master_view.`recorded_date_time`,arka_sensor_master.* FROM energy_data_master_view,arka_sensor_master WHERE arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND energy_data_master_view.sensor_code="'.$sensorCode.'" AND energy_data_master_view.gateway_code="'.$gatewayCode.'" AND arka_sensor_master.sensorCode=energy_data_master_view.sensor_code AND arka_sensor_master.gateway_id=energy_data_master_view.gateway_code '; 
		$ListFeederDet		= $this->ExecuteQuery($SelFeederDet, "select");
		$ListFeederDet2		= $this->ExecuteQuery($SelFeederDet, "numrows");
		$objSmarty->assign('ListFeederDet', $ListFeederDet);
		$objSmarty->assign('ListFeederDet2', $ListFeederDet2);	
		
	    $SelFeederDetP ='SELECT power_factor_energy_data_view.power_factor_id,power_factor_energy_data_view.`gateway_code`, power_factor_energy_data_view.`sensor_code`, power_factor_energy_data_view.`sensor_model`, power_factor_energy_data_view.`voltage_l1_n` AS `R_VOLTAGE`, power_factor_energy_data_view.`voltage_l2_n` AS `Y_VOLTAGE`, power_factor_energy_data_view.`voltage_l3_n` AS `B_VOLTAGE`, power_factor_energy_data_view.voltage_l1_l2 AS `RY_VOLTAGE`, power_factor_energy_data_view.voltage_l2_l3 AS `YB_VOLTAGE`, power_factor_energy_data_view. voltage_l3_l1 AS `BR_VOLTAGE`, power_factor_energy_data_view.current_l1 AS `R_CURRENT`, power_factor_energy_data_view.current_l2 AS `Y_CURRENT`, power_factor_energy_data_view.current_l3 AS `B_CURRENT`, power_factor_energy_data_view.apparent_power_l1_n AS `SUM_KVA`, power_factor_energy_data_view.total_active_power AS `SUM_KW`, power_factor_energy_data_view.total_reactive_power AS `SUM_KVAR`, power_factor_energy_data_view.measured_frequency AS `FREQUENCY`,power_factor_energy_data_view.power_factor_total_import AS `SUM_PF`,power_factor_energy_data_view.`step1_actual_steps_value`, power_factor_energy_data_view.`step2_actual_steps_value`, power_factor_energy_data_view.`step3_actual_steps_value`, power_factor_energy_data_view.`step4_actual_steps_value`, power_factor_energy_data_view.`step5_actual_steps_value`, power_factor_energy_data_view.`step6_actual_steps_value`, power_factor_energy_data_view.`step7_actual_steps_value`, power_factor_energy_data_view.`step8_actual_steps_value`, power_factor_energy_data_view.`step9_actual_steps_value`, power_factor_energy_data_view.`step10_actual_steps_value`, power_factor_energy_data_view.`step11_actual_steps_value`, power_factor_energy_data_view.`step12_actual_steps_value`, power_factor_energy_data_view.`step13_actual_steps_value`, power_factor_energy_data_view.`step14_actual_steps_value`, power_factor_energy_data_view.`step15_actual_steps_value`, power_factor_energy_data_view.`step16_actual_steps_value`, power_factor_energy_data_view.`step17_actual_steps_value`, power_factor_energy_data_view.`step18_actual_steps_value`, power_factor_energy_data_view.`step19_actual_steps_value`, power_factor_energy_data_view.`step20_actual_steps_value`, power_factor_energy_data_view.power_factor_total_import AS `IMPORT_EXPORT`,power_factor_energy_data_view.`recorded_date_time`,arka_sensor_master.* FROM power_factor_energy_data_view,arka_sensor_master WHERE arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND power_factor_energy_data_view.sensor_code="'.$sensorCode.'" AND power_factor_energy_data_view.gateway_code="'.$gatewayCode.'" AND arka_sensor_master.sensorCode=power_factor_energy_data_view.sensor_code AND arka_sensor_master.gateway_id=power_factor_energy_data_view.gateway_code ';
		$ListFeederDetP		= $this->ExecuteQuery($SelFeederDetP, "select");
		$ListFeederDetP2		= $this->ExecuteQuery($SelFeederDetP, "numrows");
		$objSmarty->assign('ListFeederDetP', $ListFeederDetP);
		$objSmarty->assign('ListFeederDetP2', $ListFeederDetP2);	
	}	
	/********************* GetFeederList Functions Ends **************************/
	/********************* GetCostKwhSingle Functions Starts **************************/
	function GetCostKwhSingle()
	{
		global $objSmarty,$config,$nowDate;
		$tbl = $config['DBPrefix'];
	
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}
		$sensorCode = base64_decode($_GET['sensorCode']);
		$gatewayCode = base64_decode($_GET['gatewayCode']);
		
		$ldc=date("Y", strtotime("first day of previous month"));
        $ldl=date("n", strtotime("last day of previous month"));
		
		 $selQry = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND  DATE(recorded_date)=DATE('.$nowDate.') AND MONTH(recorded_date)=MONTH('.$nowDate.') AND YEAR(recorded_date)=YEAR('.$nowDate.') AND gateway_code="'.$gatewayCode.'" AND `sensor_code`="'.$sensorCode.'"';  
		$todayCostKWH		= $this->ExecuteQuery($selQry, "select");
		$objSmarty->assign('todayCostKWH', $todayCostKWH);
		
		 
		  $selQryYes = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND DATE(recorded_date)=DATE(DATE_SUB('.$nowDate.', INTERVAL 1 DAY)) AND MONTH(recorded_date)=MONTH(DATE_SUB('.$nowDate.', INTERVAL 1 DAY)) AND YEAR(recorded_date)=YEAR(DATE_SUB('.$nowDate.', INTERVAL 1 DAY)) AND gateway_code="'.$gatewayCode.'" AND `sensor_code`="'.$sensorCode.'"'; 
		  $yesterdayCostKWH		= $this->ExecuteQuery($selQryYes, "select");
		  $objSmarty->assign('yesterdayCostKWH', $yesterdayCostKWH);
		
	
		$selQry2 = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND `gateway_code`="'.$gatewayCode.'" AND `sensor_code`="'.$sensorCode.'" AND Month(recorded_date)=MONTH('.$nowDate.') AND YEAR(recorded_date)=YEAR('.$nowDate.')';
		$monthCostKWH		= $this->ExecuteQuery($selQry2, "select");
		$objSmarty->assign('monthCostKWH', $monthCostKWH);
	
		$selQry3 = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND `gateway_code`="'.$gatewayCode.'" AND `sensor_code`="'.$sensorCode.'" AND MONTH(recorded_date)="'.$ldl.'" AND YEAR(recorded_date)="'.$ldc.'" ';
		$LastMonthCostKWH		= $this->ExecuteQuery($selQry3, "select");
		$objSmarty->assign('LastMonthCostKWH', $LastMonthCostKWH);
	
	}
     /********************* GetCostKwhSingle Functions Ends **************************/
	 /********************* GetBarGraph Functions Starts **************************/
	function GetBarGraph(){
		global $objSmarty,$config,$nowDate;
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}
		$sensorCode = base64_decode($_GET['sensorCode']);
		$gatewayCode = base64_decode($_GET['gatewayCode']);
		
		$selBarGraph='SELECT DATE_FORMAT(recorded_date,"%b") AS month_data, consuption_cost, dg_consuption_cost  FROM cron_monthly_energy_data WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND gateway_code="'.$gatewayCode.'" AND sensor_code="'.$sensorCode.'" AND DATE(recorded_date)>= DATE(DATE_SUB('.$nowDate.',INTERVAL 12 MONTH)) AND DATE(recorded_date)<= DATE('.$nowDate.') order by recorded_date ASC'; 
		$ExeBarGraph		= $this->ExecuteQuery($selBarGraph, "select");
		$ExeBarGraphCount		= $this->ExecuteQuery($selBarGraph, "numrows");
		
	$objParm='';
	$objParmDg='';
	foreach($ExeBarGraph as $key=>$value)
	{
		$objParm .='{"month": "'.$ExeBarGraph[$key]["month_data"].'","cost": '.$ExeBarGraph[$key]["consuption_cost"].',"dgcost": '.$ExeBarGraph[$key]["dg_consuption_cost"].'},';
		$objParmDg .='{
		"month": "'.$ExeBarGraph[$key]["month_data"].'",
		"cost": '.$ExeBarGraph[$key]["dg_consuption_cost"].'
		},';
	}
	
		$BarGraphData="[".rtrim($objParm, ",")."]";
		$dgBarGraphData="[".rtrim($objParmDg, ",")."]";
		$objSmarty->assign('BarGraphData',$BarGraphData);
		$objSmarty->assign('dgBarGraphData',$dgBarGraphData);
	
		$selLineGraph='SELECT DATE_FORMAT(recorded_date,"%b") AS month_data, consuption_kwh, dg_consuption_kwh  FROM cron_monthly_energy_data WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND gateway_code="'.$gatewayCode.'" AND sensor_code="'.$sensorCode.'"  AND DATE(recorded_date)>= DATE(DATE_SUB('.$nowDate.',INTERVAL 12 MONTH)) AND DATE(recorded_date)<= DATE('.$nowDate.') order by recorded_date ASC';
		$ExeLineGraph		= $this->ExecuteQuery($selLineGraph, "select");
		$ExeLineGraphCount		= $this->ExecuteQuery($selLineGraph, "numrows");
		
	$objParm2='';
	$objParm2Dg='';
	foreach($ExeLineGraph as $key2=>$value2)
	{
		$objParm2 .='{"month": "'.$ExeLineGraph[$key2]["month_data"].'","EB": '.$ExeLineGraph[$key2]["consuption_kwh"].',"DG": '.$ExeLineGraph[$key2]["dg_consuption_kwh"].'},';
		$objParm2Dg .='{
		"month": "'.$ExeLineGraph[$key2]["month_data"].'",
		"kwh": '.$ExeLineGraph[$key2]["dg_consuption_kwh"].'
		},';
	}
	
	$objGraph2='{
	"title": "EB Kwh",
	"balloonText": "[[title]]: <b>[[value]]</b>",
	"bullet": "round",
	"bulletSize": 10,
	"bulletBorderColor": "#ffffff",
	"bulletBorderAlpha": 1,
	"bulletBorderThickness": 2,
	"type": "smoothedLine",
	"valueField": "EB"
	},{
	"title": "DG Kwh",
	"balloonText": "[[title]]: <b>[[value]]</b>",
	"bullet": "round",
	"bulletSize": 10,
	"bulletBorderColor": "#ffffff",
	"bulletBorderAlpha": 1,
	"bulletBorderThickness": 2,
	"type": "smoothedLine",
	"valueField": "DG"
	}';
	
		$LineGraphData="[".rtrim($objParm2, ",")."]";
		$LineGraphData2="[".rtrim($objGraph2, ",")."]";
		$dgLineGraphData="[".rtrim($objParm2Dg, ",")."]";
		$objSmarty->assign('LineGraphData',$LineGraphData);
		$objSmarty->assign('LineGraphData2',$LineGraphData2);
		$objSmarty->assign('dgLineGraphData',$dgLineGraphData);
	}
    /********************* GetBarGraph Functions Ends **************************/
	 /********************* GetMeterLogGraph Functions Ends **************************/
	 function GetMeterLogGraph()
 {
	global $objSmarty,$config,$nowDate;
	if(function_exists('date_default_timezone_set')) {
		date_default_timezone_set("Asia/Kolkata");
	}
	$pf='';
	$gatewayCode = base64_decode($_GET['gatewayCode']);
	$sensorCode = base64_decode($_GET['sensorCode']);
	if(isset($_POST['date1']))
	{
		$date1 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
	//	$date2 = date("Y-m-d 23:59:59",strtotime(trim(addslashes($_POST['date1']))));

		
		$yaxis = $_POST['yAxis'];
	//	echo $yaxis; exit;
		if($yaxis== 'VOLTAGE' || $yaxis== 'CURRENT')
		{
			$yaxis_par="R_".$yaxis.",Y_".$yaxis.",B_".$yaxis;
			$pf=0;
		}
		else if($yaxis== 'SUM_PF'){
			$yaxis_par="TRUNCATE(IF(`SUM_PF` >= 1 AND `SUM_PF` < 2 , '-0.99', IF(`SUM_PF` >= 2 , '1', `SUM_PF`)),2) AS SUM_PF ";
			$pf=1;
		}
		else
		{
			$yaxis_par =$yaxis;
			$pf=2;
		}
	//	$query_rs1 =  "SELECT ".$yaxis_par.",recorded_date_time AS TM FROM energy_data_master WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND (recorded_date_time BETWEEN '".$date1."' AND '".$date2."') ORDER BY TM ASC";
			$query_rs1 =  "SELECT ".$yaxis_par.",recorded_date_time AS TM FROM energy_data_master WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND DATE(recorded_date_time)='".$date1."' ORDER BY TM ASC";
	}
	else
	{
		$deliverytime = new DateTime(date('Y-m-d H:i:s'));
		$hour = $deliverytime->format('H');
		$hour=intval($hour);

			
			$date1=date('Y-m-d 00:00:00');
			$date2=date('Y-m-d 23:59:59');
		//	$date=date_create(date('Y-m-d'));
			
		//	$date2=date_format($date,"Y-m-d 23:59:59");

		$yaxis_par="R_VOLTAGE,Y_VOLTAGE,B_VOLTAGE";
		$query_rs1 = "SELECT ".$yaxis_par.",recorded_date_time AS TM FROM energy_data_master WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND (recorded_date_time BETWEEN '".$date1."' AND '".$date2."') ORDER BY TM ASC";
	}
	    //echo $query_rs1; exit;
		$GetTemp = $this->ExecuteQuery($query_rs1, "select");
		$objSmarty->assign('GetTemp', $GetTemp);
	if($pf!=1)
	{
		$splVar= explode(",",$yaxis_par);
	}
	else
	{
		$splVar=array("SUM_PF");
	}
		$arrData = array();
	foreach ($GetTemp as $key => $value) 
	{
		$orgDate =$GetTemp[$key]['TM'];  
		$GDate = date("d-M-Y h:i A", strtotime($orgDate));
	if($splVar[1]!='')
	{
		array_push($arrData, array(
		$splVar[0] => $GetTemp[$key][$splVar[0]],
		$splVar[1] => $GetTemp[$key][$splVar[1]],
		$splVar[2] => $GetTemp[$key][$splVar[2]],
		"tm" => $GDate
		));
	}
	else
	{
		array_push($arrData, array(
		$splVar[0] => $GetTemp[$key][$splVar[0]],
		"tm" => $GDate
		));
	}
	}
		$ChartData = json_encode($arrData);
		$objSmarty->assign('ChartData', $ChartData);
	}
        /********************* GetMeterLogGraph Functions Ends **************************/
         /********************* GetPowerMeterLogGraph Functions Ends **************************/
	 function GetPowerMeterLogGraph()
 {
	global $objSmarty,$config,$nowDate;
	$pf='';
	$gatewayCode = base64_decode($_GET['gatewayCode']);
	$sensorCode = base64_decode($_GET['sensorCode']);
	if(isset($_POST['date1']) && isset($_POST['date2']))
	{
		$date1 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		$date2 = date("Y-m-d",strtotime(trim(addslashes($_POST['date2']))));
		$yaxis = @$_POST['yAxis'];
	if($yaxis== 'VOLTAGE')
	{
		$yaxis_par="R_VOLTAGE,Y_VOLTAGE,B_VOLTAGE";
		$yaxis_par1="voltage_l1_n AS R_VOLTAGE,voltage_l2_n AS Y_VOLTAGE,voltage_l3_n AS B_VOLTAGE";
		$pf=0;
	}
	else if($yaxis== 'CURRENT')
	{
	    $yaxis_par="R_CURRENT,Y_CURRENT,B_CURRENT";
		$yaxis_par1="current_l1 AS R_CURRENT,current_l2 AS Y_CURRENT,current_l3 AS B_CURRENT";
		$pf=0;
	}
	else if($yaxis== 'SUM_PF')
	{
	    $yaxis_par="SUM_PF";
		$yaxis_par1="power_factor_total_import AS SUM_PF ";
		$pf=1;
	}
	else if($yaxis == 'SUM_KVA')
	{
		$yaxis_par ="SUM_KVA";
		$yaxis_par1 ="(apparent_power_l1_n/1000) AS SUM_KVA";
		$pf=2;
	}
	else if($yaxis == 'SUM_KW')
	{
		$yaxis_par ="SUM_KW";
		$yaxis_par1 ="(total_active_power/1000) AS SUM_KW";
		$pf=2;
	}
	else if($yaxis == 'SUM_KVAR')
	{
		$yaxis_par ="SUM_KVAR";
		$yaxis_par1 ="(total_reactive_power/1000) AS SUM_KVAR";
		$pf=2;
	}
		$query_rs1 =  "SELECT ".$yaxis_par1.",recorded_date_time AS TM FROM power_factor_energy_data WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND (DATE(recorded_date_time) BETWEEN '".$date1."' AND '".$date2."') ORDER BY TM ASC";
	}
	else
	{
	    	$yaxis_par="R_VOLTAGE,Y_VOLTAGE,B_VOLTAGE";
		$yaxis_par1="voltage_l1_n AS R_VOLTAGE,voltage_l2_n AS Y_VOLTAGE,voltage_l3_n AS B_VOLTAGE";
		$query_rs1 = "SELECT ".$yaxis_par1.",recorded_date_time AS TM FROM power_factor_energy_data WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND DATE(recorded_date_time) = DATE(CONVERT_TZ(NOW(),'+00:00' ,'+00:00')) ORDER BY TM ASC";
	}
//	echo $query_rs1;
		$GetTemp = $this->ExecuteQuery($query_rs1, "select");
		$objSmarty->assign('GetTemp', $GetTemp);
	if($pf!=1)
	{
		$splVar= explode(",",$yaxis_par);
	}
	else
	{
		$splVar=array("SUM_PF");
	}
		$arrData = array();
	foreach ($GetTemp as $key => $value) 
	{
		$orgDate =$GetTemp[$key]['TM'];  
		$GDate = date("d-M-Y h:i A", strtotime($orgDate));
	if($splVar[1]!='')
	{
		array_push($arrData, array(
		$splVar[0] => $GetTemp[$key][$splVar[0]],
		$splVar[1] => $GetTemp[$key][$splVar[1]],
		$splVar[2] => $GetTemp[$key][$splVar[2]],
		"tm" => $GDate
		));
	}
	else
	{
		array_push($arrData, array(
		$splVar[0] => $GetTemp[$key][$splVar[0]],
		"tm" => $GDate
		));
	}
	}
		$ChartData = json_encode($arrData);
		$objSmarty->assign('ChartData', $ChartData);
	}
        /********************* GetPowerMeterLogGraph Functions Ends **************************/
		/********************* GetIcdLog Functions Starts **************************/
	function GetIcdLog()
	{
		global $objSmarty,$config,$nowDate;
		if(function_exists('date_default_timezone_set')) {
		date_default_timezone_set("Asia/Kolkata");
		}
		$gatewayCode = base64_decode($_GET['gatewayCode']);
		$sensorCode = base64_decode($_GET['sensorCode']);
		$senMod =  explode("-",base64_decode($_GET['sensorCode'])); 
	if(isset($_POST['date1']) && isset($_POST['date2']))
	{
		$date1 = date("Y-m-d 08:00:00",strtotime(trim(addslashes($_POST['date1']))));
		$date2 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		
		$date=date_create($date2);
		date_add($date,date_interval_create_from_date_string("1 days"));
		$date2=date_format($date,"Y-m-d 07:59:59");


	/************************     Shift Date Format  Starts     **********************************/
/*	
		if(function_exists('date_default_timezone_set')) {
		date_default_timezone_set("Asia/Kolkata");
		}
		$deliverytime = new DateTime($date1);
		
		$hour = $deliverytime->format('H');
		if ($hour >= 00 && $hour <=03) {
			$date=date_create(date('y-m-d'));
			date_sub($date,date_interval_create_from_date_string("1 days"));
			$recorded_date=date_format($date,"Y-m-d");
		} else {
			
			$recorded_date=date('Y-m-d');
		} */
	/************************     Shift Date Format  Starts     **********************************/
		$query_rs1 =  "SELECT recorded_date_time AS TM,posted_date_time,linux_date_time,teltonika_date_time,gateway_code,sensor_code,sensor_model,`METER_ID`, `R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`, `SUM_PF`, `FREQUENCY`, `KWH_MSB`, `KWH_LSB`, `KWH` AS KWHF, `KWH`, `METER_TYPE_RUN_HOUR_MSB`, `RUN_HOUR_LSB`, `RUN_HOUR`, `IMPORT_EXPORT` FROM energy_data_master WHERE gateway_code='".$gatewayCode."' AND EB_DG_STATUS<>'1' AND sensor_code='".$sensorCode."' AND (recorded_date_time BETWEEN '".$date1."' AND '".$date2."') ORDER BY TM DESC";
	}
	else
	{	
		$deliverytime = new DateTime(date('Y-m-d H:i:s'));
		$hour = $deliverytime->format('H');
		$hour=intval($hour);
		if ($hour >=0 && $hour <8) {
			$date=date_create(date('Y-m-d'));
			date_sub($date,date_interval_create_from_date_string("1 days"));
			$date1=date_format($date,"Y-m-d 08:00:00");
			$date2=date('Y-m-d 07:59:59');
			//echo"if";
		} else {
			
			$date1=date('Y-m-d 08:00:00');
			$date=date_create(date('Y-m-d'));
			date_add($date,date_interval_create_from_date_string("1 days"));
			$date2=date_format($date,"Y-m-d 07:59:59");
			//echo "from D".$date1;
			//echo "to D".$date2;
			//echo "else";
		}
	
		$query_rs1 = "SELECT recorded_date_time AS TM,posted_date_time,linux_date_time,teltonika_date_time,gateway_code,sensor_code,sensor_model,`METER_ID`, `R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`, `SUM_PF`, `FREQUENCY`, `KWH_MSB`, `KWH_LSB`, FORMAT(`KWH`, 2) AS KWHF, `METER_TYPE_RUN_HOUR_MSB`, `RUN_HOUR_LSB`, `RUN_HOUR`, `IMPORT_EXPORT` FROM energy_data_master WHERE  gateway_code='".$gatewayCode."' AND EB_DG_STATUS<>'1' AND sensor_code='".$sensorCode."' AND (recorded_date_time BETWEEN '".$date1."' AND '".$date2."') ORDER BY TM DESC";
	}//echo $query_rs1;exit;
		$GetICD = $this->ExecuteQuery($query_rs1, "select");
		$objSmarty->assign('GetICD', $GetICD);
	}
     /********************* GetIcdLog Functions Ends **************************/
	 
	 		/********************* Demand Report Log Functions Starts **************************/
	function GetDemandLog()
	{
		global $objSmarty,$config,$nowDate;
		if(function_exists('date_default_timezone_set')) {
		date_default_timezone_set("Asia/Kolkata");
		}
		$gatewayCode = base64_decode($_GET['gatewayCode']);
		$sensorCode = base64_decode($_GET['sensorCode']);
		$senMod =  explode("-",base64_decode($_GET['sensorCode'])); 
	if(isset($_POST['date1']) && isset($_POST['date2']))
	{
		$date1 = date("Y-m-d 08:00:00",strtotime(trim(addslashes($_POST['date1']))));
		$date2 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		
		$date=date_create($date2);
		date_add($date,date_interval_create_from_date_string("1 days"));
		$date2=date_format($date,"Y-m-d 07:59:59");


	/************************     Shift Date Format  Starts     **********************************/
/*	
		if(function_exists('date_default_timezone_set')) {
		date_default_timezone_set("Asia/Kolkata");
		}
		$deliverytime = new DateTime($date1);
		
		$hour = $deliverytime->format('H');
		if ($hour >= 00 && $hour <=03) {
			$date=date_create(date('y-m-d'));
			date_sub($date,date_interval_create_from_date_string("1 days"));
			$recorded_date=date_format($date,"Y-m-d");
		} else {
			
			$recorded_date=date('Y-m-d');
		} */
	/************************     Shift Date Format  Starts     **********************************/
		$query_rs1 =  "SELECT recorded_date_time AS TM,posted_date_time,linux_date_time,teltonika_date_time,gateway_code,sensor_code,sensor_model,`METER_ID`, `demand_max_voltage_r`, `demand_min_voltage_r`,`demand_max_voltage_y`, `demand_min_voltage_y`,`demand_max_voltage_b`, `demand_min_voltage_b`,`demand_max_line_current_r`, `demand_min_line_current_r`,`demand_max_line_current_y`, `demand_min_line_current_y`,`demand_max_line_current_b`, `demand_min_line_current_b`,`demand_max_active_power_r`, `demand_min_active_power_r`,`demand_max_active_power_y`, `demand_min_active_power_y`,`demand_max_active_power_b`, `demand_min_active_power_b`, `demand_max_voltage_ry`, `demand_min_voltage_ry`,`demand_max_voltage_yb`, `demand_min_voltage_yb`,`demand_max_voltage_br`, `demand_min_voltage_br` FROM energy_data_master WHERE gateway_code='".$gatewayCode."' AND EB_DG_STATUS<>'1' AND sensor_code='".$sensorCode."' AND (recorded_date_time BETWEEN '".$date1."' AND '".$date2."') ORDER BY TM DESC";
	}
	else
	{	
		$deliverytime = new DateTime(date('Y-m-d H:i:s'));
		$hour = $deliverytime->format('H');
		$hour=intval($hour);
		if ($hour >=0 && $hour <8) {
			$date=date_create(date('Y-m-d'));
			date_sub($date,date_interval_create_from_date_string("1 days"));
			$date1=date_format($date,"Y-m-d 08:00:00");
			$date2=date('Y-m-d 07:59:59');
			//echo"if";
		} else {
			
			$date1=date('Y-m-d 08:00:00');
			$date=date_create(date('Y-m-d'));
			date_add($date,date_interval_create_from_date_string("1 days"));
			$date2=date_format($date,"Y-m-d 07:59:59");
			//echo "from D".$date1;
			//echo "to D".$date2;
			//echo "else";
		}
	
		$query_rs1 = "SELECT recorded_date_time AS TM,posted_date_time,linux_date_time,teltonika_date_time,gateway_code,sensor_code,sensor_model,`METER_ID`, `demand_max_voltage_r`, `demand_min_voltage_r`,`demand_max_voltage_y`, `demand_min_voltage_y`,`demand_max_voltage_b`, `demand_min_voltage_b`,`demand_max_line_current_r`, `demand_min_line_current_r`,`demand_max_line_current_y`, `demand_min_line_current_y`,`demand_max_line_current_b`, `demand_min_line_current_b`,`demand_max_active_power_r`, `demand_min_active_power_r`,`demand_max_active_power_y`, `demand_min_active_power_y`,`demand_max_active_power_b`, `demand_min_active_power_b`, `demand_max_voltage_ry`, `demand_min_voltage_ry`,`demand_max_voltage_yb`, `demand_min_voltage_yb`,`demand_max_voltage_br`, `demand_min_voltage_br` FROM energy_data_master WHERE  gateway_code='".$gatewayCode."' AND EB_DG_STATUS<>'1' AND sensor_code='".$sensorCode."' AND (recorded_date_time BETWEEN '".$date1."' AND '".$date2."') ORDER BY TM DESC";
	}//echo $query_rs1;exit;
		$GetICD = $this->ExecuteQuery($query_rs1, "select");
		$objSmarty->assign('GetICD', $GetICD);
	}
     /*********************Demand Report Log Functions Ends **************************/

     	/********************* GetIcdLog Functions Starts **************************/
	function GetPowerIcdLog()
	{
		global $objSmarty,$config,$nowDate;
		$gatewayCode = base64_decode($_GET['gatewayCode']);
		$sensorCode = base64_decode($_GET['sensorCode']);
		$senMod =  explode("-",base64_decode($_GET['sensorCode'])); 
	if(isset($_POST['date1']) && isset($_POST['date2']))
	{
		$date1 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		$date2 = date("Y-m-d",strtotime(trim(addslashes($_POST['date2']))));
		$query_rs1 =  "SELECT recorded_date_time AS TM,posted_date_time,linux_date_time,teltonika_date_time,gateway_code,sensor_code,sensor_model,`power_factor_id` AS METER_ID,voltage_l1_n AS `R_VOLTAGE`,voltage_l2_n AS `Y_VOLTAGE`,voltage_l3_n AS `B_VOLTAGE`,voltage_l1_l2 AS `RY_VOLTAGE`,voltage_l2_l3 AS `YB_VOLTAGE`,voltage_l3_l1 AS `BR_VOLTAGE`,current_l1 AS `R_CURRENT`,current_l2 AS `Y_CURRENT`,current_l3 AS `B_CURRENT`,apparent_power_l1_n AS `SUM_KVA`,total_active_power AS `SUM_KW`,total_reactive_power AS `SUM_KVAR`,power_factor_total_import AS `SUM_PF`,measured_frequency AS `FREQUENCY`,cospi_total_import AS `IMPORT_EXPORT` FROM power_factor_energy_data WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND (DATE(recorded_date_time) BETWEEN '".$date1."' AND '".$date2."') ORDER BY TM DESC";
	}
	else
	{
		$query_rs1 =  "SELECT recorded_date_time AS TM,posted_date_time,linux_date_time,teltonika_date_time,gateway_code,sensor_code,sensor_model,`power_factor_id` AS METER_ID,voltage_l1_n AS `R_VOLTAGE`,voltage_l2_n AS `Y_VOLTAGE`,voltage_l3_n AS `B_VOLTAGE`,voltage_l1_l2 AS `RY_VOLTAGE`,voltage_l2_l3 AS `YB_VOLTAGE`,voltage_l3_l1 AS `BR_VOLTAGE`,current_l1 AS `R_CURRENT`,current_l2 AS `Y_CURRENT`,current_l3 AS `B_CURRENT`,apparent_power_l1_n AS `SUM_KVA`,total_active_power AS `SUM_KW`,total_reactive_power AS `SUM_KVAR`,power_factor_total_import AS `SUM_PF`,measured_frequency AS `FREQUENCY`,cospi_total_import AS `IMPORT_EXPORT` FROM power_factor_energy_data WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND DATE(recorded_date_time) = DATE(CONVERT_TZ(NOW(),'+00:00' ,'+00:00')) ORDER BY TM DESC";
	}//echo $query_rs1;
		$GetICD = $this->ExecuteQuery($query_rs1, "select");
		$objSmarty->assign('GetICD', $GetICD);
	}
     /********************* GetIcdLog Functions Ends **************************/
	 /********************* GetDailyLog Functions Starts **************************/
	function GetDailyLog()
	{
		global $objSmarty,$config,$nowDate;
		$gatewayCode = base64_decode($_GET['gatewayCode']);
		$sensorCode = base64_decode($_GET['sensorCode']);
		$nowDate= "NOW()";
	if(isset($_POST['date1']) && isset($_POST['date2']))
	{
		$date1 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		$date2 = date("Y-m-d",strtotime(trim(addslashes($_POST['date2']))));
		$query_rs1 =  "SELECT cron_daily_energy_data.*,FORMAT(cron_daily_energy_data.start_cum_kwh, 2) AS startCumKwh, FORMAT(cron_daily_energy_data.end_cum_kwh, 2) AS endCumKwh, FORMAT(cron_daily_energy_data.consuption_kwh, 2) AS conKwh, FORMAT(cron_daily_energy_data.cost, 2) AS cos FROM cron_daily_energy_data WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND recorded_date < ".$nowDate." AND  (DATE(recorded_date) BETWEEN '".$date1."' AND '".$date2."') ORDER BY recorded_date DESC";
	}
	else
	{
		$query_rs1 = "SELECT cron_daily_energy_data.*,FORMAT(cron_daily_energy_data.start_cum_kwh, 2) AS startCumKwh, FORMAT(cron_daily_energy_data.end_cum_kwh, 2) AS endCumKwh, FORMAT(cron_daily_energy_data.consuption_kwh, 2) AS conKwh, FORMAT(cron_daily_energy_data.cost, 2) AS cos FROM cron_daily_energy_data WHERE  gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."'  AND YEAR(recorded_date) = YEAR(".$nowDate.") AND  MONTH(recorded_date) = MONTH(".$nowDate.") AND recorded_date < DATE(".$nowDate.")  ORDER BY recorded_date DESC";
	}
//	echo $query_rs1;
		$GetDLog = $this->ExecuteQuery($query_rs1, "select");
		$objSmarty->assign('GetDLog', $GetDLog);
	}
      /********************* GetDailyLog Functions Ends **************************/
	  
	  	 /********************* GetDailyLog Functions Starts **************************/
	function GetSlotWiseLog()
	{
		global $objSmarty,$config,$nowDate;
		$gatewayCode = base64_decode($_GET['gatewayCode']);
		$sensorCode = base64_decode($_GET['sensorCode']);
		$nowDate= "NOW()";
	if(isset($_POST['date1']) && isset($_POST['date2']))
	{
		$date1 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		$date2 = date("Y-m-d",strtotime(trim(addslashes($_POST['date2']))));
		$query_rs1 =  "SELECT cron_slot_wise_energy_data.* FROM cron_slot_wise_energy_data WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND recorded_date < ".$nowDate." AND  (DATE(recorded_date) BETWEEN '".$date1."' AND '".$date2."') ORDER BY recorded_date DESC";
	}
	else
	{
		$query_rs1 = "SELECT cron_slot_wise_energy_data.* FROM cron_slot_wise_energy_data WHERE  gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."'  AND YEAR(recorded_date) = YEAR(".$nowDate.") AND  MONTH(recorded_date) = MONTH(".$nowDate.") AND recorded_date < DATE(".$nowDate.")  ORDER BY recorded_date DESC";
	}
//	echo $query_rs1;
		$GetDLog = $this->ExecuteQuery($query_rs1, "select");
		$objSmarty->assign('GetDLog', $GetDLog);
	}
      /********************* GetDailyLog Functions Ends **************************/

	 /********************* GetHourlyLog Functions Starts **************************/
	function GetHourlyLog()
	{
		global $objSmarty,$config,$nowDate;
		$gatewayCode = base64_decode($_GET['gatewayCode']);
		$sensorCode = base64_decode($_GET['sensorCode']);
		$nowDate= "NOW()";
	if(isset($_POST['date1']))
	{  // "post";
		$date1 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		$query_rs1 =  "SELECT cron_hourly_energy_data.*,TIME_FORMAT(CONCAT(cron_hourly_energy_data.hour_data,':00:00'),'%I %p') AS hour_datas,FORMAT(cron_hourly_energy_data.start_cum_kwh, 2) AS startCumKwh, FORMAT(cron_hourly_energy_data.end_cum_kwh, 2) AS endCumKwh, FORMAT(cron_hourly_energy_data.consuption_kwh, 2) AS conKwh, FORMAT(cron_hourly_energy_data.cost, 2) AS cos FROM cron_hourly_energy_data WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND recorded_date = '".$date1."' ORDER BY recorded_date DESC";
	}
	else
	{
		$query_rs1 = "SELECT cron_hourly_energy_data.*,TIME_FORMAT(CONCAT(cron_hourly_energy_data.hour_data,':00:00'),'%I %p') AS hour_datas,FORMAT(cron_hourly_energy_data.start_cum_kwh, 2) AS startCumKwh, FORMAT(cron_hourly_energy_data.end_cum_kwh, 2) AS endCumKwh, FORMAT(cron_hourly_energy_data.consuption_kwh, 2) AS conKwh, FORMAT(cron_hourly_energy_data.cost, 2) AS cos FROM cron_hourly_energy_data WHERE  gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."'  AND YEAR(recorded_date) = YEAR(".$nowDate.") AND  MONTH(recorded_date) = MONTH(".$nowDate.") AND recorded_date = DATE(".$nowDate.")  ORDER BY recorded_date DESC";
	}
	//echo $query_rs1; exit;
		$GetDLog = $this->ExecuteQuery($query_rs1, "select");
		$objSmarty->assign('GetDLog', $GetDLog);
	}
      /********************* GetHourlyLog Functions Ends **************************/
       /********************* GetDailyLog Functions Starts **************************/
	function GetPowerDailyLog()
	{
		global $objSmarty,$config,$nowDate;
		$gatewayCode = base64_decode($_GET['gatewayCode']);
		$sensorCode = base64_decode($_GET['sensorCode']);
		$nowDate= "NOW()";
		if(isset($_POST['date1']) && isset($_POST['date2']))
	{
		$date1 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		$date2 = date("Y-m-d",strtotime(trim(addslashes($_POST['date2']))));
		$query_rs1 =  "SELECT recorded_date_time AS TM,DATE(recorded_date_time) AS recorded_date,posted_date_time,linux_date_time,teltonika_date_time,gateway_code,sensor_code,sensor_model,`power_factor_id` AS METER_ID,voltage_l1_n AS `R_VOLTAGE`,voltage_l2_n AS `Y_VOLTAGE`,voltage_l3_n AS `B_VOLTAGE`,voltage_l1_l2 AS `RY_VOLTAGE`,voltage_l2_l3 AS `YB_VOLTAGE`,voltage_l3_l1 AS `BR_VOLTAGE`,current_l1 AS `R_CURRENT`,current_l2 AS `Y_CURRENT`,current_l3 AS `B_CURRENT`,apparent_power_l1_n AS `SUM_KVA`,total_active_power AS `SUM_KW`,total_reactive_power AS `SUM_KVAR`,power_factor_total_import AS `SUM_PF`,measured_frequency AS `FREQUENCY`,cospi_total_import AS `IMPORT_EXPORT` FROM power_factor_energy_data WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND (DATE(recorded_date_time) BETWEEN '".$date1."' AND '".$date2."') ORDER BY TM DESC";
	}
	else
	{
		$query_rs1 =  "SELECT recorded_date_time AS TM,DATE(recorded_date_time) AS recorded_date,posted_date_time,linux_date_time,teltonika_date_time,gateway_code,sensor_code,sensor_model,`power_factor_id` AS METER_ID,voltage_l1_n AS `R_VOLTAGE`,voltage_l2_n AS `Y_VOLTAGE`,voltage_l3_n AS `B_VOLTAGE`,voltage_l1_l2 AS `RY_VOLTAGE`,voltage_l2_l3 AS `YB_VOLTAGE`,voltage_l3_l1 AS `BR_VOLTAGE`,current_l1 AS `R_CURRENT`,current_l2 AS `Y_CURRENT`,current_l3 AS `B_CURRENT`,apparent_power_l1_n AS `SUM_KVA`,total_active_power AS `SUM_KW`,total_reactive_power AS `SUM_KVAR`,power_factor_total_import AS `SUM_PF`,measured_frequency AS `FREQUENCY`,cospi_total_import AS `IMPORT_EXPORT` FROM power_factor_energy_data WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND  MONTH(recorded_date_time) = MONTH(".$nowDate.") AND DATE(recorded_date_time) < DATE(".$nowDate.") ORDER BY TM DESC";
	}
//	echo $query_rs1;
		$GetDLog = $this->ExecuteQuery($query_rs1, "select");
		$objSmarty->assign('GetDLog', $GetDLog);
	}
      /********************* GetDailyLog Functions Ends **************************/
            /********* ListBranch Functions Starts ********************************/
	function ListBranch($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> '')
		{
			$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
			$comId = $_SESSION['CustomerId'];
		}
			$SelQuery = 'SELECT * FROM  `'.$tbl.'branch_master` WHERE company_id="'.$comId.'" AND record_status="1"';  
			$ListView = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListView', $ListView);
		
			$SelQuery2 = 'SELECT `'.$tbl.'platform_mapping`.*,`'.$tbl.'iot_platform`.segmentName FROM  `'.$tbl.'platform_mapping`,`'.$tbl.'iot_platform` WHERE `'.$tbl.'platform_mapping`.segmentCode=`'.$tbl.'iot_platform`.slNo AND `'.$tbl.'platform_mapping`.companyName="'.$comId.'" AND `'.$tbl.'platform_mapping`.status="1" AND `'.$tbl.'platform_mapping`.isActive="1"';  
			$platformView = $this->ExecuteQuery($SelQuery2, 'select');
			$objSmarty->assign('platformView', $platformView);
	}
    /********* ListBranch Functions End ********************************/
    /*************Get Unitrate function Starts****************************************/
	function GetUnitRate()
		{
			global $objSmarty,$config,$nowDate;
			$tbl = $config['DBPrefix'];
		$sensorCode=base64_decode($_GET['sensorCode']);
		$gatewayCode=base64_decode($_GET['gatewayCode']);
		if($_GET['companyId'] <> '')
		{
		   $comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		   $comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		   $branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		   $branchId = $_SESSION['branch_id'];
		}
		
		if($branchId =='0')
		{
			$whrClass='cron_monthly_energy_data.company_id="'.$comId.'"';
		}else
		{
			$whrClass='cron_monthly_energy_data.company_id="'.$comId.'" AND cron_monthly_energy_data.branch_id="'.$branchId.'"';
		}
		
		
		$query_rs1 = "SELECT * FROM cron_monthly_energy_data WHERE  gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND  MONTH(recorded_date) = MONTH(NOW()) AND YEAR(recorded_date) = YEAR(NOW())";
		$ThisPostData = $this->ExecuteQuery($SelQuery, 'select');
	    $objSmarty->assign('ThisPostData', $ThisPostData);
		
		$query_rs1 = "SELECT * FROM cron_monthly_energy_data WHERE  gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND  MONTH(recorded_date) = MONTH(NOW())-1 AND YEAR(recorded_date) = YEAR(NOW())";
		$LastPostData = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('LastPostData', $LastPostData);
		
		}
	/*******************Get Unitrate function Ends***********************************/
	   /********************* Current Month Daily GetMultiLineGraph Branch Functions starts **********************/
	  function currMonthDailygraph()
	  {
	  
global $objSmarty;
			$cm = date('m');
		$cmon = date('m');//echo $cmon;echo "<br>";
	    $lmon = date('m', strtotime('-5 month'));//echo $lmon;echo "<br>";
			$pyr = date('Y')-1;
			$cyr = date('Y');
			$nyr = date('Y')+1;
			if($cm >= '06')
			{
			$sd=$cyr.'-'.$lmon.'-01';
			$ed=$cyr.'-'.$cmon.'-31';
			}
			else
			{
		    $sd=$pyr.'-'.$lmon.'-01';
			$ed=$cyr.'-'.$cmon.'-31';
			}
			//echo $sd;echo $ed; exit;
			  if($_GET['companyId'] <> '')
{
	$comId = base64_decode($_GET['companyId']);
}	
else
{
	$comId = $_SESSION['CustomerId'];
}
if($_GET['branchId'] <> '')
{
$branchId = base64_decode($_GET['branchId']);
}	
else
{
$branchId = $_SESSION['branch_id'];
}
if($_GET['sensorCode'] <> '')
{
$sensorCode = base64_decode($_GET['sensorCode']);
$wherCls = ' AND sensor_code="'.$sensorCode.'" ';
}	
else
{
$wherCls = ' AND (feeder_type="Main Meter" OR feeder_type="Overall Main Meter")';

}

	
	 $colors2 =array("#C2272D", "#F8931F", "#FFFF01", "#009245", "#0193D9", "#0C04ED", 

"#612F90","#F8DC70", "#EA7A2C", "#32A6F4", "#EB34F9", "#12896E", "#0EF1C1" , "#6F6653", "#F60720" , 

"#5A0E7E" ,"#2337D1" ,"#DAF7A6", "#33FFE6","#33C1FF","#DA33FF", "#EA99B0", "#6D7C78", "#FAE7AC", 

"#F5A399");

 //$SelQuery1	= 'SELECT SUM(consuption_kwh+dg_consuption_kwh) AS skwh,SUM(consuption_cost+dg_consuption_cost) AS scost,MONTHNAME(`recorded_date`) AS rec_month,company_id,branch_id,recorded_date FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND feeder_type="Main Meter" AND recorded_date BETWEEN "'.$sd.'" AND "'.$ed.'" GROUP BY MONTH(`recorded_date`) ORDER BY recorded_date ASC';
   $SelQuery1= 'SELECT * FROM (SELECT SUM(consuption_kwh+dg_consuption_kwh) AS skwh,SUM(consuption_cost+dg_consuption_cost) AS scost,DATE_FORMAT(`recorded_date`, "%d-%M-%Y") AS rec_month,company_id,branch_id,recorded_date,sensor_code FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND recorded_date BETWEEN "'.$sd.'" AND "'.$ed.'" '.$wherCls.' GROUP BY `recorded_date` ORDER BY recorded_date DESC LIMIT 0,30) AS selqery ORDER BY recorded_date ASC';  
  
 /* SELECT * FROM (SELECT SUM(consuption_kwh+dg_consuption_kwh) AS skwh,SUM(consuption_cost+dg_consuption_cost) AS scost,DATE_FORMAT(`recorded_date`, "%d-%M-%Y") AS rec_month,company_id,branch_id,recorded_date,sensor_code FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND feeder_type="Main Meter" AND recorded_date BETWEEN "'.$sd.'" AND "'.$ed.'" '.$wherCls.' GROUP BY `recorded_date` ORDER BY recorded_date DESC LIMIT 0,30) AS selqery ORDER BY recorded_date ASC
*/

	  $graphMasterlist = $this->ExecuteQuery($SelQuery1,"select");
	  $objSmarty->assign('graphMasterlist', $graphMasterlist);
	  $test2 = array_values($graphMasterlist);
	  $loopArray2 ='';
      $countItemWiseCurMonSalQty = count($graphMasterlist);

for($k2=0; $k2<$countItemWiseCurMonSalQty; $k2++)
{
if($k2==0){
	$loopArray2 .= '{"dateM":"'.$test2[$k2][rec_month].'","value":"'.$test2[$k2][skwh].'","value1":"'.$test2[$k2][scost].'","color":"'.$colors2[$k2].'"}';
	}
	else
	{
	$loopArray2 .= ',{"dateM":"'.$test2[$k2][rec_month].'","value":"'.$test2[$k2][skwh].'","value1":"'.$test2[$k2][scost].'","color":"'.$colors2[$k2].'"}';
	}
}

$getCurMonSalDaily ="[".$loopArray2."]";	
$objSmarty->assign('getCurMonSalDaily', $getCurMonSalDaily);

	  }
	  /**********************Current Month Daily GetMultiLineGraph Branch Functions starts***************************************************/
	  
	   /********************* Today Hourly data starts **********************/
	  function hourlyDatagraph()
	  {
	  
global $objSmarty;
			//echo $sd;echo $ed;
			  if($_GET['companyId'] <> '')
{
	$comId = base64_decode($_GET['companyId']);
}	
else
{
	$comId = $_SESSION['CustomerId'];
}
if($_GET['branchId'] <> '')
{
$branchId = base64_decode($_GET['branchId']);
}	
else
{
$branchId = $_SESSION['branch_id'];
}
if($_GET['sensorCode'] <> '')
{
$sensorCode = base64_decode($_GET['sensorCode']);
$wherCls = ' AND sensor_code="'.$sensorCode.'" ';
}	
else
{
$wherCls = '';

}

	
	 $colors2 =array("#C2272D", "#F8931F", "#FFFF01", "#009245", "#0193D9", "#0C04ED", 

"#612F90","#F8DC70", "#EA7A2C", "#32A6F4", "#EB34F9", "#12896E", "#0EF1C1" , "#6F6653", "#F60720" , 

"#5A0E7E" ,"#2337D1" ,"#DAF7A6", "#33FFE6","#33C1FF","#DA33FF", "#EA99B0", "#6D7C78", "#FAE7AC", 

"#F5A399");

 //$SelQuery1	= 'SELECT SUM(consuption_kwh+dg_consuption_kwh) AS skwh,SUM(consuption_cost+dg_consuption_cost) AS scost,MONTHNAME(`recorded_date`) AS rec_month,company_id,branch_id,recorded_date FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND feeder_type="Main Meter" AND recorded_date BETWEEN "'.$sd.'" AND "'.$ed.'" GROUP BY MONTH(`recorded_date`) ORDER BY recorded_date ASC';
 $SelQuery1= 'SELECT * FROM (SELECT SUM(consuption_kwh+dg_consuption_kwh) AS skwh,SUM(consuption_cost+dg_consuption_cost) AS scost,DATE_FORMAT(`recorded_date`, "%d-%M-%Y") AS rec_month,TIME_FORMAT(CONCAT(hour_data,":00:00"),"%I %p") AS hour_data,company_id,branch_id,recorded_date,sensor_code,hourly_energy_data_id FROM `cron_hourly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND (feeder_type="Main Meter" OR feeder_type="Overall Main Meter")  AND recorded_date =DATE(NOW())'.$wherCls.' GROUP BY hour_data ORDER BY hourly_energy_data_id ) AS selqery ORDER BY hourly_energy_data_id ASC';  
 
 /* SELECT * FROM (SELECT SUM(consuption_kwh+dg_consuption_kwh) AS skwh,SUM(consuption_cost+dg_consuption_cost) AS scost,DATE_FORMAT(`recorded_date`, "%d-%M-%Y") AS rec_month,company_id,branch_id,recorded_date,sensor_code FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND feeder_type="Main Meter" AND recorded_date BETWEEN "'.$sd.'" AND "'.$ed.'" '.$wherCls.' GROUP BY `recorded_date` ORDER BY recorded_date DESC LIMIT 0,30) AS selqery ORDER BY recorded_date ASC
*/

	  $graphMasterlist = $this->ExecuteQuery($SelQuery1,"select");
	  $objSmarty->assign('graphMasterlist', $graphMasterlist);
	  $test2 = array_values($graphMasterlist);
	  $loopArray2 ='';
      $countItemWiseCurMonSalQty = count($graphMasterlist);

for($k2=0; $k2<$countItemWiseCurMonSalQty; $k2++)
{
if($k2==0){
	$loopArray2 .= '{"dateM":"'.$test2[$k2][hour_data].'","value":"'.$test2[$k2][skwh].'","value1":"'.$test2[$k2][scost].'","color":"'.$colors2[$k2].'"}';
	}
	else
	{
	$loopArray2 .= ',{"dateM":"'.$test2[$k2][hour_data].'","value":"'.$test2[$k2][skwh].'","value1":"'.$test2[$k2][scost].'","color":"'.$colors2[$k2].'"}';
	}
}

$getHourlyData ="[".$loopArray2."]";	
$objSmarty->assign('getHourlyData', $getHourlyData);

	  }
	  /**********************Today Hourly data ***************************************************/
	  /********************* GetMultiLineGraph Branch Functions starts **********************/
	  function Multilinegraph()
	  {
	  
global $objSmarty;
			$cm = date('m');
		$cmon = date('m');//echo $cmon;echo "<br>";
	    $lmon = date('m', strtotime('-5 month'));//echo $lmon;echo "<br>";
			$pyr = date('Y')-1;
			$cyr = date('Y');
			$nyr = date('Y')+1;
			if($cm >= '06')
			{
			$sd=$cyr.'-'.$lmon.'-01';
			$ed=$cyr.'-'.$cmon.'-31';
			}
			else
			{
		    $sd=$pyr.'-'.$lmon.'-01';
			$ed=$cyr.'-'.$cmon.'-31';
			}
			//echo $sd;echo $ed;
			  if($_GET['companyId'] <> '')
{
	$comId = base64_decode($_GET['companyId']);
}	
else
{
	$comId = $_SESSION['CustomerId'];
}
if($_GET['branchId'] <> '')
{
$branchId = base64_decode($_GET['branchId']);
}	
else
{
$branchId = $_SESSION['branch_id'];
}
	
	 $colors2 =array("#C2272D", "#F8931F", "#FFFF01", "#009245", "#0193D9", "#0C04ED", 

"#612F90","#F8DC70", "#EA7A2C", "#32A6F4", "#EB34F9", "#12896E", "#0EF1C1" , "#6F6653", "#F60720" , 

"#5A0E7E" ,"#2337D1" ,"#DAF7A6", "#33FFE6","#33C1FF","#DA33FF", "#EA99B0", "#6D7C78", "#FAE7AC", 

"#F5A399");

 $SelQuery1	= 'SELECT SUM(consuption_kwh+dg_consuption_kwh) AS skwh,SUM(consuption_cost+dg_consuption_cost) AS scost,MONTHNAME(`recorded_date`) AS rec_month,company_id,branch_id,recorded_date FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND feeder_type="Main Meter" AND recorded_date BETWEEN "'.$sd.'" AND "'.$ed.'" GROUP BY MONTH(`recorded_date`) ORDER BY recorded_date ASC';


	  $graphMasterlist = $this->ExecuteQuery($SelQuery1,"select");
	  $objSmarty->assign('graphMasterlist', $graphMasterlist);
	  $test2 = array_values($graphMasterlist);
	  $loopArray2 ='';
      $countItemWiseCurMonSalQty = count($graphMasterlist);

for($k2=0; $k2<$countItemWiseCurMonSalQty; $k2++)
{
if($k2==0){
	$loopArray2 .= '{"month":"'.$test2[$k2][rec_month].'","value":"'.$test2[$k2][skwh].'","value1":"'.$test2[$k2][scost].'","color":"'.$colors2[$k2].'"}';
	}
	else
	{
	$loopArray2 .= ',{"month":"'.$test2[$k2][rec_month].'","value":"'.$test2[$k2][skwh].'","value1":"'.$test2[$k2][scost].'","color":"'.$colors2[$k2].'"}';
	}
}

$getCurMonSal ="[".$loopArray2."]";	
$objSmarty->assign('getCurMonQut', $getCurMonSal);

	  }
	  /**********************GetMultiLineGraph Branch Functions starts***************************************************/
	  /********************* GetDGIcdLog Functions Starts **************************/
	function GetDGIcdLog()
	{
		global $objSmarty,$config,$nowDate;
		$gatewayCode = base64_decode($_GET['gatewayCode']);
		$sensorCode = base64_decode($_GET['sensorCode']);
		$senMod =  explode("-",base64_decode($_GET['sensorCode'])); 
	if(isset($_POST['date1']) && isset($_POST['date2']))
	{
		$date1 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		$date2 = date("Y-m-d",strtotime(trim(addslashes($_POST['date2']))));
		$query_rs1 =  "SELECT recorded_date_time AS TM,posted_date_time,linux_date_time,teltonika_date_time,gateway_code,sensor_code,sensor_model,`METER_ID`, `R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`,`DG_KVAH`, `DG_KWH`, `DG_KVARH`, `SUM_PF`, `FREQUENCY`, `KWH_MSB`, `KWH_LSB`, `KWH`, `METER_TYPE_RUN_HOUR_MSB`, `RUN_HOUR_LSB`, `RUN_HOUR`, `IMPORT_EXPORT` FROM energy_data_master WHERE gateway_code='".$gatewayCode."' AND EB_DG_STATUS='1' AND sensor_code='".$sensorCode."' AND (DATE(recorded_date_time) BETWEEN '".$date1."' AND '".$date2."') ORDER BY TM DESC";
	}
	else
	{
		$query_rs1 = "SELECT recorded_date_time AS TM,posted_date_time,linux_date_time,teltonika_date_time,gateway_code,sensor_code,sensor_model,`METER_ID`, `R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`,`DG_KVAH`, `DG_KWH`, `DG_KVARH`, `SUM_PF`, `FREQUENCY`, `KWH_MSB`, `KWH_LSB`, `KWH`, `METER_TYPE_RUN_HOUR_MSB`, `RUN_HOUR_LSB`, `RUN_HOUR`, `IMPORT_EXPORT` FROM energy_data_master WHERE  gateway_code='".$gatewayCode."' AND EB_DG_STATUS='1' AND sensor_code='".$sensorCode."' AND  DATE(recorded_date_time) = DATE(CONVERT_TZ(NOW(),'+00:00' ,'+00:00'))  ORDER BY TM DESC";
	}
		$GetDGICD = $this->ExecuteQuery($query_rs1, "select");
		$objSmarty->assign('GetDGICD', $GetDGICD);
	}
     /********************* GetDGIcdLog Functions Ends **************************/
	 /********************* GetDailyLog Functions Starts **************************/
	function GetDGDailyLog()
	{
		global $objSmarty,$config,$nowDate;
		$gatewayCode = base64_decode($_GET['gatewayCode']);
		$sensorCode = base64_decode($_GET['sensorCode']);
		$nowDate= "NOW()";
	if(isset($_POST['date1']) && isset($_POST['date2']))
	{
		$date1 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		$date2 = date("Y-m-d",strtotime(trim(addslashes($_POST['date2']))));
		$query_rs1 =  "SELECT * FROM cron_daily_energy_data WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND recorded_date < ".$nowDate." AND  (DATE(recorded_date) BETWEEN '".$date1."' AND '".$date2."') ORDER BY recorded_date DESC";
	}
	else
	{
		$query_rs1 = "SELECT * FROM cron_daily_energy_data WHERE  gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND  MONTH(recorded_date) = MONTH(".$nowDate.") AND recorded_date < DATE(".$nowDate.")  ORDER BY recorded_date DESC";
	}
		$GetDGDLog = $this->ExecuteQuery($query_rs1, "select");
		$objSmarty->assign('GetDGDLog', $GetDGDLog);
	}
      /********************* GetDailyLog Functions Ends **************************/
       /*************************Dashboard Piechart Function Starts*************************************/
	    function MultiBarChart()
	  {
	  
global $objSmarty;
		$cdd = date('d');
		$cmon = date('m');
	    $lmon = date('m', strtotime('-1 month'));
		$cyr = date('Y');
		$lyr = date('Y')-1;
		
	
		
		    $ld = date('t',strtotime('last month'));
			$ldc=$cyr.'-'.$lmon.'-01';
			$ldl=$cyr.'-'.$lmon.'-'.$ld;
			$ldc=date("Y-n-j", strtotime("first day of previous month"));
            $ldl=date("Y-n-j", strtotime("last day of previous month"));
	
			
			$ld1 = date('t');
		    $cdc=$cyr.'-'.$cmon.'-01';
			$cdl=$cyr.'-'.$cmon.'-'.$ld1;
			
			$cd=$cyr.'-'.$cmon.'-'.$cdd;
			
			  if($_GET['companyId'] <> '')
{
	$comId = base64_decode($_GET['companyId']);
}	
else
{
	$comId = $_SESSION['CustomerId'];
}
if($_GET['branchId'] <> '')
{
$branchId = base64_decode($_GET['branchId']);
}	
else
{
$branchId = $_SESSION['branch_id'];
}
	
	 $colors2 =array("#C2272D", "#F8931F", "#FFFF01", "#009245", "#0193D9", "#0C04ED", 

"#612F90","#F8DC70", "#EA7A2C", "#32A6F4", "#EB34F9", "#12896E", "#0EF1C1" , "#6F6653", "#F60720" , 

"#5A0E7E" ,"#2337D1" ,"#DAF7A6", "#33FFE6","#33C1FF","#DA33FF", "#EA99B0", "#6D7C78", "#FAE7AC", 

"#F5A399");

// $SelQuery1	= 'SELECT SUM(`consuption_kwh`) AS skwh,SUM(`consuption_cost`) AS scost,MONTHNAME(`recorded_date`) AS rec_month,company_id,branch_id,sensor_code FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND feeder_type="Main Meter" AND recorded_date BETWEEN "'.$ldc.'" AND "'.$ldl.'" GROUP BY sensor_code';

// $SelQuery2	= 'SELECT SUM(`consuption_kwh`) AS skwh,SUM(`consuption_cost`) AS scost,MONTHNAME(`recorded_date`) AS rec_month,company_id,branch_id,sensor_code FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND feeder_type="Main Meter" AND recorded_date BETWEEN "'.$cdc.'" AND "'.$cdl.'" GROUP BY sensor_code';

//$SelQuery3	= 'SELECT SUM(`consuption_kwh`) AS skwh,SUM(`consuption_cost`) AS scost,MONTHNAME(`recorded_date`) AS rec_month,company_id,branch_id,sensor_code FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND feeder_type="Main Meter" AND recorded_date BETWEEN "'.$cd.'" AND "'.$cd.'" GROUP BY sensor_code';

  $SelQuery1	= 'SELECT SUM(consuption_kwh+dg_consuption_kwh) AS skwh,SUM(consuption_cost+dg_consuption_cost) AS scost,MONTHNAME(`recorded_date`) AS rec_month,company_id,branch_id,sensor_code FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND feeder_type="Main Meter" AND recorded_date BETWEEN "'.$ldc.'" AND "'.$ldl.'" GROUP BY sensor_code'; 

 $SelQuery2	= 'SELECT SUM(consuption_kwh+dg_consuption_kwh) AS skwh,SUM(consuption_cost+dg_consuption_cost) AS scost,MONTHNAME(`recorded_date`) AS rec_month,company_id,branch_id,sensor_code FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND feeder_type="Main Meter" AND recorded_date BETWEEN "'.$cdc.'" AND "'.$cdl.'" GROUP BY sensor_code';

$SelQuery3	= 'SELECT SUM(consuption_kwh+dg_consuption_kwh) AS skwh,SUM(consuption_cost+dg_consuption_cost) AS scost,MONTHNAME(`recorded_date`) AS rec_month,company_id,branch_id,sensor_code FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND feeder_type="Main Meter" AND recorded_date BETWEEN "'.$cd.'" AND "'.$cd.'" GROUP BY sensor_code';


	  $graphMasterlist1 = $this->ExecuteQuery($SelQuery1,"select");
	  $objSmarty->assign('graphMasterlist1', $graphMasterlist1);
	  $test1 = array_values($graphMasterlist1);
	  $loopArray1 ='';
      $countItemWiseCurMonSalQty1 = count($graphMasterlist1);
	  
	  
	  $graphMasterlist2 = $this->ExecuteQuery($SelQuery2,"select");
	  $objSmarty->assign('graphMasterlist2', $graphMasterlist2);
	  $test2 = array_values($graphMasterlist2);
	  $loopArray2 ='';
      $countItemWiseCurMonSalQty2 = count($graphMasterlist2);
	  
	  $graphMasterlist3 = $this->ExecuteQuery($SelQuery3,"select");
	  $objSmarty->assign('graphMasterlist3', $graphMasterlist3);
	  $test3 = array_values($graphMasterlist3);
	  $loopArray3 ='';
      $countItemWiseCurMonSalQty3 = count($graphMasterlist3);


for($k1=0; $k1<$countItemWiseCurMonSalQty1; $k1++)
{
$SelQuery = 'SELECT * FROM  `arka_sensor_master` WHERE sensorCode="'.$test1[$k1][sensor_code].'" AND isActive="1" AND status="1"';  
			$ListView = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListView', $ListView);


if($k1==0){
	$loopArray1 .= '{"sensorcode":"'.$ListView[0][sensorName].'","kwh":"'.$test1[$k1][skwh].'","cost":"'.$test1[$k1][scost].'","color":"'.$colors2[$k1].'"}';
	}
	else
	{
	$loopArray1 .= ',{"sensorcode":"'.$ListView[0][sensorName].'","kwh":"'.$test1[$k1][skwh].'","cost":"'.$test1[$k1][scost].'","color":"'.$colors2[$k1].'"}';
	}
}

for($k2=0; $k2<$countItemWiseCurMonSalQty2; $k2++)
{
$SelQuery = 'SELECT * FROM  `arka_sensor_master` WHERE sensorCode="'.$test2[$k2][sensor_code].'" AND isActive="1" AND status="1"';  
			$ListView = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListView', $ListView);


if($k2==0){
	$loopArray2 .= '{"sensorcode":"'.$ListView[0][sensorName].'","kwh":"'.$test2[$k2][skwh].'","cost":"'.$test2[$k2][scost].'","color":"'.$colors2[$k2].'"}';
	}
	else
	{
	$loopArray2 .= ',{"sensorcode":"'.$ListView[0][sensorName].'","kwh":"'.$test2[$k2][skwh].'","cost":"'.$test2[$k2][scost].'","color":"'.$colors2[$k2].'"}';
	}
}

for($k3=0; $k3<$countItemWiseCurMonSalQty3; $k3++)
{
$SelQuery = 'SELECT * FROM  `arka_sensor_master` WHERE sensorCode="'.$test3[$k3][sensor_code].'" AND isActive="1" AND status="1"';  
			$ListView = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListView', $ListView);


if($k3==0){
	$loopArray3 .= '{"sensorcode":"'.$ListView[0][sensorName].'","kwh":"'.$test3[$k3][skwh].'","cost":"'.$test3[$k3][scost].'","color":"'.$colors2[$k3].'"}';
	}
	else
	{
	$loopArray3 .= ',{"sensorcode":"'.$ListView[0][sensorName].'","kwh":"'.$test3[$k3][skwh].'","cost":"'.$test3[$k3][scost].'","color":"'.$colors2[$k3].'"}';
	}
}

//echo $loopArray1; 
$getCurMonSal1 ="[".$loopArray1."]";	
$objSmarty->assign('getCurMonQut1', $getCurMonSal1);


$getCurMonSal2 ="[".$loopArray2."]";	
$objSmarty->assign('getCurMonQut2', $getCurMonSal2);


$getCurMonSal3 ="[".$loopArray3."]";	
$objSmarty->assign('getCurMonQut3', $getCurMonSal3);

	  }
	  /*******************Dashboard Piechart Function Ends*****************************************/
	   /*********************  GetCostKwhAll Functions Starts ******************/ 
		function GetCostKwhAllForSubDashboard()
		{
			global $objSmarty,$config,$nowDate;
			$tbl = $config['DBPrefix'];
		
		if($_GET['companyId'] <> '')
		{
		   $comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		   $comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		   $branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		   $branchId = $_SESSION['branch_id'];
		}
		$pid = base64_decode($_GET['parent_id']);
		
		$ldc=date("Y", strtotime("first day of previous month"));
            $ldl=date("n", strtotime("last day of previous month"));
		
		$senDashboard = 'SELECT * FROM arka_sensor_master WHERE slNo="'.$pid.'" AND status="1" AND isActive="1"';
			$senDashboard		= $this->ExecuteQuery($senDashboard, "select");
			$objSmarty->assign('senDashboard', $senDashboard);
		
	   $selQry = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND DATE(recorded_date)=DATE('.$nowDate.') AND MONTH(recorded_date)=MONTH('.$nowDate.') AND YEAR(recorded_date)=YEAR('.$nowDate.') AND feeder_type="Sub Meter" AND gateway_code="'.$senDashboard[0]['gateway_id'].'"'; 
		  $todayCostKWH		= $this->ExecuteQuery($selQry, "select");
		  $objSmarty->assign('todayCostKWH', $todayCostKWH);
		
		  $selQry2 = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND MONTH(recorded_date)=MONTH('.$nowDate.') AND YEAR(recorded_date)=YEAR('.$nowDate.') AND feeder_type="Sub Meter" AND gateway_code="'.$senDashboard[0]['gateway_id'].'"'; 
		  $monthCostKWH		= $this->ExecuteQuery($selQry2, "select");
		  $objSmarty->assign('monthCostKWH', $monthCostKWH);
		
		  $selQry3 = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND MONTH(recorded_date)="'.$ldl.'" AND YEAR(recorded_date)="'.$ldc.'" AND feeder_type="Sub Meter" AND gateway_code="'.$senDashboard[0]['gateway_id'].'"';
		  $LastMonthCostKWH		= $this->ExecuteQuery($selQry3, "select");
		  $objSmarty->assign('LastMonthCostKWH', $LastMonthCostKWH);
		}
		/*********************  GetCostKwhAll Functions Ends ******************/ 
		function energyMetersCount(){
			global $objSmarty,$config,$nowDate;
			$tbl = $config['DBPrefix'];
			if($_GET['companyId'] <> '')
			{
			   $comId = base64_decode($_GET['companyId']);
			}	
			else
			{
			   $comId = $_SESSION['CustomerId'];
			}
			if($_GET['branchId'] <> '')
			{
			   $branchId = base64_decode($_GET['branchId']);
			}	
			else
			{
			   $branchId = $_SESSION['branch_id'];
			}
			
			$selQryAll='SELECT COUNT(sensorCode) AS overall_energy_meters  FROM `arka_sensor_master` WHERE arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.isActive=1 AND arka_sensor_master.status=1';
			$selQryExeAll		= $this->ExecuteQuery($selQryAll, "select");
		    $objSmarty->assign('allEnergyMeter', $selQryExeAll);
			
			$selQry='SELECT COUNT(energy_data_master_view.sensor_code) AS live_energy_meters  FROM `arka_sensor_master`,energy_data_master_view WHERE arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.sensorCode=energy_data_master_view.sensor_code AND arka_sensor_master.isActive=1 AND arka_sensor_master.status=1 AND energy_data_master_view.recorded_date_time >=DATE_SUB(NOW(),INTERVAL 10 MINUTE)';
			$selQryExe		= $this->ExecuteQuery($selQry, "select");
		    $objSmarty->assign('onEnergyMeter', $selQryExe);
			
			$selQry2='SELECT COUNT(energy_data_master_view.sensor_code) AS off_energy_meters  FROM `arka_sensor_master`,energy_data_master_view WHERE arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.sensorCode=energy_data_master_view.sensor_code AND arka_sensor_master.isActive=1 AND arka_sensor_master.status=1 AND energy_data_master_view.recorded_date_time < DATE_SUB(NOW(),INTERVAL 10 MINUTE)';
			$selQryExe2		= $this->ExecuteQuery($selQry2, "select");
		    $objSmarty->assign('offEnergyMeter', $selQryExe2);
			
			$selQry3='SELECT COUNT(sensorCode) AS no_con_energy_meters  FROM `arka_sensor_master` WHERE arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.isActive=1 AND arka_sensor_master.status=1 AND arka_sensor_master.sensorCode NOT IN (SELECT sensor_code FROM energy_data_master_view)';
			$selQryExe3		= $this->ExecuteQuery($selQry3, "select");
		    $objSmarty->assign('noConEnergyMeter', $selQryExe3);
			
			$selQryOverallMainmeter='SELECT *  FROM `arka_sensor_master` WHERE  arka_sensor_master.feeder_type="Overall Main Meter" AND arka_sensor_master.isActive=1 AND arka_sensor_master.status=1';
			$selQryfactMain		= $this->ExecuteQuery($selQryOverallMainmeter, "select");
		    $objSmarty->assign('overallmainmeter', $selQryfactMain);

			
		}
		
				/*********************  List GatewayDashboard Functions Ends ******************/ 
		function listGateway(){
			global $objSmarty,$config,$nowDate;
			$tbl = $config['DBPrefix'];

			$selQry='SELECT arka_gateway_master.place_of_installation, gateway_ping_log_view.gateway_code,gateway_ping_log_view.gateway_date_time FROM arka_gateway_master,gateway_ping_log_view WHERE arka_gateway_master.gateway_id=gateway_ping_log_view.gateway_code ORDER BY arka_gateway_master.place_of_installation ';
			$selQryExe		= $this->ExecuteQuery($selQry, "select");
		    $objSmarty->assign('gatewayList', $selQryExe);


			
		}

		/********************* Get Specific IcdLog Functions Starts **************************/
	function GetSpecificLog()
	{
		global $objSmarty,$config,$nowDate;
		if(function_exists('date_default_timezone_set')) {
		date_default_timezone_set("Asia/Kolkata");
		}
		$gatewayCode = base64_decode($_GET['gatewayCode']);
		$sensorCode = base64_decode($_GET['sensorCode']);

		$sensorCodeTable = str_replace("-","_",$sensorCode);
		//echo $sensorCodeTable; exit;
		$senMod =  explode("-",base64_decode($_GET['sensorCode'])); 
	if(isset($_POST['date1']) && isset($_POST['date2']))
	{
		$date1 = date("Y-m-d 08:00:00",strtotime(trim(addslashes($_POST['date1']))));
		$date2 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		
		$date=date_create($date2);
		date_add($date,date_interval_create_from_date_string("1 days"));
		$date2=date_format($date,"Y-m-d 07:59:59");


	/************************     Shift Date Format  Starts     **********************************/
/*	
		if(function_exists('date_default_timezone_set')) {
		date_default_timezone_set("Asia/Kolkata");
		}
		$deliverytime = new DateTime($date1);
		
		$hour = $deliverytime->format('H');
		if ($hour >= 00 && $hour <=03) {
			$date=date_create(date('y-m-d'));
			date_sub($date,date_interval_create_from_date_string("1 days"));
			$recorded_date=date_format($date,"Y-m-d");
		} else {
			
			$recorded_date=date('Y-m-d');
		} */
	/************************     Shift Date Format  Starts     **********************************/
		$query_rs1 =  "SELECT recorded_date_time AS TM,".$sensorCodeTable.".* FROM ".$sensorCodeTable." WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND (recorded_date_time BETWEEN '".$date1."' AND '".$date2."') ORDER BY TM DESC";
	}
	else
	{	
		$deliverytime = new DateTime(date('Y-m-d H:i:s'));
		$hour = $deliverytime->format('H');
		$hour=intval($hour);
		if ($hour >=0 && $hour <8) {
			$date=date_create(date('Y-m-d'));
			date_sub($date,date_interval_create_from_date_string("1 days"));
			$date1=date_format($date,"Y-m-d 08:00:00");
			$date2=date('Y-m-d 07:59:59');
			//echo"if";
		} else {
			
			$date1=date('Y-m-d 08:00:00');
			$date=date_create(date('Y-m-d'));
			date_add($date,date_interval_create_from_date_string("1 days"));
			$date2=date_format($date,"Y-m-d 07:59:59");
			//echo "from D".$date1;
			//echo "to D".$date2;
			//echo "else";
		}
	
		$query_rs1 =  "SELECT recorded_date_time AS TM,".$sensorCodeTable.".* FROM ".$sensorCodeTable." WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND (recorded_date_time BETWEEN '".$date1."' AND '".$date2."') ORDER BY TM DESC";
	} //echo $query_rs1;exit;
		$GetICD = $this->ExecuteQuery($query_rs1, "select");
		$objSmarty->assign('GetICD', $GetICD);
	}
     /********************* Get Specific IcdLog Functions Ends **************************/

	  /********************* Get Specific MeterLogGraph Functions Ends **************************/
	  function GetSpecificMeterLogGraph()
	  {
		
		 global $objSmarty,$config,$nowDate;
		 if(function_exists('date_default_timezone_set')) {
			 date_default_timezone_set("Asia/Kolkata");
		 }
		 $pf='';
		 $gatewayCode = base64_decode($_GET['gatewayCode']);
		 $sensorCode = base64_decode($_GET['sensorCode']);
		 $sensorCodeTable = str_replace("-","_",$sensorCode);
		 if(isset($_POST['date1']))
		 {
			 $date1 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		 //	$date2 = date("Y-m-d 23:59:59",strtotime(trim(addslashes($_POST['date1']))));
	 
			 
			 $yaxis = $_POST['yAxis'];
		 //	echo $yaxis; exit;
			 if($yaxis== 'VOLTAGE' || $yaxis== 'CURRENT')
			 {
				 $yaxis_par="R_".$yaxis.",Y_".$yaxis.",B_".$yaxis;
				 $pf=0;
			 }
			 else if($yaxis== 'SUM_PF'){
				 $yaxis_par="TRUNCATE(IF(`SUM_PF` >= 1 AND `SUM_PF` < 2 , '-0.99', IF(`SUM_PF` >= 2 , '1', `SUM_PF`)),2) AS SUM_PF ";
				 $pf=1;
			 }
			 else
			 {
				 $yaxis_par =$yaxis;
				 $pf=2;
			 }
		 //	$query_rs1 =  "SELECT ".$yaxis_par.",recorded_date_time AS TM FROM energy_data_master WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND (recorded_date_time BETWEEN '".$date1."' AND '".$date2."') ORDER BY TM ASC";
				 $query_rs1 =  "SELECT ".$yaxis_par.",recorded_date_time AS TM FROM ".$sensorCodeTable." WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND DATE(recorded_date_time)='".$date1."' ORDER BY TM ASC";
		 }
		 else
		 {
			 $deliverytime = new DateTime(date('Y-m-d H:i:s'));
			 $hour = $deliverytime->format('H');
			 $hour=intval($hour);
	 
				 
				 $date1=date('Y-m-d 00:00:00');
				 $date2=date('Y-m-d 23:59:59');
			 //	$date=date_create(date('Y-m-d'));
				 
			 //	$date2=date_format($date,"Y-m-d 23:59:59");
	 
			 $yaxis_par="R_VOLTAGE,Y_VOLTAGE,B_VOLTAGE";
			 $query_rs1 = "SELECT ".$yaxis_par.",recorded_date_time AS TM FROM ".$sensorCodeTable." WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND (recorded_date_time BETWEEN '".$date1."' AND '".$date2."') ORDER BY TM ASC";
		 }
			 //echo $query_rs1; exit;
			 $GetTemp = $this->ExecuteQuery($query_rs1, "select");
			 $objSmarty->assign('GetTemp', $GetTemp);
		 if($pf!=1)
		 {
			 $splVar= explode(",",$yaxis_par);
		 }
		 else
		 {
			 $splVar=array("SUM_PF");
		 }
			 $arrData = array();
		 foreach ($GetTemp as $key => $value) 
		 {
			 $orgDate =$GetTemp[$key]['TM'];  
			 $GDate = date("d-M-Y h:i A", strtotime($orgDate));
		 if($splVar[1]!='')
		 {
			 array_push($arrData, array(
			 $splVar[0] => $GetTemp[$key][$splVar[0]],
			 $splVar[1] => $GetTemp[$key][$splVar[1]],
			 $splVar[2] => $GetTemp[$key][$splVar[2]],
			 "tm" => $GDate
			 ));
		 }
		 else
		 {
			 array_push($arrData, array(
			 $splVar[0] => $GetTemp[$key][$splVar[0]],
			 "tm" => $GDate
			 ));
		 }
		 }
			 $ChartData = json_encode($arrData);
			 $objSmarty->assign('ChartData', $ChartData);
		 }
			 /********************* Get Specific MeterLogGraph Functions Ends **************************/

			 /*********************  Get Specific Energy Meters Count Functions Start ******************/ 
		function specificEnergyMetersCount(){
			global $objSmarty,$config,$nowDate;
			$tbl = $config['DBPrefix'];
			if($_GET['companyId'] <> '')
			{
			   $comId = base64_decode($_GET['companyId']);
			}	
			else
			{
			   $comId = $_SESSION['CustomerId'];
			}
			if($_GET['branchId'] <> '')
			{
			   $branchId = base64_decode($_GET['branchId']);
			}	
			else
			{
			   $branchId = $_SESSION['branch_id'];
			}
			
			 $selQryAll='SELECT * FROM `arka_sensor_master` WHERE arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.isActive=1 AND arka_sensor_master.status=1'; 
			$selQryExeAll		= $this->ExecuteQuery($selQryAll, "select");
			$selQryExeAllCount		= $this->ExecuteQuery($selQryAll, "numrows");
		    $objSmarty->assign('allEnergyMeter', $selQryExeAll);
			$objSmarty->assign('overall_energy_meters', $selQryExeAllCount);
			//echo "am working";

		$SelCompanyQuery = 'SELECT companyCode FROM arka_company_master WHERE slNo="'.$comId.'" AND status="1"';  
		$SelCompanyQueryView = $this->ExecuteQuery($SelCompanyQuery, 'select');
		$comCode = $SelCompanyQueryView[0]['companyCode'];

		$SelBranchQuery = 'SELECT branch_id FROM arka_branch_master WHERE sl_no="'.$branchId.'" AND record_status="1"';  
		$SelBranchQueryView = $this->ExecuteQuery($SelBranchQuery, 'select');
		$branchCode = $SelBranchQueryView[0]['branch_id'];
		//echo "Company Code".$comCode."<br>";
		//echo "Branch Code".$branchCode."<br>"; 

           $ConfigDBName = $config['DBName'];

			$notConnect = 0;
            $live = 0;
            $off = 0;

			foreach($selQryExeAll as $meterDetail)
    {
      $sensorCode = $meterDetail['sensorCode'];
	  $sensorCodeTable = str_replace("-","_",$sensorCode); 
	  //echo $sensorCode."<br/>";

			   $selTableQry='SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE "'.$comCode.'_'.$branchCode.'\_%_'.$sensorCodeTable.'"'; 
			// echo'<br/>';
			  $selTableQryExe		= $this->ExecuteQuery($selTableQry, "select");
			  $selTableQryExeCount		= $this->ExecuteQuery($selTableQry, "numrows");
			  //echo $selTableQryExeCount;
			  $sensorTableName = $selTableQryExe[0]['TABLE_NAME'];
			  //$selTableQryExeCount = $selTableQryExe[0]['TOTALNUMBEROFTABLES'];
			  if($selTableQryExeCount > 0){

				  $selOffQry='SELECT * FROM '.$ConfigDBName.'.'.$sensorTableName.' WHERE status ="1" AND sensor_code="'.$sensorCode.'" AND posted_date_time >=DATE_SUB(NOW(),INTERVAL 10 MINUTE) ORDER BY slNo DESC LIMIT 0,1'; 
				
			  $selOffQryExe		= $this->ExecuteQuery($selOffQry, "select");
			  $selOffQryExeCount = $this->ExecuteQuery($selOffQry, "numrows");
              
			  if($selOffQryExeCount > 0){

				
				$live += 1;

			  }else{

				$off += 1;

			  }

			  }else{
				$notConnect += 1;
			  }


	}
	//exit;
	
	//echo "Overall = ".$selQryExeAllCount."<br/>"."Live = ".$live."<br/>"."Off = ".$off."<br/>"."Not Connect = ".$notConnect; exit;
	
		    $objSmarty->assign('overallmeters', $selQryExeAllCount);
			$objSmarty->assign('livemeters', $live);
			$objSmarty->assign('offmeters', $off);
			$objSmarty->assign('noconnectionmeters', $notConnect);

			
		}
		
				 /*********************  Get Specific Energy Meters Count Functions End ******************/ 

				    /********************* Get Specific FeederList Functions Starts **************************/
	function GetSpecificFeederList()  
	{
		global $objSmarty,$config,$nowDate;
			$tbl = $config['DBPrefix'];
	
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}	
		$gatewayCode=base64_decode($_GET['gatewayCode']);
		$sensorCode=base64_decode($_GET['sensorCode']);

		$ConfigDBName = $config['DBName'];
		//echo $ConfigDBName; exit;
		$SelCompanyQuery = 'SELECT companyCode FROM arka_company_master WHERE slNo="'.$comId.'" AND status="1"';  
		$SelCompanyQueryView = $this->ExecuteQuery($SelCompanyQuery, 'select');
		$comCode = $SelCompanyQueryView[0]['companyCode'];

		$SelBranchQuery = 'SELECT branch_id FROM arka_branch_master WHERE sl_no="'.$branchId.'" AND record_status="1"';  
		$SelBranchQueryView = $this->ExecuteQuery($SelBranchQuery, 'select');
		$branchCode = $SelBranchQueryView[0]['branch_id'];
		//echo "Company Code".$comCode."<br>";
		//echo "Branch Code".$branchCode."<br>";

		
	    $SelFeederName = 'SELECT * FROM arka_sensor_master WHERE company_id ="'.$comId.'" AND branch_id ="'.$branchId.'" AND segmentName="Energy Meter" AND isActive="1"'; 
		$ListFeeder		= $this->ExecuteQuery($SelFeederName, "select");
		$objSmarty->assign('ListFeeder', $ListFeeder);	

		 $SelSenso = 'SELECT * FROM arka_sensor_master WHERE company_id ="'.$comId.'" AND branch_id ="'.$branchId.'" AND sensorCode="'.$sensorCode.'" AND isActive="1"'; 
		$ListSenso	= $this->ExecuteQuery($SelSenso, "select");
		$objSmarty->assign('ListSenso', $ListSenso);
	
	
		$senMod =  explode("-",$sensorCode); 
		
		if($senMod[0]=="RGA20S")
		{
		    
	    $objSmarty->assign('KW_MAX', 0);
		$objSmarty->assign('KW_INT', 0);
		$objSmarty->assign('KVA_MAX', 0);
		$objSmarty->assign('KVA_INT', 0);
		$objSmarty->assign('KVAR_MAX', 0);
		$objSmarty->assign('KVAR_INT',0);
	}
	else
	{
		$objSmarty->assign('KW_MAX', $ListSenso[0]['kw_max_value']);
		$objSmarty->assign('KW_INT', $ListSenso[0]['kw_max_value']/5);
		$objSmarty->assign('KVA_MAX', $ListSenso[0]['kva_max_value']);
		$objSmarty->assign('KVA_INT', $ListSenso[0]['kva_max_value']/5);
		$objSmarty->assign('KVAR_MAX', $ListSenso[0]['kvar_max_value']);
		$objSmarty->assign('KVAR_INT', $ListSenso[0]['kvar_max_value']/5);
	}
	
	
	    $objSmarty->assign('KWH_MAX', $ListSenso[0]['kwh_max_value']);
		$objSmarty->assign('KWH_INT', $ListSenso[0]['kwh_max_value']/5);
		$objSmarty->assign('KVAH_MAX', $ListSenso[0]['kvah_max_value']);
		$objSmarty->assign('KVAH_INT', $ListSenso[0]['kvah_max_value']/5);
		$objSmarty->assign('KVARH_MAX', $ListSenso[0]['kvarh_max_value']);
		$objSmarty->assign('KVARH_INT', $ListSenso[0]['kvarh_max_value']/5);
	
		$sensorCodeTable = str_replace("-","_",$sensorCode); 

//echo $sensorCodeTable; exit;
		    $selTableQry='SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE "'.$comCode.'_'.$branchCode.'\_%_'.$sensorCodeTable.'"';  
			// echo'<br/>';
			  $selTableQryExe		= $this->ExecuteQuery($selTableQry, "select");
			  $selTableQryExeCount		= $this->ExecuteQuery($selTableQry, "numrows");
			  //echo $selTableQryExeCount;
			  $sensorTableName = $selTableQryExe[0]['TABLE_NAME'];
			  //$selTableQryExeCount = $selTableQryExe[0]['TOTALNUMBEROFTABLES'];
			  if($selTableQryExeCount > 0){

				  $selOffQry='SELECT * FROM '.$ConfigDBName.'.'.$sensorTableName.' WHERE status ="1" AND sensor_code="'.$sensorCode.'" AND posted_date_time >=DATE_SUB(NOW(),INTERVAL 10 MINUTE) ORDER BY slNo DESC LIMIT 0,1'; 
				
			  $selOffQryExe		= $this->ExecuteQuery($selOffQry, "select");
			  $selOffQryExeCount = $this->ExecuteQuery($selOffQry, "numrows");
              
			  if($selOffQryExeCount > 0){

			  $DBSensorTableName = $ConfigDBName.'.'.$sensorTableName;
	//echo $DBSensorTableName; exit;
				  $SelFeederDet ='SELECT '.$DBSensorTableName.'.*'.',arka_sensor_master.* FROM '.$DBSensorTableName.',arka_sensor_master WHERE arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND '.$DBSensorTableName.'.sensor_code="'.$sensorCode.'" AND '.$DBSensorTableName.'.gateway_code="'.$gatewayCode.'" AND arka_sensor_master.sensorCode='.$DBSensorTableName.'.sensor_code AND arka_sensor_master.gateway_id='.$DBSensorTableName.'.gateway_code ORDER BY '.$DBSensorTableName.'.slNo DESC LIMIT 0,1'; 
				

			  }else{

				

			  }

			  }else{
				

			  }



		 

		$ListFeederDet		= $this->ExecuteQuery($SelFeederDet, "select");
		$ListFeederDet2		= $this->ExecuteQuery($SelFeederDet, "numrows");
		$objSmarty->assign('ListFeederDet', $ListFeederDet);
		$objSmarty->assign('ListFeederDet2', $ListFeederDet2);	
		
	    $SelFeederDetP ='SELECT power_factor_energy_data_view.power_factor_id,power_factor_energy_data_view.`gateway_code`, power_factor_energy_data_view.`sensor_code`, power_factor_energy_data_view.`sensor_model`, power_factor_energy_data_view.`voltage_l1_n` AS `R_VOLTAGE`, power_factor_energy_data_view.`voltage_l2_n` AS `Y_VOLTAGE`, power_factor_energy_data_view.`voltage_l3_n` AS `B_VOLTAGE`, power_factor_energy_data_view.voltage_l1_l2 AS `RY_VOLTAGE`, power_factor_energy_data_view.voltage_l2_l3 AS `YB_VOLTAGE`, power_factor_energy_data_view. voltage_l3_l1 AS `BR_VOLTAGE`, power_factor_energy_data_view.current_l1 AS `R_CURRENT`, power_factor_energy_data_view.current_l2 AS `Y_CURRENT`, power_factor_energy_data_view.current_l3 AS `B_CURRENT`, power_factor_energy_data_view.apparent_power_l1_n AS `SUM_KVA`, power_factor_energy_data_view.total_active_power AS `SUM_KW`, power_factor_energy_data_view.total_reactive_power AS `SUM_KVAR`, power_factor_energy_data_view.measured_frequency AS `FREQUENCY`,power_factor_energy_data_view.power_factor_total_import AS `SUM_PF`,power_factor_energy_data_view.`step1_actual_steps_value`, power_factor_energy_data_view.`step2_actual_steps_value`, power_factor_energy_data_view.`step3_actual_steps_value`, power_factor_energy_data_view.`step4_actual_steps_value`, power_factor_energy_data_view.`step5_actual_steps_value`, power_factor_energy_data_view.`step6_actual_steps_value`, power_factor_energy_data_view.`step7_actual_steps_value`, power_factor_energy_data_view.`step8_actual_steps_value`, power_factor_energy_data_view.`step9_actual_steps_value`, power_factor_energy_data_view.`step10_actual_steps_value`, power_factor_energy_data_view.`step11_actual_steps_value`, power_factor_energy_data_view.`step12_actual_steps_value`, power_factor_energy_data_view.`step13_actual_steps_value`, power_factor_energy_data_view.`step14_actual_steps_value`, power_factor_energy_data_view.`step15_actual_steps_value`, power_factor_energy_data_view.`step16_actual_steps_value`, power_factor_energy_data_view.`step17_actual_steps_value`, power_factor_energy_data_view.`step18_actual_steps_value`, power_factor_energy_data_view.`step19_actual_steps_value`, power_factor_energy_data_view.`step20_actual_steps_value`, power_factor_energy_data_view.power_factor_total_import AS `IMPORT_EXPORT`,power_factor_energy_data_view.`recorded_date_time`,arka_sensor_master.* FROM power_factor_energy_data_view,arka_sensor_master WHERE arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND power_factor_energy_data_view.sensor_code="'.$sensorCode.'" AND power_factor_energy_data_view.gateway_code="'.$gatewayCode.'" AND arka_sensor_master.sensorCode=power_factor_energy_data_view.sensor_code AND arka_sensor_master.gateway_id=power_factor_energy_data_view.gateway_code ';
		$ListFeederDetP		= $this->ExecuteQuery($SelFeederDetP, "select");
		$ListFeederDetP2		= $this->ExecuteQuery($SelFeederDetP, "numrows");
		$objSmarty->assign('ListFeederDetP', $ListFeederDetP);
		$objSmarty->assign('ListFeederDetP2', $ListFeederDetP2);	
	}	
	/********************* Get Specific FeederList Functions Ends **************************/

	function DashPlatformMapingList()  
	{
		global $objSmarty;	
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}

	$SelPlatformMapListQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';  // eg : 1,2,3
			$PlatformMapListView = $this->ExecuteQuery($SelPlatformMapListQuery, 'select');
			$objSmarty->assign('PlatformMapListView', $PlatformMapListView);	

	}

function DashOverallData(){

global $objSmarty;	
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}	
		$gatewayCode=base64_decode($_GET['gatewayCode']);
		$sensorCode=base64_decode($_GET['sensorCode']);
		//echo "am here"; exit;

		$SelCompanyQuery = 'SELECT companyCode FROM arka_company_master WHERE slNo="'.$comId.'" AND status="1"';  
		$SelCompanyQueryView = $this->ExecuteQuery($SelCompanyQuery, 'select');
		$comCode = $SelCompanyQueryView[0]['companyCode'];

		$SelBranchQuery = 'SELECT branch_id FROM arka_branch_master WHERE sl_no="'.$branchId.'" AND record_status="1"';  
		$SelBranchQueryView = $this->ExecuteQuery($SelBranchQuery, 'select');
		$branchCode = $SelBranchQueryView[0]['branch_id'];
		//echo "Company Code".$comCode."<br>";
		//echo "Branch Code".$branchCode."<br>"; 
		



		   $SelPlatformMapQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';  
			$ListPlatformMapView = $this->ExecuteQuery($SelPlatformMapQuery, 'select');

			$energyPF = "Energy Meter";
		    $solarPF = "Solar Inverter";
			$TempPF = "Temperature";

/*********************************   Today Total Energy  Start ********************************************/
		$SelEnergyPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$energyPF.'" AND status="1"';  
		$ListEnergyPlatformView = $this->ExecuteQuery($SelEnergyPlatformQuery, 'select');

		$energySegCode = $ListEnergyPlatformView[0]['segmentCode'];
		$energySegId = $ListEnergyPlatformView[0]['slNo'];
		$objSmarty->assign('energySegId', $energySegId);	


		$SelSolarPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$solarPF.'" AND status="1"';  
		$ListSolarPlatformView = $this->ExecuteQuery($SelSolarPlatformQuery, 'select');
        $solarSegId = $ListSolarPlatformView[0]['slNo'];
		$solarSegCode = $ListSolarPlatformView[0]['segmentCode'];


		   $SelPlatformMapSolarQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE segmentCode="'.$solarSegId.'" AND companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';   
		 $ListPlatformMapSolarView = $this->ExecuteQuery($SelPlatformMapSolarQuery, 'select');
		 $ListPlatformMapSolarViewCount = $this->ExecuteQuery($SelPlatformMapSolarQuery, 'numrows');
		 $objSmarty->assign('solarPlatformCount', $ListPlatformMapSolarViewCount);

		 


		$dailyTableEB = $comCode."_".$branchCode."_".$energySegCode."_cron_daily";
		$dailyTableSolar = $comCode."_".$branchCode."_".$solarSegCode."_cron_daily";
//echo "Daily Table".$dailyTableEB; 

	   $dailyTable = "TPL_AMBT_E1001_cron_daily";
       $monthlyTable = "TPL_AMBT_E1001_cron_monthly";
       $hourlyTable = "TPL_AMBT_E1001_cron_hourly_".$monthShortCode."_".$yearShortCode;

	     $selDailyTableQry='SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE "'.$dailyTableEB.'"';   
			// echo'<br/>';
			  $selDailyTableQryExe		= $this->ExecuteQuery($selDailyTableQry, "select");
			  $selDailyTableQryExeCount		= $this->ExecuteQuery($selDailyTableQry, "numrows");
			  //echo $selDailyTableQryExeCount;
			  $dailyTableName = $selDailyTableQryExe[0]['TABLE_NAME'];
			  //$selTableQryExeCount = $selTableQryExe[0]['TOTALNUMBEROFTABLES'];
			  if($selDailyTableQryExeCount <= 0){

			  //echo"am in if"; exit;

			  }else{

//echo"am in else";
			
if($ListPlatformMapSolarViewCount >= 1){
		
		 $SelTodayDashTotalEnergyQry = "
SELECT
(
    SELECT COALESCE(SUM(consuption_kwh) + SUM(dg_consuption_kwh),0)
    FROM $dailyTableEB
    WHERE feeder_type='Main Meter' AND company_id = $comId
      AND branch_id = $branchId
      AND posted_date_time >= CURDATE()
      AND posted_date_time < CURDATE() + INTERVAL 1 DAY
)
+
(
    SELECT COALESCE(SUM(solar_ac_consuption_kwh),0)
    FROM $dailyTableSolar
    WHERE company_id = $comId
      AND branch_id = $branchId
      AND posted_date_time >= CURDATE()
      AND posted_date_time < CURDATE() + INTERVAL 1 DAY
)
AS total_energy
"; 
}else{

 $SelTodayDashTotalEnergyQry = "
SELECT
(
    SELECT COALESCE(SUM(consuption_kwh) + SUM(dg_consuption_kwh),0)
    FROM $dailyTableEB
    WHERE feeder_type='Main Meter' AND company_id = $comId
      AND branch_id = $branchId
      AND posted_date_time >= CURDATE()
      AND posted_date_time < CURDATE() + INTERVAL 1 DAY
) AS total_energy
";  


}

		$TodayDashTotalEnergy		= $this->ExecuteQuery($SelTodayDashTotalEnergyQry, "select");
		$objSmarty->assign('TodayDashTotalEnergy', $TodayDashTotalEnergy);

/****************************************                Today Total Energy   End ********************************************/
/****************************************                Today Grid Energy   Start ********************************************/
//echo $TodayDashTotalEnergy[0]['total_energy']; exit;

$SelTodayDashGridEnergyQry = "
SELECT
(
    SELECT COALESCE(SUM(consuption_kwh),0)
    FROM $dailyTableEB
    WHERE feeder_type='Main Meter' AND company_id = $comId
      AND branch_id = $branchId
      AND posted_date_time >= CURDATE()
      AND posted_date_time < CURDATE() + INTERVAL 1 DAY
)AS total_energy,
(
    SELECT COALESCE(SUM(consuption_cost),0)
    FROM $dailyTableEB
    WHERE feeder_type='Main Meter' AND company_id = $comId
      AND branch_id = $branchId
      AND posted_date_time >= CURDATE()
      AND posted_date_time < CURDATE() + INTERVAL 1 DAY
)AS total_cost
"; 

$SelYesterdayDashGridEnergyQry = "
SELECT
(
    SELECT COALESCE(SUM(consuption_kwh),0)
    FROM $dailyTableEB
    WHERE feeder_type='Main Meter' AND company_id = $comId
      AND branch_id = $branchId
      AND posted_date_time >= CURDATE() - INTERVAL 1 DAY
      AND posted_date_time < CURDATE()
)AS yesterday_total_energy,
(
    SELECT COALESCE(SUM(consuption_cost),0)
    FROM $dailyTableEB
    WHERE feeder_type='Main Meter' AND company_id = $comId
      AND branch_id = $branchId
      AND posted_date_time >= CURDATE() - INTERVAL 1 DAY
      AND posted_date_time < CURDATE()
)AS yesterday_total_cost
"; 

		$TodayDashGridEnergy		= $this->ExecuteQuery($SelTodayDashGridEnergyQry, "select");
		$objSmarty->assign('TodayDashGridEnergy', $TodayDashGridEnergy);	
		$YesterdayDashGridEnergy		= $this->ExecuteQuery($SelYesterdayDashGridEnergyQry, "select");
		$objSmarty->assign('YesterdayDashGridEnergy', $YesterdayDashGridEnergy);	

		

/****************************************                Today Grid Energy   End ********************************************/
/****************************************                Today DG Energy   Start ********************************************/

 $SelTodayDashDGEnergyQry = "
    SELECT COALESCE(SUM(dg_consuption_kwh)) AS dg_energy,COALESCE(SUM(dg_consuption_cost)) AS total_dg_cost
    FROM $dailyTableEB
    WHERE feeder_type='Main Meter' AND company_id = $comId
      AND branch_id = $branchId
      AND posted_date_time >= CURDATE()
      AND posted_date_time < CURDATE() + INTERVAL 1 DAY"; 

		$TodayDashDGEnergy		= $this->ExecuteQuery($SelTodayDashDGEnergyQry, "select");
		$objSmarty->assign('TodayDashDGEnergy', $TodayDashDGEnergy);	

		
		

/****************************************                Today DG Energy   End ********************************************/

/****************************************                Today Solar Energy   Start ********************************************/
if($ListPlatformMapSolarViewCount >= 1){
 $SelTodayDashSolarEnergyQry = "SELECT COALESCE(SUM(solar_ac_consuption_kwh),0) AS total_solar_energy,COALESCE(SUM(solar_ac_consuption_cost)) AS total_solar_cost
    FROM $dailyTableSolar
    WHERE company_id = $comId
      AND branch_id = $branchId
      AND posted_date_time >= CURDATE()
      AND posted_date_time < CURDATE() + INTERVAL 1 DAY"; 

		$TodayDashSolarEnergy		= $this->ExecuteQuery($SelTodayDashSolarEnergyQry, "select");
		$objSmarty->assign('TodayDashSolarEnergy', $TodayDashSolarEnergy);	

		
}		

/****************************************                Today Solar Energy  End ********************************************/
/****************************************           This month Total Energy Start ********************************************/
if($ListPlatformMapSolarViewCount >= 1){

    $SelThisMonthDashTotalEnergyQry = "
    SELECT
    (
        SELECT COALESCE(SUM(consuption_kwh) + SUM(dg_consuption_kwh),0)
        FROM $dailyTableEB
        WHERE feeder_type='Main Meter'
          AND company_id = $comId
          AND branch_id = $branchId
          AND posted_date_time >= DATE_FORMAT(CURDATE(), '%Y-%m-01')
          AND posted_date_time < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01')
    )
    +
    (
        SELECT COALESCE(SUM(solar_ac_consuption_kwh),0)
        FROM $dailyTableSolar
        WHERE company_id = $comId
          AND branch_id = $branchId
          AND posted_date_time >= DATE_FORMAT(CURDATE(), '%Y-%m-01')
          AND posted_date_time < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01')
    )
    AS total_energy
    ";

}else{

    $SelThisMonthDashTotalEnergyQry = "
    SELECT
    (
        SELECT COALESCE(SUM(consuption_kwh) + SUM(dg_consuption_kwh),0)
        FROM $dailyTableEB
        WHERE feeder_type='Main Meter'
          AND company_id = $comId
          AND branch_id = $branchId
          AND posted_date_time >= DATE_FORMAT(CURDATE(), '%Y-%m-01')
          AND posted_date_time < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01')
    ) AS total_energy
    ";

}

$ThisMonthDashTotalEnergy = $this->ExecuteQuery($SelThisMonthDashTotalEnergyQry, "select");
$objSmarty->assign('ThisMonthDashTotalEnergy', $ThisMonthDashTotalEnergy);
/****************************************           This month Total Energy End ********************************************/
/****************************************           This month Grid Energy Start ********************************************/

$SelThisMonthDashGridEnergyQry = "
SELECT
(
    SELECT COALESCE(SUM(consuption_kwh),0)
    FROM $dailyTableEB
    WHERE feeder_type='Main Meter' AND company_id = $comId
    AND branch_id = $branchId
    AND posted_date_time >= DATE_FORMAT(CURDATE(), '%Y-%m-01')
    AND posted_date_time < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01')
)AS total_energy,
(
    SELECT COALESCE(SUM(consuption_cost),0)
    FROM $dailyTableEB
    WHERE feeder_type='Main Meter' AND company_id = $comId
    AND branch_id = $branchId
    AND posted_date_time >= DATE_FORMAT(CURDATE(), '%Y-%m-01')
    AND posted_date_time < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01')
)AS total_cost
"; 

$SelLastMonthDashGridEnergyQry = "
SELECT
    COALESCE(SUM(consuption_kwh),0) AS total_energy,
    COALESCE(SUM(consuption_cost),0) AS total_cost
FROM $dailyTableEB
WHERE feeder_type='Main Meter' AND company_id = $comId
  AND branch_id = $branchId
  AND posted_date_time >= DATE_FORMAT(CURDATE() - INTERVAL 1 MONTH, '%Y-%m-01')
  AND posted_date_time < DATE_FORMAT(CURDATE(), '%Y-%m-01')
";

		$ThisMonthDashGridEnergy		= $this->ExecuteQuery($SelThisMonthDashGridEnergyQry, "select");
		$objSmarty->assign('ThisMonthDashGridEnergy', $ThisMonthDashGridEnergy);	

		$LastMonthDashGridEnergy		= $this->ExecuteQuery($SelLastMonthDashGridEnergyQry, "select");
		$objSmarty->assign('LastMonthDashGridEnergy', $LastMonthDashGridEnergy);	

		

/****************************************           This month Grid Energy End ********************************************/

/****************************************           This month DG Energy Start ********************************************/

 $SelThisMonthDashDGEnergyQry = "
    SELECT COALESCE(SUM(dg_consuption_kwh)) AS dg_energy,COALESCE(SUM(dg_consuption_cost)) AS total_dg_cost
    FROM $dailyTableEB
    WHERE feeder_type='Main Meter' AND company_id = $comId
      AND branch_id = $branchId
      AND posted_date_time >= DATE_FORMAT(CURDATE(), '%Y-%m-01')
      AND posted_date_time < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01')"; 

	  $SelLastMonthDashDGEnergyQry = "
    SELECT COALESCE(SUM(dg_consuption_kwh)) AS dg_energy,COALESCE(SUM(dg_consuption_cost)) AS total_dg_cost
    FROM $dailyTableEB
    WHERE feeder_type='Main Meter' AND company_id = $comId
      AND branch_id = $branchId
      AND posted_date_time >= DATE_FORMAT(CURDATE() - INTERVAL 1 MONTH, '%Y-%m-01')
      AND posted_date_time < DATE_FORMAT(CURDATE(), '%Y-%m-01')";

		$ThisMonthDashDGEnergy		= $this->ExecuteQuery($SelThisMonthDashDGEnergyQry, "select");
		$objSmarty->assign('ThisMonthDashDGEnergy', $ThisMonthDashDGEnergy);	

		$LastMonthDashDGEnergy		= $this->ExecuteQuery($SelLastMonthDashDGEnergyQry, "select");
		$objSmarty->assign('LastMonthDashDGEnergy', $LastMonthDashDGEnergy);	

		

/****************************************           This month DG Energy End ********************************************/
/****************************************           This month Solar Energy Start ********************************************/
if($ListPlatformMapSolarViewCount >= 1){

 $SelThisMonthDashSolarEnergyQry = "SELECT COALESCE(SUM(solar_ac_consuption_kwh),0) AS total_solar_energy,COALESCE(SUM(solar_ac_consuption_cost),0) AS total_solar_cost
    FROM $dailyTableSolar
    WHERE company_id = $comId
      AND branch_id = $branchId
      AND posted_date_time >= DATE_FORMAT(CURDATE(), '%Y-%m-01')
      AND posted_date_time < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01')"; 

		$ThisMonthDashSolarEnergy		= $this->ExecuteQuery($SelThisMonthDashSolarEnergyQry, "select");
		$objSmarty->assign('ThisMonthDashSolarEnergy', $ThisMonthDashSolarEnergy);	

		
}
/****************************************           This month Solar Energy End ********************************************/

/****************************************           Last month Solar Energy Start ********************************************/
if($ListPlatformMapSolarViewCount >= 1){

 $SelLastMonthDashSolarEnergyQry = "SELECT COALESCE(SUM(solar_ac_consuption_kwh),0) AS total_solar_energy,COALESCE(SUM(solar_ac_consuption_cost),0) AS total_solar_cost
    FROM $dailyTableSolar
    WHERE company_id = $comId
      AND branch_id = $branchId
      AND posted_date_time >= DATE_FORMAT(CURDATE() - INTERVAL 1 MONTH, '%Y-%m-01')
      AND posted_date_time < DATE_FORMAT(CURDATE(), '%Y-%m-01')";

		$LastMonthDashSolarEnergy		= $this->ExecuteQuery($SelLastMonthDashSolarEnergyQry, "select");
		$objSmarty->assign('LastMonthDashSolarEnergy', $LastMonthDashSolarEnergy);	
		
		
}

$totEnergy = $TodayDashTotalEnergy[0]['total_energy'];
$totTodayGridEnergy = $TodayDashGridEnergy[0]['total_energy'];
$totYestGridEnergy = $TodayDashGridEnergy[0]['yesterday_total_energy'];
$totTodayDGEnergy = $TodayDashDGEnergy[0]['dg_energy'];
$totTodaySolarEnergy = $TodayDashSolarEnergy[0]['total_solar_energy'];
$totThisMonthEnergy = $ThisMonthDashTotalEnergy[0]['total_energy'];
$totThisMonthGridEnergy = $ThisMonthDashGridEnergy[0]['total_energy'];
$totLastMonthGridEnergy = $LastMonthDashGridEnergy[0]['total_energy'];
$totThisMonthDGEnergy = $ThisMonthDashDGEnergy[0]['dg_energy'];
$totLastMonthDGEnergy = $LastMonthDashDGEnergy[0]['dg_energy'];
$totThisMonthSolarEnergy = $ThisMonthDashSolarEnergy[0]['total_solar_energy'];
$totLastMonthSolarEnergy = $LastMonthDashSolarEnergy[0]['total_solar_energy'];

// echo "This Month Energy - ".$totThisMonthEnergy."<br>";
// echo "This Month Grid - ".$totThisMonthGridEnergy."<br>";
// echo "This Month DG - ".$totThisMonthDGEnergy."<br>";
// echo "This Month Solar - ".$totThisMonthSolarEnergy; exit;

if ($totEnergy > 0) {
    $gridPercent  = round(($totTodayGridEnergy / $totEnergy) * 100, 2);
    $dgPercent    = round(($totTodayDGEnergy / $totEnergy) * 100, 2);
    $solarPercent = round(($totTodaySolarEnergy / $totEnergy) * 100, 2);
} else {
    $gridPercent  = 0;
    $dgPercent    = 0;
    $solarPercent = 0;
}
if ($totThisMonthEnergy > 0) {
    $thismonthgridPercent  = round(($totThisMonthGridEnergy / $totThisMonthEnergy) * 100, 2);
    $thismonthdgPercent    = round(($totThisMonthDGEnergy / $totThisMonthEnergy) * 100, 2);
    $thismonthsolarPercent = round(($totThisMonthSolarEnergy / $totThisMonthEnergy) * 100, 2);
} else {
    $thismonthgridPercent  = 0;
    $thismonthdgPercent    = 0;
    $thismonthsolarPercent = 0;
}
$objSmarty->assign('gridPercent', $gridPercent);	
$objSmarty->assign('dgPercent', $dgPercent);	
$objSmarty->assign('solarPercent', $solarPercent);	
$objSmarty->assign('thismonthgridPercent', $thismonthgridPercent);	
$objSmarty->assign('thismonthdgPercent', $thismonthdgPercent);	
$objSmarty->assign('thismonthsolarPercent', $thismonthsolarPercent);	
/****************************************           Last month Solar Energy End ********************************************/

/****************************************           Today Fresh Water Start ********************************************/

            $FlowPF = "Flow Meter";
			$flowSensorCode = "FT360-1";


		$SelFreshWaterPlatformQuery = 'SELECT segmentCode FROM arka_iot_platform WHERE segmentName="'.$FlowPF.'" AND status="1"';  
		$ListFreshWaterPlatformView = $this->ExecuteQuery($SelFreshWaterPlatformQuery, 'select');

		$freshWaterSegCode = $ListFreshWaterPlatformView[0]['segmentCode'];

		$SelfreshWaterPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$FlowPF.'" AND status="1"';  
		$ListFreshWaterPlatformView = $this->ExecuteQuery($SelfreshWaterPlatformQuery, 'select');
		$freshWaterSegCode = $ListFreshWaterPlatformView[0]['segmentCode'];
		$freshWaterSegId = $ListFreshWaterPlatformView[0]['slNo'];
		//echo $freshWaterSegCode."<br/>"; 
		//echo "Id".$freshWaterSegId."<br/>"; 


		 $SelPlatformMapFreshWaterQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE segmentCode="'.$freshWaterSegId.'" AND companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';   
		 $ListPlatformMapFreshWaterView = $this->ExecuteQuery($SelPlatformMapFreshWaterQuery, 'select');
		 $ListPlatformMapFreshWaterViewCount = $this->ExecuteQuery($SelPlatformMapFreshWaterQuery, 'numrows');
		 $objSmarty->assign('freshWaterPlatformCount', $ListPlatformMapFreshWaterViewCount);


		$dailyTableFreshWater = $comCode."_".$branchCode."_".$freshWaterSegCode."_cron_daily";



		
		  $SelTodayDashFreshWaterQry = "SELECT ROUND(SUM(flow)) AS totalizer
    FROM TPL_AMBT_8_FT360_1
    WHERE company_id = $comId
      AND branch_id = $branchId
      AND DATE(posted_date_time)=DATE(NOW()) AND  MONTH(posted_date_time)=MONTH(NOW()) AND YEAR(posted_date_time)=YEAR(NOW())";  

		$TodayDashFreshWater		= $this->ExecuteQuery($SelTodayDashFreshWaterQry, "select");
		$objSmarty->assign('TodayDashFreshWater', $TodayDashFreshWater);

/****************************************           Today Fresh Water End ********************************************/
/****************************************   Today Distilled Water Starts ********************************************/

    $distilledWaterSegCode = $ListFreshWaterPlatformView[0]['segmentCode'];
    $dailyTableDistilledWater = $comCode."_".$branchCode."_".$distilledWaterSegCode."_cron_daily";

		  $SelTodayDashDistilledWaterQry = "SELECT ROUND(SUM(flow)) AS totalizer
    FROM TPL_AMBT_9_FT360_2
    WHERE company_id = $comId
      AND branch_id = $branchId
      AND DATE(posted_date_time)=DATE(NOW()) AND  MONTH(posted_date_time)=MONTH(NOW()) AND YEAR(posted_date_time)=YEAR(NOW())";  

		$TodayDashDistilledWater		= $this->ExecuteQuery($SelTodayDashDistilledWaterQry, "select");
		$objSmarty->assign('TodayDashDistilledWater', $TodayDashDistilledWater);

/****************************************   Today Distilled Water End ********************************************/

/****************************************   Today Outdoor Temperature Start ********************************************/
 
        
		$OutdoorSensor = "OAT-1";


		  $SelOutdoorTempPlatformQuery = 'SELECT slNo,segmentCode FROM arka_iot_platform WHERE segmentName="'.$TempPF.'" AND status="1"'; 
		$ListOutdoorTempPlatformView = $this->ExecuteQuery($SelOutdoorTempPlatformQuery, 'select');

		$outdoorTempSegCode = $ListOutdoorTempPlatformView[0]['segmentCode'];
		$tempSegId = $ListOutdoorTempPlatformView[0]['slNo'];

		  $SelPlatformMapTempQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE segmentCode="'.$tempSegId.'" AND companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';   
		 $ListPlatformMapTempView = $this->ExecuteQuery($SelPlatformMapTempQuery, 'select');
		 $ListPlatformMapTempViewCount = $this->ExecuteQuery($SelPlatformMapTempQuery, 'numrows');
		 $objSmarty->assign('temperaturePlatformCount', $ListPlatformMapTempViewCount);

		$dailyTableOutdoorTemp = $comCode."_".$branchCode."_".$outdoorTempSegCode."_cron_daily";

//echo $ListPlatformMapTempViewCount; exit;

if($ListPlatformMapTempViewCount >= 1){

$SelTodayOutdoorHumidityQry = "SELECT humidity,temperature_c AS current_temp FROM TPL_AMBT_11_OAT_1
    WHERE sensor_code='".$OutdoorSensor."' AND company_id = $comId
      AND branch_id = $branchId
      AND DATE(posted_date_time)=DATE(NOW()) AND  MONTH(posted_date_time)=MONTH(NOW()) AND YEAR(posted_date_time)=YEAR(NOW())";  
$TodayOutdoorHumidity		= $this->ExecuteQuery($SelTodayOutdoorHumidityQry, "select");
		$objSmarty->assign('TodayOutdoorHumidity', $TodayOutdoorHumidity);

		
		
		  $SelTodayOutdoorTempQry = "SELECT min_temperature_c AS min_temp,max_temperature_c AS max_temp,avg_temperature_c AS avg_temp
    FROM $dailyTableOutdoorTemp
    WHERE sensor_code='".$OutdoorSensor."' AND company_id = $comId
      AND branch_id = $branchId
      AND DATE(posted_date_time)=DATE(NOW()) AND  MONTH(posted_date_time)=MONTH(NOW()) AND YEAR(posted_date_time)=YEAR(NOW())";  

		$TodayOutdoorTemp		= $this->ExecuteQuery($SelTodayOutdoorTempQry, "select");
		$objSmarty->assign('TodayOutdoorTemp', $TodayOutdoorTemp);	

		}

/****************************************   Today Outdoor Temperature End ********************************************/

if($branchId =='0')
		{
		   $whrClass=' AND alert_log_master.company_id="'.$comId.'"';
		}else
		{
		   $whrClass=' AND alert_log_master.company_id="'.$comId.'" AND alert_log_master.branch_id="'.$branchId.'"';
		
		}
			 $selIncidentLogDash = 'SELECT alert_log_master.*,arka_sensor_master.sensorName FROM `alert_log_master`,arka_sensor_master WHERE alert_log_master.sensor_code=arka_sensor_master.sensorCode'.$whrClass.' ORDER BY recorded_date_time DESC'; 
			$incidentListDash		= $this->ExecuteQuery($selIncidentLogDash, "select");
			$incidentListDashCount		= $this->ExecuteQuery($selIncidentLogDash, "numrows");
			$objSmarty->assign('incidentListDash', $incidentListDash);
			$objSmarty->assign('incidentListDashCount', $incidentListDashCount);

			}


}

 /*************************Dashboard Piechart Function Starts*************************************/
	    function DashMultiBarChart()
	  {
	  
global $objSmarty;
		$cdd = date('d');
		$cmon = date('m');
	    $lmon = date('m', strtotime('-1 month'));
		$cyr = date('Y');
		$lyr = date('Y')-1;
		
	
		
		    $ld = date('t',strtotime('last month'));
			$ldc=$cyr.'-'.$lmon.'-01';
			$ldl=$cyr.'-'.$lmon.'-'.$ld;
			$ldc=date("Y-n-j", strtotime("first day of previous month"));
            $ldl=date("Y-n-j", strtotime("last day of previous month"));
	
			
			$ld1 = date('t');
		    $cdc=$cyr.'-'.$cmon.'-01';
			$cdl=$cyr.'-'.$cmon.'-'.$ld1;
			
			$cd=$cyr.'-'.$cmon.'-'.$cdd;
			
			  if($_GET['companyId'] <> '')
{
	$comId = base64_decode($_GET['companyId']);
}	
else
{
	$comId = $_SESSION['CustomerId'];
}
if($_GET['branchId'] <> '')
{
$branchId = base64_decode($_GET['branchId']);
}	
else
{
$branchId = $_SESSION['branch_id'];
}
	
	 $colors2 =array("#C2272D", "#F8931F", "#FFFF01", "#009245", "#0193D9", "#0C04ED", 

"#612F90","#F8DC70", "#EA7A2C", "#32A6F4", "#EB34F9", "#12896E", "#0EF1C1" , "#6F6653", "#F60720" , 

"#5A0E7E" ,"#2337D1" ,"#DAF7A6", "#33FFE6","#33C1FF","#DA33FF", "#EA99B0", "#6D7C78", "#FAE7AC", 

"#F5A399");


        $SelCompanyQuery = 'SELECT companyCode FROM arka_company_master WHERE slNo="'.$comId.'" AND status="1"';  
		$SelCompanyQueryView = $this->ExecuteQuery($SelCompanyQuery, 'select');
		$comCode = $SelCompanyQueryView[0]['companyCode'];

		$SelBranchQuery = 'SELECT branch_id FROM arka_branch_master WHERE sl_no="'.$branchId.'" AND record_status="1"';  
		$SelBranchQueryView = $this->ExecuteQuery($SelBranchQuery, 'select');
		$branchCode = $SelBranchQueryView[0]['branch_id'];
		//echo "Company Code".$comCode."<br>";
		//echo "Branch Code".$branchCode."<br>"; 
		



		   $SelPlatformMapQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';  
			$ListPlatformMapView = $this->ExecuteQuery($SelPlatformMapQuery, 'select');

			$energyPF = "Energy Meter";

			$SelEnergyPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$energyPF.'" AND status="1"';  
		$ListEnergyPlatformView = $this->ExecuteQuery($SelEnergyPlatformQuery, 'select');

		$energySegCode = $ListEnergyPlatformView[0]['segmentCode'];
		$energySegId = $ListEnergyPlatformView[0]['slNo'];
		$objSmarty->assign('energySegId', $energySegId);	
		
		$dailyTableEB = $comCode."_".$branchCode."_".$energySegCode."_cron_daily";

		  $selDailyTableQry='SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE "'.$dailyTableEB.'"';   
			// echo'<br/>';
			  $selDailyTableQryExe		= $this->ExecuteQuery($selDailyTableQry, "select");
			  $selDailyTableQryExeCount		= $this->ExecuteQuery($selDailyTableQry, "numrows");
			  //echo $selDailyTableQryExeCount;
			  $dailyTableName = $selDailyTableQryExe[0]['TABLE_NAME'];
			  //$selTableQryExeCount = $selTableQryExe[0]['TOTALNUMBEROFTABLES'];
			  if($selDailyTableQryExeCount <= 0){

			  //echo"am in if"; exit;

			  }else{

//echo"am in else";

	$SelQuery1 = "SELECT
    sensor_code,
    COALESCE(SUM(consuption_kwh) + SUM(dg_consuption_kwh),0) AS skwh,
    COALESCE(SUM(consuption_cost) + SUM(dg_consuption_cost),0) AS scost
FROM $dailyTableEB
WHERE feeder_type='Main Meter'
  AND company_id = $comId
  AND branch_id = $branchId
  AND posted_date_time >= DATE_FORMAT(CURDATE(), '%Y-%m-01')
  AND posted_date_time < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01')
GROUP BY sensor_code";
  //echo $SelQuery1; exit;

  $SelQuery2 = "SELECT
    sensor_code,
    COALESCE(SUM(consuption_kwh) + SUM(dg_consuption_kwh),0) AS skwh,
    COALESCE(SUM(consuption_cost) + SUM(dg_consuption_cost),0) AS scost
FROM $dailyTableEB
WHERE feeder_type='Main Meter'
  AND company_id = $comId
  AND branch_id = $branchId
  AND posted_date_time >= DATE_FORMAT(CURDATE() - INTERVAL 1 MONTH, '%Y-%m-01')
  AND posted_date_time < DATE_FORMAT(CURDATE(), '%Y-%m-01')
GROUP BY sensor_code";
  //echo $SelQuery1; exit;



  //$SelQuery1	= 'SELECT SUM(consuption_kwh+dg_consuption_kwh) AS skwh,SUM(consuption_cost+dg_consuption_cost) AS scost,MONTHNAME(`recorded_date`) AS rec_month,company_id,branch_id,sensor_code FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND feeder_type="Main Meter" AND recorded_date BETWEEN "'.$ldc.'" AND "'.$ldl.'" GROUP BY sensor_code'; 

 //$SelQuery2	= 'SELECT SUM(consuption_kwh+dg_consuption_kwh) AS skwh,SUM(consuption_cost+dg_consuption_cost) AS scost,MONTHNAME(`recorded_date`) AS rec_month,company_id,branch_id,sensor_code FROM `cron_monthly_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND feeder_type="Main Meter" AND recorded_date BETWEEN "'.$cdc.'" AND "'.$cdl.'" GROUP BY sensor_code';

$SelQuery3	= 'SELECT SUM(consuption_kwh+dg_consuption_kwh) AS skwh,SUM(consuption_cost+dg_consuption_cost) AS scost,MONTHNAME(`recorded_date`) AS rec_month,company_id,branch_id,sensor_code FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND feeder_type="Main Meter" AND recorded_date BETWEEN "'.$cd.'" AND "'.$cd.'" GROUP BY sensor_code';


	  $graphMasterlist1 = $this->ExecuteQuery($SelQuery1,"select");
	  $objSmarty->assign('graphMasterlist1', $graphMasterlist1);
	  $test1 = array_values($graphMasterlist1);
	  $loopArray1 ='';
      $countItemWiseCurMonSalQty1 = count($graphMasterlist1);
	  
	  
	  $graphMasterlist2 = $this->ExecuteQuery($SelQuery2,"select");
	  $objSmarty->assign('graphMasterlist2', $graphMasterlist2);
	  $test2 = array_values($graphMasterlist2);
	  $loopArray2 ='';
      $countItemWiseCurMonSalQty2 = count($graphMasterlist2);
	  
	  $graphMasterlist3 = $this->ExecuteQuery($SelQuery3,"select");
	  $objSmarty->assign('graphMasterlist3', $graphMasterlist3);
	  $test3 = array_values($graphMasterlist3);
	  $loopArray3 ='';
      $countItemWiseCurMonSalQty3 = count($graphMasterlist3);


for($k1=0; $k1<$countItemWiseCurMonSalQty1; $k1++)
{
$SelQuery = 'SELECT * FROM  `arka_sensor_master` WHERE sensorCode="'.$test1[$k1][sensor_code].'" AND isActive="1" AND status="1"';  
			$ListView = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListView', $ListView);


if($k1==0){
	$loopArray1 .= '{"sensorcode":"'.$ListView[0][sensorName].'","kwh":"'.$test1[$k1][skwh].'","cost":"'.$test1[$k1][scost].'","color":"'.$colors2[$k1].'"}';
	}
	else
	{
	$loopArray1 .= ',{"sensorcode":"'.$ListView[0][sensorName].'","kwh":"'.$test1[$k1][skwh].'","cost":"'.$test1[$k1][scost].'","color":"'.$colors2[$k1].'"}';
	}
}

for($k2=0; $k2<$countItemWiseCurMonSalQty2; $k2++)
{
$SelQuery = 'SELECT * FROM  `arka_sensor_master` WHERE sensorCode="'.$test2[$k2][sensor_code].'" AND isActive="1" AND status="1"';  
			$ListView = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListView', $ListView);


if($k2==0){
	$loopArray2 .= '{"sensorcode":"'.$ListView[0][sensorName].'","kwh":"'.$test2[$k2][skwh].'","cost":"'.$test2[$k2][scost].'","color":"'.$colors2[$k2].'"}';
	}
	else
	{
	$loopArray2 .= ',{"sensorcode":"'.$ListView[0][sensorName].'","kwh":"'.$test2[$k2][skwh].'","cost":"'.$test2[$k2][scost].'","color":"'.$colors2[$k2].'"}';
	}
}

for($k3=0; $k3<$countItemWiseCurMonSalQty3; $k3++)
{
$SelQuery = 'SELECT * FROM  `arka_sensor_master` WHERE sensorCode="'.$test3[$k3][sensor_code].'" AND isActive="1" AND status="1"';  
			$ListView = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListView', $ListView);


if($k3==0){
	$loopArray3 .= '{"sensorcode":"'.$ListView[0][sensorName].'","kwh":"'.$test3[$k3][skwh].'","cost":"'.$test3[$k3][scost].'","color":"'.$colors2[$k3].'"}';
	}
	else
	{
	$loopArray3 .= ',{"sensorcode":"'.$ListView[0][sensorName].'","kwh":"'.$test3[$k3][skwh].'","cost":"'.$test3[$k3][scost].'","color":"'.$colors2[$k3].'"}';
	}
}

//echo $loopArray1; 
$getCurMonSal1 ="[".$loopArray1."]";	
$objSmarty->assign('getCurMonQut1Dash', $getCurMonSal1);


$getCurMonSal2 ="[".$loopArray2."]";	
$objSmarty->assign('getLastMonQut2Dash', $getCurMonSal2);


$getCurMonSal3 ="[".$loopArray3."]";	
$objSmarty->assign('getCurMonQut3', $getCurMonSal3);

			  }

	  }
	  /*******************Dashboard Piechart Function Ends*****************************************/

/********************* Current Month Daily GetMultiLineGraph Branch Functions starts **********************/
	  function DashCurrMonthDailygraph()
	  {
	  
global $objSmarty;
			$cm = date('m');
		$cmon = date('m');//echo $cmon;echo "<br>";
	    $lmon = date('m', strtotime('-5 month'));//echo $lmon;echo "<br>";
			$pyr = date('Y')-1;
			$cyr = date('Y');
			$nyr = date('Y')+1;
			if($cm >= '06')
			{
			$sd=$cyr.'-'.$lmon.'-01';
			$ed=$cyr.'-'.$cmon.'-31';
			}
			else
			{
		    $sd=$pyr.'-'.$lmon.'-01';
			$ed=$cyr.'-'.$cmon.'-31';
			}
			//echo $sd;echo $ed; exit;
			  if($_GET['companyId'] <> '')
{
	$comId = base64_decode($_GET['companyId']);
}	
else
{
	$comId = $_SESSION['CustomerId'];
}
if($_GET['branchId'] <> '')
{
$branchId = base64_decode($_GET['branchId']);
}	
else
{
$branchId = $_SESSION['branch_id'];
}
if($_GET['sensorCode'] <> '')
{
$sensorCode = base64_decode($_GET['sensorCode']);
$wherCls = ' AND sensor_code="'.$sensorCode.'" ';
}	
else
{
$wherCls = ' AND (feeder_type="Main Meter" OR feeder_type="Overall Main Meter")';

}

	
	 $colors2 =array("#C2272D", "#F8931F", "#FFFF01", "#009245", "#0193D9", "#0C04ED", 

"#612F90","#F8DC70", "#EA7A2C", "#32A6F4", "#EB34F9", "#12896E", "#0EF1C1" , "#6F6653", "#F60720" , 

"#5A0E7E" ,"#2337D1" ,"#DAF7A6", "#33FFE6","#33C1FF","#DA33FF", "#EA99B0", "#6D7C78", "#FAE7AC", 

"#F5A399");

        $SelCompanyQuery = 'SELECT companyCode FROM arka_company_master WHERE slNo="'.$comId.'" AND status="1"';  
		$SelCompanyQueryView = $this->ExecuteQuery($SelCompanyQuery, 'select');
		$comCode = $SelCompanyQueryView[0]['companyCode'];

		$SelBranchQuery = 'SELECT branch_id FROM arka_branch_master WHERE sl_no="'.$branchId.'" AND record_status="1"';  
		$SelBranchQueryView = $this->ExecuteQuery($SelBranchQuery, 'select');
		$branchCode = $SelBranchQueryView[0]['branch_id'];
		//echo "Company Code".$comCode."<br>";
		//echo "Branch Code".$branchCode."<br>"; 
		



		   $SelPlatformMapQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';  
			$ListPlatformMapView = $this->ExecuteQuery($SelPlatformMapQuery, 'select');

			$energyPF = "Energy Meter";

			$SelEnergyPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$energyPF.'" AND status="1"';  
		$ListEnergyPlatformView = $this->ExecuteQuery($SelEnergyPlatformQuery, 'select');

		$energySegCode = $ListEnergyPlatformView[0]['segmentCode'];
		$energySegId = $ListEnergyPlatformView[0]['slNo'];
		$objSmarty->assign('energySegId', $energySegId);	
		
		$dailyTableEB = $comCode."_".$branchCode."_".$energySegCode."_cron_daily";
    //echo $dailyTableEB; exit;
	  $selDailyTableQry='SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE "'.$dailyTableEB.'"';   
			// echo'<br/>';
			  $selDailyTableQryExe		= $this->ExecuteQuery($selDailyTableQry, "select");
			  $selDailyTableQryExeCount		= $this->ExecuteQuery($selDailyTableQry, "numrows");
			  //echo $selDailyTableQryExeCount;
			  $dailyTableName = $selDailyTableQryExe[0]['TABLE_NAME'];
			  //$selTableQryExeCount = $selTableQryExe[0]['TOTALNUMBEROFTABLES'];
			  if($selDailyTableQryExeCount <= 0){

			  //echo"am in if"; exit;

			  }else{

//echo"am in else";
 
   $SelQuery1= 'SELECT * FROM (SELECT SUM(consuption_kwh+dg_consuption_kwh) AS skwh,SUM(consuption_cost+dg_consuption_cost) AS scost,DATE_FORMAT(`recorded_date`, "%d-%M-%Y") AS rec_month,company_id,branch_id,recorded_date,sensor_code FROM '.$dailyTableEB.' WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND recorded_date BETWEEN "'.$sd.'" AND "'.$ed.'" '.$wherCls.' GROUP BY `recorded_date` ORDER BY recorded_date DESC LIMIT 0,30) AS selqery ORDER BY recorded_date ASC';  
  

	  $graphMasterlist = $this->ExecuteQuery($SelQuery1,"select");
	  $objSmarty->assign('graphMasterlist', $graphMasterlist);
	  $test2 = array_values($graphMasterlist);
	  $loopArray2 ='';
      $countItemWiseCurMonSalQty = count($graphMasterlist);

for($k2=0; $k2<$countItemWiseCurMonSalQty; $k2++)
{
if($k2==0){
	$loopArray2 .= '{"dateM":"'.$test2[$k2][rec_month].'","value":"'.$test2[$k2][skwh].'","value1":"'.$test2[$k2][scost].'","color":"'.$colors2[$k2].'"}';
	}
	else
	{
	$loopArray2 .= ',{"dateM":"'.$test2[$k2][rec_month].'","value":"'.$test2[$k2][skwh].'","value1":"'.$test2[$k2][scost].'","color":"'.$colors2[$k2].'"}';
	}
}

$getCurMonSalDaily ="[".$loopArray2."]";	
$objSmarty->assign('getCurMonSalDailyDash', $getCurMonSalDaily);

			  }

	  }


 /********************* DashMultilinegraph Functions starts **********************/
	  function DashMultilinegraph()
	  {
	  
global $objSmarty;
			$cm = date('m');
		$cmon = date('m');//echo $cmon;echo "<br>";
	    $lmon = date('m', strtotime('-5 month'));//echo $lmon;echo "<br>";
			$pyr = date('Y')-1;
			$cyr = date('Y');
			$nyr = date('Y')+1;
			if($cm >= '06')
			{
			$sd=$cyr.'-'.$lmon.'-01';
			$ed=$cyr.'-'.$cmon.'-31';
			}
			else
			{
		    $sd=$pyr.'-'.$lmon.'-01';
			$ed=$cyr.'-'.$cmon.'-31';
			}
			//echo $sd;echo $ed;
			  if($_GET['companyId'] <> '')
{
	$comId = base64_decode($_GET['companyId']);
}	
else
{
	$comId = $_SESSION['CustomerId'];
}
if($_GET['branchId'] <> '')
{
$branchId = base64_decode($_GET['branchId']);
}	
else
{
$branchId = $_SESSION['branch_id'];
}
	
	 $colors2 =array("#C2272D", "#F8931F", "#FFFF01", "#009245", "#0193D9", "#0C04ED", 

"#612F90","#F8DC70", "#EA7A2C", "#32A6F4", "#EB34F9", "#12896E", "#0EF1C1" , "#6F6653", "#F60720" , 

"#5A0E7E" ,"#2337D1" ,"#DAF7A6", "#33FFE6","#33C1FF","#DA33FF", "#EA99B0", "#6D7C78", "#FAE7AC", 

"#F5A399");

$SelCompanyQuery = 'SELECT companyCode FROM arka_company_master WHERE slNo="'.$comId.'" AND status="1"';  
		$SelCompanyQueryView = $this->ExecuteQuery($SelCompanyQuery, 'select');
		$comCode = $SelCompanyQueryView[0]['companyCode'];

		$SelBranchQuery = 'SELECT branch_id FROM arka_branch_master WHERE sl_no="'.$branchId.'" AND record_status="1"';  
		$SelBranchQueryView = $this->ExecuteQuery($SelBranchQuery, 'select');
		$branchCode = $SelBranchQueryView[0]['branch_id'];
		//echo "Company Code".$comCode."<br>";
		//echo "Branch Code".$branchCode."<br>"; 
		



		   $SelPlatformMapQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';  
			$ListPlatformMapView = $this->ExecuteQuery($SelPlatformMapQuery, 'select');

			$energyPF = "Energy Meter";

			$SelEnergyPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$energyPF.'" AND status="1"';  
		$ListEnergyPlatformView = $this->ExecuteQuery($SelEnergyPlatformQuery, 'select');

		$energySegCode = $ListEnergyPlatformView[0]['segmentCode'];
		$energySegId = $ListEnergyPlatformView[0]['slNo'];
		$objSmarty->assign('energySegId', $energySegId);	
		
		$dailyTableEB = $comCode."_".$branchCode."_".$energySegCode."_cron_daily";
    //echo $dailyTableEB; exit;

  $selDailyTableQry='SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE "'.$dailyTableEB.'"';   
			// echo'<br/>';
			  $selDailyTableQryExe		= $this->ExecuteQuery($selDailyTableQry, "select");
			  $selDailyTableQryExeCount		= $this->ExecuteQuery($selDailyTableQry, "numrows");
			  //echo $selDailyTableQryExeCount;
			  $dailyTableName = $selDailyTableQryExe[0]['TABLE_NAME'];
			  //$selTableQryExeCount = $selTableQryExe[0]['TOTALNUMBEROFTABLES'];
			  if($selDailyTableQryExeCount <= 0){

			  //echo"am in if"; exit;

			  }else{

//echo"am in else";

 $SelQuery1	= 'SELECT SUM(consuption_kwh+dg_consuption_kwh) AS skwh,SUM(consuption_cost+dg_consuption_cost) AS scost,MONTHNAME(`recorded_date`) AS rec_month,company_id,branch_id,recorded_date FROM '.$dailyTableEB.' WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND feeder_type="Main Meter" AND recorded_date BETWEEN "'.$sd.'" AND "'.$ed.'" GROUP BY MONTH(`recorded_date`) ORDER BY recorded_date ASC';


	  $graphMasterlist = $this->ExecuteQuery($SelQuery1,"select");
	  $objSmarty->assign('graphMasterlist', $graphMasterlist);
	  $test2 = array_values($graphMasterlist);
	  $loopArray2 ='';
      $countItemWiseCurMonSalQty = count($graphMasterlist);

for($k2=0; $k2<$countItemWiseCurMonSalQty; $k2++)
{
if($k2==0){
	$loopArray2 .= '{"month":"'.$test2[$k2][rec_month].'","value":"'.$test2[$k2][skwh].'","value1":"'.$test2[$k2][scost].'","color":"'.$colors2[$k2].'"}';
	}
	else
	{
	$loopArray2 .= ',{"month":"'.$test2[$k2][rec_month].'","value":"'.$test2[$k2][skwh].'","value1":"'.$test2[$k2][scost].'","color":"'.$colors2[$k2].'"}';
	}
}

$getCurMonSal ="[".$loopArray2."]";	
$objSmarty->assign('getCurMonQutDash', $getCurMonSal);

			  }

	  }
/********************* DashMultilinegraph Functions End **********************/

/********************* DashListDashboardEM Functions Start **********************/

	  function DashListDashboardEM()  
{
		global $objSmarty,$config,$nowDate;
				
		if($_GET['companyId'] <> '')
		{
		$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		$branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		$branchId = $_SESSION['branch_id'];
		}


		 $SelCompanyQuery = 'SELECT companyCode FROM arka_company_master WHERE slNo="'.$comId.'" AND status="1"';  
		$SelCompanyQueryView = $this->ExecuteQuery($SelCompanyQuery, 'select');
		$comCode = $SelCompanyQueryView[0]['companyCode'];

		$SelBranchQuery = 'SELECT branch_id FROM arka_branch_master WHERE sl_no="'.$branchId.'" AND record_status="1"';  
		$SelBranchQueryView = $this->ExecuteQuery($SelBranchQuery, 'select');
		$branchCode = $SelBranchQueryView[0]['branch_id'];
		//echo "Company Code".$comCode."<br>";
		//echo "Branch Code".$branchCode."<br>"; 

		  $SelPlatformMapQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';  
			$ListPlatformMapView = $this->ExecuteQuery($SelPlatformMapQuery, 'select');

			$energyPF = "Energy Meter";
		    $solarPF = "Solar Inverter";
			$TempPF = "Temperature";

/****************************************                Today Total Energy   Start  *********************************/
		$SelEnergyPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$energyPF.'" AND status="1"';  
		$ListEnergyPlatformView = $this->ExecuteQuery($SelEnergyPlatformQuery, 'select');

		$energySegCode = $ListEnergyPlatformView[0]['segmentCode'];
		$energySegId = $ListEnergyPlatformView[0]['slNo'];
		$objSmarty->assign('energySegId', $energySegId);	


		$SelSolarPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$solarPF.'" AND status="1"';  
		$ListSolarPlatformView = $this->ExecuteQuery($SelSolarPlatformQuery, 'select');
        $solarSegId = $ListSolarPlatformView[0]['slNo'];
		$solarSegCode = $ListSolarPlatformView[0]['segmentCode'];


		   $SelPlatformMapSolarQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE segmentCode="'.$solarSegId.'" AND companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';   
		 $ListPlatformMapSolarView = $this->ExecuteQuery($SelPlatformMapSolarQuery, 'select');
		 $ListPlatformMapSolarViewCount = $this->ExecuteQuery($SelPlatformMapSolarQuery, 'numrows');
		 $objSmarty->assign('solarPlatformCount', $ListPlatformMapSolarViewCount);

		 


		$dailyTableEB = $comCode."_".$branchCode."_".$energySegCode."_cron_daily";
		$dailyTableSolar = $comCode."_".$branchCode."_".$solarSegCode."_cron_daily";


	   $dailyTable = "TPL_AMBT_E1001_cron_daily";
       $monthlyTable = "TPL_AMBT_E1001_cron_monthly";
       $hourlyTable = "TPL_AMBT_E1001_cron_hourly_".$monthShortCode."_".$yearShortCode;

	   $selDailyTableQry='SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE "'.$dailyTableEB.'"';   
			// echo'<br/>';
			  $selDailyTableQryExe		= $this->ExecuteQuery($selDailyTableQry, "select");
			  $selDailyTableQryExeCount		= $this->ExecuteQuery($selDailyTableQry, "numrows");
			  //echo $selDailyTableQryExeCount;
			  $dailyTableName = $selDailyTableQryExe[0]['TABLE_NAME'];
			  //$selTableQryExeCount = $selTableQryExe[0]['TOTALNUMBEROFTABLES'];
			  if($selDailyTableQryExeCount <= 0){

			  //echo"am in if"; exit;

			  }else{

//echo"am in else";

	       
		 if($ListPlatformMapSolarViewCount >= 1){
		
		$SelQuery = "
SELECT 
    SUM($dailyTableEB.consuption_kwh) AS TOTAL_KWH,
    SUM($dailyTableEB.consuption_cost) AS cost,
    SUM($dailyTableEB.dg_consuption_kwh) AS dg_TOTAL_KWH,
    SUM($dailyTableEB.dg_consuption_cost) AS dg_cost,
	$dailyTableEB.sensor_code,
	$dailyTableEB.gateway_code,

    (
        SELECT COALESCE(SUM(solar_ac_consuption_kwh),0)
        FROM $dailyTableSolar
        WHERE company_id = $comId
          AND branch_id = $branchId
          AND posted_date_time >= CURDATE()
          AND posted_date_time < CURDATE() + INTERVAL 1 DAY
    ) AS solar_TOTAL_KWH,

    (
        SELECT COALESCE(SUM(solar_ac_consuption_cost),0)
        FROM $dailyTableSolar
        WHERE company_id = $comId
          AND branch_id = $branchId
          AND posted_date_time >= CURDATE()
          AND posted_date_time < CURDATE() + INTERVAL 1 DAY
    ) AS solar_cost,

    $dailyTableEB.sensor_code,
	$dailyTableEB.location_code,
    arka_sensor_master.*,
    arka_sensor_master.sensorName AS feeder_name,
    (arka_sensor_master.kw_max_value / 5) AS KW_INT,
    arka_gateway_master.place_of_installation,
    TIMESTAMPDIFF(SECOND, MAX($dailyTableEB.posted_date_time), NOW()) AS secs

FROM $dailyTableEB

INNER JOIN arka_sensor_master
    ON $dailyTableEB.sensor_code = arka_sensor_master.sensorCode

INNER JOIN arka_gateway_master
    ON arka_sensor_master.gateway_id = arka_gateway_master.gateway_id

WHERE $dailyTableEB.feeder_type = 'Main Meter'
    AND arka_sensor_master.feeder_type = 'Main Meter'
    AND $dailyTableEB.company_id = $comId
    AND $dailyTableEB.branch_id = $branchId
    AND $dailyTableEB.company_id = arka_gateway_master.company_id
    AND $dailyTableEB.branch_id = arka_gateway_master.branch_id
    AND $dailyTableEB.company_id = arka_sensor_master.company_id
    AND $dailyTableEB.branch_id = arka_sensor_master.branch_id
    AND $dailyTableEB.posted_date_time >= CURDATE()
    AND $dailyTableEB.posted_date_time < CURDATE() + INTERVAL 1 DAY

GROUP BY $dailyTableEB.sensor_code
";
}else{

$SelQuery = "
SELECT 
    SUM($dailyTableEB.consuption_kwh) AS TOTAL_KWH,
    SUM($dailyTableEB.consuption_cost) AS cost,
    SUM($dailyTableEB.dg_consuption_kwh) AS dg_TOTAL_KWH,
    SUM($dailyTableEB.dg_consuption_cost) AS dg_cost,
    $dailyTableEB.sensor_code,
	$dailyTableEB.gateway_code,
    arka_sensor_master.*,
    arka_sensor_master.sensorName AS feeder_name,
    (arka_sensor_master.kw_max_value / 5) AS KW_INT,
    arka_gateway_master.place_of_installation,
    TIMESTAMPDIFF(SECOND, MAX($dailyTableEB.posted_date_time), NOW()) AS secs
FROM $dailyTableEB
INNER JOIN arka_sensor_master
    ON $dailyTableEB.sensor_code = arka_sensor_master.sensorCode
INNER JOIN arka_gateway_master
    ON arka_sensor_master.gateway_id = arka_gateway_master.gateway_id 
WHERE $dailyTableEB.feeder_type = 'Main Meter'
    AND arka_sensor_master.feeder_type = 'Main Meter'
    AND $dailyTableEB.company_id = $comId
    AND $dailyTableEB.branch_id = $branchId
	AND $dailyTableEB.company_id = arka_gateway_master.company_id
	AND $dailyTableEB.branch_id = arka_gateway_master.branch_id
	AND $dailyTableEB.company_id = arka_sensor_master.company_id
	AND $dailyTableEB.branch_id = arka_sensor_master.branch_id
    AND $dailyTableEB.posted_date_time >= CURDATE()
    AND $dailyTableEB.posted_date_time < CURDATE() + INTERVAL 1 DAY
GROUP BY $dailyTableEB.sensor_code
";


}


//echo $SelQuery; exit;

	       $MeterList= $this->ExecuteQuery($SelQuery, "select");//print_r($MeterList);
	       $objSmarty->assign('MeterListDash', $MeterList);	

		   foreach($MeterList as $matDetail){
	$sensorLocationCode = $matDetail['location_code'];
	$sensorCode = $matDetail['sensor_code'];
	$sensorCodeTable = str_replace("-","_",$sensorCode);
	$locationCodeTable = $sensorLocationCode.'_'.$sensorCodeTable;

	//echo $locationCodeTable; exit;
	}
	       if($locationCodeTable !=''){
	     $SelQuery = 'SELECT * FROM '.$locationCodeTable.' ORDER BY posted_date_time DESC LIMIT 0,1 ';  
	       $SpecificTableDate= $this->ExecuteQuery($SelQuery, "select");//print_r($SpecificTableDate);
	       $objSmarty->assign('SpecificTableDate', $SpecificTableDate);	
		   }

	       
	  	/*echo"<br><br> selQryS: "; echo */    
		$selQryS = 'SELECT * FROM `arka_sensor_master` WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND (arka_sensor_master.feeder_type="Sub Meter" OR arka_sensor_master.feeder_type="Sub Sub Meter" ) GROUP BY sensorCode';
		
	//	echo $selQryS; exit;
	    $selQryS		= $this->ExecuteQuery($selQryS, "select");
	    $objSmarty->assign('selQryS', $selQryS);

			  }
}	

/********************* DashListDashboardEM Functions End **********************/
function DashListGateway(){
			global $objSmarty,$config,$nowDate;
			$tbl = $config['DBPrefix'];

			if($_GET['companyId'] <> '')
		{
		$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
		$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
		$branchId = base64_decode($_GET['branchId']);
		}	
		else
		{
		$branchId = $_SESSION['branch_id'];
		}


			//$selQry='SELECT arka_gateway_master.place_of_installation, gateway_ping_log_view.gateway_code,gateway_ping_log_view.gateway_date_time FROM arka_gateway_master,gateway_ping_log_view WHERE arka_gateway_master.gateway_id=gateway_ping_log_view.gateway_code ORDER BY arka_gateway_master.place_of_installation ';


	  $selQry = 'SELECT 
    agm.place_of_installation,
    gplv.gateway_code,
    gplv.gateway_date_time,

    CASE 
        WHEN gplv.gateway_date_time >= NOW() - INTERVAL 120 SECOND THEN 1 
        ELSE 0 
    END AS gateway_status,

    CASE
        WHEN TIMESTAMPDIFF(SECOND, gplv.gateway_date_time, NOW()) < 60
            THEN CONCAT(TIMESTAMPDIFF(SECOND, gplv.gateway_date_time, NOW()), " Sec Ago")
        WHEN TIMESTAMPDIFF(MINUTE, gplv.gateway_date_time, NOW()) < 60
            THEN CONCAT(TIMESTAMPDIFF(MINUTE, gplv.gateway_date_time, NOW()), " Min Ago")
        WHEN TIMESTAMPDIFF(HOUR, gplv.gateway_date_time, NOW()) < 24
            THEN CONCAT(
                TIMESTAMPDIFF(HOUR, gplv.gateway_date_time, NOW()),
                " Hr ",
                MOD(TIMESTAMPDIFF(MINUTE, gplv.gateway_date_time, NOW()), 60),
                " Min Ago"
            )
        ELSE
            CONCAT(
                TIMESTAMPDIFF(DAY, gplv.gateway_date_time, NOW()),
                " Day Ago"
            )
    END AS last_communication

FROM arka_gateway_master agm
JOIN gateway_ping_log_view gplv 
    ON agm.gateway_id = gplv.gateway_code
WHERE agm.company_id = '.$comId.'
  AND agm.branch_id = '.$branchId.'
ORDER BY agm.place_of_installation'; 
			$selQryExe		= $this->ExecuteQuery($selQry, "select");
		    $objSmarty->assign('gatewayListDash', $selQryExe);


			
		}

		 /********************* Get Specific FeederList Functions Starts **************************/
	function GetDashCostKwhSingle()  
	{
		global $objSmarty,$config,$nowDate;
			$tbl = $config['DBPrefix'];
	
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}	
		$gatewayCode=base64_decode($_GET['gatewayCode']);
		$sensorCode=base64_decode($_GET['sensorCode']);

		$ConfigDBName = $config['DBName'];
		//echo $ConfigDBName; exit;
		$SelCompanyQuery = 'SELECT companyCode FROM arka_company_master WHERE slNo="'.$comId.'" AND status="1"';  
		$SelCompanyQueryView = $this->ExecuteQuery($SelCompanyQuery, 'select');
		$comCode = $SelCompanyQueryView[0]['companyCode'];

		$SelBranchQuery = 'SELECT branch_id FROM arka_branch_master WHERE sl_no="'.$branchId.'" AND record_status="1"';  
		$SelBranchQueryView = $this->ExecuteQuery($SelBranchQuery, 'select');
		$branchCode = $SelBranchQueryView[0]['branch_id'];
		//echo "Company Code".$comCode."<br>";
		//echo "Branch Code".$branchCode."<br>";

		
	    $SelPlatformMapQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';  
			$ListPlatformMapView = $this->ExecuteQuery($SelPlatformMapQuery, 'select');

			$energyPF = "Energy Meter";
		    $solarPF = "Solar Inverter";
			$TempPF = "Temperature";

/****************************************                Today Total Energy   Start ********************************************/
		$SelEnergyPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$energyPF.'" AND status="1"';  
		$ListEnergyPlatformView = $this->ExecuteQuery($SelEnergyPlatformQuery, 'select');

		$energySegCode = $ListEnergyPlatformView[0]['segmentCode'];
		$energySegId = $ListEnergyPlatformView[0]['slNo'];
		$objSmarty->assign('energySegId', $energySegId);	


		$SelSolarPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$solarPF.'" AND status="1"';  
		$ListSolarPlatformView = $this->ExecuteQuery($SelSolarPlatformQuery, 'select');
        $solarSegId = $ListSolarPlatformView[0]['slNo'];
		$solarSegCode = $ListSolarPlatformView[0]['segmentCode'];


		   $SelPlatformMapSolarQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE segmentCode="'.$solarSegId.'" AND companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';   
		 $ListPlatformMapSolarView = $this->ExecuteQuery($SelPlatformMapSolarQuery, 'select');
		 $ListPlatformMapSolarViewCount = $this->ExecuteQuery($SelPlatformMapSolarQuery, 'numrows');
		 $objSmarty->assign('solarPlatformCount', $ListPlatformMapSolarViewCount);

		 


		$dailyTableEB = $comCode."_".$branchCode."_".$energySegCode."_cron_daily";
		$dailyTableSolar = $comCode."_".$branchCode."_".$solarSegCode."_cron_daily";

//echo $dailyTableEB; exit;

			  $ldc=date("Y", strtotime("first day of previous month"));
        $ldl=date("n", strtotime("last day of previous month"));
		
		  $selQry = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost FROM '.$dailyTableEB.' WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND  DATE(recorded_date)=DATE('.$nowDate.') AND MONTH(recorded_date)=MONTH('.$nowDate.') AND YEAR(recorded_date)=YEAR('.$nowDate.') AND gateway_code="'.$gatewayCode.'" AND `sensor_code`="'.$sensorCode.'"';  
		$todayCostKWH		= $this->ExecuteQuery($selQry, "select");
		$objSmarty->assign('todayCostKWH', $todayCostKWH);
		
		 
		  $selQryYes = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost FROM '.$dailyTableEB.' WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND DATE(recorded_date)=DATE(DATE_SUB('.$nowDate.', INTERVAL 1 DAY)) AND MONTH(recorded_date)=MONTH(DATE_SUB('.$nowDate.', INTERVAL 1 DAY)) AND YEAR(recorded_date)=YEAR(DATE_SUB('.$nowDate.', INTERVAL 1 DAY)) AND gateway_code="'.$gatewayCode.'" AND `sensor_code`="'.$sensorCode.'"'; 
		  $yesterdayCostKWH		= $this->ExecuteQuery($selQryYes, "select");
		  $objSmarty->assign('yesterdayCostKWH', $yesterdayCostKWH);
		
	
		$selQry2 = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost FROM '.$dailyTableEB.' WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND `gateway_code`="'.$gatewayCode.'" AND `sensor_code`="'.$sensorCode.'" AND Month(recorded_date)=MONTH('.$nowDate.') AND YEAR(recorded_date)=YEAR('.$nowDate.')';
		$monthCostKWH		= $this->ExecuteQuery($selQry2, "select");
		$objSmarty->assign('monthCostKWH', $monthCostKWH);
	
		$selQry3 = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost FROM '.$dailyTableEB.' WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND `gateway_code`="'.$gatewayCode.'" AND `sensor_code`="'.$sensorCode.'" AND MONTH(recorded_date)="'.$ldl.'" AND YEAR(recorded_date)="'.$ldc.'" ';
		$LastMonthCostKWH		= $this->ExecuteQuery($selQry3, "select");
		$objSmarty->assign('LastMonthCostKWH', $LastMonthCostKWH);




		 

		$ListFeederDet		= $this->ExecuteQuery($SelFeederDet, "select");
		$ListFeederDet2		= $this->ExecuteQuery($SelFeederDet, "numrows");
		$objSmarty->assign('ListFeederDet', $ListFeederDet);
		$objSmarty->assign('ListFeederDet2', $ListFeederDet2);	
		
	   
	}	
	/********************* Get Specific FeederList Functions Ends **************************/
		
 /********************* Today Hourly data starts **********************/
	  function DashHourlyDatagraph()
	  {
	  
global $objSmarty;
			//echo $sd;echo $ed;
			  if($_GET['companyId'] <> '')
{
	$comId = base64_decode($_GET['companyId']);
}	
else
{
	$comId = $_SESSION['CustomerId'];
}
if($_GET['branchId'] <> '')
{
$branchId = base64_decode($_GET['branchId']);
}	
else
{
$branchId = $_SESSION['branch_id'];
}
if($_GET['sensorCode'] <> '')
{
$sensorCode = base64_decode($_GET['sensorCode']);
$wherCls = ' AND sensor_code="'.$sensorCode.'" ';
}	
else
{
$wherCls = '';

}

	
	 $colors2 =array("#C2272D", "#F8931F", "#FFFF01", "#009245", "#0193D9", "#0C04ED", 

"#612F90","#F8DC70", "#EA7A2C", "#32A6F4", "#EB34F9", "#12896E", "#0EF1C1" , "#6F6653", "#F60720" , 

"#5A0E7E" ,"#2337D1" ,"#DAF7A6", "#33FFE6","#33C1FF","#DA33FF", "#EA99B0", "#6D7C78", "#FAE7AC", 

"#F5A399");


 $SelCompanyQuery = 'SELECT companyCode FROM arka_company_master WHERE slNo="'.$comId.'" AND status="1"';  
		$SelCompanyQueryView = $this->ExecuteQuery($SelCompanyQuery, 'select');
		$comCode = $SelCompanyQueryView[0]['companyCode'];

		$SelBranchQuery = 'SELECT branch_id FROM arka_branch_master WHERE sl_no="'.$branchId.'" AND record_status="1"';  
		$SelBranchQueryView = $this->ExecuteQuery($SelBranchQuery, 'select');
		$branchCode = $SelBranchQueryView[0]['branch_id'];
		//echo "Company Code".$comCode."<br>";
		//echo "Branch Code".$branchCode."<br>"; 

		  $SelPlatformMapQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';  
			$ListPlatformMapView = $this->ExecuteQuery($SelPlatformMapQuery, 'select');

			$energyPF = "Energy Meter";
		    $solarPF = "Solar Inverter";
			$TempPF = "Temperature";

/****************************************                Today Total Energy   Start ********************************************/
		$SelEnergyPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$energyPF.'" AND status="1"';  
		$ListEnergyPlatformView = $this->ExecuteQuery($SelEnergyPlatformQuery, 'select');

		$energySegCode = $ListEnergyPlatformView[0]['segmentCode'];
		$energySegId = $ListEnergyPlatformView[0]['slNo'];
		$objSmarty->assign('energySegId', $energySegId);	


		$SelSolarPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$solarPF.'" AND status="1"';  
		$ListSolarPlatformView = $this->ExecuteQuery($SelSolarPlatformQuery, 'select');
        $solarSegId = $ListSolarPlatformView[0]['slNo'];
		$solarSegCode = $ListSolarPlatformView[0]['segmentCode'];


		   $SelPlatformMapSolarQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE segmentCode="'.$solarSegId.'" AND companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';   
		 $ListPlatformMapSolarView = $this->ExecuteQuery($SelPlatformMapSolarQuery, 'select');
		 $ListPlatformMapSolarViewCount = $this->ExecuteQuery($SelPlatformMapSolarQuery, 'numrows');
		 $objSmarty->assign('solarPlatformCount', $ListPlatformMapSolarViewCount);

		$SelMonthQuerys = "SELECT DATE_FORMAT(CURDATE(), '%b') AS month_short_code, YEAR(CURDATE()) AS current_year";
		$SelMonthData = $this->ExecuteQuery($SelMonthQuerys, 'select');
		$monthShortCode = $SelMonthData[0]['month_short_code']; // JAN, FEB...
		$yearShortCode = $SelMonthData[0]['current_year'];

//echo "Month Short Code".$monthShortCode; exit;

		$dailyTableEB = $comCode."_".$branchCode."_".$energySegCode."_cron_daily";
		$dailyTableSolar = $comCode."_".$branchCode."_".$solarSegCode."_cron_daily";
		$hourlyTable = $comCode."_".$branchCode."_".$energySegCode."_cron_hourly_".$monthShortCode."_".$yearShortCode;



   $SelQuery1= 'SELECT * FROM (SELECT SUM(consuption_kwh+dg_consuption_kwh) AS skwh,SUM(consuption_cost+dg_consuption_cost) AS scost,DATE_FORMAT(`recorded_date`, "%d-%M-%Y") AS rec_month,TIME_FORMAT(CONCAT(hour_data,":00:00"),"%I %p") AS hour_data,company_id,branch_id,recorded_date,sensor_code,slNo FROM '.$hourlyTable.' WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND (feeder_type="Main Meter" OR feeder_type="Overall Main Meter")  AND recorded_date =DATE(NOW())'.$wherCls.' GROUP BY hour_data ORDER BY slNo ) AS selqery ORDER BY slNo ASC'; 
 

	  $graphMasterlist = $this->ExecuteQuery($SelQuery1,"select");
	  $objSmarty->assign('graphMasterlist', $graphMasterlist);
	  $test2 = array_values($graphMasterlist);
	  $loopArray2 ='';
      $countItemWiseCurMonSalQty = count($graphMasterlist);

for($k2=0; $k2<$countItemWiseCurMonSalQty; $k2++)
{
if($k2==0){
	$loopArray2 .= '{"dateM":"'.$test2[$k2][hour_data].'","value":"'.$test2[$k2][skwh].'","value1":"'.$test2[$k2][scost].'","color":"'.$colors2[$k2].'"}';
	}
	else
	{
	$loopArray2 .= ',{"dateM":"'.$test2[$k2][hour_data].'","value":"'.$test2[$k2][skwh].'","value1":"'.$test2[$k2][scost].'","color":"'.$colors2[$k2].'"}';
	}
}

$getHourlyData ="[".$loopArray2."]";	
$objSmarty->assign('getHourlyDataDash', $getHourlyData);

	  }
	  /**********************Today Hourly data ***************************************************/
/********************* GetBarGraph Functions Starts **************************/
	function DashGetBarGraph(){
		global $objSmarty,$config,$nowDate;
	if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}
		$sensorCode = base64_decode($_GET['sensorCode']);
		$gatewayCode = base64_decode($_GET['gatewayCode']);

		$ConfigDBName = $config['DBName'];
		//echo $ConfigDBName; exit;
		$SelCompanyQuery = 'SELECT companyCode FROM arka_company_master WHERE slNo="'.$comId.'" AND status="1"';  
		$SelCompanyQueryView = $this->ExecuteQuery($SelCompanyQuery, 'select');
		$comCode = $SelCompanyQueryView[0]['companyCode'];

		$SelBranchQuery = 'SELECT branch_id FROM arka_branch_master WHERE sl_no="'.$branchId.'" AND record_status="1"';  
		$SelBranchQueryView = $this->ExecuteQuery($SelBranchQuery, 'select');
		$branchCode = $SelBranchQueryView[0]['branch_id'];
		//echo "Company Code".$comCode."<br>";
		//echo "Branch Code".$branchCode."<br>";

		
	    $SelPlatformMapQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';  
			$ListPlatformMapView = $this->ExecuteQuery($SelPlatformMapQuery, 'select');

			$energyPF = "Energy Meter";
		    $solarPF = "Solar Inverter";
			$TempPF = "Temperature";

/****************************************                Today Total Energy   Start ********************************************/
		$SelEnergyPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$energyPF.'" AND status="1"';  
		$ListEnergyPlatformView = $this->ExecuteQuery($SelEnergyPlatformQuery, 'select');

		$energySegCode = $ListEnergyPlatformView[0]['segmentCode'];
		$energySegId = $ListEnergyPlatformView[0]['slNo'];
		$objSmarty->assign('energySegId', $energySegId);	


		$SelSolarPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$solarPF.'" AND status="1"';  
		$ListSolarPlatformView = $this->ExecuteQuery($SelSolarPlatformQuery, 'select');
        $solarSegId = $ListSolarPlatformView[0]['slNo'];
		$solarSegCode = $ListSolarPlatformView[0]['segmentCode'];


		   $SelPlatformMapSolarQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE segmentCode="'.$solarSegId.'" AND companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';   
		 $ListPlatformMapSolarView = $this->ExecuteQuery($SelPlatformMapSolarQuery, 'select');
		 $ListPlatformMapSolarViewCount = $this->ExecuteQuery($SelPlatformMapSolarQuery, 'numrows');
		 $objSmarty->assign('solarPlatformCount', $ListPlatformMapSolarViewCount);

		 


		$dailyTableEB = $comCode."_".$branchCode."_".$energySegCode."_cron_daily";
		$dailyTableSolar = $comCode."_".$branchCode."_".$solarSegCode."_cron_daily";

//echo $dailyTableEB; exit;

		
		 $selBarGraph='SELECT DATE_FORMAT(recorded_date,"%b") AS month_data,SUM(consuption_cost) AS consuption_cost,SUM(dg_consuption_cost) AS dg_consuption_cost FROM '.$dailyTableEB.' WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND gateway_code="'.$gatewayCode.'" AND sensor_code="'.$sensorCode.'" AND DATE(recorded_date)>= DATE(DATE_SUB('.$nowDate.',INTERVAL 12 MONTH)) AND DATE(recorded_date)<= DATE('.$nowDate.')  GROUP BY YEAR(recorded_date), MONTH(recorded_date) ORDER BY YEAR(recorded_date), MONTH(recorded_date) ASC'; 
		$ExeBarGraph		= $this->ExecuteQuery($selBarGraph, "select");
		$ExeBarGraphCount		= $this->ExecuteQuery($selBarGraph, "numrows");
		
	$objParm='';
	$objParmDg='';
	foreach($ExeBarGraph as $key=>$value)
	{
		$objParm .='{"month": "'.$ExeBarGraph[$key]["month_data"].'","cost": '.$ExeBarGraph[$key]["consuption_cost"].',"dgcost": '.$ExeBarGraph[$key]["dg_consuption_cost"].'},';
		$objParmDg .='{
		"month": "'.$ExeBarGraph[$key]["month_data"].'",
		"cost": '.$ExeBarGraph[$key]["dg_consuption_cost"].'
		},';
	}
	
		$BarGraphData="[".rtrim($objParm, ",")."]";
		$dgBarGraphData="[".rtrim($objParmDg, ",")."]";
		$objSmarty->assign('BarGraphDataDash',$BarGraphData);
		$objSmarty->assign('dgBarGraphDataDash',$dgBarGraphData);
	
		

		 $selLineGraph='SELECT DATE_FORMAT(recorded_date,"%b") AS month_data, SUM(consuption_kwh) AS consuption_kwh,SUM(dg_consuption_kwh) AS dg_consuption_kwh FROM '.$dailyTableEB.' WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND gateway_code="'.$gatewayCode.'" AND sensor_code="'.$sensorCode.'"  AND DATE(recorded_date)>= DATE(DATE_SUB('.$nowDate.',INTERVAL 12 MONTH)) AND DATE(recorded_date)<= DATE('.$nowDate.')  GROUP BY YEAR(recorded_date), MONTH(recorded_date) ORDER BY YEAR(recorded_date), MONTH(recorded_date) ASC'; 
		$ExeLineGraph		= $this->ExecuteQuery($selLineGraph, "select");
		$ExeLineGraphCount		= $this->ExecuteQuery($selLineGraph, "numrows");
		
	$objParm2='';
	$objParm2Dg='';
	foreach($ExeLineGraph as $key2=>$value2)
	{
		$objParm2 .='{"month": "'.$ExeLineGraph[$key2]["month_data"].'","EB": '.$ExeLineGraph[$key2]["consuption_kwh"].',"DG": '.$ExeLineGraph[$key2]["dg_consuption_kwh"].'},';
		$objParm2Dg .='{
		"month": "'.$ExeLineGraph[$key2]["month_data"].'",
		"kwh": '.$ExeLineGraph[$key2]["dg_consuption_kwh"].'
		},';
	}
	
	$objGraph2='{
	"title": "EB Kwh",
	"balloonText": "[[title]]: <b>[[value]]</b>",
	"bullet": "round",
	"bulletSize": 10,
	"bulletBorderColor": "#ffffff",
	"bulletBorderAlpha": 1,
	"bulletBorderThickness": 2,
	"type": "smoothedLine",
	"valueField": "EB"
	},{
	"title": "DG Kwh",
	"balloonText": "[[title]]: <b>[[value]]</b>",
	"bullet": "round",
	"bulletSize": 10,
	"bulletBorderColor": "#ffffff",
	"bulletBorderAlpha": 1,
	"bulletBorderThickness": 2,
	"type": "smoothedLine",
	"valueField": "DG"
	}';
	
		$LineGraphDataDash="[".rtrim($objParm2, ",")."]";
		$LineGraphData2="[".rtrim($objGraph2, ",")."]";
		$dgLineGraphData="[".rtrim($objParm2Dg, ",")."]";
		$objSmarty->assign('LineGraphDataDash',$LineGraphDataDash);
		$objSmarty->assign('LineGraphData2',$LineGraphData2);
		$objSmarty->assign('dgLineGraphData',$dgLineGraphData);
	}
    /********************* GetBarGraph Functions Ends **************************/

	 /********************* GetHourlyLog Functions Starts **************************/
	function DashGetHourlyLog()
	{
		global $objSmarty,$config,$nowDate;

		if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}


		$gatewayCode = base64_decode($_GET['gatewayCode']);
		$sensorCode = base64_decode($_GET['sensorCode']);
		$nowDate= "NOW()";

		$ConfigDBName = $config['DBName'];
		//echo $ConfigDBName; exit;
		 $SelCompanyQuery = 'SELECT companyCode FROM arka_company_master WHERE slNo="'.$comId.'" AND status="1"';  
		$SelCompanyQueryView = $this->ExecuteQuery($SelCompanyQuery, 'select');
		$comCode = $SelCompanyQueryView[0]['companyCode'];

		 $SelBranchQuery = 'SELECT branch_id FROM arka_branch_master WHERE sl_no="'.$branchId.'" AND record_status="1"';  
		$SelBranchQueryView = $this->ExecuteQuery($SelBranchQuery, 'select');
		$branchCode = $SelBranchQueryView[0]['branch_id'];
		//echo "Company Code".$comCode."<br>";
		//echo "Branch Code".$branchCode."<br>"; 

		  $SelPlatformMapQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';  
			$ListPlatformMapView = $this->ExecuteQuery($SelPlatformMapQuery, 'select');

			$energyPF = "Energy Meter";
		    $solarPF = "Solar Inverter";
			$TempPF = "Temperature";

/****************************************                Today Total Energy   Start ********************************************/
		$SelEnergyPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$energyPF.'" AND status="1"';  
		$ListEnergyPlatformView = $this->ExecuteQuery($SelEnergyPlatformQuery, 'select');

		$energySegCode = $ListEnergyPlatformView[0]['segmentCode'];
		$energySegId = $ListEnergyPlatformView[0]['slNo'];
		$objSmarty->assign('energySegId', $energySegId);	


		$SelSolarPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$solarPF.'" AND status="1"';  
		$ListSolarPlatformView = $this->ExecuteQuery($SelSolarPlatformQuery, 'select');
        $solarSegId = $ListSolarPlatformView[0]['slNo'];
		$solarSegCode = $ListSolarPlatformView[0]['segmentCode'];


		   $SelPlatformMapSolarQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE segmentCode="'.$solarSegId.'" AND companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';   
		 $ListPlatformMapSolarView = $this->ExecuteQuery($SelPlatformMapSolarQuery, 'select');
		 $ListPlatformMapSolarViewCount = $this->ExecuteQuery($SelPlatformMapSolarQuery, 'numrows');
		 $objSmarty->assign('solarPlatformCount', $ListPlatformMapSolarViewCount);

		$SelMonthQuerys = "SELECT DATE_FORMAT(CURDATE(), '%b') AS month_short_code, YEAR(CURDATE()) AS current_year";
		$SelMonthData = $this->ExecuteQuery($SelMonthQuerys, 'select');
		$monthShortCode = $SelMonthData[0]['month_short_code']; // JAN, FEB...
		$yearShortCode = $SelMonthData[0]['current_year'];

//echo "Month Short Code".$monthShortCode; exit;

		$dailyTableEB = $comCode."_".$branchCode."_".$energySegCode."_cron_daily";
		$dailyTableSolar = $comCode."_".$branchCode."_".$solarSegCode."_cron_daily";
		$hourlyTable = $comCode."_".$branchCode."_".$energySegCode."_cron_hourly_".$monthShortCode."_".$yearShortCode;
//echo $hourlyTable ; exit;
	if(isset($_POST['date1']))
	{  // "post";
		$date1 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		$query_rs1 =  "SELECT $hourlyTable.*,TIME_FORMAT(CONCAT($hourlyTable.hour_data,':00:00'),'%I %p') AS hour_datas,FORMAT($hourlyTable.start_kwh, 2) AS startCumKwh, FORMAT($hourlyTable.end_kwh, 2) AS endCumKwh, FORMAT($hourlyTable.consuption_kwh, 2) AS conKwh, FORMAT($hourlyTable.consuption_cost, 2) AS cos FROM $hourlyTable WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND recorded_date = '".$date1."' ORDER BY recorded_date DESC";
	}
	else
	{
		$query_rs1 = "SELECT $hourlyTable.*,TIME_FORMAT(CONCAT($hourlyTable.hour_data,':00:00'),'%I %p') AS hour_datas,FORMAT($hourlyTable.start_kwh, 2) AS startCumKwh, FORMAT($hourlyTable.end_kwh, 2) AS endCumKwh, FORMAT($hourlyTable.consuption_kwh, 2) AS conKwh, FORMAT($hourlyTable.consuption_cost, 2) AS cos FROM $hourlyTable WHERE  gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."'  AND YEAR(recorded_date) = YEAR(".$nowDate.") AND  MONTH(recorded_date) = MONTH(".$nowDate.") AND recorded_date = DATE(".$nowDate.")  ORDER BY recorded_date DESC";
	}
	//echo $query_rs1; exit;
		$GetDLogDash = $this->ExecuteQuery($query_rs1, "select");
		$objSmarty->assign('GetDLogDash', $GetDLogDash);
	}
      /********************* GetHourlyLog Functions Ends **************************/

	  /********************* GetDailyLog Functions Starts **************************/
	function DashGetDailyLog()
	{
		global $objSmarty,$config,$nowDate;
		if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}


		$gatewayCode = base64_decode($_GET['gatewayCode']);
		$sensorCode = base64_decode($_GET['sensorCode']);
		$nowDate= "NOW()";

		$ConfigDBName = $config['DBName'];
		//echo $ConfigDBName; exit;
		 $SelCompanyQuery = 'SELECT companyCode FROM arka_company_master WHERE slNo="'.$comId.'" AND status="1"';  
		$SelCompanyQueryView = $this->ExecuteQuery($SelCompanyQuery, 'select');
		$comCode = $SelCompanyQueryView[0]['companyCode'];

		 $SelBranchQuery = 'SELECT branch_id FROM arka_branch_master WHERE sl_no="'.$branchId.'" AND record_status="1"';  
		$SelBranchQueryView = $this->ExecuteQuery($SelBranchQuery, 'select');
		$branchCode = $SelBranchQueryView[0]['branch_id'];
		//echo "Company Code".$comCode."<br>";
		//echo "Branch Code".$branchCode."<br>"; 

		  $SelPlatformMapQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';  
			$ListPlatformMapView = $this->ExecuteQuery($SelPlatformMapQuery, 'select');

			$energyPF = "Energy Meter";
		    $solarPF = "Solar Inverter";
			$TempPF = "Temperature";

/****************************************                Today Total Energy   Start ********************************************/
		$SelEnergyPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$energyPF.'" AND status="1"';  
		$ListEnergyPlatformView = $this->ExecuteQuery($SelEnergyPlatformQuery, 'select');

		$energySegCode = $ListEnergyPlatformView[0]['segmentCode'];
		$energySegId = $ListEnergyPlatformView[0]['slNo'];
		$objSmarty->assign('energySegId', $energySegId);	


		$SelSolarPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$solarPF.'" AND status="1"';  
		$ListSolarPlatformView = $this->ExecuteQuery($SelSolarPlatformQuery, 'select');
        $solarSegId = $ListSolarPlatformView[0]['slNo'];
		$solarSegCode = $ListSolarPlatformView[0]['segmentCode'];


		   $SelPlatformMapSolarQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE segmentCode="'.$solarSegId.'" AND companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';   
		 $ListPlatformMapSolarView = $this->ExecuteQuery($SelPlatformMapSolarQuery, 'select');
		 $ListPlatformMapSolarViewCount = $this->ExecuteQuery($SelPlatformMapSolarQuery, 'numrows');
		 $objSmarty->assign('solarPlatformCount', $ListPlatformMapSolarViewCount);

		$SelMonthQuerys = "SELECT DATE_FORMAT(CURDATE(), '%b') AS month_short_code, YEAR(CURDATE()) AS current_year";
		$SelMonthData = $this->ExecuteQuery($SelMonthQuerys, 'select');
		$monthShortCode = $SelMonthData[0]['month_short_code']; // JAN, FEB...
		$yearShortCode = $SelMonthData[0]['current_year'];

//echo "Month Short Code".$monthShortCode; exit;

		$dailyTableEB = $comCode."_".$branchCode."_".$energySegCode."_cron_daily";
		$dailyTableSolar = $comCode."_".$branchCode."_".$solarSegCode."_cron_daily";
		$hourlyTable = $comCode."_".$branchCode."_".$energySegCode."_cron_hourly_".$monthShortCode."_".$yearShortCode;
//echo $hourlyTable ; exit;

	if(isset($_POST['date1']) && isset($_POST['date2']))
	{
		$date1 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		$date2 = date("Y-m-d",strtotime(trim(addslashes($_POST['date2']))));
		$query_rs1 =  "SELECT $dailyTableEB.*,FORMAT($dailyTableEB.start_kwh, 2) AS startCumKwh, FORMAT($dailyTableEB.end_kwh, 2) AS endCumKwh, FORMAT($dailyTableEB.consuption_kwh, 2) AS conKwh, FORMAT($dailyTableEB.consuption_cost, 2) AS cos FROM $dailyTableEB WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND recorded_date < ".$nowDate." AND  (DATE(recorded_date) BETWEEN '".$date1."' AND '".$date2."') ORDER BY recorded_date DESC";
	}
	else
	{
		$query_rs1 = "SELECT $dailyTableEB.*,FORMAT($dailyTableEB.start_kwh, 2) AS startCumKwh, FORMAT($dailyTableEB.end_kwh, 2) AS endCumKwh, FORMAT($dailyTableEB.consuption_kwh, 2) AS conKwh, FORMAT($dailyTableEB.consuption_cost, 2) AS cos FROM $dailyTableEB WHERE  gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."'  AND YEAR(recorded_date) = YEAR(".$nowDate.") AND  MONTH(recorded_date) = MONTH(".$nowDate.") AND recorded_date < DATE(".$nowDate.")  ORDER BY recorded_date DESC";
	}
//	echo $query_rs1;
		$GetDLogDash = $this->ExecuteQuery($query_rs1, "select");
		$objSmarty->assign('GetDLogDash', $GetDLogDash);
	}
      /********************* GetDailyLog Functions Ends **************************/
	  /********************* GetIcdLog Functions Starts **************************/
	function DashGetIcdLog()
	{
		global $objSmarty,$config,$nowDate;

		if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}
	
		if(function_exists('date_default_timezone_set')) {
		date_default_timezone_set("Asia/Kolkata");
		}
		$gatewayCode = base64_decode($_GET['gatewayCode']);
		$sensorCode = base64_decode($_GET['sensorCode']);
		$senMod =  explode("-",base64_decode($_GET['sensorCode'])); 
        //echo $sensorCode; 

		$sensorCodeTable = str_replace("-","_",$sensorCode); 

		$ConfigDBName = $config['DBName'];
		//echo $ConfigDBName; exit;
		 $SelCompanyQuery = 'SELECT companyCode FROM arka_company_master WHERE slNo="'.$comId.'" AND status="1"';  
		$SelCompanyQueryView = $this->ExecuteQuery($SelCompanyQuery, 'select');
		$comCode = $SelCompanyQueryView[0]['companyCode'];

		 $SelBranchQuery = 'SELECT branch_id FROM arka_branch_master WHERE sl_no="'.$branchId.'" AND record_status="1"';  
		$SelBranchQueryView = $this->ExecuteQuery($SelBranchQuery, 'select');
		$branchCode = $SelBranchQueryView[0]['branch_id'];
		//echo "Company Code".$comCode."<br>";
		//echo "Branch Code".$branchCode."<br>"; 

		  $SelPlatformMapQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';  
			$ListPlatformMapView = $this->ExecuteQuery($SelPlatformMapQuery, 'select');

			$energyPF = "Energy Meter";
		    $solarPF = "Solar Inverter";
			$TempPF = "Temperature";

/****************************************                Today Total Energy   Start ********************************************/
		$SelEnergyPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$energyPF.'" AND status="1"';  
		$ListEnergyPlatformView = $this->ExecuteQuery($SelEnergyPlatformQuery, 'select');

		$energySegCode = $ListEnergyPlatformView[0]['segmentCode'];
		$energySegId = $ListEnergyPlatformView[0]['slNo'];
		$objSmarty->assign('energySegId', $energySegId);	


		$SelSolarPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$solarPF.'" AND status="1"';  
		$ListSolarPlatformView = $this->ExecuteQuery($SelSolarPlatformQuery, 'select');
        $solarSegId = $ListSolarPlatformView[0]['slNo'];
		$solarSegCode = $ListSolarPlatformView[0]['segmentCode'];


		   $SelPlatformMapSolarQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE segmentCode="'.$solarSegId.'" AND companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';   
		 $ListPlatformMapSolarView = $this->ExecuteQuery($SelPlatformMapSolarQuery, 'select');
		 $ListPlatformMapSolarViewCount = $this->ExecuteQuery($SelPlatformMapSolarQuery, 'numrows');
		 $objSmarty->assign('solarPlatformCount', $ListPlatformMapSolarViewCount);

		$SelMonthQuerys = "SELECT DATE_FORMAT(CURDATE(), '%b') AS month_short_code, YEAR(CURDATE()) AS current_year";
		$SelMonthData = $this->ExecuteQuery($SelMonthQuerys, 'select');
		$monthShortCode = $SelMonthData[0]['month_short_code']; // JAN, FEB...
		$yearShortCode = $SelMonthData[0]['current_year'];

//echo "Month Short Code".$monthShortCode; exit;

		$dailyTableEB = $comCode."_".$branchCode."_".$energySegCode."_cron_daily";
		$dailyTableSolar = $comCode."_".$branchCode."_".$solarSegCode."_cron_daily";
		$hourlyTable = $comCode."_".$branchCode."_".$energySegCode."_cron_hourly_".$monthShortCode."_".$yearShortCode;
//echo $hourlyTable ; exit;

//SELECT `sl_no`, `sensor_model_id`, `platform_type`, `data_type`, `data_length`, `priority`, `parameter_name`, `is_active`, `status`, `testVoltage` FROM `sensor_model_parameter_master` WHERE `sensor_model_id` = 12


  $selModelQry='SELECT sl_no,model_id FROM sensor_model_master WHERE model_id=(SELECT sensorModel FROM arka_sensor_master WHERE sensorCode="'.$sensorCode.'" AND company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1") AND status="1"';  
			// echo'<br/>';
			  $selModelQryExe		= $this->ExecuteQuery($selModelQry, "select");
              $senModelId = $selModelQryExe[0]["sl_no"];

			   $selModelParameterQry='SELECT parameter_name FROM sensor_model_parameter_master WHERE sensor_model_id="'.$senModelId.'" AND is_log_report="1" AND status="1"';  
			// echo'<br/>';
			  $selModelParameterQryExe		= $this->ExecuteQuery($selModelParameterQry, "select");
			  $objSmarty->assign('SensorModelPM', $selModelParameterQryExe);

//echo $sensorCodeTable; exit;
		     $selTableQry='SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE "'.$comCode.'_'.$branchCode.'\_%_'.$sensorCodeTable.'"';   
			// echo'<br/>';
			  $selTableQryExe		= $this->ExecuteQuery($selTableQry, "select");
			  $selTableQryExeCount		= $this->ExecuteQuery($selTableQry, "numrows");
			  //echo $selTableQryExeCount;
			  $sensorTableName = $selTableQryExe[0]['TABLE_NAME'];
			  //$selTableQryExeCount = $selTableQryExe[0]['TOTALNUMBEROFTABLES'];
			  if($selTableQryExeCount > 0){

				  $selOffQry='SELECT * FROM '.$ConfigDBName.'.'.$sensorTableName.' WHERE status ="1" AND sensor_code="'.$sensorCode.'" AND posted_date_time >=DATE_SUB(NOW(),INTERVAL 10 MINUTE) ORDER BY slNo DESC LIMIT 0,1';  
				
			  $selOffQryExe		= $this->ExecuteQuery($selOffQry, "select");
			  $selOffQryExeCount = $this->ExecuteQuery($selOffQry, "numrows");
              
			  if($selOffQryExeCount > 0){

			  $DBSensorTableName = $ConfigDBName.'.'.$sensorTableName;
	//echo $DBSensorTableName; exit;

  $query_column = 'SELECT (COLUMN_NAME) AS TcolumnName,
  COUNT(COLUMN_NAME) AS TotalColumns
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = '.'"'.$ConfigDBName.'"'.'
   AND TABLE_NAME = '.'"'.$sensorTableName.'"'.'
ORDER BY ORDINAL_POSITION';
  
 /*SELECT $DBSensorTableName.COLUMN_NAME FROM ".$DBSensorTableName." WHERE  gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' ORDER BY ORDINAL_POSITION";*/

//echo $query_column;exit;
       $GetTableColumn = $this->ExecuteQuery($query_column, "select");
		$objSmarty->assign('TableColumnList', $GetTableColumn);

	if(isset($_POST['date1']) && isset($_POST['date2']))
	{
		$date1 = date("Y-m-d 08:00:00",strtotime(trim(addslashes($_POST['date1']))));
		$date2 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		
		$date=date_create($date2);
		date_add($date,date_interval_create_from_date_string("1 days"));
		$date2=date_format($date,"Y-m-d 07:59:59");
			


		$query_rs1 =  "SELECT $DBSensorTableName.*, posted_date_time AS TM FROM ".$DBSensorTableName." WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND (posted_date_time BETWEEN '".$date1."' AND '".$date2."') ORDER BY TM DESC";
	}
	else
	{	
		$deliverytime = new DateTime(date('Y-m-d H:i:s'));
		$hour = $deliverytime->format('H');
		$hour=intval($hour);
		if ($hour >=0 && $hour <8) {
			$date=date_create(date('Y-m-d'));
			date_sub($date,date_interval_create_from_date_string("1 days"));
			$date1=date_format($date,"Y-m-d 08:00:00");
			$date2=date('Y-m-d 07:59:59');
			//echo"if";
		} else {
			
			$date1=date('Y-m-d 08:00:00');
			$date=date_create(date('Y-m-d'));
			date_add($date,date_interval_create_from_date_string("1 days"));
			$date2=date_format($date,"Y-m-d 07:59:59");
			//echo "from D".$date1;
			//echo "to D".$date2;
			//echo "else";
		}
	
		$query_rs1 = "SELECT $DBSensorTableName.*, posted_date_time AS TM FROM ".$DBSensorTableName." WHERE  gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND (posted_date_time BETWEEN '".$date1."' AND '".$date2."') ORDER BY TM DESC";

		

	}
	//echo $query_rs1;exit;
				

			  }else{

			  }

			  }else{

			  }


	
		$GetICDDash = $this->ExecuteQuery($query_rs1, "select");
		$objSmarty->assign('GetICDDash', $GetICDDash);
	}
     /********************* GetIcdLog Functions Ends **************************/

	 /********************* Get Specific MeterLogGraph Functions Ends **************************/
	  function DashGetSpecificMeterLogGraph()
	  {
		
		 global $objSmarty,$config,$nowDate;

		 if($_GET['companyId'] <> '')
	{
		$comId = base64_decode($_GET['companyId']);
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
	{
		$branchId = base64_decode($_GET['branchId']);
	}	
	else
	{
		$branchId = $_SESSION['branch_id'];
	}

		 if(function_exists('date_default_timezone_set')) {
			 date_default_timezone_set("Asia/Kolkata");
		 }
		 $pf='';
		 $gatewayCode = base64_decode($_GET['gatewayCode']);
		 $sensorCode = base64_decode($_GET['sensorCode']);

		 $sensorCodeTable = str_replace("-","_",$sensorCode); 

		$ConfigDBName = $config['DBName'];
		//echo $ConfigDBName; exit;
		 $SelCompanyQuery = 'SELECT companyCode FROM arka_company_master WHERE slNo="'.$comId.'" AND status="1"';  
		$SelCompanyQueryView = $this->ExecuteQuery($SelCompanyQuery, 'select');
		$comCode = $SelCompanyQueryView[0]['companyCode'];

		 $SelBranchQuery = 'SELECT branch_id FROM arka_branch_master WHERE sl_no="'.$branchId.'" AND record_status="1"';  
		$SelBranchQueryView = $this->ExecuteQuery($SelBranchQuery, 'select');
		$branchCode = $SelBranchQueryView[0]['branch_id'];
		//echo "Company Code".$comCode."<br>";
		//echo "Branch Code".$branchCode."<br>"; 

		  $SelPlatformMapQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';  
			$ListPlatformMapView = $this->ExecuteQuery($SelPlatformMapQuery, 'select');

			$energyPF = "Energy Meter";
		    $solarPF = "Solar Inverter";
			$TempPF = "Temperature";

/****************************************                Today Total Energy   Start ********************************************/
		$SelEnergyPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$energyPF.'" AND status="1"';  
		$ListEnergyPlatformView = $this->ExecuteQuery($SelEnergyPlatformQuery, 'select');

		$energySegCode = $ListEnergyPlatformView[0]['segmentCode'];
		$energySegId = $ListEnergyPlatformView[0]['slNo'];
		$objSmarty->assign('energySegId', $energySegId);	


		$SelSolarPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$solarPF.'" AND status="1"';  
		$ListSolarPlatformView = $this->ExecuteQuery($SelSolarPlatformQuery, 'select');
        $solarSegId = $ListSolarPlatformView[0]['slNo'];
		$solarSegCode = $ListSolarPlatformView[0]['segmentCode'];


		   $SelPlatformMapSolarQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE segmentCode="'.$solarSegId.'" AND companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';   
		 $ListPlatformMapSolarView = $this->ExecuteQuery($SelPlatformMapSolarQuery, 'select');
		 $ListPlatformMapSolarViewCount = $this->ExecuteQuery($SelPlatformMapSolarQuery, 'numrows');
		 $objSmarty->assign('solarPlatformCount', $ListPlatformMapSolarViewCount);

		$SelMonthQuerys = "SELECT DATE_FORMAT(CURDATE(), '%b') AS month_short_code, YEAR(CURDATE()) AS current_year";
		$SelMonthData = $this->ExecuteQuery($SelMonthQuerys, 'select');
		$monthShortCode = $SelMonthData[0]['month_short_code']; // JAN, FEB...
		$yearShortCode = $SelMonthData[0]['current_year'];

//echo "Month Short Code".$monthShortCode; exit;

		$dailyTableEB = $comCode."_".$branchCode."_".$energySegCode."_cron_daily";
		$dailyTableSolar = $comCode."_".$branchCode."_".$solarSegCode."_cron_daily";
		$hourlyTable = $comCode."_".$branchCode."_".$energySegCode."_cron_hourly_".$monthShortCode."_".$yearShortCode;
//echo $hourlyTable ; exit;



		 //$sensorCodeTable = str_replace("-","_",$sensorCode);

		 //SELECT `sl_no`, `sensor_model_id`, `platform_type`, `data_type`, `data_length`, `priority`, `parameter_name`, `is_active`, `status`, `testVoltage` FROM `sensor_model_parameter_master` WHERE `sensor_model_id` = 12


  $selModelQry='SELECT sl_no,model_id FROM sensor_model_master WHERE model_id=(SELECT sensorModel FROM arka_sensor_master WHERE sensorCode="'.$sensorCode.'" AND company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1") AND status="1"';  
			// echo'<br/>';
			  $selModelQryExe		= $this->ExecuteQuery($selModelQry, "select");
              $senModelId = $selModelQryExe[0]["sl_no"];

			   $selModelParameterQry='SELECT parameter_name FROM sensor_model_parameter_master WHERE sensor_model_id="'.$senModelId.'" AND is_log_report="1" AND status="1"';  
			// echo'<br/>';
			  $selModelParameterQryExe		= $this->ExecuteQuery($selModelParameterQry, "select");
			  $objSmarty->assign('SensorModelPM', $selModelParameterQryExe);

            //echo $sensorCodeTable; exit;
		      $selTableQry='SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE "'.$comCode.'_'.$branchCode.'\_%_'.$sensorCodeTable.'"';   
			// echo'<br/>';
			  $selTableQryExe		= $this->ExecuteQuery($selTableQry, "select");
			  $selTableQryExeCount		= $this->ExecuteQuery($selTableQry, "numrows");
			  //echo $selTableQryExeCount;
			  $sensorTableName = $selTableQryExe[0]['TABLE_NAME'];
			  //$selTableQryExeCount = $selTableQryExe[0]['TOTALNUMBEROFTABLES'];
			  if($selTableQryExeCount > 0){

				  $selOffQry='SELECT * FROM '.$ConfigDBName.'.'.$sensorTableName.' WHERE status ="1" AND sensor_code="'.$sensorCode.'" AND posted_date_time >=DATE_SUB(NOW(),INTERVAL 10 MINUTE) ORDER BY slNo DESC LIMIT 0,1';  
				
			  $selOffQryExe		= $this->ExecuteQuery($selOffQry, "select");
			  $selOffQryExeCount = $this->ExecuteQuery($selOffQry, "numrows");
              
			  if($selOffQryExeCount > 0){

			  $DBSensorTableName = $ConfigDBName.'.'.$sensorTableName;
	//echo $DBSensorTableName; exit;




		 if(isset($_POST['date1']))
		 {
			 $date1 = date("Y-m-d",strtotime(trim(addslashes($_POST['date1']))));
		 //	$date2 = date("Y-m-d 23:59:59",strtotime(trim(addslashes($_POST['date1']))));
	 
			 
			 $yaxis = $_POST['yAxis'];
		 //	echo $yaxis; exit;
			 if($yaxis== 'VOLTAGE' || $yaxis== 'CURRENT')
			 {
				 $yaxis_par="R_".$yaxis.",Y_".$yaxis.",B_".$yaxis;
				 $pf=0;
			 }
			 else if($yaxis== 'SUM_PF'){
				 $yaxis_par="TRUNCATE(IF(`SUM_PF` >= 1 AND `SUM_PF` < 2 , '-0.99', IF(`SUM_PF` >= 2 , '1', `SUM_PF`)),2) AS SUM_PF ";
				 $pf=1;
			 }
			 else
			 {
				 $yaxis_par =$yaxis;
				 $pf=2;
			 }
		 //	$query_rs1 =  "SELECT ".$yaxis_par.",posted_date_time AS TM FROM energy_data_master WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND (posted_date_time BETWEEN '".$date1."' AND '".$date2."') ORDER BY TM ASC";
				 $query_rs1 =  "SELECT ".$yaxis_par.",posted_date_time AS TM FROM ".$DBSensorTableName." WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND DATE(posted_date_time)='".$date1."' ORDER BY TM ASC";
		 }
		 else
		 {
			 $deliverytime = new DateTime(date('Y-m-d H:i:s'));
			 $hour = $deliverytime->format('H');
			 $hour=intval($hour);
	 
				 
				 $date1=date('Y-m-d 00:00:00');
				 $date2=date('Y-m-d 23:59:59');
			 //	$date=date_create(date('Y-m-d'));
				 
			 //	$date2=date_format($date,"Y-m-d 23:59:59");
	 
			 $yaxis_par="R_VOLTAGE,Y_VOLTAGE,B_VOLTAGE";
			 $query_rs1 = "SELECT ".$yaxis_par.",posted_date_time AS TM FROM ".$DBSensorTableName." WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND (posted_date_time BETWEEN '".$date1."' AND '".$date2."') ORDER BY TM ASC";
		 }
			 //echo $query_rs1; exit;
			 $GetTemp = $this->ExecuteQuery($query_rs1, "select");
			 $objSmarty->assign('GetTemp', $GetTemp);
		 if($pf!=1)
		 {
			 $splVar= explode(",",$yaxis_par);
		 }
		 else
		 {
			 $splVar=array("SUM_PF");
		 }
			 $arrData = array();
		 foreach ($GetTemp as $key => $value) 
		 {
			 $orgDate =$GetTemp[$key]['TM'];  
			 $GDate = date("d-M-Y h:i A", strtotime($orgDate));
		 if($splVar[1]!='')
		 {
			 array_push($arrData, array(
			 $splVar[0] => $GetTemp[$key][$splVar[0]],
			 $splVar[1] => $GetTemp[$key][$splVar[1]],
			 $splVar[2] => $GetTemp[$key][$splVar[2]],
			 "tm" => $GDate
			 ));
		 }
		 else
		 {
			 array_push($arrData, array(
			 $splVar[0] => $GetTemp[$key][$splVar[0]],
			 "tm" => $GDate
			 ));
		 }
		 }
			 $ChartDataDash = json_encode($arrData);
			 $objSmarty->assign('ChartDataDash', $ChartDataDash);

			  }
			 }
		 }
			 /********************* Get Specific MeterLogGraph Functions Ends **************************/

			 /***********************Sub Dashboard List*************************************************/
function DashGetSubDashboard()  {
			global $objSmarty,$config,$nowDate;
		
			if($_GET['companyId'] <> '')
			{
			$comId = base64_decode($_GET['companyId']);
			}	
			else
			{
			$comId = $_SESSION['CustomerId'];
			}
			if($_GET['branchId'] <> '')
			{
			$branchId = base64_decode($_GET['branchId']);
			}	
			else
			{
			$branchId = $_SESSION['branch_id'];
			}
			$parent_id=base64_decode($_GET['parent_id']);


			$ConfigDBName = $config['DBName'];
		//echo $ConfigDBName; exit;
		 $SelCompanyQuery = 'SELECT companyCode FROM arka_company_master WHERE slNo="'.$comId.'" AND status="1"';  
		$SelCompanyQueryView = $this->ExecuteQuery($SelCompanyQuery, 'select');
		$comCode = $SelCompanyQueryView[0]['companyCode'];

		 $SelBranchQuery = 'SELECT branch_id FROM arka_branch_master WHERE sl_no="'.$branchId.'" AND record_status="1"';  
		$SelBranchQueryView = $this->ExecuteQuery($SelBranchQuery, 'select');
		$branchCode = $SelBranchQueryView[0]['branch_id'];
		//echo "Company Code".$comCode."<br>";
		//echo "Branch Code".$branchCode."<br>"; 

		  $SelPlatformMapQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';  
			$ListPlatformMapView = $this->ExecuteQuery($SelPlatformMapQuery, 'select');

			$energyPF = "Energy Meter";
		    $solarPF = "Solar Inverter";
			$TempPF = "Temperature";

/****************************************                Today Total Energy   Start ********************************************/
		$SelEnergyPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$energyPF.'" AND status="1"';  
		$ListEnergyPlatformView = $this->ExecuteQuery($SelEnergyPlatformQuery, 'select');

		$energySegCode = $ListEnergyPlatformView[0]['segmentCode'];
		$energySegId = $ListEnergyPlatformView[0]['slNo'];
		$objSmarty->assign('energySegId', $energySegId);	


		$SelSolarPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$solarPF.'" AND status="1"';  
		$ListSolarPlatformView = $this->ExecuteQuery($SelSolarPlatformQuery, 'select');
        $solarSegId = $ListSolarPlatformView[0]['slNo'];
		$solarSegCode = $ListSolarPlatformView[0]['segmentCode'];


		   $SelPlatformMapSolarQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE segmentCode="'.$solarSegId.'" AND companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';   
		 $ListPlatformMapSolarView = $this->ExecuteQuery($SelPlatformMapSolarQuery, 'select');
		 $ListPlatformMapSolarViewCount = $this->ExecuteQuery($SelPlatformMapSolarQuery, 'numrows');
		 $objSmarty->assign('solarPlatformCount', $ListPlatformMapSolarViewCount);

		$SelMonthQuerys = "SELECT DATE_FORMAT(CURDATE(), '%b') AS month_short_code, YEAR(CURDATE()) AS current_year";
		$SelMonthData = $this->ExecuteQuery($SelMonthQuerys, 'select');
		$monthShortCode = $SelMonthData[0]['month_short_code']; // JAN, FEB...
		$yearShortCode = $SelMonthData[0]['current_year'];

//echo "Month Short Code".$monthShortCode; exit;

		$dailyTableEB = $comCode."_".$branchCode."_".$energySegCode."_cron_daily";
		$dailyTableSolar = $comCode."_".$branchCode."_".$solarSegCode."_cron_daily";
		$hourlyTable = $comCode."_".$branchCode."_".$energySegCode."_cron_hourly_".$monthShortCode."_".$yearShortCode;
//echo $hourlyTable ; exit;



		 //$sensorCodeTable = str_replace("-","_",$sensorCode);



 

             $senDashboard = 'SELECT * FROM arka_sensor_master WHERE slNo="'.$parent_id.'" AND status="1" AND isActive="1"';  
			$senDashboard		= $this->ExecuteQuery($senDashboard, "select");
			$objSmarty->assign('senDashboard', $senDashboard);


	/*echo"<br><br> selQryS: "; echo */    
		$selQrySub = 'SELECT * FROM `arka_sensor_master` WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND (arka_sensor_master.feeder_type="Sub Meter" OR arka_sensor_master.feeder_type="Sub Sub Meter" ) GROUP BY sensorCode';
		
	//	echo $selQryS; exit;
	    $selQrySub		= $this->ExecuteQuery($selQrySub, "select");
	    $objSmarty->assign('selQrySub', $selQrySub);

		
       $MeterList = array();
		foreach($selQrySub as $subDetail)
    {
	  $feederName = $subDetail['sensorName'];
	  $gatewayCode = $subDetail['gateway_id'];
      $sensorCode = $subDetail['sensorCode'];
	  $sensorCodeTable = str_replace("-","_",$sensorCode);

	  //echo $sensorCode."<br>";

	        $selModelQry='SELECT sl_no,model_id FROM sensor_model_master WHERE model_id=(SELECT sensorModel FROM arka_sensor_master WHERE sensorCode="'.$sensorCode.'" AND company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1") AND status="1"';  
			// echo'<br/>';
			  $selModelQryExe		= $this->ExecuteQuery($selModelQry, "select");
              $senModelId = $selModelQryExe[0]["sl_no"];
              //echo $senModelId;
			   $selModelParameterQry='SELECT parameter_name FROM sensor_model_parameter_master WHERE sensor_model_id="'.$senModelId.'" AND is_log_report="1" AND status="1"';  
			// echo'<br/>';
			  $selModelParameterQryExe		= $this->ExecuteQuery($selModelParameterQry, "select");
			  $objSmarty->assign('SensorModelPM', $selModelParameterQryExe);

            //echo $sensorCodeTable; exit;
		      $selTableQry='SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE "'.$comCode.'_'.$branchCode.'\_%_'.$sensorCodeTable.'"';   
			// echo'<br/>';
			  $selTableQryExe		= $this->ExecuteQuery($selTableQry, "select");
			  $selTableQryExeCount		= $this->ExecuteQuery($selTableQry, "numrows");
			  //echo $selTableQryExeCount;
			  $sensorTableName = $selTableQryExe[0]['TABLE_NAME'];
			  //$selTableQryExeCount = $selTableQryExe[0]['TOTALNUMBEROFTABLES'];
			  if($selTableQryExeCount > 0){

				  $selOffQry='SELECT * FROM '.$ConfigDBName.'.'.$sensorTableName.' WHERE status ="1" AND sensor_code="'.$sensorCode.'" AND posted_date_time >=DATE_SUB(NOW(),INTERVAL 10 MINUTE) ORDER BY slNo DESC LIMIT 0,1';  
				
			  $selOffQryExe		= $this->ExecuteQuery($selOffQry, "select");
			  $selOffQryExeCount = $this->ExecuteQuery($selOffQry, "numrows");
              
			  if($selOffQryExeCount > 0){

			  $DBSensorTableName = $ConfigDBName.'.'.$sensorTableName;
	//echo $DBSensorTableName; 

	  $SelSpecificQuery = 'SELECT
(
    SELECT posted_date_time
    FROM '.$DBSensorTableName.'
    WHERE status="1"
      AND sensor_code="'.$sensorCode.'"
    ORDER BY posted_date_time DESC
    LIMIT 1
) AS posted_date_time,TIMESTAMPDIFF(
    SECOND,
    (
        SELECT posted_date_time
        FROM '.$DBSensorTableName.'
        WHERE status="1"
          AND sensor_code="'.$sensorCode.'"
        ORDER BY posted_date_time DESC
        LIMIT 1
    ),
    NOW()
) AS secs,'.$dailyTableEB.'.sensor_code,'.$dailyTableEB.'.gateway_code,
SUM(consuption_kwh) AS TOTAL_KWH,
SUM(consuption_cost) AS cost,(arka_sensor_master.sensorName) AS feeder_name
FROM '.$dailyTableEB.',arka_sensor_master
WHERE '.$dailyTableEB.'.sensor_code="'.$sensorCode.'" AND '.$dailyTableEB.'.gateway_code="'.$gatewayCode.'" AND arka_sensor_master.sensorCode="'.$sensorCode.'"
AND DATE(recorded_date)=CURDATE()';  

	

			  }
 
   $result = $this->ExecuteQuery($SelSpecificQuery,"select");
			  }	 

    if(!empty($result))
    {
        $MeterList[] = $result[0];
    } 

	}
//echo $SelSpecificQuery;
 $objSmarty->assign('MeterList', $MeterList);
 

//echo $SelSpecificQuery;  exit;


 			  //$SelQuery = 'SELECT arka_sensor_master.*,(arka_sensor_master.kw_max_value/5) AS KW_INT,arka_sensor_master.sensorName AS feeder_name,TIMESTAMPDIFF(SECOND, posted_date_time, NOW()) AS secs,SUM('.$dailyTableEB.'.`consuption_kwh`) AS TOTAL_KWH ,SUM('.$dailyTableEB.'.`consuption_cost`) AS cost,arka_gateway_master.place_of_installation AS gateway_name,'.$dailyTableEB.'.`consuption_cost` FROM arka_sensor_master,'.$dailyTableEB.',arka_gateway_master WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.parent_id="'.$parent_id.'" AND arka_sensor_master.feeder_type="Sub Meter" AND arka_sensor_master.sensorCode='.$dailyTableEB.'.sensor_code AND arka_sensor_master.gateway_id='.$dailyTableEB.'.gateway_code AND DATE('.$dailyTableEB.'.recorded_date)=DATE('.$nowDate.') AND MONTH('.$dailyTableEB.'.recorded_date)=MONTH(DATE('.$nowDate.')) AND YEAR('.$dailyTableEB.'.recorded_date)=YEAR(DATE('.$nowDate.')) GROUP BY '.$dailyTableEB.'.sensor_code';   
 		
	      
	       
	       	$selQryC = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,sensor_code FROM '.$dailyTableEB.',arka_sensor_master WHERE arka_sensor_master.sensorCode='.$dailyTableEB.'.sensor_code AND '.$dailyTableEB.'.company_id="'.$comId.'" AND '.$dailyTableEB.'.branch_id="'.$branchId.'" AND DATE(recorded_date)=DATE('.$nowDate.') AND MONTH(recorded_date)=MONTH(DATE('.$nowDate.')) AND YEAR(recorded_date)=YEAR(DATE('.$nowDate.')) AND arka_sensor_master.feeder_type="Sub Meter" AND '.$dailyTableEB.'.gateway_code="'.$senDashboard[0]['gateway_id'].'" GROUP BY '.$dailyTableEB.'.sensor_code'; 
	       	$CostKWHRows		= $this->ExecuteQuery($selQryC, "numrows");
	        $CostKWH		= $this->ExecuteQuery($selQryC, "select");
	        $objSmarty->assign('CostKWH', $CostKWH);

$SelQuery='SELECT max(ping_log_id) AS ping_log_id, max(gateway_code) AS gateway_code,max(gateway_date_time) AS gateway_date_time FROM `gateway_ping_log_view` GROUP BY gateway_code ORDER BY ping_log_id';
	       $gateList= $this->ExecuteQuery($SelQuery, "select");//print_r($MeterList);
	       $objSmarty->assign('gateList', $gateList);

}	
		
}
?>