<?php
class CronData extends MysqlFns
{
       /********* CronData Constructor Starts ********************************/
	function CronData()
	{
		$this->LDDisplayPath= $config['SiteGlobalPath']."class.CronData.php";
		global $config;
		global $nowDate;
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$this->MysqlFns();
		$this->Limit = 25;
		$ConLink1 = mysql_connect($config['DBHost'],$config['DBUser'],$config['DBPassword']) or die("Database Connection Failed<br>". mysql_error());
		mysql_select_db($config['DBName'], $ConLink1);
		if($config['DBUser'] != 'root')
		{
			$nowDate= 'DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE)';
		}
		else{
			$nowDate= 'NOW()';
		}
	
	} 
      /********* CronData Constructor Ends ********************************/
     /********* sensorList Functions Starts ********************************/
function sensorList($objArray)
{
	global $objSmarty,$config;
	$tbl = $config['DBPrefix'];
	$SelQuery = 'SELECT * from arka_sensor_master WHERE status="1" AND isActive="1" AND segmentName="Energy Meter"';  
	$ListSensorView = $this->ExecuteQuery($SelQuery, 'select');
	$objSmarty->assign('ListSensorView', $ListSensorView);
	return $ListSensorView;
			
}
     /********* sensorList Functions Ends ********************************/
     /*********Get Company Name Function Starts ********************************/
    function GetCompanyName()
    {
global $objSmarty,$config;

$tbl = $config['DBPrefix'];
if($_GET['companyId'] <> '')
{
	$comId = base64_decode($_GET['companyId']);
}	
else
{
	$comId = $_SESSION['CustomerId'];
}

    $SelQuery = 'SELECT * FROM  `'.$tbl.'company_master` WHERE slNo="'.$comId.'" AND status="1"';  

$GetCompanyView = $this->ExecuteQuery($SelQuery, 'select');
$objSmarty->assign('GetCompanyView', $GetCompanyView);//print_r($ListView);exit;
			return $GetCompanyView;
    }
    /*********Get Company Name Function Ends ********************************/
     /*****************List Billing Month data function Starts**********************************************/
function ListBillingMonthlyData($objArray)
    {
global $objSmarty,$config,$nowDate;
$tbl = $config['DBPrefix'];
$mon = base64_decode($_GET['monthData']);
$mcode = explode("-",$mon);//print_r($mcode);exit;
if($mcode[0] == 'Feb')
{
$nmon = '02';
}
else
{
$nmon = date('m', strtotime($mcode[0]));
}
$nyr = '20'.$mcode[1];
  if($_GET['companyId'] <> '')
{
	$comId = base64_decode($_GET['companyId']);
}	
else
{
	$comId = $_SESSION['CustomerId'];
}
if($_GET['branchId'] <> '')
{
$branchId = base64_decode($_GET['branchId']);
}	
else
{
$branchId = $_SESSION['branch_id'];
}

if($branchId =='0')
{
	$whrClass='cron_monthly_energy_data.company_id="'.$comId.'"';
}
else
{
	$whrClass='cron_monthly_energy_data.company_id="'.$comId.'" AND cron_monthly_energy_data.branch_id="'.$branchId.'"';

}
$SelQuery = 'SELECT cron_monthly_energy_data.*, `'.$tbl.'sensor_master`.sensorName FROM `cron_monthly_energy_data`,`'.$tbl.'sensor_master` WHERE '.$whrClass.' AND MONTH(cron_monthly_energy_data.recorded_date)="'.$nmon.'" AND YEAR(cron_monthly_energy_data.recorded_date)="'.$nyr.'" AND `'.$tbl.'sensor_master`.isActive="1"  AND cron_monthly_energy_data.sensor_code=`'.$tbl.'sensor_master`.sensorCode ORDER BY `'.$tbl.'sensor_master`.feeder_type  ASC';  
$ListMonthData = $this->ExecuteQuery($SelQuery, 'select');
$objSmarty->assign('ListMonthData', $ListMonthData);
}
/****************************List Billing Month data function Ends***************************************/
/**************************Update Unit Rate function Starts*********************************************************/
function UpdateUnitRate($objArray)
{
global $objSmarty,$config,$_POST;
$tbl = $config['DBPrefix'];
$mon = $objArray['monthData'];
$mcode = explode("-",$mon);//print_r($mcode);
$nmon = date('m', strtotime($mcode[0]));
$companyId = base64_decode($objArray['companyId']);
$branch_id = base64_decode($objArray['branch_id']);
if($mcode[0] == 'Feb')
{
$nmon = '02';
}
else
{
$nmon = date('m', strtotime($mcode[0]));
}
$nyr = '20'.$mcode[1];

   $SelQuery = "SELECT cron_monthly_energy_data.*, ".$tbl."sensor_master.sensorName FROM `cron_monthly_energy_data`,".$tbl."sensor_master WHERE MONTH(cron_monthly_energy_data.recorded_date)='".$nmon."' AND YEAR(cron_monthly_energy_data.recorded_date)='".$nyr."' AND ".$tbl."sensor_master.sensorName IN('".$objArray['item_id']."')  AND ".$tbl."sensor_master.company_id='".$objArray["companyId"]."' AND ".$tbl."sensor_master.branch_id='".$objArray["branch_id"]."' AND ".$tbl."sensor_master.isActive='1' AND cron_monthly_energy_data.sensor_code=".$tbl."sensor_master.sensorCode ORDER BY ".$tbl."sensor_master.feeder_type  ASC";  
$ListMonthData = $this->ExecuteQuery($SelQuery, 'select');
$objSmarty->assign('ListMonthData', $ListMonthData);

			if(!empty($ListMonthData) && is_array($ListMonthData))
			{
			foreach($ListMonthData as $key=>$value)
			{
			$icode = stripslashes($ListMonthData[$key]['sensorName']);

$ccost = $objArray["rate"][$icode] * $ListMonthData[$key]['consuption_kwh'];

 $UpQuery = 'UPDATE `'.$tbl.'sensor_master` 
  SET 
    `unit_rate`=  "'.trim(addslashes($objArray["rate"][$icode])).'"
	 WHERE 
 `sensorName`="'.$ListMonthData[$key]['sensorName'].'" and status = "1" and isActive="1" and company_id="'.$objArray["companyId"].'" and branch_id="'.$objArray["branch_id"].'"';
  $this->ExecuteQuery($UpQuery, 'update');
  
  $UpQuery = 'UPDATE `cron_monthly_energy_data` 
  SET 
    `unit_rate`=  "'.trim(addslashes($objArray["rate"][$icode])).'",
	`consuption_cost`=  consuption_kwh * "'.$objArray["rate"][$icode].'",
	`unitpriceset`="Yes"
	 WHERE 
 `sensor_code`="'.$ListMonthData[$key]['sensor_code'].'" and MONTH(cron_monthly_energy_data.recorded_date)="'.$nmon.'" AND YEAR(cron_monthly_energy_data.recorded_date)="'.$nyr.'" and company_id="'.$objArray["companyId"].'" and branch_id="'.$objArray["branch_id"].'"';
  $this->ExecuteQuery($UpQuery, 'update');
  
  $UpQuery = 'UPDATE `cron_daily_energy_data` 
  SET 
    `cost`=  "'.trim(addslashes($objArray["rate"][$icode])).'",
	`consuption_cost`=  consuption_kwh * "'.$objArray["rate"][$icode].'"
	 WHERE 
 `sensor_code`="'.$ListMonthData[$key]['sensor_code'].'" and MONTH(cron_daily_energy_data.recorded_date)="'.$nmon.'" AND YEAR(cron_daily_energy_data.recorded_date)="'.$nyr.'" and company_id="'.$objArray["companyId"].'" and branch_id="'.$objArray["branch_id"].'"';
  $this->ExecuteQuery($UpQuery, 'update');
 }
 }
header('Location:listBilling.php?success_msg_for_update');  
}
/****************************Update Unit Rate function Ends**************************************************/
	 /********* GetGatewayName Functions Starts ********************************/
	function GetGatewayName()
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$bId = base64_decode($_GET['branchId']);
		$comId = base64_decode($_GET['companyId']);
		$gId = base64_decode($_GET['gatewayId']);
		
		$SelQuery = 'SELECT * FROM  `'.$tbl.'gateway_master` WHERE branch_id="'.$bId.'" AND company_id="'.$comId.'" AND sl_no="'.$gId.'" AND record_status="1"';  
		$GetGateView = $this->ExecuteQuery($SelQuery, 'select');
		$objSmarty->assign('GetGateView', $GetGateView);
		return $GetGateView;
	}
	/********* GetGatewayName Functions Ends ********************************/
	/********* ListCronData Functions Starts ********************************/
	function ListCronData($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
			if(isset($_POST['sensorName']) && $_POST['fromDate']=='' && $_POST['toDate']==''){
			$whereClause='`sensor_code`="'.$_POST['sensorName'].'" ';
		}
		else if(isset($_POST['sensorName']) && isset($_POST['fromDate']) && isset($_POST['toDate']))
		{
			$whereClause='`sensor_code`="'.$_POST['sensorName'].'" AND recorded_date BETWEEN  "'.$_POST['fromDate'].'" AND "'.$_POST['toDate'].'"';
		}
			$SelQuery = 'SELECT * FROM `cron_daily_energy_data` WHERE '.$whereClause.' ORDER BY recorded_date DESC';  
			$ListPostData = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListPostData', $ListPostData);
			return $ListPostData;
	
	}
     /********* ListCronData Functions Ends ********************************/
	 /********* ListCronDataMonthly Functions Starts ********************************/
	function ListCronDataMonthly($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if(isset($_POST['sensorName'])){
			$whereClause='`sensor_code`="'.$_POST['sensorName'].'"  ';
		}
			$SelQuery = 'SELECT * FROM `cron_monthly_energy_data` WHERE '.$whereClause.' ORDER BY recorded_date DESC';  
			$ListPostData = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListPostData', $ListPostData);
			return $ListPostData;
	}
      /********* ListCronDataMonthly Functions Ends ********************************/
	  /********* ListBillingMonthly Functions Starts ********************************/
	function ListBillingMonthly($objArray)
	{
		global $objSmarty,$config,$nowDate;
		$tbl = $config['DBPrefix'];
	
		if($_GET['companyId'] <> '')
		{
			$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
			$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
			$branchId = base64_decode($_GET['branchId']);
		}
		else if($_POST['branchName'] <> '')
		{
			$branchId = $_POST['branchName'];
		}
		else
		{
			$branchId = $_SESSION['branch_id'];
		}
		if($branchId =='0')
		{
			$whrClass='cron_monthly_energy_data.company_id="'.$comId.'"';
		}else
		{
			$whrClass='cron_monthly_energy_data.company_id="'.$comId.'" AND cron_monthly_energy_data.branch_id="'.$branchId.'"';
		}
		if(isset($_POST['monthName'])){
			$whereClause= $whrClass.' AND MONTH(cron_monthly_energy_data.recorded_date)=MONTH("'.$_POST['monthName'].'") AND YEAR(cron_monthly_energy_data.recorded_date)=YEAR("'.$_POST['monthName'].'") ';
		}
		else{
			$whereClause= $whrClass.' AND MONTH(cron_monthly_energy_data.recorded_date)=MONTH(DATE_SUB('.$nowDate.',INTERVAL 1 MONTH)) AND YEAR(cron_monthly_energy_data.recorded_date)=YEAR(DATE_SUB('.$nowDate.',INTERVAL 1 MONTH)) ';
		}
			$SelQuery = 'SELECT cron_monthly_energy_data.*, '.$tbl.'sensor_master.sensorName FROM `cron_monthly_energy_data`,'.$tbl.'sensor_master WHERE '.$whereClause.' AND cron_monthly_energy_data.sensor_code='.$tbl.'sensor_master.sensorCode ORDER BY '.$tbl.'sensor_master.feeder_type  ASC';  
			$ListPostData = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListPostData', $ListPostData);
		
			$SelMonth = 'SELECT DATE_FORMAT(cron_monthly_energy_data.recorded_date,"%b-%y") AS month_data, cron_monthly_energy_data.recorded_date,unitpriceset,company_id,branch_id,invoice_status FROM `cron_monthly_energy_data` WHERE '.$whrClass.'  AND DATE(cron_monthly_energy_data.recorded_date) < DATE(DATE_FORMAT('.$nowDate.',"%Y-%m-01")) GROUP BY cron_monthly_energy_data.recorded_date ORDER BY cron_monthly_energy_data.recorded_date  DESC'; 
			$ListMonthName = $this->ExecuteQuery($SelMonth, 'select');
			$objSmarty->assign('ListMonthName', $ListMonthName);
	
	}
      /********* ListBillingMonthly Functions Ends ********************************/
	  /********* GetBranchName Functions Starts ********************************/
	function GetBranchName($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> ''){
			$comId = base64_decode($_GET['companyId']);
		}
		else{
			$comId = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
			$lId = base64_decode($_GET['branchId']);
		}else
		{
			$lId = $_SESSION['branch_id'];
		}
			$SelQuery = 'SELECT * FROM  `'.$tbl.'branch_master` WHERE company_id="'.$comId.'" AND sl_no="'.$lId.'" AND record_status="1"';  
			$BranchView = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('BranchView', $BranchView);
			return $BranchView;
	}
	/********* GetBranchName Functions Ends ********************************/
	/********* ListBranch Functions Starts ********************************/
	function ListBranch($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> '')
		{
			$comId = base64_decode($_GET['companyId']);
		}	
		else
		{
			$comId = $_SESSION['CustomerId'];
		}
			$SelQuery = 'SELECT * FROM  `'.$tbl.'branch_master` WHERE company_id="'.$comId.'" AND record_status="1"';  
			$ListView = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListView', $ListView);
			}
			/********* ListBranch Functions End ********************************/
			/******************Create Invoice function starts********************************************/
function CreateInvoice($mid,$cid,$bid)
{
global $objSmarty,$config;
$tbl = $config['DBPrefix'];

$mon = $mid;
$mcode = explode("-",$mon);
$nmon = date('m', strtotime($mcode[0]));
$companyId = $objArray['companyId'];
$branch_id = $objArray['branch_id'];
if($mcode[0] == 'Feb')
{
$nmon = '02';
}
else
{
$nmon = date('m', strtotime($mcode[0]));
}
$nyr = '20'.$mcode[1];
			
 $SelQuery = "SELECT cron_monthly_energy_data.*, ".$tbl."sensor_master.sensorName, ".$tbl."sensor_master.segmentName,".$tbl."sensor_master.sensorCode FROM `cron_monthly_energy_data`,".$tbl."sensor_master WHERE MONTH(cron_monthly_energy_data.recorded_date)='".$nmon."' AND YEAR(cron_monthly_energy_data.recorded_date)='".$nyr."' AND ".$tbl."sensor_master.company_id='".$cid."' AND ".$tbl."sensor_master.branch_id='".$bid."' AND cron_monthly_energy_data.sensor_code=".$tbl."sensor_master.sensorCode AND ".$tbl."sensor_master.segmentName='Energy Meter' ORDER BY ".$tbl."sensor_master.feeder_type  ASC";  
$ListMonthData = $this->ExecuteQuery($SelQuery, 'select');
$objSmarty->assign('ListMonthData', $ListMonthData);
if(!empty($ListMonthData) && is_array($ListMonthData))
			{
			    
			foreach($ListMonthData as $key=>$value)
			{
			
				$SelQuerys1	= 'SELECT MAX(CAST(SUBSTRING(invoice_no,5, length(invoice_no)-4) as UNSIGNED)) AS last FROM `invoice_master` WHERE status="1" AND company_id="'.$cid.'" Limit 0,1';
$SaleDetail	= $this->ExecuteQuery($SelQuerys1, 'select');
$objSmarty->assign('SaleDetail', $SaleDetail);
if($SaleDetail[0]['last']!="")
			{
			$SaleDetail[0]['invoice_no'] = stripslashes($SaleDetail[0]['last']);
			$s_quote = preg_replace("/[^0-9\.]/", '', $SaleDetail[0]['invoice_no']);
			$s_quote1= $s_quote + 1;
			$str = str_split($SaleDetail[0]['last'], 3);
			$str = "INV";
			$in = $str. "/" .$s_quote1;
			}
			else
			{
			$in = "INV/1";
			}
			$objSmarty->assign('in', $in);
			
			$icode = stripslashes($ListMonthData[$key]['feeder_name']);
 $InsQuery = 'INSERT INTO `invoice_master`
(
`invoice_date`,
`Invoice_no`,
`company_id`,
`branch_id`,
`sensor_code`,
`feeder_name`,
`gateway_code`,
`bill_month`,
`start_kwh`,
`end_kwh`,
`unit_price`,
`invoice_amount`,
`created_by`,
`status`
) 
VALUES(
"'.date('Y-m-d').'",
"'.$in.'",
"'.$cid.'",
"'.$bid.'",
"'.$ListMonthData[$key]['sensor_code'].'",
"'.$ListMonthData[$key]['feeder_name'].'",
"'.$ListMonthData[$key]['gateway_code'].'",
"'.$nmon.'-'.$nyr.'",
"'.$ListMonthData[$key]['start_kwh'].'",
"'.$ListMonthData[$key]['end_kwh'].'",
"'.$ListMonthData[$key]['unit_rate'].'",
"'.$ListMonthData[$key]['consuption_cost'].'",
"'.$_SESSION['UserName'].'",
"1")';  
$this->ExecuteQuery($InsQuery, 'insert');

$UpQuery = 'UPDATE `cron_monthly_energy_data` 
  SET 
    `invoice_status`=  "1"
	 WHERE 
 `sensor_code`="'.$ListMonthData[$key]['sensor_code'].'" and MONTH(cron_monthly_energy_data.recorded_date)="'.$nmon.'" AND YEAR(cron_monthly_energy_data.recorded_date)="'.$nyr.'" and company_id="'.$cid.'" and branch_id="'.$bid.'"';
  $this->ExecuteQuery($UpQuery, 'update');
}
}
$mid = base64_encode($mid);
$cid = base64_encode($cid);
$bid = base64_encode($bid);

header('Location:listInvoice.php?gId='.$mid.'&companyId='.$cid.'&branchId='.$bid.'&success_msg_for_insert');  
}
/**************************Create Invoice Function Ends*********************************************/
/*******************************List Invoice Function Starts**********************************************************/
function ListInvoice($objArray)
{
global $objSmarty,$config,$nowDate;
$tbl = $config['DBPrefix'];

if($_GET['companyId'] <> '')
{
$comId = base64_decode($_GET['companyId']);
}	
else
{
$comId = $_SESSION['CustomerId'];
}
if($_GET['branchId'] <> '')
{
$branchId = base64_decode($_GET['branchId']);
}	
else
{
$branchId = $_SESSION['branch_id'];
}

if($_GET['gId'] <> '')
{
$GId =base64_decode($_GET['gId']);
$mcode = explode("-",$GId);

if($mcode[0] == 'Feb')
{
$nmon = '02';
}
else
{
$nmon = date('m', strtotime($mcode[0]));
}
$nyr = '20'.$mcode[1];
$whrClass='AND invoice_master.bill_month="'.$nmon.'-'.$nyr.'"';
}
else
{
$whrClass='';
}

if($branchId=='0')
{
$whrCl=' company_id="'.$comId.'"';
}
else{
$whrCl=' company_id="'.$comId.'" AND branch_id="'.$branchId.'"';
}

$SelQuery = 'SELECT * FROM `invoice_master` WHERE '.$whrCl.' AND status="1" '.$whrClass.'';  
$ListInvoiceData = $this->ExecuteQuery($SelQuery, 'select');
$objSmarty->assign('ListInvoiceData', $ListInvoiceData);//print_r($ListView);exit;
}
/****************************List Invoice Function Ends***********************************/
/*************************************Delete Invoice Function Starts/********************************************************************/
function DeleteInvoiceMaster($did)
{
global $objSmarty,$config;
$tbl = $config['DBPrefix'];
$sid = base64_decode($_GET['userId']);
if($_GET['companyId'] <> '')
{
	$compid = base64_decode($_GET['companyId']);
}	
else
{
	$compid = $_SESSION['CustomerId'];
}
echo $DelQuery = 'update `invoice_master` set `status`= 0 WHERE `invoice_master_id` ="'.$did.'"';exit;
$this->ExecuteQuery($DelQuery, 'update');
header('Location:' .$_SERVER['PHP_SELF']);  
}
/***********************Delete Invoice Function Ends***************************************/
	/********* ListShiftCronData Functions Starts ********************************/
	function ListShiftCronData($objArray)
	{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
			if(isset($_POST['sensorName']) && $_POST['fromDate']=='' && $_POST['toDate']==''){
			$whereClause='`sensor_code`="'.$_POST['sensorName'].'" ';
		}
		else if(isset($_POST['sensorName']) && isset($_POST['fromDate']) && isset($_POST['toDate']))
		{
			$whereClause='`sensor_code`="'.$_POST['sensorName'].'" AND recorded_date BETWEEN  "'.$_POST['fromDate'].'" AND "'.$_POST['toDate'].'"';
		}
			$SelQuery = 'SELECT * FROM `cron_daily_shift_wise_data` WHERE '.$whereClause.' ORDER BY recorded_date DESC';  
			$ListPostData = $this->ExecuteQuery($SelQuery, 'select');
			$objSmarty->assign('ListPostData', $ListPostData);
			return $ListPostData;
	
	}
     /********* ListShiftCronData Functions Ends ********************************/
}
?>