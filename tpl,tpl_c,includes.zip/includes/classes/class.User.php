<?php
class User extends MysqlFns
{
      /********* User Constructor Starts ********************************/
	function User()
	{
		$this->LDDisplayPath= $config['SiteGlobalPath']."class.User.php";
		global $config;
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$this->MysqlFns();
		$this->Limit = 20;			
	} 
     /********* User Constructor Ends ********************************/
    /******************************* ListUserGroup Functions Starts ********************************/
function ListUserGroup($objArray)
{
global $objSmarty,$config;
$tbl = $config['DBPrefix'];
	if($_SESSION["USER_GROUP"]=='Super Admin'){
		$whr='';
	}elseif($_SESSION["USER_GROUP"]=='Company Admin'){
		$whr='AND usergroupName !="Super Admin"';
	}
	elseif($_SESSION["USER_GROUP"]=='Branch Admin'){
		$whr='AND usergroupName !="Super Admin" AND usergroupName !="Company Admin"';
	}else{
		$whr='AND usergroupName ="Branch User"';
	}
	$SelQuery = 'SELECT  * FROM `'.$tbl.'user_group_master` WHERE status="1"'.$whr.'';
	$ListGroup = $this->ExecuteQuery($SelQuery, "select");
	$objSmarty->assign('ListGroup', $ListGroup);
	return $ListGroup;
}	
       /******************************* ListUserGroup Functions Ends ********************************/
	   /****************************** UserEditView Functions Starts *****************************/
		function UserEditView($objArray)
		{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if($_GET['userId'] <> '')
		{
			$sid = base64_decode($_GET['userId']);
		}
		else
		{
			$sid = $_SESSION['User_ID'];
		}
			$SelQuery = 'SELECT * FROM `'.$tbl.'user_master` WHERE slNo="'.$sid.'" AND status="1"';   
			$ListEditView = $this->ExecuteQuery($SelQuery, "select");
			$objSmarty->assign('ListEditView', $ListEditView);
			return $ListEditView;
		}
     /****************************** UserEditView Functions Ends *****************************/
     /*********Get Company Name Function Starts ********************************/
    function GetCompanyName($objArray)
    {
global $objSmarty,$config;
$tbl = $config['DBPrefix'];
if($_GET['companyId'] <> '')
{
	$comId = base64_decode($_GET['companyId']);
}	
else
{
	$comId = $_SESSION['CustomerId'];
}
if($_GET['branchId'] <> '')
{
	$brId = base64_decode($_GET['branchId']);
}	
else
{
	$brId = $_SESSION['branch_id'];
}
    $SelQuery = 'SELECT * FROM  `'.$tbl.'company_master` WHERE slNo="'.$comId.'" AND status="1"';  

$GetView = $this->ExecuteQuery($SelQuery, 'select');
$objSmarty->assign('GetView', $GetView);//print_r($ListView);exit;

 $SelQuery2 = 'SELECT * FROM  `'.$tbl.'branch_master` WHERE sl_no="'.$brId.'" AND record_status="1"';  

$GetView2 = $this->ExecuteQuery($SelQuery2, 'select');
$objSmarty->assign('GetView2', $GetView2);
			
    }
/*********End Of Get Company Name ********************************/
	 /****************************** EditUser Functions Starts *******************************/
		function EditUser($objArray="")
		{
			global $objSmarty,$config,$objFiles;
			$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> '')
		{
		    $compid = base64_decode($_GET['companyId']);
		}	
		else
		{
			$compid = $_SESSION['CustomerId'];
		}
		if((!$objArray['userName'])){
		$objSmarty->assign('ErrorMessage', 'User Name should not be blank');
		return false;
		}elseif(!$objArray['userGroup']){
		$objSmarty->assign('ErrorMessage', 'User Group should not be blank');
		return false;
		}elseif(!$objArray['mobileNo']){
		$objSmarty->assign('ErrorMessage', 'Mobile No should not be blank');
		return false;
		}elseif(!$objArray['emailId']){
		$objSmarty->assign('ErrorMessage', 'Email Id should not be blank');
		return false;
		}elseif(!$objArray['password']){
		$objSmarty->assign('ErrorMessage', 'Password should not be blank');
		return false;
		}
		$uploadpath = $config['UserImageUpload']; 
		if($_FILES['profileImage']["name"] <> "")
		{	
			$errors     = array();
			$maxsize    = 72880;
			$acceptable = array(
			'image/jpeg','image/jpg','image/gif','image/png');
		if(($_FILES['profileImage']['size'] >= $maxsize) || ($_FILES["profileImage"]["size"] == 0)) {
			$errors2[] = 'Image is too large. Image must be less than 1 MB';
		}
		
		if((!in_array($_FILES['profileImage']['type'], $acceptable)) && (!empty($_FILES["profileImage"]["type"])))
		{
			$errors3[] = 'Only JPG, JPEG and PNG types are accepted';
		}
		
		if(count($errors2)  === 0 && count($errors3)  === 0) 
		{
			if((!file_exists($config['UserImageUpload'] . $_FILES["profileImage"]["name"])))
		{  
			$f1 = $_FILES['profileImage']['name'];
			$f1 = explode(".", $_FILES['profileImage']['name']);
			$newfilename = round(microtime(true)) . '.' . end($f1); 
		if(move_uploaded_file($_FILES['profileImage']['tmp_name'], $uploadpath.$newfilename))
			chmod($uploadpath.$newfilename,0755);
			$f1=$newfilename;   
		}
		elseif((file_exists($config['UserImageUpload'] . $_FILES["profileImage"]["name"]))) 
		{	
		    $f1 = explode(".", $_FILES['profileImage']['name']);
		    $newfilename = round(microtime(true)) . '.' . end($f1);
		if(move_uploaded_file($_FILES['profileImage']['tmp_name'], $uploadpath.$newfilename))
			chmod($uploadpath.$newfilename,0755);
			$f1=$newfilename;  
		}
		}
		else {
		foreach($errors2 as $error2) 
		{
		$objSmarty->assign('ErrorMessage', $error2);
		return false;			
		}
		foreach($errors3 as $errors2) 
		{
		$objSmarty->assign('ErrorMessage', $errors2);
		return false;
		}
		}
		}
		else
		{
			$f1=$objArray['profileImageName'];
		}
		$imgName =$f1;
				
		if($imgName =="")
		{
			$_POST['profileImageName']."if"; 
			$filename= $_POST['profileImageName'] ;
			$pathName= $_POST['imagePath'] ;
		}
		else
		{
			$imgName."else"; 
			$filename= $f1 ;
			$pathName= $uploadpath.$f1 ;
		}
			$objSmarty->assign('userId', $objArray['userId']);
		if($objArray['userId'] && $objArray['userName'])
		{
			$UpQuery = 'UPDATE `'.$tbl.'user_master` SET 
			`userName` = "'.trim($objArray['userName']).'",
			`userGroup` = "'.trim($objArray['userGroup']).'",
			`userImage`= "'.$filename.'",
			`isActive` = "'.trim($objArray['checkVal']).'",
			`mobileNo` = "'.trim($objArray['mobileNo']).'",
			`phone` = "'.trim($objArray['phone']).'",
			`emailId` = "'.trim($objArray['emailId']).'",
			`password` = "'.trim($objArray['password']).'",
			`createdBy` = "'.trim($objArray['created_by']).'"
			 WHERE 
			`slNo` ="'.trim($objArray['userId']).'"'; 
			 $this->ExecuteQuery($UpQuery, 'update');
		}
			header('Location:userList.php?companyId='.$_GET['companyId'].'&success_msg_for_update');  
		}
        /****************************** EditUser Functions Ends *******************************/
	   /******************************* ListUser Functions Starts *****************************/
		function ListUser($objArray)
		{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
			$i=$_SESSION['USER_GROUP'];
		if($_POST['table_search'] <> '')
		{
			if($_GET['companyId'] <> '')
		{
			$SelQuery='SELECT  * FROM `'.$tbl.'user_master` WHERE status="1" AND company_id="'.$_GET['companyId'].'" AND (userName like "%'.$_POST['table_search'].'%" OR userGroup like "%'.$_POST['table_search'].'%" OR isActive like "%'.$_POST['table_search'].'%" OR mobileNo like "%'.$_POST['table_search'].'%" OR phone like "%'.$_POST['table_search'].'%" OR emailId like "%'.$_POST['table_search'].'%" OR password like "%'.$_POST['table_search'].'%") ORDER BY userName DESC';
		}
		else
		{
			$SelQuery='SELECT  * FROM `'.$tbl.'user_master` WHERE status="1" AND company_id="'.$_SESSION['CustomerId'].'" AND (userName like "%'.$_POST['table_search'].'%" OR userGroup like "%'.$_POST['table_search'].'%" OR isActive like "%'.$_POST['table_search'].'%" OR mobileNo like "%'.$_POST['table_search'].'%" OR phone like "%'.$_POST['table_search'].'%" OR emailId like "%'.$_POST['table_search'].'%" OR password like "%'.$_POST['table_search'].'%") ORDER BY userName DESC';
		}
		}
		else
		{
		if($_GET['companyId'] <> '')
		{
			$compid = base64_decode($_GET['companyId']);
		}	
		else
		{
			$compid = $_SESSION['CustomerId'];
		}
		if($_GET['branchId'] <> '')
		{
			$branchid = base64_decode($_GET['branchId']);
		}	
		else
		{
			$branchid = $_SESSION['branch_id'];
		}
		
		if($i == 'Super Admin')
		{
		    	$SelQuery = 'SELECT  * FROM `'.$tbl.'user_master` WHERE status="1" AND company_id="'.$compid.'" ';
		}
			
			else
			{
			   	$SelQuery = 'SELECT  * FROM `'.$tbl.'user_master` WHERE status="1" AND company_id="'.$compid.'" AND branch_id="'.$branchid.'"'; 
			}
		}
		$ListView = $this->ExecuteQuery($SelQuery, "select");
			$objSmarty->assign('ListView', $ListView);
			return $ListView;
		}		

       /******************************* ListUser Functions Ends *****************************/
	   /******************************* GetUserCount Functions Starts ***********************/
		function GetUserCount($objArray)
		{
			global $objSmarty,$config;
			$tbl = $config['DBPrefix'];
		if($_GET['companyId'] <> '')
		{
			$compid = base64_decode($_GET['companyId']);
		}	
		else
		{
			$compid = $_SESSION['CustomerId'];
		}
			$SelQuery = 'SELECT  COUNT(`'.$tbl.'user_master`.slNo) as userCount, `'.$tbl.'company_master`.userLimit as companyUserCount FROM `'.$tbl.'user_master`, `'.$tbl.'company_master` WHERE `'.$tbl.'user_master`.status="1" AND `'.$tbl.'company_master`.status="1" AND `'.$tbl.'company_master`.isActive="1" AND `'.$tbl.'user_master`.company_id=`'.$tbl.'company_master`.slNo AND `'.$tbl.'company_master`.slNo="'.$compid.'"'; 
			$ListuserCount = $this->ExecuteQuery($SelQuery, "select");
			$objSmarty->assign('ListuserCount', $ListuserCount);
			return $ListuserCount;
		}	

    /******************************* GetUserCount Functions Ends ***********************/
	/******************************* InsertUser Functions Starts ***********************/
	function InsertUser($objArray)
	{
		global $objSmarty,$config,$objFiles;
		$tbl = $config['DBPrefix'];
	if($_GET['companyId'] <> '')
	{
		$compid = base64_decode($_GET['companyId']);
	}	
	else
	{
		$compid = $_SESSION['CustomerId'];
	}
	if($_GET['branchId'] <> '')
		{
		   $branchid = base64_decode($_GET['branchId']);
		}	
		else
		{
		   $branchid = $_SESSION['branch_id'];
		}
	if((!$objArray['userName'])){
		$objSmarty->assign('ErrorMessage', 'User Name should not be blank');
		return false;
	}elseif(!$objArray['userGroup']){
		$objSmarty->assign('ErrorMessage', 'User Group should not be blank');
		return false;
	}elseif(!$objArray['mobileNo']){
		$objSmarty->assign('ErrorMessage', 'Mobile No should not be blank');
		return false;
	}elseif(!$objArray['emailId']){
		$objSmarty->assign('ErrorMessage', 'Email Id should not be blank');
		return false;
	}elseif(!$objArray['password']){
		$objSmarty->assign('ErrorMessage', 'Password should not be blank');
		return false;
	}
		$uploadpath = $config['UserImageUpload']; 
	if($_FILES['profileImage']["name"] <> "")
	{	
		$errors     = array();
		$maxsize    = 72880;
		$acceptable = array(
		'image/jpeg','image/jpg','image/gif','image/png');
	if(($_FILES['profileImage']['size'] >= $maxsize) || ($_FILES["profileImage"]["size"] == 0)) 
	{
		$errors2[] = 'Image is too large. Image must be less than 1 MB';
	}
	if((!in_array($_FILES['profileImage']['type'], $acceptable)) && (!empty($_FILES["profileImage"]["type"])))
	{
		$errors3[] = 'Only JPG, JPEG and PNG types are accepted';
	}
	if(count($errors2)  === 0 && count($errors3)  === 0) 
	{
		if((!file_exists($config['UserImageUpload'] . $_FILES["profileImage"]["name"])))
	{  
		$f1 = $_FILES['profileImage']['name'];
		$f1 = explode(".", $_FILES['profileImage']['name']);
		echo $f1;
		echo $newfilename = round(microtime(true)) . '.' . end($f1); 
	if(move_uploaded_file($_FILES['profileImage']['tmp_name'], $uploadpath.$newfilename))
		chmod($uploadpath.$newfilename,0755);
		echo $f1=$newfilename;   
	}
	elseif((file_exists($config['UserImageUpload'] . $_FILES["profileImage"]["name"]))) 
		{	
			$f1 = explode(".", $_FILES['profileImage']['name']);
			$newfilename = round(microtime(true)) . '.' . end($f1);
	if(move_uploaded_file($_FILES['profileImage']['tmp_name'], $uploadpath.$newfilename))
		chmod($uploadpath.$newfilename,0755);
		$f1=$newfilename;  
	}
	}
	else {
	foreach($errors2 as $error2) 
	{
		$objSmarty->assign('ErrorMessage', $error2);
		return false;			
	}
	foreach($errors3 as $errors2) 
	{
		$objSmarty->assign('ErrorMessage', $errors2);
		return false;
	}
	}
	}
	else
	{
	$f1="";
	}
	$objSmarty->assign('userName', $objArray['userName']);
	if($objArray['userGroup'] && $objArray['userName'])
	{
		$InsQuery = 'INSERT INTO `'.$tbl.'user_master`
		(
		`userName`,
		`userGroup`,
		`userImage`,
		`company_id`,
		`branch_id`,
		`isActive`,
		`mobileNo`,
		`phone`,
		`emailId`,
		`password`,
		`createdBy`
		) 
		VALUES(
		"'.trim(addslashes($objArray['userName'])).'",
		"'.trim(addslashes($objArray['userGroup'])).'",
		"'.$f1.'",
		"'.$compid.'",
		"'.$branchid.'",
		"'.trim(addslashes($objArray['checkVal'])).'",
		"'.trim(addslashes($objArray['mobileNo'])).'",
		"'.trim(addslashes($objArray['phone'])).'",
		"'.trim(addslashes($objArray['emailId'])).'",
		"'.trim(addslashes($objArray['password'])).'",
		"'.trim(addslashes($objArray['created_by'])).'")';  
		$this->ExecuteQuery($InsQuery, 'insert');
	}
	header('Location:userList.php?companyId='.$_GET['companyId'].'&branchId='.$_GET['branchId'].'&success_msg_for_insert');
	}

    /******************************* InsertUser Functions Ends ***********************/
	/******************************* DeleteMaster Functions Starts ***********************/
	function DeleteMaster($sid)
	{
		global $objSmarty,$config;
		$tbl = $config['DBPrefix'];
		$sid = base64_decode($_GET['userId']);
	if($_GET['companyId'] <> '')
	{
		$compid = base64_decode($_GET['companyId']);
	}	
	else
	{
		$compid = $_SESSION['CustomerId'];
	}
		$DelQuery = 'update `'.$tbl.'user_master` set `status`= 0 WHERE `slNo` ="'.$sid.'"';
		$this->ExecuteQuery($DelQuery, 'update');
		header('Location:' .$_SERVER['PHP_SELF'].'?companyId='.$_GET["companyId"].'&succs_msg_for_del');  
	}
    /******************************* DeleteMaster Functions Ends ***********************/

}
?>