<?php /* Smarty version 2.6.25, created on 2026-06-30 16:56:48
         compiled from branchList.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'base64_encode', 'branchList.tpl', 70, false),array('modifier', 'base64_decode', 'branchList.tpl', 84, false),)), $this); ?>
	<!-- Content Wrapper. Contains page content -->
	<div class="content-wrapper">
	
	<!-- Main content -->
		<section class="content-header">
		<div class="card">
		<div class="card-header">
		
		<table style="margin-bottom:-10px;">
		<tr><td style="font-size:15PX;font-weight: bold;"><?php if ($this->_tpl_vars['companyDetail']['0']['companyName'] != ""): ?><?php echo $this->_tpl_vars['companyDetail']['0']['companyName']; ?>
<?php else: ?><?php echo $this->_supers['session']['CompanyName']; ?>
<?php endif; ?>&nbsp;&nbsp;</td>
		<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="font-size:15PX;font-weight: bold;">List Branch</font>&nbsp;</td></tr>
		
		
		<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
		<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
		</tr>
		
		</table>
		
		</div>
		
		</div>
			<form name="location_list" method="post" id="location_list">
			<div class="row">
			
				<div class="col-12">
					<div class="card">
					
					
					<?php if ($this->_tpl_vars['SuccessMessage'] != "" || $this->_tpl_vars['ErrorMessage'] != ""): ?>
					<div class="card-body">
					<?php if ($this->_tpl_vars['SuccessMessage'] != ""): ?>
					<div class="isa_success">
					<i class="fa fa-check"></i>
					<?php echo $this->_tpl_vars['SuccessMessage']; ?>
		 
					</div>
					<?php endif; ?>
					<?php if ($this->_tpl_vars['ErrorMessage'] != ""): ?>
					<div class="isa_error">
					<i class="fa fa-check"></i>
					<?php echo $this->_tpl_vars['ErrorMessage']; ?>
		 
					</div>
					<?php endif; ?>
					</div>
					<?php endif; ?>
					<!-- /.card-header -->
						<div class="card-body table-responsive">
						<?php if ($this->_supers['session']['USER_GROUP'] == 'Super Admin'): ?><a href="branchAddEdit.php?companyId=<?php echo $this->_supers['get']['companyId']; ?>
"><button type="button" style="float:right;margin-top:-6PX" class="btn btn-create">Create Branch</button></a><span style="float:right">&ensp;</span>
						<a href="companyList.php?companyId=<?php echo $this->_supers['get']['companyId']; ?>
"><button type="button"  style="float:right;margin-top:-6PX" class="btn btn-primary">List Company</button></a> <?php endif; ?><?php if ($this->_tpl_vars['ListView']['0']['branch_id'] == ""): ?><br /><?php endif; ?>
							<table id="example" class="table table-bordered table-hover">
								<thead>
								<tr>
								<th class="slNo" >#</th>
								<th class="code">Branch Code</th>
								<th class="name">Branch Name</th>
								<th class="isactive">Status</th>
								<th class="action" >Action</th>
								</tr>
								</thead>
								<tbody>
								<?php $_from = $this->_tpl_vars['ListView']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['List']):
?>
								<tr id="<?php echo $this->_tpl_vars['j']++; ?>
">
								<td ><?php echo $this->_tpl_vars['j']; ?>
</td>
								<td ><?php echo $this->_tpl_vars['List']['branch_id']; ?>
</td>
								<td ><?php echo $this->_tpl_vars['List']['branch_name']; ?>
</td>
								<td align="center"><?php if ($this->_tpl_vars['List']['is_active'] == '1'): ?><span style="color:#00A520"><b>Active</b></span><?php else: ?><span style="color:#FF0000;"><b>Inactive</b></span><?php endif; ?></td>
								<td align="right">
								<a href="utility_dashboard2.php?companyId=<?php echo $this->_supers['get']['companyId']; ?>
&branchId=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['sl_no'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
" title="Visit Utility Dashboard" target="_blank"><i class="fa fa-building"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;   
								<?php $_from = $this->_tpl_vars['platformView']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['dashName']):
?>
									    
								<?php if ($this->_tpl_vars['dashName']['segmentName'] == 'Energy Meter' && $this->_tpl_vars['dashName']['branch_id'] == $this->_tpl_vars['List']['sl_no']): ?>
									<a href="dashboard.php?companyId=<?php echo $this->_supers['get']['companyId']; ?>
&branchId=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['sl_no'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
"  title="Visit <?php echo $this->_tpl_vars['List']['branch_name']; ?>
 Energy Dashboard" target="_blank"><i class="fa fa-desktop"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
								<?php endif; ?>
								<?php if ($this->_tpl_vars['dashName']['segmentName'] == 'Temperature' && $this->_tpl_vars['dashName']['branch_id'] == $this->_tpl_vars['List']['sl_no']): ?>
									<a href="temperature_temperatureDashboard.php?companyId=<?php echo $this->_supers['get']['companyId']; ?>
&branchId=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['sl_no'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
"  title="Visit <?php echo $this->_tpl_vars['List']['branch_name']; ?>
 Temperature Dashboard" target="_blank"><i class="fa fa-thermometer-half"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
								<?php endif; ?>
								<?php endforeach; endif; unset($_from); ?>
								<?php if ($this->_supers['session']['USER_GROUP'] == 'Super Admin' || $this->_supers['session']['USER_GROUP'] == 'Company Admin'): ?> 
									<a href="shiftList.php?companyId=<?php echo $this->_supers['get']['companyId']; ?>
&branchId=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['sl_no'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
"  title="List Shift"><i class="fa fa-list"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
								<?php endif; ?>
								<?php if ($this->_supers['session']['USER_GROUP'] == 'Super Admin'): ?>	
									 <a href="#" onClick="Javascript:platformCats('<?php echo $this->_tpl_vars['List']['sl_no']; ?>
','<?php if ($this->_supers['get']['companyId'] != ""): ?><?php echo ((is_array($_tmp=$this->_supers['get']['companyId'])) ? $this->_run_mod_handler('base64_decode', true, $_tmp) : base64_decode($_tmp)); ?>
<?php else: ?><?php echo $this->_supers['session']['CustomerId']; ?>
<?php endif; ?>')" title="List IoT Platform"><i class="fa fa-spinner"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;                                <?php endif; ?>
									<a href="userList.php?companyId=<?php if ($this->_supers['get']['companyId'] != ""): ?><?php echo $this->_supers['get']['companyId']; ?>
<?php else: ?><?php echo ((is_array($_tmp=$this->_supers['session']['CustomerId'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
<?php endif; ?>&branchId=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['sl_no'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
"  title="List User"><i class="fa fa-user"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
									<a href="contactMasterList.php?companyId=<?php if ($this->_supers['get']['companyId'] != ""): ?><?php echo $this->_supers['get']['companyId']; ?>
<?php else: ?><?php echo ((is_array($_tmp=$this->_supers['session']['CustomerId'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
<?php endif; ?>&branchId=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['sl_no'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
" title="List Alert Contact"><i class="fa fa-bell"></i></a>
								<?php if ($this->_supers['session']['billing_module'] == '1'): ?> 
									&nbsp;&nbsp;&nbsp;&nbsp;
									<a href="listBilling.php?companyId=<?php if ($this->_supers['get']['companyId'] != ""): ?><?php echo $this->_supers['get']['companyId']; ?>
<?php else: ?><?php echo ((is_array($_tmp=$this->_supers['session']['CustomerId'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
<?php endif; ?>&branchId=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['sl_no'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
" title="List Billing"><i class="fas fa-file-invoice"></i></a>
								<?php endif; ?>
								&nbsp;&nbsp;&nbsp;&nbsp;
								<?php if ($this->_supers['session']['USER_GROUP'] == 'Super Admin' || $this->_supers['session']['USER_GROUP'] == 'Company Admin'): ?> 
									<a href="#"  onClick="Javascript:listGatewayGroup('<?php echo $this->_tpl_vars['List']['company_id']; ?>
','<?php echo $this->_tpl_vars['List']['sl_no']; ?>
')" title="Gateway Mapping"><i class="fa fa-podcast"></i></a>
								<?php endif; ?>
								&nbsp;&nbsp;&nbsp;&nbsp;	
								<?php if ($this->_supers['session']['USER_GROUP'] != 'Super Admin'): ?>	 
									<a href="feederList.php?companyId=<?php echo $this->_supers['get']['companyId']; ?>
&branchId=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['sl_no'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
" title="List Feeder"><i class="fa fa-lightbulb"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
								<?php endif; ?>
								<?php $_from = $this->_tpl_vars['IconList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['icon']):
?>								
								<?php if ($this->_tpl_vars['icon']['menuName'] == 'List Gateway'): ?>
									<a href="#"  onClick="Javascript:gatewayCats('<?php echo $this->_tpl_vars['List']['sl_no']; ?>
','<?php echo $this->_tpl_vars['List']['company_id']; ?>
','<?php echo $this->_tpl_vars['List']['branch_id']; ?>
')" title="List Gateway"><i class="<?php echo $this->_tpl_vars['icon']['faIcon']; ?>
"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
								<?php endif; ?>
								<?php if ($this->_tpl_vars['icon']['menuName'] == 'Location List'): ?>
									<a href="#"  onClick="Javascript:locationCats('<?php echo $this->_tpl_vars['List']['sl_no']; ?>
','<?php echo $this->_tpl_vars['List']['company_id']; ?>
','<?php echo $this->_tpl_vars['List']['branch_id']; ?>
')" title="List Lcation"><i class="<?php echo $this->_tpl_vars['icon']['faIcon']; ?>
"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
								<?php endif; ?>
								
								<?php if ($this->_tpl_vars['icon']['menuName'] == 'Edit Branch'): ?>
									<a href="#"  onClick="Javascript:editCats('<?php echo $this->_tpl_vars['List']['sl_no']; ?>
','<?php echo $this->_tpl_vars['List']['company_id']; ?>
','<?php echo $this->_tpl_vars['List']['branch_id']; ?>
','Update=Y')" title="Edit"><i class="<?php echo $this->_tpl_vars['icon']['faIcon']; ?>
"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
								<?php endif; ?>
								<?php if ($this->_tpl_vars['icon']['menuName'] == 'Delete Branch'): ?>
									 <a href="#"  onClick="Javascript:deleteCats('<?php echo $this->_tpl_vars['List']['sl_no']; ?>
','<?php echo $this->_tpl_vars['List']['company_id']; ?>
','<?php echo $this->_tpl_vars['List']['branch_id']; ?>
')" title="Delete"><i class="<?php echo $this->_tpl_vars['icon']['faIcon']; ?>
"></i></a>
								 <?php endif; ?>
								<?php endforeach; endif; unset($_from); ?>&nbsp;&nbsp;&nbsp;&nbsp;
								</td>
								</tr>
								<?php endforeach; else: ?>
								<tr><td colspan="5"><center>No Records Found</center></td></tr>
								<?php endif; unset($_from); ?>
								</tbody>
							</table>
						</div>
					
					<!-- /.card-body -->
					</div>
				<!-- /.card -->
				</div>
			</form>
		</section>
	<!-- /.content -->
	</div>
	<!-- /.content-wrapper -->
	<?php echo '
	
	<style>
	.slNo{
	width:5%;
	}
	.code{
	width:10%;
	}
	.name{
	width:40%;
	}
	.isactive{
	width:10%;
	text-align:center;
	
	}
	.action{
	text-align:right;
	}
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	/*background-color:#FFBABA;*/
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	/*vertical-align:middle;*/
	}
	</style>
	<script type="text/javascript">
	$(document).ready(function (){
	
	var table = $(\'#example\').DataTable({
	"ordering" : false,
	language: {
	"infoFiltered": "",
	search: "_INPUT_",
	searchPlaceholder: "Search..."
	},
	dom: \'<"pull-left" f><bottom>p\',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: \'<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p\',
	//dom: \'<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p\',
	
	initComplete: function(){
	//  $("div.toolbar").html(\'<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>\');   
	
	
	}       
	}); 
	
	}); 
	
	function platformCats(branchId,companyId) {
	var comId = btoa(companyId);
	var branId = btoa(branchId);
	FormName		= document.location_list;
	FormName.action =\'platformAdd.php?companyId=\'+comId+\'&branchId=\'+branId;
	FormName.submit();
	}	
	function gatewayCats(slNoIdent,compIdent,branchIdent) {
	var sid = btoa(slNoIdent);  var comId = btoa(compIdent); var bid = btoa(branchIdent);
	FormName		= document.location_list;
	FormName.action =\'gatewayList.php?companyId=\'+comId+\'&branchId=\'+sid;
	FormName.submit();
	}
	function locationCats(slNoIdent,compIdent,branchIdent) {
	var sid = btoa(slNoIdent);  var comId = btoa(compIdent); var bid = btoa(branchIdent);
	FormName		= document.location_list;
	FormName.action =\'locationList.php?companyId=\'+comId+\'&branchId=\'+sid;
	FormName.submit();
	}
	function editCats(slNoIdent,compIdent,locIdIdent) {
	var sid = btoa(slNoIdent); var comId = btoa(compIdent); var bid = btoa(locIdIdent);
	FormName		= document.location_list;
	FormName.action =\'branchAddEdit.php?companyId=\'+comId+\'&branch_id=\'+bid+\'&sl_no=\'+sid+\'&Update=y\';
	FormName.submit();
	}
	function listGatewayGroup(compIdent,locIdIdent)
	{
	var comId = btoa(compIdent); var lid = btoa(locIdIdent);
	FormName		= document.location_list;
	FormName.action =\'gatewayGroupList.php?companyId=\'+comId+\'&branchId=\'+lid;
	FormName.submit();
	}
	</script>
	<script type="text/javascript">
	function deleteCats(slNoIdent,compIdent,locIdIdent){
	var sid = btoa(slNoIdent); var comId = btoa(compIdent); var bid = btoa(locIdIdent);
	if(confirm("Are you sure to Delete this Content?")){
	FormName		= document.location_list;
	FormName.action= \'branchList.php?companyId=\'+compIdent+\'&branch_id=\'+locIdIdent+\'&sl_no=\'+slNoIdent;
	FormName.submit();
	}
	}
	</script>
	'; ?>

	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>