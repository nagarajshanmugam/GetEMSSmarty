<?php /* Smarty version 2.6.25, created on 2026-05-22 12:31:36
         compiled from AddEditcompany.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'date_format', 'AddEditcompany.tpl', 160, false),)), $this); ?>
	<div class="content-wrapper">
	<section class="content-header">
	<div class="card">
				<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><?php if ($this->_supers['get']['companyId'] != ""): ?><td style="font-size:15PX;font-weight: bold;"><?php echo $this->_tpl_vars['ListEditView']['0']['companyName']; ?>
&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td><?php endif; ?>
				<td style="font-size:15PX;font-weight: bold;"><?php if ($this->_supers['get']['companyId'] == ""): ?>Create Company<?php else: ?>Edit Company<?php endif; ?>&nbsp;</td>
				</tr>
				<tr><?php if ($this->_supers['get']['companyId'] != ""): ?><td style="font-size:10PX;color:#999999;">Company Name</td><?php endif; ?>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
				<a href="companyList.php"> <button type="button" style="float:right;margin-top:-40PX" class="btn btn-primary" value="List Company">List Company</button></a>
				</div>
			</div>
	</section>
		<section class="content">
			<div class="card">
				<!--<div class="card-header">
				<h3 class="card-title"><?php if ($this->_supers['get']['companyId'] == ""): ?>Create Company <?php else: ?>Edit Company <?php endif; ?></h3>
				<a href="companyList.php"> <button type="button" class="btn btn-primary" value="List Company" style="float:right">List Company</button></a>
				</div>-->
			
			<?php if ($this->_tpl_vars['SuccessMessage'] != ""): ?>
				<div class="card-body">
					<div class="isa_success">
					<i class="fa fa-check"></i>
					<?php echo $this->_tpl_vars['SuccessMessage']; ?>
		 
					</div>
				</div>
			<?php endif; ?>
			<?php if ($this->_tpl_vars['ErrorMessage'] != ""): ?>
				<div class="card-body">
					<div class="isa_error">
					<i class="fa fa-check"></i>
					<?php echo $this->_tpl_vars['ErrorMessage']; ?>
		 
					</div>
				</div>
			<?php endif; ?>
				<div class="card-body">
					<form class="form-horizontal" name="companyReg" id="companyReg" enctype="multipart/form-data" method="post" onsubmit="return ValidateFields();">
						<input type="hidden" name="hdAction" id="hdAction">
						<input type="hidden" id="companyId" name="companyId" value="<?php echo $this->_tpl_vars['ListEditView']['0']['slNo']; ?>
" />
						<input type="hidden" id="checkVal" name="checkVal" value="<?php echo $this->_supers['post']['checkVal']; ?>
" />
						<input type="hidden" id="billModVal" name="billModVal" value="<?php echo $this->_supers['post']['billModVal']; ?>
" />
						<input type="hidden" id="imageval" name="imageval" class="form-control" />
						<div class="row">
						<div class="form-group col-md-6">
							<label for="inputEmail3">Company Name <span class="required"><b>*</b></span></label>
							<input type="text" name="companyMaster" class="form-control form-control-sm" id="companyMaster" placeholder="Company Name" autocomplete="Off" tabindex="1" value="<?php if ($this->_tpl_vars['ListEditView']['0']['companyName'] != ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['companyName']; ?>
<?php endif; ?>">
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">Address <span class="required"><b>*</b></span></label>
							<textarea name="address" class="form-control form-control-sm" id="address" autocomplete="Off" tabindex="10" placeholder="Address"><?php if ($this->_tpl_vars['ListEditView']['0']['address'] != ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['address']; ?>
<?php endif; ?></textarea>
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">Company Code <span class="required"><b>*</b></span></label>
							<input type="text" name="companyCode" class="form-control form-control-sm" id="companyCode" placeholder="Company Code" autocomplete="Off" tabindex="2" value="<?php if ($this->_tpl_vars['ListEditView']['0']['companyCode'] != ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['companyCode']; ?>
<?php endif; ?>"  >
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">Area </label>
							<input type="text" name="area" class="form-control form-control-sm" id="area" placeholder="Area" autocomplete="Off" tabindex="11" value="<?php if ($this->_tpl_vars['ListEditView']['0']['area'] != ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['area']; ?>
<?php endif; ?>">
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">Contact Person <span class="required"><b>*</b></span></label>
							<input type="text" name="contactPerson" class="form-control form-control-sm" id="contactPerson" placeholder="Contact Person" autocomplete="Off" tabindex="3" value="<?php if ($this->_tpl_vars['ListEditView']['0']['contactPerson'] != ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['contactPerson']; ?>
<?php endif; ?>">
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">City <span class="required"><b>*</b></span></label>
							<input type="text" name="city" class="form-control form-control-sm" id="city" placeholder="City" autocomplete="Off" tabindex="12" value="<?php if ($this->_tpl_vars['ListEditView']['0']['city'] != ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['city']; ?>
<?php endif; ?>">
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">Phone</label>
							<input type="text" class="form-control form-control-sm" id="phone" name="phone" placeholder="Phone" autocomplete="Off" tabindex="4" onKeyUp="numericFilter(this);" value="<?php if ($this->_tpl_vars['ListEditView']['0']['phone'] != ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['phone']; ?>
<?php endif; ?>" maxlength="15">
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">Pincode <span class="required"><b>*</b></span></label>
							<input type="text" name="pincode" class="form-control form-control-sm" id="pincode" placeholder="Pincode" autocomplete="Off" tabindex="13" onKeyUp="numericFilter(this);" value="<?php if ($this->_tpl_vars['ListEditView']['0']['pincode'] != ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['pincode']; ?>
<?php endif; ?>" maxlength="6">
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">Email Id <span class="required"><b>*</b></span></label>
							<input type="text" name="email" class="form-control form-control-sm" id="email" placeholder="Email Id" autocomplete="Off" tabindex="5" value="<?php if ($this->_tpl_vars['ListEditView']['0']['email'] != ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['email']; ?>
<?php endif; ?>">
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">State <span class="required"><b>*</b></span></label>
							<input type="text" name="state" class="form-control form-control-sm" id="state" placeholder="State" autocomplete="Off" tabindex="14" value="<?php if ($this->_tpl_vars['ListEditView']['0']['state'] != ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['state']; ?>
<?php endif; ?>">
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">User Limit <span class="required"><b>*</b></span></label>
							<input type="text" name="userLimit" class="form-control form-control-sm" id="userLimit" autocomplete="Off" tabindex="6" placeholder="User Limit" onKeyUp="numericFilter(this);" value="<?php if ($this->_tpl_vars['ListEditView']['0']['userLimit'] != ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['userLimit']; ?>
<?php endif; ?>">
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">PAN No </label>
							<input type="text" name="panNo" class="form-control form-control-sm" id="panNo" placeholder="PAN No" autocomplete="Off" tabindex="15" value="<?php if ($this->_tpl_vars['ListEditView']['0']['panNo'] != ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['panNo']; ?>
<?php endif; ?>">
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">SMS Count Limit <span class="required"><b>*</b></span></label>
							<input type="text" name="smsLimit" class="form-control form-control-sm" id="smsLimit" autocomplete="Off" tabindex="7" placeholder="SMS Limit" onKeyUp="numericFilter(this);" value="<?php if ($this->_tpl_vars['ListEditView']['0']['smsLimit'] != ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['smsLimit']; ?>
<?php endif; ?>">
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">GST No </label>
							<input type="text" name="gstNo" class="form-control form-control-sm" id="gstNo" placeholder="GST No" autocomplete="Off" tabindex="16" value="<?php if ($this->_tpl_vars['ListEditView']['0']['gstin'] != ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['gstin']; ?>
<?php endif; ?>">
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">Company Logo <span class="required"><b>*</b></span></label>                     
							<input type="hidden" name="imageName" class="form-control form-control-sm" id="imageName" autocomplete="Off" tabindex="8" value="<?php if ($this->_tpl_vars['ListEditView']['0']['companyLogo'] != ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['companyLogo']; ?>
<?php endif; ?>" >
						<?php if ($this->_tpl_vars['ListEditView']['0']['slNo'] != ""): ?>
							<a href="./images/CompanyLogo/<?php echo $this->_tpl_vars['ListEditView']['0']['companyLogo']; ?>
" target="_blank"><img src="./images/CompanyLogo/<?php echo $this->_tpl_vars['ListEditView']['0']['companyLogo']; ?>
" width="250px" height="50px" id="imgFile" name="imgFile" /></a>
							<a href="#" onclick="Showfile();" id="edit" name="edit"><i class="fa fa-edit"></i></a>
							<input type="file"  id="image" value="<?php echo $this->_supers['post']['image']; ?>
" name="image" tabindex="16" autocomplete="Off" class="form-control form-control-sm" value="<?php echo $this->_tpl_vars['master_dtls']['companyLogo']; ?>
" accept="image/x-jpg,image/png" style="display:none;"  onblur="ValidateFields1('image');"><span style="display:none; color:#FF0000; font-size:12px;" id="spanMsg">Only JPG,PNG images are allowed / Width * Height - 250 * 50 / Below - 500KB</span>
						<?php else: ?>
							<input type="file"  id="image" value="<?php echo $this->_supers['post']['image']; ?>
" accept="image/x-jpg,image/png" onchange="return ValidateFileUpload()" name="image" tabindex="16" autocomplete="Off" class="form-control form-control-sm"><span style="color:#FF0000; font-size:12px;">Only JPG,PNG images are allowed / Width * Height - 250 * 55 / Below - 500KB</span>
						<?php endif; ?>
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">Company Logo Small <span class="required"><b>*</b></span></label>                     
							<input type="hidden" name="smallImageName" class="form-control form-control-sm" id="smallImageName" autocomplete="Off" tabindex="17" value="<?php if ($this->_tpl_vars['ListEditView']['0']['companyLogoSmall'] != ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['companyLogoSmall']; ?>
<?php endif; ?>" >
						<?php if ($this->_tpl_vars['ListEditView']['0']['slNo'] != ""): ?>
							<a href="./images/companyLogoSmall/<?php echo $this->_tpl_vars['ListEditView']['0']['companyLogoSmall']; ?>
" target="_blank"><img src="./images/CompanyLogoSmall/<?php echo $this->_tpl_vars['ListEditView']['0']['companyLogoSmall']; ?>
" width="100" height="100" id="smallImgFile" name="smallImgFile" /></a>
							<a href="#" onclick="Showfile1();" id="edit1" name="edit1"><i class="fa fa-edit"></i></a>
							<input type="file"  id="smallImage" value="<?php echo $this->_supers['post']['smallImage']; ?>
" name="smallImage" tabindex="17" autocomplete="Off" class="form-control form-control-sm" value="<?php echo $this->_tpl_vars['master_dtls']['companyLogoSmall']; ?>
" accept="image/x-jpg,image/png" style="display:none;"  onblur="ValidateFields1('smallImage');"><span style="display:none; color:#FF0000; font-size:12px;" id="spanMsg1">Only JPG,PNG images are allowed / Width * Height - 80 * 60 / Below - 200KB</span>
						<?php else: ?>
							<input type="file"  id="smallImage" value="<?php echo $this->_supers['post']['smallImage']; ?>
" accept="image/x-jpg,image/png" name="smallImage" tabindex="17" autocomplete="Off" class="form-control form-control-sm"><span style="color:#FF0000; font-size:12px;">Only JPG,PNG images are allowed / Width * Height - 80 * 60 / Below - 200KB</span>
						<?php endif; ?>
						</div>
						 <div class="form-group col-md-6">
							<div class="custom-control custom-checkbox">
							<?php if ($this->_tpl_vars['ListEditView']['0']['companyName'] != ''): ?>
							<?php if ($this->_tpl_vars['ListEditView']['0']['billing_module'] == '1'): ?>
								<input class="custom-control-input" type="checkbox" id="billingModule"  name="billingModule" tabindex="9" checked="checked">
								<label for="billingModule" class="custom-control-label">Billing Module <span class="required"><b>*</b></span></label>
							<?php else: ?>
								<input class="custom-control-input" type="checkbox" id="billingModule" name="billingModule" tabindex="9">
								<label for="billingModule" class="custom-control-label">Billing Module <span class="required"><b>*</b></span></label>
							<?php endif; ?>
							<?php else: ?>
								<input class="custom-control-input" type="checkbox" id="billingModule" name="billingModule" tabindex="9" >
								<label for="billingModule" class="custom-control-label">Billing Module <span class="required"><b>*</b></span></label>
							<?php endif; ?>
							</div>
						</div>
						<div class="form-group col-md-6">
							<div class="custom-control custom-checkbox">
							<?php if ($this->_tpl_vars['ListEditView']['0']['companyName'] != ''): ?>
							<?php if ($this->_tpl_vars['ListEditView']['0']['isActive'] == '1'): ?>
								<input class="custom-control-input" type="checkbox" id="customCheckbox2"  name="customCheckbox2" tabindex="18" checked="checked">
								<label for="customCheckbox2" class="custom-control-label">Is Active <span class="required"><b>*</b></span></label>
							<?php else: ?>
								<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="18">
								<label for="customCheckbox2" class="custom-control-label">Is Active <span class="required"><b>*</b></span></label>
							<?php endif; ?>
							<?php else: ?>
								<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="18" checked="checked">
								<label for="customCheckbox2" class="custom-control-label">Is Active <span class="required"><b>*</b></span></label>
							<?php endif; ?>
							</div>
							<input id="created_by" name="created_by" class="date-picker form-control" type="hidden" value="<?php echo $this->_supers['session']['UserName']; ?>
" readonly="true">
							<input type="hidden" class="form-control" id="timestamp" name="timestamp" value="<?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d &amp; %I:%M:%S %p') : smarty_modifier_date_format($_tmp, '%Y-%m-%d &amp; %I:%M:%S %p')); ?>
">
							<input type="hidden" class="form-control" id="created_time" name="created_time" placeholder="Time" Value="<?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%I:%M:%S %p') : smarty_modifier_date_format($_tmp, '%I:%M:%S %p')); ?>
">
						</div>
						</div>
						<div align="center">
							<center>
							<input type="submit" value="Submit" class="btn btn-create" tabindex="19"  onclick="ValidateFields();" />
							</center>
						</div>
					</form>
				</div>
			</div>
		</section>
	</div>
	<?php echo '
	<script type="text/javascript">
	$(document).ready(function() { 
	$("#email").change(function(){  
	$(".error").remove();
	var emailReg = /^([\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4})?$/;
	
	var emailaddressVal = $("#email").val();
	
	if(!emailReg.test(emailaddressVal)) {
	$("#email").after(\'<span class="error">Enter a valid email address.</span>\');
	$(\'#email\').focus();
	return false;
	}
	});
	});
	</script>
	<script type="text/javascript">
	function numericFilter(data)
	{
	data.value = data.value.replace(/[^.0-9^.+,-]/ig,"");
	}
	function text_filter(data)
	{
	data.value = data.value.replace(/[^ .a-z]/ig,"");
	}
	function Showfile()
	{
	document.getElementById(\'image\').style.display="block";
	document.getElementById(\'imgFile\').style.display="none";
	document.getElementById(\'edit\').style.display="none";
	document.getElementById(\'spanMsg\').style.display="block";
	}
	function Showfile1()
	{
	document.getElementById(\'smallImage\').style.display="block";
	document.getElementById(\'smallImgFile\').style.display="none";
	document.getElementById(\'edit1\').style.display="none";
	document.getElementById(\'spanMsg1\').style.display="block";
	}
	function ValidateFields1(id)
	{
	
	var val = document.getElementById(id).value;
	if(val == \'\')
	{
	$(".error").remove();
	$("#"+id).after(\'<span class="error">This field is required</span>\');
	$("#"+id).focus();
	return false;		
	}
	else
	{
	$(".error").remove();
	return true;
	}
	}
	function ValidateFields()
	{
	var companyMaster = $(\'#companyMaster\').val();
	var companyCode = $(\'#companyCode\').val();
	var contactPerson = $(\'#contactPerson\').val();
	var phone = $(\'#phone\').val();
	var email = $(\'#email\').val();
	var image = $(\'#image\').val();
	var smallImage = $(\'#smallImage\').val();
	var imageName = $(\'#imageName\').val(); 
	var smallImageName = $(\'#smallImageName\').val(); 
	var userLimit = $(\'#userLimit\').val();
	var smsLimit = $(\'#smsLimit\').val();
	var address = $(\'#address\').val();
	var area = $(\'#area\').val();
	var city = $(\'#city\').val();
	var pincode = $(\'#pincode\').val();
	var state = $(\'#state\').val();
	var isActive = document.getElementById("customCheckbox2").checked;
	var billMod = document.getElementById("billingModule").checked;
	var mailformat = /^[a-zA-Z0-9.!#$%&\'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*$/;
	if (isActive == false) 
	{
	document.getElementById(\'checkVal\').value=\'0\';
	}
	else
	{
	document.getElementById(\'checkVal\').value=\'1\';
	}
	if (billMod == false) 
	{
	document.getElementById(\'billModVal\').value=\'0\';
	}
	else
	{
	document.getElementById(\'billModVal\').value=\'1\';
	}
	$(".error").remove();
	if (companyMaster.length < 1) {
	$(\'#companyMaster\').after(\'<span class="error">This field is required</span>\');
	$(\'#companyMaster\').focus();
	return false;					
	}
	else if (companyCode.length < 1) {
	$(\'#companyCode\').after(\'<span class="error">This field is required</span>\');
	$(\'#companyCode\').focus();
	return false;					
	}
	else if (contactPerson.length < 1) {
	$(\'#contactPerson\').after(\'<span class="error">This field is required</span>\');
	$(\'#contactPerson\').focus();
	return false;					
	}
	else if (email.length < 1) {
	$(\'#email\').after(\'<span class="error">This field is required</span>\');
	$(\'#email\').focus();
	return false;					
	}
    else if(!mailformat.test(email)) {
	$("#email").after(\'<span class="error">Enter a valid email address.</span>\');
	$(\'#email\').focus();
	return false;	
    }
	else if (userLimit == 0) {
	$(\'#userLimit\').after(\'<span class="error">This field is required</span>\');
	$(\'#userLimit\').focus();
	return false;					
	}
	else if (smsLimit.length == 0) {
	$(\'#smsLimit\').after(\'<span class="error">This field is required</span>\');
	$(\'#smsLimit\').focus();
	return false;					
	}
	else if (address.length < 1) {
	$(\'#address\').after(\'<span class="error">This field is required</span>\');
	$(\'#address\').focus();
	return false;					
	}
	else if (city.length < 1) {
	$(\'#city\').after(\'<span class="error">This field is required</span>\');
	$(\'#city\').focus();
	return false;					
	}
	else if (pincode.length < 1) {
	$(\'#pincode\').after(\'<span class="error">This field is required</span>\');
	$(\'#pincode\').focus();
	return false;					
	}
	else if (pincode.length < 6) {
	$(\'#pincode\').after(\'<span class="error">Pincode Should be 6 digits</span>\');
	$(\'#pincode\').focus();
	return false;					
	}
	else if (state.length < 1) {
	$(\'#state\').after(\'<span class="error">This field is required</span>\');
	$(\'#state\').focus();
	return false;					
	}
	else if (image.length < 1 && imageName.length < 1) {
	$(\'#image\').after(\'<span class="error">This field is required</span>\');
	$(\'#image\').focus();
	return false;					
	}
	else if (smallImage.length < 1 && smallImageName.length < 1) {
	$(\'#smallImage\').after(\'<span class="error">This field is required</span>\');
	$(\'#smallImage\').focus();
	return false;					
	}
	}
	function GoBack()
	{
	window.history.back();
	}

function ValidateEmail(inputText)
{
var mailformat = /^[a-zA-Z0-9.!#$%&\'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*$/;
if(inputText.value.match(mailformat))
{
alert("Valid email address!");
document.companyReg.email.focus();
return true;
}
else
{
alert("You have entered an invalid email addressz!");
document.companyReg.email.focus();
}
}

	</script>
	<script type="text/javascript">
	function ValidateFileUpload() {
	var imageData = document.getElementById(\'image\');
	var FileUploadPath = imageData.value;
	
	//To check if user upload any file
	if (FileUploadPath == \'\') {
	alert("Please upload an image");
	
	} else {
	var Extension = FileUploadPath.substring(
	FileUploadPath.lastIndexOf(\'.\') + 1).toLowerCase();
	
	//The file uploaded is an image
	
	if (Extension == "png" || Extension == "jpg") {
	
	// To Display
	if (imageData.files && imageData.files[0]) {
	var reader = new FileReader();
	
	reader.onload = function(e) {
	$(\'#blah\').attr(\'src\', e.target.result);
	}
	
	reader.readAsDataURL(imageData.files[0]);
	}
	
	} 
	
	//The file upload is NOT an image
	else {
	alert("Only  JPG and PNG types are accepted");
	document.getElementById(\'image\').focus();
	document.getElementById(\'image\').value="";
	
	}
	}
	//To Check the file size an image	
	const fi  = document.getElementById(\'image\');
	if (fi .files.length > 0) { 
	for (const i = 0; i <= fi .files.length - 1; i++) { 
	
	const fsize = fi .files.item(i).size; 
	const file = Math.round((fsize / 1024)); 
	// The size of the file. 
	if (file >= 3000) { 
	alert( 
	"File too Big, please select a file less than 1mb"); 
	document.getElementById(\'image\').focus();
	document.getElementById(\'image\').value="";
	} 
	} 
	} 
	
	}
	
	</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	/*background-color:#FFBABA;*/
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	/*vertical-align:middle;*/
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	'; ?>

	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>