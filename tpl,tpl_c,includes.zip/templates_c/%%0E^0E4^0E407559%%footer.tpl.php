<?php /* Smarty version 2.6.25, created on 2025-12-05 13:10:04
         compiled from footer.tpl */ ?>
 <footer class="main-footer">

   <!--- <strong style="float:left"> <a href="https://www.innospace.co.in/">Innospace</a></strong> --->
    <strong > <a href="http://greatelephanttech.com" target="_blank">Great Elephant Technologies Pvt Ltd</a></strong>
 </footer>
		</div>
		<?php echo '

<style>
.main-footer{
text-align:right;
}
</style>
    
	'; ?>

    <!-- /Starrr -->
  </body>
</html>