<?php /* Smarty version 2.6.25, created on 2025-11-11 14:51:49
         compiled from gatewayList.tpl */ ?>
	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
			<table style="margin-bottom:-10px;">
			<tr><td style="font-size:15PX;font-weight: bold;"><?php if ($this->_tpl_vars['companyDetail']['0']['companyName'] != ""): ?><?php echo $this->_tpl_vars['companyDetail']['0']['companyName']; ?>
<?php else: ?><?php echo $this->_supers['session']['CompanyName']; ?>
<?php endif; ?>&nbsp;&nbsp;</td>
			<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
			<?php if ($this->_tpl_vars['branchDetail']['0']['branch_name'] != ""): ?>
					<td style="font-size:15PX;font-weight: bold;"><?php echo $this->_tpl_vars['branchDetail']['0']['branch_name']; ?>
&ensp;&ensp;</td><?php endif; ?>
					<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
			<td style="font-size:15PX;font-weight: bold;">List Gateway</font>&nbsp;</td></tr>
			<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
			<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
			<td style="color:#999999;font-size:10PX;">Branch Name</td>
			<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
			<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
			</tr>
			</table>
			</div>
		</div>
	<form name="gateway_list" method="post" id="gateway_list">
	<div class="row">
		<div class="col-12">
			<div class="card">
			<?php if ($this->_tpl_vars['SuccessMessage'] != "" || $this->_tpl_vars['ErrorMessage'] != ""): ?>
				<div class="card-body">
				<?php if ($this->_tpl_vars['SuccessMessage'] != ""): ?>
					<div class="isa_success">
					<i class="fa fa-check"></i>
					<?php echo $this->_tpl_vars['SuccessMessage']; ?>
		 
					</div>
				<?php endif; ?>
				<?php if ($this->_tpl_vars['ErrorMessage'] != ""): ?>
					<div class="isa_error">
					<i class="fa fa-check"></i>
					<?php echo $this->_tpl_vars['ErrorMessage']; ?>
		 
					</div>
				<?php endif; ?>
				</div>
			<?php endif; ?>
				<div class="card-body table-responsive">
				<a href="gatewayAddEdit.php?companyId=<?php echo $this->_supers['get']['companyId']; ?>
&branchId=<?php echo $this->_supers['get']['branchId']; ?>
"><button type="button" style="float:right;margin-top:-6PX" class="btn btn-create">Create Gateway</button></a><?php if ($this->_supers['session']['USER_GROUP'] == 'Company Admin'): ?><span style="float:right">&ensp;</span>
				<a href="companyDashboard.php"><button type="button"  style="float:right;margin-top:-6PX" class="btn btn-primary">Dashboard</button></a><?php endif; ?><?php if ($this->_supers['session']['USER_GROUP'] == 'Super Admin'): ?><span style="float:right">&ensp;</span>
				<a href="branchList.php?companyId=<?php echo $this->_supers['get']['companyId']; ?>
"><button type="button"  style="float:right;margin-top:-6PX" class="btn btn-primary">List Branch</button></a><span style="float:right">&ensp;</span>
				<a href="companyList.php"><button type="button"  style="float:right;margin-top:-6PX" class="btn btn-primary">List Company</button></a><?php if ($this->_tpl_vars['ListView']['0']['gateway_id'] == ""): ?><br /><?php endif; ?><?php endif; ?>
					<table id="example" class="table table-bordered table-hover">
					<thead>
					<tr>
					<th class="slNo">#</th>
					<th class="code">Gateway Code</th>
					<th class="model">Gateway Model Name</th>
				<!--	<th class="model">Model</th>-->
					<th class="place">Place of Installation</th>
					<th class="isactive">Status</th>
					<th>Action</th>
					</tr>
					</thead>
					<tbody>
					<?php $_from = $this->_tpl_vars['ListView']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['List']):
?>
					<tr id="<?php echo $this->_tpl_vars['j']++; ?>
">
					<td class="slno"><?php echo $this->_tpl_vars['j']; ?>
</td>
					<td><?php echo $this->_tpl_vars['List']['gateway_id']; ?>
</td>
					<td><?php echo $this->_tpl_vars['List']['model_name']; ?>
</td>
				<!--	<td><?php echo $this->_tpl_vars['List']['model']; ?>
</td> -->
					<td><?php echo $this->_tpl_vars['List']['place_of_installation']; ?>
</td>
					<td align="center"><?php if ($this->_tpl_vars['List']['is_active'] == '1'): ?><span style="color:#009900"><b>Active</b></span><?php else: ?><span style="color:#FF0000;"><b>Inactive</b></span><?php endif; ?></td>
					<td align="right">
					<?php $_from = $this->_tpl_vars['IconList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['icon']):
?>
					<?php if ($this->_tpl_vars['icon']['menuName'] == 'List Sensor'): ?><a href="#"  onClick="Javascript:sensorCats('<?php echo $this->_tpl_vars['List']['sl_no']; ?>
','<?php echo $this->_tpl_vars['List']['company_id']; ?>
','<?php echo $this->_tpl_vars['List']['branch_id']; ?>
','<?php echo $this->_tpl_vars['List']['gateway_id']; ?>
')" title="List Sensor"><i class="<?php echo $this->_tpl_vars['icon']['faIcon']; ?>
"></i></a>&nbsp;&nbsp;&nbsp;<?php endif; ?>
					<?php if ($this->_tpl_vars['icon']['menuName'] == 'Edit Gateway'): ?><a href="#"  onClick="Javascript:editCats('<?php echo $this->_tpl_vars['List']['sl_no']; ?>
','<?php echo $this->_tpl_vars['List']['gateway_id']; ?>
','<?php echo $this->_tpl_vars['List']['company_id']; ?>
','<?php echo $this->_tpl_vars['List']['branch_id']; ?>
','Update=Y')" title="Edit"><i class="<?php echo $this->_tpl_vars['icon']['faIcon']; ?>
"></i></a>&nbsp;&nbsp;&nbsp;<?php endif; ?>
					<?php if ($this->_tpl_vars['icon']['menuName'] == 'Delete Gateway'): ?><a href="#"  onClick="Javascript:deleteCats('<?php echo $this->_tpl_vars['List']['sl_no']; ?>
','<?php echo $this->_tpl_vars['List']['company_id']; ?>
','<?php echo $this->_tpl_vars['List']['branch_id']; ?>
')" title="Delete"><i class="<?php echo $this->_tpl_vars['icon']['faIcon']; ?>
"></i></a><?php endif; ?>
					<?php endforeach; endif; unset($_from); ?></td>
					</tr>
					<?php endforeach; else: ?>
					<tr><td colspan="6"><center>No Records Found</center></td></tr>
					<?php endif; unset($_from); ?>
					</tbody>
					</table>
				</div>
			</div>
		</div>
	</form>
	</section>
	</div>
	<?php echo '
	<style>
	.slNo{
	width:5%;
	}
	.code{
	width:15%;
	}
	.model{
	width:15%;
	}
	.place{
	width:40%;
	}
	.isactive{
	width:10%;
	text-align:center;
	
	}
	.action{
	text-align:right;
	}
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>
	<script type="text/javascript">
	$(document).ready(function (){
	
	var table = $(\'#example\').DataTable({
	"ordering" : false,
	language: {
	"infoFiltered": "",
	search: "_INPUT_",
	searchPlaceholder: "Search..."
	},
	dom: \'<"pull-left" f><bottom>p\',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: \'<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p\',
	//dom: \'<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p\',
	
	initComplete: function(){
	//$("div.toolbar").html(\'<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>\');   
	}       
	}); 
	}); 
	function editCats(slNoIdent,gateIdIdent,compIdent,branId) 
	{
		var sid = btoa(slNoIdent); var gid = btoa(gateIdIdent); var comId = btoa(compIdent); var branchId = btoa(branId);
		FormName		= document.gateway_list;
		FormName.action =\'gatewayAddEdit.php?gateway_id=\'+gid+\'&companyId=\'+comId+\'&branchId=\'+branchId+\'&sl_no=\'+sid+\'&Update=y\';
		FormName.submit();
	}
	function sensorCats(gateSlNo,cIdent,bIdent,gatewayId)
	 {
		var gid = btoa(gateSlNo); var cid = btoa(cIdent);var bid = btoa(bIdent);var gateid = btoa(gatewayId);
		FormName		= document.gateway_list;
		FormName.action =\'sensorList.php?gatewayId=\'+gateid+\'&companyId=\'+cid+\'&branchId=\'+bid;
		FormName.submit();
	}
	</script>
	<script type="text/javascript">
	function deleteCats(slNoIdent,comIdent,branIdent)
	{
		var sid = btoa(slNoIdent); var cid = btoa(comIdent); var bid = btoa(branIdent);
		if(confirm("Are you sure to Delete this Content?")){
		FormName		= document.gateway_list;
		FormName.action= \'gatewayList.php?company_id=\'+cid+\'&branch_id=\'+bid+\'&sl_no=\'+slNoIdent;
		FormName.submit();
		}
	}
	</script>
	'; ?>

	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>