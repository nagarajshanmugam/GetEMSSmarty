<?php /* Smarty version 2.6.25, created on 2026-09-30 11:37:48
         compiled from addAlertContact.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'base64_decode', 'addAlertContact.tpl', 27, false),)), $this); ?>
	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;"><?php if ($this->_tpl_vars['companyDetail']['0']['companyName'] != ""): ?><?php echo $this->_tpl_vars['companyDetail']['0']['companyName']; ?>
<?php else: ?><?php echo $this->_supers['session']['CompanyName']; ?>
<?php endif; ?>&nbsp;&nbsp;</td>
				<?php if ($this->_tpl_vars['branchDetail']['0']['branch_name'] != ""): ?>  
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;"><?php echo $this->_tpl_vars['branchDetail']['0']['branch_name']; ?>
&ensp;&ensp;</td><?php endif; ?>
					<?php if ($this->_supers['get']['sensorCode'] != ""): ?>  
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;"><?php echo $this->_tpl_vars['ListView2']['0']['sensorName']; ?>
&ensp;&ensp;</td><?php endif; ?>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">Add To Alert Contact</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:10PX;color:#999999;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;">Sensor Name</td>
				<td>&nbsp;</td>
				</tr>
				</table>
			</div>
		</div>
		<form name="contactMasterList" method="post" id="contactMasterList" onsubmit="return Validate();">
        <input type="hidden" name="hdAction" id="hdAction">
        <input type="hidden" id="companyId" name="companyId" value="<?php echo ((is_array($_tmp=$this->_supers['get']['companyId'])) ? $this->_run_mod_handler('base64_decode', true, $_tmp) : base64_decode($_tmp)); ?>
">
        <input type="hidden" id="branchId" name="branchId" value="<?php echo ((is_array($_tmp=$this->_supers['get']['branchId'])) ? $this->_run_mod_handler('base64_decode', true, $_tmp) : base64_decode($_tmp)); ?>
">
        <input type="hidden" id="sensorId" name="sensorId" value="<?php echo ((is_array($_tmp=$this->_supers['get']['slNo'])) ? $this->_run_mod_handler('base64_decode', true, $_tmp) : base64_decode($_tmp)); ?>
">
        <input type="hidden" id="item_id" name="item_id" value="<?php echo $this->_supers['post']['item_id']; ?>
">
        
		<div class="row">
			<div class="col-12">
			<?php if ($this->_tpl_vars['SuccessMessage'] != ""): ?>
				<div class="isa_success">
				<i class="fa fa-check"></i>
				<?php echo $this->_tpl_vars['SuccessMessage']; ?>
		 
				</div>
			<?php endif; ?>
			<?php if ($this->_tpl_vars['ErrorMessage'] != ""): ?>
				<div class="isa_error">
				<i class="fa fa-check"></i>
				<?php echo $this->_tpl_vars['ErrorMessage']; ?>
		 
				</div>
			<?php endif; ?>
				<div class="card">
					<div class="card-body table-responsive">
					<a href="sensorList.php?companyId=<?php echo $this->_supers['get']['companyId']; ?>
&branchId=<?php echo $this->_supers['get']['branchId']; ?>
"><button type="button" style="float:right;margin-top:-6PX" class="btn btn-create">List Sensor</button></a><?php if ($this->_tpl_vars['ListView']['0']['sl_no'] == ''): ?><br /><br /><?php endif; ?>
						<table id="example" class="table table-bordered table-hover">
						<thead>
						<tr>
						<th>#</th>
                        <th>Select</th>
						<th>Contact Person Name</th>
						<th>Mobile</th>
						<th>Email</th>
						
						</tr>
						</thead>
						<tbody>
						<?php $_from = $this->_tpl_vars['ListView']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['List']):
?>
						<tr id="<?php echo $this->_tpl_vars['j']++; ?>
">
						<td class="slNo"><?php echo $this->_tpl_vars['j']; ?>
</td>
                        <td class="slNo"><div class="custom-control custom-checkbox">
                        <?php $_from = $this->_tpl_vars['ListView1']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['person']):
?>
				            <?php if ($this->_tpl_vars['person']['contact_id'] == $this->_tpl_vars['List']['sl_no']): ?>
				                <?php $this->assign('personId', $this->_tpl_vars['person']['contact_id']); ?>
                            <?php endif; ?>
                        <?php endforeach; endif; unset($_from); ?>
                        
                            <input class="custom-control-input" type="checkbox" id="billingModule[<?php echo $this->_tpl_vars['j']; ?>
]"  name="billingModule" tabindex="8" <?php if ($this->_tpl_vars['personId'] == $this->_tpl_vars['List']['sl_no']): ?>checked="checked"<?php endif; ?> value="<?php echo $this->_tpl_vars['List']['sl_no']; ?>
">
							<label for="billingModule[<?php echo $this->_tpl_vars['j']; ?>
]" class="custom-control-label"></label>
					
                                </div></td>
						<td class="name"><?php echo $this->_tpl_vars['List']['person_name']; ?>
</td>
						<td class="mobile"><?php if ($this->_tpl_vars['List']['sms_alert'] == '1'): ?><span style="color:#009900"><b><?php echo $this->_tpl_vars['List']['mobile']; ?>
</b></span><?php else: ?><span style="color:#FF0000;"><b><?php echo $this->_tpl_vars['List']['mobile']; ?>
</b></span><?php endif; ?></td>
						<td class="email"><?php if ($this->_tpl_vars['List']['email_alert'] == '1'): ?><span style="color:#009900"><b><?php echo $this->_tpl_vars['List']['email']; ?>
</b></span><?php else: ?><span style="color:#FF0000;"><b><?php echo $this->_tpl_vars['List']['email']; ?>
</b></span><?php endif; ?></td>
						
						</tr>
						<?php endforeach; else: ?>
						<tr><td colspan="6"><center>No Records Found</center></td></tr>
						<?php endif; unset($_from); ?>
						</tbody>
						</table>
                        <div align="center">
							<center>
							<input type="submit" value="Submit" class="btn btn-create"  onclick="Validate();" />
							</center>
						</div>
					</div>
				</div>
			</div>
		</form>
	</section>
	</div>
	<?php echo '
	<style>
	.slNo{
	width:5%;
	}
	.name{
	width:15%;
	}
	.mobile{
	width:10%;
	}
	.email{
	width:20%;
	}
	.isactive{
	width:10%;
	text-align:center;
	}
	.action{
	text-align:right;
	}
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>
		<script type="text/javascript">
		$(document).ready(function (){
		
		var table = $(\'#example\').DataTable({
		"ordering" : false,
		language: {
		"infoFiltered": "",
		search: "_INPUT_",
		searchPlaceholder: "Search..."
		},
		dom: \'<"pull-left" f><bottom>p\',
		tableTools: {
		"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
		},
		//dom: \'<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p\',
		//dom: \'<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p\',
		buttons: [
		{
		text: \'Create Box\',
		className: \'btn btn-create\',
		titleAttr: \'Create Box\',
		action: function ( e, dt, button, config ) {
		window.location = \'AddEditBox.php\';
		}        
		}
		],
		initComplete: function(){
		$("div.toolbar").html(\'<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>\');   
		
		
		}       
		}); 
		
		}); 
		
		function editCats(slNoIdent,personIdent,mobIdent,compId,branId) {
		var sid = btoa(slNoIdent); var pid = btoa(personIdent); var mid = btoa(mobIdent);var cid = btoa(compId);var bid = btoa(branId);
		FormName		= document.contactMasterList;
		FormName.action =\'contactMasterAddEdit.php?person_name=\'+pid+\'&mobile=\'+mid+\'&sl_no=\'+sid+\'&companyId=\'+cid+\'&branchId=\'+bid+\'&Update=y\';
		FormName.submit();
		}
		
		</script>
		<script type="text/javascript">
		function deleteCats(slNoIdent,personIdent,mobIdent,compId,branId){
		var sid = btoa(slNoIdent); var pid = btoa(personIdent); var mid = btoa(mobIdent);var cid = btoa(compId);var bid = btoa(branId);
		if(confirm("Are you sure to Delete this Contact Person?")){
		FormName		= document.contactMasterList;
		FormName.action= \'contactMasterList.php?person_name=\'+pid+\'&mobile=\'+mid+\'&sl_no=\'+sid+\'&companyId=\'+cid+\'&branchId=\'+bid+\'&Delete=del\';
		FormName.submit();
		}
		}
		</script>
        <script type="text/javascript">
		function Validate()
		{
		var bar_code = [];
    $.each($("input[name=\'billingModule\']:checked"), function(){ 
	      bar_code.push($(this).val());  
	});
	id=bar_code.join(",");
	
	document.getElementById("item_id").value = id;
	if(id == \'\')
	{
	alert("Please Select Any contact Person");
	return false;
	}
	}
	/*function alertBox(id)
	{
	alert(id);
	}*/
		</script>
	'; ?>

	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>