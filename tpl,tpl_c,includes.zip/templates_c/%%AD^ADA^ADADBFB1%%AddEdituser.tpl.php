<?php /* Smarty version 2.6.25, created on 2026-10-05 21:54:27
         compiled from AddEdituser.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'date_format', 'AddEdituser.tpl', 128, false),)), $this); ?>
	<div class="content-wrapper">
		<section class="content-header">
			<div class="card">
				<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;"><?php if ($this->_tpl_vars['companyDetail']['0']['companyName'] != ""): ?><?php echo $this->_tpl_vars['companyDetail']['0']['companyName']; ?>
<?php else: ?><?php echo $this->_supers['session']['CompanyName']; ?>
<?php endif; ?>&nbsp;&nbsp;</td>
				<?php if ($this->_supers['get']['branchId']): ?>  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="font-size:15PX;font-weight: bold;"><?php echo $this->_tpl_vars['branchDetail']['0']['branch_name']; ?>
&ensp;&ensp;</td><?php endif; ?>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;"><?php if ($this->_supers['get']['userId'] == ""): ?>Create User<?php elseif ($this->_supers['get']['userId'] != "" && $this->_supers['get']['Update'] == 'y'): ?>Edit User <?php else: ?>Edit Profile <?php endif; ?>&nbsp;</td>
				</tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<?php if ($this->_supers['get']['branchId']): ?>  <td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="font-size:10PX;color:#999999;">Branch Name</td><?php endif; ?>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
				<?php if ($this->_tpl_vars['ListEditView']['0']['userGroup'] == 'Super Admin'): ?><a href="companyList.php"> <button type="button" class="btn btn-primary" value="List Company" style="float:right;margin-top:-40PX;">List Company</button></a><?php else: ?><a href="userList.php"> <button type="button" class="btn btn-primary" value="List User" style="float:right;margin-top:-40PX;">List User</button></a><?php endif; ?>
				</div>
			</div>
		<div class="card">
		<!--<div class="card-header">
				<h3 class="card-title"><?php if ($this->_supers['get']['userId'] == ""): ?>Create User<?php elseif ($this->_supers['get']['userId'] != "" && $this->_supers['get']['Update'] == 'y'): ?>Edit User <?php else: ?>Edit Profile <?php endif; ?></h3>
				<?php if ($this->_supers['session']['USER_GROUP'] == 'Super Admin'): ?>
				<a href="companyList.php"> <button type="button" class="btn btn-primary" value="List Company" style="float:right">List Company</button></a>
				<?php endif; ?>
				</div>-->
		<?php if ($this->_tpl_vars['SuccessMessage'] != ""): ?>
		<div class="card-body">
			<div class="isa_success">
			<i class="fa fa-check"></i>
			<?php echo $this->_tpl_vars['SuccessMessage']; ?>
		 
			</div>
		</div>
		<?php endif; ?>
		<?php if ($this->_tpl_vars['ErrorMessage'] != ""): ?>
		<div class="card-body">
			<div class="isa_error">
			<i class="fa fa-check"></i>
			<?php echo $this->_tpl_vars['ErrorMessage']; ?>
		 
			</div>
		</div>
		<?php endif; ?>
		
		<div class="card-body">
		<form name="userReg" id="userReg" method="post" role="form" enctype="multipart/form-data" onSubmit="return ValidateFields()">
		<input type="hidden" name="hdAction" id="hdAction">
		<input type="hidden" id="userId" name="userId" value="<?php echo $this->_tpl_vars['ListEditView']['0']['slNo']; ?>
" />
		<input type="hidden" id="companyId" name="companyId" value="<?php if ($this->_supers['get']['companyId'] == ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['company_id']; ?>
<?php else: ?><?php echo $this->_supers['get']['companyId']; ?>
<?php endif; ?>" />
		<input type="hidden" id="checkVal" name="checkVal" value="<?php echo $this->_supers['post']['checkVal']; ?>
" />
		<input type="text" id="textVal" name="textVal" value="<?php echo $this->_supers['post']['textVal']; ?>
" style="display:none;" />
		<input type="hidden" id="hdn_add_dtls" name="hdn_add_dtls" value="">
		<div class="row">
		<div class="form-group col-md-6">
		<label for="inputEmail3">Name <span class="required"><b>*</b></span></label>
		<input type="text" name="userName" class="form-control form-control-sm" id="userName" placeholder="Name" autocomplete="Off" tabindex="1" value="<?php if ($this->_tpl_vars['ListEditView']['0']['userName'] != ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['userName']; ?>
<?php endif; ?>">
		</div>
		
		<div class="form-group col-md-6">
		<label for="inputEmail3">Email Id <span class="required"><b>*</b></span></label>
		<input type="text" name="emailId" class="form-control form-control-sm" id="emailId" placeholder="Email Id" autocomplete="Off" tabindex="5" value="<?php if ($this->_tpl_vars['ListEditView']['0']['emailId'] != ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['emailId']; ?>
<?php endif; ?>" onblur="ValidateEmail(this);"  onChange="getcompany();">
		</div>
		<?php if ($this->_supers['get']['Update'] != 'p'): ?>
		<div class="form-group col-md-6">
		<label for="inputEmail3">User Group <span class="required"><b>*</b></span></label>
		<?php if ($this->_tpl_vars['ListEditView']['0']['userGroup'] == ""): ?>
		
			<select class="form-control form-control-sm" id="userGroup" name="userGroup" tabindex="2">
			<option value="0">--Select--</option>
			<?php $_from = $this->_tpl_vars['ListGroup']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['grp']):
?>
			<option value="<?php echo $this->_tpl_vars['grp']['usergroupName']; ?>
"><?php echo $this->_tpl_vars['grp']['usergroupName']; ?>
</option>
			<?php endforeach; endif; unset($_from); ?>
		</select>
		<?php else: ?>
		<select class="form-control form-control-sm" id="userGroup" name="userGroup" tabindex="2">
		<option id"<?php echo $this->_tpl_vars['ListEditView']['0']['userGroup']; ?>
" value="<?php echo $this->_tpl_vars['ListEditView']['0']['userGroup']; ?>
" selected="selected"><?php echo $this->_tpl_vars['ListEditView']['0']['userGroup']; ?>
</option>
		<?php $_from = $this->_tpl_vars['ListGroup']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['grp']):
?>
		<?php if ($this->_tpl_vars['ListEditView']['0']['userGroup'] != $this->_tpl_vars['grp']['usergroupName']): ?>
		<option value="<?php echo $this->_tpl_vars['grp']['usergroupName']; ?>
"><?php echo $this->_tpl_vars['grp']['usergroupName']; ?>
</option>
		<?php endif; ?>
		<?php endforeach; endif; unset($_from); ?>
		</select>
		<?php endif; ?>
		</div><?php else: ?>
		<input type="hidden" name="userGroup" id="userGroup" value="<?php echo $this->_tpl_vars['ListEditView']['0']['userGroup']; ?>
"/>
		<?php endif; ?>
		
		<div class="form-group col-md-6">
		<label for="inputEmail3">Phone</label>
		<input type="text" name="phone" class="form-control form-control-sm" id="phone" placeholder="Phone" autocomplete="Off" tabindex="6" onKeyUp="numericFilter(this);" value="<?php if ($this->_tpl_vars['ListEditView']['0']['phone'] != ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['phone']; ?>
<?php endif; ?>" maxlength="15">
		</div>
		<div class="form-group col-md-6">
		<label for="inputEmail3">Mobile No <span class="required"><b>*</b></span></label>
		<input type="text" name="mobileNo" class="form-control form-control-sm" id="mobileNo" placeholder="Mobile No" autocomplete="Off" tabindex="3" onKeyUp="numericFilter(this);" value="<?php if ($this->_tpl_vars['ListEditView']['0']['mobileNo'] != ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['mobileNo']; ?>
<?php endif; ?>" maxlength="10">
		</div>
		<div class="form-group col-md-6">
		<label for="inputEmail3">Password <span class="required"><b>*</b></span></label>
		<input type="password" name="password" class="form-control form-control-sm" id="password" placeholder="Password" autocomplete="Off" tabindex="7" value="<?php if ($this->_tpl_vars['ListEditView']['0']['password'] != ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['password']; ?>
<?php endif; ?>" onkeyup="check_length(this.value);" maxlength="8">
		</div>
		<div class="form-group col-md-6">
		<label for="inputEmail3">User Image </label>
		<input type="hidden" name="profileImageName" id="profileImageName" value="<?php if ($this->_tpl_vars['ListEditView']['0']['userImage'] != ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['userImage']; ?>
<?php endif; ?>">
		<?php if ($this->_tpl_vars['ListEditView']['0']['slNo'] != ''): ?> 
		<a href="images/UserImages/<?php echo $this->_tpl_vars['ListEditView']['0']['userImage']; ?>
" target="_blank"><img src="images/UserImages/<?php echo $this->_tpl_vars['ListEditView']['0']['userImage']; ?>
" width="100" height="100" id="imgFile" name="imgFile" /></a>
		<a href="#" onclick="Showfile();" id="edit" name="edit"><i class="fa fa-edit"></i></a>
		<input type="file"  id="profileImage" value="<?php echo $this->_supers['post']['profileImage']; ?>
" name="profileImage" accept="image/x-jpg,image/png" tabindex="4" autocomplete="Off" class="form-control form-control-sm" value="<?php echo $this->_tpl_vars['master_dtls']['userImage']; ?>
" style="display:none;" onblur="ValidateFields2('profileImage');"><span style="display:none; color:#FF0000; font-size:12px;" id="spanMsg">Only JPG,PNG images are allowed / Width * Height - 256 * 256 / Below - 500KB</span>
		<?php else: ?>
		<input type="file"  id="profileImage" value="<?php echo $this->_supers['post']['profileImage']; ?>
" name="profileImage" tabindex="4" accept="image/x-jpg,image/png" autocomplete="Off" class="form-control form-control-sm"><span style="color:#FF0000; font-size:12px;">Only JPG,PNG images are allowed / Width * Height - 256 * 256 / Below - 500KB</span>
		<?php endif; ?>
		</div>
		<div class="form-group col-md-6">
		<div class="custom-control custom-checkbox">
		<?php if ($this->_tpl_vars['ListEditView']['0']['userName'] != ''): ?>
		<?php if ($this->_tpl_vars['ListEditView']['0']['isActive'] == '1'): ?>
		<input class="custom-control-input" type="checkbox" id="customCheckbox2"  name="customCheckbox2" tabindex="8" checked="checked">
		<label for="customCheckbox2" class="custom-control-label">Is Active <span class="required"><b>*</b></span></label>
		<?php else: ?>
		<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="8">
		<label for="customCheckbox2" class="custom-control-label">Is Active <span class="required"><b>*</b></span></label>
		<?php endif; ?>
		<?php else: ?>
		<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="8" checked="checked">
		<label for="customCheckbox2" class="custom-control-label">Is Active <span class="required"><b>*</b></span></label>
		<?php endif; ?>
		</div>
		<input id="created_by" name="created_by" class="date-picker form-control" type="hidden" value="<?php echo $this->_supers['session']['UserName']; ?>
" readonly="true">
		<input type="hidden" class="form-control" id="timestamp" name="timestamp" value="<?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d &amp; %I:%M:%S %p') : smarty_modifier_date_format($_tmp, '%Y-%m-%d &amp; %I:%M:%S %p')); ?>
">
		<input type="hidden" class="form-control" id="created_time" name="created_time" placeholder="Time" Value="<?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%I:%M:%S %p') : smarty_modifier_date_format($_tmp, '%I:%M:%S %p')); ?>
">
		</div>
		</div>
		<div align="center">
		<center>
		<?php if ($this->_supers['get']['userId'] == ''): ?>
		<input type="submit" value="Submit" class="btn btn-create" tabindex="9" onclick="ValidateFields();" />		
		<?php else: ?>
		<input type="submit" value="Submit" class="btn btn-create" tabindex="9" onclick="ValidateFieldsImage();" />
		<?php endif; ?>
		</center>
		</div>
		</form>
		</div>
		</div>
		</section>	
	</div>
	<?php echo '
	<script type="text/javascript">
	function numericFilter(data)
	{
	data.value = data.value.replace(/[^.0-9^.+,-]/ig,"");
	}
	function text_filter(data)
	{
	data.value = data.value.replace(/[^ .a-z]/ig,"");
	}
	function Showfile()
	{
	document.getElementById(\'profileImage\').style.display="block";
	document.getElementById(\'imgFile\').style.display="none";
	document.getElementById(\'edit\').style.display="none";
	document.getElementById(\'spanMsg\').style.display="block";
	}
	
	function ValidateFields2(id)
	{
	var val = document.getElementById(id).value;
	if(val == \'\' || val == \'0\')
	{
	$(".error").remove();
	$("#"+id).after(\'<span class="error">This field is required</span>\');
	$("#"+id).focus();
	return false;		
	}
	else
	{
	$(".error").remove();
	return true;
	}
	}
	</script>
	<script type="text/javascript">
	function ValidateFields()	
	{
	var userName = $(\'#userName\').val();
	var userGroup = $(\'#userGroup\').val();
	var mobileNo = $(\'#mobileNo\').val();
	var emailId = $(\'#emailId\').val();	
	var password = $(\'#password\').val();
	var isActive = document.getElementById("customCheckbox2").checked;
	var company_name = $(\'#textVal\').val();
	var mailformat = /^[a-zA-Z0-9.!#$%&\'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*$/;
	if (isActive == false) 
	{
	document.getElementById(\'checkVal\').value=\'0\';
	}
	else
	{
	document.getElementById(\'checkVal\').value=\'1\';
	}
	$(".error").remove();
	if (userName.length < 1) {
	$(\'#userName\').after(\'<span class="error">This field is required</span>\');
	$(\'#userName\').focus();
	return false;					
	}
	else if (userGroup == \'0\') {
	$(\'#userGroup\').after(\'<span class="error">This field is required</span>\');
	$(\'#userGroup\').focus();
	return false;					
	}
	else if (mobileNo.length < 1) {
	$(\'#mobileNo\').after(\'<span class="error">This field is required</span>\');
	$(\'#mobileNo\').focus();
	return false;					
	}
	else if (mobileNo.length < 10) {
	$(\'#mobileNo\').after(\'<span class="error">Mobile Number should be 10 digits</span>\');
	$(\'#mobileNo\').focus();
	return false;					
	}
	else if (emailId.length < 1) {
	$(\'#emailId\').after(\'<span class="error">This field is required</span>\');
	$(\'#emailId\').focus();
	return false;					
	}
	else if(!mailformat.test(emailId)) {
	$("#emailId").after(\'<span class="error">Enter a valid email address.</span>\');
	$(\'#emailId\').focus();
	return false;	
    }
	else if (password.length < 1) {
	$(\'#password\').after(\'<span class="error">This field is required</span>\');
	$(\'#password\').focus();
	return false;					
	}
	else if (password.length < 6) {
	$(\'#password\').after(\'<span class="error">Password length should be between 6 and 8 character</span>\');
	$(\'#password\').focus();
	return false;					
	}
	else if(company_name == emailId)
	{
	$(\'#emailId\').after(\'<span class="error">Email ID already exist</span>\');
	$(\'#emailId\').focus();
	return false;
	}
	userReg.hdAction.value = 1;
	return true;
	}
	</script>
	<script type="text/javascript">
	function getcompany()
	{
	var company_name=document.getElementById("emailId").value;
	if (window.XMLHttpRequest)
	{
	xmlhttp=new XMLHttpRequest();
	}	
	else
	{
	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange=function()
	{
	if (xmlhttp.readyState==4 && xmlhttp.status==200)
	{
	var x;
	if(xmlhttp.responseText)
	{
	x=xmlhttp.responseText;
	document.getElementById("hdn_add_dtls").value=x;
	var add_dtls=x.split("_");
	document.getElementById("textVal").value=add_dtls[0];
	var ename=document.getElementById("textVal").value;
	if(company_name == ename)
	{
	$(\'#emailId\').after(\'<span class="error">Email ID already exist</span>\');
	$(\'#emailId\').focus();
	return false;
	}
	else
	{
	return true;
	}
	}
	else
	{
	document.getElementById("emailId").innerHTML="<option value=\'0\'>Please select Company Name</option>";
	}
	}
	}
	xmlhttp.open("GET","AddEdituser.php?bill_from="+company_name,true);
	xmlhttp.send();
	}
	</script>
	<script type="text/javascript">	
	function GoBack()
	{
	window.history.back();
	}
	</script>
	<script type="text/javascript">
	function check_length(val)
	{$(".error").remove();
	var test = val.length;
	if(test >= \'6\' && test <= \'8\')
	{
	$(".error").remove();
	return true;
	}
	else
	{
	$(\'#password\').after(\'<span class="error">Password length should be between 6 and 8 character</span>\');
	$(\'#password\').focus();
	return false;
	}
	}
	</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}	
	.required
	{
	color:#FF0000;
	}
	</style>
	'; ?>

	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>