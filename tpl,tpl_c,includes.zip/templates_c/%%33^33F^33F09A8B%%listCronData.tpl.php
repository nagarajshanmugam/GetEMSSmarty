<?php /* Smarty version 2.6.25, created on 2026-02-11 13:31:14
         compiled from listCronData.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'date_format', 'listCronData.tpl', 47, false),)), $this); ?>
	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;"><?php if ($this->_tpl_vars['companyDetail']['0']['companyName'] != ""): ?><?php echo $this->_tpl_vars['companyDetail']['0']['companyName']; ?>
<?php else: ?><?php echo $this->_supers['session']['CompanyName']; ?>
<?php endif; ?>&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">List Cron Data</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			</div>
		</div>
		<form name="meterList" method="post" id="meterList">
		<div class="row">
			<div class="col-12">
				<div class="card">
				<?php if ($this->_tpl_vars['SuccessMessage'] != "" || $this->_tpl_vars['ErrorMessage'] != ""): ?>
					<div class="card-body">
					<?php if ($this->_tpl_vars['SuccessMessage'] != ""): ?>
						<div class="isa_success">
						<i class="fa fa-check"></i>
						<?php echo $this->_tpl_vars['SuccessMessage']; ?>
		 
						</div>
					<?php endif; ?>
					<?php if ($this->_tpl_vars['ErrorMessage'] != ""): ?>
						<div class="isa_error">
						<i class="fa fa-check"></i>
						<?php echo $this->_tpl_vars['ErrorMessage']; ?>
		 
						</div>
					<?php endif; ?>
					</div>
				<?php endif; ?>
					<div class="card-body table-responsive">
						<div class="col-sm-3"  style="float:right;margin-top:12PX">
						<select class="form-control" id="sensorName" name="sensorName"  tabindex="1"  >
						<?php if ($this->_supers['post']['sensorName'] == ''): ?>
						<option value="">--  Select Feeder  --</option>
						<?php endif; ?>
						<?php $_from = $this->_tpl_vars['ListSensorView']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['ListMod']):
?>
						<?php if ($this->_supers['post']['sensorName'] == $this->_tpl_vars['ListMod']['sensorCode']): ?><option value="<?php echo $this->_tpl_vars['ListMod']['sensorCode']; ?>
" selected="selected"><?php echo $this->_tpl_vars['ListMod']['sensorName']; ?>
</option><?php endif; ?>
						<?php if ($this->_supers['post']['sensorName'] != $this->_tpl_vars['ListMod']['sensorCode']): ?><option value="<?php echo $this->_tpl_vars['ListMod']['sensorCode']; ?>
"><?php echo $this->_tpl_vars['ListMod']['sensorName']; ?>
</option><?php endif; ?>
						<?php endforeach; endif; unset($_from); ?>
						</select>
						</div>&nbsp;&nbsp;<div class="col-sm-2"  style="float:right;margin-top:-7PX" > To Date: <input type="text" id="toDate" name="toDate" value="<?php if ($this->_supers['post']['sensorName'] != '' && $this->_supers['post']['toDate'] == ''): ?><?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d') : smarty_modifier_date_format($_tmp, '%Y-%m-%d')); ?>
<?php elseif ($this->_supers['post']['sensorName'] != '' && $this->_supers['post']['toDate'] != ''): ?><?php echo $this->_supers['post']['toDate']; ?>
<?php endif; ?>" class="form-control" autocomplete="off" readonly="true"></div>&nbsp;&nbsp;<div class="col-sm-2"  style="float:right;margin-top:-7PX">From Date: <input type="text" id="fromDate" name="fromDate" value="<?php if ($this->_supers['post']['sensorName'] != '' && $this->_supers['post']['fromDate'] == ''): ?><?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-01') : smarty_modifier_date_format($_tmp, '%Y-%m-01')); ?>
<?php elseif ($this->_supers['post']['sensorName'] != '' && $this->_supers['post']['fromDate'] != ''): ?><?php echo $this->_supers['post']['fromDate']; ?>
<?php endif; ?>" class="form-control" autocomplete="off" readonly="true" ></div>
					<?php if ($this->_tpl_vars['ListPostData']['0']['recorded_date'] == ''): ?><p>&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;<br /></p><?php endif; ?>
					<table id="example" class="table table-bordered table-hover">
					<thead>
					<tr>
					<th class="slNo">#</th>
					<th class="">Date</th>
					<th class="">Start Kwh</th>
					<th class="">End Kwh</th>
					<th class="">Total Kwh</th>
					<th class="">Unit Rate</th>
					<th class="">Total Cost</th>
					<th>Action</th>
					</tr>
					</thead>
					<tbody>
					<?php $_from = $this->_tpl_vars['ListPostData']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['List']):
?>
					<?php if ($this->_tpl_vars['List']['recorded_date'] <= ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d') : smarty_modifier_date_format($_tmp, '%Y-%m-%d'))): ?>
					<tr id="<?php echo $this->_tpl_vars['j']++; ?>
">
					<td ><?php echo $this->_tpl_vars['j']; ?>
</td>
					<td><?php echo ((is_array($_tmp=$this->_tpl_vars['List']['recorded_date'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%e-%b-%Y") : smarty_modifier_date_format($_tmp, "%e-%b-%Y")); ?>
</td>
					<td id="skwh<?php echo $this->_tpl_vars['j']; ?>
"><script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['List']['start_cum_kwh']; ?>
','skwh<?php echo $this->_tpl_vars['j']; ?>
');</script></td>
					<td id="ekwh<?php echo $this->_tpl_vars['j']; ?>
"><script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['List']['end_cum_kwh']; ?>
','ekwh<?php echo $this->_tpl_vars['j']; ?>
');</script></td>
					<td id="ckwh<?php echo $this->_tpl_vars['j']; ?>
"><script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['List']['consuption_kwh']; ?>
','ckwh<?php echo $this->_tpl_vars['j']; ?>
');</script></td>
					<td id="cost<?php echo $this->_tpl_vars['j']; ?>
"><script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['List']['cost']; ?>
','cost<?php echo $this->_tpl_vars['j']; ?>
');</script></td>
					<td id="ccost<?php echo $this->_tpl_vars['j']; ?>
"><script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['List']['consuption_cost']; ?>
','ccost<?php echo $this->_tpl_vars['j']; ?>
');</script></td>
					<td align="right">
					<?php if ($this->_tpl_vars['List']['manual_update'] == '1'): ?><span style="color:#FF0000; font-weight:bold"> Cron Completed</span><?php else: ?>
					<a href="#"  onClick="Javascript:editCats('<?php echo $this->_tpl_vars['List']['recorded_date']; ?>
','<?php echo $this->_tpl_vars['List']['sensor_code']; ?>
','<?php echo $this->_supers['session']['UserName']; ?>
')" title="Run Manual Cron"><i class="fa fa-recycle"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php endif; ?>
					</td>
					</tr>
					<?php endif; ?>
					<?php endforeach; else: ?>
					<tr><td colspan="8"><center>No Records Found</center></td></tr>
					<?php endif; unset($_from); ?>
					</tbody>
					</table>
					</div>
				
				<!-- /.card-body -->
				</div>
			<!-- /.card -->
			</div>
		</form>
	</section>
	<!-- /.content -->
	</div>
	<!-- /.content-wrapper -->
	<?php echo '
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	<link rel="stylesheet" href="/resources/demos/style.css">
	<!--  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	-->  <script>
	$( function() {
	$( "#fromDate" ).datepicker({changeMonth: true,
	changeYear: true,maxDate: \'0\',dateFormat:\'yy-mm-dd\'});
	$( "#toDate" ).datepicker({changeMonth: true,
	changeYear: true,maxDate: \'0\',dateFormat:\'yy-mm-dd\'});
	} );
	</script>
	<script type="text/javascript">
	
	$(document).ready(function() {
	$(\'#sensorName\').on(\'change\', function() {
	this.form.submit();
	});
	});
	
	</script>
	<style>
	.slNo{
	width:5%;
	}
	.code{
	width:10%;
	}
	.apiKey{
	width:30%;
	}
	.name{
	width:40%;
	}
	.isactive{
	width:10%;
	text-align:center;
	
	}
	.action{
	text-align:right;
	}
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	/*background-color:#FFBABA;*/
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	/*vertical-align:middle;*/
	}
	</style>
	<script type="text/javascript">
	$(document).ready(function (){
	
	var table = $(\'#example\').DataTable({
	"ordering" : false,
	"pageLength": 50,
	language: {
	"infoFiltered": "",
	search: "_INPUT_",
	searchPlaceholder: "Search..."
	},
	dom: \'<"pull-left" f><bottom>p\',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: \'<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p\',
	//dom: \'<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p\',
	
	initComplete: function(){
	//  $("div.toolbar").html(\'<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>\');   
	
	
	}       
	}); 
	
	}); 
	
	function editCats(recordedDate,sensorCode,userName) 
	{
	var sid = recordedDate;
	var mid = sensorCode;  
	var comId = userName; 
	$.ajax({
	type: "POST",
	url: "cronEnergyMeterData.php",
	data: {recorded_date:recordedDate,sensor_code:sensorCode,userName:userName},
	dataType: "text",
	cache: false,
	success: function(result){
	var len = result.length;
	//$("#testDate").val(result);
	//alert(result);
	location.reload(true);
	},
	error: function(result) {
	alert(\'error\');
	}
	});
	}
	
	</script>
	<script type="text/javascript">
	function deleteCats(slNoIdent,serialIdIdent,compIdent,branIdent,gateIdent){
	var sid = btoa(slNoIdent); var scId = btoa(serialIdIdent);var comId = btoa(compIdent); var gId = btoa(gateIdent);var bId = btoa(branIdent);
	if(confirm("Are you sure to Delete this Content?")){
	FormName		= document.meterList;
	FormName.action= \'sensorList.php?gatewayId=\'+gId+\'&companyId=\'+comId+\'&branchId=\'+bId+\'&sl_no=\'+sid+\'&sen_code=\'+scId;
	FormName.submit();
	}
	}
	
	</script>
	'; ?>

	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>