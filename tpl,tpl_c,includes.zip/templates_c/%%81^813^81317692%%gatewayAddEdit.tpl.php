<?php /* Smarty version 2.6.25, created on 2025-11-15 14:24:20
         compiled from gatewayAddEdit.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'date_format', 'gatewayAddEdit.tpl', 96, false),)), $this); ?>
	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;"><?php if ($this->_tpl_vars['companyDetail']['0']['companyName'] != ""): ?><?php echo $this->_tpl_vars['companyDetail']['0']['companyName']; ?>
<?php else: ?><?php echo $this->_supers['session']['CompanyName']; ?>
<?php endif; ?>&nbsp;&nbsp;</td>
				<?php if ($this->_supers['get']['branchId']): ?>  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="font-size:15PX;font-weight: bold;"><?php echo $this->_tpl_vars['branchDetail']['0']['branch_name']; ?>
&ensp;&ensp;</td><?php endif; ?>
					<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;"><?php if ($this->_supers['get']['sl_no'] == ""): ?>Create Gateway<?php else: ?>Edit Gateway<?php endif; ?></font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				</tr>
				</table>
			<a href="gatewayList.php?companyId=<?php echo $this->_supers['get']['companyId']; ?>
&branchId=<?php echo $this->_supers['get']['branchId']; ?>
"><button type="button" style="float:right;;margin-top:-40Px" class="btn btn-primary">List Gateway</button></a>
			</div>
		</div>
	<div class="card ">
		<div class="card-body">
			<form role="form" name="gatewayRegForm" id="gatewayRegForm" method="post" onsubmit="return createValidation();" >
				<input type="hidden" name="hdAction" />
				<input type="hidden" id="check_id" name="check_id" value="<?php echo $this->_supers['post']['check_id']; ?>
">
				<input type="hidden" id="checkVal" name="checkVal" value="<?php echo $this->_supers['post']['checkVal']; ?>
" />
				<input type="hidden" id="company_id" name="company_id" value="<?php echo $this->_supers['get']['companyId']; ?>
" />
				<input type="hidden" id="branch_id" name="branch_id" value="<?php echo $this->_supers['get']['branchId']; ?>
" />
				<input type="hidden" id="oldModel" name="oldModel" value="<?php echo $this->_tpl_vars['ListEditView']['0']['model']; ?>
" />
				<input type="hidden" id="gateWayId" name="gateWayId" value="<?php echo $this->_tpl_vars['ListEditView']['0']['gateway_id']; ?>
" />
				
				<div class="row ">
					<div class="form-group col-md-6">
					<label for="exampleInputmodel">Model <span style="color:red;">*</span></label>
						<select class="form-control form-control-sm" id="model" name="model" >
						<?php if ($this->_tpl_vars['ListEditView']['0']['model'] == ""): ?>
							<option value="">-- Select Model --</option>
						<?php endif; ?>
						<?php $_from = $this->_tpl_vars['exeMod']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['modList']):
?>
						<?php if ($this->_tpl_vars['ListEditView']['0']['model'] == $this->_tpl_vars['modList']['model_code']): ?>
						<option value="<?php echo $this->_tpl_vars['ListEditView']['0']['model']; ?>
" selected="selected"><?php echo $this->_tpl_vars['modList']['model_name']; ?>
</option>
						<?php endif; ?>
						<?php if ($this->_tpl_vars['ListEditView']['0']['model'] != $this->_tpl_vars['modList']['model_code']): ?>
							<option value="<?php echo $this->_tpl_vars['modList']['model_code']; ?>
"><?php echo $this->_tpl_vars['modList']['model_name']; ?>
</option>
						<?php endif; ?>
						<?php endforeach; endif; unset($_from); ?>
						</select>
					</div>
					<div class="col-md-3">&nbsp;</div>
					<div class="col-md-3">&nbsp;</div>
						<div class="form-group col-md-6">
							<label for="exampleInputserialNo">Serial No <!--<span style="color:red;">*</span>--></label>
							<input type="text" class="form-control form-control-sm" id="serialNo" name="serialNo" placeholder="Enter Serial No" value="<?php if ($this->_tpl_vars['ListEditView']['0']['serial_no'] != ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['serial_no']; ?>
<?php endif; ?>"> <p style="color:red">* Example : Gateway Serial No *</p>
						</div>
					<div class="col-md-3">&nbsp;</div>
					<div class="col-md-3">&nbsp;</div>
					<div class="form-group col-md-6" style="margin-top:-20PX">
						<label for="exampleInputInstall">Place Of Installation <span style="color:red;">*</span></label>
						<input type="text" class="form-control form-control-sm" id="instPlace" name="instPlace" placeholder="Place Of Installation" value="<?php if ($this->_tpl_vars['ListEditView']['0']['place_of_installation'] != ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['place_of_installation']; ?>
<?php endif; ?>">
					</div>
				<div class="col-md-3">&nbsp;</div>
				<div class="col-md-3">&nbsp;</div>
					<div class="form-group col-md-6">
					<label for="exampleInputmodel">Internet Type <span style="color:red;">*</span></label>
						<select class="form-control form-control-sm" id="internet_type" name="internet_type" >
						<?php if ($this->_tpl_vars['ListEditView']['0']['internet_type'] != ""): ?>
							<option value="<?php echo $this->_tpl_vars['ListEditView']['0']['internet_type']; ?>
" ><?php echo $this->_tpl_vars['ListEditView']['0']['internet_type']; ?>
</option><?php else: ?>
							<option value="">-- Select Internet Type --</option>
						<?php endif; ?>
							<option value="4G">4G</option>
							<option value="Wifi">Wifi</option>
							<option value="Ethernet">Ethernet</option>
						</select>
					</div>
				<div class="col-md-3">&nbsp;</div>
				<div class="col-md-3">&nbsp;</div>
					<div class="form-group col-md-6">
						<label>Remarks<span style="color:red;">*</span></label>
						<textarea class="form-control form-control-sm" rows="3" name="description" id="description" placeholder="Mobile No/ Wifi Details /Ethernet Details" ><?php if ($this->_tpl_vars['ListEditView']['0']['description'] != ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['description']; ?>
<?php endif; ?></textarea>
					</div>
				<div class="col-md-3">&nbsp;</div>
				<div class="col-md-3">&nbsp;</div>
					<div class="form-group col-md-6">
						<div class="custom-control custom-checkbox">
						<?php if ($this->_tpl_vars['ListEditView']['0']['is_active'] == '1' && $this->_tpl_vars['ListAlertGatewayView']['0']['gateway_id'] == $this->_tpl_vars['ListEditView']['0']['gateway_id']): ?>
							<input class="custom-control-input" type="checkbox" id="customCheckbox2"  name="customCheckbox2" tabindex="4" checked="checked" disabled>
							<label for="customCheckbox2" class="custom-control-label">Is Active</label>
						<?php elseif ($this->_tpl_vars['ListEditView']['0']['is_active'] == '0'): ?>
							<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="4">
							<label for="customCheckbox2" class="custom-control-label">Is Active</label>
						<?php else: ?>
							<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="4" checked="checked">
							<label for="customCheckbox2" class="custom-control-label">Is Active</label>
						<?php endif; ?>
						</div>
						<input id="created_by" name="created_by" class="date-picker form-control" type="hidden" value="<?php echo $this->_supers['session']['UserName']; ?>
" readonly="true">
						<input type="hidden" class="form-control" id="timestamp" name="timestamp" value="<?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d &amp; %I:%M:%S %p') : smarty_modifier_date_format($_tmp, '%Y-%m-%d &amp; %I:%M:%S %p')); ?>
">
						<input type="hidden" class="form-control" id="created_time" name="created_time" placeholder="Time" Value="<?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%I:%M:%S %p') : smarty_modifier_date_format($_tmp, '%I:%M:%S %p')); ?>
">
					</div>
				</div>
				<div class="col-md-6"align="center">
					<input type="submit" value="Submit" class="btn btn-create" />
				</div>
			</form>
		</div>
	</div>
	</div>
	</section>
	</div>
	<?php echo '
		<script type="text/javascript">
		function createValidation(){
		var model = $(\'#model\').val();
		var instPlace = $(\'#instPlace\').val();
		var internet_type = $(\'#internet_type\').val();
		var description = $(\'#description\').val();
		var isActive = document.getElementById("customCheckbox2").checked;
		if (isActive == false) 
		{
			document.getElementById(\'checkVal\').value=\'0\';
		}
		else
		{
			document.getElementById(\'checkVal\').value=\'1\';
		}
		$(".error").remove();
		if (model < 1) {
			$(\'#model\').after(\'<span class="error">This field is required</span>\');
			$(\'#model\').focus();
			return false;					
		}
		else if (instPlace < 1) {
			$(\'#instPlace\').after(\'<span class="error">This field is required</span>\');
			$(\'#instPlace\').focus();
			return false;					
		}
		else if (internet_type < 1) {
			$(\'#internet_type\').after(\'<span class="error">This field is required</span>\');
			$(\'#internet_type\').focus();
			return false;					
		}
		else if (description < 1) {
			$(\'#description\').after(\'<span class="error">This field is required</span>\');
			$(\'#description\').focus();
			return false;					
		}
			FormName		= document.gatewayRegForm;
			FormName.method	= "POST";
			FormName.submit();
		}
		function GoBack()
		{
			window.history.back();
		}
		</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	'; ?>

	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>