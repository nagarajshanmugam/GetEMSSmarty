<?php /* Smarty version 2.6.25, created on 2026-09-30 11:37:31
         compiled from feederAlertParameter.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'base64_encode', 'feederAlertParameter.tpl', 112, false),)), $this); ?>
	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;"><?php if ($this->_tpl_vars['companyDetail']['0']['companyName'] != ""): ?><?php echo $this->_tpl_vars['companyDetail']['0']['companyName']; ?>
<?php else: ?><?php echo $this->_supers['session']['CompanyName']; ?>
<?php endif; ?>&nbsp;&nbsp;</td>
				<?php if ($this->_supers['get']['branchId']): ?>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;"><?php echo $this->_tpl_vars['branchDetail']['0']['branch_name']; ?>
&ensp;&ensp;</td>
				<?php endif; ?>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;"><?php if ($this->_supers['get']['sl_no'] == ""): ?>Create Alert Parameter<?php else: ?>Edit Alert Parameter<?php endif; ?></font>&nbsp;</td></tr>	
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			<?php if ($this->_supers['get']['sl_no'] == "" && $this->_supers['session']['USER_GROUP'] == 'Branch Admin'): ?> <a href="feederList.php?companyId=<?php echo $this->_supers['get']['companyId']; ?>
&gatewayId=<?php echo $this->_supers['get']['gatewayId']; ?>
&branchId=<?php echo $this->_supers['get']['branchId']; ?>
"><button type="button" style="float:right;margin-top:-40PX" class="btn btn-primary">List <?php if ($this->_supers['session']['COMPANY_ID'] != '4'): ?>Feeder<?php else: ?>Sensor<?php endif; ?></button></a><?php else: ?>
	<?php if ($this->_supers['session']['USER_GROUP'] == 'Branch Admin'): ?>	<a href="feederList.php?companyId=<?php echo $this->_supers['get']['companyId']; ?>
&branchId=<?php echo $this->_supers['get']['branchId']; ?>
"><button type="button" style="float:right;;margin-top:-40PX" class="btn btn-primary" >List <?php if ($this->_supers['session']['COMPANY_ID'] != '4'): ?>Feeder<?php else: ?>Sensor<?php endif; ?></button></a><?php endif; ?>
			<?php endif; ?>
			</div>
		</div>
		<div class="card">
			<div class="card-body">
				<form role="form" name="alertParameterReg" id="alertParameterReg" method="post" onsubmit="return createValidation();" >
					<input type="hidden" name="hdAction" />
				<?php if ($this->_supers['get']['sl_no'] != ""): ?>
					<input type="hidden" id="sensor_id" name="sensor_id" value="<?php echo $this->_tpl_vars['EditViewFeedForm']['0']['sensorCode']; ?>
" />
					<input type="hidden" id="gateway_id" name="gateway_id" value="<?php echo $this->_tpl_vars['EditViewFeedForm']['0']['gateway_id']; ?>
" />
					<input type="hidden" id="company_id" name="company_id" value="<?php echo $this->_tpl_vars['EditViewFeedForm']['0']['company_id']; ?>
" />
					<input type="hidden" id="branch_id" name="branch_id" value="<?php echo $this->_tpl_vars['EditViewFeedForm']['0']['branch_id']; ?>
" />
					<input type="hidden" id="sensor_model_id" name="sensor_model_id" value="<?php echo $this->_tpl_vars['EditViewFeedForm']['0']['sl_no']; ?>
" />
				<?php else: ?>
					<input type="hidden" id="sensor_id" name="sensor_id" value="<?php echo $this->_tpl_vars['EditViewFeedForm']['0']['sensorCode']; ?>
" />
					<input type="hidden" id="gateway_id" name="gateway_id" value="<?php echo $this->_tpl_vars['EditViewFeedForm']['0']['gateway_id']; ?>
" />
					<input type="hidden" id="company_id" name="company_id" value="<?php echo $this->_tpl_vars['EditViewFeedForm']['0']['company_id']; ?>
" />
					<input type="hidden" id="branch_id" name="branch_id" value="<?php echo $this->_tpl_vars['EditViewFeedForm']['0']['branch_id']; ?>
" />
					<input type="hidden" id="sensor_model_id" name="sensor_model_id" value="<?php echo $this->_tpl_vars['EditViewFeedForm']['0']['sl_no']; ?>
" />
				<?php endif; ?>
					<input type="hidden" id="check_id" name="check_id" value="<?php echo $this->_supers['post']['check_id']; ?>
">
					<input type="hidden" id="checkVal" name="checkVal" value="<?php echo $this->_supers['post']['checkVal']; ?>
" />
					<div class="row">				
						<div class="form-group col-md-6" >
							<label for="exampleInputmeterName">Sensor Name  /  Installation Place<span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm" id="feederName" name="feederName" placeholder="Enter Feeder Name" value="<?php if ($this->_tpl_vars['EditViewFeedForm']['0']['sensorName'] != ""): ?> <?php echo $this->_tpl_vars['EditViewFeedForm']['0']['sensorName']; ?>
<?php endif; ?>" autocomplete="Off"  readonly="true">
						</div>
						<div class="form-group col-md-6" >
							<label for="exampleInputmeterName">Sensor Model Name <span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm"  value="<?php if ($this->_tpl_vars['EditViewFeedForm']['0']['model_name'] != ""): ?> <?php echo $this->_tpl_vars['EditViewFeedForm']['0']['model_name']; ?>
<?php endif; ?>" autocomplete="Off"  readonly="true">
						</div>
						<div class="form-group col-md-6" >
							<label for="exampleInputmeterName">Parameter<span style="color:red;">*</span></label>
							<select name="parameterName" class="form-control form-control-sm" id="parameterName"  tabindex="1">
							<option value="" >-- Select Parameter --</option>
						<?php $_from = $this->_tpl_vars['sensorParam']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['ListPlat']):
?>
							<option value="<?php echo $this->_tpl_vars['ListPlat']['parameter_name']; ?>
"><?php echo $this->_tpl_vars['ListPlat']['parameter_name']; ?>
</option>
						<?php endforeach; endif; unset($_from); ?>
							</select>
						</div>
						<div class="form-group col-md-6 hideDiv"  style="display:none">
							<label for="exampleInputmeterName">Min Alert Value  <span style="color:red;">*</span></label>
							<input type="text" class="form-control" id="minAlertValue" name="minAlertValue" placeholder="Min Alert Value" value="" autocomplete="Off" tabindex="2" onKeyUp="numericFilter(this);">
						</div>
						<div class="form-group col-md-6 hideDiv"  style="display:none" >
						<label for="exampleInputmeterName">Max Alert Value <span style="color:red;">*</span></label>
						<input type="text" class="form-control" id="maxAlertValue" name="maxAlertValue" placeholder="Max Alert Value" value="" autocomplete="Off" tabindex="3" onKeyUp="numericFilter(this);">
					</div>
					</div>
					<div align="center">
					<input type="submit" value="Submit" class="btn btn-create" tabindex="6"/>
					</div>
				</form>
			<br/>
			<?php if ($this->_tpl_vars['SuccessMessage'] != "" || $this->_tpl_vars['ErrorMessage'] != ""): ?>
				<div class="card-body">
				<?php if ($this->_tpl_vars['SuccessMessage'] != ""): ?>
					<div class="isa_success">
					<i class="fa fa-check"></i>
					<?php echo $this->_tpl_vars['SuccessMessage']; ?>
		 
					</div>
				<?php endif; ?>
				<?php if ($this->_tpl_vars['ErrorMessage'] != ""): ?>
					<div class="isa_error">
					<i class="fa fa-check"></i>
					<?php echo $this->_tpl_vars['ErrorMessage']; ?>
		 
					</div>
				<?php endif; ?>
				</div>
			<?php endif; ?>
				<form name="parameterList" method="post" id="parameterList">
					<input type="hidden" id="hdAction2" name="hdAction2">
					<table id="example" class="table table-bordered table-hover">
					<thead>
					<tr>
					<th class="slNo">#</th>
					<th class="name">Parameter Name</th>
					<th class="type">Min Alert Value</th>
					<th class="name">Max Alert Value</th>
					<th>Action</th>
					</tr>
					</thead>
					<tbody>
					<?php $_from = $this->_tpl_vars['alertParameterList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['List']):
?>
					<tr id="<?php echo $this->_tpl_vars['j']++; ?>
">
					<td ><?php echo $this->_tpl_vars['j']; ?>
</td>
					<td><?php echo $this->_tpl_vars['List']['parameter_name']; ?>
</td>
					<td align="right"><?php echo $this->_tpl_vars['List']['min_alert_value']; ?>
</td>
					<td align="right"><?php echo $this->_tpl_vars['List']['max_alert_value']; ?>
</td>
					<td align="right">
					<a href="#"  onClick="Javascript:deleteCats('<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['alert_parameter_id'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
')" title="Delete"><i class="fa fa-trash"></i></a>
					</td>
					</tr>
					<?php endforeach; else: ?>
					<tr><td colspan="6"><center>No Records Found</center></td></tr>
					<?php endif; unset($_from); ?>
					</tbody>
					</table>
				</form>
			</div>
		</div>
	</div>
	</section>
	</div>
	<?php echo '
	<script type="text/javascript">
	$(\'#parameterName\').on(\'change\', function() {
		$(\'.hideDiv\').show();
	});
	$(document).ready(function(){
		$("#mainMeter").hide();
		$("#subMeter").hide();
		$("#Meter").hide();
	});
	</script>
	<script type="text/javascript">
	function deleteCats(slNoIdent){
		var url= window.location.href;
		var resSplit = url.split("&succ");
		var passUrl=resSplit[0];
		if(confirm("Are you sure to Delete this Alert Parmeter?")){
		FormName		= document.parameterList;
		FormName.action= passUrl+\'&Delete=\'+slNoIdent;
		FormName.submit();
		}
	}
	</script>
	<script type="text/javascript">
	function numericFilter(data)
	{
	data.value = data.value.replace(/[^.0-9^.+,-]/ig,"");
	}
	function text_filter(data)
	{
	data.value = data.value.replace(/[^ .a-z]/ig,"");
	
	}
	function createValidation(){
		var parameterName = $(\'#parameterName\').val();
		var minAlertValue = $(\'#minAlertValue\').val();
		var maxAlertValue = $(\'#maxAlertValue\').val();
		$(".error").remove();
	if (parameterName < 1) {
		$(\'#parameterName\').after(\'<span class="error">This field is required</span>\');
		$(\'#parameterName\').focus();
		return false;					
	}
	else if (minAlertValue < 1) {
		$(\'#minAlertValue\').after(\'<span class="error">This field is required</span>\');
		$(\'#minAlertValue\').focus();
		return false;					
	}
	else if (maxAlertValue < 1) {
		$(\'#maxAlertValue\').after(\'<span class="error">This field is required</span>\');
		$(\'#maxAlertValue\').focus();
		return false;					
	}
		FormName = document.alertParameterReg;
		FormName.method = "POST";
		FormName.submit();
	}
	function GoBack()
	{
		window.history.back();
	}
	</script>
	<script type="text/javascript">
	function locationDecode(){
		var lid = {$smarty.get.location_id};
		var uri_lid = decodeURIComponent(lid);
		alert(uri_lid);
	}
	</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	'; ?>

	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>