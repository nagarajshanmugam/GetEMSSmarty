<?php /* Smarty version 2.6.25, created on 2025-12-12 12:43:28
         compiled from locationList.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'truncate', 'locationList.tpl', 70, false),)), $this); ?>
	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;"><?php if ($this->_tpl_vars['companyDetail']['0']['companyName'] != ""): ?><?php echo $this->_tpl_vars['companyDetail']['0']['companyName']; ?>
<?php else: ?><?php echo $this->_supers['session']['CompanyName']; ?>
<?php endif; ?>&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;"><?php if ($this->_tpl_vars['ListBranchGet']['0']['branch_name'] != ""): ?><?php echo $this->_tpl_vars['ListBranchGet']['0']['branch_name']; ?>
<?php else: ?><?php echo $this->_supers['session']['branch_name']; ?>
<?php endif; ?>&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">List Location</font>&nbsp;</td>
				</tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:10PX;color:#999999;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			</div>
		</div>
		<form name="location_list" method="post" id="location_list">
		<div class="row">
			<div class="col-12">
				<div class="card">
				<?php if ($this->_tpl_vars['SuccessMessage'] != "" || $this->_tpl_vars['ErrorMessage'] != ""): ?>
					<div class="card-body">
					<?php if ($this->_tpl_vars['SuccessMessage'] != ""): ?>
						<div class="isa_success">
						<i class="fa fa-check"></i>
						<?php echo $this->_tpl_vars['SuccessMessage']; ?>
		 
						</div>
					<?php endif; ?>
					<?php if ($this->_tpl_vars['ErrorMessage'] != ""): ?>
						<div class="isa_error">
						<i class="fa fa-check"></i>
						<?php echo $this->_tpl_vars['ErrorMessage']; ?>
		 
						</div>
					<?php endif; ?>
					</div>
				<?php endif; ?>
					<div class="card-body table-responsive">
					<a href="locationAddEdit.php?companyId=<?php echo $this->_supers['get']['companyId']; ?>
&branchId=<?php echo $this->_supers['get']['branchId']; ?>
"><button type="button" style="float:right;margin-top:-6px" class="btn btn-create">Create Location</button></a>
					<br/><br/>
						<table id="example" class="table table-bordered table-hover">
						<thead>
						<tr>
						<th>#</th>
						<th>Code</th>
						<th>Name</th>
						<th>ID</th>
						<th>Data to Server JSON </th>
						<th>URL</th>
						<th>Status</th>
						<th>Action</th>
						</tr>
						</thead>
						<tbody>
						<?php $_from = $this->_tpl_vars['GetLocation']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['List']):
?>
						<?php $this->assign('tot', "{\"ID\":\"%i\",\"apiKey\":"); ?>
						<?php $this->assign('tot4', '"'); ?>
						<?php $this->assign('tot1', $this->_tpl_vars['List']['api_key']); ?>
						<?php $this->assign('tot2', "\" ,\"ST\":\"%s\",\"TS\":\"%t\",\"DT\":\"%d\",\"VR\":\"%a"); ?>
						<?php $this->assign('tot3', '"'); ?>
						<?php $this->assign('all', ($this->_tpl_vars['tot'])."''".($this->_tpl_vars['tot1'])."''".($this->_tpl_vars['tot2'])."''".($this->_tpl_vars['tot3'])); ?>
						<tr id="<?php echo $this->_tpl_vars['j']++; ?>
">
						<td class="slno"><?php echo $this->_tpl_vars['j']; ?>
</td>
						<td><?php echo $this->_tpl_vars['List']['location_code']; ?>
</td>
						<td><?php echo $this->_tpl_vars['List']['location_name']; ?>
</td>
						<td><?php echo $this->_tpl_vars['List']['modbus_slave_id']; ?>
</td>
						<td><span id="apik<?php echo $this->_tpl_vars['j']; ?>
" style="display:none;"><?php echo $this->_tpl_vars['tot']; ?>
<?php echo $this->_tpl_vars['tot4']; ?>
<?php echo $this->_tpl_vars['tot1']; ?>
<?php echo $this->_tpl_vars['tot2']; ?>
<?php echo $this->_tpl_vars['tot3']; ?>
</span><?php echo ((is_array($_tmp=$this->_tpl_vars['all'])) ? $this->_run_mod_handler('truncate', true, $_tmp, 30, "...", true) : smarty_modifier_truncate($_tmp, 30, "...", true)); ?>
&nbsp;&nbsp;<a href="#" onclick="Javascript:copy_password('apik<?php echo $this->_tpl_vars['j']; ?>
')" title="Copy to clipboard"><i class="fas fa-clipboard" ></i></a></td>
						<td><span id="apiu<?php echo $this->_tpl_vars['j']; ?>
" style="display:none;"><?php echo $this->_tpl_vars['List']['api_url']; ?>
</span><?php echo ((is_array($_tmp=$this->_tpl_vars['List']['api_url'])) ? $this->_run_mod_handler('truncate', true, $_tmp, 30, "...", true) : smarty_modifier_truncate($_tmp, 30, "...", true)); ?>
&nbsp;&nbsp;<a href="#" onclick="Javascript:copy_password('apiu<?php echo $this->_tpl_vars['j']; ?>
')" title="Copy to clipboard"><i class="fas fa-clipboard"></i></a></td>
						<td class="text_left status"> <?php if ($this->_tpl_vars['List']['is_active'] == '1'): ?><span style="color:#009900"><b>Active</b></span><?php else: ?><span style="color:#FF0033;"><b>Inactive</b></span><?php endif; ?></td>
						<td class="amount action">
						<?php $_from = $this->_tpl_vars['IconList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['icon']):
?>
						<?php if ($this->_tpl_vars['icon']['menuName'] == 'Location Details'): ?>
						<a href="#"  onClick="Javascript:detailCats('<?php echo $this->_tpl_vars['List']['location_master_id']; ?>
','<?php echo $this->_tpl_vars['List']['company_id']; ?>
','<?php echo $this->_tpl_vars['List']['branch_id']; ?>
','Update=Y')" title="Details"><i class="<?php echo $this->_tpl_vars['icon']['faIcon']; ?>
"></i></a>&nbsp;&nbsp;
					    <?php endif; ?>
						<?php if ($this->_tpl_vars['icon']['menuName'] == 'Edit Platform'): ?><a href="#"  onClick="Javascript:editCats('<?php echo $this->_tpl_vars['List']['location_master_id']; ?>
','<?php echo $this->_tpl_vars['List']['company_id']; ?>
','<?php echo $this->_tpl_vars['List']['branch_id']; ?>
','Update=Y')" title="Edit"><i class="<?php echo $this->_tpl_vars['icon']['faIcon']; ?>
"></i></a>&nbsp;&nbsp;
						<?php endif; ?>		
						<?php if ($this->_tpl_vars['icon']['menuName'] == 'Delete Platform'): ?><a href="#"  onClick="Javascript:deleteCats('<?php echo $this->_tpl_vars['List']['location_master_id']; ?>
','<?php echo $this->_tpl_vars['List']['company_id']; ?>
','<?php echo $this->_tpl_vars['List']['branch_id']; ?>
')" title="Delete"><i class="<?php echo $this->_tpl_vars['icon']['faIcon']; ?>
"></i></a>&nbsp;&nbsp;<?php endif; ?>
						<?php endforeach; endif; unset($_from); ?></td>
						</tr>
						<?php endforeach; else: ?>
						<tr><td colspan="8"><center>No Records Found</center></td></tr>
						<?php endif; unset($_from); ?>						
						</tbody>
						</table>
					</div>
				</div>
			</div>
		</form>
	</section>
	</div>
	<?php echo '
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>
	<script type="text/javascript">
	$(document).ready(function (){
	var table = $(\'#example\').DataTable({
	"ordering" : false,
	language: {
	"infoFiltered": "",
	search: "_INPUT_",
	searchPlaceholder: "Search..."
	},
	dom: \'<"pull-left" f><bottom>p\',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: \'<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p\',
	//dom: \'<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p\',
	buttons: [
	{
	text: \'Create Box\',
	className: \'btn btn-create\',
	titleAttr: \'Create Box\',
	action: function ( e, dt, button, config ) {
	window.location = \'AddEditBox.php\';
	}        
	}
	],
	initComplete: function(){
	$("div.toolbar").html(\'<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>\');   	
	}       
	}); 
	}); 
	
	function editCats(slNoIdent, comId, branchId) {
	
		var sid = btoa(slNoIdent);
		var cid = btoa(comId);
		var bid = btoa(branchId);

		FormName		= document.location_list;
		FormName.action =\'locationAddEdit.php?locId=\'+sid+\'&companyId=\'+cid+\'&branchId=\'+bid+\'&Update=y\';
		FormName.submit();
	}

	function detailCats(slNoIdent, comId, branchId) {
	
		var sid = btoa(slNoIdent);
		var cid = btoa(comId);
		var bid = btoa(branchId);

		FormName		= document.location_list;
		FormName.action =\'locationDetails.php?locId=\'+sid+\'&companyId=\'+cid+\'&branchId=\'+bid+\'&Update=y\';
		FormName.submit();
	}
	


	</script>
	<script type="text/javascript">
	function deleteCats(slNoIdent, comId, branchId){
		var sid = btoa(slNoIdent);
		var cid = btoa(comId);
		var bid = btoa(branchId);
		if(confirm("Are you sure to Delete this Record?")){
			FormName		= document.location_list;
			FormName.action= \'locationList.php?locId=\'+sid+\'&companyId=\'+cid+\'&branchId=\'+bid;
			FormName.submit();
		}
	}
	</script>
	<script>
	function copy_password(id) 
	{
		var copyText = document.getElementById(id);
		var textArea = document.createElement("textarea");
		textArea.value = copyText.textContent;
		document.body.appendChild(textArea);
		textArea.select();
		document.execCommand("Copy");
		textArea.remove();
	}
	</script>
	'; ?>

	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>