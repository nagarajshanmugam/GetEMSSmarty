<?php /* Smarty version 2.6.25, created on 2025-12-12 15:47:47
         compiled from locationDetails.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'date_format', 'locationDetails.tpl', 62, false),)), $this); ?>
	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;"><?php if ($this->_tpl_vars['companyDetail']['0']['companyName'] != ""): ?><?php echo $this->_tpl_vars['companyDetail']['0']['companyName']; ?>
<?php else: ?><?php echo $this->_supers['session']['CompanyName']; ?>
<?php endif; ?>&nbsp;&nbsp;</td>
					<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="font-size:15PX;font-weight: bold;"><?php echo $this->_tpl_vars['ListEditView']['0']['location_code']; ?>
&nbsp;&nbsp;</td>
					<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
						<td style="font-size:15PX;font-weight: bold;"><?php echo $this->_tpl_vars['ListEditView']['0']['location_name']; ?>
&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">Location Details</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:10PX;color:#999999;">Location Code</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:10PX;color:#999999;">Location Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			</div>
		</div>
		<form name="location_detail_form" method="post" id="location_detail_form">
		<div class="row">
			<div class="col-12">
				<div class="card">
				<?php if ($this->_tpl_vars['SuccessMessage'] != "" || $this->_tpl_vars['ErrorMessage'] != ""): ?>
					<div class="card-body">
					<?php if ($this->_tpl_vars['SuccessMessage'] != ""): ?>
						<div class="isa_success">
						<i class="fa fa-check"></i>
						<?php echo $this->_tpl_vars['SuccessMessage']; ?>
		 
						</div>
					<?php endif; ?>
					<?php if ($this->_tpl_vars['ErrorMessage'] != ""): ?>
						<div class="isa_error">
						<i class="fa fa-check"></i>
						<?php echo $this->_tpl_vars['ErrorMessage']; ?>
		 
						</div>
					<?php endif; ?>
					</div>
				<?php endif; ?>
					<div class="card-body table-responsive">
					<a href="locationList.php?companyId=<?php echo $this->_supers['get']['companyId']; ?>
&branchId=<?php echo $this->_supers['get']['branchId']; ?>
"><button type="button" style="float:right;margin-top:-6px" class="btn btn-primary">List Location</button></a>
						<table id="example" class="table table-bordered table-hover">
						<thead>
						<tr>
						<th>#</th>
						<th>Sensor</th>
						<th>IOT</th>
						<th>Start Date Time</th>
						<th>End Date Time</th>
						</tr>
						</thead>
						<tbody>
						<?php $_from = $this->_tpl_vars['GetLocationData']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['Detail']):
?>
						<tr id="<?php echo $this->_tpl_vars['j']++; ?>
">
						<td class="slno"><?php echo $this->_tpl_vars['j']; ?>
</td>
						<td><?php echo $this->_tpl_vars['Detail']['sensorName']; ?>
</td>
						<td><?php echo $this->_tpl_vars['Detail']['gateway_id']; ?>
</td>
						<td><?php echo ((is_array($_tmp=$this->_tpl_vars['Detail']['start_date_time'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%d-%b-%Y  %r') : smarty_modifier_date_format($_tmp, '%d-%b-%Y  %r')); ?>
</td>
                        <td>
                        <?php if ($this->_tpl_vars['Detail']['end_date_time'] != '' && $this->_tpl_vars['Detail']['end_date_time'] != '0000-00-00 00:00:00' && $this->_tpl_vars['Detail']['end_date_time'] != 'NULL'): ?>
                        <?php echo ((is_array($_tmp=$this->_tpl_vars['Detail']['end_date_time'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%d-%b-%Y  %r') : smarty_modifier_date_format($_tmp, '%d-%b-%Y  %r')); ?>

                        <?php else: ?>
                        <span style="color:#009900"><b>Till Now</b></span>
                        <?php endif; ?>
                        </td>
						</tr>
						<?php endforeach; else: ?>
						<tr><td colspan="8"><center>No Records Found</center></td></tr>
						<?php endif; unset($_from); ?>						
						</tbody>
						</table>
					</div>
				</div>
			</div>
		</form>
	</section>
	</div>
	<?php echo '
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>
	<script type="text/javascript">
	$(document).ready(function (){
	var table = $(\'#example\').DataTable({
	"ordering" : false,
	language: {
	"infoFiltered": "",
	search: "_INPUT_",
	searchPlaceholder: "Search..."
	},
	dom: \'<"pull-left" f><bottom>p\',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: \'<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p\',
	//dom: \'<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p\',
	buttons: [
	{
	text: \'Create Box\',
	className: \'btn btn-create\',
	titleAttr: \'Create Box\',
	action: function ( e, dt, button, config ) {
	window.location = \'AddEditBox.php\';
	}        
	}
	],
	initComplete: function(){
	$("div.toolbar").html(\'<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>\');   	
	}       
	}); 
	}); 
	
	function editCats(slNoIdent, comId, branchId) {
	
		var sid = btoa(slNoIdent);
		var cid = btoa(comId);
		var bid = btoa(branchId);

		FormName		= document.location_detail_form;
		FormName.action =\'locationAddEdit.php?locId=\'+sid+\'&companyId=\'+cid+\'&branchId=\'+bid+\'&Update=y\';
		FormName.submit();
	}

	function detailCats(slNoIdent, comId, branchId) {
	
		var sid = btoa(slNoIdent);
		var cid = btoa(comId);
		var bid = btoa(branchId);

		FormName		= document.location_detail_form;
		FormName.action =\'locationDetails.php?locId=\'+sid+\'&companyId=\'+cid+\'&branchId=\'+bid+\'&Update=y\';
		FormName.submit();
	}
	


	</script>
	<script type="text/javascript">
	function deleteCats(slNoIdent, comId, branchId){
		var sid = btoa(slNoIdent);
		var cid = btoa(comId);
		var bid = btoa(branchId);
		if(confirm("Are you sure to Delete this Record?")){
			FormName		= document.location_detail_form;
			FormName.action= \'locationList.php?locId=\'+sid+\'&companyId=\'+cid+\'&branchId=\'+bid;
			FormName.submit();
		}
	}
	</script>
	'; ?>

	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>