<?php /* Smarty version 2.6.25, created on 2025-12-06 11:43:05
         compiled from gatewayModelList.tpl */ ?>
	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;"><?php if ($this->_tpl_vars['companyDetail']['0']['companyName'] != ""): ?><?php echo $this->_tpl_vars['companyDetail']['0']['companyName']; ?>
<?php else: ?><?php echo $this->_supers['session']['CompanyName']; ?>
<?php endif; ?>&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">List Gateway Model</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			</div>
		</div>
		<form name="gateway_list" method="post" id="gateway_list">
		<div class="row">
			<div class="col-12">
				<div class="card">
				<?php if ($this->_tpl_vars['SuccessMessage'] != "" || $this->_tpl_vars['ErrorMessage'] != ""): ?>
					<div class="card-body">
					<?php if ($this->_tpl_vars['SuccessMessage'] != ""): ?>
						<div class="isa_success">
						<i class="fa fa-check"></i>
						<?php echo $this->_tpl_vars['SuccessMessage']; ?>
		 
						</div>
					<?php endif; ?>
					<?php if ($this->_tpl_vars['ErrorMessage'] != ""): ?>
						<div class="isa_error">
						<i class="fa fa-check"></i>
						<?php echo $this->_tpl_vars['ErrorMessage']; ?>
		 
						</div>
					<?php endif; ?>
					</div>
				<?php endif; ?>
					<div class="card-body table-responsive">
					<a href="addEditGatewayModel.php"><button type="button" style="float:right;margin-top:-6px" class="btn btn-create">Create Gateway Model</button></a>
						<table id="example" class="table table-bordered table-hover">
						<thead>
						<tr>
						<th>#</th>
						<th>Gateway Model Code</th>
						<th> Gateway Model Name </th>
						<th>Status</th>
						<th>Action</th>
						</tr>
						</thead>
						<tbody>
						<?php $_from = $this->_tpl_vars['ListView']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['List']):
?>
						<tr id="<?php echo $this->_tpl_vars['j']++; ?>
">
						<td class="slno"><?php echo $this->_tpl_vars['j']; ?>
</td>
						<td><?php echo $this->_tpl_vars['List']['model_code']; ?>
</td>
						<td><?php echo $this->_tpl_vars['List']['model_name']; ?>
</td>
						<td class="text_left status"> <?php if ($this->_tpl_vars['List']['is_active'] == '1'): ?><span style="color:#009900"><b>Active</b></span><?php else: ?><span style="color:#FF0033;"><b>Inactive</b></span><?php endif; ?></td>
						<td class="amount action">
						<?php $_from = $this->_tpl_vars['IconList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['icon']):
?>
						<?php if ($this->_tpl_vars['icon']['menuName'] == 'Edit Platform'): ?><a href="#"  onClick="Javascript:editCats('<?php echo $this->_tpl_vars['List']['sl_no']; ?>
','Update=Y')" title="Edit"><i class="<?php echo $this->_tpl_vars['icon']['faIcon']; ?>
"></i></a>&nbsp;&nbsp;&nbsp;<?php endif; ?>
						<?php if ($this->_tpl_vars['List']['is_active'] == '2'): ?><?php if ($this->_tpl_vars['icon']['menuName'] == 'Delete Platform'): ?><a href="#"  onClick="Javascript:deleteCats('<?php echo $this->_tpl_vars['List']['sl_no']; ?>
')" title="Delete"><i class="<?php echo $this->_tpl_vars['icon']['faIcon']; ?>
"></i></a>&nbsp;&nbsp;&nbsp;<?php endif; ?><?php endif; ?>
						<?php endforeach; endif; unset($_from); ?></td>
						</tr>
						<?php endforeach; else: ?>
						<tr><td colspan="6"><center>No Records Found</center></td></tr>
						<?php endif; unset($_from); ?>
						</tbody>
						</table>
					</div>
				</div>
			</div>
		</form>
	</section>
	</div>
	<?php echo '
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>
	<script type="text/javascript">
	$(document).ready(function (){
	
	var table = $(\'#example\').DataTable({
	"ordering" : false,
	language: {
	"infoFiltered": "",
	search: "_INPUT_",
	searchPlaceholder: "Search..."
	},
	dom: \'<"pull-left" f><bottom>p\',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: \'<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p\',
	//dom: \'<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p\',
	buttons: [
	{
	text: \'Create Box\',
	className: \'btn btn-create\',
	titleAttr: \'Create Box\',
	action: function ( e, dt, button, config ) {
	window.location = \'AddEditBox.php\';
	}        
	}
	],
	initComplete: function(){
	$("div.toolbar").html(\'<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>\');   	
	}       
	}); 
	}); 
	
	function editCats(slNoIdent) 
	{
		var sid = btoa(slNoIdent);
		FormName		= document.gateway_list;
		FormName.action =\'addEditGatewayModel.php?slNo=\'+sid+\'&Update=y\';
		FormName.submit();
	}
	</script>
	<script type="text/javascript">
	function deleteCats(slNoIdent)
	{
		var sid = btoa(slNoIdent);
		if(confirm("Are you sure to Delete this Gateway Model?")){
		FormName		= document.gateway_list;
		FormName.action= \'gatewayModelList.php?slNo=\'+sid;
		FormName.submit();
		}
	}
	</script>
	'; ?>

	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>