<?php /* Smarty version 2.6.25, created on 2025-11-11 14:40:31
         compiled from left.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'explode', 'left.tpl', 176, false),)), $this); ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" type="image/png" href=""/>
    <!--<title>Condition Monitoring System</title> -->
    <title><?php if ($this->_tpl_vars['headervariable'] == 'Temperature' && $this->_supers['session']['CompanyName'] != 'Subros'): ?>Temperature Monitoring System<?php elseif ($this->_supers['session']['CompanyName'] == 'Subros'): ?>Power Factor Controller Monitoring<?php else: ?>Energy Meter Monitoring System<?php endif; ?></title>
    
<?php echo '

 <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <!--<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">-->
   <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Select2 -->
  <link rel="stylesheet" href="plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
  <!-- Tempusdominus Bbootstrap 4 -->
  <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
   <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.css">
   <!-- JQVMap -->
  <link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
 <!-- daterange picker -->
  <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="plugins/summernote/summernote-bs4.css">
    <!-- SweetAlert2 -->
  <link rel="stylesheet" href="plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
  <!-- Toastr -->
  <link rel="stylesheet" href="plugins/toastr/toastr.min.css">
  <!-- Google Font: Source Sans Pro -->
 <!-- <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">--->
 <!-- <link href="dist/css/fontsgoogleapis.css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet"> -->
 
<!-- External Style file-->
 <link rel="stylesheet" href="dist/css/styleems.css">

  <script src="plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge(\'uibutton\', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Select2 -->
<script src="plugins/select2/js/select2.full.min.js"></script>
<!-- InputMask -->
<script src="plugins/moment/moment.min.js"></script>
<script src="plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>
<!-- date-range-picker -->
<script src="plugins/daterangepicker/daterangepicker.js"></script>
<!-- ChartJS -->
<script src="plugins/chart.js/Chart.min.js"></script>
<!-- Sparkline -->
<script src="plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<script src="plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<!-- jQuery Knob Chart -->
<script src="plugins/jquery-knob/jquery.knob.min.js"></script>
<script src="plugins/datatables/jquery.dataTables.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>

<!-- Tempusdominus Bootstrap 4 -->
<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="plugins/sweetalert2/sweetalert2.min.js"></script>
<!-- Toastr -->
<script src="plugins/toastr/toastr.min.js"></script>
<script src="dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<!--<script src="dist/js/pages/dashboard.js"></script>--->
<script src="dist/js/addcomma.js"></script>
<script src="plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<script>
if ( window.history.replaceState ) {
  window.history.replaceState( null, null, window.location.href );
}
</script>

  <script>
  $(function () {
    $(\'#example1\').DataTable({
      \'paging\'      : true,
      \'lengthChange\': false,
      \'searching\'   : true,
      \'ordering\'    : false,
      \'info\'        : false,
	  \'pageLength\': 50,
      \'autoWidth\'   : false
    })
  })
</script>
<style>
.pull-left{
    float: left !important;
}
.pull-right{
    float: right !important;
}
.pull-center{
    float: center !important;
}


span{display:block}
.openmenu li[class=""]{
    height:20px;
    overflow:hidden;
    
}
.menu-open{
    height:auto;
    overflow:visible;
    
}
</style>

	'; ?>

	 </head>
<body class="hold-transition sidebar-mini layout-fixed text-sm">
<div class="wrapper">
      <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
   <?php if ($this->_supers['session']['USER_GROUP'] != 'Super Admin' && $this->_supers['session']['CompanyName'] == 'Tecno Doors Pvt Ltd'): ?>
    <a href="dashboard.php" class="brand-link logo-switch">
  <img src="images/CompanyLogo/fermatoSmallLogo.jpg" alt="AdminLTE Docs Logo Small" class="brand-image-xl logo-xs">
  <img src="images/CompanyLogo/<?php echo $this->_supers['session']['CompanyLogo']; ?>
" alt="AdminLTE Docs Logo Large" class="brand-image-xs logo-xl" style="left: 2px">
</a>
<?php elseif ($this->_supers['session']['USER_GROUP'] != 'Super Admin'): ?>
<a href="#" class="brand-link logo-switch">
  <img src="images/CompanyLogoSmall/<?php echo $this->_supers['session']['CompanyLogoSmall']; ?>
" alt="AdminLTE Logo Small" class="brand-image-xl logo-xs">
  <img src="images/CompanyLogo/<?php echo $this->_supers['session']['CompanyLogo']; ?>
" alt="AdminLTE Docs Logo Large" class="brand-image-xs logo-xl" style="left: 2px">
</a>
<?php else: ?>
<a href="#" class="brand-link logo-switch">
  <img src="images/CompanyLogoSmall/<?php echo $this->_supers['session']['CompanyLogoSmall']; ?>
" alt="AdminLTE Logo Small" class="brand-image-xl logo-xs">
  <img src="images/CompanyLogo/<?php echo $this->_supers['session']['CompanyLogo']; ?>
" alt="AdminLTE Docs Logo Large" class="brand-image-xs logo-xl" style="left: 2px">
</a>
<?php endif; ?>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <!--<div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="dist/img/user2-160x160.jpg" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="#" class="d-block">Alexander Pierce</a>
        </div>
      </div>-->
      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar nav-legacy nav-compact nav-flat flex-column" data-widget="treeview" role="menu" data-accordion="false">
         <?php $this->assign('fooVar', $this->_supers['server']['PHP_SELF']); ?>
		  <?php $this->assign('urlVal', ((is_array($_tmp="/")) ? $this->_run_mod_handler('explode', true, $_tmp, $this->_tpl_vars['fooVar']) : explode($_tmp, $this->_tpl_vars['fooVar']))); ?>
          <?php $_from = $this->_tpl_vars['MainList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['roles']):
?>
          <?php if ($this->_tpl_vars['roles']['url'] == '#' && $this->_tpl_vars['urlVal'][1] != 'dashboard.php' && $this->_tpl_vars['urlVal'][1] != 'companyDashboard.php' && $this->_tpl_vars['urlVal'][1] != 'ac_acDashboard.php' && $this->_tpl_vars['urlVal'][1] != 'hvac_acReports.php' && $this->_tpl_vars['urlVal'][1] != 'meterDashboard.php' && $this->_tpl_vars['urlVal'][1] != 'temperature_temperatureDashboard.php' && $this->_tpl_vars['urlVal'][1] != 'DashboardTemperature.php' && $this->_tpl_vars['urlVal'][1] != 'subdashboard.php' && $this->_tpl_vars['urlVal'][1] != 'dailyReports.php' && $this->_tpl_vars['urlVal'][1] != 'shiftWiseReports.php' && $this->_tpl_vars['urlVal'][1] != 'logReports.php' && $this->_tpl_vars['urlVal'][1] != 'listIncidentLog.php' && $this->_tpl_vars['urlVal'][1] != 'customizeReportList.php' && $this->_tpl_vars['urlVal'][1] != 'energyConstructionReport.php' && $this->_tpl_vars['urlVal'][1] != 'listBilling.php' && $this->_tpl_vars['urlVal'][1] != 'temperature_temperatureLog.php' && $this->_tpl_vars['urlVal'][1] != 'temperatureDashboard.php'): ?>
          <li class="nav-item has-treeview ">
		  <?php else: ?>
		  <li class="nav-item has-treeview">
		  <?php endif; ?>
            
		  <?php if ($this->_tpl_vars['roles']['url'] == $this->_tpl_vars['urlVal'][1] || $this->_tpl_vars['roles']['url'] == '#' && $this->_tpl_vars['urlVal'][1] != 'dashboard.php' && $this->_tpl_vars['urlVal'][1] != 'companyDashboard.php' && $this->_tpl_vars['urlVal'][1] != 'ac_acDashboard.php' && $this->_tpl_vars['urlVal'][1] != 'hvac_acReports.php' && $this->_tpl_vars['urlVal'][1] != 'meterDashboard.php' && $this->_tpl_vars['urlVal'][1] != 'temperature_temperatureDashboard.php' && $this->_tpl_vars['urlVal'][1] != 'DashboardTemperature.php' && $this->_tpl_vars['urlVal'][1] != 'subdashboard.php' && $this->_tpl_vars['urlVal'][1] != 'dailyReports.php' && $this->_tpl_vars['urlVal'][1] != 'shiftWiseReports.php' && $this->_tpl_vars['urlVal'][1] != 'logReports.php' && $this->_tpl_vars['urlVal'][1] != 'listIncidentLog.php' && $this->_tpl_vars['urlVal'][1] != 'customizeReportList.php' && $this->_tpl_vars['urlVal'][1] != 'energyConstructionReport.php' && $this->_tpl_vars['urlVal'][1] != 'listBilling.php' && $this->_tpl_vars['urlVal'][1] != 'temperature_temperatureLog.php' && $this->_tpl_vars['urlVal'][1] != 'temperatureDashboard.php'): ?>
            <a href="<?php echo $this->_tpl_vars['roles']['url']; ?>
" class="nav-link active">
			<?php else: ?>
			<a href="<?php echo $this->_tpl_vars['roles']['url']; ?>
" class="nav-link ">
			<?php endif; ?>
              <i class="nav-icon far <?php echo $this->_tpl_vars['roles']['faIcon']; ?>
"></i>
              <p>
               <?php echo $this->_tpl_vars['roles']['menuName']; ?>

			   <?php if ($this->_tpl_vars['roles']['url'] == '#'): ?>
			   <i class="right fas fa-angle-left"></i>
			   <?php endif; ?>
              </p>
            </a>
			<?php if ($this->_tpl_vars['roles']['url'] == '#'): ?>
			<ul class="nav nav-treeview">
			<?php $_from = $this->_tpl_vars['SubList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['roleSub']):
?>
						<?php if ($this->_tpl_vars['roleSub']['parent_id'] == $this->_tpl_vars['roles']['slNo']): ?>
              <li class="nav-item">
                   <?php if ($this->_tpl_vars['roleSub']['url'] == $this->_tpl_vars['urlVal'][1]): ?>
                <a href="<?php echo $this->_tpl_vars['roleSub']['url']; ?>
" class="nav-link active">
				<?php $this->assign('subAct', $this->_tpl_vars['roleSub']['parent_id']); ?>
                    <?php else: ?>
			<a href="<?php echo $this->_tpl_vars['roleSub']['url']; ?>
" class="nav-link">
			<?php endif; ?>
                  <i class="nav-icon far <?php echo $this->_tpl_vars['roleSub']['faIcon']; ?>
"></i>
                  <p><?php if ($this->_tpl_vars['roleSub']['menuName'] == 'Energy Dashboard' || $this->_tpl_vars['roleSub']['menuName'] == 'Temperature Dashboard' || $this->_tpl_vars['roleSub']['menuName'] == 'AC Dashboard'): ?>Dashboard<?php else: ?><?php echo $this->_tpl_vars['roleSub']['menuName']; ?>
<?php endif; ?></p>
                </a>
              </li>
              <?php endif; ?>
			  <?php endforeach; endif; unset($_from); ?>
            </ul>
			<?php endif; ?>
          </li>
          <?php endforeach; endif; unset($_from); ?>
          
           <?php if ($this->_supers['session']['USER_GROUP'] == 'Company Admin' || $this->_supers['session']['USER_GROUP'] == 'Branch Admin'): ?>
            <?php $this->assign('fooVar', $this->_supers['server']['PHP_SELF']); ?>
		  <?php $this->assign('urlVal', ((is_array($_tmp="/")) ? $this->_run_mod_handler('explode', true, $_tmp, $this->_tpl_vars['fooVar']) : explode($_tmp, $this->_tpl_vars['fooVar']))); ?>
		     
		     
		  
		
		
		 <?php if ($this->_tpl_vars['urlVal'][1] == 'dailyReports.php' || $this->_tpl_vars['urlVal'][1] == 'shiftWiseReports.php' || $this->_tpl_vars['urlVal'][1] == 'logReports.php' || $this->_tpl_vars['urlVal'][1] == 'listIncidentLog.php' || $this->_tpl_vars['urlVal'][1] == 'customizeReportList.php' || $this->_tpl_vars['urlVal'][1] == 'energyConstructionReport.php' || $this->_tpl_vars['urlVal'][1] == 'listBilling.php' || $this->_tpl_vars['urlVal'][1] == 'temperature_temperatureLog.php'): ?>
           <li class="nav-item has-treeview menu-open" > 
           <?php else: ?>
           <li class="nav-item has-treeview" >
           <?php endif; ?>
               <?php if ($this->_tpl_vars['urlVal'][1] == 'mainEnergyMeter.php' || $this->_tpl_vars['urlVal'][1] == 'dailyReports.php' || $this->_tpl_vars['urlVal'][1] == 'shiftWiseReports.php' || $this->_tpl_vars['urlVal'][1] == 'logReports.php' || $this->_tpl_vars['urlVal'][1] == 'listIncidentLog.php' || $this->_tpl_vars['urlVal'][1] == 'customizeReportList.php' || $this->_tpl_vars['urlVal'][1] == 'energyConstructionReport.php' || $this->_tpl_vars['urlVal'][1] == 'temperature_temperatureLog.php'): ?>
               <a href="#" class="nav-link active">
                    <i class="nav-icon far fa fa-list"></i>
              <p>
                Reports<i class="right fas fa-angle-left"></i>
              </p>
            </a>
               <?php else: ?>
               <a href="#" class="nav-link">
                    <i class="nav-icon far fa fa-list"></i>
              <p>
                Reports<i class="right fas fa-angle-left"></i>
              </p>
            </a>
               <?php endif; ?>
			   <ul class="nav nav-treeview">
                <li class="nav-item">
               <?php if ($this->_tpl_vars['urlVal'][1] == 'mainEnergyMeter.php'): ?>
               <a href="mainEnergyMeter.php" class="nav-link active">
               <?php else: ?>
               <a href="mainEnergyMeter.php" class="nav-link">
               <?php endif; ?>
               <i class="nav-icon fa fa-bar-chart"></i>
              <p>
               Main Meter Reports
              </p></a>
                    </li>
                </ul>
            <ul class="nav nav-treeview">
                <li class="nav-item">
               <?php if ($this->_tpl_vars['urlVal'][1] == 'energyConstructionReport.php'): ?>
               <a href="energyConstructionReport.php" class="nav-link active">
               <?php else: ?>
               <a href="energyConstructionReport.php" class="nav-link">
               <?php endif; ?>
               <i class="nav-icon fa fa-bar-chart"></i>
              <p>
                Energy Consumption Reports
              </p></a>
                    </li>
                </ul>
                <ul class="nav nav-treeview">
                <li class="nav-item">
               <?php if ($this->_tpl_vars['urlVal'][1] == 'dailyReports.php'): ?>
               <a href="dailyReports.php" class="nav-link active">
               <?php else: ?>
               <a href="dailyReports.php" class="nav-link">
               <?php endif; ?>
               <i class="nav-icon fa fa-bar-chart"></i>
              <p>
                Daily Reports
              </p></a>
                    </li>
                </ul>
				<ul class="nav nav-treeview">
                <li class="nav-item">
               <?php if ($this->_tpl_vars['urlVal'][1] == 'dayToDayReport.php'): ?>
               <a href="dayToDayReport.php" class="nav-link active">
               <?php else: ?>
               <a href="dayToDayReport.php" class="nav-link">
               <?php endif; ?>
               <i class="nav-icon fa fa-bar-chart"></i>
              <p>
                Monthly Reports
              </p></a>
                    </li>
                </ul>
             <!--   
				<ul class="nav nav-treeview">
                <li class="nav-item">
                    <?php if ($this->_tpl_vars['urlVal'][1] == 'shiftWiseReports.php'): ?>
                    <a href="shiftWiseReports.php" class="nav-link active">
                    <?php else: ?>
                    <a href="shiftWiseReports.php" class="nav-link">
                    <?php endif; ?>
                    <i class="nav-icon fa fa-bar-chart"></i>
              <p>
                Shift Wise Reports
              </p></a>
                    </li>
                </ul>-->
<!--              <ul class="nav nav-treeview">
                <li class="nav-item">
               <?php if ($this->_tpl_vars['urlVal'][1] == 'customizeReportList.php'): ?>
               <a href="customizeReportList.php" class="nav-link active">
               <?php else: ?>
               <a href="customizeReportList.php" class="nav-link">
               <?php endif; ?>
               <i class="nav-icon fa fa-bar-chart"></i>
              <p>
                Customized Reports
              </p></a>
                    </li>
                </ul>-->
                 
            
				<ul class="nav nav-treeview">
                <li class="nav-item">
                    <?php if ($this->_tpl_vars['urlVal'][1] == 'logReports.php'): ?>
                    <a href="logReports.php" class="nav-link active">
                    <?php else: ?>
                    <a href="logReports.php" class="nav-link">
                    <?php endif; ?>
                    <i class="nav-icon fa fa-bar-chart"></i>
              <p>
                Log Reports
              </p></a>
                    </li>
                </ul>
				<ul class="nav nav-treeview">
                <li class="nav-item">
               <?php if ($this->_tpl_vars['urlVal'][1] == 'listIncidentLog.php'): ?>
                <a href="listIncidentLog.php" class="nav-link active">
               <?php else: ?>
                <a href="listIncidentLog.php" class="nav-link">
               <?php endif; ?>
               <i class="nav-icon fa fa-bar-chart"></i>
              <p>
                Recent Incidents 
              </p></a>
                    </li>
                </ul>
                
               <!-- <ul class="nav nav-treeview">
                <li class="nav-item">
               <?php if ($this->_tpl_vars['urlVal'][1] == 'temperature_temperatureLog.php'): ?>
                <a href="temperature_temperatureLog.php" class="nav-link active">
               <?php else: ?>
                <a href="temperature_temperatureLog.php" class="nav-link">
               <?php endif; ?>
               <i class="nav-icon fa fa-bar-chart"></i>
              <p>
               Temperature Log Reports
              </p></a>
                    </li>
                </ul>-->
               <!-- 
				<?php if ($this->_supers['session']['billing_module'] == '1'): ?>
				<ul class="nav nav-treeview">
                <li class="nav-item">
               <?php if ($this->_tpl_vars['urlVal'][1] == 'listBilling.php'): ?>
                <a href="listBilling.php" class="nav-link active">
               <?php else: ?>
                <a href="listBilling.php" class="nav-link">
               <?php endif; ?>
               <i class="nav-icon fa fa-bar-chart"></i>
              <p>
                List Billing 
              </p></a>
                    </li>
              </ul>
			  <?php endif; ?> -->
          </li>
       
           <?php endif; ?>
          <!--<li class="nav-item">
            <a href="feederList.php" class="nav-link">
              <i class="nav-icon far fa fa-lightbulb"></i>
              <p>
                List Sensor
              </p>
            </a>
          </li>-->
         <!-- <li class="nav-item">
            <a href="userRoleList.php" class="nav-link">
              <i class="nav-icon far fa fa-user-md"></i>
              <p>
                User Role
              </p>
            </a>
          </li>
          
          <li class="nav-item">
            <a href="userList.php" class="nav-link">
              <i class="nav-icon far fa fa-user"></i>
              <p>
                User
              </p>
            </a>
          </li>
          
          <li class="nav-item">
            <a href="companyList.php" class="nav-link">
              <i class="nav-icon far fa fa-building"></i>
              <p>
                Company
              </p>
            </a>
          </li>-->
  
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>
        

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>