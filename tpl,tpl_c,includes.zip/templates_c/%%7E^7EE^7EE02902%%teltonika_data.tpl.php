<?php /* Smarty version 2.6.25, created on 2025-11-17 10:30:53
         compiled from teltonika_data.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'date_format', 'teltonika_data.tpl', 53, false),)), $this); ?>
	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;"><?php if ($this->_tpl_vars['companyDetail']['0']['companyName'] != ""): ?><?php echo $this->_tpl_vars['companyDetail']['0']['companyName']; ?>
<?php else: ?><?php echo $this->_supers['session']['CompanyName']; ?>
<?php endif; ?>&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">List Teltonika Data</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			</div>
		</div>
		<div class="row">
			<div class="col-12">
				<div class="card">
				<?php if ($this->_tpl_vars['SuccessMessage'] != ""): ?>
					<div class="card-body">
						<div class="isa_success">
						<i class="fa fa-check"></i>
						<?php echo $this->_tpl_vars['SuccessMessage']; ?>
		 
						</div>
					</div>
				<?php endif; ?>
				<?php if ($this->_tpl_vars['ErrorMessage'] != ""): ?>
					<div class="card-body">
						<div class="isa_error">
						<i class="fa fa-check"></i>
						<?php echo $this->_tpl_vars['ErrorMessage']; ?>
		 
						</div>
					</div>
				<?php endif; ?>
					<div class="card-body table-responsive">
				<a href="#" onclick="get_excel();"> <button type="button" class="btn btn-create" value="Create Userrole" style="float:right;margin-top:-6PX">Download Excel</button></a><span style="float:right;">&ensp;</span>
					<a href="teltonika_data.php?del=Delete" onclick="return confirm('Are you sure want to delete all Data?')"> <button type="button" class="btn btn-create" value="Create Userrole" style="float:right;margin-top:-6PX">Delete All Data</button></a> <?php if ($this->_tpl_vars['ListView']['0']['json_data'] == ""): ?><br /><br /><?php endif; ?>
						<form name="companyList" id="companyList" method="post">
							<table id="example" class="table table-hover table-bordered">
							<thead>
							    
							<tr>
							<th class="slno">#</th>
							<th >DATE TIME</th>
							<th>Json Data (URL = https://emslte.arkaautomaations.com/teltonika_test.php)</th>

							</tr>
							</thead>
							<tbody>
							<?php $_from = $this->_tpl_vars['ListView']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['listDet']):
?>
							<tr id="<?php echo $this->_tpl_vars['i']++; ?>
">
							<td class="slNo"><?php echo $this->_tpl_vars['i']; ?>
</td>
								<td class="datetime" ><?php echo ((is_array($_tmp=$this->_tpl_vars['listDet']['M_timestamp'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%d-%b-%Y  %r') : smarty_modifier_date_format($_tmp, '%d-%b-%Y  %r')); ?>
</td>
							<td class="text_left"><?php echo $this->_tpl_vars['listDet']['json_data']; ?>
</td>
						
							</tr>
							<?php endforeach; else: ?>
							<tr><td colspan="10"><center>No Records Found</center></td></tr>
							<?php endif; unset($_from); ?>
							</tbody>
							</table>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
	</div>
	<?php echo '
	<script>
	$(document).ready(function (){
	var table = $(\'#example\').DataTable({
	"ordering" : false,
	language: {
	"infoFiltered": "",
	search: "_INPUT_",
	searchPlaceholder: "Search..."
	},
	dom: \'<"pull-left" f><bottom>p\',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: \'<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p\',
	//dom: \'<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p\',
	buttons: [
	{
	text: \'Create Box\',
	className: \'btn btn-create\',
	titleAttr: \'Create Box\',
	action: function ( e, dt, button, config ) {
	window.location = \'AddEditBox.php\';
	}        
	}
	],
	initComplete: function(){
	$("div.toolbar").html(\'<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>\');   	
	}       
	}); 
	}); 
	$(function () {
	$("#example1").DataTable();
	$(\'#example2\').DataTable({
	"paging": true,
	"lengthChange": false,
	"searching": false,
	"ordering": true,
	"info": true,
	"autoWidth": false,
	});
	});
	</script>
	 <script type="text/javascript">
	function get_excel()
	{
	window.location.href="teltonika_report_xl.php";
	}
	</script>
	<style>
	.datetime
	{
	width:20%;
	}
	.slNo
	{
	width:5%;
	}
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	
	</style>
	'; ?>

	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>