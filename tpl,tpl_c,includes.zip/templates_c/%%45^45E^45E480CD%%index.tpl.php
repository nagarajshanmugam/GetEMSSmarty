<?php /* Smarty version 2.6.25, created on 2025-12-05 12:58:39
         compiled from index.tpl */ ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" type="image/png" href=""/>
		<title>EMS | Log in</title>
		
		<!-- Font Awesome  for input field icon -->
		<link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
		<!-- Theme style Important -->
		<link rel="stylesheet" href="dist/css/adminlte.min.css">
	
	</head>
	<body class="hold-transition login-page" style=" background-image:url(images/emsBaner.png);">
		<div class="login-box">
			<div class="login-logo">
			<a href="#" style="color:#FFFFFF;"><b>GET</b></a>
			</div>
		<!-- /.login-logo -->
			<div class="card">
				<?php if ($this->_tpl_vars['SuccessMessage'] != ""): ?>
					<div class="isa_success">
						<i class="fa fa-check"></i>
						<?php echo $this->_tpl_vars['SuccessMessage']; ?>
		 
					</div>
				<?php endif; ?>
			 	<?php if ($this->_tpl_vars['ErrorMessage'] != ""): ?>
			 		<div class="isa_error">
						<i class="fa fa-check"></i>
						<?php echo $this->_tpl_vars['ErrorMessage']; ?>
		 
					</div>
				<?php endif; ?>
				<div class="card-body login-card-body">
					<p class="login-box-msg">Sign in</p>
				
					<form name="stafflogin" action="index.php" method="post" onSubmit="return StaffvalidateForm()">
						<input type="hidden" id="hdAction" name="hdAction">
						<div class="input-group mb-3">
							<input type="email" name="emailId" id="emailId" class="form-control" onChange="ValidateEmail(this);" placeholder="Login Email">
							<div class="input-group-append">
								<div class="input-group-text">
									<span class="fas fa-envelope"></span>
								</div>
							</div>
						</div>
						<div class="input-group mb-3">
							<input type="password" name="password" id="password" class="form-control" placeholder="Login Password">
							<div class="input-group-append">
								<div class="input-group-text">
									<span class="fas fa-lock"></span>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-12">
								<center><button type="submit" class="btn btn-primary btn-create">Sign In</button></center>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
		<?php echo '
		<script  type="text/javascript">
		
		function StaffvalidateForm()
		{
			var x=document.forms["stafflogin"]["emailId"].value;
			if (x==null || x=="")
			{
				dhtmlx.alert({
					title: "User Email Empty !",
					type:"alert-error",
					text: "Please enter the User Email",	
				});
				
				document.getElementById("emailId").focus();
				document.getElementById("emailId").style.borderColor = \'red\';
				return false;
			}
			var y=document.forms["stafflogin"]["password"].value;
			if (y==null || y=="")
			{
				dhtmlx.alert({
					title: "Password Error !",
					type:"alert-error",
					text: "Please enter the Password",	
				});	
				document.getElementById("password").focus();
				document.getElementById("password").style.borderColor = \'red\';	
				return false;
			}
			stafflogin.hdAction.value = 1;
			return true;
		}
		</script>
		<script  type="text/javascript">
		function ValidateEmail()  
		{ 
			var mailformat = /^\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$/;
			var inputText=document.getElementById(\'emailId\');  
			if(inputText.value.match(mailformat))  
			{  
				document.form1.text1.focus();  
				return true;  
			}  
			else  
			{
				dhtmlx.alert({
					title: "Wrong Email Format !",
					type:"alert-error",
					text: "You have entered an invalid email address!",	
				});
				document.getElementById("emailId").focus();
				document.getElementById("emailId").style.borderColor = \'red\';
				return false;
			} 
		}
		</script>
		<!-- for input field Alert Message-->
		<script type="text/javascript" src=\'./dhtmlxMessage/codebase/dhtmlxmessage.js\'></script>
		<link rel="stylesheet" href= "./codebase/skins/dhtmlxmessage_dhx_skyblue.css" type="text/css" media="all"/>
		
		<style type="text/css">
		.isa_success
		{
			color:#4F8A10;
			background-color:#DFF2BF;
		}
		
		.isa_error
		{
			color:#D8000C;
			background-color:#FFBABA;
		}
		.isa_success i,.isa_error i
		{
			margin:10px 22px;
			font-size:2em;
		/*vertical-align:middle;*/
		}
		</style>
		'; ?>

	</body>
</html>