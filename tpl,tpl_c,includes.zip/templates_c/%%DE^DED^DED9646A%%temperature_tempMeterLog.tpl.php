<?php /* Smarty version 2.6.25, created on 2026-07-08 16:11:39
         compiled from temperature_tempMeterLog.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'date_format', 'temperature_tempMeterLog.tpl', 110, false),)), $this); ?>
  <?php echo '

 <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <!--<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">-->
   <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Select2 -->
  <link rel="stylesheet" href="plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
  <!-- Tempusdominus Bbootstrap 4 -->
  <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
   <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.css">
   <!-- JQVMap -->
  <link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
 <!-- daterange picker -->
  <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="plugins/summernote/summernote-bs4.css">
    <!-- SweetAlert2 -->
  <link rel="stylesheet" href="plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
  <!-- Toastr -->
  <link rel="stylesheet" href="plugins/toastr/toastr.min.css">
  <!-- Google Font: Source Sans Pro -->
 <!-- <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">--->
  <link href="dist/css/fontsgoogleapis.css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
<!-- External Style file-->
 <link rel="stylesheet" href="dist/css/styleems.css">

  <script src="plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge(\'uibutton\', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Select2 -->
<script src="plugins/select2/js/select2.full.min.js"></script>
<!-- InputMask -->
<script src="plugins/moment/moment.min.js"></script>
<script src="plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>
<!-- date-range-picker -->
<script src="plugins/daterangepicker/daterangepicker.js"></script>
<!-- ChartJS -->
<script src="plugins/chart.js/Chart.min.js"></script>
<!-- Sparkline -->
<script src="plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<script src="plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<!-- jQuery Knob Chart -->
<script src="plugins/jquery-knob/jquery.knob.min.js"></script>
<script src="plugins/datatables/jquery.dataTables.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>

<!-- Tempusdominus Bootstrap 4 -->
<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="plugins/sweetalert2/sweetalert2.min.js"></script>
<!-- Toastr -->
<script src="plugins/toastr/toastr.min.js"></script>
<script src="dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
  
<script>
  $(function () {
    $(\'#example1\').DataTable({
      \'paging\'      : true,
      \'lengthChange\': false,
      \'searching\'   : true,
      \'ordering\'    : false,
      \'info\'        : false,
	  \'pageLength\': 50,
      \'autoWidth\'   : false
    })
  })
</script>
<style type="text/css">
form {

  overflow-x: hidden;
}
</style>

	'; ?>

 
		   <form role="form" name="dataraange" id="dataraange" action="" method="POST">
            <input type="hidden" id="gatewayCode" name="gatewayCode" value="<?php echo $this->_supers['get']['gatewayCode']; ?>
" />
			<input type="hidden" id="sensorCode" name="sensorCode" value="<?php echo $this->_supers['get']['sensorCode']; ?>
" />
      <input type="hidden" id="companyId" name="companyId" value="<?php echo $this->_supers['get']['companyId']; ?>
" />
      <input type="hidden" id="branchId" name="branchId" value="<?php echo $this->_supers['get']['branchId']; ?>
" />
           <div class="row">
           <div class="form-group col-md-3">
                    <label for="exampleInputserialNo">From Date <span style="color:red;">*</span></label>
                    <input type="text" size="15" id="date1" name="date1" autocomplete="OFF" class="form-control form-control-sm" readonly="true" value= "<?php if ($this->_tpl_vars['getFromDate'] == ""): ?><?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%e-%b-%Y') : smarty_modifier_date_format($_tmp, '%e-%b-%Y')); ?>
<?php else: ?><?php echo ((is_array($_tmp=$this->_tpl_vars['getFromDate'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%e-%b-%Y') : smarty_modifier_date_format($_tmp, '%e-%b-%Y')); ?>
<?php endif; ?>"/>
                  </div>
                  
                  <div class="form-group col-md-3">
                    <label for="exampleInputserialNo">To Date <span style="color:red;">*</span></label>
                    <input type="text" size="15" id="date2" name="date2" autocomplete="OFF" class="form-control form-control-sm" readonly="true" value= "<?php if ($this->_tpl_vars['getToDate'] == ""): ?><?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%e-%b-%Y') : smarty_modifier_date_format($_tmp, '%e-%b-%Y')); ?>
<?php else: ?><?php echo ((is_array($_tmp=$this->_tpl_vars['getToDate'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%e-%b-%Y') : smarty_modifier_date_format($_tmp, '%e-%b-%Y')); ?>
<?php endif; ?>"/>
                  </div>
          
         	  
 
 <div class="form-group col-md-3" style="margin-top:8px;"><br />
            
            <input name="submit" type="submit" class="btn btn-sm" value="Get Report" style="color:#FFFFFF; background-color:#17a2b8;"/>&nbsp;&nbsp;&nbsp;&nbsp;
	  <a href="#" onClick="get_excel();"><img src="images/excel1.png"  height="26" width="26" alt="Excel" title="Xls" ></a>
      &nbsp;&nbsp;&nbsp;<a href="javascript:window.print()"><img src="images/print-icon.gif" height="26" width="26"  alt="Print" title="Print"></a>
			</div>
      
           </div>
		  </form>
         
		 
	
	<center>	 <table class="table table-bordered table-hover" id="section-to-print">
   
<thead>
<tr align="center">
    <th colspan="5" bgcolor="#17a2b8" style="color:#FFFFFF" class="style3 style1" scope="row">&nbsp;&nbsp;<span class="">Temperature Log View From <?php if ($this->_tpl_vars['getFromDate'] == ""): ?><?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%e-%b-%Y') : smarty_modifier_date_format($_tmp, '%e-%b-%Y')); ?>
<?php else: ?><?php echo ((is_array($_tmp=$this->_tpl_vars['getFromDate'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%e-%b-%Y') : smarty_modifier_date_format($_tmp, '%e-%b-%Y')); ?>
<?php endif; ?> To <?php if ($this->_tpl_vars['getToDate'] == ""): ?><?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%e-%b-%Y') : smarty_modifier_date_format($_tmp, '%e-%b-%Y')); ?>
<?php else: ?><?php echo ((is_array($_tmp=$this->_tpl_vars['getToDate'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%e-%b-%Y') : smarty_modifier_date_format($_tmp, '%e-%b-%Y')); ?>
<?php endif; ?>  
 </span>   </th></tr>

<tr>
<th># </th>
<th>Date Time </th>
<th>Temperature &ordm;C</th>
<th>Temperature &ordm;F</th>
<th>Humidity RH %</th>
</tr>
</thead>
  <?php $_from = $this->_tpl_vars['GetTemp']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['List']):
?>
   <?php $this->assign('grandTCost', $this->_tpl_vars['grandTCost']+$this->_tpl_vars['List']['consuption_cost']); ?>
		 <tbody>			
<tr id="<?php echo $this->_tpl_vars['i']++; ?>
">
<td><div align="center" class=""><?php echo $this->_tpl_vars['i']; ?>
</div></td> 
<td><div align="center" class=""><?php echo ((is_array($_tmp=$this->_tpl_vars['List']['posted_date_time'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%d-%m-%Y %H:%M:%S') : smarty_modifier_date_format($_tmp, '%d-%m-%Y %H:%M:%S')); ?>
</div></td> 
<td><div align="center" class=""><?php echo $this->_tpl_vars['List']['temperature_c']; ?>
</div></td>
<td><div align="center" class=""><?php echo $this->_tpl_vars['List']['temperature_f']; ?>
</div></td>
<td><div align="center" class=""><?php echo $this->_tpl_vars['List']['humidity']; ?>
</div></td>
</tr>
 </tbody>
  <?php endforeach; else: ?>
                <tr><td colspan="5"><center>No Records Found</center></td></tr>
                <?php endif; unset($_from); ?>
 
</table></center>

		
		<!--<div id="chartdiv" style="height:500px; width:100%;">
		</div>-->		
		  <div class="clear"></div>

      
  <!-- /.content-wrapper -->
  <?php echo '
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script>
  $( function() {
    $( "#date1" ).datepicker({changeMonth: true,
    changeYear: true,maxDate: \'0\',dateFormat:\'yy-mm-dd\'});
	 $( "#date2" ).datepicker({changeMonth: true,
    changeYear: true,maxDate: \'0\',dateFormat:\'yy-mm-dd\'});
  } );
  </script>
<script type="text/javascript">
function createValidation(){
var segmentCode = $(\'#segmentCode\').val();
var segmentName = $(\'#segmentName\').val();
var isActive = document.getElementById("customCheckbox2").checked;

if (isActive == false) 
{
document.getElementById(\'checkVal\').value=\'0\';
}
else
{
document.getElementById(\'checkVal\').value=\'1\';

}

$(".error").remove();
if (segmentCode.length < 1) {
$(\'#segmentCode\').after(\'<span class="error">This field is required</span>\');
$(\'#segmentCode\').focus();
return false;					
}
else if (segmentName < 1) {
$(\'#segmentName\').after(\'<span class="error">This field is required</span>\');
$(\'#segmentName\').focus();
return false;					
}

FormName		= document.gatewayRegForm;
FormName.method	= "POST";
FormName.submit();
}
 
  function GoBack()
{
window.history.back();
}
  </script>
  <script type="text/javascript">

	function get_excel(){
// alert(\'sdasd\');
	var gatewayCode = document.getElementById("gatewayCode").value;//alert(emp);
	var sensorCode = document.getElementById("sensorCode").value;
  var companyId = document.getElementById("companyId").value;
  var branchId = document.getElementById("branchId").value;
	var from = document.getElementById("date1").value;//alert(from);
	var to = document.getElementById("date2").value;//alert(to);

//	alert(frTime);
//	alert(toTime);
   if((from!=\'\' || to !=\'\') )
	{
	    if(from ==\'\')
	    {
	        alert("Please Specify From Date");
        	document.getElementById("date1").style.borderColor="red";
        	return false;
	    }
	    else if(to ==\'\')
	    {
	        alert("Please Specify To Date");
        	document.getElementById("date2").style.borderColor="red";
        	return false;
	    }
	    else if(from > to)
	    {
	        alert("Do Not enter From Date greater than to Date");
        	document.getElementById("date1").style.borderColor="red";
        	return false;
	    }

	
	}
	
	window.location.href="temperature_temp_log_report.php?gatewayCode="+gatewayCode+"&sensorCode="+sensorCode+"&companyId="+companyId+"&branchId="+branchId+"&from="+from+"&to="+to;
}
	</script>
  <script> 
		// dhtml Calendar
	    function formvalidate()
        {
            var	date1=document.getElementById("date1").value;
            var	date2=document.getElementById("date2").value;

            if(date1 !=\'\' || date2 !=\'\')
            {
                if(date1 ==\'\')
        		{
        			alert("Please Specify From Date");
        			document.getElementById("date1").style.borderColor="red";
        			return false;
        		}
        		
        		else if(date2 ==\'\')
        		{
        			alert("Please Specify To Date");
        			document.getElementById("date2").style.borderColor="red";
        			return false;
        		}else if(date1 > date2)
        		{
        			alert("Do Not enter From Date greater than To Date");
        			document.getElementById("date1").style.borderColor="red";
        			return false;
        		}
        	
        	}
		
		    document.dataraange.submit();


        }	
        </script>
  <style>
.isa_success
{
color:#4F8A10;
background-color:#DFF2BF;
}
.error
{
color:#D8000C;
/*background-color:#FFBABA;*/
}
.isa_error
{
color:#D8000C;
background-color:#FFBABA;
}
.isa_success i,.isa_error i
{
margin:10px 22px;
font-size:2em;
/*vertical-align:middle;*/
}
.required
{
color:#FF0000;
}
@media print {
  body * {
    visibility: hidden;
  }
  #section-to-print, #section-to-print * {
    visibility: visible;
  }
  #section-to-print {
    position: absolute;
    left: 0;
    top: 0;
  }
}
</style>
  '; ?>
