<?php /* Smarty version 2.6.25, created on 2026-07-25 16:53:00
         compiled from trendGraph.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'base64_decode', 'trendGraph.tpl', 106, false),array('modifier', 'split', 'trendGraph.tpl', 107, false),array('modifier', 'date_format', 'trendGraph.tpl', 209, false),)), $this); ?>
	<?php echo '
	<link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
	<!-- Ionicons -->
	<link rel="stylesheet" href="dist/css/ionicons.min.css">
	<!-- Select2 -->
	<link rel="stylesheet" href="plugins/select2/css/select2.min.css">
	<link rel="stylesheet" href="plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
	<!-- Tempusdominus Bbootstrap 4 -->
	<link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
	<!-- iCheck -->
	<link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
	<!-- DataTables -->
	<link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.css">
	<!-- JQVMap -->
	<link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
	<!-- Theme style -->
	<link rel="stylesheet" href="dist/css/adminlte.min.css">
	<!-- overlayScrollbars -->
	<link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
	<!-- daterange picker -->
	<link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
	<!-- summernote -->
	<link rel="stylesheet" href="plugins/summernote/summernote-bs4.css">
	<!-- SweetAlert2 -->
	<link rel="stylesheet" href="plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
	<!-- Toastr -->
	<link rel="stylesheet" href="plugins/toastr/toastr.min.css">
	<!-- Google Font: Source Sans Pro -->
	<link href="dist/css/fontsgoogleapis.css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
	<!-- External Style file-->
	<link rel="stylesheet" href="dist/css/styleems.css">
	<script src="plugins/jquery/jquery.min.js"></script>
	<!-- jQuery UI 1.11.4 -->
	<script src="plugins/jquery-ui/jquery-ui.min.js"></script>
	<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
	<script>
	$.widget.bridge(\'uibutton\', $.ui.button)
	</script>
	<!-- Bootstrap 4 -->
	<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
	<!-- Select2 -->
	<script src="plugins/select2/js/select2.full.min.js"></script>
	<!-- InputMask -->
	<script src="plugins/moment/moment.min.js"></script>
	<script src="plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>
	<!-- date-range-picker -->
	<script src="plugins/daterangepicker/daterangepicker.js"></script>
	<!-- ChartJS -->
	<script src="plugins/chart.js/Chart.min.js"></script>
	<!-- Sparkline -->
	<script src="plugins/sparklines/sparkline.js"></script>
	<!-- JQVMap -->
	<script src="plugins/jqvmap/jquery.vmap.min.js"></script>
	<script src="plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
	<!-- jQuery Knob Chart -->
	<script src="plugins/jquery-knob/jquery.knob.min.js"></script>
	<script src="plugins/datatables/jquery.dataTables.js"></script>
	<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
	<!-- Tempusdominus Bootstrap 4 -->
	<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
	<!-- Summernote -->
	<script src="plugins/summernote/summernote-bs4.min.js"></script>
	<!-- overlayScrollbars -->
	<script src="plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
	<!-- AdminLTE App -->
	<script src="plugins/sweetalert2/sweetalert2.min.js"></script>
	<!-- Toastr -->
	<script src="plugins/toastr/toastr.min.js"></script>
	<script src="dist/js/adminlte.js"></script>
	<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
	<script src="dist/js/pages/dashboard.js"></script>
	<!-- AdminLTE for demo purposes -->
	<script src="dist/js/demo.js"></script>
	<script src="amcharts/amcharts.js"></script>
	<script src="amcharts/serial.js"></script>
	<script src="amcharts/themes/light.js"></script>
	<style type="text/css">
	#chartdiv {
	width	: 98%;
	height	: 500px;
	}
	</style>
	<script>
	$(function () {
	$(\'#example1\').DataTable({
	\'paging\'      : true,
	\'lengthChange\': false,
	\'searching\'   : true,
	\'ordering\'    : false,
	\'info\'        : false,
	\'pageLength\': 50,
	\'autoWidth\'   : false
	})
	})
	</script>
	<style type="text/css">
	form {
	
	overflow-x: hidden;
	}
	</style>
	'; ?>
	
		<form method="POST" role="form" name="dataraange">
		<textarea id="mutiLinedataProvider" name="mutiLinedataProvider" style="display:none;" ><?php echo $this->_tpl_vars['ChartDataDash']; ?>
</textarea>
			<div class="row">
			    <?php $this->assign('someVar', ((is_array($_tmp=$this->_supers['get']['sensorCode'])) ? $this->_run_mod_handler('base64_decode', true, $_tmp) : base64_decode($_tmp))); ?>
	<?php $this->assign('temp', ((is_array($_tmp='[-]')) ? $this->_run_mod_handler('split', true, $_tmp, $this->_tpl_vars['someVar']) : split($_tmp, $this->_tpl_vars['someVar']))); ?>
	
					<div class="form-group col-md-3">
					<label for="exampleInputserialNo">Select Parameter <span style="color:red;">*</span></label>
					<input type="hidden" id="senMode" name="senMode" value="<?php echo $this->_tpl_vars['temp'][0]; ?>
"  />
					<select id="yAxis" name="yAxis" class="form-control form-control-sm">
                    <?php if ($this->_supers['post']['yAxis'] != ''): ?>
                    <?php if ($this->_supers['post']['yAxis'] == 'VOLTAGE'): ?>
                    <option value="VOLTAGE" selected="selected">VOLTAGE</option>
                    <option value="CURRENT" >CURRENT</option>
					<option value="SUM_KVA" >KVA</option>
					<option value="SUM_KW" >KW</option>
					<option value="SUM_KVAR" >KVAR</option>
					<option value="SUM_PF" >PF</option>
					<?php if ($this->_tpl_vars['temp'][0] != 'RGA20S'): ?>
					<option value="KWH" >KWH</option>
					<?php endif; ?>
                    <?php elseif ($this->_supers['post']['yAxis'] == 'CURRENT'): ?>
					<option value="CURRENT" selected="selected">CURRENT</option>
                    <option value="VOLTAGE" >VOLTAGE</option>
					<option value="SUM_KVA" >KVA</option>
					<option value="SUM_KW" >KW</option>
					<option value="SUM_KVAR" >KVAR</option>
					<option value="SUM_PF" >PF</option>
					<?php if ($this->_tpl_vars['temp'][0] != 'RGA20S'): ?>
					<option value="KWH" >KWH</option>
					<?php endif; ?>
                    <?php elseif ($this->_supers['post']['yAxis'] == 'SUM_KVA'): ?>
					<option value="SUM_KVA" selected="selected">KVA</option>
                    <option value="VOLTAGE" >VOLTAGE</option>
                    <option value="CURRENT" >CURRENT</option>
					<option value="SUM_KW" >KW</option>
					<option value="SUM_KVAR" >KVAR</option>
					<option value="SUM_PF" >PF</option>
					<?php if ($this->_tpl_vars['temp'][0] != 'RGA20S'): ?>
					<option value="KWH" >KWH</option>
					<?php endif; ?>
                    <?php elseif ($this->_supers['post']['yAxis'] == 'SUM_KW'): ?>
					<option value="SUM_KW" selected="selected">KW</option>
                    <option value="VOLTAGE" >VOLTAGE</option>
                    <option value="CURRENT" >CURRENT</option>
					<option value="SUM_KVA" >KVA</option>
					<option value="SUM_KVAR" >KVAR</option>
					<option value="SUM_PF" >PF</option>
					<?php if ($this->_tpl_vars['temp'][0] != 'RGA20S'): ?>
					<option value="KWH" >KWH</option>
					<?php endif; ?>
                    <?php elseif ($this->_supers['post']['yAxis'] == 'SUM_KVAR'): ?>
					<option value="SUM_KVAR" selected="selected">KVAR</option>
                    <option value="VOLTAGE" >VOLTAGE</option>
                    <option value="CURRENT" >CURRENT</option>
					<option value="SUM_KVA" >KVA</option>
					<option value="SUM_KW" >KW</option>
					<option value="SUM_PF" >PF</option>
					<?php if ($this->_tpl_vars['temp'][0] != 'RGA20S'): ?>
					<option value="KWH" >KWH</option>
					<?php endif; ?>
                    <?php elseif ($this->_supers['post']['yAxis'] == 'SUM_PF'): ?>
					<option value="SUM_PF" selected="selected">PF</option>
                    <option value="VOLTAGE" >VOLTAGE</option>
                    <option value="CURRENT" >CURRENT</option>
					<option value="SUM_KVA" >KVA</option>
					<option value="SUM_KW" >KW</option>
					<option value="SUM_KVAR" >KVAR</option>
					<?php if ($this->_tpl_vars['temp'][0] != 'RGA20S'): ?>
					<option value="KWH" >KWH</option>
					<?php endif; ?>
                    <?php elseif ($this->_supers['post']['yAxis'] == 'KWH'): ?>
					<option value="KWH" selected="selected" >KWH</option>
                    <option value="VOLTAGE" >VOLTAGE</option>
                    <option value="CURRENT" >CURRENT</option>
					<option value="SUM_KVA" >KVA</option>
					<option value="SUM_KW" >KW</option>
					<option value="SUM_KVAR" >KVAR</option>
					<option value="SUM_PF" >PF</option>
                    <?php else: ?>
                    <option value="VOLTAGE" selected="selected">VOLTAGE</option>
                    <option value="CURRENT" >CURRENT</option>
					<option value="SUM_KVA" >KVA</option>
					<option value="SUM_KW" >KW</option>
					<option value="SUM_KVAR" >KVAR</option>
					<option value="SUM_PF" >PF</option>
					<?php if ($this->_tpl_vars['temp'][0] != 'RGA20S'): ?>
					<option value="KWH" >KWH</option>
					<?php endif; ?>
                    <?php endif; ?>
                    <?php else: ?>
                    <option value="VOLTAGE" >VOLTAGE</option>
					<option value="CURRENT" >CURRENT</option>
					<option value="SUM_KVA" >KVA</option>
					<option value="SUM_KW" >KW</option>
					<option value="SUM_KVAR" >KVAR</option>
					<option value="SUM_PF" >PF</option>
					<?php if ($this->_tpl_vars['temp'][0] != 'RGA20S'): ?>
					<option value="KWH" >KWH</option>
					<?php endif; ?>
                    <?php endif; ?>
					
					</select>
					</div>
				<div class="form-group col-md-3">
					<label for="exampleInputserialNo"> Date <span style="color:red;">*</span></label>
					<input type="text" size="15" id="date1" name="date1" autocomplete="OFF" class="form-control form-control-sm" readonly="true" value= "<?php if ($this->_supers['post']['date1'] != ''): ?><?php echo ((is_array($_tmp=$this->_supers['post']['date1'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%e-%b-%Y') : smarty_modifier_date_format($_tmp, '%e-%b-%Y')); ?>
<?php else: ?><?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%e-%b-%Y') : smarty_modifier_date_format($_tmp, '%e-%b-%Y')); ?>
<?php endif; ?>"/>
							<!--	<input type="hidden" size="15" id="date2" name="date2" value= "<?php if ($this->_supers['post']['date1'] != ""): ?><?php echo ((is_array($_tmp=$this->_supers['post']['date2'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%e-%b-%Y') : smarty_modifier_date_format($_tmp, '%e-%b-%Y')); ?>
<?php else: ?><?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%e-%b-%Y') : smarty_modifier_date_format($_tmp, '%e-%b-%Y')); ?>
<?php endif; ?>"/>-->
				</div>
				<!--<div class="form-group col-md-3">
					<label for="exampleInputserialNo">To Date <span style="color:red;">*</span></label>
					<input type="text" size="15" id="date2" name="date2" autocomplete="OFF" class="form-control form-control-sm" readonly="true" value= "<?php if ($this->_supers['post']['date2'] != ''): ?><?php echo ((is_array($_tmp=$this->_supers['post']['date2'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%e-%b-%Y') : smarty_modifier_date_format($_tmp, '%e-%b-%Y')); ?>
<?php else: ?><?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%e-%b-%Y') : smarty_modifier_date_format($_tmp, '%e-%b-%Y')); ?>
<?php endif; ?>"/>
				</div>-->
			<div class="form-group col-md-3"  style="margin-top:8px;"><br />
				<input name="submit" type="submit" class="btn btn-sm" onClick="formvalidate();" value="Submit" style="color:#FFFFFF; background-color:#17a2b8;"/>
			</div>
			</div>
		</form>
	<center>	 
		<table class="table table-bordered table-hover" >
		<tr >
		<th colspan="5" bgcolor="#17a2b8" style="color:#FFFFFF" class="style3 style1" scope="row"><span class="style3"><?php echo $this->_supers['post']['yAxis']; ?>
 Historical Trend Graph ON  &nbsp;&nbsp;<?php if ($this->_tpl_vars['fdate'] != ""): ?><?php echo ((is_array($_tmp=$this->_tpl_vars['fdate'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%e-%b-%Y') : smarty_modifier_date_format($_tmp, '%e-%b-%Y')); ?>
<?php else: ?><?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%e-%b-%Y') : smarty_modifier_date_format($_tmp, '%e-%b-%Y')); ?>
<?php endif; ?><!--&nbsp;&nbsp;
		&nbsp;&nbsp;To &nbsp;&nbsp;<?php if ($this->_tpl_vars['tdate'] != ""): ?><?php echo ((is_array($_tmp=$this->_tpl_vars['fdate'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%e-%b-%Y') : smarty_modifier_date_format($_tmp, '%e-%b-%Y')); ?>
<?php else: ?><?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%e-%b-%Y') : smarty_modifier_date_format($_tmp, '%e-%b-%Y')); ?>
--><?php endif; ?>&nbsp;&nbsp;<?php echo '<?php'; ?>
 
		</span></th>
		</tr></table></center>
        <?php if ($this->_supers['post']['yAxis'] == 'VOLTAGE'): ?> 
		<div id="chartdiv" style="height:500px; width:100%;">
        <?php elseif ($this->_supers['post']['yAxis'] == 'CURRENT'): ?>
        <div id="chartdiv1" style="height:500px; width:100%;">
        <?php elseif ($this->_supers['post']['yAxis'] == 'SUM_KVA'): ?>
        <div id="chartdiv2" style="height:500px; width:100%;">
        <?php elseif ($this->_supers['post']['yAxis'] == 'SUM_KW'): ?>
        <div id="chartdiv3" style="height:500px; width:100%;">
        <?php elseif ($this->_supers['post']['yAxis'] == 'SUM_KVAR'): ?>
        <div id="chartdiv4" style="height:500px; width:100%;">
        <?php elseif ($this->_supers['post']['yAxis'] == 'SUM_PF'): ?>
        <div id="chartdiv5" style="height:500px; width:100%;">
        <?php elseif ($this->_supers['post']['yAxis'] == 'KWH'): ?>
        <div id="chartdiv6" style="height:500px; width:100%;">
        <?php else: ?>
        <div id="chartdiv" style="height:500px; width:100%;">
        <?php endif; ?>
		</div>		
	<div class="clear"></div>
	<?php echo '
	<link rel="stylesheet" href="css/jquery-ui.css">
	<!--<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">-->
	<script>
	$( function() {
		$( "#date1" ).datepicker({changeMonth: true,
		changeYear: true,maxDate: \'0\',dateFormat:\'yy-mm-dd\'});
		/* $( "#date2" ).datepicker({changeMonth: true,
		changeYear: true,maxDate: \'0\',dateFormat:\'yy-mm-dd\'}); */
	} );
	</script>
	<script type="text/javascript">
	function formvalidate()
	{
		
		var date1 = document.getElementById("date1").value;
	//	document.getElementById("date2").value=date1;
	//	var date2 = document.getElementById("date2").value;
		//alert(date1);
		//alert(date2);
//	if(date1=="" || date2=="")
if(date1=="")
	{
		alert("Please Specify Date");
		return false;
	}
	}	
	</script>
	<script type="text/javascript">
	function GoBack()
	{
		window.history.back();
	}
	
	var disp = document.getElementById(\'mutiLinedataProvider\').value;
	var disp = JSON.parse(disp);
	//alert(disp);
	var chart = AmCharts.makeChart("chartdiv", {
	"type": "serial",
	"theme": "light",
	"marginTop":0,
	"marginRight": 80,
	"dataProvider": disp,
	"valueAxes": [{
	"axisAlpha": 0,
	"position": "left"
	}],
	"graphs": [{
	"id":"g1",
	"balloonText": "TM :[[category]]<br><b><span style=\'font-size:14px;\'> R_VOLTAGE  : [[value]]</span></b>",
	"bullet": "round",
	"bulletSize": 2,         
	"lineColor": "Red",
	"lineThickness": 1,
	"negativeLineColor": "#637bb6",
	"type": "smoothedLine",
	"valueField": "R_VOLTAGE"
	},{
	"id":"g2",
	"balloonText": "TM :[[category]]<br><b><span style=\'font-size:14px;\'> Y_VOLTAGE : [[value]]</span></b>",
	"bullet": "round",
	"bulletSize": 2,         
	"lineColor": "Yellow",
	"lineThickness": 1,
	"negativeLineColor": "#637bb6",
	"type": "smoothedLine",
	"valueField": "Y_VOLTAGE"
	},{
	"id":"g3",
	"balloonText": "TM :[[category]]<br><b><span style=\'font-size:14px;\'> B_VOLTAGE  : [[value]]</span></b>",
	"bullet": "round",
	"bulletSize": 2,         
	"lineColor": "Blue",
	"lineThickness": 1,
	"negativeLineColor": "#637bb6",
	"type": "smoothedLine",
	"valueField": "B_VOLTAGE"
	}],
	"chartCursor": {
	"categoryBalloonDateFormat": "YYYY  ",
	"cursorAlpha": 0,
	"valueLineEnabled":true,
	"valueLineBalloonEnabled":true,
	"valueLineAlpha":0.5,
	"labelRotation": 90,
	"fullWidth":true
	},
	"categoryField": "tm",
	"chartScrollbar": {
	"graph":"g1",
	"gridAlpha":0,
	"color":"#888888",
	"scrollbarHeight":55,
	"backgroundAlpha":0,
	"selectedBackgroundAlpha":0.1,
	"selectedBackgroundColor":"#888888",
	"graphFillAlpha":0,
	"autoGridCount":false,
	"selectedGraphFillAlpha":0,
	"graphLineAlpha":0.2,
	"graphLineColor":"#c2c2c2",
	"selectedGraphLineColor":"#888888",
	"selectedGraphLineAlpha":1
	},
	"categoryAxis": {
	"parseDates": false,
	"minorGridAlpha": 0.1,
	"labelRotation": 90,
	"minorGridEnabled": true
	},
	
	"export": {
	"enabled": true
	}
	});
	</script>
    <script type="text/javascript">
	var disp = document.getElementById(\'mutiLinedataProvider\').value;
	var disp = JSON.parse(disp);
	var chart = AmCharts.makeChart("chartdiv1", {
	"type": "serial",
	"theme": "light",
	"marginTop":0,
	"marginRight": 80,
	"dataProvider": disp,
	"valueAxes": [{
	"axisAlpha": 0,
	"position": "left"
	}],
	"graphs": [{
	"id":"g1",
	"balloonText": "TM :[[category]]<br><b><span style=\'font-size:14px;\'> R_CURRENT  : [[value]]</span></b>",
	"bullet": "round",
	"bulletSize": 2,         
	"lineColor": "Red",
	"lineThickness": 1,
	"negativeLineColor": "#637bb6",
	"type": "smoothedLine",
	"valueField": "R_CURRENT"
	},{
	"id":"g2",
	"balloonText": "TM :[[category]]<br><b><span style=\'font-size:14px;\'> Y_CURRENT : [[value]]</span></b>",
	"bullet": "round",
	"bulletSize": 2,         
	"lineColor": "Yellow",
	"lineThickness": 1,
	"negativeLineColor": "#637bb6",
	"type": "smoothedLine",
	"valueField": "Y_CURRENT"
	},{
	"id":"g3",
	"balloonText": "TM :[[category]]<br><b><span style=\'font-size:14px;\'> B_CURRENT  : [[value]]</span></b>",
	"bullet": "round",
	"bulletSize": 2,         
	"lineColor": "Blue",
	"lineThickness": 1,
	"negativeLineColor": "#637bb6",
	"type": "smoothedLine",
	"valueField": "B_CURRENT"
	}],
	"chartCursor": {
	"categoryBalloonDateFormat": "YYYY  ",
	"cursorAlpha": 0,
	"valueLineEnabled":true,
	"valueLineBalloonEnabled":true,
	"valueLineAlpha":0.5,
	"labelRotation": 90,
	"fullWidth":true
	},
	"categoryField": "tm",
	"chartScrollbar": {
	"graph":"g1",
	"gridAlpha":0,
	"color":"#888888",
	"scrollbarHeight":55,
	"backgroundAlpha":0,
	"selectedBackgroundAlpha":0.1,
	"selectedBackgroundColor":"#888888",
	"graphFillAlpha":0,
	"autoGridCount":false,
	"selectedGraphFillAlpha":0,
	"graphLineAlpha":0.2,
	"graphLineColor":"#c2c2c2",
	"selectedGraphLineColor":"#888888",
	"selectedGraphLineAlpha":1
	},
	"categoryAxis": {
	"parseDates": false,
	"minorGridAlpha": 0.1,
	"labelRotation": 90,
	"minorGridEnabled": true
	},
	
	"export": {
	"enabled": true
	}
	});
	</script>
    <script type="text/javascript">
	var disp = document.getElementById(\'mutiLinedataProvider\').value;
	var disp = JSON.parse(disp);
	var chart = AmCharts.makeChart("chartdiv2", {
	"type": "serial",
	"theme": "light",
	"marginTop":0,
	"marginRight": 80,
	"dataProvider": disp,
	"valueAxes": [{
	"axisAlpha": 0,
	"position": "left"
	}],
	"graphs": [{
	"id":"g1",
	"balloonText": "TM :[[category]]<br><b><span style=\'font-size:14px;\'> SUM_KVA  : [[value]]</span></b>",
	"bullet": "round",
	"bulletSize": 2,         
	"lineColor": "Red",
	"lineThickness": 1,
	"negativeLineColor": "#637bb6",
	"type": "smoothedLine",
	"valueField": "SUM_KVA"
	}],
	"chartCursor": {
	"categoryBalloonDateFormat": "YYYY  ",
	"cursorAlpha": 0,
	"valueLineEnabled":true,
	"valueLineBalloonEnabled":true,
	"valueLineAlpha":0.5,
	"labelRotation": 90,
	"fullWidth":true
	},
	"categoryField": "tm",
	"chartScrollbar": {
	"graph":"g1",
	"gridAlpha":0,
	"color":"#888888",
	"scrollbarHeight":55,
	"backgroundAlpha":0,
	"selectedBackgroundAlpha":0.1,
	"selectedBackgroundColor":"#888888",
	"graphFillAlpha":0,
	"autoGridCount":false,
	"selectedGraphFillAlpha":0,
	"graphLineAlpha":0.2,
	"graphLineColor":"#c2c2c2",
	"selectedGraphLineColor":"#888888",
	"selectedGraphLineAlpha":1
	},
	"categoryAxis": {
	"parseDates": false,
	"minorGridAlpha": 0.1,
	"labelRotation": 90,
	"minorGridEnabled": true
	},
	
	"export": {
	"enabled": true
	}
	});
	</script>
    <script type="text/javascript">
	var disp = document.getElementById(\'mutiLinedataProvider\').value;
	var disp = JSON.parse(disp);
	var chart = AmCharts.makeChart("chartdiv3", {
	"type": "serial",
	"theme": "light",
	"marginTop":0,
	"marginRight": 80,
	"dataProvider": disp,
	"valueAxes": [{
	"axisAlpha": 0,
	"position": "left"
	}],
	"graphs": [{
	"id":"g1",
	"balloonText": "TM :[[category]]<br><b><span style=\'font-size:14px;\'> SUM_KW  : [[value]]</span></b>",
	"bullet": "round",
	"bulletSize": 2,         
	"lineColor": "Red",
	"lineThickness": 1,
	"negativeLineColor": "#637bb6",
	"type": "smoothedLine",
	"valueField": "SUM_KW"
	}],
	"chartCursor": {
	"categoryBalloonDateFormat": "YYYY  ",
	"cursorAlpha": 0,
	"valueLineEnabled":true,
	"valueLineBalloonEnabled":true,
	"valueLineAlpha":0.5,
	"labelRotation": 90,
	"fullWidth":true
	},
	"categoryField": "tm",
	"chartScrollbar": {
	"graph":"g1",
	"gridAlpha":0,
	"color":"#888888",
	"scrollbarHeight":55,
	"backgroundAlpha":0,
	"selectedBackgroundAlpha":0.1,
	"selectedBackgroundColor":"#888888",
	"graphFillAlpha":0,
	"autoGridCount":false,
	"selectedGraphFillAlpha":0,
	"graphLineAlpha":0.2,
	"graphLineColor":"#c2c2c2",
	"selectedGraphLineColor":"#888888",
	"selectedGraphLineAlpha":1
	},
	"categoryAxis": {
	"parseDates": false,
	"minorGridAlpha": 0.1,
	"labelRotation": 90,
	"minorGridEnabled": true
	},
	
	"export": {
	"enabled": true
	}
	});
	</script>
    <script type="text/javascript">
	var disp = document.getElementById(\'mutiLinedataProvider\').value;
	var disp = JSON.parse(disp);
	var chart = AmCharts.makeChart("chartdiv4", {
	"type": "serial",
	"theme": "light",
	"marginTop":0,
	"marginRight": 80,
	"dataProvider": disp,
	"valueAxes": [{
	"axisAlpha": 0,
	"position": "left"
	}],
	"graphs": [{
	"id":"g1",
	"balloonText": "TM :[[category]]<br><b><span style=\'font-size:14px;\'> SUM_KVAR  : [[value]]</span></b>",
	"bullet": "round",
	"bulletSize": 2,         
	"lineColor": "Red",
	"lineThickness": 1,
	"negativeLineColor": "#637bb6",
	"type": "smoothedLine",
	"valueField": "SUM_KVAR"
	}],
	"chartCursor": {
	"categoryBalloonDateFormat": "YYYY  ",
	"cursorAlpha": 0,
	"valueLineEnabled":true,
	"valueLineBalloonEnabled":true,
	"valueLineAlpha":0.5,
	"labelRotation": 90,
	"fullWidth":true
	},
	"categoryField": "tm",
	"chartScrollbar": {
	"graph":"g1",
	"gridAlpha":0,
	"color":"#888888",
	"scrollbarHeight":55,
	"backgroundAlpha":0,
	"selectedBackgroundAlpha":0.1,
	"selectedBackgroundColor":"#888888",
	"graphFillAlpha":0,
	"autoGridCount":false,
	"selectedGraphFillAlpha":0,
	"graphLineAlpha":0.2,
	"graphLineColor":"#c2c2c2",
	"selectedGraphLineColor":"#888888",
	"selectedGraphLineAlpha":1
	},
	"categoryAxis": {
	"parseDates": false,
	"minorGridAlpha": 0.1,
	"labelRotation": 90,
	"minorGridEnabled": true
	},
	
	"export": {
	"enabled": true
	}
	});
	</script>
    <script type="text/javascript">
	var disp = document.getElementById(\'mutiLinedataProvider\').value;
	var disp = JSON.parse(disp);
	var chart = AmCharts.makeChart("chartdiv5", {
	"type": "serial",
	"theme": "light",
	"marginTop":0,
	"marginRight": 80,
	"dataProvider": disp,
	"valueAxes": [{
	"axisAlpha": 0,
	"position": "left"
	}],
	"graphs": [{
	"id":"g1",
	"balloonText": "TM :[[category]]<br><b><span style=\'font-size:14px;\'> SUM_PF  : [[value]]</span></b>",
	"bullet": "round",
	"bulletSize": 2,         
	"lineColor": "Red",
	"lineThickness": 1,
	"negativeLineColor": "#637bb6",
	"type": "smoothedLine",
	"valueField": "SUM_PF"
	}],
	"chartCursor": {
	"categoryBalloonDateFormat": "YYYY  ",
	"cursorAlpha": 0,
	"valueLineEnabled":true,
	"valueLineBalloonEnabled":true,
	"valueLineAlpha":0.5,
	"labelRotation": 90,
	"fullWidth":true
	},
	"categoryField": "tm",
	"chartScrollbar": {
	"graph":"g1",
	"gridAlpha":0,
	"color":"#888888",
	"scrollbarHeight":55,
	"backgroundAlpha":0,
	"selectedBackgroundAlpha":0.1,
	"selectedBackgroundColor":"#888888",
	"graphFillAlpha":0,
	"autoGridCount":false,
	"selectedGraphFillAlpha":0,
	"graphLineAlpha":0.2,
	"graphLineColor":"#c2c2c2",
	"selectedGraphLineColor":"#888888",
	"selectedGraphLineAlpha":1
	},
	"categoryAxis": {
	"parseDates": false,
	"minorGridAlpha": 0.1,
	"labelRotation": 90,
	"minorGridEnabled": true
	},
	
	"export": {
	"enabled": true
	}
	});
	</script>
    <script type="text/javascript">
	var disp = document.getElementById(\'mutiLinedataProvider\').value;
	var disp = JSON.parse(disp);
	var chart = AmCharts.makeChart("chartdiv6", {
	"type": "serial",
	"theme": "light",
	"marginTop":0,
	"marginRight": 80,
	"dataProvider": disp,
	"valueAxes": [{
	"axisAlpha": 0,
	"position": "left"
	}],
	"graphs": [{
	"id":"g1",
	"balloonText": "TM :[[category]]<br><b><span style=\'font-size:14px;\'> KWH  : [[value]]</span></b>",
	"bullet": "round",
	"bulletSize": 2,         
	"lineColor": "Red",
	"lineThickness": 1,
	"negativeLineColor": "#637bb6",
	"type": "smoothedLine",
	"valueField": "KWH"
	}],
	"chartCursor": {
	"categoryBalloonDateFormat": "YYYY  ",
	"cursorAlpha": 0,
	"valueLineEnabled":true,
	"valueLineBalloonEnabled":true,
	"valueLineAlpha":0.5,
	"labelRotation": 90,
	"fullWidth":true
	},
	"categoryField": "tm",
	"chartScrollbar": {
	"graph":"g1",
	"gridAlpha":0,
	"color":"#888888",
	"scrollbarHeight":55,
	"backgroundAlpha":0,
	"selectedBackgroundAlpha":0.1,
	"selectedBackgroundColor":"#888888",
	"graphFillAlpha":0,
	"autoGridCount":false,
	"selectedGraphFillAlpha":0,
	"graphLineAlpha":0.2,
	"graphLineColor":"#c2c2c2",
	"selectedGraphLineColor":"#888888",
	"selectedGraphLineAlpha":1
	},
	"categoryAxis": {
	"parseDates": false,
	"minorGridAlpha": 0.1,
	"labelRotation": 90,
	"minorGridEnabled": true
	},
	
	"export": {
	"enabled": true
	}
	});
	</script>
	<script>
		var dataProvider = document.getElementById(\'mutiLinedataProvider\').value;
		var Graphs = document.getElementById(\'mutiLinegraph\').value;
		var jsondataProvider = JSON.parse(dataProvider);
		var jsondataGraph = JSON.parse(Graphs);
		var linechart = AmCharts.makeChart("linechartdiv", {
		"type": "serial",
		"theme": "light",
		"dataProvider": jsondataProvider,
		"valueAxes": [{
		"gridColor": "#FFFFFF",
		"gridAlpha": 0.2,
		"dashLength": 0
		}],
		"gridAboveGraphs": true,
		"startDuration": 0.3,
		"graphs":jsondataGraph,
		"fontSize": 14,
		"chartCursor": {
		"categoryBalloonEnabled": false,
		"cursorAlpha": 0,
		"zoomable": false
		},
		"categoryField": "category",
		"categoryAxis": {
		"gridPosition": "start",
		"gridAlpha": 0
		},
		"export": {
		"enabled": true
		},
		"legend": {}
		});
	</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	'; ?>
