<?php /* Smarty version 2.6.25, created on 2026-07-16 13:12:25
         compiled from utility_dashboard3.tpl */ ?>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>

<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
<!-- Font Awesome -->
<link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
<!-- Ionicons -->
<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">


<!-- jQuery Knob -->
<script src="plugins/jquery-knob/jquery.knob.min.js"></script>
<?php echo '
<script>
$(function () {
/* jQueryKnob */

$(\'.knob\').knob({
/*change : function (value) {
//console.log("change : " + value);
},
release : function (value) {
console.log("release : " + value);
},
cancel : function () {
console.log("cancel : " + this.value);
},*/
draw: function () {

// "tron" case
if (this.$.data(\'skin\') == \'tron\') {

var a   = this.angle(this.cv)  // Angle
,
sa  = this.startAngle          // Previous start angle
,
sat = this.startAngle         // Start angle
,
ea                            // Previous end angle
,
eat = sat + a                 // End angle
,
r   = true

this.g.lineWidth = this.lineWidth

this.o.cursor
&& (sat = eat - 0.3)
&& (eat = eat + 0.3)

if (this.o.displayPrevious) {
ea = this.startAngle + this.angle(this.value)
this.o.cursor
&& (sa = ea - 0.3)
&& (ea = ea + 0.3)
this.g.beginPath()
this.g.strokeStyle = this.previousColor
this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, sa, ea, false)
this.g.stroke()
}

this.g.beginPath()
this.g.strokeStyle = r ? this.o.fgColor : this.fgColor
this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, sat, eat, false)
this.g.stroke()

this.g.lineWidth = 2
this.g.beginPath()
this.g.strokeStyle = this.o.fgColor
this.g.arc(this.xy, this.xy, this.radius - this.lineWidth + 1 + this.lineWidth * 2 / 3, 0, 2 * Math.PI, false)
this.g.stroke()

return false
}
}
})
/* END JQUERY KNOB */


})

</script>
'; ?>

<body onLoad="doOnLoad();">
  <div class="content-wrapper">
    <div class="content-header">
      <div class="container-fluid">
        <div class="row"> 
          <div class="col-md-12">
            <div class="card">
              <div class="card-body">
                <table style="margin-bottom:-10px;">
                  <tr>
                    <td style="font-size:15PX;font-weight: bold;"><?php echo $this->_tpl_vars['companyDetail']['0']['companyName']; ?>
&nbsp;&nbsp;</td>
                    <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
                    <td style="font-size:15PX;font-weight: bold;"><?php echo $this->_tpl_vars['branchDetail']['0']['branch_name']; ?>
&ensp;&ensp;</td>
                    <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
                    <td style="font-size:15PX;font-weight: bold;">Utility Dashboard</font>&nbsp;</td></tr>
                    <tr><td style="font-size:10PX;color:#999999;">Company Name</td>
                    <td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                    <td style="font-size:10PX;color:#999999;">Branch Name</td>
                    <td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                    <td style="color:#999999;font-size:10PX;">Dashboard</td><td>&nbsp;</td>
                  </tr>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- /.col -->
          <?php $_from = $this->_tpl_vars['PlatformMapListView']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['platformId']):
?>
            <?php if ($this->_tpl_vars['platformId']['segmentCode'] == $this->_tpl_vars['energySegId']): ?>
              
          <div class="col-md-2 col-sm-6 col-12">
            <div class="info-box shadow-lg  card-outline card-warning" style="background-color: rgb(245, 224, 161);border-style: solid;border-color:#ffc107">
           
              <span class="info-box-icon bg-warning "><i class="ion ion-flash"></i></span>
              <div class="info-box-content">
               <a href="dashboard.php?companyId=<?php echo $this->_supers['get']['companyId']; ?>
&branchId=<?php echo $this->_supers['get']['branchId']; ?>
" target="_blank" style=" color:black">
                <span class="info-box-text">Total Energy</span>
                <span class="info-box-number"><?php echo $this->_tpl_vars['TodayDashTotalEnergy']['0']['total_energy']; ?>
  kwh </span>
                 </a>
              </div>
              <!-- /.info-box-content -->
             
            </div>
            <!-- /.info-box -->
          </div>
          
            <?php endif; ?>
          <?php endforeach; endif; unset($_from); ?>
          <!-- /.col -->
          <!-- /.col -->
          <?php if ($this->_tpl_vars['freshWaterPlatformCount'] >= 1): ?>
          <div class="col-md-2 col-sm-6 col-12">
            <div class="info-box shadow-lg card-outline card-info" style="background-color: rgb(221, 244, 248);border-style: solid;border-color:#17a2b8">
              <span class="info-box-icon bg-info"><i class="fa fa-water"></i></span>
              <div class="info-box-content">
                <span class="info-box-text">Water Usage</span>
                <span class="info-box-number"><?php echo $this->_tpl_vars['TodayDashFreshWater']['0']['totalizer']; ?>
 L </span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <?php endif; ?>
          <!-- /.col -->
          <!-- /.col -->
          <div class="col-md-2 col-sm-6 col-12">
            <div class="info-box shadow-lg card-outline card-grey-dark" style="background-color: rgb(243, 245, 248);border-style: solid;border-color:#adb5bd">
              <span class="info-box-icon bg-grey"><i class="ion ion-shuffle"></i></span>
              <div class="info-box-content">
                <span class="info-box-text">Comp Air Usage</span>
                <span class="info-box-number">259 cfm</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <!-- /.col -->
          <?php if ($this->_tpl_vars['temperaturePlatformCount'] >= 1): ?>
          <div class="col-md-2 col-sm-6 col-12">
            <div class="info-box shadow-lg card-outline card-primary " style="background-color: rgb(183, 207, 226);border-style: solid;border-color:#007bff">
              <span class="info-box-icon bg-primary"><i class="ion ion-thermometer"></i></span>
              <div class="info-box-content">
                <span class="info-box-text">Avg Temperature</span>
                <span class="info-box-number"><?php echo $this->_tpl_vars['TodayOutdoorTemp']['0']['avg_temp']; ?>
 &deg; C</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <?php endif; ?>
          <!-- /.col -->
          <!-- /.col -->
          <div class="col-md-2 col-sm-6 col-12">
            <div class="info-box shadow-lg card-outline card-success" style="background-color: rgb(199, 247, 221);border-style: solid;border-color: #28a745">
              <span class="info-box-icon bg-success"><i class="ion ion-battery-half"></i></span>
              <div class="info-box-content">
                <span class="info-box-text">UPS Percentage</span>
                <span class="info-box-number">85 % </span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <!-- /.col -->
          
          <div class="col-md-2 col-sm-6 col-12">
          
            <div class="info-box shadow-lg card-outline card-danger "  style="background-color: rgb(254, 216, 216); border-style: solid;border-color: #dc3545;" >
              <span class="info-box-icon bg-danger"><i class="fas fa-exclamation-triangle"></i></span>
              <div class="info-box-content  ">
                <span class="info-box-text">Active Alerts</span>
                <a href="listIncidentLog.php?companyId=<?php echo $this->_supers['get']['companyId']; ?>
&branchId=<?php echo $this->_supers['get']['branchId']; ?>
" target="_blank">
                <span class="info-box-number"><?php echo $this->_tpl_vars['incidentListDashCount']; ?>
 issues</span>
                  </a>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
           
          </div>
         
          <!-- /.col -->                                           
        </div>
        <!-- /.row -->
        <!-- Main row -->
        <div class="row">
          <!-- Left col -->
          <section class="col-lg-9 connectedSortable">
            <!-- Custom tabs (Charts with tabs)-->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title"><i class="fas fa-chart-pie mr-1"></i>Energy Consuption</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <div class="tab-content p-0">
                  <div class="row">
                    <div class="col-md-4 col-sm-6 col-12">
                      <div class="info-box bg-gradient-warning">
                        <span class="info-box-icon"><i class="far fa-calendar-alt"></i></span>
                        <div class="info-box-content">
                          <span class="info-box-text">Today Grid Power</span>
                          <span class="info-box-number"><?php echo $this->_tpl_vars['TodayDashGridEnergy']['0']['total_energy']; ?>
 kwh</span>
                          <div class="progress" style=" height:10PX; border-radius: 10px; ">
                            <div class="progress-bar" style="width: 70%"></div>
                          </div>
                          <span class="progress-description"><?php echo $this->_tpl_vars['gridPercent']; ?>
% Utilized Energy</span>
                        </div>
                      <!-- /.info-box-content -->
                      </div>
                      <!-- /.info-box -->
                    </div>
                    <!-- /.col -->
                    <div class="col-md-4 col-sm-6 col-12">
                      <div class="info-box bg-gradient-danger "  >
                        <span class="info-box-icon" ><i class="fa fa-gas-pump"></i></span>
                        <div class="info-box-content">
                          <span class="info-box-text">Today Diesel Generator</span>
                          <span class="info-box-number"><?php echo $this->_tpl_vars['TodayDashDGEnergy']['0']['dg_energy']; ?>
 kwh</span>
                          <div class="progress" style=" height:10PX; border-radius: 10px; ">
                            <div class="progress-bar" style="width: 10%; height: 20px; "></div>
                          </div>
                          <span class="progress-description">
                          <?php echo $this->_tpl_vars['dgPercent']; ?>
% Utilized Energy
                          </span>
                        </div>
                        <!-- /.info-box-content -->
                      </div>
                      <!-- /.info-box -->
                    </div>
                    <!-- /.col -->
                    <div class="col-md-4 col-sm-6 col-12">
                      <div class="info-box bg-gradient-success">
                        <span class="info-box-icon"><i class="fa fa-solar-panel"></i></span>
                          <div class="info-box-content">
                            <span class="info-box-text">Today Renewable Energy
                            <!--<h6 class="widget-user-desc">Solar</h6>Renewable Energy--></span>
                            <span class="info-box-number"><?php echo $this->_tpl_vars['TodayDashSolarEnergy']['0']['total_solar_energy']; ?>
 kwh</span>
                            <div class="progress " style=" height:10PX; border-radius: 10px; ">
                              <div class="progress-bar" style="width: 20%;" height="2PX"></div>
                            </div>
                          <span class="progress-description"><?php echo $this->_tpl_vars['solarPercent']; ?>
% Utilized Energy</span>
                        </div>
                        <!-- /.info-box-content -->
                      </div>
                      <!-- /.info-box -->
                    </div>
                    <!-- /.col -->
                    <div class="col-md-4 col-sm-6 col-12">
                      <div class="info-box "  style="background-color: rgb(245, 224, 161); border-style: solid;border-color: #ffc107">
                        <span class="info-box-icon" style="background-color: #ffc107;color: white;"><i class="far fa-calendar-alt"></i></span>
                        <div class="info-box-content">
                          <span class="info-box-text">This Month Grid Power</span>
                          <span class="info-box-number"><?php echo $this->_tpl_vars['ThisMonthDashGridEnergy']['0']['total_energy']; ?>
 kwh</span>
                          <div class="progress" style=" height:10PX; border-radius: 10px; ">
                            <div class="progress-bar bg-primary progress-bar-striped" style="width: 70%"></div>
                          </div>
                          <span class="progress-description"><?php echo $this->_tpl_vars['thismonthgridPercent']; ?>
% Utilized Energy</span>
                        </div>
                        <!-- /.info-box-content -->
                      </div>
                      <!-- /.info-box -->
                    </div>
                    <!-- /.col -->
                    <!-- /.col -->
                    <div class="col-md-4 col-sm-6 col-12">
                      <div class="info-box "  style="background-color: rgb(254, 216, 216); border-style: solid;border-color: #dc3545;" >
                        <span class="info-box-icon" style="background-color: #dc3545;color: white;"><i class="fa fa-gas-pump"></i></span>
                        <div class="info-box-content">
                          <span class="info-box-text">This Month Diesel Generator</span>
                          <span class="info-box-number"><?php echo $this->_tpl_vars['ThisMonthDashDGEnergy']['0']['dg_energy']; ?>
 kwh</span>
                          <div class="progress" style=" height:10PX; border-radius: 10px; ">
                            <div class="progress-bar  bg-primary progress-bar-striped" style="width: 10%; height: 20px; "></div>
                          </div>
                          <span class="progress-description"><?php echo $this->_tpl_vars['thismonthdgPercent']; ?>
% Utilized Energy</span>
                        </div>
                        <!-- /.info-box-content -->
                      </div>
                      <!-- /.info-box -->
                    </div>
                    <!-- /.col -->
                    <div class="col-md-4 col-sm-6 col-12">
                      <div class="info-box " style="background-color: rgb(199, 247, 221);border-style: solid;border-color: #28a745">
                        <span class="info-box-icon" style="background-color: #28a745;color: white;"><i class="fa fa-solar-panel"></i></span>
                        <div class="info-box-content">
                          <span class="info-box-text" style="word-spacing: -2px; margin-left:-10px;">This Month Renewable Energy
                          <!--<h6 class="widget-user-desc">Solar</h6>Renewable Energy--></span>
                          <span class="info-box-number"><?php echo $this->_tpl_vars['ThisMonthDashSolarEnergy']['0']['total_solar_energy']; ?>
 kwh</span>
                          <div class="progress " style=" height:10PX; border-radius: 10px; ">
                            <div class="progress-bar bg-primary progress-bar-striped" style="width: 20%;" height="2PX"></div>
                          </div>
                          <span class="progress-description"><?php echo $this->_tpl_vars['thismonthsolarPercent']; ?>
% Utilized Energy</span>
                        </div>
                        <!-- /.info-box-content -->
                      </div>
                      <!-- /.info-box -->
                    </div>
                    <!-- /.col -->
                  </div>
                  <!-- /.row -->
                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->
          </section>
          <!-- /.Left col -->
          <!-- right col (We are only adding the ID to make the widgets sortable)-->
          <section class="col-lg-3 connectedSortable">
            <!-- row -->
            <div class="row">
              <div class="col-12">
                <!-- jQuery Knob -->
                <div class="card">
                  <div class="card-header">
                    <h3 class="card-title"><i class="ion ion-thermometer"></i> &ensp;Temperature</h3>
                    <div class="card-tools">
                      <button type="button" class="btn btn-tool" data-card-widget="collapse">
                        <i class="fas fa-minus"></i>
                      </button>
                      <button type="button" class="btn btn-tool" data-card-widget="remove">
                        <i class="fas fa-times"></i>
                      </button>
                    </div>
                  </div>
                  <!-- /.card-header -->
                  <div class="card-body">
                    <div class="row">
                      <div class="col-6 col-md-6 text-center">
                        <input type="text" class="knob" data-thickness="0.5" data-angleArc="250" data-angleOffset="-125" value="<?php echo $this->_tpl_vars['TodayOutdoorHumidity']['0']['current_temp']; ?>
" data-width="90" data-height="90" data-fgColor="#3c8dbc">
                        <div class="knob-label">Temperature &deg;C</div>
                      </div>
                      <!-- ./col -->
                      <div class="col-6 col-md-6 text-center">
                        <input type="text" class="knob" data-thickness="0.5" data-angleArc="250" data-angleOffset="-125" value="<?php echo $this->_tpl_vars['TodayOutdoorHumidity']['0']['humidity']; ?>
" data-width="90" data-height="90" data-fgColor="#f56954">
                        <div class="knob-label">Humidity % RH</div>
                      </div>
                      <!-- ./col -->
                    </div>
                    <!-- /.row -->
                    <hr >
                    <br>
                    <div class="row">
                      <div class="col-4 col-md-4 text-center">
                        <input type="text" class="knob" value="<?php echo $this->_tpl_vars['TodayOutdoorTemp']['0']['avg_temp']; ?>
" data-width="50" data-height="50" data-fgColor="#171192ff">
                        <div class="knob-label">Avg Temp</div>
                      </div>
                      <!-- ./col -->
                      <div class="col-4 col-md-4 text-center">
                        <input type="text" class="knob" value="<?php echo $this->_tpl_vars['TodayOutdoorTemp']['0']['min_temp']; ?>
" data-width="50" data-height="50" data-fgColor="#569bc3ff">
                        <div class="knob-label">Min Temp</div>
                      </div>
                      <!-- ./col -->
                      <div class="col-4 col-md-4 text-center">
                        <input type="text" class="knob" value="<?php echo $this->_tpl_vars['TodayOutdoorTemp']['0']['max_temp']; ?>
" data-width="50" data-height="50" data-fgColor="#fb5e5eff">
                        <div class="knob-label">Max Temp</div>
                      </div>
                      <!-- ./col -->
                    </div>
                    <!-- /.row -->
                  </div>
                  <!-- /.card-body -->
                </div>
               
                <!-- /.card -->
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->
          </section>
          <!-- right col -->
          <section class="col-lg-6 connectedSortable">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title"><i class="fa fa-water"></i> Water Management</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body" >
<div class="row"> 
              <div class="col-12 col-sm-12" > 
                  <div class="col-12 col-sm-12" style="background-color: rgba(184, 246, 238, 1);border-style: solid;border-color: #35dcc9ff; border-radius: 15px;"> 
                  <br>
<center><h4 style="font-size:15PX;font-weight: bold;">Overall Usage</h4></center>
                  <div class="info-box shadow-lg card-outline card-info" style="background-color: rgb(221, 244, 248);border-style: solid;border-color:#17a2b8; border-radius: 15px;">
                    <span class="info-box-icon bg-info"><i class="fa fa-water"></i></span>
                    
                    <div class="info-box-content">
                     <?php $this->assign('waterUsage', $this->_tpl_vars['TodayDashFreshWater']['0']['totalizer']); ?>
                        <?php $this->assign('DistilledUsage', $this->_tpl_vars['TodayDashDistilledWater']['0']['totalizer']); ?>
                        <?php $this->assign('overallUsage', $this->_tpl_vars['waterUsage']+$this->_tpl_vars['DistilledUsage']); ?>
                      <span class="info-box-number"><?php echo $this->_tpl_vars['overallUsage']; ?>
 L </span>
                      <div class="progress " style=" height:10PX; border-radius: 10px; ">
                        <div class="progress-bar bg-primary progress-bar-striped" style="width: 69%;" height="2PX"></div>
                      </div>
                      <span class="progress-description">69% Remaining Capacity</span>
                    </div>
                    <!-- /.info-box-content -->

                  </div>
                  
                  <!-- /.row -->
                </div>
                <!-- /.col -->
              </div>
</div>
<br/>
                <div class="row">              
                <!-- /.col -->
                <div class="col-md-6 col-sm-6 col-12">
                  <div class="info-box shadow-lg card-outline card-info" style="background-color: rgb(221, 244, 248);border-style: solid;border-color:#17a2b8; border-radius: 15px;">
                    <span class="info-box-icon bg-info"><i class="fa fa-water"></i></span>
                    
                    <div class="info-box-content">
                      <span class="info-box-text">Overhead Tank Usage</span>
                      <span class="info-box-number"><?php echo $this->_tpl_vars['TodayDashFreshWater']['0']['totalizer']; ?>
 L </span>
                      <div class="progress " style=" height:10PX; border-radius: 10px; ">
                        <div class="progress-bar bg-primary progress-bar-striped" style="width: 69%;" height="2PX"></div>
                      </div>
                      <span class="progress-description">69% Remaining Capacity</span>
                      <span class="float-right badge bg-primary">Normal Operation</span>
                    </div>
                    <!-- /.info-box-content -->

                  </div>
                  <!-- /.info-box -->
                </div>
                <!-- /.col -->
                <!-- /.col -->
                <div class="col-md-6 col-sm-6 col-12">
                  <div class="info-box shadow-lg card-outline card-warning" style="background-color: rgba(241, 254, 105, 1);border-style: solid;border-color:#ffc107 ; border-radius: 15px;">
                    <span class="info-box-icon bg-warning"><i class="fa fa-water"></i></span>
                    <div class="info-box-content">
                      <span class="info-box-text">Undergroud Sump</span>
                      <span class="info-box-number"><?php echo $this->_tpl_vars['TodayDashDistilledWater']['0']['totalizer']; ?>
 L </span>
                      <div class="progress " style=" height:10PX; border-radius: 10px; ">
                        <div class="progress-bar bg-primary progress-bar-striped" style="width: 58%;" height="2PX"></div>
                      </div>
                      <span class="progress-description">58% Remaining Capacity</span>
                      <span class="float-right badge bg-danger">Refill Required </span>
                    </div>
                    <!-- /.info-box-content -->
                  </div>
                  <!-- /.info-box -->
                </div>
                <!-- /.col -->
                
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </section>
          <!-- right col close -->
          <section class="col-lg-3 connectedSortable">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title"><i class="fas fa-chart-pie mr-1"></i>Compressed Air usage</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body" >
                <div class="row">
                  <!-- /.col -->
                  <div class="col-md-12 col-sm-6 col-12">
                    <div class="info-box shadow-lg  card-outline card-grey-dark" style="background-color: rgb(243, 245, 248);border-style: solid;border-color:#adb5bd"; border-radius: 15px;">
                      <span class="info-box-icon bg-grey"><i class="ion ion-shuffle"></i></span>
                      <div class="info-box-content">
                        <span class="info-box-text">Compressed Air Usage</span>
                        <span class="info-box-number">153 cfm </span>
                      </div>
                      <!-- /.info-box-content -->
                    </div>
                    <!-- /.info-box -->
                  </div>
                  <!-- /.col -->
                </div>
                <!-- /.row -->
              </div>
              <!-- /.card-body -->
            </div>
          </section>

          <section class="col-lg-3 connectedSortable">
            <!-- Alert & Status -->
          <div class="col-md-12">
            <div class="card card-default">
              <div class="card-header">
                <h3 class="card-title">
                  <i class="fas fa-exclamation-triangle"></i>
                  Alerts
                </h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <div class="alert alert-danger alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <span><i class="icon fas fa-ban"></i> Energy Alert !</span>
                  <span> Voltage Reaches High  </span>
                </div>
                <div class="alert alert-info alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <span><i class="icon fas fa-info"></i> Temperature Alert!</h5>
                  <span>  High Temperature  </span>
                </div>
                <div class="alert alert-warning alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <span><i class="icon fas fa-exclamation-triangle"></i>Water Alert!</span>
                  <span>Sump Refill Required </span>
                </div>
                <div class="alert alert-success alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <span><i class="icon fas fa-check"></i> UPS Alert!</span>
                  <span>Healthy UPS Percentage</span>
                </div>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
          </section>
        </div>
        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->
    </section>
  </div>
</body>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>