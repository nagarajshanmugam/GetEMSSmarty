<?php /* Smarty version 2.6.25, created on 2025-11-17 13:29:54
         compiled from locationAddEdit.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'base64_decode', 'locationAddEdit.tpl', 46, false),array('modifier', 'date_format', 'locationAddEdit.tpl', 114, false),)), $this); ?>
	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;"><?php if ($this->_tpl_vars['companyDetail']['0']['companyName'] != ""): ?><?php echo $this->_tpl_vars['companyDetail']['0']['companyName']; ?>
<?php else: ?><?php echo $this->_supers['session']['CompanyName']; ?>
<?php endif; ?>&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;"><?php if ($this->_tpl_vars['ListBranchGet']['0']['branch_name'] != ""): ?><?php echo $this->_tpl_vars['ListBranchGet']['0']['branch_name']; ?>
<?php else: ?><?php echo $this->_supers['session']['branch_name']; ?>
<?php endif; ?>&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;"><?php if ($this->_supers['get']['locId'] == ""): ?>Create Location<?php else: ?>Edit Location<?php endif; ?></font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:10PX;color:#999999;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			<a href="locationList.php?companyId=<?php echo $this->_supers['get']['companyId']; ?>
&branchId=<?php echo $this->_supers['get']['branchId']; ?>
"><button type="button" style="float:right;margin-top:-40PX" class="btn btn-primary">List Location</button></a>
			</div>
				<?php if ($this->_tpl_vars['SuccessMessage'] != "" || $this->_tpl_vars['ErrorMessage'] != ""): ?>
					<div class="card-body">
					<?php if ($this->_tpl_vars['SuccessMessage'] != ""): ?>
						<div class="isa_success">
						<i class="fa fa-check"></i>
						<?php echo $this->_tpl_vars['SuccessMessage']; ?>
		 
						</div>
					<?php endif; ?>
					<?php if ($this->_tpl_vars['ErrorMessage'] != ""): ?>
						<div class="isa_error">
						<i class="fa fa-check"></i>
						<?php echo $this->_tpl_vars['ErrorMessage']; ?>
		 
						</div>
					<?php endif; ?>
					</div>
				<?php endif; ?>
		</div>    
		<div class="card">
			<div class="card-body">
				<form role="form" name="locationRegForm" id="locationRegForm" method="post" onsubmit="return createValidation();" >
					<input type="hidden" name="hdAction" />
					<input type="hidden" id="check_id" name="check_id" value="<?php echo $this->_supers['post']['check_id']; ?>
">
					<input type="hidden" id="checkVal" name="checkVal" value="<?php echo $this->_supers['post']['checkVal']; ?>
" />
					<input type="hidden" id="company_id" name="company_id" value="<?php echo $this->_tpl_vars['comId']; ?>
" />
					<input type="hidden" id="platId" name="platId" value="<?php echo $this->_tpl_vars['ListEditView']['0']['slNo']; ?>
" />
					<input type="hidden" id="updateYesNo" name="updateYesNo" value="<?php echo $this->_tpl_vars['otherLocationId']; ?>
" />
					<input type="hidden" id="locMasId" name="locMasId" value="<?php echo ((is_array($_tmp=$this->_supers['get']['locId'])) ? $this->_run_mod_handler('base64_decode', true, $_tmp) : base64_decode($_tmp)); ?>
" />
					<input type="hidden" id="changeSensorId" name="changeSensorId" value="" />
					<input type="hidden" id="PreviousSensorId" name="PreviousSensorId" value="<?php echo $this->_tpl_vars['ListEditView']['0']['sensor_id']; ?>
" />
					<div class="row">
					<?php if ($this->_supers['get']['locId']): ?>
						<div class="form-group col-md-6">
							<label for="exampleInputgatewayId">Location Code <span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm" id="locationCode" name="locationCode" placeholder="Enter Location Code" value="<?php if ($this->_tpl_vars['ListEditView']['0']['location_code'] != ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['location_code']; ?>
<?php else: ?><?php echo $this->_supers['post']['locationCode']; ?>
<?php endif; ?>" tabindex="1" readonly autocomplete="Off">
						</div>
					<?php endif; ?>		
						<div class="form-group col-md-6">
							<label for="exampleInputserialNo">Location Name <span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm" id="locationName" name="locationName" placeholder="Enter Location Name" value="<?php if ($this->_tpl_vars['ListEditView']['0']['location_name'] != ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['location_name']; ?>
<?php else: ?><?php echo $this->_supers['post']['locationName']; ?>
<?php endif; ?>" tabindex="2" autocomplete="Off">
						</div>
						<div class="form-group col-md-6">
						<label for="exampleInputmodel">Sensor <span style="color:red;">*</span></label>

							<select id="sensor" name="sensor" class="form-control form-control-sm" tabindex="7" onchange="sensorCheck(this.value);">
							<option value="">--- Select Sensor ---</option>
							<?php $_from = $this->_tpl_vars['ListSensorView']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['sensorDet']):
?>
							<option value="<?php echo $this->_tpl_vars['sensorDet']['slNo']; ?>
"
							<?php if (isset ( $this->_supers['post']['sensor'] ) && $this->_supers['post']['sensor'] == $this->_tpl_vars['sensorDet']['slNo']): ?>
							selected="selected"
							<?php elseif ($this->_tpl_vars['ListEditView']['0']['sensor_id'] == $this->_tpl_vars['sensorDet']['slNo']): ?>
							selected="selected"
							<?php endif; ?>
							>
							<?php echo $this->_tpl_vars['sensorDet']['sensorName']; ?>

							</option>
							<?php endforeach; endif; unset($_from); ?>
							</select>
						</div>
						<div class="form-group col-md-6">
						<label for="exampleInputmodel">IOT Device <span style="color:red;">*</span></label>
						<select  id="iotDevice" name="iotDevice" class="form-control form-control-sm"  tabindex="7" onchange="ChangeMake(this.value);">
						<option value="">--- Select IOT Device ---</option>
                        <?php $_from = $this->_tpl_vars['ListGatewayView']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['gatewayDet']):
?>
							
						<option value="<?php echo $this->_tpl_vars['gatewayDet']['gateway_sl_no']; ?>
"
						<?php if (isset ( $this->_supers['post']['iotDevice'] ) && $this->_supers['post']['iotDevice'] == $this->_tpl_vars['gatewayDet']['gateway_sl_no']): ?>
							selected="selected"
						<?php elseif ($this->_tpl_vars['ListEditView']['0']['iot_id'] == $this->_tpl_vars['gatewayDet']['gateway_sl_no']): ?>
							selected="selected"
						<?php endif; ?>
						>
						<?php echo $this->_tpl_vars['gatewayDet']['gateway_id']; ?>
						
						</option>
						<?php endforeach; endif; unset($_from); ?>
						</select>
						</div>
                           <div class="form-group col-md-6">
							<label for="exampleInputgatewayId">Branch <span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm" id="branch" name="branch" placeholder="Enter Branch" value="<?php if ($this->_tpl_vars['ListBranchView']['0']['branch_name'] != ''): ?><?php echo $this->_tpl_vars['ListBranchView']['0']['branch_name']; ?>
<?php endif; ?>" tabindex="1" readonly >
						</div>
						<div class="form-group col-md-6">
							<div class="custom-control custom-checkbox">
							<?php if ($this->_tpl_vars['ListEditView']['0']['is_active'] == '1'): ?>
								<input class="custom-control-input" type="checkbox" id="customCheckbox2"  name="customCheckbox2" tabindex="7" checked="checked">
								<label for="customCheckbox2" class="custom-control-label">Is Active</label>
							<?php elseif ($this->_tpl_vars['ListEditView']['0']['is_active'] == '0'): ?>
								<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="7">
								<label for="customCheckbox2" class="custom-control-label">Is Active</label>
							<?php else: ?>
								<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="7" checked="checked">
								<label for="customCheckbox2" class="custom-control-label">Is Active</label>
							<?php endif; ?>
							</div>
							<input id="created_by" name="created_by" class="date-picker form-control" type="hidden" value="<?php echo $this->_supers['session']['UserName']; ?>
" readonly="true">
							<input type="hidden" class="form-control" id="timestamp" name="timestamp" value="<?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d &amp; %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d &amp; %H:%M:%S')); ?>
">
							<input type="hidden" class="form-control" id="created_time" name="created_time" placeholder="Time" Value="<?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%I:%M:%S %p') : smarty_modifier_date_format($_tmp, '%I:%M:%S %p')); ?>
">
						</div>
					</div>
					<div align="center">
					<input type="submit" value="Submit" class="btn btn-create" tabindex="8" />
					</div>
				</form>
			</div>
		</div>
	</div>	
	</section>
	</div>
	<?php echo '
	<script type="text/javascript">

	var previousSensorValue = $(\'#PreviousSensorId\').val();   // global variable

function sensorCheck(postsensorId){

    // Set the value in the input
    $(\'#changeSensorId\').val(postsensorId);

    // Now get the updated value
    var postsensorIdVal = $(\'#changeSensorId\').val();

    // Get location value
    var locationMasId = $(\'#locMasId\').val();

    // Show alerts
    //alert("Sensor Id"+postsensorIdVal);
    //alert("Location Id"+locationMasId);

    // Ajax call
    $.ajax({
        type: "POST",
        url: "ajaxLocationSensor.php",
        data: {
            postsensorVal: postsensorIdVal,
            locMas: locationMasId
        },
        dataType: "JSON",
        cache: false,
        success: function(result){
            //alert(result);
            var len = result.length;
			var existingLoc = result[0]["location_master_id"];
			var existingLocCode = result[0]["location_code"];
			
			if (existingLoc !== \'\' && existingLoc !== null) {

            // Show confirmation alert
            if (confirm("This sensor is already active in "+existingLocCode+" location.Do you want to update it?")) {
                // User clicked OK
                // Call another function or continue update
                //alert("Updating...");

            } else {
                // User clicked Cancel
                alert("Update cancelled.");
				// Cancel → reset to previous selection
                $(\'#sensor\').val(previousSensorValue);
                return false;
            }
        }

        },
        error: function(result) {
            alert(\'error\');
        }
    });

}
</script>

		<script type="text/javascript">
		function createValidation()
		{
			//var locationCode = $(\'#locationCode\').val();
			var locationName = $(\'#locationName\').val();
			var sensor = $(\'#sensor\').val();
			var iotDevice = $(\'#iotDevice\').val();
			var branch = $(\'#branch\').val();
			var isActive = document.getElementById("customCheckbox2").checked;
		if (isActive == false) 
		{
			document.getElementById(\'checkVal\').value=\'0\';
		}
		else
		{
			document.getElementById(\'checkVal\').value=\'1\';
		}
		
			$(".error").remove();
		/* if (locationCode.length < 1) {
			$(\'#locationCode\').after(\'<span class="error">This field is required</span>\');
			$(\'#locationCode\').focus();
			return false;					
		}else */
		if (locationName < 1) {
			$(\'#locationName\').after(\'<span class="error">This field is required</span>\');
			$(\'#locationName\').focus();
			return false;					
		}
		else if (sensor < 1) {
			$(\'#sensor\').after(\'<span class="error">This field is required</span>\');
			$(\'#sensor\').focus();
			return false;					
		}
		else if (iotDevice < 1) {
			$(\'#iotDevice\').after(\'<span class="error">This field is required</span>\');
			$(\'#iotDevice\').focus();
			return false;					
		}
		else if (branch < 1) {
			$(\'#branch\').after(\'<span class="error">This field is required</span>\');
			$(\'#branch\').focus();
			return false;					
		}
		
			FormName		= document.locationRegForm;
			FormName.method	= "POST";
			FormName.submit();
		}
		
		function GoBack()
		{
			window.history.back();
		}
		</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	'; ?>

	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>