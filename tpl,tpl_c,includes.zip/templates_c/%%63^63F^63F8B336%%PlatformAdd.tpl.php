<?php /* Smarty version 2.6.25, created on 2026-01-24 17:08:52
         compiled from PlatformAdd.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'base64_decode', 'PlatformAdd.tpl', 28, false),array('modifier', 'date_format', 'PlatformAdd.tpl', 33, false),)), $this); ?>
	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;"><?php if ($this->_tpl_vars['companyDetail']['0']['companyName'] != ""): ?><?php echo $this->_tpl_vars['companyDetail']['0']['companyName']; ?>
<?php else: ?><?php echo $this->_supers['session']['CompanyName']; ?>
<?php endif; ?>&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;"><?php echo $this->_tpl_vars['branchDetail']['0']['branch_name']; ?>
&ensp;&ensp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;"><?php if ($this->_supers['get']['gateway_id'] == ""): ?>Assign IoT Platform<?php else: ?>Edit IoT Platform<?php endif; ?></font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:10PX;color:#999999;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			<a href="branchList.php?companyId=<?php echo $this->_supers['get']['companyId']; ?>
"><button type="button" style="float:right;;margin-top:-40PX" class="btn btn-primary">List Branch</button></a>
			<a href="platformList.php"><button type="button" style="float:right;;margin-top:-40PX" class="btn btn-primary">List IoT Platform</button></a>
			</div>
		</div>
		<div class="card">
			<div class="card-body">
				<form role="form" name="gatewayRegForm" id="gatewayRegForm" method="post" onsubmit="return createValidation();" >
					<input type="hidden" name="hdAction" />
					<input type="hidden" id="check_id" name="check_id" value="<?php echo $this->_supers['post']['check_id']; ?>
">
					<input type="hidden" id="checkVal" name="checkVal" value="<?php echo $this->_supers['post']['checkVal']; ?>
" />
					<input type="hidden" id="company_id" name="company_id" value="<?php echo ((is_array($_tmp=$this->_supers['get']['companyId'])) ? $this->_run_mod_handler('base64_decode', true, $_tmp) : base64_decode($_tmp)); ?>
" />
					<input type="hidden" id="branch_id" name="branch_id" value="<?php echo ((is_array($_tmp=$this->_supers['get']['branchId'])) ? $this->_run_mod_handler('base64_decode', true, $_tmp) : base64_decode($_tmp)); ?>
" />
					<input type="hidden" id="platId" name="platId" value="<?php echo $this->_tpl_vars['ListEditView']['0']['slNo']; ?>
" />
					<input type="hidden" id="item_id" name="item_id" value="<?php echo $this->_supers['post']['item_id']; ?>
" />
					<input id="created_by" name="created_by" class="date-picker form-control" type="hidden" value="<?php echo $this->_supers['session']['UserName']; ?>
" readonly="true">
				    <input type="hidden" class="form-control" id="timestamp" name="timestamp" value="<?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d &amp; %I:%M:%S %p') : smarty_modifier_date_format($_tmp, '%Y-%m-%d &amp; %I:%M:%S %p')); ?>
">
				    <input type="hidden" class="form-control" id="created_time" name="created_time" placeholder="Time" Value="<?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%I:%M:%S %p') : smarty_modifier_date_format($_tmp, '%I:%M:%S %p')); ?>
">
				<div class="row">
				<?php $_from = $this->_tpl_vars['PlatformList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['ListEditView']):
?>
					<div class="form-group col-md-4">
						<div class="custom-control custom-checkbox">
						<input class="" type="checkbox" id="customCheckbox2" name="customCheckbox2[]" value="<?php echo $this->_tpl_vars['ListEditView']['slNo']; ?>
" tabindex="7" checked="checked">&nbsp;&nbsp;
						<label for="" class=""><?php echo $this->_tpl_vars['ListEditView']['segmentName']; ?>
</label>
						</div>
					</div>
				<?php endforeach; endif; unset($_from); ?>
				<?php $_from = $this->_tpl_vars['APlatformList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['ListEditView']):
?>
					<div class="form-group col-md-4">
						<div class="custom-control custom-checkbox">
						<input class="" type="checkbox" id="customCheckbox2" name="customCheckbox2[]" value="<?php echo $this->_tpl_vars['ListEditView']['slNo']; ?>
" tabindex="7">&nbsp;&nbsp;
						<label for="" class=""><?php echo $this->_tpl_vars['ListEditView']['segmentName']; ?>
</label>
						</div>
					</div>
				<?php endforeach; endif; unset($_from); ?>
				<br />
				<br />
				<br />
				</div>
					<div align="center">
					<input type="submit" value="Submit" class="btn btn-create" tabindex="8" />
					</div>
				</form>
			</div>
		</div>
	</div>
	</section>
	</div>
	<?php echo '
	<script type="text/javascript">
	function createValidation()
	{
		var segmentCode = $(\'#segmentCode\').val();
		var segmentName = $(\'#segmentName\').val();
		var isActive = document.getElementById("customCheckbox2").checked;
		var bar_code = [];
	$.each($("input[name=\'customCheckbox2\']:checked"), function()
	{ 
		bar_code.push($(this).val());  
	});
		id=bar_code.join("\',\'");
		document.getElementById("item_id").value = id;
	if (isActive == false) 
	{
		document.getElementById(\'checkVal\').value=\'0\';
	}
	else
	{
		document.getElementById(\'checkVal\').value=\'1\';
	}
	$(".error").remove();
	if (segmentCode.length < 1) {
		$(\'#segmentCode\').after(\'<span class="error">This field is required</span>\');
		$(\'#segmentCode\').focus();
		return false;					
	}
	else if (segmentName < 1) {
		$(\'#segmentName\').after(\'<span class="error">This field is required</span>\');
		$(\'#segmentName\').focus();
		return false;					
	}
		FormName		= document.gatewayRegForm;
		FormName.method	= "POST";
		FormName.submit();
	}
	function GoBack()
	{
		window.history.back();
	}
	</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	'; ?>

	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>