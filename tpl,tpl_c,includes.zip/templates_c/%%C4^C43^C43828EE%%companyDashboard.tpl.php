<?php /* Smarty version 2.6.25, created on 2026-07-04 16:48:31
         compiled from companyDashboard.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'replace', 'companyDashboard.tpl', 74, false),array('modifier', 'explode', 'companyDashboard.tpl', 77, false),array('modifier', 'date_format', 'companyDashboard.tpl', 81, false),array('modifier', 'escape', 'companyDashboard.tpl', 86, false),array('modifier', 'base64_encode', 'companyDashboard.tpl', 109, false),array('modifier', 'default', 'companyDashboard.tpl', 184, false),)), $this); ?>
<?php echo '
<script type="text/javascript">
    function includecomma1old(c,v)
{
var x=Math.round(c);
x=x.toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != \'\')
lastThree = \',\' + lastThree;
var res = otherNumbers.replace(/\\B(?=(\\d{2})+(?!\\d))/g, ",") + lastThree;
//var res = res.toFixed(4);
//var res =number_format(res, 2);
var res = res+\'.00\';
document.getElementById(v).innerHTML=res;
}
</script>

'; ?>

	<div class="content-wrapper">
		<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;"><?php if ($this->_tpl_vars['companyDetail']['0']['companyName'] != ""): ?><?php echo $this->_tpl_vars['companyDetail']['0']['companyName']; ?>
<?php else: ?><?php echo $this->_supers['session']['CompanyName']; ?>
<?php endif; ?>&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">Dashboard</font>&nbsp;</td>
				 </tr>			
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			</div>
		</div>
            <textarea id="mutiLinegraph" name="mutiLinegraph" style="display:none;" ><?php echo $this->_tpl_vars['multiLineGraphsCost']; ?>
</textarea>
<textarea id="mutiLinedataProvider" name="mutiLinedataProvider"  style="display:none;"  ><?php echo $this->_tpl_vars['multiLineDataProviderCost']; ?>
</textarea>
			<div class="row">
				<div class="col-md-8">
			
					<div class="card card-primary card-outline">
						<div class="card-header">
						<h3 class="card-title">
						<i class="far fa-chart-bar"></i>
						Cost Chart
						</h3>
						
						</div>
					<div id="linechartdiv" style="height: 260px;"></div><br />
					</div>
				</div>
			
				<!--<div class="col-md-6">
					<div class="card card-primary card-outline">
						<div class="card-header">
						<h3 class="card-title">
						</h3>
						</div>
					<br />
					<br/>
					<br/>
					<br/>
					</div>
				</div>-->
			
			<div class="col-md-4">
			<div class="card card-primary card-outline">
			<div class="card-header">
			<h3 class="card-title">Recent Incidents</h3>
			</div>
			<div class="card-body p-0">
			<ul class="products-list product-list-in-card pl-2 pr-2">
			<?php $_from = $this->_tpl_vars['incidentList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['ListIncidentLog']):
?>
			<?php $this->assign('alertMsg0', ((is_array($_tmp=$this->_tpl_vars['ListIncidentLog']['alert_message'])) ? $this->_run_mod_handler('replace', true, $_tmp, 'Hi!', '') : smarty_modifier_replace($_tmp, 'Hi!', ''))); ?>
			<?php $this->assign('alertMsg1', ((is_array($_tmp=$this->_tpl_vars['alertMsg0'])) ? $this->_run_mod_handler('replace', true, $_tmp, 'Best regards,', '') : smarty_modifier_replace($_tmp, 'Best regards,', ''))); ?>
			<?php $this->assign('alertMsg', ((is_array($_tmp=$this->_tpl_vars['alertMsg1'])) ? $this->_run_mod_handler('replace', true, $_tmp, 'Arka Automaations Limited.', '') : smarty_modifier_replace($_tmp, 'Arka Automaations Limited.', ''))); ?>
			<?php $this->assign('alertBreak', ((is_array($_tmp=",")) ? $this->_run_mod_handler('explode', true, $_tmp, $this->_tpl_vars['alertMsg']) : explode($_tmp, $this->_tpl_vars['alertMsg']))); ?>
			<?php $this->assign('l', 0); ?>
			<li class="item">
			<div class="product-img">
			<a href="javascript:void(0)" class="product-title"><?php echo $this->_tpl_vars['ListIncidentLog']['sensor_code']; ?>
 - ( <?php echo ((is_array($_tmp=$this->_tpl_vars['ListIncidentLog']['recorded_date_time'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%e-%b-%Y %I:%M %p") : smarty_modifier_date_format($_tmp, "%e-%b-%Y %I:%M %p")); ?>
 )</a>
			<?php if ($this->_tpl_vars['ListIncidentLog']['alert_status'] == 'Low'): ?><span class="badge badge-warning"  style="float:right;"><?php echo $this->_tpl_vars['ListIncidentLog']['alert_status']; ?>
</span><?php elseif ($this->_tpl_vars['ListIncidentLog']['alert_status'] == 'Normal'): ?><span class="badge badge-info"  style="float:right;"><?php echo $this->_tpl_vars['ListIncidentLog']['alert_status']; ?>
</span><?php elseif ($this->_tpl_vars['ListIncidentLog']['alert_status'] == 'Normal'): ?><span class="badge badge-danger"  style="float:right;"><?php echo $this->_tpl_vars['ListIncidentLog']['alert_status']; ?>
</span><?php endif; ?>
			<span class="product-description" style="font-size:12px">
			<?php unset($this->_sections['i']);
$this->_sections['i']['name'] = 'i';
$this->_sections['i']['loop'] = is_array($_loop=$this->_tpl_vars['alertBreak']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['i']['show'] = true;
$this->_sections['i']['max'] = $this->_sections['i']['loop'];
$this->_sections['i']['step'] = 1;
$this->_sections['i']['start'] = $this->_sections['i']['step'] > 0 ? 0 : $this->_sections['i']['loop']-1;
if ($this->_sections['i']['show']) {
    $this->_sections['i']['total'] = $this->_sections['i']['loop'];
    if ($this->_sections['i']['total'] == 0)
        $this->_sections['i']['show'] = false;
} else
    $this->_sections['i']['total'] = 0;
if ($this->_sections['i']['show']):

            for ($this->_sections['i']['index'] = $this->_sections['i']['start'], $this->_sections['i']['iteration'] = 1;
                 $this->_sections['i']['iteration'] <= $this->_sections['i']['total'];
                 $this->_sections['i']['index'] += $this->_sections['i']['step'], $this->_sections['i']['iteration']++):
$this->_sections['i']['rownum'] = $this->_sections['i']['iteration'];
$this->_sections['i']['index_prev'] = $this->_sections['i']['index'] - $this->_sections['i']['step'];
$this->_sections['i']['index_next'] = $this->_sections['i']['index'] + $this->_sections['i']['step'];
$this->_sections['i']['first']      = ($this->_sections['i']['iteration'] == 1);
$this->_sections['i']['last']       = ($this->_sections['i']['iteration'] == $this->_sections['i']['total']);
?>
			<?php $this->assign('l', $this->_tpl_vars['l']+1); ?>
			<?php echo ((is_array($_tmp=$this->_tpl_vars['alertBreak'][$this->_sections['i']['index']])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
,<?php if ($this->_tpl_vars['l'] == '1'): ?><br /><?php endif; ?>
			<?php endfor; endif; ?>
			</span>
			</div>
			</li>
			<?php endforeach; endif; unset($_from); ?>
			</ul>
			</div>
			<div class="card-footer text-center">
			<a href="listIncidentLog.php" class="uppercase">View All Incidents</a>
			</div>
			</div>
			</div>
			</div>
			
            <!--command by shanmugakani (changed as list)-->
	<!--	<div class="row">
		<div class="col-md-12">
		<div class="card">
		<div class="card-body row">
		<?php $_from = $this->_tpl_vars['branchList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['ListBranch']):
?>
		<div class="col-md-3">
		<div class="card card-widget widget-user">
		<a href="dashboard.php?companyId=<?php echo ((is_array($_tmp=$this->_tpl_vars['ListBranch']['company_id'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
&branchId=<?php echo ((is_array($_tmp=$this->_tpl_vars['ListBranch']['sl_no'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
"><div class="widget-user-header bg-info">
		<h3 class="widget-user-username">
		</h3>
		<h5 class="widget-user-desc"><?php echo $this->_tpl_vars['ListBranch']['branch_name']; ?>
</h5>
		</div></a>
		<a href="dashboard.php?companyId=<?php echo ((is_array($_tmp=$this->_tpl_vars['ListBranch']['company_id'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
&branchId=<?php echo ((is_array($_tmp=$this->_tpl_vars['ListBranch']['sl_no'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
"><div class="widget-user-image">
		<img class="img-circle elevation-2" src="images/meterImage.png" alt="User Avatar">
		</div></a>
		<div class="card-footer">
		<div class="row">
		<div class="col-sm-6 border-right">
		<div class="description-block">
		<h5 class="description-header">&#8377;<?php $_from = $this->_tpl_vars['currMonthCostKWH']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['List']):
?>
		<?php if ($this->_tpl_vars['List']['branch_id'] == $this->_tpl_vars['ListBranch']['sl_no']): ?>  <?php echo $this->_tpl_vars['List']['cost']; ?>
<?php endif; ?>
		<?php endforeach; endif; unset($_from); ?></h5>
		<span class="description-text">This Month Cost</span>
		</div>
		</div>
		<div class="col-sm-6 ">
		<div class="description-block">
		<h5 class="description-header">&#8377; <?php $_from = $this->_tpl_vars['lastMonthCostKWH']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['List']):
?>
		<?php if ($this->_tpl_vars['List']['branch_id'] == $this->_tpl_vars['ListBranch']['sl_no']): ?>  <?php echo $this->_tpl_vars['List']['cost']; ?>
<?php endif; ?>
		<?php endforeach; endif; unset($_from); ?></h5>
		<span class="description-text">Last Month Cost</span>
		</div>
		</div>
		</div>
		</div>
		</div>
		</div> 
        <?php endforeach; endif; unset($_from); ?> 
		</div>
		</div>
		</div>
		</div>-->
          <!--command by shanmugakani (changed as list)-->
          <form name="location_list" method="post" id="location_list">
          <div class="row">
		<div class="col-md-12">
		<div class="card card-primary card-outline">
        <div class="card-header">
						<h3 class="card-title">
						<i class="fa fa-list"></i>
						List of Branch
						</h3>
						 <a href="branchAddEdit.php?companyId=<?php echo $this->_supers['session']['COMPANY_ID']; ?>
" ><button type="button" style="float:right;margin-top:-6PX" class="btn btn-create">Create Branch</button></a>
						</div>
		<div class="card-body table-responsive no-padding">
		   
        <table id="example" class="table table-bordered table-hover">
								<thead>
								<tr>
								<th class="slNo" rowspan="2">#</th>
								<th class="name" rowspan="2">Branch Name</th>
                                 <th  colspan="2" class="code" >This Month</th>
                                 <th  colspan="2" class="code" >Last Month</th>
								<th class="isactive" rowspan="2">Status</th>
								<th class="action" rowspan="2">Action</th>
								</tr>
                                 <tr>
    			 
                  <th class="cost" >KWH</th>
                  <th class="cost" >Cost</th>
                  <th class="cost" >KWH</th>
                  <th class="cost" >Cost</th>
                  
                </tr>
						</thead>
						<tbody>
						<?php $_from = $this->_tpl_vars['ListView']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['List']):
?>
						<tr id="<?php echo $this->_tpl_vars['j']++; ?>
">
						<td ><?php echo $this->_tpl_vars['j']; ?>
</td>
						<td ><?php echo $this->_tpl_vars['List']['branch_name']; ?>
</td>
						<?php $_from = $this->_tpl_vars['currMonthCostKWH']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['ListC']):
?>
						<?php if ($this->_tpl_vars['ListC']['branch_id'] == $this->_tpl_vars['List']['sl_no']): ?> 
						<td align="right" id="<?php echo $this->_tpl_vars['j']; ?>
ck"><script type="text/javascript">includecomma1('<?php echo ((is_array($_tmp=@$this->_tpl_vars['ListC']['TOTAL_KWH'])) ? $this->_run_mod_handler('default', true, $_tmp, "0.00") : smarty_modifier_default($_tmp, "0.00")); ?>
','<?php echo $this->_tpl_vars['j']; ?>
ck');</script></td>
						<td align="right" id="<?php echo $this->_tpl_vars['j']; ?>
cc"><script type="text/javascript">includecomma1('<?php echo ((is_array($_tmp=@$this->_tpl_vars['ListC']['cost'])) ? $this->_run_mod_handler('default', true, $_tmp, "0.00") : smarty_modifier_default($_tmp, "0.00")); ?>
','<?php echo $this->_tpl_vars['j']; ?>
cc');</script></td>
						<?php else: ?>
						<td align="right" id="<?php echo $this->_tpl_vars['j']; ?>
ck">0.00</td>
						<td align="right" id="<?php echo $this->_tpl_vars['j']; ?>
cc">0.00</td>
						<?php endif; ?>
						<?php endforeach; else: ?>
						<td align="right">0.00</td>
						<td align="right">0.00</td>
						<?php endif; unset($_from); ?>

						
						<?php $_from = $this->_tpl_vars['lastMonthCostKWH']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['ListL']):
?>
						<?php if ($this->_tpl_vars['ListL']['branch_id'] == $this->_tpl_vars['List']['sl_no']): ?> 
						<td align="right" id="<?php echo $this->_tpl_vars['j']; ?>
lk"><script type="text/javascript">includecomma1('<?php echo ((is_array($_tmp=@$this->_tpl_vars['ListL']['TOTAL_KWH'])) ? $this->_run_mod_handler('default', true, $_tmp, "0.00") : smarty_modifier_default($_tmp, "0.00")); ?>
','<?php echo $this->_tpl_vars['j']; ?>
lk');</script></td>
						<td align="right" id="<?php echo $this->_tpl_vars['j']; ?>
lc"><script type="text/javascript">includecomma1('<?php echo ((is_array($_tmp=@$this->_tpl_vars['ListL']['cost'])) ? $this->_run_mod_handler('default', true, $_tmp, "0.00") : smarty_modifier_default($_tmp, "0.00")); ?>
','<?php echo $this->_tpl_vars['j']; ?>
lc');</script></td>
						<?php else: ?>
						<td align="right" id="<?php echo $this->_tpl_vars['j']; ?>
lk">0.00</td>
						<td align="right" id="<?php echo $this->_tpl_vars['j']; ?>
lc">0.00</td>
						<?php endif; ?>
						<?php endforeach; else: ?>
						<td align="right">0.00</td>
						<td align="right">0.00</td>
						<?php endif; unset($_from); ?>
						
						<td align="center"><?php if ($this->_tpl_vars['List']['is_active'] == '1'): ?><span style="color:#00A520"><b>Active</b></span><?php else: ?><span style="color:#FF0000;"><b>Inactive</b></span><?php endif; ?></td>
						<td align="right">
						<?php $_from = $this->_tpl_vars['platformView']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['dashName']):
?>
						<?php if ($this->_tpl_vars['dashName']['segmentName'] == 'Energy Meter' && $this->_tpl_vars['dashName']['branch_id'] == $this->_tpl_vars['List']['sl_no']): ?>
							<a href="dashboard.php?companyId=<?php if ($this->_supers['get']['companyId'] != ""): ?><?php echo $this->_supers['get']['companyId']; ?>
<?php else: ?><?php echo ((is_array($_tmp=$this->_supers['session']['CustomerId'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
<?php endif; ?>&branchId=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['sl_no'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
"  title="Visit <?php echo $this->_tpl_vars['List']['branch_name']; ?>
 Energy Dashboard" target="_blank"><i class="fa fa-desktop"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
						<?php endif; ?>
						<?php if ($this->_tpl_vars['dashName']['segmentName'] == 'Temperature' && $this->_tpl_vars['dashName']['branch_id'] == $this->_tpl_vars['List']['sl_no']): ?>
							<a href="temperature_temperatureDashboard.php?companyId=<?php echo $this->_supers['get']['companyId']; ?>
&branchId=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['sl_no'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
"  title="Visit <?php echo $this->_tpl_vars['List']['branch_name']; ?>
 Temperature Dashboard" target="_blank"><i class="fa fa-thermometer-half"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
						<?php endif; ?>
						<?php endforeach; endif; unset($_from); ?>
						<?php if ($this->_supers['session']['USER_GROUP'] == 'Super Admin' || $this->_supers['session']['USER_GROUP'] == 'Company Admin'): ?> 
							<a href="shiftList.php?companyId=<?php echo $this->_supers['get']['companyId']; ?>
&branchId=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['sl_no'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
"  title="List Shift"><i class="fa fa-list"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
						<?php endif; ?>
						<?php if ($this->_supers['session']['USER_GROUP'] == 'Super Admin'): ?>	
								<a href="platformList.php?companyId=<?php if ($this->_supers['get']['companyId'] != ""): ?><?php echo $this->_supers['get']['companyId']; ?>
<?php else: ?><?php echo ((is_array($_tmp=$this->_supers['session']['CustomerId'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
<?php endif; ?>&branchId=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['sl_no'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
" title="List IoT Platform"><i class="fa fa-spinner"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;                                <?php endif; ?>
							<a href="userList.php?companyId=<?php if ($this->_supers['get']['companyId'] != ""): ?><?php echo $this->_supers['get']['companyId']; ?>
<?php else: ?><?php echo ((is_array($_tmp=$this->_supers['session']['CustomerId'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
<?php endif; ?>&branchId=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['sl_no'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
"  title="List User"><i class="fa fa-user"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
							<a href="contactMasterList.php?companyId=<?php if ($this->_supers['get']['companyId'] != ""): ?><?php echo $this->_supers['get']['companyId']; ?>
<?php else: ?><?php echo ((is_array($_tmp=$this->_supers['session']['CustomerId'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
<?php endif; ?>&branchId=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['sl_no'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
" title="List Alert Contact"><i class="fa fa-bell"></i></a>
						<?php if ($this->_supers['session']['billing_module'] == '1'): ?> 
							&nbsp;&nbsp;&nbsp;&nbsp;
							<a href="listBilling.php?companyId=<?php if ($this->_supers['get']['companyId'] != ""): ?><?php echo $this->_supers['get']['companyId']; ?>
<?php else: ?><?php echo ((is_array($_tmp=$this->_supers['session']['CustomerId'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
<?php endif; ?>&branchId=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['sl_no'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
" title="List Billing"><i class="fas fa-file-invoice"></i></a>
						<?php endif; ?>
					
						<?php if ($this->_supers['session']['USER_GROUP'] == 'Super Admin' || $this->_supers['session']['USER_GROUP'] == 'Company Admin'): ?> 
							&nbsp;&nbsp;&nbsp;&nbsp;
							<a href="#"  onClick="Javascript:listGatewayGroup('<?php echo $this->_tpl_vars['List']['company_id']; ?>
','<?php echo $this->_tpl_vars['List']['sl_no']; ?>
')" title="Gateway Mapping"><i class="fa fa-podcast"></i></a>
						<?php endif; ?>
							
						<?php if ($this->_supers['session']['USER_GROUP'] != 'Super Admin' && $this->_supers['session']['USER_GROUP'] != 'Company Admin'): ?>	 
						&nbsp;&nbsp;&nbsp;&nbsp;
							<a href="feederList.php?companyId=<?php echo $this->_supers['get']['companyId']; ?>
&branchId=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['sl_no'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
" title="List Feeder"><i class="fa fa-lightbulb"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
						<?php endif; ?>
						<?php $_from = $this->_tpl_vars['IconList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['icon']):
?>								
						<?php if ($this->_tpl_vars['icon']['menuName'] == 'List Gateway'): ?>
							&nbsp;&nbsp;
							<a href="#"  onClick="Javascript:gatewayCats('<?php echo $this->_tpl_vars['List']['sl_no']; ?>
','<?php echo $this->_tpl_vars['List']['company_id']; ?>
','<?php echo $this->_tpl_vars['List']['branch_id']; ?>
')" title="List Gateway" ><i class="<?php echo $this->_tpl_vars['icon']['faIcon']; ?>
"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
						<?php endif; ?>
						<?php if ($this->_tpl_vars['icon']['menuName'] == 'Edit Branch'): ?>
							<a href="#"  onClick="Javascript:editCats('<?php echo $this->_tpl_vars['List']['sl_no']; ?>
','<?php echo $this->_tpl_vars['List']['company_id']; ?>
','<?php echo $this->_tpl_vars['List']['branch_id']; ?>
','Update=Y')" title="Edit"><i class="<?php echo $this->_tpl_vars['icon']['faIcon']; ?>
"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
						<?php endif; ?>
						<?php if ($this->_tpl_vars['icon']['menuName'] == 'Delete Branch' && $this->_supers['session']['USER_GROUP'] == 'Super Admin'): ?>
								<a href="#"  onClick="Javascript:deleteCats('<?php echo $this->_tpl_vars['List']['sl_no']; ?>
','<?php echo $this->_tpl_vars['List']['company_id']; ?>
','<?php echo $this->_tpl_vars['List']['branch_id']; ?>
')" title="Delete"><i class="<?php echo $this->_tpl_vars['icon']['faIcon']; ?>
"></i></a>
							<?php endif; ?>
						<?php endforeach; endif; unset($_from); ?>&nbsp;&nbsp;&nbsp;&nbsp;
						</td>
						</tr>
						<?php endforeach; else: ?>
						<tr><td colspan="5"><center>No Records Found</center></td></tr>
						<?php endif; unset($_from); ?>
						</tbody>
					</table>
                            </div>
                            </div>
                            </div>
                            </div>
                            </form>
                            
		
		</section>
	
	<!-- /.content -->
	</div>
	<?php echo '

<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>-->
<script src="./amcharts/amcharts.js"></script>
<script src="./amcharts/serial.js"></script>
<script src="./amcharts/plugins/export/export.min.js"></script>
<script src="./amcharts/themes/light.js"></script>
<!-- Resources -->
<script src="./amChart/amchart.js"></script>
<script src="./amChart/amchartPieChart.js"></script>
<!--<script src="https://www.amcharts.com/lib/3/plugins/export/export.js"></script>-->
<script src="./amChart/amchartLight.js"></script>
<script src="./amChart/amchartColumnChart.js"></script>
<link rel="stylesheet" href="./amcharts/plugins/export/export.css" type="text/css" media="all" />	<style>
	#linechartdiv {
	width	: 100%;
	height	: 400px;
	}	
	.name
	{
	    width:15%;
	}
	.slNo
	{
	     width:3%;
	}
	.code
	{
	     width:10%;
	}
	.isactive
	{
	     width:5%;
	}
	.action 
	{
	     width:20%;
	}
	</style>
	
	<script>
//	alert("hai");

	//mutiLinedataProvider
	var dataProvider = document.getElementById(\'mutiLinedataProvider\').value;
var Graphs = document.getElementById(\'mutiLinegraph\').value;
//alert(Graphs);
var jsondataProvider = JSON.parse(dataProvider);
var jsondataGraph = JSON.parse(Graphs);
	//alert(jsondataGraph);
//	alert(dataProvider);alert(Graphs);
	var linechart = AmCharts.makeChart("linechartdiv", {
	"type": "serial",
	"theme": "light",
	"dataProvider": jsondataProvider,
	"valueAxes": [{
	"gridColor": "#FFFFFF",
	"gridAlpha": 0.2,
	"dashLength": 0
	}],
	"gridAboveGraphs": true,
	"startDuration": 0.3,
	"graphs":jsondataGraph,
	"fontSize": 14,
	"chartCursor": {
	"categoryBalloonEnabled": false,
	"cursorAlpha": 0,
	"zoomable": false
	},
	"categoryField": "month",
	"categoryAxis": {
	"gridPosition": "start",
	"gridAlpha": 0
	},
	"export": {
	"enabled": true // false- If don\'t need to dowload option 
	}
	});
	</script>
	<script type="text/javascript">
	     function gatewayCats(slNoIdent,compIdent,branchIdent) {
   var sid = btoa(slNoIdent);  var comId = btoa(compIdent); var bid = btoa(branchIdent);
   FormName		= document.location_list;
   FormName.action =\'gatewayList.php?companyId=\'+comId+\'&branchId=\'+sid;
   FormName.submit();
}

function editCats(slNoIdent,compIdent,locIdIdent) {
	var sid = btoa(slNoIdent); var comId = btoa(compIdent); var bid = btoa(locIdIdent);
	FormName		= document.location_list;
	FormName.action =\'branchAddEdit.php?companyId=\'+comId+\'&branch_id=\'+bid+\'&sl_no=\'+sid+\'&Update=y\';
	FormName.submit();
	}
	function listGatewayGroup(compIdent,locIdIdent)
  {
    var comId = btoa(compIdent); var lid = btoa(locIdIdent);
   FormName		= document.location_list;
   FormName.action =\'gatewayGroupList.php?companyId=\'+comId+\'&branchId=\'+lid;
   FormName.submit();
  }
	function deleteCats(slNoIdent,compIdent,locIdIdent){
	var sid = btoa(slNoIdent); var comId = btoa(compIdent); var bid = btoa(locIdIdent);
	if(confirm("Are you sure to Delete this Content?")){
	FormName		= document.location_list;
	FormName.action= \'branchList.php?companyId=\'+compIdent+\'&branch_id=\'+locIdIdent+\'&sl_no=\'+slNoIdent;
	FormName.submit();
	}
	}

	</script>
	'; ?>

	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>