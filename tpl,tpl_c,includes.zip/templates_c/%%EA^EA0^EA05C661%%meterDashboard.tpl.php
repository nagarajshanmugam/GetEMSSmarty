<?php /* Smarty version 2.6.25, created on 2026-06-30 16:57:20
         compiled from meterDashboard.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'date_format', 'meterDashboard.tpl', 424, false),array('modifier', 'base64_encode', 'meterDashboard.tpl', 446, false),)), $this); ?>
	<?php echo '

	<script type="text/javascript">
    function addcomma(c)
{
var x=c;
x=x.toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != \'\')
    lastThree = \',\' + lastThree;
var res = otherNumbers.replace(/\\B(?=(\\d{2})+(?!\\d))/g, ",") + lastThree;
return res;
}

function includecomma(c)
{
var x=c;
x=x.toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != \'\')
    lastThree = \',\' + lastThree;
var res = otherNumbers.replace(/\\B(?=(\\d{2})+(?!\\d))/g, ",") + lastThree;
return res;
}
</script>
	<script type="text/javascript">
	function includecomma1old(c,v)
{
var x=Math.round(c);
x=x.toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != \'\')
lastThree = \',\' + lastThree;
var res = otherNumbers.replace(/\\B(?=(\\d{2})+(?!\\d))/g, ",") + lastThree;
//var res = res.toFixed(4);
//var res =number_format(res, 2);
var res = res+\'.00\';
document.getElementById(v).innerHTML=res;
}
</script>
<script type="text/javascript">
	function includecomma1(c,v)
{
//var x=Math.round(c);
//var x=c.toFixed(2);

var x=c.split(".");
var ld=x[1];
var ty=typeof(x[1]);//alert(ty);
if(ty == \'undefined\')
{
   
    var ld=\'00\';
}
else
{
var ld=x[1].slice(0, 2);
}
x=x[0].toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != \'\')
{
lastThree = \',\' + lastThree;
var res = otherNumbers.replace(/\\B(?=(\\d{2})+(?!\\d))/g, ",") + lastThree;
}
else
{
lastThree =  lastThree;
var res = otherNumbers.replace(/\\B(?=(\\d{2})+(?!\\d))/g, ",") + lastThree;
}
//var res = res+\'.00\';
if(res == \'\')
{
    var res=\'0\';
}
var res = res+\'.\'+ld;
document.getElementById(v).innerHTML=res;
}
</script>

	<script src="amcharts/amcharts.js"></script>
	<script src="amcharts/serial.js"></script>
	<script src="amcharts/themes/light.js"></script>
	<!--     Gauge Script      --->
	<script src="./amChart/amchart.js"></script>
	<script src="./js/gaugeChart/gauge.js"></script>
	<script src="./js/gaugeChart/export.min.js"></script>

	<script src="amcharts/plugins/export/export.min.js"></script>
	<link rel="stylesheet" href="amcharts/plugins/export/export.css" type="text/css" media="all" />
	<script src="./amChart/amchartLight.js"></script>
<script src="./amChart/amchartColumnChart.js"></script>
<!--	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
-->	<style type="text/css">
	.thal
	{
	text-align:left;
	}
	.thar
	{
	text-align:right;
	}
	.bclass
	{
	font:Geneva, Arial, Helvetica, sans-serif;
	font-size:14px;
	font-weight:600;
	}
	</style>
	<!-- Styles -->
	<style>
	#chartdiv {
	width: 100%;
	height: 500px;
	}
	#chartdiv2 {
	width: 100%;
	height: 500px;
	}
	#chartdiv3 {
	width: 100%;
	height: 500px;
	}
	#Barchartdiv {
	width: 100%;
	height: 500px;
	}
	#Linechartdiv {
	width	: 100%;
	height	: 800px;
	}	
	.noscroll,.tab-content
	{
	overflow-x:hidden;
	}
	</style>
	<!----     Line Chart         ------------->
	<script>
	var chart = AmCharts.makeChart("Linechartdiv", {
	"type": "serial",
	"theme": "none",
	"marginTop":5,
	"marginBottom":0,
	"marginRight": 50,
	"dataProvider": '; ?>
<?php echo $this->_tpl_vars['LineGraphDataDash']; ?>
<?php echo ',
	"valueAxes": [{
	"axisAlpha": 0,
	"position": "left",
	"gridAlpha": 0.2,
	"dashLength": 0
	}],
	"graphs": [{
	"id":"g1",
	"balloonText": "[[category]]<br><b><span style=\'font-size:14px;\'>[[EB]] kwh</span></b>",
	"bullet": "round",
	"bulletSize": 8,
	"lineColor": "#d1655d",
	"lineThickness": 2,
	"negativeLineColor": "#637bb6",
	"type": "smoothedLine",
	"valueField": "EB",
	"animationPlayed": true
	}],
	"chartScrollbar": {
	"enabled" :false, //true if you need drag  option in top
	"graph":"g1",
	"gridAlpha":0,
	"color":"#888888",
	"scrollbarHeight":55,
	"backgroundAlpha":0,
	"selectedBackgroundAlpha":0.1,
	"selectedBackgroundColor":"#888888",
	"graphFillAlpha":0,
	"autoGridCount":true,
	"selectedGraphFillAlpha":0,
	"graphLineAlpha":0.2,
	"graphLineColor":"#c2c2c2",
	"selectedGraphLineColor":"#888888",
	"selectedGraphLineAlpha":1
	
	},
	"chartCursor": {
	"categoryBalloonDateFormat": "YYYY",
	"cursorAlpha": 0,
	"valueLineEnabled":true,
	"valueLineBalloonEnabled":true,
	"valueLineAlpha":0.5,
	"fullWidth":true,
	"zoomable": false //true if line chart need zoom option
	
	},
	"categoryField": "month",
	"export": {
	"enabled": true
	}
	});
	Linechart.addListener("rendered", zoomChart);
	if(Linechart.zoomChart){
	Linechart.zoomChart();
	}
	
	function zoomChart(){
	Linechart.zoomToIndexes(Math.round(Linechart.dataProvider.length * 0.4), Math.round(Linechart.dataProvider.length * 0.55));
	}
	
	</script>
	
	<!----       AmChart Bar Chart       ---------->
	<script>
	//var plotBarGraphData=JSON.parse(bGraphData);
	var Barchart = AmCharts.makeChart( "Barchartdiv", {
	"type": "serial",
	"theme": "none",
	"dataProvider": '; ?>
<?php echo $this->_tpl_vars['BarGraphDataDash']; ?>
<?php echo ',
	"valueAxes": [ {
	"gridColor": "#FFFFFF",
	"gridAlpha": 0.2,
	"dashLength": 0
	} ],
	"gridAboveGraphs": true,
	"startDuration": 1,
	"graphs": [ {
	"balloonText": "[[category]]: <b>Rs.[[value]]</b>",
	"fillAlphas": 0.8,
	"lineAlpha": 0.2,
	"type": "column",
	"valueField": "cost"
	} ],
	"chartCursor": {
	"categoryBalloonEnabled": false,
	"cursorAlpha": 0,
	"zoomable": false
	},
	"categoryField": "month",
	"categoryAxis": {
	"gridPosition": "start",
	"gridAlpha": 0,
	"tickPosition": "start",
	"tickLength": 5 // length for x axis bottom line
	},
	"export": {
	"enabled": true
	}
	} );
	</script>
	<script>
	var chart = AmCharts.makeChart("chartdiv", {
	"theme": "none",
	"type": "gauge",
	"axes": [{
	"topTextFontSize": 20,
	"topTextYOffset": 70,
	"axisColor": "#31d6ea",
	"axisThickness": 1,
	"endValue": '; ?>
<?php echo $this->_tpl_vars['KW_MAX']; ?>
<?php echo ',
	"gridInside": true,
	"inside": true,
	"radius": "60%",
	"valueInterval": '; ?>
<?php echo $this->_tpl_vars['KW_INT']; ?>
<?php echo ',
	"tickColor": "#67b7dc",
	"startAngle": -90,
	"endAngle": 90,
	"unit": "",
	"labelsEnabled":true,
	"bandOutlineAlpha": 0,
	"bands": [{
	"color": "#0080ff",
	"endValue": '; ?>
<?php echo $this->_tpl_vars['KW_MAX']; ?>
<?php echo ',
	"innerRadius": "105%",
	"radius": "170%",
	"gradientRatio": [0.5, 0, -0.5],
	"startValue": 0
	}, {
	"color": "#3cd3a3",
	"endValue": 0,
	"innerRadius": "105%",
	"radius": "170%",
	"gradientRatio": [0.5, 0, -0.5],
	"startValue": 0
	}]
	}],
	"arrows": [{
	"alpha": 1,
	"innerRadius": "35%",
	"nailRadius": 0,
	"radius": "170%"
	}]
	});
	setInterval(randomValue, 500);
	// set random value
	function randomValue() {
	var value = '; ?>
<?php echo $this->_tpl_vars['ListFeederDet']['0']['SUM_KW']; ?>
<?php echo ';
	chart.arrows[0].setValue(value);
	chart.axes[0].setTopText(value + " KW");
	// adjust darker band to new value
	chart.axes[0].bands[1].setEndValue(value);
	}
	</script>
	<script>
	var chart2 = AmCharts.makeChart("chartdiv2", {
	"theme": "none",
	"type": "gauge",
	"axes": [{
	"topTextFontSize": 20,
	"topTextYOffset": 70,
	"axisColor": "#31d6ea",
	"axisThickness": 1,
	"endValue": '; ?>
<?php echo $this->_tpl_vars['KVA_MAX']; ?>
<?php echo ',
	"gridInside": true,
	"inside": true,
	"radius": "60%",
	"valueInterval": '; ?>
<?php echo $this->_tpl_vars['KVA_INT']; ?>
<?php echo ',
	"tickColor": "#67b7dc",
	"startAngle": -90,
	"endAngle": 90,
	"unit": "",
	"labelsEnabled":true,
	"bandOutlineAlpha": 0,
	"bands": [{
	"color": "#0080ff",
	"endValue": '; ?>
<?php echo $this->_tpl_vars['KVA_MAX']; ?>
<?php echo ',
	"innerRadius": "105%",
	"radius": "170%",
	"gradientRatio": [0.5, 0, -0.5],
	"startValue": 0
	}, {
	"color": "#3cd3a3",
	"endValue": 0,
	"innerRadius": "105%",
	"radius": "170%",
	"gradientRatio": [0.5, 0, -0.5],
	"startValue": 0
	}]
	}],
	"arrows": [{
	"alpha": 1,
	"innerRadius": "35%",
	"nailRadius": 0,
	"radius": "170%"
	}]
	});
	setInterval(randomValue2, 500);
	// set random value
	function randomValue2() {
	var value = '; ?>
<?php echo $this->_tpl_vars['ListFeederDet']['0']['SUM_KVA']; ?>
<?php echo ';
	chart2.arrows[0].setValue(value);
	chart2.axes[0].setTopText(value + " KVA");
	// adjust darker band to new value
	chart2.axes[0].bands[1].setEndValue(value);
	}
	</script>
	<script>
	var chart3 = AmCharts.makeChart("chartdiv3", {
	"theme": "none",
	"type": "gauge",
	"axes": [{
	"topTextFontSize": 20,
	"topTextYOffset": 70,
	"axisColor": "#31d6ea",
	"axisThickness": 1,
	"endValue": '; ?>
<?php echo $this->_tpl_vars['KVAR_MAX']; ?>
<?php echo ',
	"gridInside": true,
	"inside": true,
	"radius": "60%",
	"valueInterval": '; ?>
<?php echo $this->_tpl_vars['KVAR_INT']; ?>
<?php echo ',
	"tickColor": "#67b7dc",
	"startAngle": -90,
	"endAngle": 90,
	"unit": "",
	
	"labelsEnabled":true,
	"bandOutlineAlpha": 0,
	"bands": [{
	"color": "#0080ff",
	"endValue": '; ?>
<?php echo $this->_tpl_vars['KVAR_MAX']; ?>
<?php echo ',
	"innerRadius": "105%",
	"radius": "170%",
	"gradientRatio": [0.5, 0, -0.5],
	"startValue": 0
	}, {
	"color": "#3cd3a3",
	"endValue": 0,
	"innerRadius": "105%",
	"radius": "170%",
	"gradientRatio": [0.5, 0, -0.5],
	"startValue": 0
	}]
	}],
	"arrows": [{
	"alpha": 1,
	"innerRadius": "35%",
	"nailRadius": 0,
	"radius": "170%"
	}]
	});
	setInterval(randomValue3, 500);
	// set random value
	function randomValue3() {
	var value = '; ?>
<?php echo $this->_tpl_vars['ListFeederDet']['0']['SUM_KVAR']; ?>
<?php echo ';
	chart3.arrows[0].setValue(value);
	chart3.axes[0].setTopText(value + " KVAR");
	// adjust darker band to new value
	chart3.axes[0].bands[1].setEndValue(value);
	}
	</script>
	'; ?>

	<div class="content-wrapper ">
	<div class="content-header">
	<div class="container-fluid ">
	<div class="row"> <div class="col-md-12">
	<div class="card">
	<div class="card-body">
		<table style="margin-bottom:-10px;">
		<tr><td style="font-size:12PX;font-weight: bold;"><?php echo $this->_tpl_vars['LoctList']['0']['companyName']; ?>
&nbsp;&nbsp;</td>
		<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="font-size:12PX;font-weight: bold;"><?php echo $this->_tpl_vars['LoctList']['0']['branch_name']; ?>
&ensp;&ensp;</td>
		<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="font-size:12PX;font-weight: bold;"><?php echo $this->_tpl_vars['LoctList']['0']['sensorName']; ?>
</font>&nbsp;</td>
		<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="font-size:12PX;font-weight: bold;"><?php echo $this->_tpl_vars['LoctList']['0']['place_of_installation']; ?>
 - <?php if ($this->_tpl_vars['LoctList']['0']['gateway_id'] != 'YMN-1' && $this->_tpl_vars['LoctList']['0']['gateway_id'] == $this->_tpl_vars['gateList']['0']['gateway_code'] && $this->_tpl_vars['gateList']['0']['gateway_date_time'] >= ((is_array($_tmp=$this->_tpl_vars['dateSec'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d %H:%M:%S'))): ?><a style="color:#00CC00;"> ON </a><?php elseif ($this->_tpl_vars['LoctList']['0']['gateway_id'] == 'YMN-1' && $this->_tpl_vars['LoctList']['0']['gateway_id'] == $this->_tpl_vars['gateList']['0']['gateway_code'] && $this->_tpl_vars['gateList']['0']['gateway_date_time'] >= ((is_array($_tmp=$this->_tpl_vars['dateSec1'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d %H:%M:%S'))): ?> <a style="color: #00CC00;"> ON</a> <?php else: ?> <a style="color: #FF0000;"> OFF</a> <?php endif; ?></font>&nbsp;</td>
		</tr>
		
		<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
		<td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="font-size:10PX;color:#999999;">Branch Name</td>
		<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="color:#999999;font-size:10PX;">Energy Meter Name (Place of Installation)</td>
		<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="color:#999999;font-size:10PX;">Gateway </td>
		</tr>
		</table>

		<input type="hidden" id="gatewayCode" value="<?php echo $this->_supers['get']['gatewayCode']; ?>
" />
		<input type="hidden" id="sensorCode" value="<?php echo $this->_supers['get']['sensorCode']; ?>
" />
		<input type="hidden" id="companyId" value="<?php echo $this->_supers['get']['companyId']; ?>
" />
		<input type="hidden" id="branchId" value="<?php echo $this->_supers['get']['branchId']; ?>
" />
		<form name="dashboard" id="dashboard" method="post">
		<div  style="margin-top:-40PX;float:right" class="col-md-4"  >
	<b>Select E.Meter &nbsp;&nbsp;: &nbsp;&nbsp;</b><select  class="form-control select2" id="feederPost" name="feederPost"  style="width:250PX" onchange="postFeeder();">
	<?php $_from = $this->_tpl_vars['ListFeeder']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['listDet']):
?>
	<?php if ($this->_tpl_vars['LoctList']['0']['sensorCode'] == $this->_tpl_vars['listDet']['sensorCode']): ?>
	<option value="<?php echo $this->_tpl_vars['listDet']['sensorName']; ?>
|<?php echo ((is_array($_tmp=$this->_tpl_vars['listDet']['sensorCode'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
|<?php echo ((is_array($_tmp=$this->_tpl_vars['listDet']['gateway_id'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
|<?php echo ((is_array($_tmp=$this->_tpl_vars['listDet']['company_id'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
|<?php echo ((is_array($_tmp=$this->_tpl_vars['listDet']['branch_id'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
"  selected="selected"><?php echo $this->_tpl_vars['LoctList']['0']['sensorName']; ?>
</option> <?php endif; ?>
	<?php if ($this->_tpl_vars['LoctList']['0']['sensorCode'] != $this->_tpl_vars['listDet']['sensorCode']): ?>
	<option value="<?php echo $this->_tpl_vars['listDet']['sensorName']; ?>
|<?php echo ((is_array($_tmp=$this->_tpl_vars['listDet']['sensorCode'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
|<?php echo ((is_array($_tmp=$this->_tpl_vars['listDet']['gateway_id'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
|<?php echo ((is_array($_tmp=$this->_tpl_vars['listDet']['company_id'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
|<?php echo ((is_array($_tmp=$this->_tpl_vars['listDet']['branch_id'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
"><?php echo $this->_tpl_vars['listDet']['sensorName']; ?>
</option>
	<?php endif; ?>
	<?php endforeach; endif; unset($_from); ?>
	</select>
	</div>
	</form>	</div>
	</div>
	</div>
	</div>
	<div class="row">
		
		<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2 card-outline card-danger">
			<span class="info-box-icon bg-danger elevation-1"><i class="fa fa-bolt"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">T KWH&ensp;&ensp;<b id="tckw"><script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['todayCostKWH']['0']['TOTAL_KWH']; ?>
','tckw');</script></b></span>
			<span class="info-box-text">
			Y KWH&ensp;&ensp; <b id="yckw"><script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['yesterdayCostKWH']['0']['TOTAL_KWH']; ?>
','yckw');</script></b>
			</span>
	
			</div>
			</div>
		</div>
		<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box card-outline card-primary">
			<span class="info-box-icon bg-info elevation-1"><b>&#8377;</b></span>
			<div class="info-box-content">
			<span class="info-box-text">T Cost&ensp;&ensp;<b id="tc"><script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['todayCostKWH']['0']['cost']; ?>
','tc');</script></b></span>
			<span class="info-box-text">

			Y Cost&ensp;&ensp; <b id="yc"><script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['yesterdayCostKWH']['0']['cost']; ?>
','yc');</script></b>
			<small></small>
			</span>
			</div>
			</div>
		</div>
	<!-- fix for small devices only -->
	<div class="clearfix hidden-md-up"></div>
			
			<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2 card-outline card-danger">
			<span class="info-box-icon bg-danger elevation-1"><i class="fa fa-bolt"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">This Month KWH</span>
			<span class="info-box-number" id="tmk">
			    <script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['monthCostKWH']['0']['TOTAL_KWH']; ?>
','tmk');</script>
			    </span>
			</div>
			</div>
			</div>
			<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2 card-outline card-primary">
			<span class="info-box-icon bg-info elevation-1"><b>&#8377;</b></span>
			<div class="info-box-content">
			<span class="info-box-text"> This Month Cost</span>
			<span class="info-box-number" id="tmc">
			<script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['monthCostKWH']['0']['cost']; ?>
','tmc');</script>
			</span>
			</div>
			</div>
			</div>
	<div class="clearfix hidden-md-up"></div>
		
		<div class="col-12 col-sm-6 col-md-2">
		<div class="info-box mb-2 card-outline card-danger">
		<span class="info-box-icon bg-danger elevation-1"><i class="fa fa-bolt"></i></span>
		<div class="info-box-content">
		<span class="info-box-text">Last Month KWH</span>
		<span class="info-box-number" id="lmk">
		    <script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['LastMonthCostKWH']['0']['TOTAL_KWH']; ?>
','lmk');</script>
		    </span>
		</div>
		</div>
		</div>
		<div class="col-12 col-sm-6 col-md-2">
		<div class="info-box mb-2 card-outline card-primary">
		<span class="info-box-icon bg-info elevation-1"><b>&#8377;</b></span>
		<div class="info-box-content">
		<span class="info-box-text">Last Month Cost</span>
		<span class="info-box-number" id="lmc">
		    <script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['LastMonthCostKWH']['0']['cost']; ?>
','lmc');</script>
		    </span>
		</div>
		</div>
		</div>
	</div>
		

	
	<?php if ($this->_tpl_vars['ListFeederDet2'] == '0'): ?>
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-body">
				<h1 align="center" style="color:#FF0000"> No Records Found  </h1>
				</div>
			</div>
		</div>
	</div>
	<?php else: ?>
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-body">
					<div class="row">
						<div class="col-md-4" >
							<div class="card card-widget widget-user-2">
								<div class="card card-outline card-primary">
									<div class="card-header">
									<h5 class="" style="text-align:left"><b>KW </b></h5>
									</div>
								</div>
								<div class="card-footer" style="height:200PX">
									<ul class="nav flex-column" >
									<li class="nav-item" style="backgroud-color:white">
									<div id="chartdiv" style="margin-top:-115PX"></div>
									</li>
									</ul>
								</div>
							</div>
						</div><div class="col-md-4" >
					<div class="card card-widget widget-user-2">
						<div class="card card-outline card-primary">
							<div class="card-header">
							<h5 class="" style="text-align:left"><b>KVA</b></h5>
							</div>
						</div>
						<div class="card-footer" style="height:200PX">
							<ul class="nav flex-column" >
							<li class="nav-item" style="backgroud-color:white">
							<div id="chartdiv2" style="margin-top:-115PX"></div>
							</li>
							</ul>
						</div>
					</div>
					</div>
						<div class="col-md-4" >
							<div class="card card-widget widget-user-2">
								<div class="card card-outline card-primary">
									<div class="card-header">
									<h5 class="" style="text-align:left"><b>KVAR </b></h5>
									</div>
								</div>
								<div class="card-footer" style="height:200PX">
									<ul class="nav flex-column" >
									<li class="nav-item" style="backgroud-color:white">
									<div id="chartdiv3" style="margin-top:-115PX"></div>
									</li>
									</ul>
								</div>
							</div>
						</div>
        				</div>
					<div class="row">
						<div class="col-md-4">
							<div class="card card-widget widget-user-2">
								<div class="card-footer p-0">
									<ul class="nav flex-column">
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b>VR</b> <span class="float-right badge bg-danger"><?php echo $this->_tpl_vars['ListFeederDet']['0']['R_VOLTAGE']; ?>
</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> VY </b><span class="float-right badge bg-warning"><?php echo $this->_tpl_vars['ListFeederDet']['0']['Y_VOLTAGE']; ?>
</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> VB</b> <span class="float-right badge bg-primary"><?php echo $this->_tpl_vars['ListFeederDet']['0']['B_VOLTAGE']; ?>
</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> Status - <?php echo ((is_array($_tmp=$this->_tpl_vars['ListFeederDet']['0']['recorded_date_time'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%d-%b-%Y %I:%M %p") : smarty_modifier_date_format($_tmp, "%d-%b-%Y %I:%M %p")); ?>
 </b><span class="float-right badge bg-success">Last Logged</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b>Feeder Name </b><span class="float-right badge bg-success"><?php echo $this->_tpl_vars['ListFeederDet']['0']['sensorName']; ?>
</span>
										</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="card card-widget widget-user-2">
								<div class="card-footer p-0">
									<ul class="nav flex-column">
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> VRY </b><span class="float-right badge bg-danger"><?php echo $this->_tpl_vars['ListFeederDet']['0']['RY_VOLTAGE']; ?>
</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b>VYB</b> <span class="float-right badge bg-warning"><?php echo $this->_tpl_vars['ListFeederDet']['0']['YB_VOLTAGE']; ?>
</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> VBR</b> <span class="float-right badge bg-primary"><?php echo $this->_tpl_vars['ListFeederDet']['0']['BR_VOLTAGE']; ?>
</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> PF</b> <span class="float-right badge bg-success"><?php echo $this->_tpl_vars['ListFeederDet']['0']['SUM_PF']; ?>
</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> Frequency </b> <span class="float-right badge bg-success"><?php echo $this->_tpl_vars['ListFeederDet']['0']['FREQUENCY']; ?>
</span>
										</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="card card-widget widget-user-2">					
								<div class="card-footer p-0">
									<ul class="nav flex-column">
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b>IR</b> <span class="float-right badge bg-danger"><?php echo $this->_tpl_vars['ListFeederDet']['0']['R_CURRENT']; ?>
</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b>IY</b> <span class="float-right badge bg-warning"><?php echo $this->_tpl_vars['ListFeederDet']['0']['Y_CURRENT']; ?>
</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> IB</b> <span class="float-right badge bg-primary"><?php echo $this->_tpl_vars['ListFeederDet']['0']['B_CURRENT']; ?>
</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black" >
										<b>KWH</b> <span class="float-right badge bg-success"><?php echo $this->_tpl_vars['ListFeederDet']['0']['KWH']; ?>
</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black" >
										<b> Run Hr</b> <span class="float-right badge bg-success"><?php echo $this->_tpl_vars['ListFeederDet']['0']['RUN_HOUR']; ?>
</span>
										</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
						
					
					
					<textarea id="currMonQutDaily" name="currMonQutDaily" style="display:none"><?php echo $this->_tpl_vars['getCurMonSalDailyDash']; ?>
</textarea>
        <div class="row">
				<div class="col-md-12">
			
					<div class="card card-primary card-outline">
						<div class="card-header">
						<h3 class="card-title">
						<i class="far fa-chart-bar"></i>
						Daily Cost Chart
						</h3>
						</div>
                        
					<!--<div id="linechartdiv" style="height: 260px;"></div><br />-->
                    
                    <div class="chart">
        <canvas id="DailybarChart2" style="height: 208px;" ></canvas>
        </div>
                    
					</div>
				</div>
			
			
			
			
			</div>	
			
		<textarea id="hourlyData" name="hourlyData" style="display:none"><?php echo $this->_tpl_vars['getHourlyDataDash']; ?>
</textarea>
        <div class="row">
				<div class="col-md-12">
			
					<div class="card card-primary card-outline">
						<div class="card-header">
						<h3 class="card-title">
						<i class="far fa-chart-bar"></i>
						Today Hourly Chart
						</h3>
						</div>
                        
					<!--<div id="linechartdiv" style="height: 260px;"></div><br />-->
                    
                    <div class="chart">
        <canvas id="DailybarChart3" style="height: 208px;" ></canvas>
        </div>
                    
					</div>
				</div>
			
			
			
			
			</div>	

						
				<div class="row">
					<div class="col-md-6">
						<div class="card card-primary card-outline">
							<div class="card-header">
							<h3 class="card-title">
							<i class="far fa-chart-bar"></i>
							Cost Chart
							</h3>
							</div>
						<div id="Barchartdiv" style="height: 300px;"></div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="card card-primary card-outline">
							<div class="card-header">
							<h3 class="card-title">
							<i class="far fa-chart-bar"></i>
							Kwh Chart
							</h3>
							</div>
							<div class="card-body">
							<div id="Linechartdiv" style="height: 260px;"></div>
							</div>
						</div>
					</div>
				</div>
				
			
				<!--<section class="content">
				    <div class="box box-default color-palette-box">
        
        <div class="box-body">
          <div class="row">
            <div class="col-sm-4 col-md-2">
              <h4 class="text-center">Primary</h4>

              <div class="color-palette-set">
                <div class="bg-light-blue disabled color-palette"><span>Disabled</span></div>
                <div class="bg-light-blue color-palette"><span>#3c8dbc</span></div>
                <div class="bg-light-blue-active color-palette"><span>Active</span></div>
              </div>
            </div>
            <div class="col-sm-4 col-md-2">
              <h4 class="text-center">Info</h4>

              <div class="color-palette-set">
                <div class="bg-aqua disabled color-palette"><span>Disabled</span></div>
                <div class="bg-aqua color-palette"><span>#00c0ef</span></div>
                <div class="bg-aqua-active color-palette"><span>Active</span></div>
              </div>
            </div>
            <div class="col-sm-4 col-md-2">
              <h4 class="text-center">Success</h4>

              <div class="color-palette-set">
                <div class="bg-green disabled color-palette"><span>Disabled</span></div>
                <div class="bg-green color-palette"><span>#00a65a</span></div>
                <div class="bg-green-active color-palette"><span>Active</span></div>
              </div>
            </div>
            <div class="col-sm-4 col-md-2">
              <h4 class="text-center">Warning</h4>

              <div class="color-palette-set">
                <div class="bg-yellow disabled color-palette"><span>Disabled</span></div>
                <div class="bg-yellow color-palette"><span>#f39c12</span></div>
                <div class="bg-yellow-active color-palette"><span>Active</span></div>
              </div>
            </div>
            <div class="col-sm-4 col-md-2">
              <h4 class="text-center">Danger</h4>

              <div class="color-palette-set">
                <div class="bg-red disabled color-palette"><span>Disabled</span></div>
                <div class="bg-red color-palette"><span>#f56954</span></div>
                <div class="bg-red-active color-palette"><span>Active</span></div>
              </div>
            </div>
            <div class="col-sm-4 col-md-2">
              <h4 class="text-center">Gray</h4>

              <div class="color-palette-set">
                <div class="bg-gray disabled color-palette"><span>Disabled</span></div>
                <div class="bg-gray color-palette"><span>#d2d6de</span></div>
                <div class="bg-gray-active color-palette"><span>Active</span></div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-sm-4 col-md-2">
              <h4 class="text-center">Navy</h4>

              <div class="color-palette-set">
                <div class="bg-navy disabled color-palette"><span>Disabled</span></div>
                <div class="bg-navy color-palette"><span>#001F3F</span></div>
                <div class="bg-navy-active color-palette"><span>Active</span></div>
              </div>
            </div>
            <div class="col-sm-4 col-md-2">
              <h4 class="text-center">Teal</h4>

              <div class="color-palette-set">
                <div class="bg-teal disabled color-palette"><span>Disabled</span></div>
                <div class="bg-teal color-palette"><span>#39CCCC</span></div>
                <div class="bg-teal-active color-palette"><span>Active</span></div>
              </div>
            </div>
            <div class="col-sm-4 col-md-2">
              <h4 class="text-center">Purple</h4>

              <div class="color-palette-set">
                <div class="bg-purple disabled color-palette"><span>Disabled</span></div>
                <div class="bg-purple color-palette"><span>#605ca8</span></div>
                <div class="bg-purple-active color-palette"><span>Active</span></div>
              </div>
            </div>
            <div class="col-sm-4 col-md-2">
              <h4 class="text-center">Orange</h4>

              <div class="color-palette-set">
                <div class="bg-orange disabled color-palette"><span>Disabled</span></div>
                <div class="bg-orange color-palette"><span>#ff851b</span></div>
                <div class="bg-orange-active color-palette"><span>Active</span></div>
              </div>
            </div>
            <div class="col-sm-4 col-md-2">
              <h4 class="text-center">Maroon</h4>

              <div class="color-palette-set">
                <div class="bg-maroon disabled color-palette"><span>Disabled</span></div>
                <div class="bg-maroon color-palette"><span>#D81B60</span></div>
                <div class="bg-maroon-active color-palette"><span>Active</span></div>
              </div>
            </div>
            <div class="col-sm-4 col-md-2">
              <h4 class="text-center">Black</h4>

              <div class="color-palette-set">
                <div class="bg-black disabled color-palette"><span>Disabled</span></div>
                <div class="bg-black color-palette"><span>#111111</span></div>
                <div class="bg-black-active color-palette"><span>Active</span></div>
              </div>
            </div>
          </div>
        </div>
      </div>
				</section>-->
				<div class="row">
					<div class="col-md-12">
						<div class="card card-primary card-tabs">
							<div class="card-header p-0 pt-1 border-bottom-0">
								<ul class="nav nav-tabs" id="custom-content-below-tab" role="tablist">
								
									<li class="nav-item">
									<!-- onclick="dailyReport()"   -->
									<a class="nav-link active" id="custom-content-below-messages-tab" data-toggle="pill" href="#tab-5" role="tab" aria-controls="custom-content-below-messages" aria-selected="false"  >Hourly Report</a>
									</li>
									<?php if ($this->_tpl_vars['LoctList']['0']['feeder_type'] == 'Overall Main Meter'): ?>

									<li class="nav-item">
									<!-- onclick="dailyReport()"   -->
									<a class="nav-link " id="custom-content-below-messages-tab" data-toggle="pill" href="#tab-6" role="tab" aria-controls="custom-content-below-messages" aria-selected="false"  >Slot Wise Report</a>
									</li>
									<?php endif; ?>
									<li class="nav-item">
									<!-- onclick="dailyReport()"   -->
									<a class="nav-link " id="custom-content-below-messages-tab" data-toggle="pill" href="#tab-4" role="tab" aria-controls="custom-content-below-messages" aria-selected="false"  >Daily Report</a>
									</li>
									<li class="nav-item">
									<!-- onclick="logReport()"   -->
									<a class="nav-link" onclick="logReport()" id="custom-content-below-messages-tab" data-toggle="pill" href="#tab-3" role="tab" aria-controls="custom-content-below-messages" aria-selected="false" >Log Report</a>
									</li>
									<li class="nav-item">
									<!-- onclick="trentGraph()"   -->
									<a class="nav-link" onclick="trentGraph()"  id="custom-content-below-profile-tab" data-toggle="pill" href="#tab-1" role="tab" aria-controls="custom-content-below-profile" aria-selected="true" >Historical Trend</a>
									</li>
								<!--	<?php if ($this->_tpl_vars['LoctList']['0']['feeder_type'] == 'Main Meter' || $this->_tpl_vars['LoctList']['0']['feeder_type'] == 'Overall Main Meter'): ?>
									<li class="nav-item">
								
									<a class="nav-link" onclick="demandReport()"  id="custom-content-below-profile-tab" data-toggle="pill" href="#tab-2" role="tab" aria-controls="custom-content-below-profile" aria-selected="true" >Demand Report</a>
									</li>
									<?php endif; ?> 
									-->
								
								</ul>
							</div>
							 <div class="tab-content" >
										<div id="tab-5" class="tab-pane active" >
									<!--<div class="loader"></div>-->
										<div class="card-body">
										<!--<iframe  height="820px" width="98%" src="./energyMeterDlyReport.php?gatewayCode=<?php echo $this->_supers['get']['gatewayCode']; ?>
&sensorCode=<?php echo $this->_supers['get']['sensorCode']; ?>
" style="border:1px;"></iframe></div>-->
										<iframe id="hourly_report" height="820px" width="98%" src="" style="border:1px;"></iframe></div>
									</div>	
									<?php if ($this->_tpl_vars['LoctList']['0']['feeder_type'] == 'Overall Main Meter'): ?>
									<div id="tab-6" class="tab-pane active" >
									<!--<div class="loader"></div>-->
										<div class="card-body">
										<!--<iframe  height="820px" width="98%" src="./energyMeterDlyReport.php?gatewayCode=<?php echo $this->_supers['get']['gatewayCode']; ?>
&sensorCode=<?php echo $this->_supers['get']['sensorCode']; ?>
" style="border:1px;"></iframe></div>-->
										<iframe id="slot_wise_report" height="820px" width="98%" src="" style="border:1px;"></iframe></div>
									</div>		
									<?php endif; ?>							
									<div id="tab-4" class="tab-pane " >
									<!--<div class="loader"></div>-->
										<div class="card-body">
										<!--<iframe  height="820px" width="98%" src="./energyMeterDlyReport.php?gatewayCode=<?php echo $this->_supers['get']['gatewayCode']; ?>
&sensorCode=<?php echo $this->_supers['get']['sensorCode']; ?>
" style="border:1px;"></iframe></div>-->
										<iframe id="daily_report" height="820px" width="98%" src="" style="border:1px;"></iframe></div>
									</div>
									<div id="tab-3" class="tab-pane">
									<div class="loader" style="background-color:#999999"></div>
										<div class="card-body">
										<iframe id="log_report" height="820px" width="98%" src="" style="border:1px;"></iframe>
										</div>
									</div>
								
									<div id="tab-1" class="tab-pane ">
									<div class="loader"></div>
											<div class="card-body">
											<iframe id="trendGraph" height="820px" width="100%" src="" style="border:1px;"></iframe></div>
									</div>
								<!--	<div id="tab-2" class="tab-pane ">
									<div class="loader"></div>
											<div class="card-body">
											<iframe id="demand_report" height="820px" width="100%" src="" style="border:1px;"></iframe></div>
									</div>-->
							</div>
						</div>
					</div>
				</div>
				</div>
			</div>
		</div>
	</div><?php endif; ?>
	</div>
	</div>
	</div>
	<?php echo '
	<script src="plugins/jquery/jquery.min.js"></script>

	<script type="text/javascript">
	var gId=$("#gatewayCode").val();
	var sId=$("#sensorCode").val();
	var cId=$("#companyId").val();
	var bId=$("#branchId").val();
	var pageURL = $(location).attr("href");	
	window.onload = function(){
	
	setTimeout(function(){
	document.getElementById(\'hourly_report\').src = \'./energyMeterHourlyReport.php?companyId=\'+cId+\'&branchId=\'+bId+\'&gatewayCode=\'+gId+\'&sensorCode=\'+sId;
	'; ?>
<?php if ($this->_tpl_vars['LoctList']['0']['feeder_type'] == 'Overall Main Meter'): ?><?php echo '
	document.getElementById(\'slot_wise_report\').src = \'./energyMeterSlotWiseReport.php?companyId=\'+cId+\'&branchId=\'+bId+\'&gatewayCode=\'+gId+\'&sensorCode=\'+sId;
	'; ?>
<?php endif; ?><?php echo '
	document.getElementById(\'daily_report\').src = \'./energyMeterDlyReport.php?companyId=\'+cId+\'&branchId=\'+bId+\'&gatewayCode=\'+gId+\'&sensorCode=\'+sId;

	//document.getElementById(\'trendGraph\').src = \'./trendGraph.php?gatewayCode=\'+gId+\'&sensorCode=\'+sId;
	//document.getElementById(\'log_report\').src = \'./icdMeterLog.php?gatewayCode=\'+gId+\'&sensorCode=\'+sId;
	
	},100);
	};
</script>
<script>
/*		function dailyReport(){
	var gId=$("#gatewayCode").val();
	var sId=$("#sensorCode").val();
	document.getElementById(\'daily_report\').src = \'./energyMeterDlyReport.php?gatewayCode=\'+gId+\'&sensorCode=\'+sId;
	$(".loader").hide();
	}*/
	function trentGraph(){
	var gId=$("#gatewayCode").val();
	var sId=$("#sensorCode").val();
	var cId=$("#companyId").val();
	var bId=$("#branchId").val();
	document.getElementById(\'trendGraph\').src = \'./trendGraph.php?companyId=\'+cId+\'&branchId=\'+bId+\'&gatewayCode=\'+gId+\'&sensorCode=\'+sId;
	$(".loader").hide();
	}
		function logReport(){
	var gId=$("#gatewayCode").val();
	var sId=$("#sensorCode").val();
	var cId=$("#companyId").val();
	var bId=$("#branchId").val();
	document.getElementById(\'log_report\').src = \'./icdMeterLog.php?companyId=\'+cId+\'&branchId=\'+bId+\'&gatewayCode=\'+gId+\'&sensorCode=\'+sId;
	$(".loader").hide();
	}
	function demandReport(){
	var gId=$("#gatewayCode").val();
	var sId=$("#sensorCode").val();
	document.getElementById(\'demand_report\').src = \'./demandLog.php?gatewayCode=\'+gId+\'&sensorCode=\'+sId;
	$(".loader").hide();
	}

</script>

<script>
	function postFeeder()
	{
		var feederName=document.getElementById("feederPost").value;
		var feedSplit= feederName.split("|");
		var senCod=feedSplit[1];
		var gatCod=feedSplit[2];
		var comId=feedSplit[3];
		var branId=feedSplit[4];
		FormName		= document.dashboard;
		FormName.action= "meterDashboard.php?companyId="+comId+"&branchId="+branId+"&sensorCode="+senCod+"&gatewayCode="+gatCod;
		FormName.submit();
	}
	</script>
	<script type="text/javascript">
var result = document.getElementById(\'currMonQutDaily\').value;
//alert(result);
var jsonData=result;
var obj = JSON.parse(jsonData);
var mon = "";
var dataVal = "";
var dataVal1 = "";
var colo = "";
var i;
for (i = 0; i < obj.length; i++) {
if(i==0){
  mon += obj[i].dateM ;
  dataVal += obj[i].value;
  dataVal1 += obj[i].value1;
   colo += obj[i].color;
   }
  else
  {
  mon += ", "+ obj[i].dateM;
  dataVal += ", "+ obj[i].value;
   dataVal1 += ", "+ obj[i].value1;
   colo += \', \'+ obj[i].color;
 }
}
// loop  variable concatinate each  record  as an array
var monthVal = mon;
var dataValue =dataVal;
var dataValue1 =dataVal1;
var colors =colo;


// above mentioned  array variable  split by comma to plot the variable in lable and data in chart
var month =  monthVal.split(\',\');
var dataV=  dataVal.split(\',\');//alert(numberWithCommas(dataV));
//alert(dataV);
 
  var dis = Math.round(dataV);//alert(dis);
  var vad = addcomma(dis);//alert(vad);
//var dataV=addCommas(dataV);
var dataV1=  dataVal1.split(\',\');
var clr=  colors.split(\',\');
  var barChartCanvasSec = $(\'#DailybarChart2\').get(0).getContext(\'2d\');
 

  var barChartDataSec = {
    labels  :  month,
    datasets: [
      {
          label               : \'Kwh\',
          backgroundColor     : \'#67b7dc\',
          borderColor         :  \'#67b7dc\',
          pointRadius          : false,
          pointColor          :  \'#67b7dc\',
          pointStrokeColor    :  \'#67b7dc\',
          pointHighlightFill  :  \'#67b7dc\',
          pointHighlightStroke:  \'#67b7dc\',
		  fillColor: "#67b7dc",
          data                : dataV
      },
      {
        label                 : \'Cost\',
          backgroundColor     : \'#fdd400\',
          borderColor         :  \'#fdd400\',
          pointRadius         : false,
          pointColor          :  \'#fdd400\',
          pointStrokeColor    :  \'#fdd400\',
          pointHighlightFill  :  \'#fdd400\',
          pointHighlightStroke:  \'#fdd400\',
		  fillColor: "#fdd400",
          data                : dataV1
      }
    ]
  };
  
   
  
    var barChartOptionsSec = {
	tooltips: {
        callbacks: {
            label: function(tooltipItem) {
			var dis = Math.round(tooltipItem.yLabel);
			//alert(dis);
  var vad = includecomma(dis);
  //alert(vad);
                return vad;
            }
        }
    },
      responsive              : true,
      maintainAspectRatio     : false,
      datasetFill             : true,
	    scales: {
		yAxes: [{
              ticks:{
                  stepSize : 5000,

              }
			  }]
		}
	      };


    var barChartSec = new Chart(barChartCanvasSec, {
      type: \'bar\', 
      data: barChartDataSec,
      options: barChartOptionsSec,
    });
	
	barChartSec.Bar(barChartDataSec, barChartOptionsSec);
	
</script>

<script type="text/javascript">
var result = document.getElementById(\'hourlyData\').value;
//alert(result);
var jsonData=result;
var obj = JSON.parse(jsonData);
var mon = "";
var dataVal = "";
var dataVal1 = "";
var colo = "";
var i;
for (i = 0; i < obj.length; i++) {
if(i==0){
  mon += obj[i].dateM ;
  dataVal += obj[i].value;
  dataVal1 += obj[i].value1;
   colo += obj[i].color;
   }
  else
  {
  mon += ", "+ obj[i].dateM;
  dataVal += ", "+ obj[i].value;
   dataVal1 += ", "+ obj[i].value1;
   colo += \', \'+ obj[i].color;
 }
}
// loop  variable concatinate each  record  as an array
var monthVal = mon;
var dataValue =dataVal;
var dataValue1 =dataVal1;
var colors =colo;


// above mentioned  array variable  split by comma to plot the variable in lable and data in chart
var month =  monthVal.split(\',\');
var dataV=  dataVal.split(\',\');//alert(numberWithCommas(dataV));
//alert(dataV);
 
  var dis = Math.round(dataV);//alert(dis);
  var vad = addcomma(dis);//alert(vad);
//var dataV=addCommas(dataV);
var dataV1=  dataVal1.split(\',\');
var clr=  colors.split(\',\');
  var barChartCanvasSec2 = $(\'#DailybarChart3\').get(0).getContext(\'2d\');
 

  var barChartDataSec2 = {
    labels  :  month,
    datasets: [
      {
          label               : \'Kwh\',
          backgroundColor     : \'#67b7dc\',
          borderColor         :  \'#67b7dc\',
          pointRadius          : false,
          pointColor          :  \'#67b7dc\',
          pointStrokeColor    :  \'#67b7dc\',
          pointHighlightFill  :  \'#67b7dc\',
          pointHighlightStroke:  \'#67b7dc\',
		  fillColor: "#67b7dc",
          data                : dataV
      },
      {
        label                 : \'Cost\',
          backgroundColor     : \'#fdd400\',
          borderColor         :  \'#fdd400\',
          pointRadius         : false,
          pointColor          :  \'#fdd400\',
          pointStrokeColor    :  \'#fdd400\',
          pointHighlightFill  :  \'#fdd400\',
          pointHighlightStroke:  \'#fdd400\',
		  fillColor: "#fdd400",
          data                : dataV1
      }
    ]
  };
  
   
  
    var barChartOptionsSec2 = {
	tooltips: {
        callbacks: {
            label: function(tooltipItem) {
			var dis = Math.round(tooltipItem.yLabel);
			//alert(dis);
  var vad = includecomma(dis);
  //alert(vad);
                return vad;
            }
        }
    },
      responsive              : true,
      maintainAspectRatio     : false,
      datasetFill             : true,
	    scales: {
		yAxes: [{
              ticks:{
                  stepSize : 5000,

              }
			  }]
		}
	      };


    var barChartSec2 = new Chart(barChartCanvasSec2, {
      type: \'bar\', 
      data: barChartDataSec2,
      options: barChartOptionsSec2,
    });
	
	barChartSec2.Bar(barChartDataSec2, barChartOptionsSec2);
	
</script>
<script>
  $(function () {
    //Initialize Select2 Elements
    $(\'.select2\').select2()

    //Initialize Select2 Elements
    $(\'.select2bs4\').select2({
      theme: \'bootstrap4\'
    })
});
</script>
<script src="plugins/select2/js/select2.full.min.js"></script> <!--  This script for select drop down-->
	<style type="text/css">
	#DailybarChart2{
	width	: 100%;
	height	: 450px;
	}
	#DailybarChart3{
	width	: 100%;
	height	: 450px;
	}
	</style>
	<style type="text/css">
	iframe {
		overflow-x: hidden;
		overflow-y: scroll;
	}
	</style>
	'; ?>

	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>