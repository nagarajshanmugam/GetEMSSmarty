<?php /* Smarty version 2.6.25, created on 2026-06-30 16:57:31
         compiled from subdashboard.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'base64_encode', 'subdashboard.tpl', 234, false),array('modifier', 'date_format', 'subdashboard.tpl', 253, false),)), $this); ?>
<?php echo '

<script type="text/javascript">
     function secondsToDhms(seconds,v) {//alert(seconds);
var seconds = Number(seconds);
var d = Math.floor(seconds / (3600*24));
var h = Math.floor(seconds % (3600*24) / 3600);
var m = Math.floor(seconds % 3600 / 60);
var s = Math.floor(seconds % 60);

var dDisplay = d > 0 ? d + (d == 1 ? " day, " : " days, ") : "";
var hDisplay = h > 0 ? h + (h == 1 ? " hr, " : " hrs, ") : "";
var mDisplay = m > 0 ? m + (m == 1 ? " min, " : " min\'s, ") : "";
var sDisplay = s > 0 ? s + (s == 1 ? " sec" : " sec\'s") : "";
var res=  dDisplay + hDisplay + mDisplay + sDisplay;
document.getElementById(v).innerHTML=res;
}
 </script>
 <script type="text/javascript">
	function includecomma1(c,v)
{
//var x=Math.round(c);
//var x=c.toFixed(2);

var x=c.split(".");
var ld=x[1];
var ty=typeof(x[1]);//alert(ty);
if(ty == \'undefined\')
{
   
    var ld=\'00\';
}
else
{
var ld=x[1].slice(0, 2);
}
x=x[0].toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != \'\')
{
lastThree = \',\' + lastThree;
var res = otherNumbers.replace(/\\B(?=(\\d{2})+(?!\\d))/g, ",") + lastThree;
}
else
{
lastThree =  lastThree;
var res = otherNumbers.replace(/\\B(?=(\\d{2})+(?!\\d))/g, ",") + lastThree;
}
//var res = res+\'.00\';
var res = res+\'.\'+ld;
document.getElementById(v).innerHTML=res;
}
</script>
'; ?>


<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<body onLoad="doOnLoad();">
<div class="content-wrapper">

<!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">-->

    <div class="content-header">

      <div class="container-fluid">

            <div class="row"> <div class="col-md-12">
            <div class="card">
            <div class="card-body">

			 <table style="margin-bottom:-10px;">
		  <tr><td style="font-size:15PX;font-weight: bold;"><?php echo $this->_tpl_vars['companyDetail']['0']['companyName']; ?>
&nbsp;&nbsp;</td>
		  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  <td style="font-size:15PX;font-weight: bold;"><?php echo $this->_tpl_vars['branchDetail']['0']['branch_name']; ?>
&ensp;&ensp;</td>
		  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  <td style="font-size:15PX;font-weight: bold;"><?php echo $this->_tpl_vars['senDashboard']['0']['sensorName']; ?>
&ensp;&ensp;</td>
		  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  <td style="font-size:15PX;font-weight: bold;">List Sub Meter  <!---(<?php echo $this->_tpl_vars['LoctList']['0']['gateway_id']; ?>
 / <?php echo $this->_tpl_vars['LoctList']['0']['sensorCode']; ?>
)--></font>&nbsp;</td></tr>
		  
		
		  <tr><td style="font-size:10PX;color:#999999;">Company Name</td>
		  <td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  <td style="font-size:10PX;color:#999999;">Branch Name</td>
		  <td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  <td style="font-size:10PX;color:#999999;">Meter Name</td>
		  <td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  <!--<td style="color:#999999;font-size:10PX;">Dashboard</td><td>&nbsp;</td>-->
		  </tr>
		  
		  </table>
		             

		    </div>
			</div>
			</div>
          <!--<div class="col-md-12 >
		  
            <div class="info-box">
              <div class="info-box-content">
                 <span class="pull-left text-info"><h5><b><?php echo $this->_tpl_vars['LoctList']['0']['companyName']; ?>
&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp; <?php echo $this->_tpl_vars['LoctList']['0']['branch_name']; ?>
&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp; <?php echo $this->_tpl_vars['LoctList']['0']['gateway_id']; ?>
&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;<?php echo $this->_tpl_vars['LoctList']['0']['sensorName']; ?>
</b></h5></span>
              </div>
            </div>
          </div>-->
          </div>

<!--<div class="row">
          <div class="col-12 col-sm-6 col-md-2">
            <div class="info-box card-outline card-primary">
              <span class="info-box-icon bg-info elevation-1"><i class="fa fa-rupee"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Today Cost&ensp;&ensp;&ensp;&ensp;</span>
                <span class="info-box-number" id="tcost">
			<script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['todayCostKWH']['0']['cost']; ?>
','tcost');</script>
			<small></small>
			</span>
              </div>
           
            </div>
           
          </div>
       
          <div class="col-12 col-sm-6 col-md-2">
            <div class="info-box mb-2 card-outline card-danger">
              <span class="info-box-icon bg-danger elevation-1"><i class="fa fa-bolt"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Today KWH &ensp;&ensp;&ensp;&ensp;</span>
                <span class="info-box-number" id="tkwh">
			<script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['todayCostKWH']['0']['TOTAL_KWH']; ?>
','tkwh');</script>
			<small></small>
			</span>
              </div>
          
            </div>
         
          </div>
         
          <div class="clearfix hidden-md-up"></div>

          <div class="col-12 col-sm-6 col-md-2">
            <div class="info-box mb-2 card-outline card-primary">
              <span class="info-box-icon bg-info elevation-1"><i class="fa fa-rupee"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">This Month Cost</span>
                <span class="info-box-number" id="mcost">
			<script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['monthCostKWH']['0']['cost']; ?>
','mcost');</script>
			<small></small>
			</span>
              </div>
             
            </div>
           
          </div>
        
          <div class="col-12 col-sm-6 col-md-2">
            <div class="info-box mb-2 card-outline card-danger">
              <span class="info-box-icon bg-danger elevation-1"><i class="fa fa-bolt"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">This Month KWH</span>
                <span class="info-box-number" id="mkwh">
			<script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['monthCostKWH']['0']['TOTAL_KWH']; ?>
','mkwh');</script>
			<small></small>
			</span>
              </div>
             
            </div>
           
          </div>
          
          <div class="clearfix hidden-md-up"></div>

          <div class="col-12 col-sm-6 col-md-2">
            <div class="info-box mb-2 card-outline card-primary">
              <span class="info-box-icon bg-info elevation-1"><i class="fa fa-rupee"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Last Month Cost</span>
                <span class="info-box-number" id="lcost">
			<script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['LastMonthCostKWH']['0']['cost']; ?>
','lcost');</script>
			<small></small>
			</span>
              </div>
              
            </div>
            
          </div>
         
          <div class="col-12 col-sm-6 col-md-2">
            <div class="info-box mb-2 card-outline card-danger">
              <span class="info-box-icon bg-danger elevation-1"><i class="fa fa-bolt"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Last Month KWH</span>
                <span class="info-box-number" id="lkwh">
			<script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['LastMonthCostKWH']['0']['TOTAL_KWH']; ?>
','lkwh');</script>
			<small></small>
			</span>
              </div>
             
            </div>
           
          </div>
         
         
        </div>-->
       
            <div class="row">

			<div class="col-md-12">

            <div class="card card-outline card-primary">
<div class="card-header">
						<h3 class="card-title">
						<i class="fa fa-list"></i>
						&nbsp;&nbsp;List of Sub Energy Meter
						</h3>
						
						</div>
               <div class="card-body table-responsive no-padding">
			 <div class="row">

            

            
<input type="hidden" id="cid" name="cid" value="<?php if ($this->_supers['get']['companyId'] != ""): ?><?php echo $this->_supers['get']['companyId']; ?>
<?php else: ?><?php echo $this->_supers['session']['customerId']; ?>
<?php endif; ?>" />
    <input type="hidden" id="bid" name="bid" value="<?php echo $this->_supers['get']['branchId']; ?>
" />
     <input type="hidden" id="parentid" name="parentid" value="<?php echo $this->_supers['get']['parent_id']; ?>
" />
            <input type="hidden" value="<?php echo $this->_tpl_vars['Dashboard']['0']['segmentName']; ?>
" />

   
<!--<div class="col-md-4" onclick="window.location='./meterDashboard.php?companyId=<?php if ($this->_supers['get']['companyId'] != ""): ?><?php echo $this->_supers['get']['companyId']; ?>
<?php else: ?><?php echo ((is_array($_tmp=$this->_supers['session']['CustomerId'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
<?php endif; ?>&branchId=<?php if ($this->_supers['get']['branchId'] != ""): ?><?php echo $this->_supers['get']['branchId']; ?>
<?php else: ?><?php echo ((is_array($_tmp=$this->_supers['session']['branch_id'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
<?php endif; ?>&sensorCode=<?php echo ((is_array($_tmp=$this->_tpl_vars['master_dtls']['sensor_code'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
&gatewayCode=<?php echo ((is_array($_tmp=$this->_tpl_vars['master_dtls']['gateway_code'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
'" style="cursor:pointer;">

            <div class="card card-widget widget-user-2">

              <div class="card card-outline card-primary">

			  <div class="widget-user-header bg-primary">
			  <div class="widget-user-image">
                  <img class="img-circle elevation-2" src="images/meterImage.png" alt="User Avatar">
                </div>
			   <h5 class="widget-user-username" style="text-align:left"><b><?php echo $this->_tpl_vars['master_dtls']['feeder_name']; ?>
</b><span class="float-right badge bg-warning"></span></h5>

			  </div>
			  </div>
			   
				  <div class="card-footer p-0">
                <ul class="nav flex-column">
								  <li class="nav-item">
                    <a href="#" class="nav-link" style="text-decoration:none;color:black">
                     <b> Status  -  <?php echo ((is_array($_tmp=$this->_tpl_vars['master_dtls']['recorded_date_time'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%d-%b-%Y %I:%M %p") : smarty_modifier_date_format($_tmp, "%d-%b-%Y %I:%M %p")); ?>
 </b><span class="float-right badge bg-success">Last Logged</span>
                    </a>
                  </li>

				<?php $_from = $this->_tpl_vars['CostKWH']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['costKwh']):
?>
					 <?php if ($this->_tpl_vars['costKwh']['sensor_code'] == $this->_tpl_vars['master_dtls']['sensor_code']): ?>
					   <li class="nav-item">
						<a href="#" class="nav-link" style="text-decoration:none;color:black">
						  <b>Today KWH</b> <span class="float-right badge bg-success"><?php echo $this->_tpl_vars['costKwh']['TOTAL_KWH']; ?>
</span>
						</a>
					   </li>
					   <li class="nav-item">
						<a href="#" class="nav-link" style="text-decoration:none;color:black">
						  <b>Today Cost</b> <span class="float-right badge bg-success">Rs.<?php echo $this->_tpl_vars['costKwh']['cost']; ?>
</span>
						</a>
					   </li>
					  <?php endif; ?>
				  <?php endforeach; endif; unset($_from); ?>
                </ul>
              </div>
			  </div>
			  </div>-->
			  <div id="list_books" class="col-12">
<table id="example" class="table table-bordered table-hover">
                <thead>
                <tr>
    			  <th class="slNo" rowspan="2" >#</th>
                  <th class="name" rowspan="2">Place Of Installation</th>
                  <th class="code" rowspan="2">Gateway</th>
				   <th class="status" rowspan="2">Status</th>
                  <th  colspan="2" class="code" >Today</th>
                  <th class="action" rowspan="2">Date Time</th>
                  <th class="last" rowspan="2">Last Comm</th>
                  
          
                </tr>
                <tr>
    			 
                  <th class="cost" >KWH</th>
                  <th class="cost" >Cost</th>
                  
                </tr>
                </thead>
                <tbody>		<?php $this->assign('tkwh', 0.00); ?>
             			<?php $this->assign('tcost', 0.00); ?>
				<?php $_from = $this->_tpl_vars['MeterList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['List']):
?>
                <?php $this->assign('pid', ((is_array($_tmp=$this->_tpl_vars['List']['slNo'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp))); ?>
				 <?php $this->assign('subMetL', 'No'); ?>
                <tr id="<?php echo $this->_tpl_vars['j']++; ?>
">
				 <td ><?php echo $this->_tpl_vars['j']; ?>
</td>
                 <td><a href="meterDashboard.php?companyId=<?php echo $this->_supers['get']['companyId']; ?>
&branchId=<?php echo $this->_supers['get']['branchId']; ?>
&sensorCode=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['sensor_code'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
&gatewayCode=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['gateway_code'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
"><span style="color:#000000;" title="Meter Details" class="uline"><?php echo $this->_tpl_vars['List']['feeder_name']; ?>
</span></a>&ensp; &ensp;<!--<?php if ($this->_tpl_vars['List']['feeder_type'] == 'Main Meter'): ?><a href="subdashboard.php?parent_id=<?php echo $this->_tpl_vars['pid']; ?>
&companyId=<?php echo $this->_supers['get']['companyId']; ?>
&branchId=<?php echo $this->_supers['get']['branchId']; ?>
"><i class="fa fa-sitemap" aria-hidden="true" title="Submeter List"></i></a><?php endif; ?>-->
                <?php $_from = $this->_tpl_vars['selQryS']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['sub']):
?><?php if ($this->_tpl_vars['List']['slNo'] == $this->_tpl_vars['sub']['parent_id'] && $this->_tpl_vars['subMetL'] == 'No'): ?>&ensp;&ensp;<a href="subdashboard.php?parent_id=<?php echo $this->_tpl_vars['pid']; ?>
&companyId=<?php echo $this->_supers['get']['companyId']; ?>
&branchId=<?php echo $this->_supers['get']['branchId']; ?>
"><i class="fa fa-sitemap" aria-hidden="true" title="Submeter List"></i></a><?php $this->assign('subMetL', 'Yes'); ?><?php endif; ?><?php endforeach; endif; unset($_from); ?></td>
                 <td ><?php echo $this->_tpl_vars['List']['gateway_code']; ?>
</td>
				 
				 
		
				
				<td>
				<?php if ($this->_tpl_vars['List']['posted_date_time'] >= ((is_array($_tmp=$this->_tpl_vars['dateSec1'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d %H:%M:%S'))): ?>
				<img  src="./images/on.png">
				<?php else: ?>
				  <img  src="./images/off.png">
				<?php endif; ?>
	<!--			<?php $_from = $this->_tpl_vars['gateList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['gate']):
?>
				
				<?php if ($this->_tpl_vars['gate']['gateway_code'] != 'YMN-1' && $this->_tpl_vars['gate']['gateway_code'] == $this->_tpl_vars['List']['gateway_code'] && $this->_tpl_vars['gate']['gateway_date_time'] >= ((is_array($_tmp=$this->_tpl_vars['dateSec'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d %H:%M:%S'))): ?>
                 <img  src="./images/on.png">
                 <?php $this->assign('tog', '1'); ?>
                <?php elseif ($this->_tpl_vars['gate']['gateway_code'] != 'YMN-1' && $this->_tpl_vars['gate']['gateway_code'] == $this->_tpl_vars['List']['gateway_code'] && $this->_tpl_vars['gate']['gateway_date_time'] < ((is_array($_tmp=$this->_tpl_vars['dateSec'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d %H:%M:%S'))): ?>
                <img  src="./images/off.png">
                 <?php $this->assign('tog', '1'); ?>
                <?php endif; ?>
                
                <?php if ($this->_tpl_vars['gate']['gateway_code'] == 'YMN-1' && $this->_tpl_vars['gate']['gateway_code'] == $this->_tpl_vars['List']['gateway_code'] && $this->_tpl_vars['gate']['gateway_date_time'] >= ((is_array($_tmp=$this->_tpl_vars['dateSec1'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d %H:%M:%S'))): ?>
                 <img  src="./images/on.png">
                 <?php $this->assign('tog', '1'); ?>
                <?php elseif ($this->_tpl_vars['gate']['gateway_code'] == 'YMN-1' && $this->_tpl_vars['gate']['gateway_code'] == $this->_tpl_vars['List']['gateway_code'] && $this->_tpl_vars['gate']['gateway_date_time'] < ((is_array($_tmp=$this->_tpl_vars['dateSec1'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d %H:%M:%S'))): ?>
                <img  src="./images/off.png">
                 <?php $this->assign('tog', '1'); ?>
                <?php endif; ?>
               
                <?php endforeach; endif; unset($_from); ?>
                <?php if ($this->_tpl_vars['tog'] == ''): ?>
                <img  src="./images/off.png">
                <?php endif; ?>
                 <?php $this->assign('tog', ''); ?>-->
				 
				 
                 
                </td>
				
				

  

								   <?php $this->assign('tkwh', $this->_tpl_vars['tkwh']+$this->_tpl_vars['List']['TOTAL_KWH']); ?>
            			   <?php $this->assign('tcost', $this->_tpl_vars['tcost']+$this->_tpl_vars['List']['cost']); ?>

				 <td align="right"><?php echo $this->_tpl_vars['List']['TOTAL_KWH']; ?>
</td>
                 <td align="right"><?php echo $this->_tpl_vars['List']['cost']; ?>
</td>

				  <td><?php echo ((is_array($_tmp=$this->_tpl_vars['List']['posted_date_time'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%d-%b-%Y %I:%M:%S %p") : smarty_modifier_date_format($_tmp, "%d-%b-%Y %I:%M:%S %p")); ?>
</td>
		       <td id="<?php echo $this->_tpl_vars['j']; ?>
"><script type="text/javascript">secondsToDhms('<?php echo $this->_tpl_vars['List']['secs']; ?>
','<?php echo $this->_tpl_vars['j']; ?>
');</script> ago</td>
			   
            
                </tr>
                <?php endforeach; else: ?>
                <tr><td colspan="8"><center>No Records Found</center></td></tr>
                <?php endif; unset($_from); ?>
               
               
                </tbody>
                
                     <tr>
                    <td colspan="4" align="right"><b>Total</b></td>

                    <td align="right"><b><span id="tk"><script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['tkwh']; ?>
','tk');</script></span></b></td>
                    <td align="right"><b> <span id="tc"><script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['tcost']; ?>
','tc');</script></span></b></td>
				
                    <td colspan="2"></td>
                    </tr>
              </table>
              </div>
        


</div>
</div>
									<div class="card-body table-responsive">

            <div class="row">

          
        </div>

        </div>


								

        

        

	  

	   

        


      </div>

    </div>

  </div>

  </div>

  </div>

  </div>
</body>
 <?php echo '
 <style>
  .slNo
 {
 width:3%;
 }
 .name
 {
 width:18%;
 }
 .gate
 {
 width:10%;
 }
 .status
 {
 width:5%;
 }
 .code
 {
 width:10%;
 }
 .cost
 {
 width:5%;
 }
 .action
 {
 width:15%;
 }
 .last
 {
 width:11%;
 }
 .uline
 {
 text-decoration:underline;
 }
 </style>
  <script type="text/javascript">
 function doOnLoad()
 {
 //setInterval(Add_Item, 3000);
 }
 </script>
 <script type="text/javascript">
  $("input[data-bootstrap-switch]").each(function(){
      $(this).bootstrapSwitch(\'state\', $(this).prop(\'checked\'));
    });
	</script>
	  <script type="text/javascript">
	function Add_Item()
{
var cid =$(\'#cid\').val() ;
var bid =$(\'#bid\').val() ;//alert(bid)
var parentid =$(\'#parentid\').val() ;
$.ajax({
		type: "POST",
		url: "getSubTableData.php",
		data: {cid:cid,bid:bid,parentid:parentid},
		success: function(data) {
		$("#list_books").html(data);
		}
		});
}
	</script>
 '; ?>


  <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>