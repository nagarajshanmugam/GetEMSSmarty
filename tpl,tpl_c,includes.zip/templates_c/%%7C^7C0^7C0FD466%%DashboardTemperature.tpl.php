<?php /* Smarty version 2.6.25, created on 2026-07-08 16:11:39
         compiled from DashboardTemperature.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'date_format', 'DashboardTemperature.tpl', 94, false),)), $this); ?>
<!DOCTYPE HTML>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Temperature Chart</title>
<?php echo '
<script type="text/javascript">
     function secondsToDhms(seconds,v) {//alert(seconds);
var seconds = Number(seconds);
var d = Math.floor(seconds / (3600*24));
var h = Math.floor(seconds % (3600*24) / 3600);
var m = Math.floor(seconds % 3600 / 60);
var s = Math.floor(seconds % 60);

var dDisplay = d > 0 ? d + (d == 1 ? " day, " : " days, ") : "";
var hDisplay = h > 0 ? h + (h == 1 ? " hr, " : " hrs, ") : "";
var mDisplay = m > 0 ? m + (m == 1 ? " min, " : " min\'s, ") : "";
var sDisplay = s > 0 ? s + (s == 1 ? " sec" : " sec\'s") : "";
//var res= \'Last Updated\' + \' \' + dDisplay + hDisplay + mDisplay + sDisplay;
var res= dDisplay + hDisplay + mDisplay + sDisplay;
document.getElementById(v).innerHTML=res;
}

 </script>

		<style type="text/css">
.highcharts-figure,
.highcharts-data-table table {
    min-width: 210px;
    max-width: 1000px;
    margin: 1em auto;
}

.highcharts-data-table table {
    font-family: Verdana, sans-serif;
    border-collapse: collapse;
    border: 1px solid #ebebeb;
    margin: 10px auto;
    text-align: center;
    width: 100%;
    max-width: 500px;
}

.highcharts-data-table caption {
    padding: 1em 0;
    font-size: 1.2em;
    color: #555;
}

.highcharts-data-table th {
    font-weight: 600;
    padding: 0.5em;
}

.highcharts-data-table td,
.highcharts-data-table th,
.highcharts-data-table caption {
    padding: 0.5em;
}

.highcharts-data-table thead tr,
.highcharts-data-table tr:nth-child(even) {
    background: #f8f8f8;
}

.highcharts-data-table tr:hover {
    background: #f1f7ff;
}

		</style>
		'; ?>

	</head>
	<body>
<script src="./highCharts/code/highcharts.js"></script>
<script src="./highCharts/code/modules/series-label.js"></script>
<script src="./highCharts/code/modules/exporting.js"></script>
<script src="./highCharts/code/modules/export-data.js"></script>
<script src="./highCharts/code/modules/accessibility.js"></script>
<div class="content-wrapper">
	<div class="content-header">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-body">
						<table style="margin-bottom:-10px;">
						<tr><td style="font-size:15PX;font-weight: bold;"><?php if ($this->_tpl_vars['companyDetail']['0']['companyName'] != ""): ?><?php echo $this->_tpl_vars['companyDetail']['0']['companyName']; ?>
<?php else: ?><?php echo $this->_supers['session']['CompanyName']; ?>
<?php endif; ?>&nbsp;&nbsp;</td>
						<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
						<td style="font-size:15PX;font-weight: bold;"><?php echo $this->_tpl_vars['branchDetail']['0']['branch_name']; ?>
&ensp;&ensp;</td>
						<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="font-size:15PX;font-weight: bold;"><?php echo $this->_tpl_vars['LoctList']['0']['sensorName']; ?>
</font>&nbsp;</td>
		<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="font-size:15PX;font-weight: bold;"><?php echo $this->_tpl_vars['LoctList']['0']['gateway_id']; ?>
 - <?php if ($this->_tpl_vars['LoctList']['0']['gateway_id'] == $this->_tpl_vars['gateList']['0']['gateway_code'] && $this->_tpl_vars['gateList']['0']['gateway_date_time'] >= ((is_array($_tmp=$this->_tpl_vars['dateSec'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d %H:%M:%S'))): ?> <a style="color: #00CC00;">ON</a> <?php else: ?> <a style="color: #FF0000;">OFF</a> <?php endif; ?></font>&nbsp;</td>
		
						</tr>
						
						
						<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
						<td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
						<td style="font-size:10PX;color:#999999;">Branch Name</td>
						<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="color:#999999;font-size:10PX;">Feeder Name (Place of Installation)</td>
		<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="color:#999999;font-size:10PX;">Gateway Name - Status</td>
						</tr>
						</table>
					</div>
				</div>
			</div>
		</div>
        
      <textarea id="mutiLinegraph" name="mutiLinegraph" style="display:none;"><?php echo $this->_tpl_vars['LineGraphData']; ?>
</textarea>
<textarea id="mutiLinegraph2" name="mutiLinegraph2" style="display:none;"><?php echo $this->_tpl_vars['LineGraphData2']; ?>
</textarea>
<textarea id="mutiLinedataProviderT" name="mutiLinedataProviderT" style="display:none;" ><?php echo $this->_tpl_vars['LineGraphDataT']; ?>
</textarea>
<textarea id="mutiLinedataProviderH" name="mutiLinedataProviderH" style="display:none;"><?php echo $this->_tpl_vars['LineGraphDataH']; ?>
</textarea>
  
        <div class="row">
        <div class="col-md-9">
		<?php if ($this->_tpl_vars['ExeDashGraph']['0']['TemHum'] == 'Temperature' || $this->_tpl_vars['ExeDashGraph']['0']['TemHum'] == 'Both'): ?>
        <div class="card card-primary card-outline">
						<div class="card-header">
						<h3 class="card-title">
						<i class="far fa-chart-bar"></i>
						Temperature Chart
						</h3>
						</div>                    
                  <div class="chart">
				  <figure class="highcharts-figure">
    <div id="container" ></div>
    <!--<p class="highcharts-description">
        This demo shows how plot bands can be used on an axis to
        highlight regions of a chart. In this example, the plot
        bands are used to separate the wind speeds on the Y-axis
        into categories.
    </p>-->
</figure>
							 
                             </div>
        </div>
        <?php endif; ?>
		<?php if ($this->_tpl_vars['ExeDashGraph']['0']['TemHum'] == 'Humidity' || $this->_tpl_vars['ExeDashGraph']['0']['TemHum'] == 'Both'): ?>
        <div class="card card-primary card-outline">
						<div class="card-header">
						<h3 class="card-title">
						<i class="far fa-chart-bar"></i>
						 Humidity Chart
						</h3>
						</div>                    
                  <div class="chart">
						 <figure class="highcharts-figure">
    <div id="container1" ></div>
    <!--<p class="highcharts-description">
        This demo shows how plot bands can be used on an axis to
        highlight regions of a chart. In this example, the plot
        bands are used to separate the wind speeds on the Y-axis
        into categories.
    </p>-->
</figure>
							</div>
							
							
        </div>
                <?php endif; ?>   
					</div>
					 <?php $_from = $this->_tpl_vars['TempSenList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['List']):
?>
            <tr id="<?php echo $this->_tpl_vars['j']++; ?>
">
          <div class="col-md-3">
            <!-- Box Comment -->
            <div class="card card-widget card-primary">
              <div class="card-header" style="margin-bottom:-15px;">
                <div class="card-title">
                  <center><span class="username"><b><a href="#"><?php echo $this->_tpl_vars['List']['sensorName']; ?>
</a></b></span></center>
                </div>
              </div>
              
              <div class="card-body">
                  
              <?php if ($this->_tpl_vars['List']['secs'] < '2100' && $this->_tpl_vars['List']['secs'] != ''): ?>
                <div class="row">
                    <?php if ($this->_tpl_vars['ExeDashGraph']['0']['TemHum'] == 'Both'): ?>
                  <div class="col-sm-6">
                    <div class="description-block">
                         <img class="img-circle elevation-2" src="./images/temperature.jpg" alt="User Image" width="70" height="70">
                      <h5 class="description-header" style="color:#15b5f0;padding-top:6px;"><b><?php echo $this->_tpl_vars['List']['temperature_c']; ?>
 &deg; C</b></h5>
                      <span class="description-text"></span>
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="description-block">
                        <img class="img-circle elevation-2" src="./images/humidity.jpg" alt="User Image" width="70" height="70">
                      <h5 class="description-header" style="color:#7db616;padding-top:6px;"><b><?php echo $this->_tpl_vars['List']['humidity']; ?>
 %</b></h5>
                      <span class="description-text"></span>
                    </div>
                  </div>
                  <?php endif; ?>
				  <?php if ($this->_tpl_vars['ExeDashGraph']['0']['TemHum'] == 'Temperature'): ?>
                  <div class="col-sm-12">
                    <div class="description-block">
                         <img class="img-circle elevation-2" src="./images/temperature.jpg" alt="User Image" width="70" height="70">
                      <h5 class="description-header" style="color:#15b5f0;padding-top:6px;"><b><?php echo $this->_tpl_vars['List']['temperature_c']; ?>
 &deg; C</b></h5>
                      <span class="description-text"></span>
                    </div>
                  </div>
                  <?php endif; ?>
				  <?php if ($this->_tpl_vars['ExeDashGraph']['0']['TemHum'] == 'Humidity'): ?>
                  <div class="col-sm-12">
                    <div class="description-block">
                        <img class="img-circle elevation-2" src="./images/humidity.jpg" alt="User Image" width="70" height="70">
                      <h5 class="description-header" style="color:#7db616;padding-top:6px;"><b><?php echo $this->_tpl_vars['List']['humidity']; ?>
 %</b></h5>
                      <span class="description-text"></span>
                    </div>
                  </div>
                  <?php endif; ?>
                </div>
				
               
                <center ><b><span class="text-muted" style="margin-bottom:-15px;margin-top:-5px;" id="<?php echo $this->_tpl_vars['j']; ?>
" ><script type="text/javascript">secondsToDhms('<?php echo $this->_tpl_vars['List']['secs']; ?>
','<?php echo $this->_tpl_vars['j']; ?>
');</script> ago</span></b></center>
				<?php else: ?>
				<div class="row overlay">
                    <?php if ($this->_tpl_vars['ExeDashGraph']['0']['TemHum'] == 'Both'): ?>
                  <div class="col-sm-6 overlay">
                    <div class="description-block">
                         <img class="img-circle elevation-2" src="./images/temperatureCrayScale.png" alt="User Image" width="70" height="70">
                      <h5 class="description-header" style="color:#15b5f0;padding-top:6px;"><b></b></h5>
                      <span class="description-text"></span>
                    </div>
                  </div>
                  <div class="col-sm-6 overlay">
                    <div class="description-block">
                        <img class="img-circle elevation-2" src="./images/humidityGrayScale.png" alt="User Image" width="70" height="70">
                      <h5 class="description-header" style="color:#7db616;padding-top:6px;"><b></b></h5>
                      <span class="description-text"></span>
                    </div>
                  </div>
                  <?php endif; ?>
				  <?php if ($this->_tpl_vars['ExeDashGraph']['0']['TemHum'] == 'Temperature'): ?>
                  <div class="col-sm-12 overlay">
                    <div class="description-block">
                         <img class="img-circle elevation-2" src="./images/temperatureCrayScale.png" alt="User Image" width="70" height="70">
                      <h5 class="description-header" style="color:#15b5f0;padding-top:6px;"><b></b></h5>
                      <span class="description-text"></span>
                    </div>
                  </div>
                  <?php endif; ?>
				  <?php if ($this->_tpl_vars['ExeDashGraph']['0']['TemHum'] == 'Humidity'): ?>
                  <div class="col-sm-12 overlay">
                    <div class="description-block">
                        <img class="img-circle elevation-2" src="./images/humidityGrayScale.png" alt="User Image" width="70" height="70">
                      <h5 class="description-header" style="color:#7db616;padding-top:6px;"><b></b></h5>
                      <span class="description-text"></span>
                    </div>
                  </div>
                  <?php endif; ?>
                </div>
				
               <br>
                <center ><b><span class="text-muted" style="margin-bottom:-15px;margin-top:-5px;" id="<?php echo $this->_tpl_vars['j']; ?>
" >Sensor Off Status</span></b></center>
				<?php endif; ?>
              </div>
              
              <div class="card-footer card-comments">
                  <div class="comment-text" ><span class="username" style="color:#15b5f0; margin-top:-5px;"><!--<b>Latest Incidents</b>--></span></div>
                <?php $_from = $this->_tpl_vars['incidentList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['ListIncidentLog']):
?>
				 
                     <div class="card-comment">
                  <div class="comment-text" style="margin:-5px;">
                    <span class="username">
                      <?php echo $this->_tpl_vars['ListIncidentLog']['sensor_code']; ?>

                      <span class="text-muted float-right"> <?php echo ((is_array($_tmp=$this->_tpl_vars['ListIncidentLog']['recorded_date_time'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%e-%b-%Y %I:%M %p") : smarty_modifier_date_format($_tmp, "%e-%b-%Y %I:%M %p")); ?>
</span>
                    </span>
                  <?php if ($this->_tpl_vars['ExeDashGraph']['0']['TemHum'] == 'Both'): ?>
                   T - <?php echo $this->_tpl_vars['ListIncidentLog']['temperature_c']; ?>
 &deg; C &nbsp;&nbsp;&nbsp;&nbsp;
                   H - <?php echo $this->_tpl_vars['ListIncidentLog']['humidity']; ?>
 %
				   <?php endif; ?>
				   <?php if ($this->_tpl_vars['ExeDashGraph']['0']['TemHum'] == 'Temperature'): ?>
                   T - <?php echo $this->_tpl_vars['ListIncidentLog']['temperature_c']; ?>
 &deg; C &nbsp;&nbsp;&nbsp;&nbsp;
 
				   <?php endif; ?>
				   <?php if ($this->_tpl_vars['ExeDashGraph']['0']['TemHum'] == 'Humidity'): ?>
                  H - <?php echo $this->_tpl_vars['ListIncidentLog']['humidity']; ?>
 % &nbsp;&nbsp;&nbsp;&nbsp;
                   
				   <?php endif; ?>
                  </div>
                </div>

<?php endforeach; endif; unset($_from); ?>
              </div>
              
              
             
            </div>
            <!-- /.card -->
          </div>
          </tr>
          <?php endforeach; endif; unset($_from); ?>
				
       
           
          <!-- /.col -->
        </div>
    <div class="row">
			<div class="col-md-12">
				<div class="card card-primary card-tabs">
					<div class="card-header p-0 pt-1 border-bottom-0">
						<ul class="nav nav-tabs" id="custom-content-below-tab" role="tablist">
							<!--<li class="nav-item">
							<a class="nav-link active" id="custom-content-below-home-tab" data-toggle="pill" href="#tab-2" role="tab" aria-controls="custom-content-below-home" aria-selected="true">Trend Graph</a>
							</li>-->
							<li class="nav-item">
							<a class="nav-link " id="custom-content-below-home-tab" data-toggle="pill" href="#tab-1" role="tab" aria-controls="custom-content-below-home" aria-selected="true">Log</a>
							</li>
						</ul>
					</div>
					<div class="tab-content">
						<!--<div id="tab-2" class="tab-pane active">
								<div class="card-body">
							<iframe height="620px" width="100%" id="tab-1"  src="./temperature_temperatureTrendGraph.php?gatewayCode=<?php echo $this->_supers['get']['gatewayCode']; ?>
&sensorCode=<?php echo $this->_supers['get']['sensorCode']; ?>
" style="border:1px;"></iframe>
								</div>
						</div>-->
						<div id="tab-1" class="tab-pane active">
								<div class="card-body">
							<iframe height="500px" width="100%" id="tab-1"  src="./temperature_tempMeterLog.php?gatewayCode=<?php echo $this->_supers['get']['gatewayCode']; ?>
&sensorCode=<?php echo $this->_supers['get']['sensorCode']; ?>
&companyId=<?php echo $this->_supers['get']['companyId']; ?>
&branchId=<?php echo $this->_supers['get']['branchId']; ?>
" style="border:1px;"></iframe>
								</div>
						</div>
					</div>
				</div>
			</div>
		</div>
    
    
    
	</div>
	</div>
	</div>
  <?php echo '
		<script type="text/javascript">
// Data retrieved from http://vikjavev.no/ver/index.php?spenn=2d&sluttid=16.06.2015.



	//alert(jsondataProvider);
//	alert(dataProvider);alert(Graphs);
//var ndat = '; ?>
<?php echo $this->_tpl_vars['LineGraphData']; ?>
<?php echo '; 
//alert(ndat);
//document.getElementById("rd").innerHTML=\'Date : \'+ndat;
/*var set_value=32;
var USL1=33;
var LSL1=31;
var USL2=34;
var LSL2=30;
var USL3=34.01;
var LSL3=30.01;*/
var minval=25;
var maxval=39;
var startVal=20;
var valData='; ?>
<?php echo $this->_tpl_vars['LineGraphData']; ?>
<?php echo ';
Highcharts.chart(\'container\', {
    chart: {
        type: \'spline\',
		 zoomType: \'x\',
        scrollablePlotArea: {
            minWidth: 600,
            scrollPositionX: 1
        }
    },
    title: {
        text: \'\',
        align: \'left\'
    },
    subtitle: {
        text: \'\',
        align: \'left\'
    },
    xAxis: {
        type: \'datetime\',
		lineWidth: 0,
   minorGridLineWidth: 0,
   lineColor: \'black\'
    },
    yAxis: {
	    min:20,max:60,
        title: {
            text: \'Temperature in °C\'
        },
        minorGridLineWidth: 0,
        gridLineWidth: 0,
        alternateGridColor: null,
        plotBands: [{ // Light air
            from: minval,
            to: maxval,
          //  color: \'rgba(68, 170, 213, 0.1)\',
		   color: \'#41FF4E\',
            label: {
                text: \'\',
                style: {
                  //  color: \'green\'
				  color: \'#41FF4E\'
                }
            }
        }, { // Light breeze
            from: 20,
            to:minval ,
            color: \'#7BAAFF\',
            label: {
                text: \'\',
                style: {
                    //color: \'Blue\'
					color: \'#7BAAFF\'
                }
            }
        }, { // Gentle breeze
            from: maxval,
            to: 65,
            color: \'#FF5353\',
            label: {
                text: \'\',
                style: {
				//color: \'red\'
                    color: \'#FF5353\'
                }
            }
        }]
    },
    tooltip: {
        valueSuffix: \' °C\'
    },xAxis: {
        categories: '; ?>
<?php echo $this->_tpl_vars['LineGraphDataDT']; ?>
<?php echo ' ,
lineColor: \'transparent\'
    },
    plotOptions: {
        series: {
            allowPointSelect: true
        }
    },
    series: [{
        name: \'Time\',
        data: valData,
		color:\'#1E282B\'

    }],
    navigation: {
        menuItemStyle: {
            fontSize: \'10px\'
        }
    }
});
		</script>
		<script type="text/javascript">
// Data retrieved from http://vikjavev.no/ver/index.php?spenn=2d&sluttid=16.06.2015.



	//alert(jsondataProvider);
//	alert(dataProvider);alert(Graphs);
//var ndat = '; ?>
<?php echo $this->_tpl_vars['LineGraphData']; ?>
<?php echo '; 
//alert(ndat);
//document.getElementById("rd").innerHTML=\'Date : \'+ndat;
/*var set_value=32;
var USL1=33;
var LSL1=31;
var USL2=34;
var LSL2=30;
var USL3=34.01;
var LSL3=30.01;*/
var startVal=0;
var minval=30;
var maxval=53;
var valData='; ?>
<?php echo $this->_tpl_vars['LineGraphDataH']; ?>
<?php echo ';
Highcharts.chart(\'container1\', {
    chart: {
        type: \'spline\',
		 zoomType: \'x\',
        scrollablePlotArea: {
            minWidth: 600,
            scrollPositionX: 1
        }
    },
    title: {
        text: \'\',
        align: \'left\'
    },
    subtitle: {
        text: \'\',
        align: \'left\'
    },
    xAxis: {
        type: \'datetime\',
		lineWidth: 0,
   minorGridLineWidth: 0,
   lineColor: \'black\'
    },
    yAxis: {
	    min:0,max:80,
        title: {
            text: \'Humidity in %\'
        },
        minorGridLineWidth: 0,
        gridLineWidth: 0,
        alternateGridColor: null,
        plotBands: [{ // Light air
            from: minval,
            to: maxval,
          //  color: \'rgba(68, 170, 213, 0.1)\',
		   color: \'#41FF4E\',
            label: {
                text: \'\',
                style: {
                   color: \'#41FF4E\'
				  //color: \'green\'
                }
            }
        }, { // Light breeze
            from: 0,
            to:minval ,
            color: \'#7BAAFF\',
            label: {
                text: \'\',
                style: {
                    //color: \'Blue\'
					  color: \'#7BAAFF\'
                }
            }
        }, { // Gentle breeze
            from: maxval,
            to: 80,
            color: \'#FF5353\',
            label: {
                text: \'\',
                style: {
                    //color: \'red\'
					 color: \'#FF5353\'
                }
            }
        }]
    },
    tooltip: {
        valueSuffix: \' %\'
    },xAxis: {
        categories: '; ?>
<?php echo $this->_tpl_vars['LineGraphDataDT']; ?>
<?php echo ' ,
lineColor: \'transparent\'
    },
    plotOptions: {
        series: {
            allowPointSelect: true
        }
    },
    series: [{
        name: \'Time\',
        data: valData,
        color:\'#1E282B\'
    }],
    navigation: {
        menuItemStyle: {
            fontSize: \'10px\'
        }
    }
});
		</script>
		<script type="text/javascript">
// Data retrieved from http://vikjavev.no/ver/index.php?spenn=2d&sluttid=16.06.2015.



	//alert(jsondataProvider);
//	alert(dataProvider);alert(Graphs);
//var ndat = '; ?>
<?php echo $this->_tpl_vars['LineGraphData']; ?>
<?php echo '; 
//alert(ndat);
//document.getElementById("rd").innerHTML=\'Date : \'+ndat;
var set_value=50;
var USL1=60;
var LSL1=45;
var USL2=70;
var LSL2=40;
var USL3=80;
var LSL3=35;
var valData='; ?>
<?php echo $this->_tpl_vars['LineGraphDataH']; ?>
<?php echo ';
Highcharts.chart(\'container11, {
    chart: {
        type: \'spline\',
		 zoomType: \'x\',
        scrollablePlotArea: {
            minWidth: 600,
            scrollPositionX: 1
        }
    },
    title: {
        text: \'\',
        align: \'left\'
    },
    subtitle: {
        text: \'\',
        align: \'left\'
    },
    xAxis: {
        type: \'datetime\',
		lineWidth: 0,
   minorGridLineWidth: 0,
   lineColor: \'transparent\'
    },
    yAxis: {
        title: {
            text: \'Humidity in %\'
        },
        minorGridLineWidth: 0,
        gridLineWidth: 0,
        alternateGridColor: null,
        plotBands: [{ // Light air
            from: set_value,
            to: USL1,
          //  color: \'rgba(68, 170, 213, 0.1)\',
		   color: \'#95fca4\',
            label: {
                text: \'\',
                style: {
                  //  color: \'#606060\'
				  color: \'green\'
                }
            }
        }, { // Light breeze
            from: set_value,
            to: LSL1,
            color: \'#95fca4\',
            label: {
                text: \'\',
                style: {
                    color: \'green\'
                }
            }
        }, { // Gentle breeze
            from: LSL1,
            to: LSL2,
            color: \'#e6e487\',
            label: {
                text: \'\',
                style: {
                    color: \'yellow\'
                }
            }
        }, { // Moderate breeze
             from: USL1,
            to: USL2,
            color: \'#e6e487\',
            label: {
                text: \'\',
                style: {
                    color: \'Yellow\'
                }
            }
        }, { // Fresh breeze
            from: LSL2,
            to: LSL3,
            color: \'#fa4d64\',
            label: {
                text: \'\',
                style: {
                    color: \'red\'
                }
            }
        }, { // Strong breeze
              from: USL2,
            to: USL3,
            color: \'#fa4d64\',
            label: {
                text: \'\',
                style: {
                    color: \'red\'
                }
            }
        }]
    },
    tooltip: {
        valueSuffix: \' %\'
    },xAxis: {
        categories: '; ?>
<?php echo $this->_tpl_vars['LineGraphDataDT']; ?>
<?php echo ' ,
lineColor: \'transparent\'
    },
    plotOptions: {
        series: {
            allowPointSelect: true
        }
    },
    series: [{
        name: \'Time\',
        data: valData

    }],
    navigation: {
        menuItemStyle: {
            fontSize: \'10px\'
        }
    }
});
		</script>
		'; ?>

	</body>
</html>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>