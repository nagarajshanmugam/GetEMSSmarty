<?php /* Smarty version 2.6.25, created on 2026-09-09 11:45:44
         compiled from branchAddEdit.tpl */ ?>
		<div class="content-wrapper">
			<section class="content-header">
			<div class="card">
				<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;"><?php if ($this->_tpl_vars['companyDetail']['0']['companyName'] != ""): ?><?php echo $this->_tpl_vars['companyDetail']['0']['companyName']; ?>
<?php else: ?><?php echo $this->_supers['session']['CompanyName']; ?>
<?php endif; ?>&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<?php if ($this->_supers['get']['sl_no'] != ""): ?><td style="font-size:15PX;font-weight: bold;"><?php echo $this->_tpl_vars['ListEditView']['0']['branch_name']; ?>
</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<?php endif; ?>
				<td style="font-size:15PX;font-weight: bold;"><?php if ($this->_supers['get']['sl_no'] == ""): ?>Create Branch<?php else: ?>Edit Branch<?php endif; ?>&nbsp;</td>
				</tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<?php if ($this->_supers['get']['sl_no'] != ""): ?>
				<td style="font-size:10PX;color:#999999;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<?php endif; ?>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
				<a href="branchList.php?companyId=<?php echo $this->_supers['get']['companyId']; ?>
"><button type="button" style="float:right; margin-top:-40PX;" class="btn btn-primary">List Branch</button></a>
				</div>
			</div>
			</section>
			<section class="content">
				<div class="card">
			
					<div class="card-body">
						<form role="form" name="locationRegForm" id="locationRegForm" method="post" onsubmit="return createValidation();" >
							<input type="hidden" name="hdAction" />
							<input type="hidden" id="check_id" name="check_id" value="<?php echo $this->_supers['post']['check_id']; ?>
">
							<input type="hidden" id="item_id" name="item_id" value="<?php echo $this->_supers['post']['item_id']; ?>
" />
							<input type="hidden" id="checkVal" name="checkVal" value="<?php echo $this->_supers['post']['checkVal']; ?>
" />
							<input type="hidden" id="checkValEbMeter" name="checkValEbMeter" value="<?php echo $this->_supers['post']['checkValEbMeter']; ?>
" />
							<input type="hidden" id="checkValDgMeter" name="checkValDgMeter" value="<?php echo $this->_supers['post']['checkValDgMeter']; ?>
" />
							<input type="hidden" id="checkValSolarMeter" name="checkValSolarMeter" value="<?php echo $this->_supers['post']['checkValSolarMeter']; ?>
" />
							<div class="row">
							<div class="form-group col-md-6">
								<label for="exampleInputlocationId">Branch Code <span style="color:red;">*</span></label>
								<input type="text" class="form-control form-control-sm" id="branchId" name="branchId"   maxlength="10" placeholder="Enter Branch Code" value="<?php if ($this->_tpl_vars['ListEditView']['0']['branch_id'] != ""): ?> <?php echo $this->_tpl_vars['ListEditView']['0']['branch_id']; ?>
<?php endif; ?>">
							</div>
							<div class="form-group col-md-6">
								<label for="exampleInputlocationName">Branch Name <span style="color:red;">*</span></label>
								<input type="text" class="form-control form-control-sm" id="branchName" name="branchName" placeholder="Enter Branch name" value="<?php if ($this->_tpl_vars['ListEditView']['0']['branch_name'] != ""): ?><?php echo $this->_tpl_vars['ListEditView']['0']['branch_name']; ?>
<?php endif; ?>">
							</div>
					<div class="form-group col-md-4">
						<div class="custom-control custom-checkbox">
						<?php if ($this->_tpl_vars['ListEditView']['0']['EB'] == '1'): ?>
						<input class="" type="checkbox" id="customCheckbox2" name="customCheckbox2" value="" checked="checked" tabindex="7">&nbsp;&nbsp;
						<label for="" class="">EB</label>
						<?php elseif ($this->_tpl_vars['ListEditView']['0']['EB'] == '0'): ?>
						<input class="" type="checkbox" id="customCheckbox2" name="customCheckbox2" value="" tabindex="7">&nbsp;&nbsp;
						<label for="" class="">EB</label>
						<?php else: ?>
						<input class="" type="checkbox" id="customCheckbox2" name="customCheckbox2" value="" tabindex="7">&nbsp;&nbsp;
						<label for="" class="">EB</label>
						<?php endif; ?>
						</div>
					</div>
					<div class="form-group col-md-4">
						<div class="custom-control custom-checkbox">
						<?php if ($this->_tpl_vars['ListEditView']['0']['DG'] == '1'): ?>
						<input class="" type="checkbox" id="customCheckbox3" name="customCheckbox3" value="" checked="checked" tabindex="7">&nbsp;&nbsp;
						<label for="" class="">DG</label>
						<?php elseif ($this->_tpl_vars['ListEditView']['0']['DG'] == '0'): ?>
						<input class="" type="checkbox" id="customCheckbox3" name="customCheckbox3" value="" tabindex="7">&nbsp;&nbsp;
						<label for="" class="">DG</label>
						<?php else: ?>
						<input class="" type="checkbox" id="customCheckbox3" name="customCheckbox3" value="" tabindex="7">&nbsp;&nbsp;
						<label for="" class="">DG</label>
						<?php endif; ?>
						</div>
					</div>
					<div class="form-group col-md-4">
						<div class="custom-control custom-checkbox">
						<?php if ($this->_tpl_vars['ListEditView']['0']['Solar'] == '1'): ?>
						<input class="" type="checkbox" id="customCheckbox4" name="customCheckbox4" value="" checked="checked" tabindex="7">&nbsp;&nbsp;
						<label for="" class="">Solar</label>
						<?php elseif ($this->_tpl_vars['ListEditView']['0']['Solar'] == '0'): ?>
						<input class="" type="checkbox" id="customCheckbox4" name="customCheckbox4" value="" tabindex="7">&nbsp;&nbsp;
						<label for="" class="">Solar</label>
						<?php else: ?>
						<input class="" type="checkbox" id="customCheckbox4" name="customCheckbox4" value="" tabindex="7">&nbsp;&nbsp;
						<label for="" class="">Solar</label>
						<?php endif; ?>
						</div>
					</div>
							<div class="form-group col-md-6">
								<div class="custom-control custom-checkbox">
								<?php if ($this->_tpl_vars['ListEditView']['0']['is_active'] == '1'): ?>
									<input class="custom-control-input" type="checkbox" id="customCheckbox"  name="customCheckbox" tabindex="4" checked="checked">
									<label for="customCheckbox" class="custom-control-label">Is Active</label>
								<?php elseif ($this->_tpl_vars['ListEditView']['0']['is_active'] == '0'): ?>
									<input class="custom-control-input" type="checkbox" id="customCheckbox" name="customCheckbox" tabindex="4">
									<label for="customCheckbox" class="custom-control-label">Is Active</label>
								<?php else: ?>
									<input class="custom-control-input" type="checkbox" id="customCheckbox" name="customCheckbox" tabindex="4" checked="checked">
									<label for="customCheckbox" class="custom-control-label">Is Active</label>
								<?php endif; ?>
								</div>
								<input id="created_by" name="created_by" class="date-picker form-control" type="hidden" value="<?php echo $this->_supers['session']['UserName']; ?>
" readonly="true">
							
							</div>
							</div>
							<div  align="center">
							<input type="submit" value="Submit" class="btn btn-create" />
							</div>
						</form>
					</div>
				
				</div>
			</div>		
		</section>
	</div>
	<?php echo '
	<script type="text/javascript">
	function createValidation(){
	var branchId = $(\'#branchId\').val();
	var branchName = $(\'#branchName\').val();
	var isActive = document.getElementById("customCheckbox").checked;
	
	if (isActive == false) 
	{
	document.getElementById(\'checkVal\').value=\'0\';
	}
	else
	{
	document.getElementById(\'checkVal\').value=\'1\';
	}
	
	var eb = document.getElementById("customCheckbox2").checked;
	var dg = document.getElementById("customCheckbox3").checked;
	var solar = document.getElementById("customCheckbox4").checked;
		/*var bar_code = [];
	$.each($("input[name=\'customCheckbox2\']:checked"), function()
	{ 
		bar_code.push($(this).val());  
	});
		id=bar_code.join("\',\'");
		document.getElementById("item_id").value = id;*/
	if (eb == false) 
	{
		document.getElementById(\'checkValEbMeter\').value=\'0\';
	}
	else
	{
		document.getElementById(\'checkValEbMeter\').value=\'1\';
	}
	if (dg == false) 
	{
		document.getElementById(\'checkValDgMeter\').value=\'0\';
	}
	else
	{
		document.getElementById(\'checkValDgMeter\').value=\'1\';
	}
	if (solar == false) 
	{
		document.getElementById(\'checkValSolarMeter\').value=\'0\';
	}
	else
	{
		document.getElementById(\'checkValSolarMeter\').value=\'1\';
	}
	$(".error").remove();
	if(branchId.length < 1) {
	$(\'#branchId\').after(\'<span class="error">This field is required</span>\');
	$(\'#branchId\').focus();
	return false;					
	}
	else if(branchName.length < 1 && branchId.length > 1) {
	
	$(\'#branchName\').after(\'<span class="error">This field is required</span>\');
	$(\'#branchName\').focus();
	return false;
	
	}	
	FormName		= document.locationRegForm;
	FormName.method	= "POST";
	FormName.submit();
	}
	function GoBack()
	{
	window.history.back();
	}
	</script>
<!--	<script>
	function CheckDuplicateLocName()
	{
	var locationId = $("#locationId").val();
	$.ajax({
	type: "POST",
	url: "AjaxLocationCode.php",
	data: {locationId:locationId},
	dataType:"TEXT",
	cache: false,
	
	success: function(result){
	var obj = JSON.parse(result);
	var feild= $("#locationId").val();
	if(obj[0].location_id = feild ){
	document.getElementById("locationId").value =\'\';
	alert(\'Your enter data already exist ...\');
	createValidation();
	return false;	
	}
	},
	error: function(result) {
	alert(\'error\');
	}
	});
	} 
	</script>-->
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	'; ?>

	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>