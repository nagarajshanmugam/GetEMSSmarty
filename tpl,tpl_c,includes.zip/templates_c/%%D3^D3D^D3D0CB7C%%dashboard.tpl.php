<?php /* Smarty version 2.6.25, created on 2026-07-08 17:21:00
         compiled from dashboard.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'base64_encode', 'dashboard.tpl', 47, false),array('modifier', 'replace', 'dashboard.tpl', 413, false),array('modifier', 'explode', 'dashboard.tpl', 416, false),array('modifier', 'date_format', 'dashboard.tpl', 420, false),array('modifier', 'escape', 'dashboard.tpl', 425, false),)), $this); ?>
<?php echo '
<script type="text/javascript">
     function secondsToDhms(seconds,v) {//alert(seconds);
var seconds = Number(seconds);
var d = Math.floor(seconds / (3600*24));
var h = Math.floor(seconds % (3600*24) / 3600);
var m = Math.floor(seconds % 3600 / 60);
var s = Math.floor(seconds % 60);

var dDisplay = d > 0 ? d + (d == 1 ? " day, " : " days, ") : "";
var hDisplay = h > 0 ? h + (h == 1 ? " hr, " : " hrs, ") : "";
var mDisplay = m > 0 ? m + (m == 1 ? " min, " : " min\'s, ") : "";
var sDisplay = s > 0 ? s + (s == 1 ? " sec" : " sec\'s") : "";
var res=  dDisplay + hDisplay + mDisplay + sDisplay;
document.getElementById(v).innerHTML=res;
}
 </script>'; ?>

<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<body onLoad="doOnLoad();">
<div class="content-wrapper">
    <div class="content-header">

      <div class="container-fluid">
            <div class="row"> 
				<div class="col-md-12">
					<div class="card">
						<div class="card-body">
						  <table style="margin-bottom:-10px;">
						  <tr><td style="font-size:15PX;font-weight: bold;"><?php echo $this->_tpl_vars['companyDetail']['0']['companyName']; ?>
&nbsp;&nbsp;</td>
						  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
						  <td style="font-size:15PX;font-weight: bold;"><?php echo $this->_tpl_vars['branchDetail']['0']['branch_name']; ?>
&ensp;&ensp;</td>
						  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
						  <td style="font-size:15PX;font-weight: bold;">Energy Meter</font>&nbsp;</td></tr>
						  <tr><td style="font-size:10PX;color:#999999;">Company Name</td>
						  <td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
						  <td style="font-size:10PX;color:#999999;">Branch Name</td>
						  <td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
						  <td style="color:#999999;font-size:10PX;">Dashboard</td><td>&nbsp;</td>
						  </tr>
						  </table>
						</div>
					</div>
				</div>
          </div>
    
        <?php if ($this->_tpl_vars['branchDetail']['0']['EB'] == '1'): ?>
		<!--<a href="meterDashboard.php?companyId=<?php echo ((is_array($_tmp=$this->_tpl_vars['overallmainmeter']['0']['company_id'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
&branchId=<?php echo ((is_array($_tmp=$this->_tpl_vars['overallmainmeter']['0']['branch_id'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
&sensorCode=<?php echo ((is_array($_tmp=$this->_tpl_vars['overallmainmeter']['0']['sensorCode'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
&gatewayCode=<?php echo ((is_array($_tmp=$this->_tpl_vars['overallmainmeter']['0']['gateway_id'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
" style="text-decoration:none;color:#000000;" title="Click to view Overall Main Meter Details" >-->
        <div class="row ">
	<!--------  EB Data Starts      ------>
	<div class="card card-widget card-outline card-primary widget-user-2 col-md-12 ">
								
									<div class="card-header">
									<h5 class="" style="text-align:left"><b>EB Data</b></h5>
									
								</div>
							<br />	
		<div class="row  ">
		<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-info elevation-1"><i class="fa fa-bolt"></i></span>
			<div class="info-box-content">
			<div class="row">
			<span class="info-box-text" >T KWH&ensp;
      </span>
      <span>
      <b id="tckw"><script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['TodayDashGridEnergy']['0']['total_energy']; ?>
','tckw');</script>
      </b>
      </span>
      </div>
			<span class="info-box-text">
			Y KWH&ensp;&ensp;&ensp;&ensp; <b id="yckw"><script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['YesterdayDashGridEnergy']['0']['yesterday_total_energy']; ?>
','yckw');</script></b>
			</span>
			</div>
			</div>
		</div>
		<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box">
			<span class="info-box-icon bg-info elevation-1"><b>&#8377;</b></span>
			<div class="info-box-content">
			<span class="info-box-text">T Cost&ensp;&ensp;&ensp;&ensp;<b id="tc"><script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['TodayDashGridEnergy']['0']['total_cost']; ?>
','tc');</script></b></span>
			<span class="info-box-text">

			Y Cost&ensp;&ensp;&ensp;&ensp; <b id="yc"><script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['YesterdayDashGridEnergy']['0']['yesterday_total_cost']; ?>
','yc');</script></b>
			<small></small>
			</span>
			</div>
			</div>
		</div>
		
	<!-- fix for small devices only -->
	       <div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-info elevation-1"><i class="fa fa-bolt"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">This Month KWH</span>
			<span class="info-box-number" id="mck">
			<script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['ThisMonthDashGridEnergy']['0']['total_energy']; ?>
','mck');</script>
			</span>
			</div>
			</div>
			</div>
			<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-info elevation-1"><b>&#8377;</b></span>
			<div class="info-box-content">
			<span class="info-box-text"> This Month Cost</span>
			<span class="info-box-number" id="mc">
			<script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['ThisMonthDashGridEnergy']['0']['total_cost']; ?>
','mc');</script>
			</span>
			</div>
			</div>
			</div>
			<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-info elevation-1"><i class="fa fa-bolt"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">Last Month KWH</span>
			<span class="info-box-number" id="lmk">
			<script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['LastMonthDashGridEnergy']['0']['total_energy']; ?>
','lmk');</script>
			</span>
			</div>
			</div>
			</div>
			<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-info elevation-1"><b>&#8377;</b></span>
			<div class="info-box-content">
			<span class="info-box-text">Last Month Cost</span>
			<span class="info-box-number" id="lckw">
			<script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['LastMonthDashGridEnergy']['0']['total_cost']; ?>
','lckw');</script>
			</span>
			</div>
			</div>
			</div>
		</div></div>
	</div>
	<!--</a>-->
	<?php endif; ?>
	<!--------  EB Data Ends      ------>
	<div></div>
	<!--------  DG Data Starts      ------>
	<?php if ($this->_tpl_vars['branchDetail']['0']['DG'] == '1'): ?>
	<div class="row">
	<div class="card card-widget card-outline card-danger widget-user-2 col-md-12 ">
								
									<div class="card-header">
									<h5 class="" style="text-align:left"><b>DG Data  </b></h5>
									
								</div>
							<br />	
		<div class="row">
		<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-danger elevation-1"><i class="fa fa-bolt"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">Today KWH&ensp;&ensp;&ensp;&ensp;</span>
			<span class="info-box-number" id="tkDG">
			<script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['TodayDashDGEnergy']['0']['dg_energy']; ?>
','tkDG');</script>
			</span>
			</div>
			</div>
		</div>
		<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box">
			<span class="info-box-icon bg-danger elevation-1"><i class="fa fa-rupee"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">Today Cost&ensp;&ensp;&ensp;&ensp;</span>
			<span class="info-box-number" id="tkDGc">
			<script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['TodayDashDGEnergy']['0']['total_dg_cost']; ?>
','tkDGc');</script>
			<small></small>
			</span>
			</div>
			</div>
		</div>
		
	<!-- fix for small devices only -->
	        <div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-danger elevation-1"><i class="fa fa-bolt"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">This Month KWH</span>
			<span class="info-box-number" id="ckDG">
			<script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['ThisMonthDashDGEnergy']['0']['dg_energy']; ?>
','ckDG');</script>
			</span>
			</div>
			</div>
			</div>
			<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-danger elevation-1"><i class="fa fa-rupee"></i></span>
			<div class="info-box-content">
			<span class="info-box-text"> This Month Cost</span>
			<span class="info-box-number" id="cckDG">
			<script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['ThisMonthDashDGEnergy']['0']['total_dg_cost']; ?>
','cckDG');</script>
			</span>
			</div>
			</div>
			</div>
			<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-danger elevation-1"><i class="fa fa-bolt"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">Last Month KWH</span>
			<span class="info-box-number" id="lkDG">
			<script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['LastMonthDashDGEnergy']['0']['dg_energy']; ?>
','lkDG');</script>
			</span>
			</div>
			</div>
			</div>
			<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-danger elevation-1"><i class="fa fa-rupee"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">Last Month Cost</span>
			<span class="info-box-number" id="lckDG">
			<script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['LastMonthDashDGEnergy']['0']['total_dg_cost']; ?>
','lckDG');</script>
			</span>
			</div>
			</div>
			</div>
		</div></div>
	</div>
	<?php endif; ?>
	<!--------  DG Data Ends      ------>
	<!--------  Solar Data Starts      ------>
	<?php if ($this->_tpl_vars['branchDetail']['0']['solarInverter'] == '1'): ?>
	<div class="row">
	<div class="card card-widget card-outline card-warning widget-user-2 col-md-12 ">
								
									<div class="card-header">
									<h5 class="" style="text-align:left"><b>Solar Data  </b></h5>
									
								</div>
							<br />	
		<div class="row">
		<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-warning elevation-1"><i class="fa fa-bolt"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">Today KWH&ensp;&ensp;&ensp;&ensp;</span>
			<span class="info-box-number" id="tk">
			<script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['TodayDashSolarEnergy']['0']['total_solar_energy']; ?>
','tk');</script>
			</span>
			</div>
			</div>
		</div>
		<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box">
			<span class="info-box-icon bg-warning elevation-1"><i class="fa fa-rupee"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">Today Cost&ensp;&ensp;&ensp;&ensp;</span>
			<span class="info-box-number" id="tkc">
			<script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['TodayDashSolarEnergy']['0']['total_solar_cost']; ?>
','tkc');</script>
			<small></small>
			</span>
			</div>
			</div>
		</div>
		
	<!-- fix for small devices only -->
	        <div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-warning elevation-1"><i class="fa fa-bolt"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">This Month KWH</span>
			<span class="info-box-number" id="ck">
			<script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['ThisMonthDashSolarEnergy']['0']['total_solar_energy']; ?>
','ck');</script>
			</span>
			</div>
			</div>
			</div>
			<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-warning elevation-1"><i class="fa fa-rupee"></i></span>
			<div class="info-box-content">
			<span class="info-box-text"> This Month Cost</span>
			<span class="info-box-number" id="cck">
			<script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['ThisMonthDashSolarEnergy']['0']['total_solar_cost']; ?>
','cck');</script>
			</span>
			</div>
			</div>
			</div>
		<div class="col-12 col-sm-6 col-md-2">
		<div class="info-box mb-2">
		<span class="info-box-icon bg-warning elevation-1"><i class="fa fa-bolt"></i></span>
		<div class="info-box-content">
		<span class="info-box-text">Last Month KWH</span>
		<span class="info-box-number" id="lk">
		<script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['LastMonthDashSolarEnergy']['0']['total_solar_energy']; ?>
','lk');</script>
		</span>
		</div>
		</div>
		</div>
		<div class="col-12 col-sm-6 col-md-2">
		<div class="info-box mb-2">
		<span class="info-box-icon bg-warning elevation-1"><i class="fa fa-rupee"></i></span>
		<div class="info-box-content">
		<span class="info-box-text">Last Month Cost</span>
		<span class="info-box-number" id="lck">
		<script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['LastMonthDashSolarEnergy']['0']['total_solar_cost']; ?>
','lck');</script>
		</span>
		</div>
		</div>
		</div>
		</div></div>
	</div>
	<?php endif; ?>
	<!--------  Solar Data End      ------>
	</div>
        
        <textarea id="thisMonthPieData" name="thisMonthPieData" style="display:none;"><?php echo $this->_tpl_vars['getCurMonQut1Dash']; ?>
</textarea>
        <textarea id="lastMonthPieData" name="lastMonthPieData"  style="display:none;"><?php echo $this->_tpl_vars['getLastMonQut2Dash']; ?>
</textarea>
        <!--<textarea id="currMonQut3" name="currMonQut3"  style="display:none;"><?php echo $this->_tpl_vars['getCurMonQut3']; ?>
</textarea>--->
         <div class="row">
		 <div class="col-md-6">
     <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">This month - Kwh</h3>
              </div>
              <div class="card-body">
                <canvas id="pieChart1" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
              </div>
            </div>
            </div>
             <div class="col-md-6">
     <div class="card card-warning">
              <div class="card-header">
                <h3 class="card-title">This month - Cost</h3>
              </div>
              <div class="card-body">
                <canvas id="pieChart4" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
              </div>
            </div>
            </div>
            
             
            <div class="col-md-6">
     <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Last month - Kwh</h3>
              </div>
              <div class="card-body">
                <canvas id="pieChart2" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
              </div>
            </div>
            </div>
            <div class="col-md-6">
     <div class="card card-warning">
              <div class="card-header">
                <h3 class="card-title">Last month - Cost</h3>
              </div>
              <div class="card-body">
                <canvas id="pieChart3" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
              </div>
            </div>
            </div>         
            </div>
        <textarea id="currMonQutDaily" name="currMonQutDaily"  style="display:none;"><?php echo $this->_tpl_vars['getCurMonSalDailyDash']; ?>
</textarea>
        <div class="row">
				<div class="col-md-12">
			
					<div class="card card-primary card-outline">
						<div class="card-header">
						<h3 class="card-title">
						<i class="far fa-chart-bar"></i>
						Daily Cost Chart
						</h3>
						</div>
                        
					<!--<div id="linechartdiv" style="height: 260px;"></div><br />-->
                    
                    <div class="chart">
        <canvas id="DailybarChart2" style="height: 278px;" ></canvas>
        </div>
                    
					</div>
				</div>
			
			
			</div>
        <textarea id="currMonQut" name="currMonQut"  style="display:none;"><?php echo $this->_tpl_vars['getCurMonQutDash']; ?>
</textarea>
		
        <div class="row">
				<div class="col-md-8">
			
					<div class="card card-primary card-outline">
						<div class="card-header">
						<h3 class="card-title">
						<i class="far fa-chart-bar"></i>
						Monthly Cost Chart
						</h3>
						</div>
                        
					<!--<div id="linechartdiv" style="height: 260px;"></div><br />-->
                    
                    <div class="chart">
        <canvas id="barChart2" style="height: 340px;" ></canvas>
        </div>
                    
					</div>
				</div>
			
			
			
			<div class="col-md-4">
			<div class="card card-primary card-outline">
			<div class="card-header">
			<h3 class="card-title">Recent Incidents</h3>
			</div>
			<div class="card-body p-0">
			<ul class="products-list product-list-in-card pl-2 pr-2">
			<?php $_from = $this->_tpl_vars['incidentList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['ListIncidentLog']):
?>
			<?php $this->assign('alertMsg0', ((is_array($_tmp=$this->_tpl_vars['ListIncidentLog']['alert_message'])) ? $this->_run_mod_handler('replace', true, $_tmp, 'Hi!', '') : smarty_modifier_replace($_tmp, 'Hi!', ''))); ?>
			<?php $this->assign('alertMsg1', ((is_array($_tmp=$this->_tpl_vars['alertMsg0'])) ? $this->_run_mod_handler('replace', true, $_tmp, 'Best regards,', '') : smarty_modifier_replace($_tmp, 'Best regards,', ''))); ?>
			<?php $this->assign('alertMsg', ((is_array($_tmp=$this->_tpl_vars['alertMsg1'])) ? $this->_run_mod_handler('replace', true, $_tmp, 'Arka Automaations Limited.', '') : smarty_modifier_replace($_tmp, 'Arka Automaations Limited.', ''))); ?>
			<?php $this->assign('alertBreak', ((is_array($_tmp=",")) ? $this->_run_mod_handler('explode', true, $_tmp, $this->_tpl_vars['alertMsg']) : explode($_tmp, $this->_tpl_vars['alertMsg']))); ?>
			<?php $this->assign('l', 0); ?>
			<li class="item">
			<div class="product-img">
			<a href="javascript:void(0)" class="product-title"><?php echo $this->_tpl_vars['ListIncidentLog']['sensorName']; ?>
 <br>- ( <?php echo ((is_array($_tmp=$this->_tpl_vars['ListIncidentLog']['recorded_date_time'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%e-%b-%Y %I:%M %p") : smarty_modifier_date_format($_tmp, "%e-%b-%Y %I:%M %p")); ?>
 )</a>
			<?php if ($this->_tpl_vars['ListIncidentLog']['alert_status'] == 'Low'): ?><span class="badge badge-warning float-right"><?php elseif ($this->_tpl_vars['ListIncidentLog']['alert_status'] == 'Normal'): ?><span class="badge badge-info float-right"><?php elseif ($this->_tpl_vars['ListIncidentLog']['alert_status'] == 'High'): ?><span class="badge badge-danger float-right"><?php endif; ?><?php echo $this->_tpl_vars['ListIncidentLog']['alert_status']; ?>
</span>
			<span class="product-description" style="font-size:12px">
			<?php unset($this->_sections['i']);
$this->_sections['i']['name'] = 'i';
$this->_sections['i']['loop'] = is_array($_loop=$this->_tpl_vars['alertBreak']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['i']['show'] = true;
$this->_sections['i']['max'] = $this->_sections['i']['loop'];
$this->_sections['i']['step'] = 1;
$this->_sections['i']['start'] = $this->_sections['i']['step'] > 0 ? 0 : $this->_sections['i']['loop']-1;
if ($this->_sections['i']['show']) {
    $this->_sections['i']['total'] = $this->_sections['i']['loop'];
    if ($this->_sections['i']['total'] == 0)
        $this->_sections['i']['show'] = false;
} else
    $this->_sections['i']['total'] = 0;
if ($this->_sections['i']['show']):

            for ($this->_sections['i']['index'] = $this->_sections['i']['start'], $this->_sections['i']['iteration'] = 1;
                 $this->_sections['i']['iteration'] <= $this->_sections['i']['total'];
                 $this->_sections['i']['index'] += $this->_sections['i']['step'], $this->_sections['i']['iteration']++):
$this->_sections['i']['rownum'] = $this->_sections['i']['iteration'];
$this->_sections['i']['index_prev'] = $this->_sections['i']['index'] - $this->_sections['i']['step'];
$this->_sections['i']['index_next'] = $this->_sections['i']['index'] + $this->_sections['i']['step'];
$this->_sections['i']['first']      = ($this->_sections['i']['iteration'] == 1);
$this->_sections['i']['last']       = ($this->_sections['i']['iteration'] == $this->_sections['i']['total']);
?>
			<?php $this->assign('l', $this->_tpl_vars['l']+1); ?>
			<?php echo ((is_array($_tmp=$this->_tpl_vars['alertBreak'][$this->_sections['i']['index']])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
,<?php if ($this->_tpl_vars['l'] == '1'): ?><br /><?php endif; ?>
			<?php endfor; endif; ?>
			</span>
			</div>
			</li>
			<?php endforeach; endif; unset($_from); ?>
			</ul>
			</div>
			<div class="card-footer text-center">
			<a href="listIncidentLog.php" class="uppercase">View All Incidents</a>
			</div>
			</div>
			</div>
			</div>
        
        
            <div class="row">
			<div class="col-md-10">
            <div class="card card-outline card-primary">
            <div class="card-header">
						<h3 class="card-title">
						<i class="fa fa-list"></i>
						&nbsp;&nbsp;List of Energy Meter
						</h3>
						
						</div>
               <div class="card-body table-responsive no-padding">
			 <div class="row">
<input type="hidden" id="cid" name="cid" value="<?php if ($this->_supers['get']['companyId'] != ""): ?><?php echo $this->_supers['get']['companyId']; ?>
<?php else: ?><?php echo $this->_supers['session']['customerId']; ?>
<?php endif; ?>" />
				<input type="hidden" id="bid" name="bid" value="<?php echo $this->_supers['get']['branchId']; ?>
" />
				<input type="hidden" value="<?php echo $this->_tpl_vars['Dashboard']['0']['segmentName']; ?>
" />
    <div id="list_books" class="col-12">
			  <table id="example" class="table table-bordered table-hover">
                <thead>
                <tr>
    			  <th class="slNo" rowspan="3" >#</th>
                  <th class="name" rowspan="3">Place Of Installation </th>
                  <th class="gate" rowspan="3">Gateway</th>
				 <!--  <th class="status" rowspan="3">Status</th>-->
				 <?php if ($this->_tpl_vars['branchDetail']['0']['EB'] == '1' && $this->_tpl_vars['branchDetail']['0']['DG'] == '1' && $this->_tpl_vars['branchDetail']['0']['solarInverter'] == '1'): ?>
                  <th colspan="6" class="code" >Today</th>
				  <?php elseif ($this->_tpl_vars['branchDetail']['0']['EB'] == '1' && $this->_tpl_vars['branchDetail']['0']['DG'] == '1' && $this->_tpl_vars['branchDetail']['0']['solarInverter'] == '0'): ?>
				  <th colspan="4" class="code" >Today</th>
				  <?php elseif ($this->_tpl_vars['branchDetail']['0']['EB'] == '1' && $this->_tpl_vars['branchDetail']['0']['DG'] == '0' && $this->_tpl_vars['branchDetail']['0']['solarInverter'] == '1'): ?>
				  <th colspan="4" class="code" >Today</th>
				  <?php elseif ($this->_tpl_vars['branchDetail']['0']['EB'] == '1' && $this->_tpl_vars['branchDetail']['0']['DG'] == '0' && $this->_tpl_vars['branchDetail']['0']['solarInverter'] == '0'): ?>
				  <th colspan="2" class="code" >Today</th>
				  <?php elseif ($this->_tpl_vars['branchDetail']['0']['EB'] == '0' && $this->_tpl_vars['branchDetail']['0']['DG'] == '1' && $this->_tpl_vars['branchDetail']['0']['solarInverter'] == '1'): ?>
				  <th colspan="4" class="code" >Today</th>
				  <?php elseif ($this->_tpl_vars['branchDetail']['0']['EB'] == '0' && $this->_tpl_vars['branchDetail']['0']['DG'] == '1' && $this->_tpl_vars['branchDetail']['0']['solarInverter'] == '0'): ?>
				   <th colspan="2" class="code" >Today</th>
				  <?php elseif ($this->_tpl_vars['branchDetail']['0']['EB'] == '0' && $this->_tpl_vars['branchDetail']['0']['DG'] == '0' && $this->_tpl_vars['branchDetail']['0']['solarInverter'] == '1'): ?>
				   <th colspan="2" class="code" >Today</th>
				  <?php else: ?>
				  <!-- <th colspan="6" class="code" >Today</th>-->
				   <?php endif; ?>
                  <th class="action" rowspan="3">Date Time</th>
                  <th class="last" rowspan="3">Last Comm</th>
                  
          
                </tr>
                <tr>
				<?php if ($this->_tpl_vars['branchDetail']['0']['EB'] == '1'): ?>
                    <th class="cost" colspan="2">EB</th>
				<?php endif; ?>
                  <?php if ($this->_tpl_vars['branchDetail']['0']['DG'] == '1'): ?>
                    <th class="cost" colspan="2">DG</th>
				<?php endif; ?>
				<?php if ($this->_tpl_vars['branchDetail']['0']['solarInverter'] == '1'): ?>
                    <th class="cost" colspan="2">Solar</th>
				<?php endif; ?>
                </tr>
                <tr>
    			 <?php if ($this->_tpl_vars['branchDetail']['0']['EB'] == '1'): ?>
                  <th class="cost" >KWH</th>
                  <th class="cost" >Cost</th>
				  <?php endif; ?>
				  <?php if ($this->_tpl_vars['branchDetail']['0']['DG'] == '1'): ?>
                   <th class="cost" >KWH</th>
                  <th class="cost" >Cost</th>
				  <?php endif; ?>
				  <?php if ($this->_tpl_vars['branchDetail']['0']['solarInverter'] == '1'): ?>
				  <th class="cost" >KWH</th>
                  <th class="cost" >Cost</th>
				  <?php endif; ?>
               
                 
                  
                </tr>
                </thead>
                <tbody>
                    
				<?php $_from = $this->_tpl_vars['MeterListDash']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['List']):
?>
                <?php $this->assign('pid', ((is_array($_tmp=$this->_tpl_vars['List']['slNo'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp))); ?>
                <?php $this->assign('subMetL', 'No'); ?>
                <tr id="<?php echo $this->_tpl_vars['j']++; ?>
">
				 <td ><?php echo $this->_tpl_vars['j']; ?>
</td>
				 	
                 
                     <td><a href="meterDashboard.php?companyId=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['company_id'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
&branchId=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['branch_id'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
&sensorCode=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['sensor_code'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
&gatewayCode=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['gateway_code'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
" style="text-decoration:underline;color:#000000;" title="Meter Details" ><?php echo $this->_tpl_vars['List']['feeder_name']; ?>
</a><?php $_from = $this->_tpl_vars['selQryS']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['sub']):
?><?php if ($this->_tpl_vars['List']['feeder_type'] == 'Main Meter' && $this->_tpl_vars['List']['slNo'] == $this->_tpl_vars['sub']['parent_id'] && $this->_tpl_vars['subMetL'] == 'No'): ?>&ensp;&ensp;<a href="subdashboard.php?parent_id=<?php echo $this->_tpl_vars['pid']; ?>
&companyId=<?php echo $this->_supers['get']['companyId']; ?>
&branchId=<?php echo $this->_supers['get']['branchId']; ?>
"><i class="fa fa-sitemap" aria-hidden="true" title="Submeter List"></i></a><?php $this->assign('subMetL', 'Yes'); ?><?php endif; ?><?php endforeach; endif; unset($_from); ?></td>
                 
                 <td ><?php echo $this->_tpl_vars['List']['place_of_installation']; ?>
</td>
				 
				 
		
			<!--	<td>
			
			
				<?php if ($this->_tpl_vars['List']['gateway_code'] != "YMN-1" && $this->_tpl_vars['List']['gateway_code'] == $this->_tpl_vars['List']['gateway_code'] && $this->_tpl_vars['List']['gateway_date_time'] >= ((is_array($_tmp=$this->_tpl_vars['dateSec'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d %H:%M:%S'))): ?>
                
                <img  src="./images/on.png">
                 <?php $this->assign('tog', '1'); ?>
                <?php elseif ($this->_tpl_vars['List']['gateway_code'] != "YMN-1" && $this->_tpl_vars['List']['gateway_code'] == $this->_tpl_vars['List']['gateway_code'] && $this->_tpl_vars['List']['gateway_date_time'] < ((is_array($_tmp=$this->_tpl_vars['dateSec'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d %H:%M:%S'))): ?>
                
                <img  src="./images/off.png">
                 <?php $this->assign('tog', '1'); ?>
                <?php endif; ?>
                
                
                <?php if ($this->_tpl_vars['List']['gateway_code'] == "YMN-1" && $this->_tpl_vars['List']['gateway_code'] == $this->_tpl_vars['List']['gateway_code'] && $this->_tpl_vars['List']['gateway_date_time'] >= ((is_array($_tmp=$this->_tpl_vars['dateSec1'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d %H:%M:%S'))): ?>
                
                <img  src="./images/on.png">
                 <?php $this->assign('tog', '1'); ?>
                <?php elseif ($this->_tpl_vars['List']['gateway_code'] == "YMN-1" && $this->_tpl_vars['List']['gateway_code'] == $this->_tpl_vars['List']['gateway_code'] && $this->_tpl_vars['List']['gateway_date_time'] < ((is_array($_tmp=$this->_tpl_vars['dateSec1'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d %H:%M:%S'))): ?>
                
                <img  src="./images/off.png">
                 <?php $this->assign('tog', '1'); ?>
                <?php endif; ?>
               
               
                <?php if ($this->_tpl_vars['tog'] == ''): ?>
                
                <img  src="./images/off.png">
                <?php endif; ?>
                 <?php $this->assign('tog', ''); ?>
                </td>
				
				
			-->
                 
         
             
			
				   <?php if ($this->_tpl_vars['branchDetail']['0']['EB'] == '1'): ?>
                    <td align="right" id="<?php echo $this->_tpl_vars['j']; ?>
kwh"> <script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['List']['TOTAL_KWH']; ?>
','<?php echo $this->_tpl_vars['j']; ?>
kwh');</script></td>
                    <td align="right" id="<?php echo $this->_tpl_vars['j']; ?>
cost"> <script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['List']['cost']; ?>
','<?php echo $this->_tpl_vars['j']; ?>
cost');</script></td>
					<?php endif; ?>
					 <?php if ($this->_tpl_vars['branchDetail']['0']['DG'] == '1'): ?>
                    <td align="right" id="<?php echo $this->_tpl_vars['j']; ?>
dgkwh"> <script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['List']['dg_TOTAL_KWH']; ?>
','<?php echo $this->_tpl_vars['j']; ?>
dgkwh');</script></td>
                    <td align="right" id="<?php echo $this->_tpl_vars['j']; ?>
dgcost"> <script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['List']['dg_cost']; ?>
','<?php echo $this->_tpl_vars['j']; ?>
dgcost');</script></td>
					<?php endif; ?>
					 <?php if ($this->_tpl_vars['branchDetail']['0']['solarInverter'] == '1'): ?>
					  <td align="right" id="<?php echo $this->_tpl_vars['j']; ?>
solarkwh"> <script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['List']['solar_TOTAL_KWH']; ?>
','<?php echo $this->_tpl_vars['j']; ?>
solarkwh');</script></td>
                    <td align="right" id="<?php echo $this->_tpl_vars['j']; ?>
solarcost"> <script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['List']['solar_cost']; ?>
','<?php echo $this->_tpl_vars['j']; ?>
solarcost');</script></td>
					 <?php endif; ?>
                     <?php $this->assign('totalKWH', $this->_tpl_vars['totalKWH']+$this->_tpl_vars['List']['TOTAL_KWH']); ?>
                     <?php $this->assign('totalCost', $this->_tpl_vars['totalCost']+$this->_tpl_vars['List']['cost']); ?>
                     <?php $this->assign('dgTotalKWH', $this->_tpl_vars['dgTotalKWH']+$this->_tpl_vars['List']['dg_TOTAL_KWH']); ?>
                     <?php $this->assign('dgTotalCost', $this->_tpl_vars['dgTotalCost']+$this->_tpl_vars['List']['dg_cost']); ?>
					 <?php $this->assign('solarTotalKWH', $this->_tpl_vars['solarTotalKWH']+$this->_tpl_vars['List']['solar_TOTAL_KWH']); ?>
                     <?php $this->assign('solarTotalCost', $this->_tpl_vars['solarTotalCost']+$this->_tpl_vars['List']['solar_cost']); ?>
				
				  <td><?php echo ((is_array($_tmp=$this->_tpl_vars['SpecificTableDate']['0']['posted_date_time'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%d-%b-%Y %I:%M:%S %p") : smarty_modifier_date_format($_tmp, "%d-%b-%Y %I:%M:%S %p")); ?>
</td>
		       <td><?php echo $this->_tpl_vars['gatewayListDash']['0']['last_communication']; ?>
</td>
			   
            
                </tr>
                
                <?php endforeach; endif; unset($_from); ?>
               <?php if ($this->_tpl_vars['PMeterList'] != ""): ?>
               <?php $_from = $this->_tpl_vars['PMeterList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['List']):
?>
                <?php $this->assign('pid', ((is_array($_tmp=$this->_tpl_vars['List']['slNo'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp))); ?>
                <tr id="<?php echo $this->_tpl_vars['j']++; ?>
">
				 <td ><?php echo $this->_tpl_vars['j']; ?>
</td>
				 	
                 
                     <td><a href="meterDashboard.php?companyId=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['company_id'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
&branchId=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['branch_id'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
&sensorCode=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['sensor_code'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
&gatewayCode=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['gateway_code'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
" style="text-decoration:underline;color:#000000;" title="Meter Details" ><?php echo $this->_tpl_vars['List']['feeder_name']; ?>
</a><?php $_from = $this->_tpl_vars['selQryS']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['sub']):
?><?php if ($this->_tpl_vars['List']['feeder_type'] == 'Main Meter' && $this->_tpl_vars['List']['slNo'] == $this->_tpl_vars['sub']['parent_id']): ?>&ensp;&ensp;<a href="subdashboard.php?parent_id=<?php echo $this->_tpl_vars['pid']; ?>
&companyId=<?php echo $this->_supers['get']['companyId']; ?>
&branchId=<?php echo $this->_supers['get']['branchId']; ?>
"><i class="fa fa-sitemap" aria-hidden="true" title="Submeter List"></i></a><?php endif; ?><?php endforeach; endif; unset($_from); ?></td>
                 
                 <td ><?php echo $this->_tpl_vars['List']['gateway_code']; ?>
</td>
				 
				 
		
			<!--	<td>
				
			
				<?php if ($this->_tpl_vars['List']['gateway_code'] != "YMN-1" && $this->_tpl_vars['List']['gateway_code'] == $this->_tpl_vars['List']['gateway_code'] && $this->_tpl_vars['List']['gateway_date_time'] >= ((is_array($_tmp=$this->_tpl_vars['dateSec'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d %H:%M:%S'))): ?>
                
                <img  src="./images/on.png">
                 <?php $this->assign('tog', '1'); ?>
                <?php elseif ($this->_tpl_vars['List']['gateway_code'] != "YMN-1" && $this->_tpl_vars['List']['gateway_code'] == $this->_tpl_vars['List']['gateway_code'] && $this->_tpl_vars['List']['gateway_date_time'] < ((is_array($_tmp=$this->_tpl_vars['dateSec'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d %H:%M:%S'))): ?>
                
                <img  src="./images/off.png">
                 <?php $this->assign('tog', '1'); ?>
                <?php endif; ?>
                
                
                <?php if ($this->_tpl_vars['List']['gateway_code'] == "YMN-1" && $this->_tpl_vars['List']['gateway_code'] == $this->_tpl_vars['List']['gateway_code'] && $this->_tpl_vars['List']['gateway_date_time'] >= ((is_array($_tmp=$this->_tpl_vars['dateSec1'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d %H:%M:%S'))): ?>
                
                <img  src="./images/on.png">
                 <?php $this->assign('tog', '1'); ?>
                <?php elseif ($this->_tpl_vars['List']['gateway_code'] == "YMN-1" && $this->_tpl_vars['List']['gateway_code'] == $this->_tpl_vars['List']['gateway_code'] && $this->_tpl_vars['List']['gateway_date_time'] < ((is_array($_tmp=$this->_tpl_vars['dateSec1'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d %H:%M:%S'))): ?>
                
                <img  src="./images/off.png">
                 <?php $this->assign('tog', '1'); ?>
                <?php endif; ?>
               
               
                <?php if ($this->_tpl_vars['tog'] == ''): ?>
                
                <img  src="./images/off.png">
                <?php endif; ?>
                 <?php $this->assign('tog', ''); ?>
                </td>
				
				
			-->
                 
            
				 
				  <?php if ($this->_tpl_vars['branchDetail']['0']['EB'] == '1'): ?>
                    <td align="right" id="<?php echo $this->_tpl_vars['j']; ?>
kwh"> <script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['List']['TOTAL_KWH']; ?>
','<?php echo $this->_tpl_vars['j']; ?>
kwh');</script></td>
                    <td align="right" id="<?php echo $this->_tpl_vars['j']; ?>
cost"> <script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['List']['cost']; ?>
','<?php echo $this->_tpl_vars['j']; ?>
cost');</script></td>
					<?php endif; ?>
				   <?php if ($this->_tpl_vars['branchDetail']['0']['DG'] == '1'): ?>
                    <td align="right" id="<?php echo $this->_tpl_vars['j']; ?>
dgkwh"> <script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['List']['dg_TOTAL_KWH']; ?>
','<?php echo $this->_tpl_vars['j']; ?>
dgkwh');</script></td>
                    <td align="right" id="<?php echo $this->_tpl_vars['j']; ?>
dgcost"> <script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['List']['dg_cost']; ?>
','<?php echo $this->_tpl_vars['j']; ?>
dgcost');</script></td>
                    <?php endif; ?>
				   <?php if ($this->_tpl_vars['branchDetail']['0']['solarInverter'] == '1'): ?>
				    <td align="right" id="<?php echo $this->_tpl_vars['j']; ?>
solarkwh"> <script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['List']['solar_TOTAL_KWH']; ?>
','<?php echo $this->_tpl_vars['j']; ?>
solarkwh');</script></td>
                    <td align="right" id="<?php echo $this->_tpl_vars['j']; ?>
solarcost"> <script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['List']['solar_cost']; ?>
','<?php echo $this->_tpl_vars['j']; ?>
solarcost');</script></td>
					<?php endif; ?>
				  <?php $this->assign('totalKWH', $this->_tpl_vars['totalKWH']+$this->_tpl_vars['List']['TOTAL_KWH']); ?>
                     <?php $this->assign('totalCost', $this->_tpl_vars['totalCost']+$this->_tpl_vars['List']['cost']); ?>
                     <?php $this->assign('dgTotalKWH', $this->_tpl_vars['dgTotalKWH']+$this->_tpl_vars['List']['dg_TOTAL_KWH']); ?>
                     <?php $this->assign('dgTotalCost', $this->_tpl_vars['dgTotalCost']+$this->_tpl_vars['List']['dg_cost']); ?>
					 <?php $this->assign('solarTotalKWH', $this->_tpl_vars['solarTotalKWH']+$this->_tpl_vars['List']['solar_TOTAL_KWH']); ?>
                     <?php $this->assign('solarTotalCost', $this->_tpl_vars['solarTotalCost']+$this->_tpl_vars['List']['solar_cost']); ?>
				  <td><?php echo ((is_array($_tmp=$this->_tpl_vars['List']['recorded_date_time'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%d-%b-%Y %I:%M:%S %p") : smarty_modifier_date_format($_tmp, "%d-%b-%Y %I:%M:%S %p")); ?>
</td>
		       <td id="<?php echo $this->_tpl_vars['j']; ?>
"><script type="text/javascript">secondsToDhms('<?php echo $this->_tpl_vars['List']['secs']; ?>
','<?php echo $this->_tpl_vars['j']; ?>
');</script> </td>
			   
            
                </tr>
              
                <?php endforeach; endif; unset($_from); ?>
               <?php endif; ?>
               <tr>
                   <td></td>
                   <td></td>
                   <td></td>
				   <?php if ($this->_tpl_vars['branchDetail']['0']['EB'] == '1'): ?>
                   <td align="right" id="tKwh"><script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['totalKWH']; ?>
','tKwh');</script></td>
                   <td align="right" id="tCost"><script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['totalCost']; ?>
','tCost');</script></td>
				   <?php endif; ?>
				   <?php if ($this->_tpl_vars['branchDetail']['0']['DG'] == '1'): ?>
                   <td align="right" id="tdgKwh"><script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['dgTotalKWH']; ?>
','tdgKwh');</script></td>
                   <td align="right" id="tdgCost"><script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['dgTotalCost']; ?>
','tdgCost');</script></td>
				   <?php endif; ?>
				   <?php if ($this->_tpl_vars['branchDetail']['0']['solarInverter'] == '1'): ?>
				   <td align="right" id="tsolarKwh"><script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['solarTotalKWH']; ?>
','tsolarKwh');</script></td>
                   <td align="right" id="tsolarCost"><script type="text/javascript">includecomma1('<?php echo $this->_tpl_vars['solarTotalCost']; ?>
','tsolarCost');</script></td>
				   <?php endif; ?>
                   <td></td>
                   <td></td>
                </tr>
               
                </tbody>
                
              </table>
			  </div>
</div>
</div>
<div class="card-body table-responsive">
            <div class="row">
        </div>
        </div>
      </div>
    </div>
	
	<div class="col-md-2">
			<div class="card card-primary card-outline">
			<div class="card-header">
			<h3 class="card-title">Gateway List</h3>
			</div>
			<div class="card-body p-0">
			<ul class="products-list product-list-in-card pl-2 pr-2">
			 <?php $_from = $this->_tpl_vars['gatewayListDash']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['List']):
?>
			
			<li class="item">
			<div class="product-img">
			<a href="javascript:void(0)" class="product-title"><?php echo $this->_tpl_vars['List']['place_of_installation']; ?>
  &ensp; &ensp; &ensp; &ensp; &ensp; &ensp;&ensp;</a>
			<?php if ($this->_tpl_vars['List']['gateway_code'] != "YMN-1" && $this->_tpl_vars['List']['gateway_code'] == $this->_tpl_vars['List']['gateway_code'] && $this->_tpl_vars['List']['gateway_date_time'] >= ((is_array($_tmp=$this->_tpl_vars['dateSec'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d %H:%M:%S'))): ?>
               <span class="badge badge-success float-right"> 
                ON
                </span>
                 <?php $this->assign('tog', '1'); ?>
                <?php elseif ($this->_tpl_vars['List']['gateway_code'] != "YMN-1" && $this->_tpl_vars['List']['gateway_code'] == $this->_tpl_vars['List']['gateway_code'] && $this->_tpl_vars['List']['gateway_date_time'] < ((is_array($_tmp=$this->_tpl_vars['dateSec'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d %H:%M:%S'))): ?>
                <span class="badge badge-danger float-right">
              OFF
               </span>
                 <?php $this->assign('tog', '1'); ?>
                <?php endif; ?>
                
                
                <?php if ($this->_tpl_vars['List']['gateway_code'] == "YMN-1" && $this->_tpl_vars['List']['gateway_code'] == $this->_tpl_vars['List']['gateway_code'] && $this->_tpl_vars['List']['gateway_date_time'] >= ((is_array($_tmp=$this->_tpl_vars['dateSec1'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d %H:%M:%S'))): ?>
                <span class="badge badge-success float-right"> 
               ON
                </span>
                 <?php $this->assign('tog', '1'); ?>
                <?php elseif ($this->_tpl_vars['List']['gateway_code'] == "YMN-1" && $this->_tpl_vars['List']['gateway_code'] == $this->_tpl_vars['List']['gateway_code'] && $this->_tpl_vars['List']['gateway_date_time'] < ((is_array($_tmp=$this->_tpl_vars['dateSec1'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d %H:%M:%S'))): ?>
                 <span class="badge badge-danger float-right">
                     OFF
                </span>
                 <?php $this->assign('tog', '1'); ?>
                <?php endif; ?>
               
               
                <?php if ($this->_tpl_vars['tog'] == ''): ?>
                 <span class="badge badge-danger float-right">
                OFF
                 </span>
                <?php endif; ?>
                 <?php $this->assign('tog', ''); ?>
				
			
			<span class="product-description" style="font-size:12px">
			
			</span>
			</div>
			</li>
			
			<?php endforeach; endif; unset($_from); ?>
			</ul>
			</div>
		<!--	<div class="card-footer text-center">
			<a href="listIncidentLog.php" class="uppercase">View All Incidents</a>
			</div> -->
			</div>
			
			
			<div class="card card-primary card-outline">
			<div class="card-header">
			<h3 class="card-title">EB Meters</h3>
			</div>
			<div class="card-body p-0">
			<ul class="products-list product-list-in-card pl-2 pr-2">
			<li class="item">
			<div class="product-img">
			<a href="javascript:void(0)" class="product-title text-primary">Overall  &ensp; &ensp; &ensp; &ensp; &ensp; &ensp;&ensp;</a>
               <span class="badge badge-primary float-right"> 
                <?php echo $this->_tpl_vars['overallmeters']; ?>

                </span>
   			</div>
			</li>
			<li class="item">
			<div class="product-img">
			<a href="javascript:void(0)" class="product-title text-success" >Live  &ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp;&ensp;</a>
               <span class="badge badge-success float-right"> 
                <?php echo $this->_tpl_vars['livemeters']; ?>

                </span>
   			</div>
			</li>
			<li class="item">
			<div class="product-img">
			<a href="javascript:void(0)" class="product-title text-danger">Off&ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp;&ensp;</a>
               <span class="badge badge-danger float-right"> 
                <?php echo $this->_tpl_vars['offmeters']; ?>

                </span>
   			</div>
			</li>
			<li class="item">
			<div class="product-img">
			<a href="javascript:void(0)" class="product-title text-warning">No Con.. &nbsp; &ensp; &ensp; &ensp; &ensp; &ensp;&ensp;</a>
               <span class="badge badge-warning float-right"> 
                <?php echo $this->_tpl_vars['noconnectionmeters']; ?>

                </span>
   			</div>
			</li>

			</ul>
			</div>
		<!--	<div class="card-footer text-center">
			<a href="listIncidentLog.php" class="uppercase">View All Incidents</a>
			</div> -->
			</div>
			</div>
  </div>
  </div>
  </div>
  </div>
  </body>
 <?php echo '
 <style>
 .slNo
 {
 width:3%;
 }
 .name
 {
 width:18%;
 }
 .gate
 {
 width:10%;
 }
 .status
 {
 width:5%;
 }
 .code
 {
 width:10%;
 }
 .cost
 {
 width:5%;
 }
 .action
 {
 width:15%;
 }
 .last
 {
 width:11%;
 }
 .uline
 {
 text-decoration:underline;
 }
 #barChart2 {
	width	: 100%;
	height	: 450px;
	}	
	 #DailybarChart2{
	width	: 100%;
	height	: 450px;
	}	
 </style>
  <script>
  $(function () {
    $(\'#example1\').DataTable({
      \'paging\'      : true,
      \'lengthChange\': false,
      \'searching\'   : true,
      \'ordering\'    : false,
      \'info\'        : false,
	  \'pageLength\': 50,
      \'autoWidth\'   : false,
      "columnDefs": [{
                "targets": \'_all\',
                "createdCell": function (th, cellData, rowData, row, col) {
                    $(th).css(\'padding\', \'10px\')
                }
            }]
    })
  })
  
</script>
<!-- <script type="text/javascript">
 function doOnLoad()
 {
 setInterval(Add_Item, 3000);
 }
 </script>-->
 <script type="text/javascript">
  $("input[data-bootstrap-switch]").each(function(){
      $(this).bootstrapSwitch(\'state\', $(this).prop(\'checked\'));
    });
	</script>
<!--	    <script type="text/javascript">
	function Add_Item()
{
var cid =$(\'#cid\').val() ;
var bid =$(\'#bid\').val() ;//alert(bid)
$.ajax({
		type: "POST",
		url: "getTableData.php",
		data: {cid:cid,bid:bid},
		success: function(data) {
		$("#list_books").html(data);
		}
		});
}
	</script>-->
	<style>
	    .dataTable thead .sorting_asc,
 .dataTable thead .sorting_desc,
.dataTable thead .sorting {
    padding-left: 2.2rem !important;
    padding-right: 0.75rem !important;
 }
	</style>
	 <script type="text/javascript">
    function addcomma(c)
{
var x=c;
x=x.toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != \'\')
    lastThree = \',\' + lastThree;
var res = otherNumbers.replace(/\\B(?=(\\d{2})+(?!\\d))/g, ",") + lastThree;
return res;
}

function includecomma(c)
{
var x=c;
x=x.toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != \'\')
    lastThree = \',\' + lastThree;
var res = otherNumbers.replace(/\\B(?=(\\d{2})+(?!\\d))/g, ",") + lastThree;
return res;
}
</script>

  <script>
	/*********** This month - Kwh and Cost Pie Chart Start **********************/
	var result = document.getElementById(\'thisMonthPieData\').value;

var jsonData=result;
var obj = JSON.parse(jsonData);
var sensor = "";
var dataVal = "";
var dataVal1 = "";
var colo = "";
var i;
for (i = 0; i < obj.length; i++) {
if(i==0){
  sensor += obj[i].sensorcode ;
  dataVal += obj[i].kwh;
  dataVal1 += obj[i].cost;
   colo += obj[i].color;
   }
  else
  {
  sensor += ", "+ obj[i].sensorcode;
  dataVal += ", "+ obj[i].kwh;
   dataVal1 += ", "+ obj[i].cost;
   colo += \', \'+ obj[i].color;
 }
}

var sensorVal = sensor;
var dataValue =dataVal;
var dataValue1 =dataVal1;
var colors =colo;


var sensor =  sensorVal.split(\',\');
var dataV=  dataVal.split(\',\');
var dataV1=  dataVal1.split(\',\');
var colors=  colo.split(\',\');
 
var dis = Math.round(dataV);
var vad = addcomma(dis);

var pieChartData = {
labels  :  sensor,
datasets: [
{
label               : \'Kwh\',
backgroundColor     : colors,
hoverBackgroundColor: colors,
hoverBorderColor    : colors,
borderColor         :  colors,
pointRadius          : false,
pointColor          :  colors,
pointStrokeColor    :  colors,
pointHighlightFill  :  colors,
pointHighlightStroke:  colors,
fillColor: colors,
data                : dataV
}
]
};
 
	var pieChartDataCost = {
labels  :  sensor,
datasets: [
{
label               : \'Cost\',
backgroundColor     : colors,
hoverBackgroundColor: colors,
hoverBorderColor    : colors,
borderColor         :  colors,
pointRadius          : false,
pointColor          :  colors,
pointStrokeColor    :  colors,
pointHighlightFill  :  colors,
pointHighlightStroke:  colors,
fillColor: colors,
data                : dataV1
}
]
};
	
       /* This Month Kwh Pie */
  var pieChartCanvasKCM = $(\'#pieChart1\').get(0).getContext(\'2d\')
    var pieDataKCM       = pieChartData;
    var pieOptionsKCM     = {
      maintainAspectRatio : false,
      responsive : true,
      legend: {
        position: \'right\',
      }
    }
      var pieChart = new Chart(pieChartCanvasKCM, {
      type: \'pie\',
      data: pieDataKCM,
      options: pieOptionsKCM      
    })
    
    /* This Month Cost Pie */
  var pieChartCanvas = $(\'#pieChart4\').get(0).getContext(\'2d\')
    var pieData        = pieChartDataCost;
    var pieOptions     = {
      maintainAspectRatio : false,
      responsive : true,
      legend: {
        position: \'right\',
      }
    }
      var pieChart = new Chart(pieChartCanvas, {
      type: \'pie\',
      data: pieData,
      options: pieOptions      
    })

/*********** This month - Kwh and Cost Pie Chart End **********************/
	</script>

<script>

/*********** Last month - Kwh Pie Chart Start **********************/
var result = document.getElementById(\'lastMonthPieData\').value;
var jsonData=result;
var obj = JSON.parse(jsonData);
var sensor = "";
var dataVal = "";
var dataVal1 = "";
var colo = "";
var i;
for (i = 0; i < obj.length; i++) {
if(i==0){
  sensor += obj[i].sensorcode ;
  dataVal += obj[i].kwh;
  dataVal1 += obj[i].cost;
   colo += obj[i].color;
   }
  else
  {
  sensor += ", "+ obj[i].sensorcode;
  dataVal += ", "+ obj[i].kwh;
   dataVal1 += ", "+ obj[i].cost;
   colo += \', \'+ obj[i].color;
 }
}

var sensorVal = sensor;
var dataValue =dataVal;
var dataValue1 =dataVal1;
var colors =colo;


var sensor =  sensorVal.split(\',\');
var dataV=  dataVal.split(\',\');
var dataV1=  dataVal1.split(\',\');
var colors=  colo.split(\',\');
 
var dis = Math.round(dataV);
var vad = addcomma(dis);

var pieChartDataLast = {
labels  :  sensor,
datasets: [
{
label               : \'Kwh\',
backgroundColor     : colors,
hoverBackgroundColor: colors,
hoverBorderColor    : colors,
borderColor         :  colors,
pointRadius          : false,
pointColor          :  colors,
pointStrokeColor    :  colors,
pointHighlightFill  :  colors,
pointHighlightStroke:  colors,
fillColor: colors,
data                : dataV
}
]
};

var pieChartDataCostLast = {
labels  :  sensor,
datasets: [
{
label               : \'Cost\',
backgroundColor     : colors,
hoverBackgroundColor: colors,
hoverBorderColor    : colors,
borderColor         :  colors,
pointRadius          : false,
pointColor          :  colors,
pointStrokeColor    :  colors,
pointHighlightFill  :  colors,
pointHighlightStroke:  colors,
fillColor: colors,
data                : dataV1
}
]
};
      /* Last Month Kwh Pie */
var pieChartCanvas = $(\'#pieChart2\').get(0).getContext(\'2d\')
    var pieData        = pieChartDataLast;
    var pieOptions     = {
      maintainAspectRatio : false,
      responsive : true,
      legend: {
        position: \'right\',
      }
    }
    //Create pie or douhnut chart
    // You can switch between pie and douhnut using the method below.
    var pieChart = new Chart(pieChartCanvas, {
      type: \'pie\',
      data: pieData,
      options: pieOptions      
    })

        /* Last Month Cost Pie */
    var pieChartCanvas = $(\'#pieChart3\').get(0).getContext(\'2d\')
    var pieData        = pieChartDataCostLast;
    var pieOptions     = {
      maintainAspectRatio : false,
      responsive : true,
      legend: {
        position: \'right\',
      }
    }
      var pieChart = new Chart(pieChartCanvas, {
      type: \'pie\',
      data: pieData,
      options: pieOptions      
    })

    
   /*********** Last month - Kwh Pie Chart End **********************/
</script>



<script type="text/javascript">

/* BAR VALUE PLUGIN - register only one time */
if (!window.barValuePluginRegistered) {
  Chart.plugins.register({
    afterDatasetsDraw: function(chart) {
      if (!chart.options.showBarValue) return;

      var ctx = chart.ctx;

      chart.data.datasets.forEach(function(dataset, datasetIndex) {
        var meta = chart.getDatasetMeta(datasetIndex);

        meta.data.forEach(function(bar, index) {
          var value = dataset.data[index];

          if (value === null || value === undefined || value === \'\') return;

          value = Math.round(Number(value));

          var barX = bar._model.x;
          var barY = bar._model.y;
          var baseY = bar._model.base;
          var barHeight = baseY - barY;

          ctx.save();
          ctx.font = \'bold 10px Arial\';
          ctx.textAlign = \'center\';
          ctx.textBaseline = \'middle\';

          /* Kwh blue bar - show value above */
          if (dataset.label == \'Kwh\') {
            ctx.fillStyle = \'#000000\';
            ctx.fillText(includecomma(value), barX, barY - 8);
          }

          /* Cost yellow bar - show value inside vertically */
          if (dataset.label == \'Cost\') {
            if (barHeight > 45) {
              ctx.fillStyle = \'#ffffff\';

              ctx.translate(barX, barY + 28);
              ctx.rotate(-Math.PI / 2);
              ctx.fillText(includecomma(value), 0, 0);
            } else {
              ctx.fillStyle = \'#000000\';
              ctx.fillText(includecomma(value), barX, barY - 8);
            }
          }

          ctx.restore();
        });
      });
    }
  });

  window.barValuePluginRegistered = true;
}


var result = document.getElementById(\'currMonQut\').value;

var jsonData = result;
var obj = JSON.parse(jsonData);

var mon = "";
var dataVal = "";
var dataVal1 = "";
var colo = "";

for (var i = 0; i < obj.length; i++) {
  if (i == 0) {
    mon += obj[i].month;
    dataVal += obj[i].value;
    dataVal1 += obj[i].value1;
    colo += obj[i].color;
  } else {
    mon += ", " + obj[i].month;
    dataVal += ", " + obj[i].value;
    dataVal1 += ", " + obj[i].value1;
    colo += ", " + obj[i].color;
  }
}

var month = mon.split(\',\');
var dataV = dataVal.split(\',\').map(Number);
var dataV1 = dataVal1.split(\',\').map(Number);

var barChartCanvasSec = $(\'#barChart2\').get(0).getContext(\'2d\');

var barChartDataSec = {
  labels: month,
  datasets: [
    {
      label: \'Kwh\',
      backgroundColor: \'#67b7dc\',
      borderColor: \'#67b7dc\',
      data: dataV
    },
    {
      label: \'Cost\',
      backgroundColor: \'#fdd400\',
      borderColor: \'#fdd400\',
      data: dataV1
    }
  ]
};

var barChartOptionsSec = {
  showBarValue: true,

  responsive: true,
  maintainAspectRatio: false,
  datasetFill: false,

  legend: {
    display: true,
    position: \'top\',
    labels: {
      boxWidth: 50,
      fontSize: 12
    }
  },

  tooltips: {
    callbacks: {
      label: function(tooltipItem, data) {
        var label = data.datasets[tooltipItem.datasetIndex].label || \'\';
        var value = Math.round(tooltipItem.yLabel);
        return label + \': \' + includecomma(value);
      }
    }
  },

  scales: {
    xAxes: [{
      gridLines: {
        display: true
      },
      ticks: {
        autoSkip: false,
        maxRotation: 45,
        minRotation: 45,
        fontSize: 11
      },
      categoryPercentage: 0.75,
      barPercentage: 0.85
    }],

    yAxes: [{
      ticks: {
        beginAtZero: true,
        stepSize: 5000,
        fontSize: 11,
        callback: function(value) {
          return includecomma(value);
        }
      }
    }]
  }
};

var barChartSec = new Chart(barChartCanvasSec, {
  type: \'bar\',
  data: barChartDataSec,
  options: barChartOptionsSec
});

</script>
<script type="text/javascript">

/* Daily Bar Value Plugin */
Chart.plugins.register({
  afterDatasetsDraw: function(chart) {
    if (!chart.options.showBarValue) return;

    var ctx = chart.ctx;

    chart.data.datasets.forEach(function(dataset, datasetIndex) {
      var meta = chart.getDatasetMeta(datasetIndex);

      meta.data.forEach(function(bar, index) {
        var value = dataset.data[index];

        if (value === null || value === undefined || value === \'\') return;

        value = Math.round(Number(value));

        var barX = bar._model.x;
        var barY = bar._model.y;
        var baseY = bar._model.base;
        var barHeight = baseY - barY;

        ctx.save();
        ctx.font = \'bold 10px Arial\';
        ctx.textAlign = \'center\';
        ctx.textBaseline = \'middle\';

        /* Kwh small blue bar - show above */
        if (dataset.label == \'Kwh\') {
          ctx.fillStyle = \'#000000\';
          ctx.fillText(includecomma(value), barX, barY - 8);
        }

        /* Cost yellow bar - show inside bar */
        if (dataset.label == \'Cost\') {
          if (barHeight > 45) {
            ctx.fillStyle = \'#ffffff\';

            /* Rotate value inside yellow bar */
            ctx.translate(barX, barY + 28);
            ctx.rotate(-Math.PI / 2);
            ctx.fillText(includecomma(value), 0, 0);
          } else {
            ctx.fillStyle = \'#000000\';
            ctx.fillText(includecomma(value), barX, barY - 8);
          }
        }

        ctx.restore();
      });
    });
  }
});


var result = document.getElementById(\'currMonQutDaily\').value;
var jsonData = result;
var obj = JSON.parse(jsonData);

var mon = "";
var dataVal = "";
var dataVal1 = "";
var colo = "";

for (var i = 0; i < obj.length; i++) {
  if (i == 0) {
    mon += obj[i].dateM;
    dataVal += obj[i].value;
    dataVal1 += obj[i].value1;
    colo += obj[i].color;
  } else {
    mon += ", " + obj[i].dateM;
    dataVal += ", " + obj[i].value;
    dataVal1 += ", " + obj[i].value1;
    colo += ", " + obj[i].color;
  }
}

var month = mon.split(\',\');
var dataV = dataVal.split(\',\').map(Number);
var dataV1 = dataVal1.split(\',\').map(Number);

var barChartCanvasSec = $(\'#DailybarChart2\').get(0).getContext(\'2d\');

var barChartDataSec = {
  labels: month,
  datasets: [
    {
      label: \'Kwh\',
      backgroundColor: \'#67b7dc\',
      borderColor: \'#67b7dc\',
      data: dataV
    },
    {
      label: \'Cost\',
      backgroundColor: \'#fdd400\',
      borderColor: \'#fdd400\',
      data: dataV1
    }
  ]
};

var barChartOptionsSec = {
  showBarValue: true,

  responsive: true,
  maintainAspectRatio: false,
  datasetFill: false,

  legend: {
    display: true,
    position: \'top\',
    labels: {
      boxWidth: 50,
      fontSize: 12
    }
  },

  tooltips: {
    callbacks: {
      label: function(tooltipItem, data) {
        var label = data.datasets[tooltipItem.datasetIndex].label || \'\';
        var value = Math.round(tooltipItem.yLabel);
        return label + \': \' + includecomma(value);
      }
    }
  },

  scales: {
    xAxes: [{
      gridLines: {
        display: true
      },
      ticks: {
        autoSkip: false,
        maxRotation: 45,
        minRotation: 45,
        fontSize: 11
      },
      categoryPercentage: 0.75,
      barPercentage: 0.85
    }],

    yAxes: [{
      ticks: {
        beginAtZero: true,
        stepSize: 1000,
        fontSize: 11,
        callback: function(value) {
          return includecomma(value);
        }
      }
    }]
  }
};

var barChartSec = new Chart(barChartCanvasSec, {
  type: \'bar\',
  data: barChartDataSec,
  options: barChartOptionsSec
});

</script>
 '; ?>


  <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>