<?php /* Smarty version 2.6.25, created on 2026-09-30 11:37:40
         compiled from feederAddEdit.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'base64_decode', 'feederAddEdit.tpl', 33, false),array('modifier', 'date_format', 'feederAddEdit.tpl', 145, false),)), $this); ?>
<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;"><?php if ($this->_tpl_vars['companyDetail']['0']['companyName'] != ""): ?><?php echo $this->_tpl_vars['companyDetail']['0']['companyName']; ?>
<?php else: ?><?php echo $this->_supers['session']['CompanyName']; ?>
<?php endif; ?>&nbsp;&nbsp;</td>
				<?php if ($this->_supers['get']['branchId']): ?>  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="font-size:15PX;font-weight: bold;"><?php echo $this->_tpl_vars['branchDetail']['0']['branch_name']; ?>
&ensp;&ensp;</td><?php endif; ?>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">Edit Energy Meter</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			<a href="feederList.php?companyId=<?php echo $this->_supers['get']['companyId']; ?>
&branchId=<?php echo $this->_supers['get']['branchId']; ?>
"><button type="button" class="btn btn-primary" value="" style="float:right;margin-top:-40PX">List Energy Meter</button></a>
			</div>
		</div>
		<div class="card">
			<div class="card-body">
				<form role="form" name="feederRegForm" id="feederRegForm" method="post" onsubmit="return createValidation();" >
					<input type="hidden" name="hdAction" />
					
					<input type="hidden" id="segName" name="segName" value="<?php echo $this->_tpl_vars['GetModelPlat']['0']['segmentName']; ?>
" />
				<?php if ($this->_supers['get']['sl_no'] != ""): ?>
					<input type="hidden" id="gateway_id" name="gateway_id" value="<?php echo $this->_tpl_vars['ListEditView']['0']['gateway_id']; ?>
" />
					<input type="hidden" id="branch_id" name="branch_id" value="<?php echo $this->_tpl_vars['ListEditView']['0']['branch_id']; ?>
" />
					<input type="hidden" id="company_id" name="company_id" value="<?php echo $this->_tpl_vars['ListEditView']['0']['company_id']; ?>
" />
					<input type="hidden" id="feederId" name="feederId" value="<?php echo $this->_supers['get']['feeder_master_id']; ?>
" />
				<?php else: ?>
					<input type="hidden" id="gateway_id" name="gateway_id" value="<?php echo ((is_array($_tmp=$this->_supers['get']['gatewayId'])) ? $this->_run_mod_handler('base64_decode', true, $_tmp) : base64_decode($_tmp)); ?>
" />
					<input type="hidden" id="company_id" name="company_id" value="<?php echo ((is_array($_tmp=$this->_supers['get']['companyId'])) ? $this->_run_mod_handler('base64_decode', true, $_tmp) : base64_decode($_tmp)); ?>
" />
					<input type="hidden" id="branch_id" name="branch_id" value="<?php echo ((is_array($_tmp=$this->_supers['get']['branchId'])) ? $this->_run_mod_handler('base64_decode', true, $_tmp) : base64_decode($_tmp)); ?>
" />
				<?php endif; ?>
					<input type="hidden" id="check_id" name="check_id" value="<?php echo $this->_supers['post']['check_id']; ?>
">
					<input type="hidden" id="checkVal" name="checkVal" value="<?php echo $this->_supers['post']['checkVal']; ?>
" />
				<div class="row">
					
					<div class="form-group col-md-6" >
						<label for="exampleInputmeterName">Sensor Name  /  Place Of Installation <span style="color:red;">*</span></label>
						<input type="text" class="form-control form-control-sm" id="sensorName" name="sensorName" placeholder="Enter Sensor Name" value="<?php if ($this->_tpl_vars['EditViewFeedForm']['0']['sensorName'] != ""): ?> <?php echo $this->_tpl_vars['EditViewFeedForm']['0']['sensorName']; ?>
<?php endif; ?>" autocomplete="Off" tabindex="2">
					</div>
					<?php if ($this->_tpl_vars['GetModelPlat']['0']['segmentName'] == 'Energy Meter'): ?>
					<div class="form-group col-md-6">
					<label for="exampleInputmodel">Energy Meter Type <span style="color:red;">*</span></label>
					<?php if ($this->_tpl_vars['EditViewFeedForm']['0']['slNo'] != ""): ?><select class="form-control form-control-sm" id="feederType" name="feederType"  tabindex="1" readonly="true" onchange="feederTypefun();" >
					<option value="<?php echo $this->_tpl_vars['EditViewFeedForm']['0']['feeder_type']; ?>
"><?php echo $this->_tpl_vars['EditViewFeedForm']['0']['feeder_type']; ?>
</option>
					<?php else: ?>
					<select class="form-control form-control-sm" id="feederType" name="feederType"  tabindex="3" onchange="feederTypefun();" >
					<option value="">--  Select  --</option>
					<?php endif; ?>
					<?php if ($this->_tpl_vars['EditViewFeedForm']['0']['feeder_type'] == ""): ?>
					    <option value="Main Meter">Main Meter</option>
						<option value="Sub Meter">Sub Meter</option>
						<option value="Sub Sub Meter">Sub Sub Meter</option>
					<?php endif; ?>
					</select>
					</div>
					<?php endif; ?>
					<div class="form-group col-md-6" id="Meter">
					<label for="exampleInputmake" id="subMeter">Sub Meter<span style="color:red;">*</span></label>
					<label for="exampleInputmake" id="mainMeter">Main Meter<span style="color:red;">*</span></label>
					<select class="form-control form-control-sm" id="meterType" name="meterType"  tabindex="4"><option value="">--  Select --</option>
					</select>
					</div>
					<?php if ($this->_tpl_vars['EditViewFeedForm']['0']['make'] == 'PFC'): ?>
					<div class="form-group col-md-6" >
						<label for="exampleInputLevel1">Level 1 (Below 100 )<span style="color:red;">*</span></label>
						<input type="text" class="form-control form-control-sm" id="level1" name="level1" placeholder="Enter Level1" value="<?php if ($this->_tpl_vars['EditViewFeedForm']['0']['level1'] != ""): ?> <?php echo $this->_tpl_vars['EditViewFeedForm']['0']['level1']; ?>
<?php endif; ?>" autocomplete="Off" tabindex="2" onkeyup="numericFilter(this)">
					</div>
					<div class="form-group col-md-6" >
						<label for="exampleInputLevel2">Level 2 (Above 0)<span style="color:red;">*</span></label>
						<input type="text" class="form-control form-control-sm" id="level2" name="level2" placeholder="Enter Level2" value="<?php if ($this->_tpl_vars['EditViewFeedForm']['0']['level2'] != ""): ?> <?php echo $this->_tpl_vars['EditViewFeedForm']['0']['level2']; ?>
<?php endif; ?>" autocomplete="Off" tabindex="3" onkeyup="numericFilter(this)">
					</div>
					<?php endif; ?>
				<?php if ($this->_supers['session']['USER_GROUP'] != 'Branch User' && $this->_tpl_vars['EditViewFeedForm']['0']['make'] != 'PFC'): ?>
				<?php if ($this->_tpl_vars['EditViewFeedForm']['0']['feeder_master_id'] != ""): ?> 
				<div class="form-group col-md-6" style="margin-top:10X">
				<?php endif; ?>
				<?php if ($this->_tpl_vars['GetModelPlat']['0']['segmentName'] == 'Energy Meter'): ?>
				<div class="form-group col-md-6" >
				
					<label for="exampleInputmodel">Unit Rate <span style="color:red;">*</span></label>
					<input type="text" class="form-control form-control-sm" id="unitRate" name="unitRate" placeholder="Enter Unit Rate" value="<?php if ($this->_tpl_vars['EditViewFeedForm']['0']['unit_rate'] != ""): ?><?php echo $this->_tpl_vars['EditViewFeedForm']['0']['unit_rate']; ?>
<?php else: ?>0.00<?php endif; ?>" autocomplete="Off" onkeyup="numericFilter(this);" tabindex="5">
				</div>
				<div class="form-group col-md-6" >
				
					<label for="exampleInputmodel">Energy Meter Id<span style="color:red;">*</span></label>
					<input type="text" class="form-control form-control-sm" id="energyMeterId" name="energyMeterId" placeholder="Enter ID" value="<?php if ($this->_tpl_vars['EditViewFeedForm']['0']['modbus_slave_id'] != ""): ?><?php echo $this->_tpl_vars['EditViewFeedForm']['0']['modbus_slave_id']; ?>
<?php else: ?>0<?php endif; ?>" readonly="true"autocomplete="Off" onkeyup="numericFilter(this);" >
				</div>
				 <div class="form-group col-md-6">
					<label for="inputEmail3">KWH Max Value </label>
					<input type="text" name="kwhMaxValue" class="form-control form-control-sm" id="kwhMaxValue" placeholder="KWH Max Value"  tabindex="3" value="<?php if ($this->_tpl_vars['EditViewFeedForm']['0']['kwh_max_value'] != ""): ?><?php echo $this->_tpl_vars['EditViewFeedForm']['0']['kwh_max_value']; ?>
<?php endif; ?>" onkeyup="numericFilter(this)">
				</div>
				
				<!--<div class="form-group col-md-6">
					<label for="inputEmail3">DG Unit Rate</label>
					<input type="text" name="dgunitRate" class="form-control form-control-sm" id="dgunitRate" placeholder="DG Unit Rate"  tabindex="3" value="<?php if ($this->_tpl_vars['EditViewFeedForm']['0']['dg_unit_rate'] != ""): ?><?php echo $this->_tpl_vars['EditViewFeedForm']['0']['dg_unit_rate']; ?>
<?php endif; ?>" onkeyup="numericFilter(this)">
				</div>-->
                <div class="form-group col-md-6">
					<label for="inputEmail3">KVAH Max Value </label>
					<input type="text" name="kvahMaxValue" class="form-control form-control-sm" id="kvahMaxValue" placeholder="KVAH Max value"  tabindex="4" value="<?php if ($this->_tpl_vars['EditViewFeedForm']['0']['kvah_max_value'] != ""): ?><?php echo $this->_tpl_vars['EditViewFeedForm']['0']['kvah_max_value']; ?>
<?php endif; ?>" onkeyup="numericFilter(this)" >
				</div>	
                 <div class="form-group col-md-6">
					<label for="inputEmail3">KW Max Value </label>
					<input type="text" name="kwMaxValue" class="form-control form-control-sm" id="kwMaxValue" placeholder="KW Max Value"  tabindex="3" value="<?php if ($this->_tpl_vars['EditViewFeedForm']['0']['kw_max_value'] != ""): ?><?php echo $this->_tpl_vars['EditViewFeedForm']['0']['kw_max_value']; ?>
<?php endif; ?>" onkeyup="numericFilter(this)">
				</div>
				<div class="form-group col-md-6">
					<label for="inputEmail3">KVARH Max Value </label>
					<input type="text" name="kvarhMaxValue" class="form-control form-control-sm" id="kvarhMaxValue" placeholder="KVARH Max value"  tabindex="4" value="<?php if ($this->_tpl_vars['EditViewFeedForm']['0']['kvarh_max_value'] != ""): ?><?php echo $this->_tpl_vars['EditViewFeedForm']['0']['kvarh_max_value']; ?>
<?php endif; ?>" onkeyup="numericFilter(this)" >
				</div>	
               
				<div class="form-group col-md-6">
					<label for="inputEmail3">KVA Max Value </label>
					<input type="text" name="kvaMaxValue" class="form-control form-control-sm" id="kvaMaxValue" placeholder="KVA Max Value"  tabindex="4" value="<?php if ($this->_tpl_vars['EditViewFeedForm']['0']['kva_max_value'] != ""): ?><?php echo $this->_tpl_vars['EditViewFeedForm']['0']['kva_max_value']; ?>
<?php endif; ?>" onkeyup="numericFilter(this)"  >
				</div>
				<div class="form-group col-md-6">
					<label for="inputEmail3">KVAR Max Value </label>
					<input type="text" name="kvarMaxValue" class="form-control form-control-sm" id="kvarMaxValue" placeholder="KVAR Max Value"  tabindex="5" value="<?php if ($this->_tpl_vars['EditViewFeedForm']['0']['kvar_max_value'] != ""): ?><?php echo $this->_tpl_vars['EditViewFeedForm']['0']['kvar_max_value']; ?>
<?php endif; ?>" onkeyup="numericFilter(this)"  >
				</div>

                <?php endif; ?>
				<?php endif; ?>
				<?php if ($this->_tpl_vars['companyDetail']['0']['billing_module'] == '1'): ?>
				<?php if ($this->_tpl_vars['GetModelPlat']['0']['segmentName'] == 'Energy Meter'): ?>
				<div class="form-group col-md-6">
					<label for="inputEmail3">Contact Person </label>
					<input type="text" name="contact_person" class="form-control form-control-sm" id="contact_person" placeholder="Contact Person"   value="<?php if ($this->_tpl_vars['EditViewFeedForm']['0']['contact_person'] != ""): ?><?php echo $this->_tpl_vars['EditViewFeedForm']['0']['contact_person']; ?>
<?php endif; ?>" onkeyup="text_filter(this)">
				</div>
                <div class="form-group col-md-6">
					<label for="inputEmail3">KVAR Max Value </label>
					<input type="text" name="kvarMaxValue" class="form-control form-control-sm" id="kvarMaxValue" placeholder="KVAR Max Value"  tabindex="4" value="<?php if ($this->_tpl_vars['EditViewFeedForm']['0']['kvar_max_value'] != ""): ?><?php echo $this->_tpl_vars['EditViewFeedForm']['0']['kvar_max_value']; ?>
<?php endif; ?>" onkeyup="numericFilter(this)"  >
				</div>
				<div class="form-group col-md-6">
					<label for="inputEmail3">Mobile No </label>
					<input type="text" name="contact_no" class="form-control form-control-sm" id="contact_no" placeholder="Mobile No"   value="<?php if ($this->_tpl_vars['EditViewFeedForm']['0']['contact_no'] != ""): ?><?php echo $this->_tpl_vars['EditViewFeedForm']['0']['contact_no']; ?>
<?php endif; ?>" onkeyup="numericFilter(this)" >
				</div>
				<div class="form-group col-md-6">
					<label for="inputEmail3">Email Id </label>
					<input type="text" name="email_id" class="form-control form-control-sm" id="email_id" placeholder="Email Id"   value="<?php if ($this->_tpl_vars['EditViewFeedForm']['0']['email_id'] != ""): ?><?php echo $this->_tpl_vars['EditViewFeedForm']['0']['email_id']; ?>
<?php endif; ?>"  >
					
					<input id="created_by" name="created_by"  type="hidden" value="<?php echo $this->_supers['session']['UserName']; ?>
" readonly="true">
					<input type="hidden" class="form-control" id="created_date_time" name="created_date_time" value="<?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d %H:%M:%S')); ?>
">
					<input type="hidden" class="form-control" id="created_time" name="created_time" placeholder="Time" Value="<?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%I:%M:%S %p') : smarty_modifier_date_format($_tmp, '%I:%M:%S %p')); ?>
">
			
				</div>
				<?php endif; ?>
				<?php endif; ?>				
				
				</div>
					<div align="center">
						<input type="submit" value="Submit" class="btn btn-create" tabindex="6"/>
					</div>
				</form>
			</div>
		</div>
	</div>
	</section>
	</div>
	<?php echo '
	<script type="text/javascript">
	$(document).ready(function(){
		$("#mainMeter").hide();
		$("#subMeter").hide();
		$("#Meter").hide();
	});
	</script>
	<script >
	function feederTypefun(){
		var feederType= $("#feederType").val();
		var branId=$("#branch_id").val();
	if(feederType ==\'Sub Meter\')
	{
		$("#Meter").show();
		$("#mainMeter").show();
		$("#subMeter").hide();
	}else if(feederType==\'Sub Sub Meter\'){
		$("#Meter").show();
		$("#subMeter").show();
		$("#mainMeter").hide();
	}
	else if(feederType==\'Main Meter\'){
		$("#Meter").hide();
		$("#subMeter").hide();
		$("#mainMeter").hide();
		return false;
	}
	$.ajax({
	type: "POST",
	url: "ajaxFeederType.php",
	data: {feedType:feederType,branchId:branId},
	dataType: "JSON",
	cache: false,
	success: function(result){
	var len = result.length;
	$("#meterType").empty();
	$("#meterType").append("<option value=\'\'> -- Select -- </option>");
	var option;
	for( var i = 0; i<len; i++){
	var slNo = result[i]["slNo"];
	var sensorName = result[i]["sensorName"];
	var parentId = result[i]["parent_id"];
	var submeterId = result[i]["submeter_id"];
	option +="<option value=\'"+slNo+"/"+sensorName+"/"+parentId+"/"+submeterId+"\'>"+sensorName+"</option>";
	}
	$("#meterType").append(option);
	},
	error: function(result) {
	alert(\'error\');
	}
	});
	}
	</script>
	<script type="text/javascript">
	function numericFilter(data)
	{
	data.value = data.value.replace(/[^.0-9^.+,-]/ig,"");
	}
	function text_filter(data)
	{
	data.value = data.value.replace(/[^ .a-z]/ig,"");
	
	}
	function createValidation(){
	//alert("am working");
		var sensorName = $(\'#sensorName\').val();
		var segmentN = $(\'#segName\').val();
		if(segmentN == "Energy Meter"){
		var feederName = $(\'#feederName\').val();
		var feederType = $(\'#feederType\').val();
		var unitRate = $(\'#unitRate\').val();
           }
		$(".error").remove();
	if (sensorName < 1) {
		$(\'#sensorName\').after(\'<span class="error">This field is required</span>\');
		$(\'#sensorName\').focus();
		return false;					
	}
	if(segmentN == "Energy Meter"){
	 if (feederName < 1) {
		$(\'#feederName\').after(\'<span class="error">This field is required</span>\');
		$(\'#feederName\').focus();
		return false;					
	}
	else if (feederType < 1) {
		$(\'#feederType\').after(\'<span class="error">This field is required</span>\');
		$(\'#feederType\').focus();
		return false;					
	}
	else if(unitRate < 1) {
		$(\'#unitRate\').after(\'<span class="error">This field is required</span>\');
		$(\'#unitRate\').focus();
		return false;					
	}
	}
		FormName = document.feederRegForm;
		FormName.method = "POST";
		FormName.submit();
	}
	
	function GoBack()
	{
		window.history.back();
	}	
	</script>
	<script type="text/javascript">
	function locationDecode(){
		var lid = {$smarty.get.location_id};
		var uri_lid = decodeURIComponent(lid);
		alert(uri_lid);
	}
	</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	'; ?>

	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>