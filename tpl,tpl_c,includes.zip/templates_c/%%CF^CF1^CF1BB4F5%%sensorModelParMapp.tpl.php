<?php /* Smarty version 2.6.25, created on 2026-01-27 13:30:26
         compiled from sensorModelParMapp.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'base64_decode', 'sensorModelParMapp.tpl', 37, false),)), $this); ?>
	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;"><?php if ($this->_tpl_vars['companyDetail']['0']['companyName'] != ""): ?><?php echo $this->_tpl_vars['companyDetail']['0']['companyName']; ?>
<?php else: ?><?php echo $this->_supers['session']['CompanyName']; ?>
<?php endif; ?>&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;"><?php if ($this->_supers['get']['groupId'] == ""): ?>Sensor Model Parameter Mapping<?php else: ?>Sensor Model Parameter Mapping<?php endif; ?></font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			<a href="sensorModelList.php"> <button type="button" class="btn btn-primary" value="List Sensor Model" style="float:right;margin-top:-40PX">List Sensor Model</button></a>
			</div>
		</div>
	<div class="card">
	<?php if ($this->_tpl_vars['SuccessMessage'] != ""): ?>
		<div class="card-body">
			<div class="isa_success">
			<i class="fa fa-check"></i>
			<?php echo $this->_tpl_vars['SuccessMessage']; ?>
		 
			</div>
		</div>
	<?php endif; ?>
	<?php if ($this->_tpl_vars['ErrorMessage'] != ""): ?>
		<div class="card-body">
			<div class="isa_error">
			<i class="fa fa-check"></i>
			<?php echo $this->_tpl_vars['ErrorMessage']; ?>
		 
			</div>
		</div>
	<?php endif; ?>  
		<div class="card-body">
		<form  role="form" name="sensorModParMappReg" id="sensorModParMappReg" method="post" onsubmit="return ValidateFields();">
			<input type="hidden" name="hdAction" id="hdAction">
			<input type="text" id="sensorModId" name="sensorModId" value="<?php echo ((is_array($_tmp=$this->_supers['get']['sl_no'])) ? $this->_run_mod_handler('base64_decode', true, $_tmp) : base64_decode($_tmp)); ?>
" />
			<input type="hidden" id="checkVal" name="checkVal" value="<?php echo $this->_supers['post']['checkVal']; ?>
" />
			<input id="created_by" name="created_by" class="date-picker form-control" type="hidden" value="<?php echo $this->_supers['session']['UserName']; ?>
" readonly="true" tabindex="5">
			<div class="row">
				<div class="form-group col-md-6">
					<label for="inputEmail3">Sensor Model Name <span class="required"><b>*</b></span></label>
					<input type="text" name="sensorModelName" class="form-control form-control-sm" id="sensorModelName" placeholder="Sensor Model Name" autocomplete="Off" tabindex="1" value="<?php if ($this->_tpl_vars['SensorModel']['0']['model_name'] != ""): ?><?php echo $this->_tpl_vars['SensorModel']['0']['model_name']; ?>
<?php endif; ?>" readonly="true" >
				</div>
				<div class="form-group col-md-6">
					<label for="inputEmail3">Platform Type<span class="required"><b>*</b></span></label>
					<select name="platformType" class="form-control form-control-sm" id="platformType"  >
					<?php if ($this->_tpl_vars['GetParmDet']['0']['platform_type'] == ''): ?><option value="">-- Select Platform --</option><?php else: ?><option value="<?php echo $this->_tpl_vars['GetParmDet']['0']['platform_type']; ?>
"><?php echo $this->_tpl_vars['GetParmDet']['0']['platform_type']; ?>
</option><?php endif; ?>
					<?php $_from = $this->_tpl_vars['GetPlatform']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['ListPlat']):
?>
					<?php if ($this->_tpl_vars['ListPlat']['segmentName'] != $this->_tpl_vars['GetParmDet']['0']['platform_type']): ?>
					<option value="<?php echo $this->_tpl_vars['ListPlat']['segmentName']; ?>
"><?php echo $this->_tpl_vars['ListPlat']['segmentName']; ?>
</option>
					<?php endif; ?>
					<?php endforeach; endif; unset($_from); ?>
					</select>
				</div>
				<div class="form-group col-md-6">
					<h3 class="m-t-none m-b">Assign Parameters</h3>
				</div>
			<div class="form-group col-md-6"></div>
			<div class="hr-line-dashed"></div>	   
			<?php if ($this->_tpl_vars['ListEditView']['0']['slNo'] != ""): ?>
				<div class="col-md-5">
					<select class="form-control input-lg" multiple="multiple" name="exam16[]" id="exam16" size="15" value="<?php echo $this->_tpl_vars['exam16']; ?>
" autocomplete="Off" tabindex="4" onblur="ValidateFields1('exam16');">
								<?php $_from = $this->_tpl_vars['GetParameter']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['ListDet']):
?>
									<option value="<?php echo $this->_tpl_vars['ListDet']['Field']; ?>
"><?php echo $this->_tpl_vars['ListDet']['Field']; ?>
</option>	
								<?php endforeach; endif; unset($_from); ?>
						</select>
						</div>
					<?php else: ?>
						<div class="col-md-5">
				<select class="form-control input-lg" multiple="multiple" name="exam16[]" id="exam16" size="15" value="<?php echo $this->_tpl_vars['exam16']; ?>
" autocomplete="Off" tabindex="4" onblur="ValidateFields1('exam16');">
								<?php $_from = $this->_tpl_vars['GetParameter']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['ListDet1']):
?>
									<option value="<?php echo $this->_tpl_vars['ListDet1']['Field']; ?>
"><?php echo $this->_tpl_vars['ListDet1']['Field']; ?>
</option>	
								<?php endforeach; endif; unset($_from); ?>
						</select>
						</div>
					<?php endif; ?>
					<div class="col-sm-2 top-buffer" ><center>
					<br /><br /><br /><br /><br /><br />
					<input type="button" class="btn btn-sm btn-create m-t-n-xs" name="add" value=">>" onClick="moveOptionLeftToRight(this.form.exam16,this.form.dexam16)" id="roleadd" autocomplete="Off" ><br><br>
					<input type="button" class="btn btn-sm btn-create m-t-n-xs" name="remove" value="<<" onClick="moveOptionRightToLeft(this.form.dexam16, this.form.exam16)" id="roleremove" autocomplete="Off" >
					</center></div>
					 <?php if ($this->_tpl_vars['ListEditView']['0']['slNo'] != ""): ?>
						 <div class="col-sm-5">
				<select class="form-control input-lg" multiple="multiple" name="dexam16[]" id="dexam16" size="15" value="<?php echo $this->_tpl_vars['dexam16']; ?>
" autocomplete="Off" tabindex="5" onblur="ValidateFields1('dexam16');">
								<?php $_from = $this->_tpl_vars['groupMapping']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['ListDet2']):
?>
								<option value="<?php echo $this->_tpl_vars['ListDet2']['slNo']; ?>
"><?php echo $this->_tpl_vars['ListDet2']['menuName']; ?>
</option>	
								<?php endforeach; endif; unset($_from); ?>
						  </select>
						 </div>
					 <?php else: ?>
						 <div class="col-sm-5">
				<select class="form-control input-lg" multiple="multiple" name="dexam16[]" id="dexam16" size="15" value="<?php echo $this->_tpl_vars['dexam16']; ?>
" autocomplete="Off" tabindex="5" onblur="ValidateFields1('dexam16');">
						  </select>
						 </div>
					 <?php endif; ?>
				</div>
		</div>
	<div align="center"><center>
		<input type="submit" value="Submit" class="btn btn-create" onclick="ValidateFields();listbox_selectall('dexam16', true)" />
	</center></div>
	<br />
	</form>
	</div>
	</div>
	</section>
	</div>
	<?php echo '
	<script type="text/javascript">
	$( document ).ready(function() 
	{
	var platType = $(\'#platformType\').val();
	var slNo = $(\'#sensorModId\').val();
	if(platType != \'\'){
	$.ajax({
	type: "POST",
	url: "ajaxSenModPar.php",
	data: {platType:platType,sl_no:slNo,left:"left"},
	dataType: "JSON",
	cache: false,
	success: function(result){
	//alert(result);
	var len = result.length;
	$("#exam16").empty();
	var option;
	for( var i = 0; i<len; i++){
	var eId = result[i]["Field"];
	option +="<option value=\'"+eId+"\'>"+eId+"</option>";
	}
	$("#exam16").append(option);
	},
	error: function(result) {
	alert(\'error\');
	}
	});
	$.ajax({
	type: "POST",
	url: "ajaxSenModPar.php",
	data: {platType:platType,sl_no:slNo,right:"right"},
	dataType: "JSON",
	cache: false,
	success: function(result){
	//alert(result);
	var len = result.length;
	$("#dexam16").empty();
	var option;
	for( var i = 0; i<len; i++){
	var eId = result[i]["parameter_name"];
	option +="<option value=\'"+eId+"\'>"+eId+"</option>";
	}
	$("#dexam16").append(option);
	},
	error: function(result) {
	alert(\'error\');
	}
	});
	}
	});
	$(\'#platformType\').on(\'change\', function() {
	var platType = $(\'#platformType\').val();
	var slNo = $(\'#sensorModId\').val();
	$.ajax({
	type: "POST",
	url: "ajaxSenModPar.php",
	data: {platType:platType,sl_no:slNo,left:"left"},
	dataType: "JSON",
	cache: false,
	success: function(result){
	var len = result.length;
	$("#exam16").empty();
	var option;
	for( var i = 0; i<len; i++){
	var eId = result[i]["Field"];
	option +="<option value=\'"+eId+"\'>"+eId+"</option>";
	}
	$("#exam16").append(option);
	},
	error: function(result) {
	alert(\'error\');
	}
	});
	$.ajax({
	type: "POST",
	url: "ajaxSenModPar.php",
	data: {platType:platType,sl_no:slNo,right:"right"},
	dataType: "JSON",
	cache: false,
	success: function(result){
	var len = result.length;
	$("#dexam16").empty();
	var option;
	for( var i = 0; i<len; i++){
	var eId = result[i]["parameter_name"];
	option +="<option value=\'"+eId+"\'>"+eId+"</option>";
	}
	$("#dexam16").append(option);
	},
	error: function(result) {
	alert(\'error\');
	}
	});
	});
	function ValidateFields1(id)
	{
		var val = document.getElementById(id).value;
	if(val == \'\')
	{
	$(".error").remove();
		$("#"+id).after(\'<span class="error">This field is required</span>\');
		$("#"+id).focus();
		return false;		
	}
	else
	{
		$(".error").remove();
		return true;
	}
	}
	function ValidateFields()
	{
		var platformType = $(\'#platformType\').val();
		var dexam16 = $(\'#dexam16\').val();
	
		$(".error").remove();
	if (platformType.length < 1) {
		$(\'#platformType\').after(\'<span class="error">This field is required</span>\');
		$(\'#platformType\').focus();
		return false;					
	}
	else if(dexam16.length < 1) {
		$(\'#dexam16\').after(\'<span class="error">This field is required</span>\');
		$(\'#dexam16\').focus();
		return false;					
	}
		sensorModParMappReg.hdAction.value = 1;
		return true;
	}
	function GoBack()
	{
		window.history.back();
	}
	//*************************************swapping start*********************************************//
	function moveOptionLeftToRight(objSourceElement,objTargetElement)
	{ 
		var aryTempSourceOptions = new Array();
		var x = 0;
	
	for (var i = 0; i < objSourceElement.length; i++){
	if (objSourceElement.options[i].selected){
	if(objTargetElement.options.length > 0 && objTargetElement.options[0].text == \'None\'){
		objTargetElement.options.length = 0;		
	}
		var intTargetLen = objTargetElement.length++;
	if((objSourceElement.options[i].text=="Other")&&(objSourceElement.name=="exam16[]"))
	{
		statuschng1(\'specdosh\',objSourceElement.name,objSourceElement.options[i].value)
	}
	
		objTargetElement.options[intTargetLen].text = objSourceElement.options[i].text;
		objTargetElement.options[intTargetLen].value = objSourceElement.options[i].value;	
	}else{			
		var objTempValues = new Object();
		objTempValues.text = objSourceElement.options[i].text;
		objTempValues.value = objSourceElement.options[i].value;
		aryTempSourceOptions[x] = objTempValues;
		x++;
	}
	}
		objSourceElement.length = aryTempSourceOptions.length;	
	for (var i = 0; i < aryTempSourceOptions.length; i++) {
		objSourceElement.options[i].text = aryTempSourceOptions[i].text;
		objSourceElement.options[i].value = aryTempSourceOptions[i].value;
		objSourceElement.options[i].selected = false;
	}
	}
	function moveOptionRightToLeft(objSourceElement, objTargetElement){
		var aryTempSourceOptions = new Array();
		var x = 0;
	if(objSourceElement.options.length > 0 && objSourceElement.options[0].text == \'None\'){
		return false;
	}
	for (var i = 0; i < objSourceElement.length; i++){
	if (objSourceElement.options[i].selected){
		var intTargetLen = objTargetElement.length++;
		objTargetElement.options[intTargetLen].text = objSourceElement.options[i].text;
		objTargetElement.options[intTargetLen].value = objSourceElement.options[i].value;
	}else{			
		var objTempValues = new Object();
		objTempValues.text = objSourceElement.options[i].text;
		objTempValues.value = objSourceElement.options[i].value;
		aryTempSourceOptions[x] = objTempValues;
		x++;
	}
	}
		objSourceElement.length = aryTempSourceOptions.length;	
	for (var i = 0; i < aryTempSourceOptions.length; i++){
		objSourceElement.options[i].text = aryTempSourceOptions[i].text;
		objSourceElement.options[i].value = aryTempSourceOptions[i].value;
		objSourceElement.options[i].selected = false;
	}
	if(objSourceElement.options.length == 0){
		objSourceElement.options.length = 1;
		objSourceElement.options[0].text = \'None\';
		objSourceElement.options[0].selected = false;
	}
	}
	function listbox_selectall(listID, isSelect) {
		var listbox = document.getElementById(listID);
	for(var count=0; count < listbox.options.length; count++) {
	listbox.options[count].selected = isSelect;
	}
	}
	</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	'; ?>

	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>