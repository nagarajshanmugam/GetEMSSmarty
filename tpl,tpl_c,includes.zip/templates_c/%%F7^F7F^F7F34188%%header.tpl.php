<?php /* Smarty version 2.6.25, created on 2025-12-05 13:07:19
         compiled from header.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'date_format', 'header.tpl', 28, false),array('modifier', 'base64_encode', 'header.tpl', 62, false),)), $this); ?>
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" style="color:#FFFFFF" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block"><a class="nav-link" style="color:#FFFFFF; margin-top:-8px;font-size:16px;"><b><?php if ($this->_tpl_vars['companyDetail']['0']['companyName'] != ""): ?><?php echo $this->_tpl_vars['companyDetail']['0']['companyName']; ?>
<?php else: ?><?php echo $this->_supers['session']['CompanyName']; ?>
<?php endif; ?> - <?php if ($this->_tpl_vars['headervariable'] == 'Temperature' && $this->_supers['session']['CompanyName'] != 'Subros'): ?>Temperature Monitoring System<?php elseif ($this->_supers['session']['CompanyName'] == 'Subros'): ?>Power Factor Controller Monitoring<?php else: ?>Energy Meter Monitoring System<?php endif; ?><!--Condition Monitoring System--></b></a></li>
    
      <!--<li class="nav-item d-none d-sm-inline-block">
        <a href="#" class="nav-link">Contact</a>
      </li>-->
    </ul>

    <!-- SEARCH FORM -->
    <!--<form class="form-inline ml-3">
      <div class="input-group input-group-sm">
        <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
        <div class="input-group-append">
          <button class="btn btn-navbar" type="submit">
            <i class="fas fa-search"></i>
          </button>
        </div>
      </div>
    </form>-->

    <ul class="navbar-nav ml-auto">
	  <li class="nav-item d-none d-sm-inline-block" style="float:right">
        <a href="#" style="color:#FFFFFF; margin-top:-8px;font-size:18px;"><b><?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, "%e-%b-%Y %I:%M:%S %p") : smarty_modifier_date_format($_tmp, "%e-%b-%Y %I:%M:%S %p")); ?>
</b></a>
      </li>
      <li class="nav-item dropdown user-menu">
        <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
          <img src="./images/UserImages/<?php echo $this->_supers['session']['UserImage']; ?>
" class="user-image img-circle elevation-2" alt="User Image">
          <span class="d-none d-md-inline" style="color:#FFFFFF"><?php echo $this->_supers['session']['UserName']; ?>
</span>
        </a>
        <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <!-- User image -->
          <li class="user-header">
            <img src="./images/UserImages/<?php echo $this->_supers['session']['UserImage']; ?>
" class="img-circle elevation-2" alt="User Image">

            <p style="color:#FFFFFF">
              <?php echo $this->_supers['session']['UserName']; ?>

             <!-- <small>Member since Nov. 2012</small> -->
            </p>
          </li>
          <!-- Menu Body -->
          <!--<li class="user-body">-->
            <!--<div class="row">
              <div class="col-4 text-center">
                <a href="#">Followers</a>
              </div>
              <div class="col-4 text-center">
                <a href="#">Sales</a>
              </div>
              <div class="col-4 text-center">
                <a href="#">Friends</a>
              </div>
            </div>-->
            <!-- /.row -->
         <!-- </li>-->
          <!-- Menu Footer-->
          <li class="user-footer">
            <a href="profile.php?userId=<?php echo ((is_array($_tmp=$this->_supers['session']['User_ID'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
&Update=p" class="btn btn-default btn-flat">Update Profile</a>
            <a href="logout.php" class="btn btn-default btn-flat float-right">Sign out</a>
          </li>
        </ul>
      </li>
    </ul>
  </nav>
  <?php echo '
  
<style>
.main-header,.user-header{
/*background-color:#3c8dbc;*/
background-color:#17a2b8;;
}
</style>


 
'; ?>
