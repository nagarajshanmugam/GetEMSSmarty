<?php /* Smarty version 2.6.25, created on 2026-01-27 14:33:53
         compiled from addEditSensorModelParameter.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'date_format', 'addEditSensorModelParameter.tpl', 94, false),)), $this); ?>
	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
			<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;"><?php if ($this->_tpl_vars['companyDetail']['0']['companyName'] != ""): ?><?php echo $this->_tpl_vars['companyDetail']['0']['companyName']; ?>
<?php else: ?><?php echo $this->_supers['session']['CompanyName']; ?>
<?php endif; ?>&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				
			    <td style="font-size:15PX;font-weight: bold;"><?php if ($this->_tpl_vars['GetModelName']['0']['model_name'] != ""): ?><?php echo $this->_tpl_vars['GetModelName']['0']['model_name']; ?>
<?php endif; ?>&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				
				<?php if ($this->_supers['get']['sl_no'] != ""): ?>
			<td style="font-size:15PX;font-weight: bold;"><?php echo $this->_tpl_vars['ListParameterEditView']['0']['parameter_name']; ?>
&nbsp;&nbsp;</td>
		
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
			<?php endif; ?>
			<td style="font-size:15PX;font-weight: bold;"><?php if ($this->_supers['get']['sl_no'] == ""): ?>Create <?php else: ?>Edit <?php endif; ?> Parameter</font>&nbsp;</td></tr>
				<td style="color:#999999;font-size:10PX;"></td>
			     </tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:10PX;color:#999999;">Sensor Model Name</td>
				<?php if ($this->_supers['get']['sl_no'] != ""): ?>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:10PX;color:#999999;">Parameter Name</td>
				<?php endif; ?>
			
				</tr>
				</table>
			<a href="sensorModelParameterList.php?sen_model=<?php echo $this->_supers['get']['sen_model']; ?>
"><button type="button" style="float:right;margin-top:-40Px" class="btn btn-primary">List Sensor Model Parameter</button></a>
			</div>
		</div>
		<div class="card">
		<?php if ($this->_tpl_vars['SuccessMessage'] != ""): ?>
			<div class="card-body">
				<div class="isa_success">
				<i class="fa fa-check"></i>
				<?php echo $this->_tpl_vars['SuccessMessage']; ?>
		 
				</div>
			</div>
		<?php endif; ?>
		<?php if ($this->_tpl_vars['ErrorMessage'] != ""): ?>
			<div class="card-body">
				<div class="isa_error">
				<i class="fa fa-check"></i>
				<?php echo $this->_tpl_vars['ErrorMessage']; ?>
		 
				</div>
			</div>
		<?php endif; ?> 
			<div class="card-body">
				<form role="form" name="sensorModelParameterForm" id="sensorModelParameterForm" method="post" onsubmit="return createValidation();" >
					<input type="hidden" name="hdAction" />
					<input type="hidden" id="company_id" name="company_id" value="<?php echo $this->_supers['get']['companyId']; ?>
" />
					<input type="hidden" id="check_id" name="check_id" value="<?php echo $this->_supers['post']['check_id']; ?>
">
					<input type="hidden" id="checkVal" name="checkVal" value="<?php echo $this->_supers['post']['checkVal']; ?>
" />
					<div class="row">					
						<div class="form-group col-md-6" style="margin-top:-5PX">
							<label for="exampleInputgatewayId">Parameter Name <span style="color:red;">*</span></label>
	<input type="text" class="form-control form-control-sm" id="parameterName" name="parameterName" placeholder="Enter Parameter Name" value="<?php if ($this->_tpl_vars['ListParameterEditView']['0']['parameter_name'] != ''): ?><?php echo $this->_tpl_vars['ListParameterEditView']['0']['parameter_name']; ?>
<?php else: ?><?php echo $this->_supers['post']['parameterName']; ?>
<?php endif; ?>" tabindex="2">
						</div>
						<div class="form-group col-md-6">
						<label for="exampleInputmodel">Data Type <span style="color:red;">*</span></label>
						<select  id="dataType" name="dataType" class="form-control form-control-sm"  tabindex="7" onchange="GetDataLength(this.value);">
						<option value="0" >--- Select Data Type ----</option>
						<?php $_from = $this->_tpl_vars['DataTypeExe']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['dataT']):
?>
                        <option value="<?php echo $this->_tpl_vars['dataT']['sl_no']; ?>
|<?php echo $this->_tpl_vars['dataT']['length']; ?>
" <?php if ($this->_tpl_vars['ListParameterEditView']['0']['data_type'] == $this->_tpl_vars['dataT']['data_type']): ?> selected<?php endif; ?> ><?php echo $this->_tpl_vars['dataT']['data_type']; ?>
</option>
						<?php endforeach; endif; unset($_from); ?>
                        
						</select>
						</div>
						<div class="form-group col-md-6" style="margin-top:-5PX">
							<label for="exampleInputgatewayId">Length <span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm" id="parameterLength" name="parameterLength" placeholder="Enter Parameter Length" value="<?php if ($this->_tpl_vars['ListParameterEditView']['0']['data_length'] != ''): ?><?php echo $this->_tpl_vars['ListParameterEditView']['0']['data_length']; ?>
<?php else: ?><?php echo $this->_supers['post']['parameterLength']; ?>
<?php endif; ?>"  tabindex="2">
						</div>
                        
                        <div class="form-group col-md-6">
						<div class="form-group" style="margin-top:-5PX">
							<label for="exampleInputgatewayId">Priority <span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm" id="priority" name="priority" placeholder="Enter Parameter Priority" value="<?php if ($this->_tpl_vars['ListParameterEditView']['0']['priority'] != ''): ?><?php echo $this->_tpl_vars['ListParameterEditView']['0']['priority']; ?>
<?php else: ?><?php echo $this->_supers['post']['priority']; ?>
<?php endif; ?>">
						</div>
							<div class="custom-control custom-checkbox">
							<?php if ($this->_tpl_vars['ListParameterEditView']['0']['is_active'] == '1'): ?>
								<input class="custom-control-input" type="checkbox" id="customCheckbox2"  name="customCheckbox2" tabindex="12" checked="checked">
								<label for="customCheckbox2" class="custom-control-label">Is Active</label>
							<?php elseif ($this->_tpl_vars['ListParameterEditView']['0']['is_active'] == '0'): ?>
								<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="12">
								<label for="customCheckbox2" class="custom-control-label">Is Active</label>
							<?php else: ?>
								<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="12" checked="checked">
								<label for="customCheckbox2" class="custom-control-label">Is Active</label>
							<?php endif; ?>
							</div>
							<input id="created_by" name="created_by" class="date-picker form-control" type="hidden" value="<?php echo $this->_supers['session']['UserName']; ?>
" readonly="true">
							<input type="hidden" class="form-control" id="created_date_time" name="created_date_time" value="<?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d  %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d  %H:%M:%S')); ?>
">
							<input type="hidden" class="form-control" id="created_time" name="created_time" placeholder="Time" Value="<?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%I:%M:%S %p') : smarty_modifier_date_format($_tmp, '%I:%M:%S %p')); ?>
">
						</div>					
						
					</div>
					<div align="center">
					<input type="submit" value="Submit" class="btn btn-create" />
					</div>
				</form>
			</div>
		</div>
	</div>
	</section>
	</div>
	<?php echo '
	<script type="text/javascript">
	function createValidation()
	{
		var parameterName = $(\'#parameterName\').val();
		var dataType = $(\'#dataType\').val();
		var priority = $(\'#priority\').val();
	
		var isActive = document.getElementById("customCheckbox2").checked;
	
	if (isActive == false) 
	{
		document.getElementById(\'checkVal\').value=\'0\';
	}
	else
	{
		document.getElementById(\'checkVal\').value=\'1\';
	}
		$(".error").remove();
	if (parameterName < 1) {
		$(\'#parameterName\').after(\'<span class="error">This field is required</span>\');
		$(\'#parameterName\').focus();
		return false;					
	}
	else if (dataType == 0) {
		$(\'#dataType\').after(\'<span class="error">This field is required</span>\');
		$(\'#dataType\').focus();
		return false;					
	}
	else if (priority < 1) {
		$(\'#priority\').after(\'<span class="error">This field is required</span>\');
		$(\'#priority\').focus();
		return false;					
	}
	
		FormName		= document.sensorModelParameterForm;
		FormName.method	= "POST";
		FormName.submit();
	}
	
	function GoBack()
	{
		window.history.back();
	}
	
	function GetDataLength(cval)
	{
	var dataVal = cval;
	// Split the string by the | symbol
	var splitArray = dataVal.split(\'|\');
	if(splitArray[1] != \'\' && splitArray[0] != 0){
	document.getElementById(\'parameterLength\').value = splitArray[1];
	}else{
	document.getElementById(\'parameterLength\').value = \'\';
	}
	
	}
	</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	'; ?>

	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>