<?php /* Smarty version 2.6.25, created on 2025-11-11 14:51:39
         compiled from companyList.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'base64_encode', 'companyList.tpl', 59, false),)), $this); ?>
    <div class="content-wrapper">
	<section class="content-header">
	  <div class="card">
		 <div class="card-header">
			<table style="margin-bottom:-10px;">
			<tr><td style="font-size:15PX;font-weight: bold;">List Company</font>&nbsp;</td></tr>
			<tr><td style="color:#999999;font-size:10PX;">&nbsp;</td><td>&nbsp;</td></tr>
			</table>
		 </div>
	  </div>
		<div class="row">
			<div class="col-12">
				<div class="card">
				<?php if ($this->_tpl_vars['SuccessMessage'] != ""): ?>
					<div class="card-body">
					<div class="isa_success">
					<i class="fa fa-check"></i>
					<?php echo $this->_tpl_vars['SuccessMessage']; ?>
		 
					</div>
					</div>
				<?php endif; ?>
				<?php if ($this->_tpl_vars['ErrorMessage'] != ""): ?>
					<div class="card-body">
					<div class="isa_error">
					<i class="fa fa-check"></i>
					<?php echo $this->_tpl_vars['ErrorMessage']; ?>
		 
					</div>
					</div>
				<?php endif; ?>
					<div class="card-body table-responsive">
					<a href="AddEditcompany.php"> <button type="button" class="btn btn-create" value="Create Userrole" style="float:right;margin-top:-6PX">Create Company</button></a>
						<form name="companyList" id="companyList" method="post">
							<table id="example" class="table table-hover table-bordered">
							<thead>
							<tr>
							<th class="slno">#</th>
							<th>Company Code</th>
							<th>Company Name</th>
							<th>Contact Person</th>
							<th>Phone</th>
							<th>User</th>
							<th>SMS</th>
							<th>Status</th>
							<th>Action</th>
							</tr>
							</thead>
							<tbody>
							<?php $_from = $this->_tpl_vars['ListView']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['master_dtls']):
?>
							<tr id="<?php echo $this->_tpl_vars['i']++; ?>
">
							<td class="slNo"><?php echo $this->_tpl_vars['i']; ?>
</td>
							<td class="code"><?php echo $this->_tpl_vars['master_dtls']['companyCode']; ?>
</td>
							<td class="name"><?php echo $this->_tpl_vars['master_dtls']['companyName']; ?>
</td>
							<td class="text_left"><?php echo $this->_tpl_vars['master_dtls']['contactPerson']; ?>
</td>
							<td class="phone"><?php if ($this->_tpl_vars['master_dtls']['phone'] != ""): ?><?php echo $this->_tpl_vars['master_dtls']['phone']; ?>
<?php else: ?><center>-</center><?php endif; ?></td>
							<td class="limit"><?php echo $this->_tpl_vars['master_dtls']['userLimit']; ?>
</td>
							<td class="limit"><?php echo $this->_tpl_vars['master_dtls']['smsLimit']; ?>
</td>
							<td class="isactive"><?php if ($this->_tpl_vars['master_dtls']['isActive'] == '1'): ?><span style="color:#009900"><b>Active</b></span><?php else: ?><span style="color:#FF0033;"><b>Inactive</b></span><?php endif; ?></td>
							<td class="amount">
							<a href="companyDashboard.php?companyId=<?php echo ((is_array($_tmp=$this->_tpl_vars['master_dtls']['slNo'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
"  title="Visit <?php echo $this->_tpl_vars['master_dtls']['companyName']; ?>
 Dashboard" target="_blank"><i class="fa fa-cloud"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
							<a href="userList.php?companyId=<?php echo ((is_array($_tmp=$this->_tpl_vars['master_dtls']['slNo'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
" title="List User"><i class="fa fa-user"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
							<a href="#" onClick="Javascript:branchCats('<?php echo $this->_tpl_vars['master_dtls']['slNo']; ?>
')" title="List Branch"><i class="fas fa-code-branch"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
							<a href="#" onclick="Javascript:editCats('<?php echo $this->_tpl_vars['master_dtls']['slNo']; ?>
')" title="Edit"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
							<a href="#" onClick="Javascript:deleteCats('<?php echo $this->_tpl_vars['master_dtls']['slNo']; ?>
')" title="Delete"><i class="fa fa-trash"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;		     
							</td>
							</tr>
							<?php endforeach; else: ?>
							<tr><td colspan="10"><center>No Records Found</center></td></tr>
							<?php endif; unset($_from); ?>
							</tbody>
							</table>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
    </div>
	<?php echo '
		<script type="text/javascript">
		$(document).ready(function (){
		
		var table = $(\'#example\').DataTable({
		"ordering" : false,
		language: {
		"infoFiltered": "",
		search: "_INPUT_",
		searchPlaceholder: "Search..."
		},
		dom: \'<"pull-left" f><bottom>p\',
		tableTools: {
		"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
		},
		//dom: \'<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p\',
		//dom: \'<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p\',
		buttons: [
		{
		text: \'Create Box\',
		className: \'btn btn-create\',
		titleAttr: \'Create Box\',
		action: function ( e, dt, button, config ) {
		window.location = \'AddEditBox.php\';
		}        
		}
		],
		initComplete: function(){
		$("div.toolbar").html(\'<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>\');   
		
		
		}       
		}); 
		
		}); 
		
		function branchCats(compIdent) {
		var comId = btoa(compIdent);
		FormName		= document.companyList;
		FormName.action =\'branchList.php?companyId=\'+comId;
		FormName.submit();
		}
		function editCats(slNoIdent) {
		var sid = btoa(slNoIdent);
		FormName		= document.companyList;
		FormName.action =\'AddEditcompany.php?companyId=\'+sid+\'&Update=y\';
		FormName.submit();
		}
		function deleteCats(CatIdent){
		if(confirm("Are you sure to Delete this Content?")){
		FormName		= document.companyList;
		FormName.action= "companyList.php?cId="+CatIdent;
		FormName.submit();
		}
		}
		</script>
		<script>
		$(function () {
		$("#example1").DataTable();
		$(\'#example2\').DataTable({
		"paging": true,
		"lengthChange": false,
		"searching": false,
		"ordering": true,
		"info": true,
		"autoWidth": false,
		});
		});
		</script>
		<style>
		.slNo{
		width:5%;
		}
		.code{
		width:10%;
		}
		.name{
		width:20%;
		}
		.limit{
		width:5%;
		}
		.phone{
		width:10%;
		}
		.isactive{
		width:10%;
		text-align:center;
		
		}
		.action{
		text-align:right;
		}
		
		.isa_success
		{
		color:#4F8A10;
		background-color:#DFF2BF;
		}
		.error
		{
		color:#D8000C;
		/*background-color:#FFBABA;*/
		}
		.isa_error
		{
		color:#D8000C;
		background-color:#FFBABA;
		}
		.isa_success i,.isa_error i
		{
		margin:10px 22px;
		font-size:2em;
		/*vertical-align:middle;*/
		}
		
		</style>
	'; ?>

	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>