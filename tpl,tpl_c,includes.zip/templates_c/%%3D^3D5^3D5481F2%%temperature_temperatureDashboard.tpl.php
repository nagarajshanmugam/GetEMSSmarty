<?php /* Smarty version 2.6.25, created on 2026-07-08 16:11:28
         compiled from temperature_temperatureDashboard.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'base64_encode', 'temperature_temperatureDashboard.tpl', 68, false),array('modifier', 'date_format', 'temperature_temperatureDashboard.tpl', 75, false),)), $this); ?>
<?php echo '
<script type="text/javascript">
     function secondsToDhms(seconds,v) {//alert(seconds);
var seconds = Number(seconds);
var d = Math.floor(seconds / (3600*24));
var h = Math.floor(seconds % (3600*24) / 3600);
var m = Math.floor(seconds % 3600 / 60);
var s = Math.floor(seconds % 60);

var dDisplay = d > 0 ? d + (d == 1 ? " day, " : " days, ") : "";
var hDisplay = h > 0 ? h + (h == 1 ? " hr, " : " hrs, ") : "";
var mDisplay = m > 0 ? m + (m == 1 ? " min, " : " min\'s, ") : "";
var sDisplay = s > 0 ? s + (s == 1 ? " sec" : " sec\'s") : "";
//var res= \'Last Updated\' + \' \' + dDisplay + hDisplay + mDisplay + sDisplay;
var res= dDisplay + hDisplay + mDisplay + sDisplay;
document.getElementById(v).innerHTML=res;
}

 </script>
 <style type="text/css">
     .padclass
	{
	    padding-top:18px;
	    padding-bottom:3px;
	}
 </style>
 
'; ?>

	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<body onLoad="doOnLoad();">
	<div class="content-wrapper">
	<div class="content-header">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-body">
						<table style="margin-bottom:-10px;">
						<tr><td style="font-size:15PX;font-weight: bold;"><?php if ($this->_tpl_vars['companyDetail']['0']['companyName'] != ""): ?><?php echo $this->_tpl_vars['companyDetail']['0']['companyName']; ?>
<?php else: ?><?php echo $this->_supers['session']['CompanyName']; ?>
<?php endif; ?>&nbsp;&nbsp;</td>
						<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
						<td style="font-size:15PX;font-weight: bold;"><?php echo $this->_tpl_vars['branchDetail']['0']['branch_name']; ?>
&ensp;&ensp;</td>
						<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
						<td style="font-size:15PX;font-weight: bold;">Temperature  <!---(<?php echo $this->_tpl_vars['LoctList']['0']['gateway_id']; ?>
 / <?php echo $this->_tpl_vars['LoctList']['0']['sensorCode']; ?>
)--></font>&nbsp;</td></tr>
						<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
						<td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
						<td style="font-size:10PX;color:#999999;">Branch Name</td>
						<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
						<td style="color:#999999;font-size:10PX;">Dashboard</td><td>&nbsp;</td>
						</tr>
						</table>
					</div>
				</div>
			</div>
		</div>
        
       <!-- <textarea id="currMonQut" name="currMonQut"  style="display:none;"><?php echo $this->_tpl_vars['getCurMonQut']; ?>
</textarea>-->
        
        
        <div class="row">        

            <?php $_from = $this->_tpl_vars['TempList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['List']):
?>
            <tr id="<?php echo $this->_tpl_vars['j']++; ?>
">
          <div class="col-md-3">
            <!-- Box Comment -->
            <div class="card card-widget card-primary">
              <div class="card-header" style="margin-bottom:-15px;">
                <div class="card-title">
                  <center><span class="username"><b><a href="DashboardTemperature.php?companyId=<?php if ($this->_supers['get']['companyId'] != ""): ?><?php echo $this->_supers['get']['companyId']; ?>
<?php else: ?><?php echo ((is_array($_tmp=$this->_supers['session']['CustomerId'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
<?php endif; ?>&branchId=<?php if ($this->_supers['get']['branchId'] != ""): ?><?php echo $this->_supers['get']['branchId']; ?>
<?php else: ?><?php echo ((is_array($_tmp=$this->_supers['session']['branch_id'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
<?php endif; ?>&sensorCode=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['sensor_code'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
&gatewayCode=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['gateway_code'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
"><?php echo $this->_tpl_vars['List']['feeder_name']; ?>
</a></b></span></center>
                </div>
              </div>
              
              <div class="card-body">
                  
              
			 <!-- <?php echo ((is_array($_tmp=$this->_tpl_vars['ListIncidentLog']['posted_date_time'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%H:%M %S") : smarty_modifier_date_format($_tmp, "%H:%M %S")); ?>

			  <?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, "%H:%M:%S") : smarty_modifier_date_format($_tmp, "%H:%M:%S")); ?>
--->
			  <?php if ($this->_tpl_vars['List']['secs'] < '2100' && $this->_tpl_vars['List']['secs'] != ''): ?>
                <div class="row">
                    <?php if ($this->_tpl_vars['List']['TemHum'] == 'Both'): ?>
                  <div class="col-sm-6">
                    <div class="description-block">
                         <img class="img-circle elevation-2" src="./images/temperature.jpg" alt="User Image" width="70" height="70">
                      <h5 class="description-header" style="color:#15b5f0;padding-top:6px;"><b><?php echo $this->_tpl_vars['List']['temperature_c']; ?>
 &deg; C</b></h5>
                      <span class="description-text"></span>
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="description-block">
                        <img class="img-circle elevation-2" src="./images/humidity.jpg" alt="User Image" width="70" height="70">
                      <h5 class="description-header" style="color:#7db616;padding-top:6px;"><b><?php echo $this->_tpl_vars['List']['humidity']; ?>
 %</b></h5>
                      <span class="description-text"></span>
                    </div>
                  </div>
                  <?php endif; ?>
				  <?php if ($this->_tpl_vars['List']['TemHum'] == 'Temperature'): ?>
                  <div class="col-sm-12">
                    <div class="description-block">
                         <img class="img-circle elevation-2" src="./images/temperature.jpg" alt="User Image" width="70" height="70">
                      <h5 class="description-header" style="color:#15b5f0;padding-top:6px;"><b><?php echo $this->_tpl_vars['List']['temperature_c']; ?>
 &deg; C</b></h5>
                      <span class="description-text"></span>
                    </div>
                  </div>
                  <?php endif; ?>
				  <?php if ($this->_tpl_vars['List']['TemHum'] == 'Humidity'): ?>
                  <div class="col-sm-12">
                    <div class="description-block">
                        <img class="img-circle elevation-2" src="./images/humidity.jpg" alt="User Image" width="70" height="70">
                      <h5 class="description-header" style="color:#7db616;padding-top:6px;"><b><?php echo $this->_tpl_vars['List']['humidity']; ?>
 %</b></h5>
                      <span class="description-text"></span>
                    </div>
                  </div>
                  <?php endif; ?>
                </div>
				
               
                <center ><b><span class="text-muted" style="margin-bottom:-15px;margin-top:-5px;" id="<?php echo $this->_tpl_vars['j']; ?>
" ><script type="text/javascript">secondsToDhms('<?php echo $this->_tpl_vars['List']['secs']; ?>
','<?php echo $this->_tpl_vars['j']; ?>
');</script> ago</span></b></center>
				<?php else: ?>
				<div class="row overlay ">
                    <?php if ($this->_tpl_vars['List']['TemHum'] == 'Both'): ?>
                  <div class="col-sm-6 overlay ">
                    <div class="description-block">
                         <img class="img-circle elevation-2" src="./images/temperatureCrayScale.png" alt="User Image" width="70" height="70">
                      <h5 class="description-header" style="color:#15b5f0;padding-top:6px;"><b></b></h5>
                      <span class="description-text"></span>
                    </div>
                  </div>
                  <div class="col-sm-6 overlay">
                    <div class="description-block">
                        <img class="img-circle elevation-2" src="./images/humidityGrayScale.png" alt="User Image" width="70" height="70">
                      <h5 class="description-header" style="color:#7db616;padding-top:6px;"><b></b></h5>
                      <span class="description-text"></span>
                    </div>
                  </div>
                  <?php endif; ?>
				  <?php if ($this->_tpl_vars['List']['TemHum'] == 'Temperature'): ?>
                  <div class="col-sm-12 overlay">
                    <div class="description-block">
                         <img class="img-circle elevation-2 " src="./images/temperatureCrayScale.png" alt="User Image" width="70" height="70">
                      <h5 class="description-header" style="color:#15b5f0;padding-top:6px;"><b></b></h5>
                      <span class="description-text"></span>
                    </div>
                  </div>
                  <?php endif; ?>
				  <?php if ($this->_tpl_vars['List']['TemHum'] == 'Humidity'): ?>
                  <div class="col-sm-12 overlay ">
                    <div class="description-block">
                        <img class="img-circle elevation-2 " src="./images/humidityGrayScale.png" alt="User Image" width="70" height="70">
                      <h5 class="description-header" style="color:#7db616;padding-top:6px;"><b></b></h5>
                      <span class="description-text"></span>
                    </div>
                  </div>
                  <?php endif; ?>
                </div>
				
               <br>
                <center ><b><span class="text-muted" style="margin-bottom:-15px;margin-top:-5px;" id="<?php echo $this->_tpl_vars['j']; ?>
" >Sensor Off Status</span></b></center>
				<?php endif; ?>
              </div>
              
              <div class="card-footer card-comments">
                  <div class="comment-text" ><span class="username" style="color:#15b5f0; margin-top:-5px;"><!--<b>Latest Incidents</b>--></span></div>
               <?php $_from = $this->_tpl_vars['allincidentList'][$this->_tpl_vars['List']['sensor_code']]; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['ListIncidentLog']):
?>
    <?php if ($this->_tpl_vars['ListIncidentLog']['sensor_code'] == $this->_tpl_vars['List']['sensor_code']): ?>
        <div class="card-comment">
            <div class="comment-text" style="margin:-5px;">
                <span class="username">
                    <?php echo $this->_tpl_vars['ListIncidentLog']['sensor_code']; ?>

                    <span class="text-muted float-right">
                        <?php echo ((is_array($_tmp=$this->_tpl_vars['ListIncidentLog']['posted_date_time'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%e-%b-%Y %I:%M %p") : smarty_modifier_date_format($_tmp, "%e-%b-%Y %I:%M %p")); ?>

                    </span>
                </span>

                <?php if ($this->_tpl_vars['List']['TemHum'] == 'Both'): ?>
                    T - <?php echo $this->_tpl_vars['ListIncidentLog']['temperature_c']; ?>
 &deg; C &nbsp;&nbsp;&nbsp;&nbsp;
                    H - <?php echo $this->_tpl_vars['ListIncidentLog']['humidity']; ?>
 %
                <?php endif; ?>

                <?php if ($this->_tpl_vars['List']['TemHum'] == 'Temperature'): ?>
                    T - <?php echo $this->_tpl_vars['ListIncidentLog']['temperature_c']; ?>
 &deg; C
                <?php endif; ?>

                <?php if ($this->_tpl_vars['List']['TemHum'] == 'Humidity'): ?>
                    H - <?php echo $this->_tpl_vars['ListIncidentLog']['humidity']; ?>
 %
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
<?php endforeach; endif; unset($_from); ?>
              </div>
              
              <div class="card-footer">
                   <center> <span>
                      <a href="DashboardTemperature.php?companyId=<?php if ($this->_supers['get']['companyId'] != ""): ?><?php echo $this->_supers['get']['companyId']; ?>
<?php else: ?><?php echo ((is_array($_tmp=$this->_supers['session']['CustomerId'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
<?php endif; ?>&branchId=<?php if ($this->_supers['get']['branchId'] != ""): ?><?php echo $this->_supers['get']['branchId']; ?>
<?php else: ?><?php echo ((is_array($_tmp=$this->_supers['session']['branch_id'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
<?php endif; ?>&sensorCode=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['sensor_code'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
&gatewayCode=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['gateway_code'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
"><button type="submit" class="btn btn-success">View More</button></a>
                    </span></center>
              </div>
             
            </div>
            <!-- /.card -->
          </div>
          </tr>
          <?php endforeach; endif; unset($_from); ?>
          <!-- /.col -->
        </div>
    
    
    <div class="row">
			<div class="col-md-10">
            <div class="card card-outline card-primary">
            <div class="card-header">
						<h3 class="card-title">
						<i class="fa fa-list"></i>
						&nbsp;&nbsp;List of Temperature Sensor
						</h3>
						
						</div>
               <div class="card-body table-responsive no-padding">
			 <div class="row">
<input type="hidden" id="cid" name="cid" value="<?php if ($this->_supers['get']['companyId'] != ""): ?><?php echo $this->_supers['get']['companyId']; ?>
<?php else: ?><?php echo $this->_supers['session']['customerId']; ?>
<?php endif; ?>" />
				<input type="hidden" id="bid" name="bid" value="<?php echo $this->_supers['get']['branchId']; ?>
" />
				<input type="hidden" value="<?php echo $this->_tpl_vars['Dashboard']['0']['segmentName']; ?>
" />
    <div id="list_books" class="col-12">
			  <table id="example" class="table table-bordered table-hover">
                <thead>
                <tr>
    			  <th class="slNo" rowspan="2" >#</th>
                  <th class="name" rowspan="2">Place Of Installation</th>
                  <th class="gate" rowspan="2">Gateway</th>
				   <!--<th class="status" rowspan="2">Status</th>-->
                  <th  colspan="2" class="code" >Temperature</th>
                   <th  class="status" rowspan="2">Humidity</th>
                  <th class="action" rowspan="2">Date Time</th>
                  <th class="last" rowspan="2">Last Comm</th>
                  
          
                </tr>
                <tr>
    			 
                  <th class="cost">&deg; C</th>
                  <th class="cost" >&deg; F</th>
                  
                </tr>
                </thead>
                <tbody>
				<?php $_from = $this->_tpl_vars['TempList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['List']):
?>
                <?php $this->assign('pid', ((is_array($_tmp=$this->_tpl_vars['List']['feeder_master_id'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp))); ?>
                <tr id="<?php echo $this->_tpl_vars['k']++; ?>
">
				 <td ><?php echo $this->_tpl_vars['k']; ?>
</td>
				 	
                 <td><a href="DashboardTemperature.php?companyId=<?php if ($this->_supers['get']['companyId'] != ""): ?><?php echo $this->_supers['get']['companyId']; ?>
<?php else: ?><?php echo ((is_array($_tmp=$this->_supers['session']['CustomerId'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
<?php endif; ?>&branchId=<?php if ($this->_supers['get']['branchId'] != ""): ?><?php echo $this->_supers['get']['branchId']; ?>
<?php else: ?><?php echo ((is_array($_tmp=$this->_supers['session']['branch_id'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
<?php endif; ?>&sensorCode=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['sensor_code'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
&gatewayCode=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['gateway_code'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
" style="text-decoration:underline;color:#000000;" title="Meter Details" ><?php echo $this->_tpl_vars['List']['feeder_name']; ?>
</a><?php $_from = $this->_tpl_vars['selQryS']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['sub']):
?><?php if ($this->_tpl_vars['List']['feeder_type'] == 'Main Meter' && $this->_tpl_vars['List']['slNo'] == $this->_tpl_vars['sub']['parent_id']): ?>&ensp;&ensp;<a href="subdashboard.php?parent_id=<?php echo $this->_tpl_vars['pid']; ?>
&companyId=<?php echo $this->_supers['get']['companyId']; ?>
&branchId=<?php echo $this->_supers['get']['branchId']; ?>
"><i class="fa fa-sitemap" aria-hidden="true" title="Submeter List"></i></a><?php endif; ?><?php endforeach; endif; unset($_from); ?></td>
                 <td ><?php echo $this->_tpl_vars['List']['gateway_code']; ?>
</td>
            <td align="right">
                <?php if (isset ( $this->_tpl_vars['List']['temperature_c'] ) && $this->_tpl_vars['List']['temperature_c'] != ''): ?>
                    <?php echo $this->_tpl_vars['List']['temperature_c']; ?>

                <?php else: ?>
                    -
                <?php endif; ?>
                 </td>
            <td align="right">
                <?php if (isset ( $this->_tpl_vars['List']['temperature_f'] ) && $this->_tpl_vars['List']['temperature_f'] != ''): ?>
                    <?php echo $this->_tpl_vars['List']['temperature_f']; ?>

                <?php else: ?>
                    -
                <?php endif; ?>
                 </td>
                 <td align="right">
                <?php if (isset ( $this->_tpl_vars['List']['humidity'] ) && $this->_tpl_vars['List']['humidity'] != ''): ?>
                    <?php echo $this->_tpl_vars['List']['humidity']; ?>

                <?php else: ?>
                    -
                <?php endif; ?>
                 </td>               
				  <td><?php echo ((is_array($_tmp=$this->_tpl_vars['List']['posted_date_time'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%d-%b-%Y %I:%M:%S %p") : smarty_modifier_date_format($_tmp, "%d-%b-%Y %I:%M:%S %p")); ?>
</td>
		       <td id="t<?php echo $this->_tpl_vars['k']; ?>
"><script type="text/javascript">secondsToDhms('<?php echo $this->_tpl_vars['List']['secs']; ?>
','t<?php echo $this->_tpl_vars['k']; ?>
');</script> ago</td>
			   
            
                </tr>
                <?php endforeach; else: ?>
                <tr><td colspan="8"><center>No Records Found</center></td></tr>
                <?php endif; unset($_from); ?>
               
               
                </tbody>
                
              </table>
			  </div>
</div>
</div>
<div class="card-body table-responsive">
            <div class="row">
        </div>
        </div>
      </div>
    </div>
	<div class="col-md-2">
			<div class="card card-primary card-outline">
			<div class="card-header">
			<h3 class="card-title">Gateway List</h3>
			</div>
			<div class="card-body p-0">
			<ul class="products-list product-list-in-card pl-2 pr-2">
			
			<?php $_from = $this->_tpl_vars['TempList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['List']):
?>
			<?php $_from = $this->_tpl_vars['gateList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['gate']):
?>
			 <?php if ($this->_tpl_vars['List']['gateway_code'] != $this->_tpl_vars['gatewayCode']): ?>
			<li class="item">
			<?php echo $this->_tpl_vars['gate']['gateway_code']; ?>

			<?php if ($this->_tpl_vars['gate']['gateway_code'] == $this->_tpl_vars['List']['gateway_code'] && $this->_tpl_vars['gate']['gateway_date_time'] >= ((is_array($_tmp=$this->_tpl_vars['dateSec'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d %H:%M:%S'))): ?>
                <span class="badge badge-success float-right"> 
                ON
				</span>
                 <?php $this->assign('tog', '1'); ?>
                <?php elseif ($this->_tpl_vars['gate']['gateway_code'] == $this->_tpl_vars['List']['gateway_code'] && $this->_tpl_vars['gate']['gateway_date_time'] < ((is_array($_tmp=$this->_tpl_vars['dateSec'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d %H:%M:%S'))): ?>
                 <span class="badge badge-danger float-right">
                OFF
				</span>
                 <?php $this->assign('tog', '1'); ?>
                <?php endif; ?>
			</li>
				
				<?php endif; ?>
               <?php $this->assign('gatewayCode', $this->_tpl_vars['List']['gateway_code']); ?>
                <?php endforeach; endif; unset($_from); ?>
				<?php endforeach; endif; unset($_from); ?>
				<?php $this->assign('tog', ''); ?>
			</ul>
			</div>
		<!--	<div class="card-footer text-center">
			<a href="listIncidentLog.php" class="uppercase">View All Incidents</a>
			</div> -->
			</div>
			</div>
  </div>
    
	</div>
	</div>
	</div>
	</body>
	<?php echo '
    
	<style>
.slNo
 {
 width:3%;
 }
 .name
 {
 width:18%;
 }
 .gate
 {
 width:10%;
 }
 .status
 {
 width:5%;
 }
 .code
 {
 width:10%;
 }
 .cost
 {
 width:5%;
 }
 .action
 {
 width:15%;
 }
 .last
 {
 width:11%;
 }
 .uline
 {
 text-decoration:underline;
 }
	 #barChart2 {
	width	: 100%;
	height	: 450px;
	}
	</style>
	<script type="text/javascript">
 function doOnLoad()
 {
 setInterval(Add_Item, 3000);
 }
 </script>
      <script type="text/javascript">
	function Add_Item()
{
var cid =$(\'#cid\').val() ;
var bid =$(\'#bid\').val() ;//alert(bid)
$.ajax({
		type: "POST",
		url: "getTemptable.php",
		data: {cid:cid,bid:bid},
		success: function(data) {
		$("#list_books").html(data);
		}
		});
}
	</script>
    <!--<script type="text/javascript">
var result = document.getElementById(\'currMonQut\').value;

var jsonData=result;
var obj = JSON.parse(jsonData);
var mon = "";
var dataVal = "";
var dataVal1 = "";
var colo = "";
var i;
for (i = 0; i < obj.length; i++) {
if(i==0){
  mon += obj[i].month ;
  dataVal += obj[i].value;
  dataVal1 += obj[i].value1;
   colo += obj[i].color;
   }
  else
  {
  mon += ", "+ obj[i].month;
  dataVal += ", "+ obj[i].value;
   dataVal1 += ", "+ obj[i].value1;
   colo += \', \'+ obj[i].color;
 }
}
// loop  variable concatinate each  record  as an array
var monthVal = mon;
var dataValue =dataVal;
var dataValue1 =dataVal1;
var colors =colo;


// above mentioned  array variable  split by comma to plot the variable in lable and data in chart
var month =  monthVal.split(\',\');
var dataV=  dataVal.split(\',\');//alert(numberWithCommas(dataV));
//alert(dataV);
 
  var dis = Math.round(dataV);//alert(dis);
  var vad = addcomma(dis);//alert(vad);
//var dataV=addCommas(dataV);
var dataV1=  dataVal1.split(\',\');
var clr=  colors.split(\',\');
  var barChartCanvas = $(\'#barChart2\').get(0).getContext(\'2d\');
 

  var barChartData = {
    labels  :  month,
    datasets: [
      {
          label               : \'Kwh\',
          backgroundColor     : \'#67b7dc\',
          borderColor         :  \'#67b7dc\',
          pointRadius          : false,
          pointColor          :  \'#67b7dc\',
          pointStrokeColor    :  \'#67b7dc\',
          pointHighlightFill  :  \'#67b7dc\',
          pointHighlightStroke:  \'#67b7dc\',
		  fillColor: "#67b7dc",
          data                : dataV
      },
      {
        label                 : \'Cost\',
          backgroundColor     : \'#fdd400\',
          borderColor         :  \'#fdd400\',
          pointRadius         : false,
          pointColor          :  \'#fdd400\',
          pointStrokeColor    :  \'#fdd400\',
          pointHighlightFill  :  \'#fdd400\',
          pointHighlightStroke:  \'#fdd400\',
		  fillColor: "#fdd400",
          data                : dataV1
      }
    ]
  };
  
   
  
    var barChartOptions = {
	tooltips: {
        callbacks: {
            label: function(tooltipItem) {
			var dis = Math.round(tooltipItem.yLabel);
  var vad = includecomma(dis);
                return  vad;
            }
        }
    },
      responsive              : true,
      maintainAspectRatio     : true,
      datasetFill             : true,
	    scales: {
		yAxes: [{
              ticks:{
                  stepSize : 5000,

              }
			  }]
		}
	      };


    var barChart = new Chart(barChartCanvas, {
      type: \'bar\', 
      data: barChartData,
      options: barChartOptions,
    });
	
	barChart.Bar(barChartData, barChartOptions);
	
</script>-->
    
	'; ?>

	
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>