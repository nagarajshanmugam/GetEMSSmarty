<?php /* Smarty version 2.6.25, created on 2026-08-31 11:35:46
         compiled from listIncidentLog.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'date_format', 'listIncidentLog.tpl', 45, false),array('modifier', 'base64_decode', 'listIncidentLog.tpl', 50, false),array('modifier', 'replace', 'listIncidentLog.tpl', 74, false),array('modifier', 'explode', 'listIncidentLog.tpl', 77, false),array('modifier', 'escape', 'listIncidentLog.tpl', 85, false),)), $this); ?>
	<body onload="GetSensor()">
	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;"><?php if ($this->_tpl_vars['companyDetail']['0']['companyName'] != ""): ?><?php echo $this->_tpl_vars['companyDetail']['0']['companyName']; ?>
<?php else: ?><?php echo $this->_supers['session']['CompanyName']; ?>
<?php endif; ?>&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>			
				<td style="font-size:15PX;font-weight: bold;"><?php echo $this->_tpl_vars['branchDetail']['0']['branch_name']; ?>
&ensp;&ensp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">List Incidents Log</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:10PX;color:#999999;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			</div>
		</div>
		<form name="meterList" method="post" id="meterList">
		     <input type="hidden" id="ssensor" name="ssensor" value="<?php echo $this->_tpl_vars['ListDailyRep']['0']['sensorCode']; ?>
">
		<div class="row">
			<div class="col-12">
				<div class="card">
				<?php if ($this->_tpl_vars['SuccessMessage'] != "" || $this->_tpl_vars['ErrorMessage'] != ""): ?>
					<div class="card-body">
					<?php if ($this->_tpl_vars['SuccessMessage'] != ""): ?>
						<div class="isa_success">
						<i class="fa fa-check"></i>
						<?php echo $this->_tpl_vars['SuccessMessage']; ?>
		 
						</div>
					<?php endif; ?>
					<?php if ($this->_tpl_vars['ErrorMessage'] != ""): ?>
						<div class="isa_error">
						<i class="fa fa-check"></i>
						<?php echo $this->_tpl_vars['ErrorMessage']; ?>
		 
						</div>
					<?php endif; ?>
					</div>
				<?php endif; ?>
				<input type="hidden" id="sname" name="sname" value="<?php echo $this->_supers['post']['sensorName']; ?>
" />
					<div class="card-body table-responsive">
                    <div class="col-sm-12">
                    	<div class="col-sm-2"  style="float:left;margin-top:10PX">From Date: <input type="text" id="fromDate" name="fromDate" value="<?php if ($this->_supers['post']['sensorName'] != '' && $this->_supers['post']['fromDate'] == ''): ?><?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-01') : smarty_modifier_date_format($_tmp, '%Y-%m-01')); ?>
<?php elseif ($this->_supers['post']['sensorName'] != '' && $this->_supers['post']['fromDate'] != ''): ?><?php echo $this->_supers['post']['fromDate']; ?>
<?php else: ?><?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d') : smarty_modifier_date_format($_tmp, '%Y-%m-%d')); ?>
<?php endif; ?>" class="form-control" autocomplete="off" readonly="true" ></div>
                        &nbsp;&nbsp;
                        
                    
					<div class="col-sm-3"  style="float:left;margin-top:30PX">
					<input type="hidden" name="branchName" id="branchName" value="<?php echo ((is_array($_tmp=$this->_supers['get']['branchId'])) ? $this->_run_mod_handler('base64_decode', true, $_tmp) : base64_decode($_tmp)); ?>
">
						<select class="form-control" id="sensorName" name="sensorName"  tabindex="1"  >
						    <option value="">--  Select Sensor  --</option>
						</select>
					</div>&nbsp;&nbsp;
					 &nbsp;&nbsp;
					<div class="col-sm-2"  style="float:left;margin-top:30PX">
						<input type="button" value="Submit" id="submitButton" name="submitButton" class="btn btn-create">
					</div>&nbsp;&nbsp;
                    </div>
				
                    <?php if ($this->_tpl_vars['ListPostData']['0']['recorded_date'] == ''): ?><p><br/><br /></p><?php endif; ?>
						<table id="example" class="table table-bordered table-hover">
						<thead>
						<tr>
						<th class="slNo">#</th>
						<th class="">Date</th>
						<th class="">Sensor Code</th>
						<th class="">Incident Message</th>
						<th class="">Alert Status</th>
						</tr>
						</thead>
						<tbody>
						<?php $_from = $this->_tpl_vars['ListIncidentLog']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['List']):
?>
						<?php $this->assign('alertMsg0', ((is_array($_tmp=$this->_tpl_vars['List']['alert_message'])) ? $this->_run_mod_handler('replace', true, $_tmp, 'Hi!', '') : smarty_modifier_replace($_tmp, 'Hi!', ''))); ?>
						<?php $this->assign('alertMsg1', ((is_array($_tmp=$this->_tpl_vars['alertMsg0'])) ? $this->_run_mod_handler('replace', true, $_tmp, 'Best regards,', '') : smarty_modifier_replace($_tmp, 'Best regards,', ''))); ?>
						<?php $this->assign('alertMsg', ((is_array($_tmp=$this->_tpl_vars['alertMsg1'])) ? $this->_run_mod_handler('replace', true, $_tmp, 'Arka Automaations Limited.', '') : smarty_modifier_replace($_tmp, 'Arka Automaations Limited.', ''))); ?>
						<?php $this->assign('alertBreak', ((is_array($_tmp=",")) ? $this->_run_mod_handler('explode', true, $_tmp, $this->_tpl_vars['alertMsg']) : explode($_tmp, $this->_tpl_vars['alertMsg']))); ?>
						<?php $this->assign('l', 0); ?>
						<tr id="<?php echo $this->_tpl_vars['j']++; ?>
">
						<td ><?php echo $this->_tpl_vars['j']; ?>
</td>
						<td><?php echo ((is_array($_tmp=$this->_tpl_vars['List']['recorded_date_time'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%e-%b-%Y %I:%M %p") : smarty_modifier_date_format($_tmp, "%e-%b-%Y %I:%M %p")); ?>
</td>
						<td><?php echo $this->_tpl_vars['List']['sensor_code']; ?>
</td>
						<td> <?php unset($this->_sections['i']);
$this->_sections['i']['name'] = 'i';
$this->_sections['i']['loop'] = is_array($_loop=$this->_tpl_vars['alertBreak']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['i']['show'] = true;
$this->_sections['i']['max'] = $this->_sections['i']['loop'];
$this->_sections['i']['step'] = 1;
$this->_sections['i']['start'] = $this->_sections['i']['step'] > 0 ? 0 : $this->_sections['i']['loop']-1;
if ($this->_sections['i']['show']) {
    $this->_sections['i']['total'] = $this->_sections['i']['loop'];
    if ($this->_sections['i']['total'] == 0)
        $this->_sections['i']['show'] = false;
} else
    $this->_sections['i']['total'] = 0;
if ($this->_sections['i']['show']):

            for ($this->_sections['i']['index'] = $this->_sections['i']['start'], $this->_sections['i']['iteration'] = 1;
                 $this->_sections['i']['iteration'] <= $this->_sections['i']['total'];
                 $this->_sections['i']['index'] += $this->_sections['i']['step'], $this->_sections['i']['iteration']++):
$this->_sections['i']['rownum'] = $this->_sections['i']['iteration'];
$this->_sections['i']['index_prev'] = $this->_sections['i']['index'] - $this->_sections['i']['step'];
$this->_sections['i']['index_next'] = $this->_sections['i']['index'] + $this->_sections['i']['step'];
$this->_sections['i']['first']      = ($this->_sections['i']['iteration'] == 1);
$this->_sections['i']['last']       = ($this->_sections['i']['iteration'] == $this->_sections['i']['total']);
?>
						<?php $this->assign('l', $this->_tpl_vars['l']+1); ?>
						<?php echo ((is_array($_tmp=$this->_tpl_vars['alertBreak'][$this->_sections['i']['index']])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
,<?php if ($this->_tpl_vars['l'] == '2'): ?><br /><?php endif; ?>
						<?php endfor; endif; ?></td>
						<td align="center" ><?php if ($this->_tpl_vars['ListIncidentLog']['alert_status'] == 'Low'): ?><span class="text-warning"><?php elseif ($this->_tpl_vars['ListIncidentLog']['alert_status'] == 'Normal'): ?><span class="text-info"><?php elseif ($this->_tpl_vars['ListIncidentLog']['alert_status'] == 'Normal'): ?><span class="text-danger"><?php endif; ?><?php echo $this->_tpl_vars['List']['alert_status']; ?>
</span></td>
						</tr>
						<?php endforeach; else: ?>
						<tr><td colspan="8"><center>No Records Found</center></td></tr>
						<?php endif; unset($_from); ?>
						</tbody>
						</table>
					</div>
				</div>
			</div>
		</form>
	</section>
	</div>
	</body>
	<?php echo '
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	<link rel="stylesheet" href="/resources/demos/style.css">
	 <script>
	$( function() {
		$( "#fromDate" ).datepicker({changeMonth: true,
		changeYear: true,maxDate: \'0\',dateFormat:\'yy-mm-dd\'});
		$( "#toDate" ).datepicker({changeMonth: true,
		changeYear: true,maxDate: \'0\',dateFormat:\'yy-mm-dd\'});
	} );
	</script>
	<script type="text/javascript">
	$(document).ready(function() {
	$(\'#sensorName\').on(\'change\', function() {
	this.form.submit();
	});
	$(\'#submitButton\').on(\'click\', function() {
	this.form.submit();
	});
	});
	
	</script>
	<script type="text/javascript">
function GetSensor()
{
    var val = document.getElementById(\'branchName\').value;
var val1 = document.getElementById(\'sname\').value;
$.ajax({
	type: "POST",
	url: "getSensorsDash.php",
	data: {branch:val},
	success: function(result){
	var res = JSON.parse(result);
	var nlen=Object.keys(res).length;
	$("#sensorName").empty();
		var sel = \'--Select Sensor--\';
	$("#sensorName").append("<option value=\'\' selected>"+sel+"</option>");
for( var i = 0; i<nlen; i++){
var id = res[i][\'id\'];
var name = res[i][\'name\'];
if(val1 == id)
{
$("#sensorName").append("<option value=\'"+id+"\' selected>"+name+"</option>");
}
else if(val == \'\' && val1 == \'\')
{
$("#sensorName").append("<option value=\'\' selected>"+sel+"</option>");
}
else
{
$("#sensorName").append("<option value=\'"+id+"\'>"+name+"</option>");
}
}
	},
	error: function(result) {
	alert(\'error\');
	}
	});
}
</script>
	<style>
	.slNo{
	width:5%;
	}
	.code{
	width:10%;
	}
	.apiKey{
	width:30%;
	}
	.name{
	width:40%;
	}
	.isactive{
	width:10%;
	text-align:center;
	}
	.action{
	text-align:right;
	}
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>
	<script type="text/javascript">
	$(document).ready(function (){
	var table = $(\'#example\').DataTable({
	"ordering" : false,
	"pageLength": 50,
	"bPaginate": false,
	"searching": false,
	language: {
	"infoFiltered": "",
	search: "_INPUT_",
	searchPlaceholder: "Search..."
	},
	dom: \'<"pull-left" f><bottom>p\',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: \'<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p\',
	//dom: \'<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p\',
	
	initComplete: function(){
	//$("div.toolbar").html(\'<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>\');   	
	}       
	}); 
	}); 
	
	function unitPriceCats(slNoIdent,metIdIdent,compIdent,locIdIdent) {
		var sid = btoa(slNoIdent); var mid = btoa(metIdIdent); var comId = btoa(compIdent); var lId = btoa(locIdIdent);
		FormName		= document.meterList;
		FormName.action =\'unitPriceList.php?sl_no=\'+sid+\'&companyId=\'+comId+\'&location_id=\'+lId+\'&meter_id=\'+mid;
		FormName.submit();
	}
	
	function editCats(recordedDate,sensorCode,userName) {
		var sid = recordedDate;
		var mid = sensorCode;  
		var comId = userName; 
		$.ajax({
		type: "POST",
		url: "cronEnergyMeterData.php",
		data: {recorded_date:recordedDate,sensor_code:sensorCode,userName:userName},
		dataType: "text",
		cache: false,
		success: function(result){
		var len = result.length;
		//$("#testDate").val(result);
		//alert(result);
		location.reload(true);
		},
		error: function(result) {
		alert(\'error\');
		}
		});
	}
	
	</script>
	<script type="text/javascript">
	function deleteCats(slNoIdent,serialIdIdent,compIdent,branIdent,gateIdent){
		var sid = btoa(slNoIdent); var scId = btoa(serialIdIdent);var comId = btoa(compIdent); var gId = btoa(gateIdent);var bId = btoa(branIdent);
		if(confirm("Are you sure to Delete this Content?")){
		FormName		= document.meterList;
		FormName.action= \'sensorList.php?gatewayId=\'+gId+\'&companyId=\'+comId+\'&branchId=\'+bId+\'&sl_no=\'+sid+\'&sen_code=\'+scId;
		FormName.submit();
		}
	}
	</script>
	'; ?>

	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>