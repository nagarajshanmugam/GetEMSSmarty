<?php /* Smarty version 2.6.25, created on 2026-02-11 13:32:03
         compiled from userList.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'base64_encode', 'userList.tpl', 43, false),)), $this); ?>
	<div class="content-wrapper">
		<section class="content-header">
			<div class="card">
				<div class="card-header">
					<table style="margin-bottom:-10px;">
					<tr><td style="font-size:15PX;font-weight: bold;"><?php if ($this->_tpl_vars['companyDetail']['0']['companyName'] != ""): ?><?php echo $this->_tpl_vars['companyDetail']['0']['companyName']; ?>
<?php else: ?><?php echo $this->_supers['session']['CompanyName']; ?>
<?php endif; ?>&nbsp;&nbsp;</td>
					<?php if ($this->_supers['get']['branchId']): ?>  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="font-size:15PX;font-weight: bold;"><?php echo $this->_tpl_vars['branchDetail']['0']['branch_name']; ?>
&ensp;&ensp;</td><?php endif; ?>
					<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="font-size:15PX;font-weight: bold;">List User</font>&nbsp;</td>
					</tr>
					<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
					<?php if ($this->_supers['get']['branchId']): ?>  <td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="font-size:10PX;color:#999999;">Branch Name</td><?php endif; ?>
					<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
					</tr>
					</table>
				</div>
			</div>
			<div class="row">
				<div class="col-12">
					<div class="card">
					<?php if ($this->_tpl_vars['SuccessMessage'] != "" || $this->_tpl_vars['ErrorMessage'] != ""): ?>
						<div class="card-body">
						<?php if ($this->_tpl_vars['SuccessMessage'] != ""): ?>
							<div class="isa_success">
							<i class="fa fa-check"></i>
							<?php echo $this->_tpl_vars['SuccessMessage']; ?>
		 
							</div>
						<?php endif; ?>
						<?php if ($this->_tpl_vars['ErrorMessage'] != ""): ?>
							<div class="isa_error">
							<i class="fa fa-check"></i>
							<?php echo $this->_tpl_vars['ErrorMessage']; ?>
		 
							</div>
						<?php endif; ?>
						</div>
					<?php endif; ?>
						<div class="card-body table-responsive">
							<form name="userList" id="userList" method="post">
							<?php if ($this->_tpl_vars['ListuserCount']['0']['userCount'] < $this->_tpl_vars['ListuserCount']['0']['companyUserCount']): ?>
								<a href="AddEdituser.php?companyId=<?php if ($this->_supers['session']['USER_GROUP'] != 'Super Admin' && $this->_supers['get']['companyId'] == ''): ?><?php echo ((is_array($_tmp=$this->_supers['session']['CustomerId'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
<?php else: ?><?php echo $this->_supers['get']['companyId']; ?>
<?php endif; ?>&branchId=<?php echo $this->_supers['get']['branchId']; ?>
"><button type="button" style="float:right;margin-top:-6PX" class="btn btn-create">Create User</button></a><span style="float:right;">&ensp;</span>
							<?php else: ?>
								<b style="color:#FF0000;float:right;margin-top:-6PX">User Limit Exceeded</b>
							<?php endif; ?>
							<?php if ($this->_supers['session']['USER_GROUP'] == 'Super Admin'): ?> 
								<a href="companyList.php?companyId=<?php echo $this->_tpl_vars['company_id']; ?>
"><button type="button"  style="float:right;margin-top:-6PX" class="btn btn-primary">List Company</button></a> 
							<?php endif; ?>
							
							<table id="example" class="table table-hover table-bordered">
								<thead>
								<tr>
								<th class="slno">#</th>
								<th>User Name</th>
								<th>User Group</th>
								<th>Mobile No</th>
								<th>Email Id</th>
								<th>Status</th>
								<th>Action</th>
								</tr>
								</thead>
								<tbody>
								<?php $_from = $this->_tpl_vars['ListView']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['master_dtls']):
?>
									<tr id="<?php echo $this->_tpl_vars['i']++; ?>
">
									<td class="slno"><?php echo $this->_tpl_vars['i']; ?>
</td>
									<td class="text_left"><?php echo $this->_tpl_vars['master_dtls']['userName']; ?>
</td>
									<td class="text_left"><?php echo $this->_tpl_vars['master_dtls']['userGroup']; ?>
</td>
									<td class="text_right"><?php echo $this->_tpl_vars['master_dtls']['mobileNo']; ?>
</td>
									<td class="text_left"><?php echo $this->_tpl_vars['master_dtls']['emailId']; ?>
</td>
									<td class="text_left status"><?php if ($this->_tpl_vars['master_dtls']['isActive'] == '1'): ?><span style="color: #009900"><b>Active</b></span><?php else: ?><span style="color: #FF0033;"><b>Inactive</b></span><?php endif; ?></td>
									<td class="amount action"><a href="#" onclick="Javascript:editCats('<?php echo $this->_tpl_vars['master_dtls']['slNo']; ?>
','<?php echo $this->_tpl_vars['master_dtls']['company_id']; ?>
','<?php echo $this->_supers['get']['branchId']; ?>
')" title="Edit"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;
									<a href="#" onClick="Javascript:deleteCats('<?php echo $this->_tpl_vars['master_dtls']['slNo']; ?>
','<?php echo $this->_tpl_vars['master_dtls']['company_id']; ?>
')" title="Delete"><i class="fa fa-trash"></i></a></td>
									</tr>
								<?php endforeach; else: ?>
									<tr><td colspan="8"><center>No Records Found</center></td></tr>
								<?php endif; unset($_from); ?>
								</tbody>
							</table>
							</form>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>
	<?php echo '
	<script type="text/javascript">
	$(document).ready(function (){
	
	var table = $(\'#example\').DataTable({
	"ordering" : false,
	language: {
	"infoFiltered": "",
	search: "_INPUT_",
	searchPlaceholder: "Search..."
	},
	dom: \'<"pull-left" f><bottom>p\',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: \'<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p\',
	//dom: \'<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p\',
	buttons: [
	{
	text: \'Create Box\',
	className: \'btn btn-create\',
	titleAttr: \'Create Box\',
	action: function ( e, dt, button, config ) {
	window.location = \'AddEditBox.php\';
	}        
	}
	],
	initComplete: function(){
	$("div.toolbar").html(\'<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>\');   
	}       
	}); 
	}); 
	
	function editCats(slNoIdent,compIdent,branIdent) {
	var sid = btoa(slNoIdent);var comId = btoa(compIdent);
	FormName		= document.userList;
	FormName.action =\'AddEdituser.php?companyId=\'+comId+\'&branchId=\'+branIdent+\'&userId=\'+sid+\'&Update=y\';
	FormName.submit();
	}
	
	function deleteCats(CatIdent,compIdent){
	var sid = btoa(CatIdent);var comId = btoa(compIdent);
	if(confirm("Are you sure to Delete this Content?")){
	FormName		= document.userList;
	FormName.action= \'userList.php?companyId=\'+comId+\'&userId=\'+sid;
	FormName.submit();
	}
	}
	</script>
	<script>
	$(function () {
	$("#example1").DataTable();
	$(\'#example2\').DataTable({
	"paging": true,
	"lengthChange": false,
	"searching": false,
	"ordering": false,
	"info": false,
	"autoWidth": false,
	});
	});
	</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>
	'; ?>

	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>