<?php /* Smarty version 2.6.25, created on 2025-11-11 14:52:15
         compiled from sensorList.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'truncate', 'sensorList.tpl', 74, false),array('modifier', 'base64_encode', 'sensorList.tpl', 80, false),)), $this); ?>
	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;"><?php if ($this->_tpl_vars['companyDetail']['0']['companyName'] != ""): ?><?php echo $this->_tpl_vars['companyDetail']['0']['companyName']; ?>
<?php else: ?><?php echo $this->_supers['session']['CompanyName']; ?>
<?php endif; ?>&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<?php if ($this->_tpl_vars['branchDetail']['0']['branch_name'] != ""): ?>
					<td style="font-size:15PX;font-weight: bold;"><?php echo $this->_tpl_vars['branchDetail']['0']['branch_name']; ?>
&ensp;&ensp;</td><?php endif; ?>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">List Sensor</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			</div>
		</div>
		<form name="meterList" method="post" id="meterList">
		<div class="row">
			<div class="col-12">
				<div class="card">
				<?php if ($this->_tpl_vars['SuccessMessage'] != "" || $this->_tpl_vars['ErrorMessage'] != ""): ?>
					<div class="card-body">
					<?php if ($this->_tpl_vars['SuccessMessage'] != ""): ?>
						<div class="isa_success">
						<i class="fa fa-check"></i>
						<?php echo $this->_tpl_vars['SuccessMessage']; ?>
		 
						</div>
					<?php endif; ?>
					<?php if ($this->_tpl_vars['ErrorMessage'] != ""): ?>
						<div class="isa_error">
						<i class="fa fa-check"></i>
						<?php echo $this->_tpl_vars['ErrorMessage']; ?>
		 
						</div>
					<?php endif; ?>
					</div>
				<?php endif; ?>
					<div class="card-body table-responsive">
					<a href="sensorMasterAddEdit.php?companyId=<?php echo $this->_supers['get']['companyId']; ?>
&gatewayId=<?php echo $this->_supers['get']['gatewayId']; ?>
&branchId=<?php echo $this->_supers['get']['branchId']; ?>
"><button type="button" style="float:right;margin-top:-6PX" class="btn btn-create">Create Sensor</button></a><span style="float:right;">&ensp;</span>
					<a href="gatewayList.php?companyId=<?php echo $this->_supers['get']['companyId']; ?>
&branchId=<?php echo $this->_supers['get']['branchId']; ?>
"><button type="button" style="float:right;margin-top:-6PX" class="btn btn-primary"> List Gateway</button></a><?php if ($this->_supers['session']['USER_GROUP'] == 'Super Admin'): ?><span style="float:right;">&ensp;</span>
					<a href="branchList.php?companyId=<?php echo $this->_supers['get']['companyId']; ?>
"><button type="button" style="float:right;margin-top:-6PX" class="btn btn-primary"> List Branch</button></a><?php endif; ?>
					<?php if ($this->_tpl_vars['ListSensorView']['0']['slNo'] == ""): ?>&ensp;<br /><br /><?php endif; ?>
						<table id="example" class="table table-bordered table-hover">
						<thead>
						<tr>
						<th class="slno">#</th>
					<!--	<th class="code">Sensor Code</th>-->
					    <th class="name">Sensor Model</th>
						<th class="name">Sensor Name</th>
						<th class="name">ID</th>
						<th class="json">Data to server JSON Format</th>
						<th class="apiKey">URL</th>
						<th class="isactive">Status</th>
						<th class="action">Action</th>
						</tr>
						</thead>
						<tbody>
						<?php $_from = $this->_tpl_vars['ListSensorView']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['List']):
?>
						<?php $this->assign('tot', "{\"ID\":\"%i\",\"apiKey\":"); ?>
						<?php $this->assign('tot4', '"'); ?>
						<?php $this->assign('tot1', $this->_tpl_vars['List']['api_key']); ?>
						<?php $this->assign('tot2', "\" ,\"ST\":\"%s\",\"TS\":\"%t\",\"DT\":\"%d\",\"VR\":\"%a"); ?>
						<?php $this->assign('tot3', '"'); ?>
						<?php $this->assign('all', ($this->_tpl_vars['tot'])."''".($this->_tpl_vars['tot1'])."''".($this->_tpl_vars['tot2'])."''".($this->_tpl_vars['tot3'])); ?>
						<tr id="<?php echo $this->_tpl_vars['j']++; ?>
">
						<td ><?php echo $this->_tpl_vars['j']; ?>
</td>
					<!--	<td><?php echo $this->_tpl_vars['List']['sensorCode']; ?>
</td>-->
					    <td><?php echo $this->_tpl_vars['List']['model_name']; ?>
</td>
						<td><?php echo $this->_tpl_vars['List']['sensorName']; ?>
</td>
						<td><?php echo $this->_tpl_vars['List']['modbus_slave_id']; ?>
</td>
						<td><span id="apik<?php echo $this->_tpl_vars['j']; ?>
" style="display:none;"><?php echo $this->_tpl_vars['tot']; ?>
<?php echo $this->_tpl_vars['tot4']; ?>
<?php echo $this->_tpl_vars['tot1']; ?>
<?php echo $this->_tpl_vars['tot2']; ?>
<?php echo $this->_tpl_vars['tot3']; ?>
}</span><?php echo ((is_array($_tmp=$this->_tpl_vars['all'])) ? $this->_run_mod_handler('truncate', true, $_tmp, 30, "...", true) : smarty_modifier_truncate($_tmp, 30, "...", true)); ?>
&nbsp;&nbsp;<a href="#" onclick="Javascript:copy_password('apik<?php echo $this->_tpl_vars['j']; ?>
')" title="Copy to clipboard"><i class="fas fa-clipboard" ></i></a></td>
						<td><span id="apiu<?php echo $this->_tpl_vars['j']; ?>
" style="display:none;"><?php echo $this->_tpl_vars['List']['api_url']; ?>
</span><?php echo ((is_array($_tmp=$this->_tpl_vars['List']['api_url'])) ? $this->_run_mod_handler('truncate', true, $_tmp, 30, "...", true) : smarty_modifier_truncate($_tmp, 30, "...", true)); ?>
&nbsp;&nbsp;<a href="#" onclick="Javascript:copy_password('apiu<?php echo $this->_tpl_vars['j']; ?>
')" title="Copy to clipboard"><i class="fas fa-clipboard"></i></a></td>
						<td align="center"><?php if ($this->_tpl_vars['List']['isActive'] == '1'): ?><span style="color:#009900"><b>Active</b></span><?php else: ?><span style="color:#FF0000;"><b>Inactive</b></span><?php endif; ?></td>
						<td align="right">
						<?php if ($this->_tpl_vars['List']['sensorModel'] != 'TE'): ?> <a href="#"  onClick="Javascript:alertCats('<?php echo $this->_tpl_vars['List']['slNo']; ?>
','<?php echo $this->_tpl_vars['List']['sensorCode']; ?>
','<?php echo $this->_tpl_vars['List']['company_id']; ?>
','<?php echo $this->_tpl_vars['List']['branch_id']; ?>
','<?php echo $this->_tpl_vars['List']['gateway_id']; ?>
','Update=Y')" title="Alert Parameter"><i class="fa fa-window-restore"></i></a>&nbsp;&nbsp;&nbsp;<?php endif; ?>
						<a href="#"  onClick="Javascript:editFeederCats('<?php echo $this->_tpl_vars['List']['slNo']; ?>
','<?php echo $this->_tpl_vars['List']['sensorCode']; ?>
','<?php echo $this->_tpl_vars['List']['company_id']; ?>
','<?php echo $this->_tpl_vars['List']['branch_id']; ?>
','<?php echo $this->_tpl_vars['List']['gateway_id']; ?>
','Update=Y')" title="Sensor Feeder Update"><i class="fa fa-share"></i></a>&nbsp;&nbsp;&nbsp;
						<?php if ($this->_tpl_vars['List']['sensorModel'] == 'RGA20S'): ?><a href="capacityList.php?slNo=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['slNo'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
&sensorCode=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['sensorCode'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
&companyId=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['company_id'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
&branchId=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['branch_id'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
&gatewayId=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['gateway_id'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
"  title="List Capacitor Value"><i class="fa fa-list"></i></a>&nbsp;&nbsp;&nbsp;<?php endif; ?>
						<?php $_from = $this->_tpl_vars['IconList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['icon']):
?>
						<?php if ($this->_tpl_vars['icon']['menuName'] == 'Add Alert Contact'): ?><a href="addAlertContact.php?slNo=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['slNo'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
&sensorCode=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['sensorCode'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
&companyId=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['company_id'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
&branchId=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['branch_id'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
&gatewayId=<?php echo ((is_array($_tmp=$this->_tpl_vars['List']['gateway_id'])) ? $this->_run_mod_handler('base64_encode', true, $_tmp) : base64_encode($_tmp)); ?>
"  title="Add Alert Contact"><i class="<?php echo $this->_tpl_vars['icon']['faIcon']; ?>
"></i></a>&nbsp;&nbsp;&nbsp;<?php endif; ?>
						
						<?php if ($this->_tpl_vars['icon']['menuName'] == 'Edit Sensor'): ?><a href="#"  onClick="Javascript:editCats('<?php echo $this->_tpl_vars['List']['slNo']; ?>
','<?php echo $this->_tpl_vars['List']['sensorCode']; ?>
','<?php echo $this->_tpl_vars['List']['company_id']; ?>
','<?php echo $this->_tpl_vars['List']['branch_id']; ?>
','<?php echo $this->_tpl_vars['List']['gateway_id']; ?>
','Update=Y')" title="Edit"><i class="<?php echo $this->_tpl_vars['icon']['faIcon']; ?>
"></i></a>&nbsp;&nbsp;&nbsp;<?php endif; ?>
						<?php if ($this->_tpl_vars['icon']['menuName'] == 'Delete Sensor'): ?><a href="#"  onClick="Javascript:deleteCats('<?php echo $this->_tpl_vars['List']['slNo']; ?>
','<?php echo $this->_tpl_vars['List']['sensorCode']; ?>
','<?php echo $this->_tpl_vars['List']['company_id']; ?>
','<?php echo $this->_tpl_vars['List']['branch_id']; ?>
','<?php echo $this->_tpl_vars['List']['gateway_id']; ?>
')" title="Delete"><i class="fa fa-trash"></i></a>&nbsp;&nbsp;&nbsp;<?php endif; ?>
						<?php endforeach; endif; unset($_from); ?>
						</td>
						</tr>
						<?php endforeach; else: ?>
						<tr><td colspan="7"><center>No Records Found</center></td></tr>
						<?php endif; unset($_from); ?>
						</tbody>
						</table>
					</div>
				</div>
			</div>
		</form>
	</section>
	</div>
	<?php echo '
	<style>
	.slno{
	width:5%;
	}
	.code{
	width:10%;
	}
	.apiKey{
	width:15%;
	}
	.name{
	width:10%;
	}
	.json{
	width:15%;
	}
	.isactive{
	width:10%;
	text-align:center;
	}
	.action{
	text-align:right;
	width:10%;
	}
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>
	<script type="text/javascript">
	$(document).ready(function (){
	
	var table = $(\'#example\').DataTable({
	"ordering" : false,
	language: {
	"infoFiltered": "",
	search: "_INPUT_",
	searchPlaceholder: "Search..."
	},
	dom: \'<"pull-left" f><bottom>p\',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: \'<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p\',
	//dom: \'<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p\',
	
	initComplete: function(){
	//$("div.toolbar").html(\'<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>\');   
	}       
	}); 
	}); 
	
	function unitPriceCats(slNoIdent,metIdIdent,compIdent,locIdIdent) 
	{
		var sid = btoa(slNoIdent); var mid = btoa(metIdIdent); var comId = btoa(compIdent); var lId = btoa(locIdIdent);
		FormName		= document.meterList;
		FormName.action =\'unitPriceList.php?sl_no=\'+sid+\'&companyId=\'+comId+\'&location_id=\'+lId+\'&meter_id=\'+mid;
		FormName.submit();
	}
	
	function editCats(slNoIdent,metIdIdent,compIdent,branIdent,gateIdent,Update) 
	{
		var sid = btoa(slNoIdent); var mid = btoa(metIdIdent);  var comId = btoa(compIdent); var gId = btoa(gateIdent);var bId = btoa(branIdent);
		FormName		= document.meterList;
		FormName.action =\'sensorMasterAddEdit.php?sl_no=\'+sid+\'&sensor_id=\'+mid+\'&companyId=\'+comId+\'&gatewayId=\'+gId+\'&branchId=\'+bId+\'&Update=y\';
		FormName.submit();
	}
	</script>
	<script type="text/javascript">
	function deleteCats(slNoIdent,serialIdIdent,compIdent,branIdent,gateIdent)
	{
		var sid = btoa(slNoIdent); var scId = btoa(serialIdIdent);var comId = btoa(compIdent); var gId = btoa(gateIdent);var bId = btoa(branIdent);
		if(confirm("Are you sure to Delete this Content?")){
		FormName		= document.meterList;
		FormName.action= \'sensorList.php?gatewayId=\'+gId+\'&companyId=\'+comId+\'&branchId=\'+bId+\'&sl_no=\'+sid+\'&sen_code=\'+scId;
		FormName.submit();
		}
	}
		function alertCats(slNoIdent,metIdIdent,compIdent,branIdent,gateIdent,Update) {
		var sid = btoa(slNoIdent); var mid = btoa(metIdIdent);  var comId = btoa(compIdent); var gId = btoa(gateIdent);var bId = btoa(branIdent);
		FormName		= document.meterList;
		FormName.action =\'feederAlertParameter.php?sl_no=\'+sid+\'&sensor_id=\'+mid+\'&companyId=\'+comId+\'&gatewayId=\'+gId+\'&branchId=\'+bId+\'&Update=y\';
		FormName.submit();
	}
		function editFeederCats(slNoIdent,metIdIdent,compIdent,branIdent,gateIdent,Update) {
		var sid = btoa(slNoIdent); var mid = btoa(metIdIdent);  var comId = btoa(compIdent); var gId = btoa(gateIdent);var bId = btoa(branIdent);
		FormName		= document.meterList;
		FormName.action =\'feederAddEdit.php?sl_no=\'+sid+\'&sensor_id=\'+mid+\'&companyId=\'+comId+\'&gatewayId=\'+gId+\'&branchId=\'+bId+\'&Update=y\';
		FormName.submit();
	}
	</script>
	<script type="text/javascript">
	function myFunction(id) 
	{
		var copyText = document.getElementById(id);
		copyText.select();
		copyText.setSelectionRange(0, 99999);
		document.execCommand("copy");
		alert("Copied the text: " + copyText.value);
	}
	function copy_password(id) 
	{
		var copyText = document.getElementById(id);
		var textArea = document.createElement("textarea");
		textArea.value = copyText.textContent;
		document.body.appendChild(textArea);
		textArea.select();
		document.execCommand("Copy");
		textArea.remove();
	}
	</script>
	'; ?>

	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>