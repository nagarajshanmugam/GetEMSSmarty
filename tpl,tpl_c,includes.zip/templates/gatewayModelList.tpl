	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">List Gateway Model</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			</div>
		</div>
		<form name="gateway_list" method="post" id="gateway_list">
		<div class="row">
			<div class="col-12">
				<div class="card">
				{if $SuccessMessage neq "" || $ErrorMessage neq ""}
					<div class="card-body">
					{if $SuccessMessage neq ""}
						<div class="isa_success">
						<i class="fa fa-check"></i>
						{$SuccessMessage}		 
						</div>
					{/if}
					{if $ErrorMessage neq ""}
						<div class="isa_error">
						<i class="fa fa-check"></i>
						{$ErrorMessage}		 
						</div>
					{/if}
					</div>
				{/if}
					<div class="card-body table-responsive">
					<a href="addEditGatewayModel.php"><button type="button" style="float:right;margin-top:-6px" class="btn btn-create">Create Gateway Model</button></a>
						<table id="example" class="table table-bordered table-hover">
						<thead>
						<tr>
						<th>#</th>
						<th>Gateway Model Code</th>
						<th> Gateway Model Name </th>
						<th>Status</th>
						<th>Action</th>
						</tr>
						</thead>
						<tbody>
						{foreach from=$ListView item=List}
						<tr id="{$j++}">
						<td class="slno">{$j}</td>
						<td>{$List.model_code}</td>
						<td>{$List.model_name}</td>
						<td class="text_left status"> {if $List.is_active eq "1"}<span style="color:#009900"><b>Active</b></span>{else}<span style="color:#FF0033;"><b>Inactive</b></span>{/if}</td>
						<td class="amount action">
						{foreach from=$IconList item=icon}
						{if $icon.menuName eq "Edit Platform"}<a href="#"  onClick="Javascript:editCats('{$List.sl_no}','Update=Y')" title="Edit"><i class="{$icon.faIcon}"></i></a>&nbsp;&nbsp;&nbsp;{/if}
						{if $List.is_active eq "2"}{if $icon.menuName eq "Delete Platform"}<a href="#"  onClick="Javascript:deleteCats('{$List.sl_no}')" title="Delete"><i class="{$icon.faIcon}"></i></a>&nbsp;&nbsp;&nbsp;{/if}{/if}
						{/foreach}</td>
						</tr>
						{foreachelse}
						<tr><td colspan="6"><center>No Records Found</center></td></tr>
						{/foreach}
						</tbody>
						</table>
					</div>
				</div>
			</div>
		</form>
	</section>
	</div>
	{literal}
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>
	<script type="text/javascript">
	$(document).ready(function (){
	
	var table = $('#example').DataTable({
	"ordering" : false,
	language: {
	"infoFiltered": "",
	search: "_INPUT_",
	searchPlaceholder: "Search..."
	},
	dom: '<"pull-left" f><bottom>p',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: '<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p',
	//dom: '<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p',
	buttons: [
	{
	text: 'Create Box',
	className: 'btn btn-create',
	titleAttr: 'Create Box',
	action: function ( e, dt, button, config ) {
	window.location = 'AddEditBox.php';
	}        
	}
	],
	initComplete: function(){
	$("div.toolbar").html('<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>');   	
	}       
	}); 
	}); 
	
	function editCats(slNoIdent) 
	{
		var sid = btoa(slNoIdent);
		FormName		= document.gateway_list;
		FormName.action ='addEditGatewayModel.php?slNo='+sid+'&Update=y';
		FormName.submit();
	}
	</script>
	<script type="text/javascript">
	function deleteCats(slNoIdent)
	{
		var sid = btoa(slNoIdent);
		if(confirm("Are you sure to Delete this Gateway Model?")){
		FormName		= document.gateway_list;
		FormName.action= 'gatewayModelList.php?slNo='+sid;
		FormName.submit();
		}
	}
	</script>
	{/literal}
	{include file="footer.tpl"}