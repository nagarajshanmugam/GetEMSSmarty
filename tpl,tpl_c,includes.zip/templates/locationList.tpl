	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">{if $ListBranchGet.0.branch_name neq ""}{$ListBranchGet.0.branch_name}{else}{$smarty.session.branch_name}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">List Location</font>&nbsp;</td>
				</tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:10PX;color:#999999;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			</div>
		</div>
		<form name="location_list" method="post" id="location_list">
		<div class="row">
			<div class="col-12">
				<div class="card">
				{if $SuccessMessage neq "" || $ErrorMessage neq ""}
					<div class="card-body">
					{if $SuccessMessage neq ""}
						<div class="isa_success">
						<i class="fa fa-check"></i>
						{$SuccessMessage}		 
						</div>
					{/if}
					{if $ErrorMessage neq ""}
						<div class="isa_error">
						<i class="fa fa-check"></i>
						{$ErrorMessage}		 
						</div>
					{/if}
					</div>
				{/if}
					<div class="card-body table-responsive">
					<a href="locationAddEdit.php?companyId={$smarty.get.companyId}&branchId={$smarty.get.branchId}"><button type="button" style="float:right;margin-top:-6px" class="btn btn-create">Create Location</button></a>
					<br/><br/>
						<table id="example" class="table table-bordered table-hover">
						<thead>
						<tr>
						<th>#</th>
						<th>Code</th>
						<th>Name</th>
						<th>ID</th>
						<th>Data to Server JSON </th>
						<th>URL</th>
						<th>Status</th>
						<th>Action</th>
						</tr>
						</thead>
						<tbody>
						{foreach from=$GetLocation item=List}
						{assign var=tot value={"ID":"%i","apiKey":"}
						{assign var=tot4 value='"'}
						{assign var=tot1 value=$List.api_key}
						{assign var=tot2 value=" ,"ST":"%s","TS":"%t","DT":"%d","VR":"%a"}
						{assign var=tot3 value='"'}
						{assign var=all value=$tot''$tot1''$tot2''$tot3}
						<tr id="{$j++}">
						<td class="slno">{$j}</td>
						<td>{$List.location_code}</td>
						<td>{$List.location_name}</td>
						<td>{$List.modbus_slave_id}</td>
						<td><span id="apik{$j}" style="display:none;">{$tot}{$tot4}{$tot1}{$tot2}{$tot3}</span>{$all|truncate:30:"...":true}&nbsp;&nbsp;<a href="#" onclick="Javascript:copy_password('apik{$j}')" title="Copy to clipboard"><i class="fas fa-clipboard" ></i></a></td>
						<td><span id="apiu{$j}" style="display:none;">{$List.api_url}</span>{$List.api_url|truncate:30:"...":true}&nbsp;&nbsp;<a href="#" onclick="Javascript:copy_password('apiu{$j}')" title="Copy to clipboard"><i class="fas fa-clipboard"></i></a></td>
						<td class="text_left status"> {if $List.is_active eq "1"}<span style="color:#009900"><b>Active</b></span>{else}<span style="color:#FF0033;"><b>Inactive</b></span>{/if}</td>
						<td class="amount action">
						{foreach from=$IconList item=icon}
						{if $icon.menuName eq "Location Details"}
						<a href="#"  onClick="Javascript:detailCats('{$List.location_master_id}','{$List.company_id}','{$List.branch_id}','Update=Y')" title="Details"><i class="{$icon.faIcon}"></i></a>&nbsp;&nbsp;
					    {/if}
						{if $icon.menuName eq "Edit Platform"}<a href="#"  onClick="Javascript:editCats('{$List.location_master_id}','{$List.company_id}','{$List.branch_id}','Update=Y')" title="Edit"><i class="{$icon.faIcon}"></i></a>&nbsp;&nbsp;
						{/if}		
						{if $icon.menuName eq "Delete Platform"}<a href="#"  onClick="Javascript:deleteCats('{$List.location_master_id}','{$List.company_id}','{$List.branch_id}')" title="Delete"><i class="{$icon.faIcon}"></i></a>&nbsp;&nbsp;{/if}
						{/foreach}</td>
						</tr>
						{foreachelse}
						<tr><td colspan="8"><center>No Records Found</center></td></tr>
						{/foreach}						
						</tbody>
						</table>
					</div>
				</div>
			</div>
		</form>
	</section>
	</div>
	{literal}
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>
	<script type="text/javascript">
	$(document).ready(function (){
	var table = $('#example').DataTable({
	"ordering" : false,
	language: {
	"infoFiltered": "",
	search: "_INPUT_",
	searchPlaceholder: "Search..."
	},
	dom: '<"pull-left" f><bottom>p',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: '<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p',
	//dom: '<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p',
	buttons: [
	{
	text: 'Create Box',
	className: 'btn btn-create',
	titleAttr: 'Create Box',
	action: function ( e, dt, button, config ) {
	window.location = 'AddEditBox.php';
	}        
	}
	],
	initComplete: function(){
	$("div.toolbar").html('<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>');   	
	}       
	}); 
	}); 
	
	function editCats(slNoIdent, comId, branchId) {
	
		var sid = btoa(slNoIdent);
		var cid = btoa(comId);
		var bid = btoa(branchId);

		FormName		= document.location_list;
		FormName.action ='locationAddEdit.php?locId='+sid+'&companyId='+cid+'&branchId='+bid+'&Update=y';
		FormName.submit();
	}

	function detailCats(slNoIdent, comId, branchId) {
	
		var sid = btoa(slNoIdent);
		var cid = btoa(comId);
		var bid = btoa(branchId);

		FormName		= document.location_list;
		FormName.action ='locationDetails.php?locId='+sid+'&companyId='+cid+'&branchId='+bid+'&Update=y';
		FormName.submit();
	}
	


	</script>
	<script type="text/javascript">
	function deleteCats(slNoIdent, comId, branchId){
		var sid = btoa(slNoIdent);
		var cid = btoa(comId);
		var bid = btoa(branchId);
		if(confirm("Are you sure to Delete this Record?")){
			FormName		= document.location_list;
			FormName.action= 'locationList.php?locId='+sid+'&companyId='+cid+'&branchId='+bid;
			FormName.submit();
		}
	}
	</script>
	<script>
	function copy_password(id) 
	{
		var copyText = document.getElementById(id);
		var textArea = document.createElement("textarea");
		textArea.value = copyText.textContent;
		document.body.appendChild(textArea);
		textArea.select();
		document.execCommand("Copy");
		textArea.remove();
	}
	</script>
	{/literal}
	{include file="footer.tpl"}