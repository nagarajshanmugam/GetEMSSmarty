 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <!--<section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
		  <ol class="breadcrumb float-sm">
              <li class="breadcrumb-item">{$GetCompanyView.0.companyName}</li>
			  <li class="breadcrumb-item">{$BranchView.0.branch_name}</li>
               <li class="breadcrumb-item">{$smarty.get.gatewayId|base64_decode}</li>
              <li class="breadcrumb-item active">List Sensor</li>
            </ol>
          </div>
          <div class="col-sm-6">
            
          </div>
        </div>
      </div>
    </section>-->

     <!-- Main content -->
     <section class="content-header">
	<div class="card">
            <div class="card-header">

		   <table style="margin-bottom:-10px;">
		  <tr><td style="font-size:15PX;font-weight: bold;">{$companyDetail.0.companyName}&nbsp;&nbsp;</td>
		  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		   {if $branchDetail.0.branch_name neq ""}
            <td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&nbsp;&nbsp;</font>&nbsp;</td>
			<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
            {/if}
            <td style="font-size:15PX;font-weight: bold;">{$smarty.get.gId|base64_decode}</font>&nbsp;</td>
		  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  <td style="font-size:15PX;font-weight: bold;">List Invoice</font>&nbsp;</td></tr>
		  
		
		  <tr><td style="font-size:10PX;color:#999999;">Company Name</td>
		  <td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  {if $branchDetail.0.branch_name neq ""}
			<td style="color:#999999;font-size:10PX;">Branch Name</td>
            <td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
            {/if}
            <td style="color:#999999;font-size:10PX;">Month Name</td>
          <td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  <td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
		  </tr>
		  
		  </table></div>
        
      </div>
	 <form name="meterList" method="post" id="meterList">
      <div class="row">
	 
        <div class="col-12">
          <div class="card">
		  
            
            {if $SuccessMessage neq "" || $ErrorMessage neq ""}
            <div class="card-body">
					{if $SuccessMessage neq ""}
					<div class="isa_success">
					<i class="fa fa-check"></i>
					{$SuccessMessage}		 
					</div>
					{/if}
					{if $ErrorMessage neq ""}
					<div class="isa_error">
					<i class="fa fa-check"></i>
					{$ErrorMessage}		 
					</div>
					{/if}
					</div>
                    {/if}
            <!-- /.card-header -->
        <div class="card-body table-responsive">
				{if $smarty.session.USER_GROUP eq "Branch User" || $smarty.session.USER_GROUP eq "Branch Admin"}	<a href="listBilling.php?companyId={$smarty.get.companyId}&branchId={$smarty.get.branchId}"> <button type="button" class="btn btn-create" value="Create Userrole" style="float:right;margin-top:-6PX">List Billing</button></a>{else}<a href="listBilling.php?companyId={$smarty.get.companyId}"> <button type="button" class="btn btn-create" value="Create Userrole" style="float:right;margin-top:-6PX">List Billing</button></a>{/if}
					          
             <table id="example" class="table table-bordered table-hover">
                <thead>
                <tr>
    			  <th class="slNo">#</th>
				   <th class="">Invoice No</th>
				   <th class="" align="right">Invoice Date</th>
                   <th class="" align="right">Feeder Name</th>
                   <th class="" align="right">Start Kwh</th>
                   <th class="" align="right">End Kwh</th>
                   <th class="" align="right">Total Kwh</th>
                    <th class="" align="right">Unit Rate</th>
                    <th class="" align="right">Total Cost</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
				{foreach from=$ListInvoiceData item=List}
				{assign var=tot_kwh value=$List.end_kwh-$List.start_kwh}
                <tr id="{$j++}">
				 <td >{$j}</td>
				 <td>{$List.Invoice_no}</td>
                 <td>{$List.invoice_date|date_format:'%e-%b-%Y'}</td>
                 <td>{$List.feeder_name}</td>
                  <td align="right">{$List.start_kwh|string_format:"%.2f"}</td>
                   <td align="right">{$List.end_kwh|string_format:"%.2f"}</td>
                    <td align="right">{$tot_kwh|string_format:"%.2f"}</td>
                 <td align="right">{$List.unit_price}</td>
                 <td align="right">{$List.invoice_amount}</td>
                 
               <td align="right">
				  <!--<a href="#"  onClick="Javascript:editCats('{$List.recorded_date}','{$List.sensor_code}','{$List.company_id}','{$List.branch_id}','{$List.invoice_master_id}')" title="Download Invoice"><i class="fa fa-download"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-->
				  <a href="html.php?recorded_date={$List.bill_month}&sensor_code={$List.sensor_code}&company_id={$List.company_id}&branch_id={$List.branch_id}&invoice_no={$List.invoice_master_id}"  title="Download PDF" target="_blank"><i class="fa fa-download" ></i></a>
                  <!--<a href="#"  onClick="Javascript:deleteCats('{$List.invoice_master_id}')" title="Remove Invoice"><i class="fa fa-trash"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-->
               </td>
                </tr>
				
               {foreachelse}
                <tr><td colspan="8"><center>No Records Found</center></td></tr>
                {/foreach}
               
               
                </tbody>
              </table>
            </div>

         <!-- /.card-body -->
          </div>
          <!-- /.card -->
          </div>
		  </form>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  {literal}
 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
<!--  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
-->  <script>
  $( function() {
    $( "#fromDate" ).datepicker({changeMonth: true,
    changeYear: true,maxDate: '0',dateFormat:'yy-mm-dd'});
	 $( "#toDate" ).datepicker({changeMonth: true,
    changeYear: true,maxDate: '0',dateFormat:'yy-mm-dd'});
  } );
  </script>
  <script type="text/javascript">
  
        $(document).ready(function() {
            $('#monthName').on('change', function() {
                this.form.submit();
            });
        });
		
        </script>
  <style>
  .slNo{
  width:5%;
  }
  .code{
  width:10%;
  }
  .apiKey{
  width:30%;
  }
  .name{
  width:40%;
  }
  .isactive{
  width:10%;
  text-align:center;

  }
   .action{
  text-align:right;
    }
.isa_success
{
color:#4F8A10;
background-color:#DFF2BF;
}
.error
{
color:#D8000C;
/*background-color:#FFBABA;*/
}
.isa_error
{
color:#D8000C;
background-color:#FFBABA;
}
.isa_success i,.isa_error i
{
margin:10px 22px;
font-size:2em;
/*vertical-align:middle;*/
}
</style>

  <script type="text/javascript">
    $(document).ready(function (){

var table = $('#example').DataTable({
	 "ordering" : false,
	 "pageLength": 50,
      language: {
	    "infoFiltered": "",
        search: "_INPUT_",
        searchPlaceholder: "Search..."
    },
	dom: '<"pull-left" f><bottom>p',
	tableTools: {
          "sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
        },
	//dom: '<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p',
	//dom: '<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p',
	
       initComplete: function(){
        //  $("div.toolbar").html('<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>');   
		
		 
       }       
    }); 

}); 

  
  function unitPriceCats(slNoIdent,metIdIdent,compIdent,locIdIdent) {
    var sid = btoa(slNoIdent); var mid = btoa(metIdIdent); var comId = btoa(compIdent); var lId = btoa(locIdIdent);
   FormName		= document.meterList;
   FormName.action ='unitPriceList.php?sl_no='+sid+'&companyId='+comId+'&location_id='+lId+'&meter_id='+mid;
   FormName.submit();
}
  
function setCats(recordedDate,comId,bId) {
window.location.href='setUnitRate.php?monthData='+recordedDate+'&companyId='+comId+'&branch_id='+bId;
target = "_blank";
done=1;
}

function editCats(recordedDate,sensorCode,companyId,branchId,invoiceId) {
// alert("i am here");
   var sid = recordedDate;
   var mid = sensorCode;  
  
  // window.location.href='generateBillingPdf.php?recorded_date='+recordedDate+'&sensor_code='+sensorCode;
  window.location.href='html.php?recorded_date='+recordedDate+'&sensor_code='+sensorCode+'&company_id='+companyId+'&branch_id='+branchId+'&invoice_no='+invoiceId;
  target = "_blank";
  done=1;
 // $("#box").load("html.php?recorded_date='+recordedDate+'&sensor_code='+sensorCode");
 /* $.ajax({
  url: 'html.php',
  type: 'post',
  data: {recorded_date: recordedDate,sensor_code: sensorCode},
  success: function(response){
     alert("Download PDF Sucessfully");
  }
   
});*/

  
}

   function deleteCats(CatIdent){
  if(confirm("Are you sure to Delete this Content?")){
  FormName		= document.meterList;
  FormName.action= "listInvoice.php?dId="+CatIdent;
  FormName.submit();
 }
 }

 function createCats(MonId,ComId,BchId){
  if(confirm("Are you sure to Create Invoice?")){
  FormName		= document.meterList;
  FormName.action= "listBilling.php?MId="+MonId+"&CId="+ComId+"&BId="+BchId;
  FormName.submit();
 }
 }
  
  </script>
  {/literal}
  {include file="footer.tpl"}