{include file=$HeaderTpl Title="Header"}
{include file=$LeftTpl Title="Left"}
{include file=$FooterTpl Title="Footer"}
{include file=$IncludeTpl Title="Include Tem"} 