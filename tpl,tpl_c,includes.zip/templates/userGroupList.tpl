	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">List User Group</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			</div>
		</div>
	<div class="row">
		<div class="col-12">
			<div class="card">
			{if $SuccessMessage neq "" || $ErrorMessage neq ""}
				<div class="card-body">
				{if $SuccessMessage neq ""}
					<div class="isa_success">
					<i class="fa fa-check"></i>
					{$SuccessMessage}		 
					</div>
				{/if}
				{if $ErrorMessage neq ""}
					<div class="isa_error">
					<i class="fa fa-check"></i>
					{$ErrorMessage}		 
					</div>
				{/if}
				</div>
			{/if}
				<div class="card-body table-responsive">
				<a href="AddEdituserGroup.php"><button type="button" class="btn btn-create" value="Create Usergroup" style="float:right;margin-top:-6px">Create User Group</button></a>
					<form name="groupList" id="groupList" method="post">
						<table id="example" class="table table-hover table-bordered">
						<thead>
						<tr>
						<th class="slno">#</th>
						<th>Usergroup Name</th>
						<th>Status</th>
						<th>Action</th>
						</tr>
						</thead>
						<tbody>
						{foreach from=$ListView item=master_dtls}
						<tr id="{$i++}">
						<td class="slno">{$i}</td>
						<td class="text_left">{$master_dtls.usergroupName}</td>
						<td class="status text_left">{if $master_dtls.isActive eq "1"}<span style="color: #009900"><b>Active</b></span>{else}<span style="color: #FF0033  ;"><b>Inactive</b></span>{/if}</td>
						<td class="amount action">
						<a href="#" onclick="Javascript:editCats('{$master_dtls.slNo}')" title="Edit"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;
						<a href="#" onClick="Javascript:deleteCats('{$master_dtls.slNo}')" title="Delete"><i class="fa fa-trash"></i></a></td>
						</tr>
						{/foreach}
						</tbody>
						</table>
					</form>
				</div>
			</div>
		</div>
	</div>
	</section>
	</div>
	{literal}
		<script type="text/javascript">
		function editCats(slNoIdent) 
		{
			var sid = btoa(slNoIdent);
			FormName		= document.groupList;
			FormName.action ='AddEdituserGroup.php?groupId='+slNoIdent+'&Update=y';
			FormName.submit();
		}
		function deleteCats(CatIdent)
		{
			if(confirm("Are you sure to Delete this Content?")){
			FormName		= document.groupList;
			FormName.action= "userGroupList.php?gId="+CatIdent;
			FormName.submit();
			}
		}
		</script>
	<script>
	$(document).ready(function ()
	{
	var table = $('#example').DataTable({
	"ordering" : false,
	language: {
	"infoFiltered": "",
	search: "_INPUT_",
	searchPlaceholder: "Search..."
	},
	dom: '<"pull-left" f><bottom>p',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: '<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p',
	//dom: '<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p',
	buttons: [
	{
	text: 'Create Box',
	className: 'btn btn-create',
	titleAttr: 'Create Box',
	action: function ( e, dt, button, config ) {
	window.location = 'AddEditBox.php';
	}        
	}
	],
	initComplete: function(){
	$("div.toolbar").html('<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>');   
	}       
	}); 
	}); 
	$(function () {
	$("#example1").DataTable();
	$('#example2').DataTable({
	"paging": true,
	"lengthChange": false,
	"searching": false,
	"ordering": true,
	"info": true,
	"autoWidth": false,
	});
	});
	</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>
	{/literal}
	{include file="footer.tpl"}