{literal}
<script type="text/javascript">
    function includecomma1(c,v)
{
var x=Math.round(c);
x=x.toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != '')
lastThree = ',' + lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
//var res = res.toFixed(4);
//var res =number_format(res, 2);
var res = res+'.00';
document.getElementById(v).innerHTML=res;
}
</script>
<script type="text/javascript">
	function includecomma1(c,v)
{
//var x=Math.round(c);
//var x=c.toFixed(2);

var x=c.split(".");
var ld=x[1];
var ty=typeof(x[1]);//alert(ty);
if(ty == 'undefined')
{
   
    var ld='00';
}
else
{
var ld=x[1].slice(0, 2);
}
x=x[0].toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != '')
{
lastThree = ',' + lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
}
else
{
lastThree =  lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
}
//var res = res+'.00';
var res = res+'.'+ld;
document.getElementById(v).innerHTML=res;
}
</script>
{/literal}
<body onLoad="GetSensor()">
	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{if $smarty.session.USER_GROUP eq 'Branch Admin' || $smarty.session.USER_GROUP eq 'Branch User'}
			
				<td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>
				
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{/if}
				<td style="font-size:15PX;font-weight: bold;">AC Reports</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{if $smarty.session.USER_GROUP eq 'Branch Admin' || $smarty.session.USER_GROUP eq 'Branch User'}
				<td style="font-size:10PX;color:#999999;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{/if}
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			</div>
		</div>
		<form name="meterList" method="post" id="meterList">
		    <input type="hidden" id="ssensor" name="ssensor" value="{$ListDailyRep.0.sensorCode}">
		<div class="row">
			<div class="col-12">
				<div class="card">				
				{if $SuccessMessage neq "" || $ErrorMessage neq ""}
					<div class="card-body">
					{if $SuccessMessage neq ""}
						<div class="isa_success">
						<i class="fa fa-check"></i>
						{$SuccessMessage}		 
						</div>
					{/if}
					{if $ErrorMessage neq ""}
						<div class="isa_error">
						<i class="fa fa-check"></i>
						{$ErrorMessage}		 
						</div>
					{/if}
					</div>
				{/if}
				 <input type="hidden" id="sname" name="sname" value="{$smarty.post.sensorName}" />
					<div class="card-body table-responsive">
						<div class="col-sm-12">
						    <div class=""  style="float:left;margin-top:10PX;margin-right:5px;">From Date: <input type="text" id="fromDate" name="fromDate" value="{if  $smarty.post.fromDate eq ''}{$yesterday|date_format:'%Y-%m-%d'}{else}{$smarty.post.fromDate|date_format:'%Y-%m-%d'}{/if}" class="form-control" autocomplete="off" readonly="true" ></div>
						    <div class=""  style="float:left;margin-top:10PX;margin-right:5px;" > To Date: <input type="text" id="toDate" name="toDate" value="{if  $smarty.post.toDate eq ''}{$yesterday|date_format:'%Y-%m-%d'}{else}{$smarty.post.toDate|date_format:'%Y-%m-%d'}{/if}" class="form-control" autocomplete="off" readonly="true"></div>&nbsp;&nbsp;
						 <div class="col-sm-3"  style="float:left;margin-top:30PX;margin-right:5px;">
						     {if $smarty.session.USER_GROUP eq 'Branch Admin' || $smarty.session.USER_GROUP eq 'Branch User'}
						<select class="form-control" id="branchName" name="branchName"  tabindex="1" onChange="GetSensor();" disabled   >
						    {else}
						    <select class="form-control" id="branchName" name="branchName"  tabindex="1" onchange="GetSensor();"   >
						    {/if}
						    <option value="">--Select Branch--</option>
						    {if $smarty.session.USER_GROUP eq 'Branch Admin' || $smarty.session.USER_GROUP eq 'Branch User'}
						    <option value="{$branchDetail.0.sl_no}" selected="selected">{$branchDetail.0.branch_name}</option>
						    {else}
						{foreach from=$ListBranch item=ListBnh}
						{if $smarty.post.branchName eq $ListBnh.sl_no}<option value="{$ListBnh.sl_no}" selected="selected">{$ListBnh.branch_name}</option>{/if}
						{if $smarty.post.branchName neq $ListBnh.sl_no}<option value="{$ListBnh.sl_no}">{$ListBnh.branch_name}</option>{/if}
						{/foreach}
						{/if}
						</select>
						</div>
							<div class="col-sm-3"  style="float:left;margin-top:30PX;margin-right:5px;">
						<select class="form-control" id="sensorName" name="sensorName"  tabindex="1"  >
						<option value="">--Select Sensor--</option>
					
						</select>
						</div>
						<div class=""  style="float:left;margin-top:30PX">
						<input type="button" value="Submit" id="submitButton" name="submitButton" class="btn btn-create">
						</div>
						</div>
						
					<P><br><br></P>
						<table id="example" class="table table-bordered table-hover">
						<thead>
						<tr>
						<th class="slNo">#</th>
						<th class="">Datetime</th>
						<th class="">Ambient Temp Indoor</th>
						<th class="">Cold Air Temp Indoor</th>
						<th class="">Ambient Temp Outdoor</th>
						<th class="">Hot Air Temp Outdoor</th>
						<th class="">Condensor Outlet Temp</th>
						<th class="">Compressor In</th>
						<th class="">Compressor Out</th>
						
						</tr>
						</thead>
						<tbody>
						{foreach from=$ListDailyRep item=List}
						{if $List.recorded_date lte $smarty.now|date_format:'%Y-%m-%d %I:%M %p'}
						<tr id="{$j++}">
						<td >{$j}</td>
						<td>{$List.recorded_date_time|date_format:'%e-%b-%Y %I:%M %p'}</td>
					    <td align="left">{$List.ampient_temperature_indoor}</td>
						<td align="left">{$List.coldair_temperature_indoor}</td>
						<td align="left">{$List.ampient_temperature_outdoor	}</td>
						<td align="left">{$List.hotair_temperature_outdoor}</td>
						<td align="left">{$List.condensor_outlet_temperature}</td>
						<td align="left">{$List.compressor_in}</td>
						<td align="left">{$List.compressor_out}</td>
						
						<!--<td align="right" id="1{$j}"><script type="text/javascript">includecomma1('{$List.start_cum_kwh}','1{$j}');</script></td>
						<td align="right" id="2{$j}"><script type="text/javascript">includecomma1('{$List.end_cum_kwh}','2{$j}');</script></td>
						<td align="right" id="3{$j}"><script type="text/javascript">includecomma1('{$List.consuption_kwh}','3{$j}');</script></td>
						<td align="right" id="4{$j}"><script type="text/javascript">includecomma1('{$List.cost}','4{$j}');</script></td>
						<td align="right" id="5{$j}"><script type="text/javascript">includecomma1('{$List.consuption_cost}','5{$j}');</script></td>-->
						{assign var="grandTCost" value=$grandTCost+$List.consuption_cost}
						</tr>
						{/if}
						
						{foreachelse}
						<tr><td colspan="9"><center>No Records Found</center></td></tr>
						{/foreach}
						{if $ListDailyRep.0.start_cum_kwh neq ''}
						<tr>
						    <td></td>
						    <td></td>
						    <td></td>
						    <td></td>
						    <td></td>
						<td align="right" ><b>Total</b></td>
						<td align="right"><b>Rs. <span id="gtot"><script type="text/javascript">includecomma1('{$grandTCost}','gtot');</script></span></b></td>
						</tr>
						{/if}
						</tbody>
						</table>
					</div>
				</div>
			</div>
		</form>
	</section>
	</div>
	</body>
	{literal}
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	<link rel="stylesheet" href="/resources/demos/style.css">
    <script>

	$( function() {
		$( "#fromDate" ).datepicker({changeMonth: true,
		changeYear: true,maxDate: '-1',dateFormat:'yy-mm-dd'});
		$( "#toDate" ).datepicker({changeMonth: true,
		changeYear: true,maxDate: '-1',dateFormat:'yy-mm-dd'});
	} );
	</script>
	<script type="text/javascript">
	setTimeout(myURL, 5000);
	function myURL(){
	this.form.submit();
	}
	$(document).ready(function() {
	$('#sensorName').on('change', function() {
	this.form.submit();
	});
	$('#submitButton').on('click', function() {
	this.form.submit();
	});
	});
	</script>
	<style>
	.slNo{
	width:5%;
	}
	.code{
	width:10%;
	}
	.apiKey{
	width:30%;
	}
	.name{
	width:40%;
	}
	.isactive{
	width:10%;
	text-align:center;
	
	}
	.action{
	text-align:right;
	}
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>
	<script type="text/javascript">
	$(document).ready(function (){
	
	var table = $('#example').DataTable({
	"ordering" : false,
	"pageLength": 50,
	"bPaginate": false,
	language: {
	"infoFiltered": ""/*,
	search: "_INPUT_",
	searchPlaceholder: "Search..."*/
	},
	dom: '<bottom>p',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: '<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p',
	//dom: '<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p',
	
	initComplete: function(){
	//$("div.toolbar").html('<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>');   	
	}       
	}); 
	}); 
	
	function unitPriceCats(slNoIdent,metIdIdent,compIdent,locIdIdent) {
		var sid = btoa(slNoIdent); var mid = btoa(metIdIdent); var comId = btoa(compIdent); var lId = btoa(locIdIdent);
		FormName		= document.meterList;
		FormName.action ='unitPriceList.php?sl_no='+sid+'&companyId='+comId+'&location_id='+lId+'&meter_id='+mid;
		FormName.submit();
	}
	
	function editCats(recordedDate,sensorCode,userName) {
		var sid = recordedDate;
		var mid = sensorCode;  
		var comId = userName; 
	$.ajax({
	type: "POST",
	url: "cronEnergyMeterData.php",
	data: {recorded_date:recordedDate,sensor_code:sensorCode,userName:userName},
	dataType: "text",
	cache: false,
	success: function(result){
	var len = result.length;
	//$("#testDate").val(result);
	//alert(result);
	location.reload(true);
	},
	error: function(result) {
	alert('error');
	}
	});
	}
	</script>
	<script type="text/javascript">
	function deleteCats(slNoIdent,serialIdIdent,compIdent,branIdent,gateIdent){
		var sid = btoa(slNoIdent); var scId = btoa(serialIdIdent);var comId = btoa(compIdent); var gId = btoa(gateIdent);var bId = btoa(branIdent);
		if(confirm("Are you sure to Delete this Content?")){
		FormName		= document.meterList;
		FormName.action= 'sensorList.php?gatewayId='+gId+'&companyId='+comId+'&branchId='+bId+'&sl_no='+sid+'&sen_code='+scId;
		FormName.submit();
		}
	}
	</script>
	<script type="text/javascript">
	    function doOnLoad()
	    {
	        var branch = document.getElementById('branchName').value;
	        var ssensor = document.getElementById('ssensor').value;
	       
	    }
	</script>

	<script type="text/javascript">
function GetSensor()
{
var val = document.getElementById('branchName').value;
var val1 = document.getElementById('sname').value;

$.ajax({
	type: "POST",
	url: "getSensors.php",
	data: {branch:val},
	success: function(result){
	var res = JSON.parse(result);
	var nlen=Object.keys(res).length;
	$("#sensorName").empty();
	var sel = '--Select Sensor--';
	$("#sensorName").append("<option value='' selected>"+sel+"</option>");
for( var i = 0; i<nlen; i++){
var id = res[i]['id'];
var name = res[i]['name'];
if(val1 == id)
{
$("#sensorName").append("<option value='"+id+"' selected>"+name+"</option>");
}
else if(val == '' && val1 == '')
{
$("#sensorName").append("<option value='' selected>"+sel+"</option>");
}
else
{
$("#sensorName").append("<option value='"+id+"'>"+name+"</option>");
}
}
	},
	error: function(result) {
	alert('error');
	}
	});
}
</script>
	{/literal}
	{include file="footer.tpl"}