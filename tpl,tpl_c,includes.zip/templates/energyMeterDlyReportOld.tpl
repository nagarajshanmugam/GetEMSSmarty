	{literal}
	
	<link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
	<!-- Ionicons -->
	<link rel="stylesheet" href="dist/css/ionicons.min.css">
	<!-- Select2 -->
	<link rel="stylesheet" href="plugins/select2/css/select2.min.css">
	<link rel="stylesheet" href="plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
	<!-- Tempusdominus Bbootstrap 4 -->
	<link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
	<!-- iCheck -->
	<link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
	<!-- DataTables -->
	<link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.css">
	<!-- JQVMap -->
	<link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
	<!-- Theme style -->
	<link rel="stylesheet" href="dist/css/adminlte.min.css">
	<!-- overlayScrollbars -->
	<link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
	<!-- daterange picker -->
	<link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
	<!-- summernote -->
	<link rel="stylesheet" href="plugins/summernote/summernote-bs4.css">
	<!-- SweetAlert2 -->
	<link rel="stylesheet" href="plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
	<!-- Toastr -->
	<link rel="stylesheet" href="plugins/toastr/toastr.min.css">
	<!-- Google Font: Source Sans Pro -->
	<link href="dist/css/fontsgoogleapis.css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
	<!-- External Style file-->
	<link rel="stylesheet" href="dist/css/styleems.css">
	<script src="plugins/jquery/jquery.min.js"></script>
	<!-- jQuery UI 1.11.4 -->
	<script src="plugins/jquery-ui/jquery-ui.min.js"></script>
	<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
	<script>
	$.widget.bridge('uibutton', $.ui.button)
	</script>
	<!-- Bootstrap 4 -->
	<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
	<!-- Select2 -->
	<script src="plugins/select2/js/select2.full.min.js"></script>
	<!-- InputMask -->
	<script src="plugins/moment/moment.min.js"></script>
	<script src="plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>
	<!-- date-range-picker -->
	<script src="plugins/daterangepicker/daterangepicker.js"></script>
	<!-- ChartJS -->
	<script src="plugins/chart.js/Chart.min.js"></script>
	<!-- Sparkline -->
	<script src="plugins/sparklines/sparkline.js"></script>
	<!-- JQVMap -->
	<script src="plugins/jqvmap/jquery.vmap.min.js"></script>
	<script src="plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
	<!-- jQuery Knob Chart -->
	<script src="plugins/jquery-knob/jquery.knob.min.js"></script>
	<script src="plugins/datatables/jquery.dataTables.js"></script>
	<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
	<!-- Tempusdominus Bootstrap 4 -->
	<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
	<!-- Summernote -->
	<script src="plugins/summernote/summernote-bs4.min.js"></script>
	<!-- overlayScrollbars -->
	<script src="plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
	<!-- AdminLTE App -->
	<script src="plugins/sweetalert2/sweetalert2.min.js"></script>
	<!-- Toastr -->
	<script src="plugins/toastr/toastr.min.js"></script>
	<script src="dist/js/adminlte.js"></script>
	<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
	<script src="dist/js/pages/dashboard.js"></script>
	<!-- AdminLTE for demo purposes -->
	<script src="dist/js/demo.js"></script>
		<script type="text/javascript">
	function includecomma1(c,v)
{
//var x=Math.round(c);
//var x=c.toFixed(2);

var x=c.split(".");
var ld=x[1];
var ty=typeof(x[1]);//alert(ty);
if(ty == 'undefined')
{
   
    var ld='00';
}
else
{
var ld=x[1].slice(0, 2);
}
x=x[0].toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != '')
{
lastThree = ',' + lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
}
else
{
lastThree =  lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
}
//var res = res+'.00';
var res = res+'.'+ld;
document.getElementById(v).innerHTML=res;
}
</script>
	<script>
	$(function () {
	$('#example1').DataTable({
	'paging'      : true,
	'lengthChange': false,
	'searching'   : true,
	'ordering'    : false,
	'info'        : false,
	'pageLength': 50,
	'autoWidth'   : false
	})
	})
	</script>
	<style type="text/css">
	form {
		overflow-x: hidden;
	}
	th
	{
	position: sticky;
  top: 0;
  }
	</style>
	{/literal}
		<form role="form" name="dataraange" id="dataraange" action="" method="POST">
		    	<input type="hidden" id="gatewayCode" name="gatewayCode" value="{$smarty.get.gatewayCode}" />
			<input type="hidden" id="sensorCode" name="sensorCode" value="{$smarty.get.sensorCode}" />
			<div class="row">
				<div class="form-group col-md-3">
					<label for="exampleInputserialNo">From Date <span style="color:red;">*</span></label>
					<input type="text" size="15" id="date1" name="date1" autocomplete="OFF" class="form-control form-control-sm" readonly="true" value= "{if $smarty.post.date1 neq ""}{$smarty.post.date1|date_format:'%e-%b-%Y'}{else}{$firstday|date_format:'%e-%b-%Y'}{/if}"/>
				</div>
				<div class="form-group col-md-3">
					<label for="exampleInputserialNo">To Date <span style="color:red;">*</span></label>
					<input type="text" size="15" id="date2" name="date2" autocomplete="OFF" class="form-control form-control-sm" readonly="true" value= "{if $smarty.post.date2 neq ""}{$smarty.post.date2|date_format:'%e-%b-%Y'}{else}{$yesterday|date_format:'%e-%b-%Y'}{/if}"/>
				</div>
			<div class="form-group col-md-3" style="margin-top:8px;"><br />
				<input type="button" onClick="formvalidate();" class="btn btn-sm" value="Get Report" style="color:#FFFFFF; background-color:#17a2b8;"/>&nbsp;&nbsp;&nbsp;&nbsp;
				<a href="#" onClick="get_excel();"><img src="images/excel1.png"  height="26" width="26" alt="Excel" title="Xls" ></a>
			&nbsp;&nbsp;&nbsp;<a href="javascript:window.print()"><img src="images/print-icon.gif" height="26" width="26"  alt="Print" title="Print"></a>
			</div>
			</div>
		</form>
	<center>	
		<table class="table table-bordered table-hover" id="section-to-print">
		<thead>
		<tr align="center">
		<th colspan="6" bgcolor="#17a2b8" style="color:#FFFFFF" class="style3 style1" scope="row"><img src="images/1133035.png" height="14" width="14">&nbsp;&nbsp;<span class="">Meter Log View From {if $getFromDate eq ""}{$firstday|date_format:'%e-%b-%Y'}{else}{$getFromDate|date_format:'%e-%b-%Y'}{/if} To {if $getToDate eq ""}{$yesterday|date_format:'%e-%b-%Y'}{else}{$getToDate|date_format:'%e-%b-%Y'}{/if} 
		</span>   </th></tr>
		{assign var=someVar value=$GetDLog.0.sensor_code}
	{assign var=temp value='[-]'|split:$someVar}
	<input type="hidden" id="senMode" name="senMode" value="{$temp[0]}"  />
		<tr>
		<th>Date</th>
		<th>Start Kwh </th>
		<th>End Kwh</th>
		<th>Total Kwh</th>
		<th>Unit Rate</th>
		<th>Total Cost</th>
		</tr>
		</thead>
		{foreach from=$GetDLog item=List}
		{assign var=sumKWH value=$sumKWH+$List.consuption_kwh}
		{assign var=sumCost value=$sumCost+$List.consuption_cost}
		{if $List.recorded_date eq ''}
		{assign var=newDate value="0000-00-00"} 
		{else}
		{assign var=orgDate value=$List.recorded_date} 
		{assign var=date value=strtotime($orgDate)}
		{assign var=newDate value=$orgDate|date_format:'%d-%m-%Y'} 
		{/if}
		<tbody>	
		<tr>
		<td><div align="center" class="">{$newDate|date_format:"%e-%b-%Y"}</div></td>
		<td><div align="right" class="">{if $List.start_cum_kwh eq ''}0{else}{$List.start_cum_kwh|string_format:"%.2f"}{/if}</div></td>
		<td><div align="right" class="">{if $List.end_cum_kwh eq ''}0{else}{$List.end_cum_kwh|string_format:"%.2f"}{/if}</div></td>
		<td><div align="right" class="">{if $List.consuption_kwh eq ''}0{else}{$List.consuption_kwh|string_format:"%.2f"}{/if}</div></td>
		<td><div align="right" class="">{if $List.cost eq ''}0{else}{$List.cost|string_format:"%.2f"}{/if}</div></td>
		<td><div align="right" class="">{if $List.consuption_cost eq ''}0{else}{$List.consuption_cost|string_format:"%.2f"}{/if}</div></td>
		</tr>
		</tbody>
		{foreachelse}
		<tr><td colspan="6"><center>No Records Found</center></td></tr>
		{/foreach}
		<tr>
		<td colspan="3"><div align="right" class=""><b>Total KWH</b></div></td>
		<td><div align="right" class=""><b><span id="skwh"><script type="text/javascript">includecomma1('{$sumKWH}','skwh');</script></span></b></div></td>
		<td><div align="right" class=""><b>Total Cost</b></div></td>
		<td><div align="right" class=""><b>Rs.<span id="scost"><script type="text/javascript">includecomma1('{$sumCost}','scost');</script></span></b></div></td>
		</tr>
		</table></center>
    	<div class="clear"></div>
	{literal}
	<link rel="stylesheet" href="css/jquery-ui.css">
	<!--<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">-->
	<script>
	$( function() {
		$( "#date1" ).datepicker({changeMonth: true,
		changeYear: true,maxDate: '-1',dateFormat:'yy-mm-dd'});
		$( "#date2" ).datepicker({changeMonth: true,
		changeYear: true,maxDate: '-1',dateFormat:'yy-mm-dd'});
	} );
	</script>
	<script type="text/javascript">
	function createValidation(){
		var segmentCode = $('#segmentCode').val();
		var segmentName = $('#segmentName').val();
		var isActive = document.getElementById("customCheckbox2").checked;
	
	if (isActive == false) 
	{
		document.getElementById('checkVal').value='0';
	}
	else
	{
		document.getElementById('checkVal').value='1';
	}
		$(".error").remove();
	if (segmentCode.length < 1) {
		$('#segmentCode').after('<span class="error">This field is required</span>');
		$('#segmentCode').focus();
		return false;					
	}
	else if (segmentName < 1) {
		$('#segmentName').after('<span class="error">This field is required</span>');
		$('#segmentName').focus();
		return false;					
	}
		FormName		= document.gatewayRegForm;
		FormName.method	= "POST";
		FormName.submit();
	}
	function GoBack()
	{
		window.history.back();
	}
	</script>
	<script> 
	// dhtml Calendar
	function formvalidate()
	{
		var	date1=document.getElementById("date1").value;
		var	date2=document.getElementById("date2").value;
		
		var d = new Date(date1);
      var month = '' + (d.getMonth() + 1);
      var  day = '' + d.getDate();
      var  year = d.getFullYear();
        if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;
        var	date1=year + "-" + month + "-" + day;
        
        var d2 = new Date(date2);
      var month2 = '' + (d2.getMonth() + 1);
      var  day2 = '' + d2.getDate();
      var  year2 = d2.getFullYear();
        if (month2.length < 2) month2 = '0' + month2;
    if (day2.length < 2) day2 = '0' + day2;
        var	date2=year2 + "-" + month2 + "-" + day2;
        
	
	if(date1 =='')
	{
		alert("Please Specify From Date");
		document.getElementById("date1").style.borderColor="red";
		return false;
	}
	else if(date2 =='')
	{
		alert("Please Specify To Date");
		document.getElementById("date2").style.borderColor="red";
		return false;
	}else if(date1 > date2)
	{
		alert("Do Not enter From Date greater than To Date");
		document.getElementById("date1").style.borderColor="red";
		return false;
	}
		FormName	= document.dataraange;
  			  FormName.method	= "POST";
              FormName.submit();	
	}	
	</script>
	<script type="text/javascript">
	function get_excel(){
		var gatewayCode = document.getElementById("gatewayCode").value;
		var sensorCode = document.getElementById("sensorCode").value;
		var date1 = document.getElementById("date1").value;
		var date2 = document.getElementById("date2").value;
		var senMode = document.getElementById("senMode").value;
	
	if((date1!='' || date2 !='') )
	{
	if(date1 =='')
	{
		alert("Please Specify From Date");
		document.getElementById("date1").style.borderColor="red";
		return false;
	}
	else if(date2 =='')
	{
		alert("Please Specify To Date");
		document.getElementById("date2").style.borderColor="red";
		return false;
	}
	else if(date1 > date2)
	{
		alert("Do Not enter From Date greater than to Date");
		document.getElementById("date1").style.borderColor="red";
		return false;
	}
	}
	if(senMode != "TE")
	{ 
		window.location.href="dly_log_report_xl.php?gatewayCode="+gatewayCode+"&sensorCode="+sensorCode+"&date1="+date1+"&date2="+date2;
	}
	else
	{
		window.location.href="trinityEntityDly_xl.php?gatewayCode="+gatewayCode+"&sensorCode="+sensorCode+"&date1="+date1+"&date2="+date2;
	} 
	}
	</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	@media print {
	body * {
	visibility: hidden;
	}
	#section-to-print, #section-to-print * {
	visibility: visible;
	}
	#section-to-print {
	position: absolute;
	left: 0;
	top: 0;
	}
	}
	</style>
	{/literal}
