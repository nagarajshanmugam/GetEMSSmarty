	{literal}
	<script type="text/javascript">
    function addcomma(c)
{
var x=c;
x=x.toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != '')
    lastThree = ',' + lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
return res;
}

function includecomma(c)
{
var x=c;
x=x.toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != '')
    lastThree = ',' + lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
return res;
}
</script>
<script type="text/javascript">
	function includecomma1(c,v)
{
//var x=Math.round(c);
//var x=c.toFixed(2);

var x=c.split(".");
var ld=x[1];
var ty=typeof(x[1]);//alert(ty);
if(ty == 'undefined')
{
   
    var ld='00';
}
else
{
var ld=x[1].slice(0, 2);
}
x=x[0].toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != '')
{
lastThree = ',' + lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
}
else
{
lastThree =  lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
}
//var res = res+'.00';
if(res == '')
{
    var res='0';
}
var res = res+'.'+ld;
document.getElementById(v).innerHTML=res;
}
</script>

	<script src="amcharts/amcharts.js"></script>
	<script src="amcharts/serial.js"></script>
	<script src="amcharts/themes/light.js"></script>
	<!--     Gauge Script      --->
	<script src="./amChart/amchart.js"></script>
	<script src="./js/gaugeChart/gauge.js"></script>
	<script src="./js/gaugeChart/export.min.js"></script>

	<script src="amcharts/plugins/export/export.min.js"></script>
	<link rel="stylesheet" href="amcharts/plugins/export/export.css" type="text/css" media="all" />
	<script src="./amChart/amchartLight.js"></script>
<script src="./amChart/amchartColumnChart.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<style type="text/css">
	.thal
	{
	text-align:left;
	}
	.thar
	{
	text-align:right;
	}
	.bclass
	{
	font:Geneva, Arial, Helvetica, sans-serif;
	font-size:14px;
	font-weight:600;
	}
	</style>
	<!-- Styles -->
	<style>
	#chartdiv {
	width: 100%;
	height: 500px;
	}
	#chartdiv2 {
	width: 100%;
	height: 500px;
	}
	#chartdiv3 {
	width: 100%;
	height: 500px;
	}
	#Barchartdiv {
	width: 100%;
	height: 500px;
	}
	#Linechartdiv {
	width	: 100%;
	height	: 800px;
	}	
	.noscroll,.tab-content
	{
	overflow-x:hidden;
	}
	</style>
	<!----     Line Chart         ------------->
	<script>
	var chart = AmCharts.makeChart("Linechartdiv", {
	"type": "serial",
	"theme": "none",
	"marginTop":5,
	"marginBottom":0,
	"marginRight": 50,
	"dataProvider": {/literal}{$LineGraphData}{literal},
	"valueAxes": [{
	"axisAlpha": 0,
	"position": "left",
	"gridAlpha": 0.2,
	"dashLength": 0
	}],
	"graphs": [{
	"id":"g1",
	"balloonText": "[[category]]<br><b><span style='font-size:14px;'>[[EB]] kwh</span></b>",
	"bullet": "round",
	"bulletSize": 8,
	"lineColor": "#d1655d",
	"lineThickness": 2,
	"negativeLineColor": "#637bb6",
	"type": "smoothedLine",
	"valueField": "EB",
	"animationPlayed": true
	}],
	"chartScrollbar": {
	"enabled" :false, //true if you need drag  option in top
	"graph":"g1",
	"gridAlpha":0,
	"color":"#888888",
	"scrollbarHeight":55,
	"backgroundAlpha":0,
	"selectedBackgroundAlpha":0.1,
	"selectedBackgroundColor":"#888888",
	"graphFillAlpha":0,
	"autoGridCount":true,
	"selectedGraphFillAlpha":0,
	"graphLineAlpha":0.2,
	"graphLineColor":"#c2c2c2",
	"selectedGraphLineColor":"#888888",
	"selectedGraphLineAlpha":1
	
	},
	"chartCursor": {
	"categoryBalloonDateFormat": "YYYY",
	"cursorAlpha": 0,
	"valueLineEnabled":true,
	"valueLineBalloonEnabled":true,
	"valueLineAlpha":0.5,
	"fullWidth":true,
	"zoomable": false //true if line chart need zoom option
	
	},
	"categoryField": "month",
	"export": {
	"enabled": true
	}
	});
	Linechart.addListener("rendered", zoomChart);
	if(Linechart.zoomChart){
	Linechart.zoomChart();
	}
	
	function zoomChart(){
	Linechart.zoomToIndexes(Math.round(Linechart.dataProvider.length * 0.4), Math.round(Linechart.dataProvider.length * 0.55));
	}
	
	</script>
	
	<!----       AmChart Bar Chart       ---------->
	<script>
	//var plotBarGraphData=JSON.parse(bGraphData);
	var Barchart = AmCharts.makeChart( "Barchartdiv", {
	"type": "serial",
	"theme": "none",
	"dataProvider": {/literal}{$BarGraphData}{literal},
	"valueAxes": [ {
	"gridColor": "#FFFFFF",
	"gridAlpha": 0.2,
	"dashLength": 0
	} ],
	"gridAboveGraphs": true,
	"startDuration": 1,
	"graphs": [ {
	"balloonText": "[[category]]: <b>Rs.[[value]]</b>",
	"fillAlphas": 0.8,
	"lineAlpha": 0.2,
	"type": "column",
	"valueField": "cost"
	} ],
	"chartCursor": {
	"categoryBalloonEnabled": false,
	"cursorAlpha": 0,
	"zoomable": false
	},
	"categoryField": "month",
	"categoryAxis": {
	"gridPosition": "start",
	"gridAlpha": 0,
	"tickPosition": "start",
	"tickLength": 5 // length for x axis bottom line
	},
	"export": {
	"enabled": true
	}
	} );
	</script>
	<script>
	var chart = AmCharts.makeChart("chartdiv", {
	"theme": "none",
	"type": "gauge",
	"axes": [{
	"topTextFontSize": 20,
	"topTextYOffset": 70,
	"axisColor": "#31d6ea",
	"axisThickness": 1,
	"endValue": {/literal}{$KW_MAX}{literal},
	"gridInside": true,
	"inside": true,
	"radius": "60%",
	"valueInterval": {/literal}{$KW_INT}{literal},
	"tickColor": "#67b7dc",
	"startAngle": -90,
	"endAngle": 90,
	"unit": "",
	"labelsEnabled":true,
	"bandOutlineAlpha": 0,
	"bands": [{
	"color": "#0080ff",
	"endValue": {/literal}{$KW_MAX}{literal},
	"innerRadius": "105%",
	"radius": "170%",
	"gradientRatio": [0.5, 0, -0.5],
	"startValue": 0
	}, {
	"color": "#3cd3a3",
	"endValue": 0,
	"innerRadius": "105%",
	"radius": "170%",
	"gradientRatio": [0.5, 0, -0.5],
	"startValue": 0
	}]
	}],
	"arrows": [{
	"alpha": 1,
	"innerRadius": "35%",
	"nailRadius": 0,
	"radius": "170%"
	}]
	});
	setInterval(randomValue, 500);
	// set random value
	function randomValue() {
	var value = {/literal}{$ListFeederDet.0.SUM_KW}{literal};
	chart.arrows[0].setValue(value);
	chart.axes[0].setTopText(value + " KW");
	// adjust darker band to new value
	chart.axes[0].bands[1].setEndValue(value);
	}
	</script>
	<script>
	var chart2 = AmCharts.makeChart("chartdiv2", {
	"theme": "none",
	"type": "gauge",
	"axes": [{
	"topTextFontSize": 20,
	"topTextYOffset": 70,
	"axisColor": "#31d6ea",
	"axisThickness": 1,
	"endValue": {/literal}{$KVA_MAX}{literal},
	"gridInside": true,
	"inside": true,
	"radius": "60%",
	"valueInterval": {/literal}{$KVA_INT}{literal},
	"tickColor": "#67b7dc",
	"startAngle": -90,
	"endAngle": 90,
	"unit": "",
	"labelsEnabled":true,
	"bandOutlineAlpha": 0,
	"bands": [{
	"color": "#0080ff",
	"endValue": {/literal}{$KVA_MAX}{literal},
	"innerRadius": "105%",
	"radius": "170%",
	"gradientRatio": [0.5, 0, -0.5],
	"startValue": 0
	}, {
	"color": "#3cd3a3",
	"endValue": 0,
	"innerRadius": "105%",
	"radius": "170%",
	"gradientRatio": [0.5, 0, -0.5],
	"startValue": 0
	}]
	}],
	"arrows": [{
	"alpha": 1,
	"innerRadius": "35%",
	"nailRadius": 0,
	"radius": "170%"
	}]
	});
	setInterval(randomValue2, 500);
	// set random value
	function randomValue2() {
	var value = {/literal}{$ListFeederDet.0.SUM_KVA}{literal};
	chart2.arrows[0].setValue(value);
	chart2.axes[0].setTopText(value + " KVA");
	// adjust darker band to new value
	chart2.axes[0].bands[1].setEndValue(value);
	}
	</script>
	<script>
	var chart3 = AmCharts.makeChart("chartdiv3", {
	"theme": "none",
	"type": "gauge",
	"axes": [{
	"topTextFontSize": 20,
	"topTextYOffset": 70,
	"axisColor": "#31d6ea",
	"axisThickness": 1,
	"endValue": {/literal}{$KVAR_MAX}{literal},
	"gridInside": true,
	"inside": true,
	"radius": "60%",
	"valueInterval": {/literal}{$KVAR_INT}{literal},
	"tickColor": "#67b7dc",
	"startAngle": -90,
	"endAngle": 90,
	"unit": "",
	
	"labelsEnabled":true,
	"bandOutlineAlpha": 0,
	"bands": [{
	"color": "#0080ff",
	"endValue": {/literal}{$KVAR_MAX}{literal},
	"innerRadius": "105%",
	"radius": "170%",
	"gradientRatio": [0.5, 0, -0.5],
	"startValue": 0
	}, {
	"color": "#3cd3a3",
	"endValue": 0,
	"innerRadius": "105%",
	"radius": "170%",
	"gradientRatio": [0.5, 0, -0.5],
	"startValue": 0
	}]
	}],
	"arrows": [{
	"alpha": 1,
	"innerRadius": "35%",
	"nailRadius": 0,
	"radius": "170%"
	}]
	});
	setInterval(randomValue3, 500);
	// set random value
	function randomValue3() {
	var value = {/literal}{$ListFeederDet.0.SUM_KVAR}{literal};
	chart3.arrows[0].setValue(value);
	chart3.axes[0].setTopText(value + " KVAR");
	// adjust darker band to new value
	chart3.axes[0].bands[1].setEndValue(value);
	}
	</script>
	{/literal}
	<div class="content-wrapper ">
	<div class="content-header">
	<div class="container-fluid ">
	<div class="row"> <div class="col-md-12">
	<div class="card">
	<div class="card-body">
		<table style="margin-bottom:-10px;">
		<tr><td style="font-size:15PX;font-weight: bold;">{$LoctList.0.companyName}&nbsp;&nbsp;</td>
		<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="font-size:15PX;font-weight: bold;">{$LoctList.0.branch_name}&ensp;&ensp;</td>
		<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="font-size:15PX;font-weight: bold;">{$LoctList.0.sensorName}</font>&nbsp;</td>
		<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="font-size:15PX;font-weight: bold;">{$LoctList.0.gateway_id} - {if $LoctList.0.gateway_id neq 'YMN-1' && $LoctList.0.gateway_id eq $gateList.0.gateway_code && $gateList.0.gateway_date_time gte $dateSec|date_format:'%Y-%m-%d %H:%M:%S' }<a style="color:#00CC00;"> ON </a>{elseif $LoctList.0.gateway_id eq 'YMN-1' && $LoctList.0.gateway_id eq $gateList.0.gateway_code && $gateList.0.gateway_date_time gte $dateSec1|date_format:'%Y-%m-%d %H:%M:%S'} <a style="color: #00CC00;"> ON</a> {else} <a style="color: #FF0000;"> OFF</a> {/if}</font>&nbsp;</td>
		</tr>
		
		<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
		<td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="font-size:10PX;color:#999999;">Branch Name</td>
		<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="color:#999999;font-size:10PX;">Feeder Name (Place of Installation)</td>
		<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="color:#999999;font-size:10PX;">Gateway Name - Status</td>
		</tr>
		</table>
		<input type="hidden" id="gatewayCode" value="{$smarty.get.gatewayCode}" />
		<input type="hidden" id="sensorCode" value="{$smarty.get.sensorCode}" />
		<form name="dashboard" id="dashboard" method="post">
		<div  style="margin-top:-40PX;float:right" class="col-md-4"  >
	<b>Select Feeder &nbsp;&nbsp;: &nbsp;&nbsp;</b><select  id="feederPost" name="feederPost"  style="width:200PX" onchange="postFeeder();">
	{foreach from=$ListFeeder item=listDet}
	{if $LoctList.0.sensorName eq $listDet.sensorName}
	<option value="{$listDet.sensorName}/{$listDet.sensorCode|base64_encode}/{$listDet.gateway_id|base64_encode}/{$listDet.company_id|base64_encode}/{$listDet.branch_id|base64_encode}"  selected="selected">{$LoctList.0.sensorName}</option> {/if}
	{if $LoctList.0.sensorName neq $listDet.sensorName}
	<option value="{$listDet.sensorName}/{$listDet.sensorCode|base64_encode}/{$listDet.gateway_id|base64_encode}/{$listDet.company_id|base64_encode}/{$listDet.branch_id|base64_encode}">{$listDet.sensorName}</option>
	{/if}
	{/foreach}
	</select>
	</div>
	</form>
	</div>
	</div>
	</div>
	</div>
	<div class="row">
		<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box card-outline card-primary">
			<span class="info-box-icon bg-info elevation-1"><i class="fa fa-rupee"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">Today Cost&ensp;&ensp;&ensp;&ensp;</span>
			<span class="info-box-number">
			{if $todayCostKWH.0.cost eq ''}0.00{else}{$todayCostKWH.0.cost}{/if}
			<script type="text/javascript">includecomma1('{$View.grandAmt}','{$s}');</script>
			<small></small>
			</span>
			</div>
			</div>
		</div>
		<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2 card-outline card-danger">
			<span class="info-box-icon bg-danger elevation-1"><i class="fa fa-bolt"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">Today KWH&ensp;&ensp;&ensp;&ensp;</span>
			<span class="info-box-number">
			    {if $todayCostKWH.0.TOTAL_KWH eq ''}0.00{else}{$todayCostKWH.0.TOTAL_KWH}{/if}
			    <script type="text/javascript">includecomma1('{$View.grandAmt}','{$s}');</script>
			    </span>
			</div>
			</div>
		</div>
	<!-- fix for small devices only -->
	<div class="clearfix hidden-md-up"></div>
			<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2 card-outline card-primary">
			<span class="info-box-icon bg-info elevation-1"><i class="fa fa-rupee"></i></span>
			<div class="info-box-content">
			<span class="info-box-text"> This Month Cost</span>
			<span class="info-box-number" id="tmc">
			<script type="text/javascript">includecomma1('{$monthCostKWH.0.cost}','tmc');</script>
			</span>
			</div>
			</div>
			</div>
			<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2 card-outline card-danger">
			<span class="info-box-icon bg-danger elevation-1"><i class="fa fa-bolt"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">This Month KWH</span>
			<span class="info-box-number" id="tmk">
			    <script type="text/javascript">includecomma1('{$monthCostKWH.0.TOTAL_KWH}','tmk');</script>
			    </span>
			</div>
			</div>
			</div>
	<div class="clearfix hidden-md-up"></div>
		<div class="col-12 col-sm-6 col-md-2">
		<div class="info-box mb-2 card-outline card-primary">
		<span class="info-box-icon bg-info elevation-1"><i class="fa fa-rupee"></i></span>
		<div class="info-box-content">
		<span class="info-box-text">Last Month Cost</span>
		<span class="info-box-number" id="lmc">
		    <script type="text/javascript">includecomma1('{$LastMonthCostKWH.0.cost}','lmc');</script>
		    </span>
		</div>
		</div>
		</div>
		<div class="col-12 col-sm-6 col-md-2">
		<div class="info-box mb-2 card-outline card-danger">
		<span class="info-box-icon bg-danger elevation-1"><i class="fa fa-bolt"></i></span>
		<div class="info-box-content">
		<span class="info-box-text">Last Month KWH</span>
		<span class="info-box-number" id="lmk">
		    <script type="text/javascript">includecomma1('{$LastMonthCostKWH.0.TOTAL_KWH}','lmk');</script>
		    </span>
		</div>
		</div>
		</div>
	</div>
		

	
	{if $ListFeederDet2 eq "0"}
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-body">
				<h1 align="center" style="color:#FF0000"> No Records Found  </h1>
				</div>
			</div>
		</div>
	</div>
	{else}
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-body">
					<div class="row">
						<div class="col-md-4" >
							<div class="card card-widget widget-user-2">
								<div class="card card-outline card-primary">
									<div class="card-header">
									<h5 class="" style="text-align:left"><b>KW </b></h5>
									</div>
								</div>
								<div class="card-footer" style="height:200PX">
									<ul class="nav flex-column" >
									<li class="nav-item" style="backgroud-color:white">
									<div id="chartdiv" style="margin-top:-115PX"></div>
									</li>
									</ul>
								</div>
							</div>
						</div><div class="col-md-4" >
					<div class="card card-widget widget-user-2">
						<div class="card card-outline card-primary">
							<div class="card-header">
							<h5 class="" style="text-align:left"><b>KVA</b></h5>
							</div>
						</div>
						<div class="card-footer" style="height:200PX">
							<ul class="nav flex-column" >
							<li class="nav-item" style="backgroud-color:white">
							<div id="chartdiv2" style="margin-top:-115PX"></div>
							</li>
							</ul>
						</div>
					</div>
					</div>
						<div class="col-md-4" >
							<div class="card card-widget widget-user-2">
								<div class="card card-outline card-primary">
									<div class="card-header">
									<h5 class="" style="text-align:left"><b>KVAR </b></h5>
									</div>
								</div>
								<div class="card-footer" style="height:200PX">
									<ul class="nav flex-column" >
									<li class="nav-item" style="backgroud-color:white">
									<div id="chartdiv3" style="margin-top:-115PX"></div>
									</li>
									</ul>
								</div>
							</div>
						</div>
        				</div>
					<div class="row">
						<div class="col-md-4">
							<div class="card card-widget widget-user-2">
								<div class="card-footer p-0">
									<ul class="nav flex-column">
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b>VR</b> <span class="float-right badge bg-danger">{$ListFeederDet.0.R_VOLTAGE}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> VY </b><span class="float-right badge bg-warning">{$ListFeederDet.0.Y_VOLTAGE}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> VB</b> <span class="float-right badge bg-primary">{$ListFeederDet.0.B_VOLTAGE}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> Status - {$ListFeederDet.0.recorded_date_time|date_format:"%d-%b-%Y %I:%M %p"} </b><span class="float-right badge bg-success">Last Logged</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b>Feeder Name </b><span class="float-right badge bg-success">{$ListFeederDet.0.sensorName}</span>
										</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="card card-widget widget-user-2">
								<div class="card-footer p-0">
									<ul class="nav flex-column">
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> VRY </b><span class="float-right badge bg-danger">{$ListFeederDet.0.RY_VOLTAGE}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b>VYB</b> <span class="float-right badge bg-warning">{$ListFeederDet.0.YB_VOLTAGE}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> VBR</b> <span class="float-right badge bg-primary">{$ListFeederDet.0.BR_VOLTAGE}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> PF</b> <span class="float-right badge bg-success">{$ListFeederDet.0.SUM_PF}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> Frequency </b> <span class="float-right badge bg-success">{$ListFeederDet.0.FREQUENCY}</span>
										</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="card card-widget widget-user-2">					
								<div class="card-footer p-0">
									<ul class="nav flex-column">
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b>IR</b> <span class="float-right badge bg-danger">{$ListFeederDet.0.R_CURRENT}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b>IY</b> <span class="float-right badge bg-warning">{$ListFeederDet.0.Y_CURRENT}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> IB</b> <span class="float-right badge bg-primary">{$ListFeederDet.0.B_CURRENT}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black" >
										<b>KWH</b> <span class="float-right badge bg-success">{$ListFeederDet.0.KWH}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black" >
										<b> Run Hr</b> <span class="float-right badge bg-success">{$ListFeederDet.0.RUN_HOUR}</span>
										</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
						
					
					
					<textarea id="currMonQutDaily" name="currMonQutDaily" style="display:none">{$getCurMonSalDaily}</textarea>
        <div class="row">
				<div class="col-md-12">
			
					<div class="card card-primary card-outline">
						<div class="card-header">
						<h3 class="card-title">
						<i class="far fa-chart-bar"></i>
						Daily Cost Chart
						</h3>
						</div>
                        
					<!--<div id="linechartdiv" style="height: 260px;"></div><br />-->
                    
                    <div class="chart">
        <canvas id="DailybarChart2" style="height: 208px;" ></canvas>
        </div>
                    
					</div>
				</div>
			
			
			
			
			</div>	
						
				<div class="row">
					<div class="col-md-6">
						<div class="card card-primary card-outline">
							<div class="card-header">
							<h3 class="card-title">
							<i class="far fa-chart-bar"></i>
							Cost Chart
							</h3>
							</div>
						<div id="Barchartdiv" style="height: 300px;"></div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="card card-primary card-outline">
							<div class="card-header">
							<h3 class="card-title">
							<i class="far fa-chart-bar"></i>
							Kwh Chart
							</h3>
							</div>
							<div class="card-body">
							<div id="Linechartdiv" style="height: 260px;"></div>
							</div>
						</div>
					</div>
				</div>
				
			
				<!--<section class="content">
				    <div class="box box-default color-palette-box">
        
        <div class="box-body">
          <div class="row">
            <div class="col-sm-4 col-md-2">
              <h4 class="text-center">Primary</h4>

              <div class="color-palette-set">
                <div class="bg-light-blue disabled color-palette"><span>Disabled</span></div>
                <div class="bg-light-blue color-palette"><span>#3c8dbc</span></div>
                <div class="bg-light-blue-active color-palette"><span>Active</span></div>
              </div>
            </div>
            <div class="col-sm-4 col-md-2">
              <h4 class="text-center">Info</h4>

              <div class="color-palette-set">
                <div class="bg-aqua disabled color-palette"><span>Disabled</span></div>
                <div class="bg-aqua color-palette"><span>#00c0ef</span></div>
                <div class="bg-aqua-active color-palette"><span>Active</span></div>
              </div>
            </div>
            <div class="col-sm-4 col-md-2">
              <h4 class="text-center">Success</h4>

              <div class="color-palette-set">
                <div class="bg-green disabled color-palette"><span>Disabled</span></div>
                <div class="bg-green color-palette"><span>#00a65a</span></div>
                <div class="bg-green-active color-palette"><span>Active</span></div>
              </div>
            </div>
            <div class="col-sm-4 col-md-2">
              <h4 class="text-center">Warning</h4>

              <div class="color-palette-set">
                <div class="bg-yellow disabled color-palette"><span>Disabled</span></div>
                <div class="bg-yellow color-palette"><span>#f39c12</span></div>
                <div class="bg-yellow-active color-palette"><span>Active</span></div>
              </div>
            </div>
            <div class="col-sm-4 col-md-2">
              <h4 class="text-center">Danger</h4>

              <div class="color-palette-set">
                <div class="bg-red disabled color-palette"><span>Disabled</span></div>
                <div class="bg-red color-palette"><span>#f56954</span></div>
                <div class="bg-red-active color-palette"><span>Active</span></div>
              </div>
            </div>
            <div class="col-sm-4 col-md-2">
              <h4 class="text-center">Gray</h4>

              <div class="color-palette-set">
                <div class="bg-gray disabled color-palette"><span>Disabled</span></div>
                <div class="bg-gray color-palette"><span>#d2d6de</span></div>
                <div class="bg-gray-active color-palette"><span>Active</span></div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-sm-4 col-md-2">
              <h4 class="text-center">Navy</h4>

              <div class="color-palette-set">
                <div class="bg-navy disabled color-palette"><span>Disabled</span></div>
                <div class="bg-navy color-palette"><span>#001F3F</span></div>
                <div class="bg-navy-active color-palette"><span>Active</span></div>
              </div>
            </div>
            <div class="col-sm-4 col-md-2">
              <h4 class="text-center">Teal</h4>

              <div class="color-palette-set">
                <div class="bg-teal disabled color-palette"><span>Disabled</span></div>
                <div class="bg-teal color-palette"><span>#39CCCC</span></div>
                <div class="bg-teal-active color-palette"><span>Active</span></div>
              </div>
            </div>
            <div class="col-sm-4 col-md-2">
              <h4 class="text-center">Purple</h4>

              <div class="color-palette-set">
                <div class="bg-purple disabled color-palette"><span>Disabled</span></div>
                <div class="bg-purple color-palette"><span>#605ca8</span></div>
                <div class="bg-purple-active color-palette"><span>Active</span></div>
              </div>
            </div>
            <div class="col-sm-4 col-md-2">
              <h4 class="text-center">Orange</h4>

              <div class="color-palette-set">
                <div class="bg-orange disabled color-palette"><span>Disabled</span></div>
                <div class="bg-orange color-palette"><span>#ff851b</span></div>
                <div class="bg-orange-active color-palette"><span>Active</span></div>
              </div>
            </div>
            <div class="col-sm-4 col-md-2">
              <h4 class="text-center">Maroon</h4>

              <div class="color-palette-set">
                <div class="bg-maroon disabled color-palette"><span>Disabled</span></div>
                <div class="bg-maroon color-palette"><span>#D81B60</span></div>
                <div class="bg-maroon-active color-palette"><span>Active</span></div>
              </div>
            </div>
            <div class="col-sm-4 col-md-2">
              <h4 class="text-center">Black</h4>

              <div class="color-palette-set">
                <div class="bg-black disabled color-palette"><span>Disabled</span></div>
                <div class="bg-black color-palette"><span>#111111</span></div>
                <div class="bg-black-active color-palette"><span>Active</span></div>
              </div>
            </div>
          </div>
        </div>
      </div>
				</section>-->
				<div class="row">
					<div class="col-md-12">
						<div class="card card-primary card-tabs">
							<div class="card-header p-0 pt-1 border-bottom-0">
								<ul class="nav nav-tabs" id="custom-content-below-tab" role="tablist">
									<li class="nav-item">
									<a class="nav-link active" id="custom-content-below-messages-tab" data-toggle="pill" href="#tab-4" role="tab" aria-controls="custom-content-below-messages" aria-selected="false"  onclick="dailyReport()" >Daily Report</a>
									</li>
									<li class="nav-item">
									<a class="nav-link" id="custom-content-below-messages-tab" data-toggle="pill" href="#tab-3" role="tab" aria-controls="custom-content-below-messages" aria-selected="false" onclick="logReport()">Log Report</a>
									</li>
									<li class="nav-item">
									<a class="nav-link " id="custom-content-below-profile-tab" data-toggle="pill" href="#tab-1" role="tab" aria-controls="custom-content-below-profile" aria-selected="true" onclick="trentGraph()">Historical Trend</a>
									</li>
									
								
								</ul>
							</div>
							 <div class="tab-content" >
										<div id="tab-4" class="tab-pane active" >
									<!--<div class="loader"></div>-->
										<div class="card-body">
										<iframe  height="820px" width="98%" src="./energyMeterDlyReport.php?gatewayCode={$smarty.get.gatewayCode}&sensorCode={$smarty.get.sensorCode}" style="border:1px;"></iframe></div>
										<!--<iframe id="daily_report" height="820px" width="98%" src="" style="border:1px;"></iframe></div>-->
									</div>
									<div id="tab-3" class="tab-pane">
									<div class="loader" style="background-color:#999999"></div>
										<div class="card-body">
										<iframe id="log_report" height="820px" width="98%" src="" style="border:1px;"></iframe>
										</div>
									</div>
								
									<div id="tab-1" class="tab-pane ">
									<div class="loader"></div>
											<div class="card-body">
											<iframe id="trendGraph" height="820px" width="100%" src="" style="border:1px;"></iframe></div>
									</div>
							</div>
						</div>
					</div>
				</div>
				</div>
			</div>
		</div>
	</div>{/if}
	</div>
	</div>
	</div>
	{literal}
	<style>
	.loader {
	margin: 200px auto;
	font-size: 25px;
	width: 1em;
	height: 1em;
	border-radius: 50%;
	position: relative;
	text-indent: -9999em;
	-webkit-animation: load5 1.1s infinite ease;
	animation: load5 1.1s infinite ease;
	-webkit-transform: translateZ(0);
	-ms-transform: translateZ(0);
	transform: translateZ(0);
	}
	@-webkit-keyframes load5 {
	0%,
	100% {
	box-shadow: 0em -2.6em 0em 0em #0a7b6e, 1.8em -1.8em 0 0em rgba(10,123,110, 0.2), 2.5em 0em 0 0em rgba(10,123,110, 0.2), 1.75em 1.75em 0 0em rgba(10,123,110, 0.2), 0em 2.5em 0 0em rgba(10,123,110, 0.2), -1.8em 1.8em 0 0em rgba(10,123,110, 0.2), -2.6em 0em 0 0em rgba(10,123,110, 0.5), -1.8em -1.8em 0 0em rgba(10,123,110, 0.7);
	}
	12.5% {
	box-shadow: 0em -2.6em 0em 0em rgba(10,123,110, 0.7), 1.8em -1.8em 0 0em #0a7b6e, 2.5em 0em 0 0em rgba(10,123,110, 0.2), 1.75em 1.75em 0 0em rgba(10,123,110, 0.2), 0em 2.5em 0 0em rgba(10,123,110, 0.2), -1.8em 1.8em 0 0em rgba(10,123,110, 0.2), -2.6em 0em 0 0em rgba(10,123,110, 0.2), -1.8em -1.8em 0 0em rgba(10,123,110, 0.5);
	}
	25% {
	box-shadow: 0em -2.6em 0em 0em rgba(10,123,110, 0.5), 1.8em -1.8em 0 0em rgba(10,123,110, 0.7), 2.5em 0em 0 0em #0a7b6e, 1.75em 1.75em 0 0em rgba(10,123,110, 0.2), 0em 2.5em 0 0em rgba(10,123,110, 0.2), -1.8em 1.8em 0 0em rgba(10,123,110, 0.2), -2.6em 0em 0 0em rgba(10,123,110, 0.2), -1.8em -1.8em 0 0em rgba(10,123,110, 0.2);
	}
	37.5% {
	box-shadow: 0em -2.6em 0em 0em rgba(10,123,110, 0.2), 1.8em -1.8em 0 0em rgba(10,123,110, 0.5), 2.5em 0em 0 0em rgba(10,123,110, 0.7), 1.75em 1.75em 0 0em #0a7b6e, 0em 2.5em 0 0em rgba(10,123,110, 0.2), -1.8em 1.8em 0 0em rgba(10,123,110, 0.2), -2.6em 0em 0 0em rgba(10,123,110, 0.2), -1.8em -1.8em 0 0em rgba(10,123,110, 0.2);
	}
	50% {
	box-shadow: 0em -2.6em 0em 0em rgba(10,123,110, 0.2), 1.8em -1.8em 0 0em rgba(10,123,110, 0.2), 2.5em 0em 0 0em rgba(10,123,110, 0.5), 1.75em 1.75em 0 0em rgba(10,123,110, 0.7), 0em 2.5em 0 0em #0a7b6e, -1.8em 1.8em 0 0em rgba(10,123,110, 0.2), -2.6em 0em 0 0em rgba(10,123,110, 0.2), -1.8em -1.8em 0 0em rgba(10,123,110, 0.2);
	}
	62.5% {
	box-shadow: 0em -2.6em 0em 0em rgba(10,123,110, 0.2), 1.8em -1.8em 0 0em rgba(10,123,110, 0.2), 2.5em 0em 0 0em rgba(10,123,110, 0.2), 1.75em 1.75em 0 0em rgba(10,123,110, 0.5), 0em 2.5em 0 0em rgba(10,123,110, 0.7), -1.8em 1.8em 0 0em #0a7b6e, -2.6em 0em 0 0em rgba(10,123,110, 0.2), -1.8em -1.8em 0 0em rgba(10,123,110, 0.2);
	}
	75% {
	box-shadow: 0em -2.6em 0em 0em rgba(10,123,110, 0.2), 1.8em -1.8em 0 0em rgba(10,123,110, 0.2), 2.5em 0em 0 0em rgba(10,123,110, 0.2), 1.75em 1.75em 0 0em rgba(10,123,110, 0.2), 0em 2.5em 0 0em rgba(10,123,110, 0.5), -1.8em 1.8em 0 0em rgba(10,123,110, 0.7), -2.6em 0em 0 0em #0a7b6e, -1.8em -1.8em 0 0em rgba(10,123,110, 0.2);
	}
	87.5% {
	box-shadow: 0em -2.6em 0em 0em rgba(10,123,110, 0.2), 1.8em -1.8em 0 0em rgba(10,123,110, 0.2), 2.5em 0em 0 0em rgba(10,123,110, 0.2), 1.75em 1.75em 0 0em rgba(10,123,110, 0.2), 0em 2.5em 0 0em rgba(10,123,110, 0.2), -1.8em 1.8em 0 0em rgba(10,123,110, 0.5), -2.6em 0em 0 0em rgba(10,123,110, 0.7), -1.8em -1.8em 0 0em #0a7b6e;
	}
	}
	@keyframes load5 {
	0%,
	100% {
	box-shadow: 0em -2.6em 0em 0em #0a7b6e, 1.8em -1.8em 0 0em rgba(10,123,110, 0.2), 2.5em 0em 0 0em rgba(10,123,110, 0.2), 1.75em 1.75em 0 0em rgba(10,123,110, 0.2), 0em 2.5em 0 0em rgba(10,123,110, 0.2), -1.8em 1.8em 0 0em rgba(10,123,110, 0.2), -2.6em 0em 0 0em rgba(10,123,110, 0.5), -1.8em -1.8em 0 0em rgba(10,123,110, 0.7);
	}
	12.5% {
	box-shadow: 0em -2.6em 0em 0em rgba(10,123,110, 0.7), 1.8em -1.8em 0 0em #0a7b6e, 2.5em 0em 0 0em rgba(10,123,110, 0.2), 1.75em 1.75em 0 0em rgba(10,123,110, 0.2), 0em 2.5em 0 0em rgba(10,123,110, 0.2), -1.8em 1.8em 0 0em rgba(10,123,110, 0.2), -2.6em 0em 0 0em rgba(10,123,110, 0.2), -1.8em -1.8em 0 0em rgba(10,123,110, 0.5);
	}
	25% {
	box-shadow: 0em -2.6em 0em 0em rgba(10,123,110, 0.5), 1.8em -1.8em 0 0em rgba(10,123,110, 0.7), 2.5em 0em 0 0em #0a7b6e, 1.75em 1.75em 0 0em rgba(10,123,110, 0.2), 0em 2.5em 0 0em rgba(10,123,110, 0.2), -1.8em 1.8em 0 0em rgba(10,123,110, 0.2), -2.6em 0em 0 0em rgba(10,123,110, 0.2), -1.8em -1.8em 0 0em rgba(10,123,110, 0.2);
	}
	37.5% {
	box-shadow: 0em -2.6em 0em 0em rgba(10,123,110, 0.2), 1.8em -1.8em 0 0em rgba(10,123,110, 0.5), 2.5em 0em 0 0em rgba(10,123,110, 0.7), 1.75em 1.75em 0 0em #0a7b6e, 0em 2.5em 0 0em rgba(10,123,110, 0.2), -1.8em 1.8em 0 0em rgba(10,123,110, 0.2), -2.6em 0em 0 0em rgba(10,123,110, 0.2), -1.8em -1.8em 0 0em rgba(10,123,110, 0.2);
	}
	50% {
	box-shadow: 0em -2.6em 0em 0em rgba(10,123,110, 0.2), 1.8em -1.8em 0 0em rgba(10,123,110, 0.2), 2.5em 0em 0 0em rgba(10,123,110, 0.5), 1.75em 1.75em 0 0em rgba(10,123,110, 0.7), 0em 2.5em 0 0em #0a7b6e, -1.8em 1.8em 0 0em rgba(10,123,110, 0.2), -2.6em 0em 0 0em rgba(10,123,110, 0.2), -1.8em -1.8em 0 0em rgba(10,123,110, 0.2);
	}
	62.5% {
	box-shadow: 0em -2.6em 0em 0em rgba(10,123,110, 0.2), 1.8em -1.8em 0 0em rgba(10,123,110, 0.2), 2.5em 0em 0 0em rgba(10,123,110, 0.2), 1.75em 1.75em 0 0em rgba(10,123,110, 0.5), 0em 2.5em 0 0em rgba(10,123,110, 0.7), -1.8em 1.8em 0 0em #0a7b6e, -2.6em 0em 0 0em rgba(10,123,110, 0.2), -1.8em -1.8em 0 0em rgba(10,123,110, 0.2);
	}
	75% {
	box-shadow: 0em -2.6em 0em 0em rgba(10,123,110, 0.2), 1.8em -1.8em 0 0em rgba(10,123,110, 0.2), 2.5em 0em 0 0em rgba(10,123,110, 0.2), 1.75em 1.75em 0 0em rgba(10,123,110, 0.2), 0em 2.5em 0 0em rgba(10,123,110, 0.5), -1.8em 1.8em 0 0em rgba(10,123,110, 0.7), -2.6em 0em 0 0em #0a7b6e, -1.8em -1.8em 0 0em rgba(10,123,110, 0.2);
	}
	87.5% {
	box-shadow: 0em -2.6em 0em 0em rgba(10,123,110, 0.2), 1.8em -1.8em 0 0em rgba(10,123,110, 0.2), 2.5em 0em 0 0em rgba(10,123,110, 0.2), 1.75em 1.75em 0 0em rgba(10,123,110, 0.2), 0em 2.5em 0 0em rgba(10,123,110, 0.2), -1.8em 1.8em 0 0em rgba(10,123,110, 0.5), -2.6em 0em 0 0em rgba(10,123,110, 0.7), -1.8em -1.8em 0 0em #0a7b6e;
	}
	}
	</style>
	<script type="text/javascript">
/*	var gId=$("#gatewayCode").val();
	var sId=$("#sensorCode").val();
	var pageURL = $(location).attr("href");	
	window.onload = function(){
	setTimeout(function(){
	document.getElementById('trendGraph').src = './trendGraph.php?gatewayCode='+gId+'&sensorCode='+sId;
	document.getElementById('log_report').src = './icdMeterLog.php?gatewayCode='+gId+'&sensorCode='+sId;
	document.getElementById('daily_report').src = './energyMeterDlyReport.php?gatewayCode='+gId+'&sensorCode='+sId;
	setTimeout(function(){ $(".loader").hide();},500);
	},500);
	};*/
		function dailyReport(){
	var gId=$("#gatewayCode").val();
	var sId=$("#sensorCode").val();
	document.getElementById('daily_report').src = './energyMeterDlyReport.php?gatewayCode='+gId+'&sensorCode='+sId;
	$(".loader").hide();
	}
	function trentGraph(){
	var gId=$("#gatewayCode").val();
	var sId=$("#sensorCode").val();
	document.getElementById('trendGraph').src = './trendGraph.php?gatewayCode='+gId+'&sensorCode='+sId;
	$(".loader").hide();
	}
		function logReport(){
	var gId=$("#gatewayCode").val();
	var sId=$("#sensorCode").val();
	document.getElementById('log_report').src = './icdMeterLog.php?gatewayCode='+gId+'&sensorCode='+sId;
	$(".loader").hide();
	}
	function postFeeder()
	{
		var feederName=document.getElementById("feederPost").value;
		var feedSplit= feederName.split("/");
		var senCod=feedSplit[1];
		var gatCod=feedSplit[2];
		var comId=feedSplit[3];
		var branId=feedSplit[4];
		FormName		= document.dashboard;
		FormName.action= "meterDashboard.php?companyId="+comId+"&branchId="+branId+"&sensorCode="+senCod+"&gatewayCode="+gatCod;
		FormName.submit();
	}
	</script>
	<script type="text/javascript">
var result = document.getElementById('currMonQutDaily').value;
//alert(result);
var jsonData=result;
var obj = JSON.parse(jsonData);
var mon = "";
var dataVal = "";
var dataVal1 = "";
var colo = "";
var i;
for (i = 0; i < obj.length; i++) {
if(i==0){
  mon += obj[i].dateM ;
  dataVal += obj[i].value;
  dataVal1 += obj[i].value1;
  colo += obj[i].color;
   }
  else
  {
  mon += ", "+ obj[i].dateM;
  dataVal += ", "+ obj[i].value;
   dataVal1 += ", "+ obj[i].value1;
   colo += ', '+ obj[i].color;
 }
}
// loop  variable concatinate each  record  as an array
var monthVal = mon;
var dataValue =dataVal;
var dataValue1 =dataVal1;
var colors =colo;
//alert(dataValue);
//alert(dataValue1);
// above mentioned  array variable  split by comma to plot the variable in lable and data in chart
var month =  monthVal.split(',');
var dataV=  dataVal.split(',');//alert(numberWithCommas(dataV));
//alert(dataV);
 
   var dis = Math.round(dataV);//alert(dis);
  var vad = addcomma(dis);//alert(vad);
//var dataV=addCommas(dataV);
var dataV1=  dataVal1.split(',');
//alert(dataV1);
var clr=  colors.split(',');

  var barChartCanvas = $('#DailybarChart2').get(0).getContext('2d');
 

  var barChartData = {
    labels  :  month,
    datasets: [
      {
          label               : 'Kwh',
          backgroundColor     : '#67b7dc',
          borderColor         :  '#67b7dc',
          pointRadius          : false,
          pointColor          :  '#67b7dc',
          pointStrokeColor    :  '#67b7dc',
          pointHighlightFill  :  '#67b7dc',
          pointHighlightStroke:  '#67b7dc',
		  fillColor: "#67b7dc",
          data                : dataV
      },
      {
        label                 : 'Cost',
          backgroundColor     : '#fdd400',
          borderColor         :  '#fdd400',
          pointRadius         : false,
          pointColor          :  '#fdd400',
          pointStrokeColor    :  '#fdd400',
          pointHighlightFill  :  '#fdd400',
          pointHighlightStroke:  '#fdd400',
		  fillColor: "#fdd400",
          data                : dataV1
      }
    ]
  };
  
   
  
    var barChartOptions = {
	tooltips: {
        callbacks: {
            label: function(tooltipItem) {
			var dis = Math.round(tooltipItem.yLabel);
  var vad = includecomma(dis);
  //alert(vad);
                return  vad;
            }
        }
    },
      responsive              : true,
      maintainAspectRatio     : false,
      datasetFill             : true,
	    scales: {
		yAxes: [{
              ticks:{
                  stepSize : 5000,

              }
			  }]
		}
	      };


    var barChartSec = new Chart(barChartCanvas, {
      type: 'bar', 
      data: barChartData,
      options: barChartOptions,
    });
	
	barChartSec.Bar(barChartData, barChartOptions);
	
</script>
	<style type="text/css">
	#DailybarChart2{
	width	: 100%;
	height	: 450px;
	}
	</style>
	<style type="text/css">
	iframe {
		overflow-x: hidden;
		overflow-y: scroll;
	}
	</style>
	{/literal}
	{include file="footer.tpl"}