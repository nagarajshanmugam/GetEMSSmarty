	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">{if $smarty.get.groupId eq ""}Create User Group{else}Edit User Group{/if}</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			<a href="userGroupList.php"> <button type="button" class="btn btn-primary" value="List Userrole" style="float:right;margin-top:-40PX">List User Group</button></a>
			</div>
		</div>
	<div class="card">
	{if $SuccessMessage neq ""}
		<div class="card-body">
			<div class="isa_success">
			<i class="fa fa-check"></i>
			{$SuccessMessage}		 
			</div>
		</div>
	{/if}
	{if $ErrorMessage neq ""}
		<div class="card-body">
			<div class="isa_error">
			<i class="fa fa-check"></i>
			{$ErrorMessage}		 
			</div>
		</div>
	{/if}  
		<div class="card-body">
		<form  role="form" name="userGroupReg" id="userGroupReg" method="post" onsubmit="return ValidateFields();">
			<input type="hidden" name="hdAction" id="hdAction">
			<input type="hidden" id="group" name="group" value="{$ListEditView.0.slNo}" />
			<input type="hidden" id="checkVal" name="checkVal" value="{$smarty.post.checkVal}" />
			<input id="created_by" name="created_by" class="date-picker form-control" type="hidden" value="{$smarty.session.UserName}" readonly="true" tabindex="5">
		<div class="row">
		<div class="form-group col-md-6">
			<label for="inputEmail3">Usergroup Name <span class="required"><b>*</b></span></label>
			<input type="text" name="usergroupName" class="form-control form-control-sm" id="usergroupName" placeholder="UserGroup Name" autocomplete="Off" tabindex="1" value="{if $ListEditView.0.usergroupName neq ""}{$ListEditView.0.usergroupName}{/if}" onblur="ValidateFields1('usergroupName');">
		</div>
			<div class="form-group col-md-6">
				<div class="custom-control custom-checkbox">
				{if $ListEditView.0.usergroupName neq ''}
				{if $ListEditView.0.isActive eq "1"}
					<input class="custom-control-input" type="checkbox" id="customCheckbox2"  name="customCheckbox2" tabindex="6" checked="checked">
					<label for="customCheckbox2" class="custom-control-label">Is Active <span class="required"><b>*</b></span></label>
				{else}
					<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="6">
					<label for="customCheckbox2" class="custom-control-label">Is Active <span class="required"><b>*</b></span></label>
				{/if}
				{else}
					<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="6" checked="checked">
					<label for="customCheckbox2" class="custom-control-label">Is Active <span class="required"><b>*</b></span></label>
				{/if}
				</div>
				<input id="created_by" name="created_by" class="date-picker form-control" type="hidden" value="{$smarty.session.UserName}" readonly="true">
				<input type="hidden" class="form-control" id="timestamp" name="timestamp" value="{$smarty.now|date_format:'%Y-%m-%d &amp; %I:%M:%S %p'}">
				<input type="hidden" class="form-control" id="created_time" name="created_time" placeholder="Time" Value="{$smarty.now|date_format:'%I:%M:%S %p'}">
			</div>
			<div class="form-group col-md-6">
				<h3 class="m-t-none m-b">Roles Creation</h3>
			</div>
			<div class="form-group col-md-6"></div>
			<div class="hr-line-dashed"></div>	   
			  {if $ListEditView.0.slNo neq ""}
				  <div class="col-md-5">
				<select class="form-control input-lg" multiple="multiple" name="exam16[]" id="exam16" size="15" value="{$exam16}" autocomplete="Off" tabindex="4" onblur="ValidateFields1('exam16');">
							{foreach from=$uRoleList item=ListDet}
								<option value="{$ListDet.slNo}">{$ListDet.menuName} - ( {$ListDet.menuType} )</option>	
							{/foreach}
				 </select>
							</div>
						{else}
							<div class="col-md-5">
				<select class="form-control input-lg" multiple="multiple" name="exam16[]" id="exam16" size="15" value="{$exam16}" autocomplete="Off" tabindex="4" onblur="ValidateFields1('exam16');">
							{foreach from=$RoleList item=ListDet1}
								<option value="{$ListDet1.slNo}">{$ListDet1.menuName} - ( {$ListDet1.menuType} )</option>	
							{/foreach}
				</select>
							</div>
						{/if}
						<div class="col-sm-2 top-buffer" ><center>
						<br /><br /><br /><br /><br /><br />
					<input type="button" class="btn btn-sm btn-create m-t-n-xs" name="add" value=">>" onClick="moveOptionLeftToRight(this.form.exam16,this.form.dexam16)" id="roleadd" autocomplete="Off" ><br><br>
					<input type="button" class="btn btn-sm btn-create m-t-n-xs" name="remove" value="<<" onClick="moveOptionRightToLeft(this.form.dexam16, this.form.exam16)" id="roleremove" autocomplete="Off" >
						</center></div>
						 {if $ListEditView.0.slNo neq ""}
							 <div class="col-sm-5">
			                 <select class="form-control input-lg" multiple="multiple" name="dexam16[]" id="dexam16" size="15" value="{$dexam16}" autocomplete="Off" tabindex="5" onblur="ValidateFields1('dexam16');">
							{foreach from=$groupMapping item=ListDet2}
							<option value="{$ListDet2.slNo}">{$ListDet2.menuName} - ( {$ListDet2.menuType} )</option>	
							{/foreach}
							 </select>
							 </div>
						 {else}
							 <div class="col-sm-5">
			<select class="form-control input-lg" multiple="multiple" name="dexam16[]" id="dexam16" size="15" value="{$dexam16}" autocomplete="Off" tabindex="5" onblur="ValidateFields1('dexam16');">
							  </select>
							 </div>
						 {/if}
					</div>
		 </div>
		<div align="center"><center>
		<input type="submit" value="Submit" class="btn btn-create" onclick="ValidateFields();listbox_selectall('dexam16', true)" />
		</center></div>
	<br />
	</form>
	</div>
	</div>
	</section>
	</div>
	{literal}
	<script type="text/javascript">
	function ValidateFields1(id)
	{
	var val = document.getElementById(id).value;
	if(val == '')
	{
		$(".error").remove();
		$("#"+id).after('<span class="error">This field is required</span>');
		$("#"+id).focus();
		return false;		
	}
	else
	{
		$(".error").remove();
		return true;
	}
	}
	function ValidateFields()
	{
		var usergroupName = $('#usergroupName').val();
		var dexam16 = $('#dexam16').val();
		var isActive = document.getElementById("customCheckbox2").checked;
	
	if (isActive == false) 
	{
		document.getElementById('checkVal').value='0';
	}
	else
	{
		document.getElementById('checkVal').value='1';
	}
	
	$(".error").remove();
	if (usergroupName.length < 1) {
		$('#usergroupName').after('<span class="error">This field is required</span>');
		$('#usergroupName').focus();
		return false;					
	}
	else if(dexam16.length < 1) {
		$('#dexam16').after('<span class="error">This field is required</span>');
		$('#dexam16').focus();
		return false;					
	}
		userGroupReg.hdAction.value = 1;
		return true;
	}
	function GoBack()
	{
		window.history.back();
	}
	//*************************************swapping start*********************************************//
	function moveOptionLeftToRight(objSourceElement,objTargetElement)
	{ 
		var aryTempSourceOptions = new Array();
		var x = 0;
	
	for (var i = 0; i < objSourceElement.length; i++){
	if (objSourceElement.options[i].selected){
	if(objTargetElement.options.length > 0 && objTargetElement.options[0].text == 'None'){
		objTargetElement.options.length = 0;		
	}
		var intTargetLen = objTargetElement.length++;
	if((objSourceElement.options[i].text=="Other")&&(objSourceElement.name=="exam16[]"))
	{
		statuschng1('specdosh',objSourceElement.name,objSourceElement.options[i].value)
	}
		objTargetElement.options[intTargetLen].text = objSourceElement.options[i].text;
		objTargetElement.options[intTargetLen].value = objSourceElement.options[i].value;
	}else{			
		var objTempValues = new Object();
		objTempValues.text = objSourceElement.options[i].text;
		objTempValues.value = objSourceElement.options[i].value;
		aryTempSourceOptions[x] = objTempValues;
		x++;
	}
	}
		objSourceElement.length = aryTempSourceOptions.length;	
	for (var i = 0; i < aryTempSourceOptions.length; i++) {
		objSourceElement.options[i].text = aryTempSourceOptions[i].text;
		objSourceElement.options[i].value = aryTempSourceOptions[i].value;
		objSourceElement.options[i].selected = false;
	}
	}
	function moveOptionRightToLeft(objSourceElement, objTargetElement){
		var aryTempSourceOptions = new Array();
		var x = 0;
	if(objSourceElement.options.length > 0 && objSourceElement.options[0].text == 'None'){
	return false;
	}
	for (var i = 0; i < objSourceElement.length; i++){
	if (objSourceElement.options[i].selected){
		var intTargetLen = objTargetElement.length++;
		objTargetElement.options[intTargetLen].text = objSourceElement.options[i].text;
		objTargetElement.options[intTargetLen].value = objSourceElement.options[i].value;
	}else{			
		var objTempValues = new Object();
		objTempValues.text = objSourceElement.options[i].text;
		objTempValues.value = objSourceElement.options[i].value;
		aryTempSourceOptions[x] = objTempValues;
		x++;
	}
	}
		objSourceElement.length = aryTempSourceOptions.length;	
	for (var i = 0; i < aryTempSourceOptions.length; i++){
		objSourceElement.options[i].text = aryTempSourceOptions[i].text;
		objSourceElement.options[i].value = aryTempSourceOptions[i].value;
		objSourceElement.options[i].selected = false;
	}
	if(objSourceElement.options.length == 0){
		objSourceElement.options.length = 1;
		objSourceElement.options[0].text = 'None';
		objSourceElement.options[0].selected = false;
	}
	}
	function listbox_selectall(listID, isSelect) {
		var listbox = document.getElementById(listID);
	for(var count=0; count < listbox.options.length; count++) {
		listbox.options[count].selected = isSelect;
	}
	}
	</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	{/literal}
	{include file="footer.tpl"}