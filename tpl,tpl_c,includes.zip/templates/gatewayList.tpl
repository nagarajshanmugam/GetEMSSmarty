	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
			<table style="margin-bottom:-10px;">
			<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
			<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
			{if $branchDetail.0.branch_name neq ""}
					<td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>{/if}
					<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
			<td style="font-size:15PX;font-weight: bold;">List Gateway</font>&nbsp;</td></tr>
			<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
			<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
			<td style="color:#999999;font-size:10PX;">Branch Name</td>
			<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
			<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
			</tr>
			</table>
			</div>
		</div>
	<form name="gateway_list" method="post" id="gateway_list">
	<div class="row">
		<div class="col-12">
			<div class="card">
			{if $SuccessMessage neq "" || $ErrorMessage neq ""}
				<div class="card-body">
				{if $SuccessMessage neq ""}
					<div class="isa_success">
					<i class="fa fa-check"></i>
					{$SuccessMessage}		 
					</div>
				{/if}
				{if $ErrorMessage neq ""}
					<div class="isa_error">
					<i class="fa fa-check"></i>
					{$ErrorMessage}		 
					</div>
				{/if}
				</div>
			{/if}
				<div class="card-body table-responsive">
				<a href="gatewayAddEdit.php?companyId={$smarty.get.companyId}&branchId={$smarty.get.branchId}"><button type="button" style="float:right;margin-top:-6PX" class="btn btn-create">Create Gateway</button></a>{if $smarty.session.USER_GROUP eq "Company Admin"}<span style="float:right">&ensp;</span>
				<a href="companyDashboard.php"><button type="button"  style="float:right;margin-top:-6PX" class="btn btn-primary">Dashboard</button></a>{/if}{if $smarty.session.USER_GROUP eq "Super Admin"}<span style="float:right">&ensp;</span>
				<a href="branchList.php?companyId={$smarty.get.companyId}"><button type="button"  style="float:right;margin-top:-6PX" class="btn btn-primary">List Branch</button></a><span style="float:right">&ensp;</span>
				<a href="companyList.php"><button type="button"  style="float:right;margin-top:-6PX" class="btn btn-primary">List Company</button></a>{if $ListView.0.gateway_id eq ""}<br />{/if}{/if}
					<table id="example" class="table table-bordered table-hover">
					<thead>
					<tr>
					<th class="slNo">#</th>
					<th class="code">Gateway Code</th>
					<th class="model">Gateway Model Name</th>
				<!--	<th class="model">Model</th>-->
					<th class="place">Place of Installation</th>
					<th class="isactive">Status</th>
					<th>Action</th>
					</tr>
					</thead>
					<tbody>
					{foreach from=$ListView item=List}
					<tr id="{$j++}">
					<td class="slno">{$j}</td>
					<td>{$List.gateway_id}</td>
					<td>{$List.model_name}</td>
				<!--	<td>{$List.model}</td> -->
					<td>{$List.place_of_installation}</td>
					<td align="center">{if $List.is_active eq "1"}<span style="color:#009900"><b>Active</b></span>{else}<span style="color:#FF0000;"><b>Inactive</b></span>{/if}</td>
					<td align="right">
					{foreach from=$IconList item=icon}
					{if $icon.menuName eq "List Sensor"}<a href="#"  onClick="Javascript:sensorCats('{$List.sl_no}','{$List.company_id}','{$List.branch_id}','{$List.gateway_id}')" title="List Sensor"><i class="{$icon.faIcon}"></i></a>&nbsp;&nbsp;&nbsp;{/if}
					{if $icon.menuName eq "Edit Gateway"}<a href="#"  onClick="Javascript:editCats('{$List.sl_no}','{$List.gateway_id}','{$List.company_id}','{$List.branch_id}','Update=Y')" title="Edit"><i class="{$icon.faIcon}"></i></a>&nbsp;&nbsp;&nbsp;{/if}
					{if $icon.menuName eq "Delete Gateway"}<a href="#"  onClick="Javascript:deleteCats('{$List.sl_no}','{$List.company_id}','{$List.branch_id}')" title="Delete"><i class="{$icon.faIcon}"></i></a>{/if}
					{/foreach}</td>
					</tr>
					{foreachelse}
					<tr><td colspan="6"><center>No Records Found</center></td></tr>
					{/foreach}
					</tbody>
					</table>
				</div>
			</div>
		</div>
	</form>
	</section>
	</div>
	{literal}
	<style>
	.slNo{
	width:5%;
	}
	.code{
	width:15%;
	}
	.model{
	width:15%;
	}
	.place{
	width:40%;
	}
	.isactive{
	width:10%;
	text-align:center;
	
	}
	.action{
	text-align:right;
	}
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>
	<script type="text/javascript">
	$(document).ready(function (){
	
	var table = $('#example').DataTable({
	"ordering" : false,
	language: {
	"infoFiltered": "",
	search: "_INPUT_",
	searchPlaceholder: "Search..."
	},
	dom: '<"pull-left" f><bottom>p',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: '<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p',
	//dom: '<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p',
	
	initComplete: function(){
	//$("div.toolbar").html('<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>');   
	}       
	}); 
	}); 
	function editCats(slNoIdent,gateIdIdent,compIdent,branId) 
	{
		var sid = btoa(slNoIdent); var gid = btoa(gateIdIdent); var comId = btoa(compIdent); var branchId = btoa(branId);
		FormName		= document.gateway_list;
		FormName.action ='gatewayAddEdit.php?gateway_id='+gid+'&companyId='+comId+'&branchId='+branchId+'&sl_no='+sid+'&Update=y';
		FormName.submit();
	}
	function sensorCats(gateSlNo,cIdent,bIdent,gatewayId)
	 {
		var gid = btoa(gateSlNo); var cid = btoa(cIdent);var bid = btoa(bIdent);var gateid = btoa(gatewayId);
		FormName		= document.gateway_list;
		FormName.action ='sensorList.php?gatewayId='+gateid+'&companyId='+cid+'&branchId='+bid;
		FormName.submit();
	}
	</script>
	<script type="text/javascript">
	function deleteCats(slNoIdent,comIdent,branIdent)
	{
		var sid = btoa(slNoIdent); var cid = btoa(comIdent); var bid = btoa(branIdent);
		if(confirm("Are you sure to Delete this Content?")){
		FormName		= document.gateway_list;
		FormName.action= 'gatewayList.php?company_id='+cid+'&branch_id='+bid+'&sl_no='+slNoIdent;
		FormName.submit();
		}
	}
	</script>
	{/literal}
	{include file="footer.tpl"}