{literal}
<script type="text/javascript">
    function includecomma1old(c,v)
{
var x=Math.round(c);
x=x.toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != '')
lastThree = ',' + lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
//var res = res.toFixed(4);
//var res =number_format(res, 2);
var res = res+'.00';
document.getElementById(v).innerHTML=res;
}
</script>
<script type="text/javascript">
	function includecomma1(c,v)
{
//var x=Math.round(c);
//var x=c.toFixed(2);

var x=c.split(".");
var ld=x[1];//alert(x[1]);
var ty=typeof(x[1]);//alert(ty);
if(ty == 'undefined')
{
   
    var ld='00';
}
else
{
var ld=x[1].slice(0, 2);
}
//var ld=x[1].slice(0, 2);
x=x[0].toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != '')
{
lastThree = ',' + lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
}
else
{
lastThree =  lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
}
//var res = res+'.00';
var res = res+'.'+ld;
document.getElementById(v).innerHTML=res;
}
</script>
{/literal}
<body onLoad="GetGateway();GetShift();">
<div class="content-wrapper">
<section class="content-header">
	<div class="card">
		<div class="card-header">
			<table style="margin-bottom:-10px;">
			<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
			<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
			{if $smarty.session.USER_GROUP eq 'Branch Admin' || $smarty.session.USER_GROUP eq 'Branch User'}
			
				<td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>
			
			<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
			{/if}
			<td style="font-size:15PX;font-weight: bold;">Month Reports</font>&nbsp;</td></tr>
			<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
			<td style="font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
			{if $smarty.session.USER_GROUP eq 'Branch Admin' || $smarty.session.USER_GROUP eq 'Branch User'}
			<td style="font-size:10PX;color:#999999;">Branch Name</td>
			<td style="font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
			{/if}
			<td style="color:#999999;font-size:15PX;"></td><td>&nbsp;</td>
			</tr>
			</table>
		</div>
	</div>
	<form name="meterList" method="post" id="meterList">
	     <input type="hidden" id="ssensor" name="ssensor" value="{$ListDailyRep.0.sensorCode}">
	<div class="row">
		<div class="col-12">
			<div class="card">
			{if $SuccessMessage neq "" || $ErrorMessage neq ""}
				<div class="card-body">
				{if $SuccessMessage neq ""}
					<div class="isa_success">
					<i class="fa fa-check"></i>
					{$SuccessMessage}		 
					</div>
				{/if}
				{if $ErrorMessage neq ""}
					<div class="isa_error">
					<i class="fa fa-check"></i>
					{$ErrorMessage}		 
					</div>
				{/if}
				</div>
			{/if}
             <input type="hidden" id="cname" name="cname" value="{$smarty.session.COMPANY_ID}" />
            <input type="hidden" id="gname" name="gname" value="{$smarty.post.gatewayName}" />
             <input type="hidden" id="sname" name="sname" value="{$smarty.post.shiftName}" />
              <input type="hidden" id="companyId" name="companyId" value="{$smarty.session.COMPANY_ID}" />
			  <input type="hidden" id="branchId" name="branchId" value="{$smarty.session.branch_id}" />
				<div class="card-body table-responsive">
				    <div class="col-sm-12">
                  <div class="col-sm-6"  style="float:left;margin-top:10PX;">
				 Month :
<input type="text" id="month" name="month" class="monthPicker" value="{if $smarty.post.month eq ''}{$smarty.now|date_format:'%B %Y'}{/if}"  readonly="true"/>	<p style="color:red"> * Click above to choose month to download Excell Report *</p>	
				  <!--Month : <input type="text" id="fromDate" name="fromDate" value="{if $smarty.post.shiftName neq '' && $smarty.post.fromDate eq ''}{$smarty.now|date_format:'%Y-%m'}{elseif $smarty.post.shiftName neq '' && $smarty.post.fromDate neq ''}{$smarty.post.fromDate}{else}{$smarty.now|date_format:'%Y-%m'}{/if}" class="form-control" autocomplete="off" readonly="true">--></div>&nbsp;&nbsp;
                </div>	
				<br/><br/><br/>
				<div class="col-sm-12">
				<div class="col-sm-2">
                   <center>  <input type="button" value="Excel" id="excelButton" name="excelButton" class="btn btn-create" style="" title="Xls" onClick="get_excel();"></center>
					</div>		
					</div>
				</div>
			</div>
		</div>
	</form>
</section>
</div>
</body>
{literal}
<link rel="stylesheet" href="/resources/demos/style.css">
<link rel="stylesheet" href="css/jquery-ui.css">
<script type="text/javascript">
$(document).ready(function()
{   
    $(".monthPicker").datepicker({
        dateFormat: 'MM yy',
        changeMonth: true,
        changeYear: true,
        showButtonPanel: true,

        onClose: function(dateText, inst) {
            var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
            var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
            $(this).val($.datepicker.formatDate('MM yy', new Date(year, month, 1)));
        }
    });

    $(".monthPicker").focus(function () {
        $(".ui-datepicker-calendar").hide();
        $("#ui-datepicker-div").position({
            my: "center top",
            at: "center bottom",
            of: $(this)
        });
    });
});
</script>
<script type="text/javascript">
	setTimeout(myURL, 5000);
	function myURL(){
	this.form.submit();
}
</script>
	<style>
	.slNo{
	width:5%;
	}
	.code{
	width:10%;
	}
	.apiKey{
	width:30%;
	}
	.name{
	width:40%;
	}
	.isactive{
	width:10%;
	text-align:center;
	}
	.action{
	text-align:right;
	}
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>
<script type="text/javascript">
$(document).ready(function (){

var table = $('#example').DataTable({
"ordering" : false,
"pageLength": 50,
"bPaginate": false,
language: {
"infoFiltered": ""/*,
search: "_INPUT_",
searchPlaceholder: "Search..."*/
},
dom: '<bottom>p',
tableTools: {
"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
},
//dom: '<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p',
//dom: '<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p',

initComplete: function(){
//$("div.toolbar").html('<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>');   
}       
}); 
}); 




</script>

<script type="text/javascript">
	function get_excel(){
	//alert("am working");
		var fromMonth = document.getElementById("month").value;
		var companyId = document.getElementById("companyId").value;
		var branchId = document.getElementById("branchId").value;
		//alert(fromMonth);
	
	if(fromMonth =='')
	{
		alert("Please Specify Month");
		document.getElementById("month").style.borderColor="red";
		return false;
	}
	
	alert("Are you sure want to download Excell Report")
	//window.location.href="monthReport_xl.php?fromMonth="+fromMonth+"&companyId="+companyId+"&branchId="+branchId;
	}
	</script>
{/literal}
{include file="footer.tpl"}