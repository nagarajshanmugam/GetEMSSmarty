	<body onload="GetSensor()">
	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>			
				<td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">List Incidents Log</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:10PX;color:#999999;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			</div>
		</div>
		<form name="meterList" method="post" id="meterList">
		     <input type="hidden" id="ssensor" name="ssensor" value="{$ListDailyRep.0.sensorCode}">
		<div class="row">
			<div class="col-12">
				<div class="card">
				{if $SuccessMessage neq "" || $ErrorMessage neq ""}
					<div class="card-body">
					{if $SuccessMessage neq ""}
						<div class="isa_success">
						<i class="fa fa-check"></i>
						{$SuccessMessage}		 
						</div>
					{/if}
					{if $ErrorMessage neq ""}
						<div class="isa_error">
						<i class="fa fa-check"></i>
						{$ErrorMessage}		 
						</div>
					{/if}
					</div>
				{/if}
				<input type="hidden" id="sname" name="sname" value="{$smarty.post.sensorName}" />
					<div class="card-body table-responsive">
                    <div class="col-sm-12">
                    	<div class="col-sm-2"  style="float:left;margin-top:10PX">From Date: <input type="text" id="fromDate" name="fromDate" value="{if $smarty.post.sensorName neq '' && $smarty.post.fromDate eq ''}{$smarty.now|date_format:'%Y-%m-01'}{elseif $smarty.post.sensorName neq '' && $smarty.post.fromDate neq ''}{$smarty.post.fromDate}{else}{$smarty.now|date_format:'%Y-%m-%d'}{/if}" class="form-control" autocomplete="off" readonly="true" ></div>
                        &nbsp;&nbsp;
                        
                    
					<div class="col-sm-3"  style="float:left;margin-top:30PX">
					<input type="hidden" name="branchName" id="branchName" value="{$smarty.get.branchId|base64_decode}">
						<select class="form-control" id="sensorName" name="sensorName"  tabindex="1"  >
						    <option value="">--  Select Sensor  --</option>
						</select>
					</div>&nbsp;&nbsp;
					 &nbsp;&nbsp;
					<div class="col-sm-2"  style="float:left;margin-top:30PX">
						<input type="button" value="Submit" id="submitButton" name="submitButton" class="btn btn-create">
					</div>&nbsp;&nbsp;
                    </div>
				
                    {if $ListPostData.0.recorded_date eq ''}<p><br/><br /></p>{/if}
						<table id="example" class="table table-bordered table-hover">
						<thead>
						<tr>
						<th class="slNo">#</th>
						<th class="">Date</th>
						<th class="">Sensor Code</th>
						<th class="">Incident Message</th>
						<th class="">Alert Status</th>
						</tr>
						</thead>
						<tbody>
						{foreach from=$ListIncidentLog item=List}
						{assign var="alertMsg0" value=$List.alert_message|replace:'Hi!':''}
						{assign var="alertMsg1" value=$alertMsg0|replace:'Best regards,':''}
						{assign var="alertMsg" value=$alertMsg1|replace:'Arka Automaations Limited.':''}
						{assign var="alertBreak" value=","|explode:$alertMsg}
						{assign var="l" value=0}
						<tr id="{$j++}">
						<td >{$j}</td>
						<td>{$List.recorded_date_time|date_format:"%e-%b-%Y %I:%M %p"}</td>
						<td>{$List.sensor_code}</td>
						<td> {section name=i loop=$alertBreak}
						{assign var="l" value=$l+1}
						{$alertBreak[i]|escape},{if $l eq '2'}<br />{/if}
						{/section}</td>
						<td align="center" >{if $ListIncidentLog.alert_status eq "Low"}<span class="text-warning">{elseif $ListIncidentLog.alert_status eq "Normal"}<span class="text-info">{elseif $ListIncidentLog.alert_status eq "Normal"}<span class="text-danger">{/if}{$List.alert_status}</span></td>
						</tr>
						{foreachelse}
						<tr><td colspan="8"><center>No Records Found</center></td></tr>
						{/foreach}
						</tbody>
						</table>
					</div>
				</div>
			</div>
		</form>
	</section>
	</div>
	</body>
	{literal}
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	<link rel="stylesheet" href="/resources/demos/style.css">
	 <script>
	$( function() {
		$( "#fromDate" ).datepicker({changeMonth: true,
		changeYear: true,maxDate: '0',dateFormat:'yy-mm-dd'});
		$( "#toDate" ).datepicker({changeMonth: true,
		changeYear: true,maxDate: '0',dateFormat:'yy-mm-dd'});
	} );
	</script>
	<script type="text/javascript">
	$(document).ready(function() {
	$('#sensorName').on('change', function() {
	this.form.submit();
	});
	$('#submitButton').on('click', function() {
	this.form.submit();
	});
	});
	
	</script>
	<script type="text/javascript">
function GetSensor()
{
    var val = document.getElementById('branchName').value;
var val1 = document.getElementById('sname').value;
$.ajax({
	type: "POST",
	url: "getSensorsDash.php",
	data: {branch:val},
	success: function(result){
	var res = JSON.parse(result);
	var nlen=Object.keys(res).length;
	$("#sensorName").empty();
		var sel = '--Select Sensor--';
	$("#sensorName").append("<option value='' selected>"+sel+"</option>");
for( var i = 0; i<nlen; i++){
var id = res[i]['id'];
var name = res[i]['name'];
if(val1 == id)
{
$("#sensorName").append("<option value='"+id+"' selected>"+name+"</option>");
}
else if(val == '' && val1 == '')
{
$("#sensorName").append("<option value='' selected>"+sel+"</option>");
}
else
{
$("#sensorName").append("<option value='"+id+"'>"+name+"</option>");
}
}
	},
	error: function(result) {
	alert('error');
	}
	});
}
</script>
	<style>
	.slNo{
	width:5%;
	}
	.code{
	width:10%;
	}
	.apiKey{
	width:30%;
	}
	.name{
	width:40%;
	}
	.isactive{
	width:10%;
	text-align:center;
	}
	.action{
	text-align:right;
	}
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>
	<script type="text/javascript">
	$(document).ready(function (){
	var table = $('#example').DataTable({
	"ordering" : false,
	"pageLength": 50,
	"bPaginate": false,
	"searching": false,
	language: {
	"infoFiltered": "",
	search: "_INPUT_",
	searchPlaceholder: "Search..."
	},
	dom: '<"pull-left" f><bottom>p',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: '<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p',
	//dom: '<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p',
	
	initComplete: function(){
	//$("div.toolbar").html('<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>');   	
	}       
	}); 
	}); 
	
	function unitPriceCats(slNoIdent,metIdIdent,compIdent,locIdIdent) {
		var sid = btoa(slNoIdent); var mid = btoa(metIdIdent); var comId = btoa(compIdent); var lId = btoa(locIdIdent);
		FormName		= document.meterList;
		FormName.action ='unitPriceList.php?sl_no='+sid+'&companyId='+comId+'&location_id='+lId+'&meter_id='+mid;
		FormName.submit();
	}
	
	function editCats(recordedDate,sensorCode,userName) {
		var sid = recordedDate;
		var mid = sensorCode;  
		var comId = userName; 
		$.ajax({
		type: "POST",
		url: "cronEnergyMeterData.php",
		data: {recorded_date:recordedDate,sensor_code:sensorCode,userName:userName},
		dataType: "text",
		cache: false,
		success: function(result){
		var len = result.length;
		//$("#testDate").val(result);
		//alert(result);
		location.reload(true);
		},
		error: function(result) {
		alert('error');
		}
		});
	}
	
	</script>
	<script type="text/javascript">
	function deleteCats(slNoIdent,serialIdIdent,compIdent,branIdent,gateIdent){
		var sid = btoa(slNoIdent); var scId = btoa(serialIdIdent);var comId = btoa(compIdent); var gId = btoa(gateIdent);var bId = btoa(branIdent);
		if(confirm("Are you sure to Delete this Content?")){
		FormName		= document.meterList;
		FormName.action= 'sensorList.php?gatewayId='+gId+'&companyId='+comId+'&branchId='+bId+'&sl_no='+sid+'&sen_code='+scId;
		FormName.submit();
		}
	}
	</script>
	{/literal}
	{include file="footer.tpl"}