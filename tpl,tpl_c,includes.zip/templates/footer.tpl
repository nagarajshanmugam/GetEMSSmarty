 <footer class="main-footer">

   <!--- <strong style="float:left"> <a href="https://www.innospace.co.in/">Innospace</a></strong> --->
    <strong > <a href="http://greatelephanttech.com" target="_blank">Great Elephant Technologies Pvt Ltd</a></strong>
 </footer>
		</div>
		{literal}

<style>
.main-footer{
text-align:right;
}
</style>
    
	{/literal}
    <!-- /Starrr -->
  </body>
</html>
