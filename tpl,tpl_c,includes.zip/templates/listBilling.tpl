<div class="content-wrapper">
<section class="content-header">
	<div class="card">
		<div class="card-header">
			<table style="margin-bottom:-10px;">
			<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
			<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
			{if $branchDetail.0.branch_name neq ""}
            <td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&nbsp;&nbsp;</font>&nbsp;</td>
			<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
            {/if}
			<td style="font-size:15PX;font-weight: bold;">List Billing</font>&nbsp;</td>
			</tr>
			
			<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
			<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
			{if $branchDetail.0.branch_name neq ""}
			<td style="color:#999999;font-size:10PX;">Branch Name</td>
            <td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
            {/if}
			<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
			</tr>
			</table>
		</div>
	</div>
	<form name="meterList" method="post" id="meterList">
	<div class="row">
		<div class="col-12">
			<div class="card">
			{if $SuccessMessage neq "" || $ErrorMessage neq ""}
				<div class="card-body">
				{if $SuccessMessage neq ""}
					<div class="isa_success">
					<i class="fa fa-check"></i>
					{$SuccessMessage}		 
					</div>
				{/if}
				{if $ErrorMessage neq ""}
					<div class="isa_error">
					<i class="fa fa-check"></i>
					{$ErrorMessage}		 
					</div>
				{/if}
				</div>
			{/if}
			<div class="card-body table-responsive">
			   {if $smarty.session.branch_id eq "0"}
            <div class="col-sm-3"  style="float:right;">
						<select class="form-control form-control-sm" id="branchName" name="branchName"  tabindex="1" onChange="GetSensor();" >
						<option value="">---Select Branch---</option>
                        {foreach from=$ListView item=ListBnh}
						{if $smarty.post.branchName eq $ListBnh.sl_no}<option value="{$ListBnh.sl_no}" selected="selected">{$ListBnh.branch_name}</option>{/if}
						{if $smarty.post.branchName neq $ListBnh.sl_no}<option value="{$ListBnh.sl_no}">{$ListBnh.branch_name}</option>{/if}
						{/foreach}
						</select>
						</div>
                        
                        {/if}
            {if $ListPostData.0.recorded_date eq ''}<p>&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;<br /></p>{/if}
             {if $ListMonthName.0.month_data neq ''}<p>&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;<br /></p>{/if}
            
				<table id="example" class="table table-bordered table-hover">
				<thead>
				<tr>
				<th class="slNo">#</th>
				<th class="">Month</th>
				<th class="" align="right">Unit Rate Set</th>
				<th>Action</th>
				</tr>
				</thead>
				<tbody>
				{foreach from=$ListMonthName item=List}
				<tr id="{$j++}">
				<td >{$j}</td>
				<td>{$List.month_data}</td>
				<td>{if $List.unitpriceset eq ""}No{else}{$List.unitpriceset}{/if}</td>
				<td align="right">
				{if $List.unitpriceset eq "No" || $List.unitpriceset eq ""}
				<a href="#"  onClick="Javascript:setCats('{$List.month_data}','{$List.company_id}','{$List.branch_id}')" title="Set Unit Rate"><i class="fa fa-check-circle" aria-hidden="true"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				{/if}
				{if $List.unitpriceset eq "Yes" && $List.invoice_status eq "0"}
				<a href="#"  onClick="Javascript:setCats('{$List.month_data}','{$List.company_id}','{$List.branch_id}')" title="Set Unit Rate"><i class="fa fa-check-circle" aria-hidden="true"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<a href="#"  onClick="Javascript:createCats('{$List.month_data}','{$List.company_id}','{$List.branch_id}')" title="Create Invoice"><i class="fa fa-file"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				{/if}
				{if $List.unitpriceset eq "Yes" && $List.invoice_status eq "1"}
				<a href="#"  onClick="Javascript:listCats('{$List.month_data}','{$List.company_id}','{$List.branch_id}')" title="List Invoice"><i class="fa fa-list"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<a href="#"  onClick="Javascript:viewCats('{$List.month_data}','{$List.company_id}','{$List.branch_id}')" title="View Unit Rate"><i class="fa fa-search-plus"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				{/if}
				</td>
				</tr>
				{foreachelse}
				<tr><td colspan="8"><center>No Records Found</center></td></tr>
				{/foreach}
				</tbody>
				</table>
			</div>
			</div>
		</div>
	</form>
</section>
</div>
{literal}
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
	<script>
	$( function() {
		$( "#fromDate" ).datepicker({changeMonth: true,
		changeYear: true,maxDate: '0',dateFormat:'yy-mm-dd'});
		$( "#toDate" ).datepicker({changeMonth: true,
		changeYear: true,maxDate: '0',dateFormat:'yy-mm-dd'});
	} );
	</script>
	<script type="text/javascript">
	$(document).ready(function() {
	$('#monthName').on('change', function() {
		this.form.submit();
	});
	$('#branchName').on('change', function() {
		this.form.submit();
	});
	});
	</script>
	<style>
	.slNo{
	width:5%;
	}
	.code{
	width:10%;
	}
	.apiKey{
	width:30%;
	}
	.name{
	width:40%;
	}
	.isactive{
	width:10%;
	text-align:center;
	}
	.action{
	text-align:right;
	}
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>

	<script type="text/javascript">
	$(document).ready(function (){
	var table = $('#example').DataTable({
	"ordering" : false,
	"pageLength": 50,
	"searching": false,
	language: {
	"infoFiltered": "",
	search: "_INPUT_",
	searchPlaceholder: "Search..."
	},
	dom: '<"pull-left" f><bottom>p',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: '<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p',
	//dom: '<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p',
	
	initComplete: function(){
	//  $("div.toolbar").html('<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>');	
	}       
	}); 
	});
	
	function unitPriceCats(slNoIdent,metIdIdent,compIdent,locIdIdent) {
		var sid = btoa(slNoIdent); var mid = btoa(metIdIdent); var comId = btoa(compIdent); var lId = btoa(locIdIdent);
		FormName		= document.meterList;
		FormName.action ='unitPriceList.php?sl_no='+sid+'&companyId='+comId+'&location_id='+lId+'&meter_id='+mid;
		FormName.submit();
	}
	function setCats(recordedDate,comId,bId) {
		var recordedDate = btoa(recordedDate);
		var comId = btoa(comId);
		var bId = btoa(bId);
		window.location.href='setUnitRate.php?monthData='+recordedDate+'&companyId='+comId+'&branchId='+bId;
		target = "_blank";
		done=1;
	}
	function createCats(MonId,ComId,BchId){
		if(confirm("Are you sure to Create Invoice?")){
		FormName		= document.meterList;
		FormName.action= "listBilling.php?MId="+MonId+"&CId="+ComId+"&BId="+BchId;
		FormName.submit();
		}
	}
	function listCats(MonId,ComId,BchId){
		var MonId = btoa(MonId);
		var ComId = btoa(ComId);
		var BchId = btoa(BchId);
		FormName		= document.meterList;
		FormName.action= "listInvoice.php?gId="+MonId+"&companyId="+ComId+"&branchId="+BchId;
		FormName.submit();
	}
	function viewCats(MonId,ComId,BchId){
		var MonId = btoa(MonId);
		var comId = btoa(ComId);
		var BchId = btoa(BchId);
		FormName		= document.meterList;
		FormName.action= "viewRate.php?monthData="+MonId+"&companyId="+comId+"&branchId="+BchId;
		FormName.submit();
	}
	</script>
	<script type="text/javascript">
	function deleteCats(slNoIdent,serialIdIdent,compIdent,branIdent,gateIdent){
		var sid = btoa(slNoIdent); var scId = btoa(serialIdIdent);var comId = btoa(compIdent); var gId = btoa(gateIdent);var bId = btoa(branIdent);
		if(confirm("Are you sure to Delete this Content?")){
		FormName		= document.meterList;
		FormName.action= 'sensorList.php?gatewayId='+gId+'&companyId='+comId+'&branchId='+bId+'&sl_no='+sid+'&sen_code='+scId;
		FormName.submit();
		}
	}
	</script>
{/literal}
{include file="footer.tpl"}