		<div class="content-wrapper">
			<section class="content-header">
			<div class="card">
				<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{if $smarty.get.sl_no neq ""}<td style="font-size:15PX;font-weight: bold;">{$ListEditView.0.branch_name}</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{/if}
				<td style="font-size:15PX;font-weight: bold;">{if $smarty.get.sl_no eq ""}Create Branch{else}Edit Branch{/if}&nbsp;</td>
				</tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{if $smarty.get.sl_no neq ""}
				<td style="font-size:10PX;color:#999999;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{/if}
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
				<a href="branchList.php?companyId={$smarty.get.companyId}"><button type="button" style="float:right; margin-top:-40PX;" class="btn btn-primary">List Branch</button></a>
				</div>
			</div>
			</section>
			<section class="content">
				<div class="card">
			
					<div class="card-body">
						<form role="form" name="locationRegForm" id="locationRegForm" method="post" onsubmit="return createValidation();" >
							<input type="hidden" name="hdAction" />
							<input type="hidden" id="check_id" name="check_id" value="{$smarty.post.check_id}">
							<input type="hidden" id="item_id" name="item_id" value="{$smarty.post.item_id}" />
							<input type="hidden" id="checkVal" name="checkVal" value="{$smarty.post.checkVal}" />
							<input type="hidden" id="checkValEbMeter" name="checkValEbMeter" value="{$smarty.post.checkValEbMeter}" />
							<input type="hidden" id="checkValDgMeter" name="checkValDgMeter" value="{$smarty.post.checkValDgMeter}" />
							<input type="hidden" id="checkValSolarMeter" name="checkValSolarMeter" value="{$smarty.post.checkValSolarMeter}" />
							<div class="row">
							<div class="form-group col-md-6">
								<label for="exampleInputlocationId">Branch Code <span style="color:red;">*</span></label>
								<input type="text" class="form-control form-control-sm" id="branchId" name="branchId"   maxlength="10" placeholder="Enter Branch Code" value="{if $ListEditView.0.branch_id neq ""} {$ListEditView.0.branch_id}{/if}">
							</div>
							<div class="form-group col-md-6">
								<label for="exampleInputlocationName">Branch Name <span style="color:red;">*</span></label>
								<input type="text" class="form-control form-control-sm" id="branchName" name="branchName" placeholder="Enter Branch name" value="{if $ListEditView.0.branch_name neq ""}{$ListEditView.0.branch_name}{/if}">
							</div>
					<div class="form-group col-md-4">
						<div class="custom-control custom-checkbox">
						{if $ListEditView.0.EB eq '1'}
						<input class="" type="checkbox" id="customCheckbox2" name="customCheckbox2" value="" checked="checked" tabindex="7">&nbsp;&nbsp;
						<label for="" class="">EB</label>
						{elseif $ListEditView.0.EB eq '0'}
						<input class="" type="checkbox" id="customCheckbox2" name="customCheckbox2" value="" tabindex="7">&nbsp;&nbsp;
						<label for="" class="">EB</label>
						{else}
						<input class="" type="checkbox" id="customCheckbox2" name="customCheckbox2" value="" tabindex="7">&nbsp;&nbsp;
						<label for="" class="">EB</label>
						{/if}
						</div>
					</div>
					<div class="form-group col-md-4">
						<div class="custom-control custom-checkbox">
						{if $ListEditView.0.DG eq '1'}
						<input class="" type="checkbox" id="customCheckbox3" name="customCheckbox3" value="" checked="checked" tabindex="7">&nbsp;&nbsp;
						<label for="" class="">DG</label>
						{elseif $ListEditView.0.DG eq '0'}
						<input class="" type="checkbox" id="customCheckbox3" name="customCheckbox3" value="" tabindex="7">&nbsp;&nbsp;
						<label for="" class="">DG</label>
						{else}
						<input class="" type="checkbox" id="customCheckbox3" name="customCheckbox3" value="" tabindex="7">&nbsp;&nbsp;
						<label for="" class="">DG</label>
						{/if}
						</div>
					</div>
					<div class="form-group col-md-4">
						<div class="custom-control custom-checkbox">
						{if $ListEditView.0.Solar eq '1'}
						<input class="" type="checkbox" id="customCheckbox4" name="customCheckbox4" value="" checked="checked" tabindex="7">&nbsp;&nbsp;
						<label for="" class="">Solar</label>
						{elseif $ListEditView.0.Solar eq '0'}
						<input class="" type="checkbox" id="customCheckbox4" name="customCheckbox4" value="" tabindex="7">&nbsp;&nbsp;
						<label for="" class="">Solar</label>
						{else}
						<input class="" type="checkbox" id="customCheckbox4" name="customCheckbox4" value="" tabindex="7">&nbsp;&nbsp;
						<label for="" class="">Solar</label>
						{/if}
						</div>
					</div>
							<div class="form-group col-md-6">
								<div class="custom-control custom-checkbox">
								{if $ListEditView.0.is_active eq '1'}
									<input class="custom-control-input" type="checkbox" id="customCheckbox"  name="customCheckbox" tabindex="4" checked="checked">
									<label for="customCheckbox" class="custom-control-label">Is Active</label>
								{elseif $ListEditView.0.is_active eq '0'}
									<input class="custom-control-input" type="checkbox" id="customCheckbox" name="customCheckbox" tabindex="4">
									<label for="customCheckbox" class="custom-control-label">Is Active</label>
								{else}
									<input class="custom-control-input" type="checkbox" id="customCheckbox" name="customCheckbox" tabindex="4" checked="checked">
									<label for="customCheckbox" class="custom-control-label">Is Active</label>
								{/if}
								</div>
								<input id="created_by" name="created_by" class="date-picker form-control" type="hidden" value="{$smarty.session.UserName}" readonly="true">
							
							</div>
							</div>
							<div  align="center">
							<input type="submit" value="Submit" class="btn btn-create" />
							</div>
						</form>
					</div>
				
				</div>
			</div>		
		</section>
	</div>
	{literal}
	<script type="text/javascript">
	function createValidation(){
	var branchId = $('#branchId').val();
	var branchName = $('#branchName').val();
	var isActive = document.getElementById("customCheckbox").checked;
	
	if (isActive == false) 
	{
	document.getElementById('checkVal').value='0';
	}
	else
	{
	document.getElementById('checkVal').value='1';
	}
	
	var eb = document.getElementById("customCheckbox2").checked;
	var dg = document.getElementById("customCheckbox3").checked;
	var solar = document.getElementById("customCheckbox4").checked;
		/*var bar_code = [];
	$.each($("input[name='customCheckbox2']:checked"), function()
	{ 
		bar_code.push($(this).val());  
	});
		id=bar_code.join("','");
		document.getElementById("item_id").value = id;*/
	if (eb == false) 
	{
		document.getElementById('checkValEbMeter').value='0';
	}
	else
	{
		document.getElementById('checkValEbMeter').value='1';
	}
	if (dg == false) 
	{
		document.getElementById('checkValDgMeter').value='0';
	}
	else
	{
		document.getElementById('checkValDgMeter').value='1';
	}
	if (solar == false) 
	{
		document.getElementById('checkValSolarMeter').value='0';
	}
	else
	{
		document.getElementById('checkValSolarMeter').value='1';
	}
	$(".error").remove();
	if(branchId.length < 1) {
	$('#branchId').after('<span class="error">This field is required</span>');
	$('#branchId').focus();
	return false;					
	}
	else if(branchName.length < 1 && branchId.length > 1) {
	
	$('#branchName').after('<span class="error">This field is required</span>');
	$('#branchName').focus();
	return false;
	
	}	
	FormName		= document.locationRegForm;
	FormName.method	= "POST";
	FormName.submit();
	}
	function GoBack()
	{
	window.history.back();
	}
	</script>
<!--	<script>
	function CheckDuplicateLocName()
	{
	var locationId = $("#locationId").val();
	$.ajax({
	type: "POST",
	url: "AjaxLocationCode.php",
	data: {locationId:locationId},
	dataType:"TEXT",
	cache: false,
	
	success: function(result){
	var obj = JSON.parse(result);
	var feild= $("#locationId").val();
	if(obj[0].location_id = feild ){
	document.getElementById("locationId").value ='';
	alert('Your enter data already exist ...');
	createValidation();
	return false;	
	}
	},
	error: function(result) {
	alert('error');
	}
	});
	} 
	</script>-->
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	{/literal}
	{include file="footer.tpl"}