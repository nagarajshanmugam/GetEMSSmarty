
<body >
	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{if $smarty.session.USER_GROUP eq 'Branch Admin' || $smarty.session.USER_GROUP eq 'Branch User'}
				<td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{/if}
				<td style="font-size:15PX;font-weight: bold;">Log Reports</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{if $smarty.session.USER_GROUP eq 'Branch Admin' || $smarty.session.USER_GROUP eq 'Branch User'}
				<td style="font-size:10PX;color:#999999;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{/if}
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			</div>
		</div>
		<form name="meterList" method="post" id="meterList">
		    <input type="hidden" id="ssensor" name="ssensor" value="{$ListDailyRep.0.sensorCode}">
		<div class="row">
			<div class="col-12">
				<div class="card">
				{if $SuccessMessage neq "" || $ErrorMessage neq ""}
					<div class="card-body">
					{if $SuccessMessage neq ""}
						<div class="isa_success">
						<i class="fa fa-check"></i>
						{$SuccessMessage}		 
						</div>
					{/if}
					{if $ErrorMessage neq ""}
						<div class="isa_error">
						<i class="fa fa-check"></i>
						{$ErrorMessage}		 
						</div>
					{/if}
					</div>
				{/if}
					<input type="hidden" id="sname" name="sname" value="{$smarty.post.sensorName}" />
					<div class="card-body table-responsive"><div class="col-sm-1"  style="float:right;margin-top:30PX">
					<a href="heinn_dashboard.php"><input type="button" value="Back" id="submitButton" name="submitButton" class="btn btn-danger"></a>
					</div>&nbsp;&nbsp;
					<div class="col-sm-1"  style="float:right;margin-top:30PX">
					<input type="button" value="Submit" id="submitButton" name="submitButton" class="btn btn-create">
					</div>&nbsp;&nbsp;
					
					<div class="col-sm-2"  style="float:right;margin-top:10PX" > To Date: <input type="text" id="toDate" name="toDate" value="{if $smarty.post.sensorName neq '' && $smarty.post.toDate eq ''}{$smarty.now|date_format:'%Y-%m-%d'}{elseif $smarty.post.sensorName neq '' && $smarty.post.toDate neq ''}{$smarty.post.toDate}{else}{$smarty.now|date_format:'%Y-%m-%d'}{/if}" class="form-control" autocomplete="off" readonly="true"></div>&nbsp;&nbsp;<div class="col-sm-2"  style="float:right;margin-top:10PX">From Date: <input type="text" id="fromDate" name="fromDate" value="{if $smarty.post.sensorName neq '' && $smarty.post.fromDate eq ''}{$smarty.now|date_format:'%Y-%m-01'}{elseif $smarty.post.sensorName neq '' && $smarty.post.fromDate neq ''}{$smarty.post.fromDate}{else}{$smarty.now|date_format:'%Y-%m-%d'}{/if}" class="form-control" autocomplete="off" readonly="true" ></div>
					<P><br><br></P>
						<table id="example" class="table table-bordered table-hover">
						<thead>
						<tr>
						<th class="">Date Time</th>
						<th class="">Machine Status</th>
						<th class="">Bearing 1 Temperature &#176;C</th>
						
						</tr>
						</thead>
						<tbody>
						{foreach from=$ListLogRep item=List}
						<tr id="{$j++}">
						<td>{$List.TM|date_format:"%e-%b-%Y %I:%M %p"}</td>
						<td align="center">{if $List.machine_status eq "ON"}<b style="color:green">{else}<b style="color:red">{/if}{$List.machine_status}</b></td>
						<td align="right">{$List.bearing_1_temperature}</td>
						
						</tr>
						{foreachelse}
						<tr><td colspan="15"><center>No Records Found</center></td></tr>
						{/foreach}
						</tbody>
						</table>
					</div>
				</div>
			</div>
		</form>
	</section>
	</div>
	{literal}
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	<link rel="stylesheet" href="/resources/demos/style.css">
    <script>
	$( function() {
		$( "#fromDate" ).datepicker({changeMonth: true,
		changeYear: true,maxDate: '0',dateFormat:'yy-mm-dd'});
		$( "#toDate" ).datepicker({changeMonth: true,
		changeYear: true,maxDate: '0',dateFormat:'yy-mm-dd'});
	} );
	</script>
	<script type="text/javascript">
/*		setTimeout(myURL, 5000);
		function myURL(){
		this.form.submit();
	}
	*/
	</script>
	<script type="text/javascript">
	$('#submitButton').on('click', function() {
	    alert('hai');
		this.form.submit();
	});
	});
	</script>
		
	<style>
	.slNo{
	width:5%;
	}
	.code{
	width:10%;
	}
	.apiKey{
	width:30%;
	}
	.name{
	width:40%;
	}
	.isactive{
	width:10%;
	text-align:center;
	}
	.action{
	text-align:right;
	}
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>
	<script type="text/javascript">
	$(document).ready(function (){
	var table = $('#example').DataTable({
	"ordering" : false,
	"pageLength": 100,
	"bPaginate": false,
	language: {
	"infoFiltered": ""/*,
	search: "_INPUT_",
	searchPlaceholder: "Search..."*/
	},
	dom: '<bottom>p',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: '<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p',
	//dom: '<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p',
	
	initComplete: function(){
	//$("div.toolbar").html('<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>');   	
	}       
	}); 
	}); 
	

	</script>

	{/literal}
	{include file="footer.tpl"}