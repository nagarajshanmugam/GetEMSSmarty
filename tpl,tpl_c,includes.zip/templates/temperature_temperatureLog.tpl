	<div class="content-wrapper">
	<div class="content-header">
	<div class="container-fluid">
		<div class="row"> 
			<div class="col-md-12">
				<div class="card">
					<div class="card-body">
						<table style="margin-bottom:-10px;">
						<tr><td style="font-size:15PX;font-weight: bold;">{$companyDetail.0.companyName}&nbsp;&nbsp;</td>
						<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
						<td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>
						<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
						<td style="font-size:15PX;font-weight: bold;">Temperature Log Reports   <!---({$LoctList.0.gateway_id} / {$LoctList.0.sensorCode})--></font>&nbsp;</td></tr>		
						<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
						<td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
						<td style="font-size:10PX;color:#999999;">Branch Name</td>
						<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
						<!--<td style="color:#999999;font-size:10PX;">Dashboard</td><td>&nbsp;</td>-->
						</tr>
						</table>
						<input type="hidden" id="gatewayCode" value="{$smarty.get.gatewayCode}" />
						<input type="hidden" id="sensorCode" value="{$smarty.get.sensorCode}" />	
					</div>
				</div>
			</div>
		</div>
	{foreach from=$TempList item=List}
	{if $List.sensor_code eq $smarty.get.sensorCode}
		<div class="row">
			<div class="col-12 col-sm-6 col-md-4">
				<div class="info-box">
				<span class="info-box-icon bg-danger elevation-1"><!--&ordm; C--><img src="images/73025-200.png" style="padding:3px;color:#fff;"></span>
					<div class="info-box-content">
					<span class="info-box-text">Celsius&ensp;&ensp;&ensp;&ensp;</span>
						<span class="info-box-number">
						{$List.temperature_c} &ordm; C 
						<small></small>
						</span>
					</div>
				</div>
			</div>
			<div class="col-12 col-sm-6 col-md-4">
				<div class="info-box mb-2">
				<span class="info-box-icon bg-warning"><img src="images/Fahrenheit-icon.png" style="padding:3px;color:#fff;"></span>
				
					<div class="info-box-content">
					<span class="info-box-text">Fahrenheit&ensp;&ensp;&ensp;&ensp;</span>
					<span class="info-box-number">{$List.temperature_f} &ordm; F </span>
					</div>
				</div>
			</div>		
		<!-- fix for small devices only -->
		<div class="clearfix hidden-md-up"></div>
		
			<div class="col-12 col-sm-6 col-md-4">
				<div class="info-box mb-4">
				<span class="info-box-icon bg-info elevation-1"><img src="images/humidity.png" style="padding:3px; color:#fff;"></span>
				
					<div class="info-box-content">
					<span class="info-box-text"><!--{$smarty.now|date_format:"%B"}--> Humidity</span>
					<span class="info-box-number"> {$List.humidity} RH %</span>
					</div>
				</div>
			</div>
		</div>
	{/if}
	{/foreach}
		<div class="row">
			<div class="col-md-12">
				<div class="card card-primary card-tabs">
					<div class="card-header p-0 pt-1 border-bottom-0">
						<ul class="nav nav-tabs" id="custom-content-below-tab" role="tablist">
							<li class="nav-item">
							<a class="nav-link active" id="custom-content-below-home-tab" data-toggle="pill" href="#tab-1" role="tab" aria-controls="custom-content-below-home" aria-selected="true">Trend Graph</a>
							</li>
							<li class="nav-item">
							<a class="nav-link " id="custom-content-below-home-tab" data-toggle="pill" href="#tab-2" role="tab" aria-controls="custom-content-below-home" aria-selected="true">Log</a>
							</li>
						</ul>
					</div>
					<div class="tab-content">
						<div id="tab-1" class="tab-pane active">
								<div class="card-body">
							<iframe height="620px" width="100%" id="tab-1"  src="./temperature_temperatureTrendGraph.php?gatewayCode={$smarty.get.gatewayCode}&sensorCode={$smarty.get.sensorCode}" style="border:1px;"></iframe>
								</div>
						</div>
						<div id="tab-2" class="tab-pane ">
								<div class="card-body">
							<iframe height="500px" width="100%" id="tab-2"  src="./temperature_tempMeterLog.php?gatewayCode={$smarty.get.gatewayCode}&sensorCode={$smarty.get.sensorCode}" style="border:1px;"></iframe>
								</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	</div>
	</div>
	{include file="footer.tpl"}