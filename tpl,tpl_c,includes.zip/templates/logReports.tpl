{literal}
<script type="text/javascript">
    function includecomma1old(c,v)
{
var x=Math.round(c);
x=x.toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != '')
lastThree = ',' + lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
//var res = res.toFixed(4);
//var res =number_format(res, 2);
var res = res+'.00';
document.getElementById(v).innerHTML=res;
}
</script>
<script type="text/javascript">
	function includecomma1(c,v)
{
//var x=Math.round(c);
//var x=c.toFixed(2);

var x=c.split(".");
var ld=x[1];
x=x[0].toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != '')
{
lastThree = ',' + lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
}
else
{
lastThree =  lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
}
//var res = res+'.00';
var res = res+'.'+ld;
document.getElementById(v).innerHTML=res;
}
</script>
{/literal}
<body onLoad="GetSensor();">
	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{if $smarty.session.USER_GROUP eq 'Branch Admin' || $smarty.session.USER_GROUP eq 'Branch User'}
				<td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{/if}
				<td style="font-size:15PX;font-weight: bold;">Log Reports</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{if $smarty.session.USER_GROUP eq 'Branch Admin' || $smarty.session.USER_GROUP eq 'Branch User'}
				<td style="font-size:10PX;color:#999999;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{/if}
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			</div>
		</div>
		<form name="meterList" method="post" id="meterList">
		    <input type="hidden" id="ssensor" name="ssensor" value="{$ListDailyRep.0.sensorCode}">
		<div class="row">
			<div class="col-12">
				<div class="card">
				{if $SuccessMessage neq "" || $ErrorMessage neq ""}
					<div class="card-body">
					{if $SuccessMessage neq ""}
						<div class="isa_success">
						<i class="fa fa-check"></i>
						{$SuccessMessage}		 
						</div>
					{/if}
					{if $ErrorMessage neq ""}
						<div class="isa_error">
						<i class="fa fa-check"></i>
						{$ErrorMessage}		 
						</div>
					{/if}
					</div>
				{/if}
					<input type="hidden" id="sname" name="sname" value="{$smarty.post.sensorName}" />
					<div class="card-body table-responsive">
					    <div class="col-sm-12">
                    
                    <div class=""  style="float:left;margin-top:10PX;margin-right:5px;">Date: <input type="text" id="fromDate" name="fromDate" value="{if $smarty.post.sensorName neq '' && $smarty.post.fromDate eq ''}{$smarty.now|date_format:'%Y-%m-01'}{elseif $smarty.post.sensorName neq '' && $smarty.post.fromDate neq ''}{$smarty.post.fromDate}{else}{$smarty.now|date_format:'%Y-%m-%d'}{/if}"  class="form-control" autocomplete="off" readonly="true" >
					<input type="hidden" id="toDate" name="toDate" value="{if $smarty.post.sensorName neq '' && $smarty.post.toDate eq ''}{$smarty.now|date_format:'%Y-%m-%d'}{elseif $smarty.post.sensorName neq '' && $smarty.post.toDate neq ''}{$smarty.post.toDate}{else}{$smarty.now|date_format:'%Y-%m-%d'}{/if}"></div>&nbsp;&nbsp;
                    
                    <!--<div class=""  style="float:left;margin-top:10PX;margin-right:5px;" > To Date: <input type="text" id="toDate" name="toDate" value="{if $smarty.post.sensorName neq '' && $smarty.post.toDate eq ''}{$smarty.now|date_format:'%Y-%m-%d'}{elseif $smarty.post.sensorName neq '' && $smarty.post.toDate neq ''}{$smarty.post.toDate}{else}{$smarty.now|date_format:'%Y-%m-%d'}{/if}" class="form-control" autocomplete="off" readonly="true"></div>&nbsp;&nbsp;-->
                    
                    <div class="col-sm-3"  style="float:left;margin-top:30PX;margin-right:px;">
				    {if $smarty.session.USER_GROUP eq 'Branch Admin' || $smarty.session.USER_GROUP eq 'Branch User'}
						<select class="form-control" id="branchName" name="branchName"  tabindex="1" onChange="GetSensor();" disabled   >
						    {else}
						<select class="form-control" id="branchName" name="branchName"  tabindex="1" onchange="GetSensor();" >
						    {/if}
						      <option value="">--Select Branch--</option>
						       {if $smarty.session.USER_GROUP eq 'Branch Admin' || $smarty.session.USER_GROUP eq 'Branch User'}
						    <option value="{$branchDetail.0.sl_no}" selected="selected">{$branchDetail.0.branch_name}</option>
						    {else}
						{foreach from=$ListBranch item=ListBnh}
						{if $smarty.post.branchName eq $ListBnh.sl_no}<option value="{$ListBnh.sl_no}" selected="selected">{$ListBnh.branch_name}</option>{/if}
						{if $smarty.post.branchName neq $ListBnh.sl_no}<option value="{$ListBnh.sl_no}">{$ListBnh.branch_name}</option>{/if}
						{/foreach}
						{/if}
						</select>
						</div>&nbsp;
                        
                        <div class="col-sm-3"  style="float:left;margin-top:30PX;margin-right:5px;">
						<select class="form-control" id="sensorName" name="sensorName"  tabindex="1"  >
					<option value="">--Select Sensor--</option>
						</select>
					</div>&nbsp;&nbsp;
                    
					<div class=""  style="float:left;margin-top:30PX; margin-right:5px;">
					<input type="button" value="Submit" id="submitButton" name="submitButton" class="btn btn-create">
					</div>
                    </div>
					<P><br><br></P>
						<table id="example" class="table table-bordered table-hover">
						<thead>
						<tr>
						<th class="">Date Time</th>
						<th class="">VR</th>
						<th class="">VY</th>
						<th class="">VB</th>
						<th class="">VRY</th>
						<th class="">VYB</th>
						<th class="">VBR</th>
						<th class="">IR</th>
						<th class="">IY</th>
						<th class="">IB</th>
						<th class="">KVA</th>
						<th class="">KW</th>
						<th class="">KVAR</th>
						<th class="">PF</th>
						<th class="">KWH</th>
						</tr>
						</thead>
						<tbody>
						{foreach from=$ListLogRep item=List}
						<tr id="{$j++}">
						<td>{$List.TM|date_format:"%e-%b-%Y %I:%M %p"}</td>
						<td align="right">{$List.R_VOLTAGE}</td>
						<td align="right">{$List.Y_VOLTAGE}</td>
						<td align="right">{$List.B_VOLTAGE}</td>
						<td align="right"> {$List.RY_VOLTAGE}</td>
						<td align="right">{$List.YB_VOLTAGE}</td>
						<td align="right">{$List.BR_VOLTAGE}</td>
						<td align="right">{$List.R_CURRENT}</td>
						<td align="right">{$List.Y_CURRENT}</td>
						<td align="right">{$List.B_CURRENT}</td>
						<td align="right">{$List.SUM_KVA}</td>
						<td align="right">{$List.SUM_KW}</td>
						<td align="right">{$List.SUM_KVAR}</td>
						<td align="right">{$List.PF}</td>
						<td align="right" id="kw{$j}"><script type="text/javascript">includecomma1('{$List.KWH}','kw{$j}');</script></td>
						</tr>
						{foreachelse}
						<tr><td colspan="15"><center>No Records Found</center></td></tr>
						{/foreach}
						</tbody>
						</table>
					</div>
				</div>
			</div>
		</form>
	</section>
	</div>
	{literal}
	<link rel="stylesheet" href="/resources/demos/style.css">
	<link rel="stylesheet" href="css/jquery-ui.css">
    <script>
	$( function() {
		$( "#fromDate" ).datepicker({changeMonth: true,
		changeYear: true,maxDate: '0',dateFormat:'yy-mm-dd'});
		$( "#toDate" ).datepicker({changeMonth: true,
		changeYear: true,maxDate: '0',dateFormat:'yy-mm-dd'});
	} );
	</script>
	<script type="text/javascript">
		setTimeout(myURL, 5000);
		function myURL(){
		this.form.submit();
	}
	$(document).ready(function() {
	$('#toDate').val($('#fromDate').val());
	$('#sensorName').on('change', function() {
		this.form.submit();
	});
	$('#submitButton').on('click', function() {
		$('#toDate').val($('#fromDate').val());
		this.form.submit();
	});
	});
	</script>
		<script type="text/javascript">
function GetSensor()
{
var val = document.getElementById('branchName').value;
var val1 = document.getElementById('sname').value;
$.ajax({
	type: "POST",
	url: "getSensors.php",
	data: {branch:val},
	success: function(result){
	//alert(result);
	var res = JSON.parse(result);
	
	var nlen=Object.keys(res).length;
		$("#sensorName").empty();
	var sel = '--Select Sensor--';
	$("#sensorName").append("<option value='' selected>"+sel+"</option>");
for( var i = 0; i<nlen; i++){
var id = res[i]['id'];
var name = res[i]['name'];
if(val1 == id)
{
$("#sensorName").append("<option value='"+id+"' selected>"+name+"</option>");
}
else if(val == '' && val1 == '')
{
$("#sensorName").append("<option value='' selected>"+sel+"</option>");
}
else
{
$("#sensorName").append("<option value='"+id+"'>"+name+"</option>");
}
}
	},
	error: function(result) {
	alert('error');
	}
	});
}
</script>
	<style>
	.slNo{
	width:5%;
	}
	.code{
	width:10%;
	}
	.apiKey{
	width:30%;
	}
	.name{
	width:40%;
	}
	.isactive{
	width:10%;
	text-align:center;
	}
	.action{
	text-align:right;
	}
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>
	<script type="text/javascript">
	$(document).ready(function (){
	var table = $('#example').DataTable({
	"ordering" : false,
	"pageLength": 100,
	"bPaginate": false,
	language: {
	"infoFiltered": ""/*,
	search: "_INPUT_",
	searchPlaceholder: "Search..."*/
	},
	dom: '<bottom>p',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: '<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p',
	//dom: '<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p',
	
	initComplete: function(){
	//$("div.toolbar").html('<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>');   	
	}       
	}); 
	}); 
	
	function unitPriceCats(slNoIdent,metIdIdent,compIdent,locIdIdent) {
		var sid = btoa(slNoIdent); var mid = btoa(metIdIdent); var comId = btoa(compIdent); var lId = btoa(locIdIdent);
		FormName		= document.meterList;
		FormName.action ='unitPriceList.php?sl_no='+sid+'&companyId='+comId+'&location_id='+lId+'&meter_id='+mid;
		FormName.submit();
	}
	function editCats(recordedDate,sensorCode,userName) {
	var sid = recordedDate;
	var mid = sensorCode;  
	var comId = userName; 
	$.ajax({
	type: "POST",
	url: "cronEnergyMeterData.php",
	data: {recorded_date:recordedDate,sensor_code:sensorCode,userName:userName},
	dataType: "text",
	cache: false,
	success: function(result){
	var len = result.length;
	//$("#testDate").val(result);
	//alert(result);
	location.reload(true);
	},
	error: function(result) {
	alert('error');
	}
	});
	}
	
	</script>
	<script type="text/javascript">
	function deleteCats(slNoIdent,serialIdIdent,compIdent,branIdent,gateIdent){
		var sid = btoa(slNoIdent); var scId = btoa(serialIdIdent);var comId = btoa(compIdent); var gId = btoa(gateIdent);var bId = btoa(branIdent);
		if(confirm("Are you sure to Delete this Content?")){
		FormName		= document.meterList;
		FormName.action= 'sensorList.php?gatewayId='+gId+'&companyId='+comId+'&branchId='+bId+'&sl_no='+sid+'&sen_code='+scId;
		FormName.submit();
		}
	}
	</script>
	{/literal}
	{include file="footer.tpl"}