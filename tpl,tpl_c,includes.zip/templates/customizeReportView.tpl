{literal}
<script type="text/javascript">
    function includecomma1old(c,v)
{
var x=Math.round(c);
x=x.toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != '')
lastThree = ',' + lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
//var res = res.toFixed(4);
//var res =number_format(res, 2);
var res = res+'.00';
document.getElementById(v).innerHTML=res;
}
</script>
<script type="text/javascript">
	function includecomma1(c,v)
{
//var x=Math.round(c);
//var x=c.toFixed(2);

var x=c.split(".");
var ld=x[1];
var ty=typeof(x[1]);//alert(ty);
if(ty == 'undefined')
{
   
    var ld='00';
}
else
{
var ld=x[1].slice(0, 2);
}
x=x[0].toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != '')
{
lastThree = ',' + lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
}
else
{
lastThree =  lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
}
//var res = res+'.00';
var res = res+'.'+ld;
document.getElementById(v).innerHTML=res;
}
</script>
{/literal}
<body onLoad="">
<div class="content-wrapper">
<section class="content-header">
	<div class="card table-responsive no-padding">
		<div class="card-header">
			<table style="margin-bottom:-10px;">
			<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
			<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		
				{if $smarty.get.branchId neq ""}<td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>
			<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>{/if}
		
          	<td style="font-size:15PX;font-weight: bold;">Customized Reports</font>&nbsp;</td>
            <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
             <td style="font-size:15PX;font-weight: bold;">{$ListMaster.0.reportName}&ensp;&ensp;</td>
            </tr>
			<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
			<td style="font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		
		{if $smarty.get.branchId neq ""}	<td style="font-size:10PX;color:#999999;">Branch Name</td>
			<td style="font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>{/if}
		
            
			<td style="font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
            <td style="color:#999999;font-size:15PX;"></td>
            <td style="font-size:10PX;color:#999999;">Report Name</td>
			
			</tr>
			</table>
		</div>
	</div>
	<form name="meterList" method="post" id="meterList">
	     <input type="hidden" id="ssensor" name="ssensor" value="{$ListDailyRep.0.sensorCode}">
	<div class="row">
		<div class="col-12">
			<div class="card">
			    <!--<a href="customizeReportList.php"><button type="button" style="float:right;margin-top:6PX;margin-right:16px;" class="btn btn-info"> List Customized Report</button></a>-->
			{if $SuccessMessage neq "" || $ErrorMessage neq ""}
				<div class="card-body">
				{if $SuccessMessage neq ""}
					<div class="isa_success">
					<i class="fa fa-check"></i>
					{$SuccessMessage}		 
					</div>
				{/if}
				{if $ErrorMessage neq ""}
					<div class="isa_error">
					<i class="fa fa-check"></i>
					{$ErrorMessage}		 
					</div>
				{/if}
				</div>
			{/if}
			<input type="hidden" id="sname" name="sname" value="{$smarty.post.shiftName}" />
            <input type="hidden" id="cname" name="cname" value="{$smarty.session.COMPANY_ID}" />
            <input type="hidden" id="sno" name="sno" value="{$smarty.get.slNo|base64_decode}" />
            <input type="hidden" id="companyId" name="companyId" value="{$smarty.get.companyId|base64_decode}" />
            <input type="hidden" id="branchId" name="branchId" value="{$smarty.get.branchId|base64_decode}" />
				<div class="card-body table-responsive">
				  
				<div class="col-sm-12">
                    <div class="col-sm-2"  style="float:left;margin-top:10PX;">From Date: <input type="text" id="fromDate" name="fromDate" value="{if $smarty.post.shiftName neq '' && $smarty.post.fromDate eq ''}{$yesterday|date_format:'%Y-%m-%d'}{elseif $smarty.post.fromDate neq ''}{$smarty.post.fromDate|date_format:'%Y-%m-%d'}{else}{$yesterday|date_format:'%Y-%m-%d'}{/if}" class="form-control" autocomplete="off" readonly="true" >&nbsp;&nbsp;&nbsp;&nbsp;</div>
                    
                    	<div class="col-sm-2"  style="float:left;margin-top:10PX;" > To Date: <input type="text" id="toDate" name="toDate" value="{if $smarty.post.toDate eq ''}{$yesterday|date_format:'%Y-%m-%d'}{elseif $smarty.post.toDate neq ''}{$smarty.post.toDate|date_format:'%Y-%m-%d'}{else}{$yesterday|date_format:'%Y-%m-%d'}{/if}" class="form-control" autocomplete="off" readonly="true"></div>
                        
                        <div class="col-sm-2"  style="float:left;margin-top:30PX;">
				<select class="form-control" id="shiftName" name="shiftName"  tabindex="1"  >
			<option value="">--Select Shift--</option>
			{foreach from=$ListShift item=shift}
			{if $smarty.post.shiftName neq "" && $smarty.post.shiftName eq $shift.shift_master_id}
			<option value="{$shift.shift_master_id}" selected>{$shift.shift_name} - {$shift.start_time} - {$shift.end_time}</option>
			{else}
			<option value="{$shift.shift_master_id}">{$shift.shift_name} - {$shift.start_time} - {$shift.end_time}</option>
			{/if}
			{/foreach}
				</select>
				</div>
                
                <div class="col-sm-2"  style="float:left;margin-top:30PX;">
					<input type="button" value="Submit" id="submitButton" name="submitButton" class="btn btn-create" style="">
                    <!--<a href="#" onClick="get_excel();"><img src="images/excel1.png"  height="23" width="23" alt="Excel" title="Xls" ></a>-->
                    <input type="button" value="Excel" id="excelButton" name="excelButton" class="btn btn-create" style="" title="Xls" onClick="get_excel();">
					</div>
                    
				    
                    
                    <div class="col-sm-4"  style="float:left;margin-top:30PX;"><a href="customizeReportAddEdit.php?slNo={$smarty.get.slNo}&companyId={$smarty.get.companyId}&branchId={$smarty.get.branchId}&Update=y"><button type="button" class="btn btn-danger">Edit Report</button></a>&nbsp;&nbsp;<a href="customizeReportList.php"><button type="button" class="btn btn-info">List Customized Report</button></a></div>
                    
                    <!--<div class="col-sm-2"  style="float:left;margin-top:30PX"><a href="customizeReportList.php"><button type="button" class="btn btn-info">List Customized Report</button></a></div>-->
				</div>
				<P><br><br><br></P>
					<table id="example" class="table table-bordered table-hover">
					<thead>
					<tr>
					<th class="slNo" rowspan="2">#</th>
                    <th class="" rowspan="2">Sensor Name</th>
					<th class="" rowspan="2">Start KWH</th>
                    <th class="" rowspan="2">End KWH</th>
                    <th class="" rowspan="2">Total KWH</th>
					<th class="" rowspan="2">Total Cost</th>
					</tr>
					
					</thead>
					<tbody>
					{foreach from=$ListDataMaster item=arr1}
                  {assign var="ckwh" value=$arr1.end_cum_kwh-$arr1.start_cum_kwh}
					<tr id="{$j++}">
					<td >{$j}</td>
					<td align="left">{$arr1.sensorName}</td>
                    <td align="right" id="1{$j}"><script type="text/javascript">includecomma1('{$arr1.start_cum_kwh}','1{$j}');</script></td>
                    <td align="right" id="2{$j}"><script type="text/javascript">includecomma1('{$arr1.end_cum_kwh}','2{$j}');</script></td>
                    <td align="right" id="3{$j}"><script type="text/javascript">includecomma1('{$ckwh}','3{$j}');</script></td>
                    <td align="right" id="4{$j}"><script type="text/javascript">includecomma1('{$arr1.ccost}','4{$j}');</script></td>
                     {assign var="startTKWH" value=$startTKWH+$arr1.start_cum_kwh}
					{assign var="endTKWH" value=$endTKWH+$arr1.end_cum_kwh}
					{assign var="conTKWH" value=$conTKWH+$ckwh}
					{assign var="conTCOST" value=$conTCOST+$arr1.ccost}
					</tr>
					{/foreach}
                    {if $ListDataMaster.0.start_cum_kwh neq '' && $ListDataMaster.0.start_cum_kwh neq '0.00'}
					<!--<tr >
					<td align="center" ></td>
					<td align="right" ><b>Total</b></td>
					<td align="right" ><b><span id="fkwh"><script type="text/javascript">includecomma1('{$startTKWH}','fkwh');</script></span></b></td>
					<td align="right" ><b><span id="ftot"><script type="text/javascript">includecomma1('{$endTKWH}','ftot');</script></span></b></td>
					<td align="right" ><b><span id="skwh"><script type="text/javascript">includecomma1('{$conTKWH}','skwh');</script></span></b></td>
					<td align="right" ><b><span id="ttot"><script type="text/javascript">includecomma1('{$conTCOST}','ttot');</script></span></b></td>
					</tr>-->
				    {/if}
					</tbody>
					</table>
				</div>
			</div>
		</div>
	</form>
</section>
</div>
</body>
{literal}
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script>
$( function() {
	$( "#fromDate" ).datepicker({changeMonth: true,
	changeYear: true,maxDate: '-1',dateFormat:'yy-mm-dd'});
	$( "#toDate" ).datepicker({changeMonth: true,
	changeYear: true,maxDate: '-1',dateFormat:'yy-mm-dd'});
} );
</script>
<script type="text/javascript">
	setTimeout(myURL, 5000);
	function myURL(){
	this.form.submit();
}
$(document).ready(function() {
$('#shiftName').on('change', function() {
	this.form.submit();
});
$('#submitButton').on('click', function() {
	this.form.submit();
});
});
</script>
	<script type="text/javascript">
function GetSensor()
{
    var val = document.getElementById('branchName').value;
var val1 = document.getElementById('sname').value;

$.ajax({
	type: "POST",
	url: "getSensors.php",
	data: {branch:val},
	success: function(result){
	var res = JSON.parse(result);
	var nlen=Object.keys(res).length;
		$("#sensorName").empty();
	var sel = '--Select Sensor--';
	$("#sensorName").append("<option value='' selected>"+sel+"</option>");
for( var i = 0; i<nlen; i++){
var id = res[i]['id'];
var name = res[i]['name'];
if(val1 == id)
{
$("#sensorName").append("<option value='"+id+"' selected>"+name+"</option>");
}
else if(val == '' && val1 == '')
{
$("#sensorName").append("<option value='' selected>"+sel+"</option>");
}
else
{
$("#sensorName").append("<option value='"+id+"'>"+name+"</option>");
}
}
	},
	error: function(result) {
	alert('error');
	}
	});
}

function GetShift()
{
var valc = document.getElementById('cname').value;
var val = document.getElementById('branchName').value;
var val1 = document.getElementById('sname').value;

$.ajax({
type: "POST",
url: "getShift.php",
data: {branch:val,company:valc},
success: function(result){
var res = JSON.parse(result);
var nlen=Object.keys(res).length;
$("#shiftName").empty();
var sel = '--Select Shift--';
$("#shiftName").append("<option value='' selected>"+sel+"</option>");
for( var i = 0; i<nlen; i++){
var id = res[i]['id'];
var name = res[i]['name'];
if(val1 == id)
{
$("#shiftName").append("<option value='"+id+"' selected>"+name+"</option>");
}
else if(val == '' && val1 == '')
{
$("#shiftName").append("<option value='' selected>"+sel+"</option>");
}
else
{
$("#shiftName").append("<option value='"+id+"'>"+name+"</option>");
}
}
},
error: function(result) {
alert('error');
}
});
}
</script>
	<style>
	.slNo{
	width:5%;
	}
	.code{
	width:10%;
	}
	.apiKey{
	width:30%;
	}
	.name{
	width:40%;
	}
	.isactive{
	width:10%;
	text-align:center;
	}
	.action{
	text-align:right;
	}
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>
<script type="text/javascript">
$(document).ready(function (){
var table = $('#example').DataTable({
"ordering" : false,
"pageLength": 50,
"bPaginate": false,
language: {
"infoFiltered": ""/*,
search: "_INPUT_",
searchPlaceholder: "Search..."*/
},
dom: '<bottom>p',
tableTools: {
"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
},
//dom: '<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p',
//dom: '<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p',

initComplete: function(){
//$("div.toolbar").html('<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>');   
}       
}); 
}); 
</script>
<script type="text/javascript">
	function get_excel(){
		var branchName = '';
		var shiftName = document.getElementById("shiftName").value;
		var fromDate = document.getElementById("fromDate").value;
		var toDate = document.getElementById("toDate").value;
		var slNo = document.getElementById("sno").value;
		var companyId = document.getElementById("companyId").value;
		var branchId = document.getElementById("branchId").value;
	
	if((fromDate!='' || toDate !='') )
	{
	if(fromDate =='')
	{
		alert("Please Specify From Date");
		document.getElementById("fromDate").style.borderColor="red";
		return false;
	}
	else if(toDate =='')
	{
		alert("Please Specify To Date");
		document.getElementById("toDate").style.borderColor="red";
		return false;
	}
	else if(fromDate > toDate)
	{
		alert("Do Not enter From Date greater than to Date");
		document.getElementById("fromDate").style.borderColor="red";
		return false;
	}
	}
	window.location.href="customize_report_xl.php?branchName="+branchId+"&shiftName="+shiftName+"&fromDate="+fromDate+"&toDate="+toDate+"&slNo="+slNo+"&companyId="+companyId+"&branchId="+branchId;
	}
	</script>

{/literal}
{include file="footer.tpl"}