	<div class="content-wrapper">
		<section class="content-header">
			<div class="card">
				<div class="card-header">
					<table style="margin-bottom:-10px;">
					<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
					<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="font-size:15PX;font-weight: bold;">{$BranchView.0.branch_name}&nbsp;&nbsp;</td>
					<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="font-size:15PX;font-weight: bold;">{if $smarty.get.shift_master_id eq ""}Create Shift{else}Edit Shift{/if}</font>&nbsp;</td></tr>
					<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
					<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="color:#999999;font-size:10PX;">Branch Name</td>
					<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
					</tr>
					</table>
					<a href="shiftList.php?companyId={$smarty.get.companyId}&branchId={$smarty.get.branchId}"><button type="button" style="float:right;margin-top:-30PX" class="btn btn-primary">List Shift</button></a>
				</div>
			</div>
		</section>
		<section class="content">
			<div class="card">
				<div class="card-body">
					<form role="form" name="shiftForm" id="shiftForm" method="post" onsubmit="return createValidation();" >
						<input type="hidden" name="hdAction" />
						<input type="hidden" id="check_id" name="check_id" value="{$smarty.post.check_id}">
						<input type="hidden" id="checkVal" name="checkVal" value="{$smarty.post.checkVal}" />
						<div class="row">
							<div class="form-group col-md-6">
								<label for="exampleInputlocationId">Shift Name <span style="color:red;">*</span></label>
								<input type="text" class="form-control form-control-sm" id="shiftNameTxt" name="shiftNameTxt" placeholder="Enter Shift Name" value="{if $ListEditView.0.shift_name neq ""} {$ListEditView.0.shift_name}{/if}">
							</div>
						</div>
						<div class="row">
							<div class="form-group col-md-6">
								<label for="exampleInputlocationId">Start Time {$ListEditView.0.start_time} <span style="color:red;">*</span></label>
								<input type="time" class="form-control form-control-sm" id="startTimeTxt" name="startTimeTxt" placeholder="Enter Start Time" value="{if $ListEditView.0.start_time neq ""} {$ListEditView.0.start_time}{/if}">
							</div>
						</div>
						<div class="row">
							<div class="form-group col-md-6">
								<label for="exampleInputlocationId">End Time<span style="color:red;">*</span></label>
								<input type="time" class="form-control form-control-sm" id="endTimeTxt" name="endTimeTxt" placeholder="Enter End Time" value="{if $ListEditView.0.end_time neq ""} {$ListEditView.0.end_time}{/if}">
							</div>
						</div>
						<div class="form-group col-md-6">
							<div class="custom-control custom-checkbox">
							{if $ListEditView.0.is_active eq '1'}
								<input class="custom-control-input" type="checkbox" id="customCheckbox2"  name="customCheckbox2" tabindex="4" checked="checked">
								<label for="customCheckbox2" class="custom-control-label">Is Active</label>
							{elseif $ListEditView.0.is_active eq '0'}
								<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="4">
								<label for="customCheckbox2" class="custom-control-label">Is Active</label>
							{else}
								<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="4" checked="checked">
								<label for="customCheckbox2" class="custom-control-label">Is Active</label>
							{/if}
							</div>
								<input id="created_by" name="created_by" class="date-picker form-control" type="hidden" value="{$smarty.session.UserName}" readonly="true">
						</div>
						<div  align="center" class="col-md-6">
							<input type="submit" value="Submit" class="btn btn-create" />
						</div>
					</form>
				</div>
			</div>
		</div>
		</section>
	</div>
	{literal}
		<script type="text/javascript">
		document.getElementById("startTimeTxt").value="{/literal}{$ListEditView.0.start_time}{literal}";
		document.getElementById("endTimeTxt").value="{/literal}{$ListEditView.0.end_time}{literal}";
		function createValidation(){
		var shiftName = $('#shiftNameTxt').val();
		var startTime = $('#startTimeTxt').val();
		var endTime = $('#endTimeTxt').val();
		var isActive = document.getElementById("customCheckbox2").checked;
		if (isActive == false) 
		{
			document.getElementById('checkVal').value='0';
		}
		else
		{
			document.getElementById('checkVal').value='1';
		}
		$(".error").remove();
		if(shiftName.length < 1)
		{
			$('#shiftNameTxt').after('<span class="error">This field is required</span>');
			$('#shiftNameTxt').focus();
			return false;					
		}
		else if(startTime.length < 1 )
		{
			$('#startTimeTxt').after('<span class="error">This field is required</span>');
			$('#startTimeTxt').focus();
			return false;
		}	
		else if(endTime.length < 1 )
		{
			$('#endTimeTxt').after('<span class="error">This field is required</span>');
			$('#endTimeTxt').focus();
			return false;
		}		
			FormName		= document.shiftForm;
			FormName.method	= "POST";
			FormName.submit();
		}
		function GoBack()
		{
			window.history.back();
		}
		</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	{/literal}
	{include file="footer.tpl"}