{literal}
<script type="text/javascript">
     function secondsToDhms(seconds,v) {//alert(seconds);
var seconds = Number(seconds);
var d = Math.floor(seconds / (3600*24));
var h = Math.floor(seconds % (3600*24) / 3600);
var m = Math.floor(seconds % 3600 / 60);
var s = Math.floor(seconds % 60);

var dDisplay = d > 0 ? d + (d == 1 ? " day, " : " days, ") : "";
var hDisplay = h > 0 ? h + (h == 1 ? " hr, " : " hrs, ") : "";
var mDisplay = m > 0 ? m + (m == 1 ? " min, " : " min's, ") : "";
var sDisplay = s > 0 ? s + (s == 1 ? " sec" : " sec's") : "";
var res=  dDisplay + hDisplay + mDisplay + sDisplay;
document.getElementById(v).innerHTML=res;
}
 </script>{/literal}
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<body onLoad="doOnLoad();">
<div class="content-wrapper">
    <div class="content-header">

      <div class="container-fluid">
            <div class="row"> 
				<div class="col-md-12">
					<div class="card">
						<div class="card-body">
						  <table style="margin-bottom:-10px;">
						  <tr><td style="font-size:15PX;font-weight: bold;">{$companyDetail.0.companyName}&nbsp;&nbsp;</td>
						  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
						  <td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>
						  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
						  <td style="font-size:15PX;font-weight: bold;">Energy Meter</font>&nbsp;</td></tr>
						  <tr><td style="font-size:10PX;color:#999999;">Company Name</td>
						  <td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
						  <td style="font-size:10PX;color:#999999;">Branch Name</td>
						  <td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
						  <td style="color:#999999;font-size:10PX;">Dashboard</td><td>&nbsp;</td>
						  </tr>
						  </table>
						</div>
					</div>
				</div>
          </div>
    
        {if $branchDetail.0.EB eq "1"}
		<!--<a href="meterDashboard.php?companyId={$overallmainmeter.0.company_id|base64_encode}&branchId={$overallmainmeter.0.branch_id|base64_encode}&sensorCode={$overallmainmeter.0.sensorCode|base64_encode}&gatewayCode={$overallmainmeter.0.gateway_id|base64_encode}" style="text-decoration:none;color:#000000;" title="Click to view Overall Main Meter Details" >-->
        <div class="row ">
	<!--------  EB Data Starts      ------>
	<div class="card card-widget card-outline card-primary widget-user-2 col-md-12 ">
								
									<div class="card-header">
									<h5 class="" style="text-align:left"><b>EB Data</b></h5>
									
								</div>
							<br />	
		<div class="row  ">
		<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-info elevation-1"><i class="fa fa-bolt"></i></span>
			<div class="info-box-content">
			<div class="row">
			<span class="info-box-text" >T KWH&ensp;
      </span>
      <span>
      <b id="tckw"><script type="text/javascript">includecomma1('{$TodayDashGridEnergy.0.total_energy}','tckw');</script>
      </b>
      </span>
      </div>
			<span class="info-box-text">
			Y KWH&ensp;&ensp;&ensp;&ensp; <b id="yckw"><script type="text/javascript">includecomma1('{$YesterdayDashGridEnergy.0.yesterday_total_energy}','yckw');</script></b>
			</span>
			</div>
			</div>
		</div>
		<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box">
			<span class="info-box-icon bg-info elevation-1"><b>&#8377;</b></span>
			<div class="info-box-content">
			<span class="info-box-text">T Cost&ensp;&ensp;&ensp;&ensp;<b id="tc"><script type="text/javascript">includecomma1('{$TodayDashGridEnergy.0.total_cost}','tc');</script></b></span>
			<span class="info-box-text">

			Y Cost&ensp;&ensp;&ensp;&ensp; <b id="yc"><script type="text/javascript">includecomma1('{$YesterdayDashGridEnergy.0.yesterday_total_cost}','yc');</script></b>
			<small></small>
			</span>
			</div>
			</div>
		</div>
		
	<!-- fix for small devices only -->
	       <div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-info elevation-1"><i class="fa fa-bolt"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">This Month KWH</span>
			<span class="info-box-number" id="mck">
			<script type="text/javascript">includecomma1('{$ThisMonthDashGridEnergy.0.total_energy}','mck');</script>
			</span>
			</div>
			</div>
			</div>
			<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-info elevation-1"><b>&#8377;</b></span>
			<div class="info-box-content">
			<span class="info-box-text"> This Month Cost</span>
			<span class="info-box-number" id="mc">
			<script type="text/javascript">includecomma1('{$ThisMonthDashGridEnergy.0.total_cost}','mc');</script>
			</span>
			</div>
			</div>
			</div>
			<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-info elevation-1"><i class="fa fa-bolt"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">Last Month KWH</span>
			<span class="info-box-number" id="lmk">
			<script type="text/javascript">includecomma1('{$LastMonthDashGridEnergy.0.total_energy}','lmk');</script>
			</span>
			</div>
			</div>
			</div>
			<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-info elevation-1"><b>&#8377;</b></span>
			<div class="info-box-content">
			<span class="info-box-text">Last Month Cost</span>
			<span class="info-box-number" id="lckw">
			<script type="text/javascript">includecomma1('{$LastMonthDashGridEnergy.0.total_cost}','lckw');</script>
			</span>
			</div>
			</div>
			</div>
		</div></div>
	</div>
	<!--</a>-->
	{/if}
	<!--------  EB Data Ends      ------>
	<div></div>
	<!--------  DG Data Starts      ------>
	{if $branchDetail.0.DG eq "1"}
	<div class="row">
	<div class="card card-widget card-outline card-danger widget-user-2 col-md-12 ">
								
									<div class="card-header">
									<h5 class="" style="text-align:left"><b>DG Data  </b></h5>
									
								</div>
							<br />	
		<div class="row">
		<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-danger elevation-1"><i class="fa fa-bolt"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">Today KWH&ensp;&ensp;&ensp;&ensp;</span>
			<span class="info-box-number" id="tkDG">
			<script type="text/javascript">includecomma1('{$TodayDashDGEnergy.0.dg_energy}','tkDG');</script>
			</span>
			</div>
			</div>
		</div>
		<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box">
			<span class="info-box-icon bg-danger elevation-1"><i class="fa fa-rupee"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">Today Cost&ensp;&ensp;&ensp;&ensp;</span>
			<span class="info-box-number" id="tkDGc">
			<script type="text/javascript">includecomma1('{$TodayDashDGEnergy.0.total_dg_cost}','tkDGc');</script>
			<small></small>
			</span>
			</div>
			</div>
		</div>
		
	<!-- fix for small devices only -->
	        <div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-danger elevation-1"><i class="fa fa-bolt"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">This Month KWH</span>
			<span class="info-box-number" id="ckDG">
			<script type="text/javascript">includecomma1('{$ThisMonthDashDGEnergy.0.dg_energy}','ckDG');</script>
			</span>
			</div>
			</div>
			</div>
			<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-danger elevation-1"><i class="fa fa-rupee"></i></span>
			<div class="info-box-content">
			<span class="info-box-text"> This Month Cost</span>
			<span class="info-box-number" id="cckDG">
			<script type="text/javascript">includecomma1('{$ThisMonthDashDGEnergy.0.total_dg_cost}','cckDG');</script>
			</span>
			</div>
			</div>
			</div>
			<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-danger elevation-1"><i class="fa fa-bolt"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">Last Month KWH</span>
			<span class="info-box-number" id="lkDG">
			<script type="text/javascript">includecomma1('{$LastMonthDashDGEnergy.0.dg_energy}','lkDG');</script>
			</span>
			</div>
			</div>
			</div>
			<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-danger elevation-1"><i class="fa fa-rupee"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">Last Month Cost</span>
			<span class="info-box-number" id="lckDG">
			<script type="text/javascript">includecomma1('{$LastMonthDashDGEnergy.0.total_dg_cost}','lckDG');</script>
			</span>
			</div>
			</div>
			</div>
		</div></div>
	</div>
	{/if}
	<!--------  DG Data Ends      ------>
	<!--------  Solar Data Starts      ------>
	{if $branchDetail.0.solarInverter eq "1"}
	<div class="row">
	<div class="card card-widget card-outline card-warning widget-user-2 col-md-12 ">
								
									<div class="card-header">
									<h5 class="" style="text-align:left"><b>Solar Data  </b></h5>
									
								</div>
							<br />	
		<div class="row">
		<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-warning elevation-1"><i class="fa fa-bolt"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">Today KWH&ensp;&ensp;&ensp;&ensp;</span>
			<span class="info-box-number" id="tk">
			<script type="text/javascript">includecomma1('{$TodayDashSolarEnergy.0.total_solar_energy}','tk');</script>
			</span>
			</div>
			</div>
		</div>
		<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box">
			<span class="info-box-icon bg-warning elevation-1"><i class="fa fa-rupee"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">Today Cost&ensp;&ensp;&ensp;&ensp;</span>
			<span class="info-box-number" id="tkc">
			<script type="text/javascript">includecomma1('{$TodayDashSolarEnergy.0.total_solar_cost}','tkc');</script>
			<small></small>
			</span>
			</div>
			</div>
		</div>
		
	<!-- fix for small devices only -->
	        <div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-warning elevation-1"><i class="fa fa-bolt"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">This Month KWH</span>
			<span class="info-box-number" id="ck">
			<script type="text/javascript">includecomma1('{$ThisMonthDashSolarEnergy.0.total_solar_energy}','ck');</script>
			</span>
			</div>
			</div>
			</div>
			<div class="col-12 col-sm-6 col-md-2">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-warning elevation-1"><i class="fa fa-rupee"></i></span>
			<div class="info-box-content">
			<span class="info-box-text"> This Month Cost</span>
			<span class="info-box-number" id="cck">
			<script type="text/javascript">includecomma1('{$ThisMonthDashSolarEnergy.0.total_solar_cost}','cck');</script>
			</span>
			</div>
			</div>
			</div>
		<div class="col-12 col-sm-6 col-md-2">
		<div class="info-box mb-2">
		<span class="info-box-icon bg-warning elevation-1"><i class="fa fa-bolt"></i></span>
		<div class="info-box-content">
		<span class="info-box-text">Last Month KWH</span>
		<span class="info-box-number" id="lk">
		<script type="text/javascript">includecomma1('{$LastMonthDashSolarEnergy.0.total_solar_energy}','lk');</script>
		</span>
		</div>
		</div>
		</div>
		<div class="col-12 col-sm-6 col-md-2">
		<div class="info-box mb-2">
		<span class="info-box-icon bg-warning elevation-1"><i class="fa fa-rupee"></i></span>
		<div class="info-box-content">
		<span class="info-box-text">Last Month Cost</span>
		<span class="info-box-number" id="lck">
		<script type="text/javascript">includecomma1('{$LastMonthDashSolarEnergy.0.total_solar_cost}','lck');</script>
		</span>
		</div>
		</div>
		</div>
		</div></div>
	</div>
	{/if}
	<!--------  Solar Data End      ------>
	</div>
        
        <textarea id="thisMonthPieData" name="thisMonthPieData" style="display:none;">{$getCurMonQut1Dash}</textarea>
        <textarea id="lastMonthPieData" name="lastMonthPieData"  style="display:none;">{$getLastMonQut2Dash}</textarea>
        <!--<textarea id="currMonQut3" name="currMonQut3"  style="display:none;">{$getCurMonQut3}</textarea>--->
         <div class="row">
		 <div class="col-md-6">
     <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">This month - Kwh</h3>
              </div>
              <div class="card-body">
                <canvas id="pieChart1" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
              </div>
            </div>
            </div>
             <div class="col-md-6">
     <div class="card card-warning">
              <div class="card-header">
                <h3 class="card-title">This month - Cost</h3>
              </div>
              <div class="card-body">
                <canvas id="pieChart4" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
              </div>
            </div>
            </div>
            
             
            <div class="col-md-6">
     <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Last month - Kwh</h3>
              </div>
              <div class="card-body">
                <canvas id="pieChart2" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
              </div>
            </div>
            </div>
            <div class="col-md-6">
     <div class="card card-warning">
              <div class="card-header">
                <h3 class="card-title">Last month - Cost</h3>
              </div>
              <div class="card-body">
                <canvas id="pieChart3" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
              </div>
            </div>
            </div>         
            </div>
        <textarea id="currMonQutDaily" name="currMonQutDaily"  style="display:none;">{$getCurMonSalDailyDash}</textarea>
        <div class="row">
				<div class="col-md-12">
			
					<div class="card card-primary card-outline">
						<div class="card-header">
						<h3 class="card-title">
						<i class="far fa-chart-bar"></i>
						Daily Cost Chart
						</h3>
						</div>
                        
					<!--<div id="linechartdiv" style="height: 260px;"></div><br />-->
                    
                    <div class="chart">
        <canvas id="DailybarChart2" style="height: 278px;" ></canvas>
        </div>
                    
					</div>
				</div>
			
			
			</div>
        <textarea id="currMonQut" name="currMonQut"  style="display:none;">{$getCurMonQutDash}</textarea>
		
        <div class="row">
				<div class="col-md-8">
			
					<div class="card card-primary card-outline">
						<div class="card-header">
						<h3 class="card-title">
						<i class="far fa-chart-bar"></i>
						Monthly Cost Chart
						</h3>
						</div>
                        
					<!--<div id="linechartdiv" style="height: 260px;"></div><br />-->
                    
                    <div class="chart">
        <canvas id="barChart2" style="height: 340px;" ></canvas>
        </div>
                    
					</div>
				</div>
			
			
			
			<div class="col-md-4">
			<div class="card card-primary card-outline">
			<div class="card-header">
			<h3 class="card-title">Recent Incidents</h3>
			</div>
			<div class="card-body p-0">
			<ul class="products-list product-list-in-card pl-2 pr-2">
			{foreach from=$incidentList item=ListIncidentLog}
			{assign var="alertMsg0" value=$ListIncidentLog.alert_message|replace:'Hi!':''}
			{assign var="alertMsg1" value=$alertMsg0|replace:'Best regards,':''}
			{assign var="alertMsg" value=$alertMsg1|replace:'Arka Automaations Limited.':''}
			{assign var="alertBreak" value=","|explode:$alertMsg}
			{assign var="l" value=0}
			<li class="item">
			<div class="product-img">
			<a href="javascript:void(0)" class="product-title">{$ListIncidentLog.sensorName} <br>- ( {$ListIncidentLog.recorded_date_time|date_format:"%e-%b-%Y %I:%M %p"} )</a>
			{if $ListIncidentLog.alert_status eq "Low"}<span class="badge badge-warning float-right">{elseif $ListIncidentLog.alert_status eq "Normal"}<span class="badge badge-info float-right">{elseif $ListIncidentLog.alert_status eq "High"}<span class="badge badge-danger float-right">{/if}{$ListIncidentLog.alert_status}</span>
			<span class="product-description" style="font-size:12px">
			{section name=i loop=$alertBreak}
			{assign var="l" value=$l+1}
			{$alertBreak[i]|escape},{if $l eq '1'}<br />{/if}
			{/section}
			</span>
			</div>
			</li>
			{/foreach}
			</ul>
			</div>
			<div class="card-footer text-center">
			<a href="listIncidentLog.php" class="uppercase">View All Incidents</a>
			</div>
			</div>
			</div>
			</div>
        
        
            <div class="row">
			<div class="col-md-10">
            <div class="card card-outline card-primary">
            <div class="card-header">
						<h3 class="card-title">
						<i class="fa fa-list"></i>
						&nbsp;&nbsp;List of Energy Meter
						</h3>
						
						</div>
               <div class="card-body table-responsive no-padding">
			 <div class="row">
<input type="hidden" id="cid" name="cid" value="{if $smarty.get.companyId neq ""}{$smarty.get.companyId}{else}{$smarty.session.customerId}{/if}" />
				<input type="hidden" id="bid" name="bid" value="{$smarty.get.branchId}" />
				<input type="hidden" value="{$Dashboard.0.segmentName}" />
    <div id="list_books" class="col-12">
			  <table id="example" class="table table-bordered table-hover">
                <thead>
                <tr>
    			  <th class="slNo" rowspan="3" >#</th>
                  <th class="name" rowspan="3">Place Of Installation </th>
                  <th class="gate" rowspan="3">Gateway</th>
				 <!--  <th class="status" rowspan="3">Status</th>-->
				 {if $branchDetail.0.EB eq "1" AND $branchDetail.0.DG eq "1" AND $branchDetail.0.solarInverter eq "1"}
                  <th colspan="6" class="code" >Today</th>
				  {elseif $branchDetail.0.EB eq "1" AND $branchDetail.0.DG eq "1" AND $branchDetail.0.solarInverter eq "0"}
				  <th colspan="4" class="code" >Today</th>
				  {elseif $branchDetail.0.EB eq "1" AND $branchDetail.0.DG eq "0" AND $branchDetail.0.solarInverter eq "1"}
				  <th colspan="4" class="code" >Today</th>
				  {elseif $branchDetail.0.EB eq "1" AND $branchDetail.0.DG eq "0" AND $branchDetail.0.solarInverter eq "0"}
				  <th colspan="2" class="code" >Today</th>
				  {elseif $branchDetail.0.EB eq "0" AND $branchDetail.0.DG eq "1" AND $branchDetail.0.solarInverter eq "1"}
				  <th colspan="4" class="code" >Today</th>
				  {elseif $branchDetail.0.EB eq "0" AND $branchDetail.0.DG eq "1" AND $branchDetail.0.solarInverter eq "0"}
				   <th colspan="2" class="code" >Today</th>
				  {elseif $branchDetail.0.EB eq "0" AND $branchDetail.0.DG eq "0" AND $branchDetail.0.solarInverter eq "1"}
				   <th colspan="2" class="code" >Today</th>
				  {else}
				  <!-- <th colspan="6" class="code" >Today</th>-->
				   {/if}
                  <th class="action" rowspan="3">Date Time</th>
                  <th class="last" rowspan="3">Last Comm</th>
                  
          
                </tr>
                <tr>
				{if $branchDetail.0.EB eq "1"}
                    <th class="cost" colspan="2">EB</th>
				{/if}
                  {if $branchDetail.0.DG eq "1"}
                    <th class="cost" colspan="2">DG</th>
				{/if}
				{if $branchDetail.0.solarInverter eq "1"}
                    <th class="cost" colspan="2">Solar</th>
				{/if}
                </tr>
                <tr>
    			 {if $branchDetail.0.EB eq "1"}
                  <th class="cost" >KWH</th>
                  <th class="cost" >Cost</th>
				  {/if}
				  {if $branchDetail.0.DG eq "1"}
                   <th class="cost" >KWH</th>
                  <th class="cost" >Cost</th>
				  {/if}
				  {if $branchDetail.0.solarInverter eq "1"}
				  <th class="cost" >KWH</th>
                  <th class="cost" >Cost</th>
				  {/if}
               
                 
                  
                </tr>
                </thead>
                <tbody>
                    
				{foreach from=$MeterListDash item=List}
                {assign var=pid value=$List.slNo|base64_encode}
                {assign var=subMetL value="No"}
                <tr id="{$j++}">
				 <td >{$j}</td>
				 	
                 
                     <td><a href="meterDashboard.php?companyId={$List.company_id|base64_encode}&branchId={$List.branch_id|base64_encode}&sensorCode={$List.sensor_code|base64_encode}&gatewayCode={$List.gateway_code|base64_encode}" style="text-decoration:underline;color:#000000;" title="Meter Details" >{$List.feeder_name}</a>{foreach from=$selQryS item=sub}{if $List.feeder_type eq "Main Meter" &&  $List.slNo eq $sub.parent_id && $subMetL eq "No"}&ensp;&ensp;<a href="subdashboard.php?parent_id={$pid}&companyId={$smarty.get.companyId}&branchId={$smarty.get.branchId}"><i class="fa fa-sitemap" aria-hidden="true" title="Submeter List"></i></a>{assign var=subMetL value="Yes"}{/if}{/foreach}</td>
                 
                 <td >{$List.place_of_installation}</td>
				 
				 
		
			<!--	<td>
			
			
				{if $List.gateway_code neq "YMN-1" && $List.gateway_code eq $List.gateway_code && $List.gateway_date_time gte $dateSec|date_format:'%Y-%m-%d %H:%M:%S' }
                
                <img  src="./images/on.png">
                 {assign var="tog" value='1'}
                {elseif $List.gateway_code neq "YMN-1" && $List.gateway_code eq $List.gateway_code && $List.gateway_date_time lt $dateSec|date_format:'%Y-%m-%d %H:%M:%S'}
                
                <img  src="./images/off.png">
                 {assign var="tog" value='1'}
                {/if}
                
                
                {if $List.gateway_code eq "YMN-1" && $List.gateway_code eq $List.gateway_code && $List.gateway_date_time gte $dateSec1|date_format:'%Y-%m-%d %H:%M:%S' }
                
                <img  src="./images/on.png">
                 {assign var="tog" value='1'}
                {elseif $List.gateway_code eq "YMN-1" && $List.gateway_code eq $List.gateway_code && $List.gateway_date_time lt $dateSec1|date_format:'%Y-%m-%d %H:%M:%S'}
                
                <img  src="./images/off.png">
                 {assign var="tog" value='1'}
                {/if}
               
               
                {if $tog eq ''}
                
                <img  src="./images/off.png">
                {/if}
                 {assign var="tog" value=''}
                </td>
				
				
			-->
                 
         
             
			
				   {if $branchDetail.0.EB eq "1"}
                    <td align="right" id="{$j}kwh"> <script type="text/javascript">includecomma1('{$List.TOTAL_KWH}','{$j}kwh');</script></td>
                    <td align="right" id="{$j}cost"> <script type="text/javascript">includecomma1('{$List.cost}','{$j}cost');</script></td>
					{/if}
					 {if $branchDetail.0.DG eq "1"}
                    <td align="right" id="{$j}dgkwh"> <script type="text/javascript">includecomma1('{$List.dg_TOTAL_KWH}','{$j}dgkwh');</script></td>
                    <td align="right" id="{$j}dgcost"> <script type="text/javascript">includecomma1('{$List.dg_cost}','{$j}dgcost');</script></td>
					{/if}
					 {if $branchDetail.0.solarInverter eq "1"}
					  <td align="right" id="{$j}solarkwh"> <script type="text/javascript">includecomma1('{$List.solar_TOTAL_KWH}','{$j}solarkwh');</script></td>
                    <td align="right" id="{$j}solarcost"> <script type="text/javascript">includecomma1('{$List.solar_cost}','{$j}solarcost');</script></td>
					 {/if}
                     {assign var=totalKWH value=$totalKWH+$List.TOTAL_KWH}
                     {assign var=totalCost value=$totalCost+$List.cost}
                     {assign var=dgTotalKWH value=$dgTotalKWH+$List.dg_TOTAL_KWH}
                     {assign var=dgTotalCost value=$dgTotalCost+$List.dg_cost}
					 {assign var=solarTotalKWH value=$solarTotalKWH+$List.solar_TOTAL_KWH}
                     {assign var=solarTotalCost value=$solarTotalCost+$List.solar_cost}
				
				  <td>{$SpecificTableDate.0.posted_date_time|date_format:"%d-%b-%Y %I:%M:%S %p"}</td>
		       <td>{$gatewayListDash.0.last_communication}</td>
			   
            
                </tr>
                
                {/foreach}
               {if $PMeterList neq ""}
               {foreach from=$PMeterList item=List}
                {assign var=pid value=$List.slNo|base64_encode}
                <tr id="{$j++}">
				 <td >{$j}</td>
				 	
                 
                     <td><a href="meterDashboard.php?companyId={$List.company_id|base64_encode}&branchId={$List.branch_id|base64_encode}&sensorCode={$List.sensor_code|base64_encode}&gatewayCode={$List.gateway_code|base64_encode}" style="text-decoration:underline;color:#000000;" title="Meter Details" >{$List.feeder_name}</a>{foreach from=$selQryS item=sub}{if $List.feeder_type eq "Main Meter" &&  $List.slNo eq $sub.parent_id}&ensp;&ensp;<a href="subdashboard.php?parent_id={$pid}&companyId={$smarty.get.companyId}&branchId={$smarty.get.branchId}"><i class="fa fa-sitemap" aria-hidden="true" title="Submeter List"></i></a>{/if}{/foreach}</td>
                 
                 <td >{$List.gateway_code}</td>
				 
				 
		
			<!--	<td>
				
			
				{if $List.gateway_code neq "YMN-1" && $List.gateway_code eq $List.gateway_code && $List.gateway_date_time gte $dateSec|date_format:'%Y-%m-%d %H:%M:%S' }
                
                <img  src="./images/on.png">
                 {assign var="tog" value='1'}
                {elseif $List.gateway_code neq "YMN-1" && $List.gateway_code eq $List.gateway_code && $List.gateway_date_time lt $dateSec|date_format:'%Y-%m-%d %H:%M:%S'}
                
                <img  src="./images/off.png">
                 {assign var="tog" value='1'}
                {/if}
                
                
                {if $List.gateway_code eq "YMN-1" && $List.gateway_code eq $List.gateway_code && $List.gateway_date_time gte $dateSec1|date_format:'%Y-%m-%d %H:%M:%S' }
                
                <img  src="./images/on.png">
                 {assign var="tog" value='1'}
                {elseif $List.gateway_code eq "YMN-1" && $List.gateway_code eq $List.gateway_code && $List.gateway_date_time lt $dateSec1|date_format:'%Y-%m-%d %H:%M:%S'}
                
                <img  src="./images/off.png">
                 {assign var="tog" value='1'}
                {/if}
               
               
                {if $tog eq ''}
                
                <img  src="./images/off.png">
                {/if}
                 {assign var="tog" value=''}
                </td>
				
				
			-->
                 
            
				 
				  {if $branchDetail.0.EB eq "1"}
                    <td align="right" id="{$j}kwh"> <script type="text/javascript">includecomma1('{$List.TOTAL_KWH}','{$j}kwh');</script></td>
                    <td align="right" id="{$j}cost"> <script type="text/javascript">includecomma1('{$List.cost}','{$j}cost');</script></td>
					{/if}
				   {if $branchDetail.0.DG eq "1"}
                    <td align="right" id="{$j}dgkwh"> <script type="text/javascript">includecomma1('{$List.dg_TOTAL_KWH}','{$j}dgkwh');</script></td>
                    <td align="right" id="{$j}dgcost"> <script type="text/javascript">includecomma1('{$List.dg_cost}','{$j}dgcost');</script></td>
                    {/if}
				   {if $branchDetail.0.solarInverter eq "1"}
				    <td align="right" id="{$j}solarkwh"> <script type="text/javascript">includecomma1('{$List.solar_TOTAL_KWH}','{$j}solarkwh');</script></td>
                    <td align="right" id="{$j}solarcost"> <script type="text/javascript">includecomma1('{$List.solar_cost}','{$j}solarcost');</script></td>
					{/if}
				  {assign var=totalKWH value=$totalKWH+$List.TOTAL_KWH}
                     {assign var=totalCost value=$totalCost+$List.cost}
                     {assign var=dgTotalKWH value=$dgTotalKWH+$List.dg_TOTAL_KWH}
                     {assign var=dgTotalCost value=$dgTotalCost+$List.dg_cost}
					 {assign var=solarTotalKWH value=$solarTotalKWH+$List.solar_TOTAL_KWH}
                     {assign var=solarTotalCost value=$solarTotalCost+$List.solar_cost}
				  <td>{$List.recorded_date_time|date_format:"%d-%b-%Y %I:%M:%S %p"}</td>
		       <td id="{$j}"><script type="text/javascript">secondsToDhms('{$List.secs}','{$j}');</script> </td>
			   
            
                </tr>
              
                {/foreach}
               {/if}
               <tr>
                   <td></td>
                   <td></td>
                   <td></td>
				   {if $branchDetail.0.EB eq "1"}
                   <td align="right" id="tKwh"><script type="text/javascript">includecomma1('{$totalKWH}','tKwh');</script></td>
                   <td align="right" id="tCost"><script type="text/javascript">includecomma1('{$totalCost}','tCost');</script></td>
				   {/if}
				   {if $branchDetail.0.DG eq "1"}
                   <td align="right" id="tdgKwh"><script type="text/javascript">includecomma1('{$dgTotalKWH}','tdgKwh');</script></td>
                   <td align="right" id="tdgCost"><script type="text/javascript">includecomma1('{$dgTotalCost}','tdgCost');</script></td>
				   {/if}
				   {if $branchDetail.0.solarInverter eq "1"}
				   <td align="right" id="tsolarKwh"><script type="text/javascript">includecomma1('{$solarTotalKWH}','tsolarKwh');</script></td>
                   <td align="right" id="tsolarCost"><script type="text/javascript">includecomma1('{$solarTotalCost}','tsolarCost');</script></td>
				   {/if}
                   <td></td>
                   <td></td>
                </tr>
               
                </tbody>
                
              </table>
			  </div>
</div>
</div>
<div class="card-body table-responsive">
            <div class="row">
        </div>
        </div>
      </div>
    </div>
	
	<div class="col-md-2">
			<div class="card card-primary card-outline">
			<div class="card-header">
			<h3 class="card-title">Gateway List</h3>
			</div>
			<div class="card-body p-0">
			<ul class="products-list product-list-in-card pl-2 pr-2">
			 {foreach from=$gatewayListDash item=List}
			
			<li class="item">
			<div class="product-img">
			<a href="javascript:void(0)" class="product-title">{$List.place_of_installation}  &ensp; &ensp; &ensp; &ensp; &ensp; &ensp;&ensp;</a>
			{if $List.gateway_code neq "YMN-1" && $List.gateway_code eq $List.gateway_code && $List.gateway_date_time gte $dateSec|date_format:'%Y-%m-%d %H:%M:%S' }
               <span class="badge badge-success float-right"> 
                ON
                </span>
                 {assign var="tog" value='1'}
                {elseif $List.gateway_code neq "YMN-1" && $List.gateway_code eq $List.gateway_code && $List.gateway_date_time lt $dateSec|date_format:'%Y-%m-%d %H:%M:%S'}
                <span class="badge badge-danger float-right">
              OFF
               </span>
                 {assign var="tog" value='1'}
                {/if}
                
                
                {if $List.gateway_code eq "YMN-1" && $List.gateway_code eq $List.gateway_code && $List.gateway_date_time gte $dateSec1|date_format:'%Y-%m-%d %H:%M:%S' }
                <span class="badge badge-success float-right"> 
               ON
                </span>
                 {assign var="tog" value='1'}
                {elseif $List.gateway_code eq "YMN-1" && $List.gateway_code eq $List.gateway_code && $List.gateway_date_time lt $dateSec1|date_format:'%Y-%m-%d %H:%M:%S'}
                 <span class="badge badge-danger float-right">
                     OFF
                </span>
                 {assign var="tog" value='1'}
                {/if}
               
               
                {if $tog eq ''}
                 <span class="badge badge-danger float-right">
                OFF
                 </span>
                {/if}
                 {assign var="tog" value=''}
				
			
			<span class="product-description" style="font-size:12px">
			
			</span>
			</div>
			</li>
			
			{/foreach}
			</ul>
			</div>
		<!--	<div class="card-footer text-center">
			<a href="listIncidentLog.php" class="uppercase">View All Incidents</a>
			</div> -->
			</div>
			
			
			<div class="card card-primary card-outline">
			<div class="card-header">
			<h3 class="card-title">EB Meters</h3>
			</div>
			<div class="card-body p-0">
			<ul class="products-list product-list-in-card pl-2 pr-2">
			<li class="item">
			<div class="product-img">
			<a href="javascript:void(0)" class="product-title text-primary">Overall  &ensp; &ensp; &ensp; &ensp; &ensp; &ensp;&ensp;</a>
               <span class="badge badge-primary float-right"> 
                {$overallmeters}
                </span>
   			</div>
			</li>
			<li class="item">
			<div class="product-img">
			<a href="javascript:void(0)" class="product-title text-success" >Live  &ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp;&ensp;</a>
               <span class="badge badge-success float-right"> 
                {$livemeters}
                </span>
   			</div>
			</li>
			<li class="item">
			<div class="product-img">
			<a href="javascript:void(0)" class="product-title text-danger">Off&ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp;&ensp;</a>
               <span class="badge badge-danger float-right"> 
                {$offmeters}
                </span>
   			</div>
			</li>
			<li class="item">
			<div class="product-img">
			<a href="javascript:void(0)" class="product-title text-warning">No Con.. &nbsp; &ensp; &ensp; &ensp; &ensp; &ensp;&ensp;</a>
               <span class="badge badge-warning float-right"> 
                {$noconnectionmeters}
                </span>
   			</div>
			</li>

			</ul>
			</div>
		<!--	<div class="card-footer text-center">
			<a href="listIncidentLog.php" class="uppercase">View All Incidents</a>
			</div> -->
			</div>
			</div>
  </div>
  </div>
  </div>
  </div>
  </body>
 {literal}
 <style>
 .slNo
 {
 width:3%;
 }
 .name
 {
 width:18%;
 }
 .gate
 {
 width:10%;
 }
 .status
 {
 width:5%;
 }
 .code
 {
 width:10%;
 }
 .cost
 {
 width:5%;
 }
 .action
 {
 width:15%;
 }
 .last
 {
 width:11%;
 }
 .uline
 {
 text-decoration:underline;
 }
 #barChart2 {
	width	: 100%;
	height	: 450px;
	}	
	 #DailybarChart2{
	width	: 100%;
	height	: 450px;
	}	
 </style>
  <script>
  $(function () {
    $('#example1').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : true,
      'ordering'    : false,
      'info'        : false,
	  'pageLength': 50,
      'autoWidth'   : false,
      "columnDefs": [{
                "targets": '_all',
                "createdCell": function (th, cellData, rowData, row, col) {
                    $(th).css('padding', '10px')
                }
            }]
    })
  })
  
</script>
<!-- <script type="text/javascript">
 function doOnLoad()
 {
 setInterval(Add_Item, 3000);
 }
 </script>-->
 <script type="text/javascript">
  $("input[data-bootstrap-switch]").each(function(){
      $(this).bootstrapSwitch('state', $(this).prop('checked'));
    });
	</script>
<!--	    <script type="text/javascript">
	function Add_Item()
{
var cid =$('#cid').val() ;
var bid =$('#bid').val() ;//alert(bid)
$.ajax({
		type: "POST",
		url: "getTableData.php",
		data: {cid:cid,bid:bid},
		success: function(data) {
		$("#list_books").html(data);
		}
		});
}
	</script>-->
	<style>
	    .dataTable thead .sorting_asc,
 .dataTable thead .sorting_desc,
.dataTable thead .sorting {
    padding-left: 2.2rem !important;
    padding-right: 0.75rem !important;
 }
	</style>
	 <script type="text/javascript">
    function addcomma(c)
{
var x=c;
x=x.toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != '')
    lastThree = ',' + lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
return res;
}

function includecomma(c)
{
var x=c;
x=x.toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != '')
    lastThree = ',' + lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
return res;
}
</script>

  <script>
	/*********** This month - Kwh and Cost Pie Chart Start **********************/
	var result = document.getElementById('thisMonthPieData').value;

var jsonData=result;
var obj = JSON.parse(jsonData);
var sensor = "";
var dataVal = "";
var dataVal1 = "";
var colo = "";
var i;
for (i = 0; i < obj.length; i++) {
if(i==0){
  sensor += obj[i].sensorcode ;
  dataVal += obj[i].kwh;
  dataVal1 += obj[i].cost;
   colo += obj[i].color;
   }
  else
  {
  sensor += ", "+ obj[i].sensorcode;
  dataVal += ", "+ obj[i].kwh;
   dataVal1 += ", "+ obj[i].cost;
   colo += ', '+ obj[i].color;
 }
}

var sensorVal = sensor;
var dataValue =dataVal;
var dataValue1 =dataVal1;
var colors =colo;


var sensor =  sensorVal.split(',');
var dataV=  dataVal.split(',');
var dataV1=  dataVal1.split(',');
var colors=  colo.split(',');
 
var dis = Math.round(dataV);
var vad = addcomma(dis);

var pieChartData = {
labels  :  sensor,
datasets: [
{
label               : 'Kwh',
backgroundColor     : colors,
hoverBackgroundColor: colors,
hoverBorderColor    : colors,
borderColor         :  colors,
pointRadius          : false,
pointColor          :  colors,
pointStrokeColor    :  colors,
pointHighlightFill  :  colors,
pointHighlightStroke:  colors,
fillColor: colors,
data                : dataV
}
]
};
 
	var pieChartDataCost = {
labels  :  sensor,
datasets: [
{
label               : 'Cost',
backgroundColor     : colors,
hoverBackgroundColor: colors,
hoverBorderColor    : colors,
borderColor         :  colors,
pointRadius          : false,
pointColor          :  colors,
pointStrokeColor    :  colors,
pointHighlightFill  :  colors,
pointHighlightStroke:  colors,
fillColor: colors,
data                : dataV1
}
]
};
	
       /* This Month Kwh Pie */
  var pieChartCanvasKCM = $('#pieChart1').get(0).getContext('2d')
    var pieDataKCM       = pieChartData;
    var pieOptionsKCM     = {
      maintainAspectRatio : false,
      responsive : true,
      legend: {
        position: 'right',
      }
    }
      var pieChart = new Chart(pieChartCanvasKCM, {
      type: 'pie',
      data: pieDataKCM,
      options: pieOptionsKCM      
    })
    
    /* This Month Cost Pie */
  var pieChartCanvas = $('#pieChart4').get(0).getContext('2d')
    var pieData        = pieChartDataCost;
    var pieOptions     = {
      maintainAspectRatio : false,
      responsive : true,
      legend: {
        position: 'right',
      }
    }
      var pieChart = new Chart(pieChartCanvas, {
      type: 'pie',
      data: pieData,
      options: pieOptions      
    })

/*********** This month - Kwh and Cost Pie Chart End **********************/
	</script>

<script>

/*********** Last month - Kwh Pie Chart Start **********************/
var result = document.getElementById('lastMonthPieData').value;
var jsonData=result;
var obj = JSON.parse(jsonData);
var sensor = "";
var dataVal = "";
var dataVal1 = "";
var colo = "";
var i;
for (i = 0; i < obj.length; i++) {
if(i==0){
  sensor += obj[i].sensorcode ;
  dataVal += obj[i].kwh;
  dataVal1 += obj[i].cost;
   colo += obj[i].color;
   }
  else
  {
  sensor += ", "+ obj[i].sensorcode;
  dataVal += ", "+ obj[i].kwh;
   dataVal1 += ", "+ obj[i].cost;
   colo += ', '+ obj[i].color;
 }
}

var sensorVal = sensor;
var dataValue =dataVal;
var dataValue1 =dataVal1;
var colors =colo;


var sensor =  sensorVal.split(',');
var dataV=  dataVal.split(',');
var dataV1=  dataVal1.split(',');
var colors=  colo.split(',');
 
var dis = Math.round(dataV);
var vad = addcomma(dis);

var pieChartDataLast = {
labels  :  sensor,
datasets: [
{
label               : 'Kwh',
backgroundColor     : colors,
hoverBackgroundColor: colors,
hoverBorderColor    : colors,
borderColor         :  colors,
pointRadius          : false,
pointColor          :  colors,
pointStrokeColor    :  colors,
pointHighlightFill  :  colors,
pointHighlightStroke:  colors,
fillColor: colors,
data                : dataV
}
]
};

var pieChartDataCostLast = {
labels  :  sensor,
datasets: [
{
label               : 'Cost',
backgroundColor     : colors,
hoverBackgroundColor: colors,
hoverBorderColor    : colors,
borderColor         :  colors,
pointRadius          : false,
pointColor          :  colors,
pointStrokeColor    :  colors,
pointHighlightFill  :  colors,
pointHighlightStroke:  colors,
fillColor: colors,
data                : dataV1
}
]
};
      /* Last Month Kwh Pie */
var pieChartCanvas = $('#pieChart2').get(0).getContext('2d')
    var pieData        = pieChartDataLast;
    var pieOptions     = {
      maintainAspectRatio : false,
      responsive : true,
      legend: {
        position: 'right',
      }
    }
    //Create pie or douhnut chart
    // You can switch between pie and douhnut using the method below.
    var pieChart = new Chart(pieChartCanvas, {
      type: 'pie',
      data: pieData,
      options: pieOptions      
    })

        /* Last Month Cost Pie */
    var pieChartCanvas = $('#pieChart3').get(0).getContext('2d')
    var pieData        = pieChartDataCostLast;
    var pieOptions     = {
      maintainAspectRatio : false,
      responsive : true,
      legend: {
        position: 'right',
      }
    }
      var pieChart = new Chart(pieChartCanvas, {
      type: 'pie',
      data: pieData,
      options: pieOptions      
    })

    
   /*********** Last month - Kwh Pie Chart End **********************/
</script>



<script type="text/javascript">

/* BAR VALUE PLUGIN - register only one time */
if (!window.barValuePluginRegistered) {
  Chart.plugins.register({
    afterDatasetsDraw: function(chart) {
      if (!chart.options.showBarValue) return;

      var ctx = chart.ctx;

      chart.data.datasets.forEach(function(dataset, datasetIndex) {
        var meta = chart.getDatasetMeta(datasetIndex);

        meta.data.forEach(function(bar, index) {
          var value = dataset.data[index];

          if (value === null || value === undefined || value === '') return;

          value = Math.round(Number(value));

          var barX = bar._model.x;
          var barY = bar._model.y;
          var baseY = bar._model.base;
          var barHeight = baseY - barY;

          ctx.save();
          ctx.font = 'bold 10px Arial';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';

          /* Kwh blue bar - show value above */
          if (dataset.label == 'Kwh') {
            ctx.fillStyle = '#000000';
            ctx.fillText(includecomma(value), barX, barY - 8);
          }

          /* Cost yellow bar - show value inside vertically */
          if (dataset.label == 'Cost') {
            if (barHeight > 45) {
              ctx.fillStyle = '#ffffff';

              ctx.translate(barX, barY + 28);
              ctx.rotate(-Math.PI / 2);
              ctx.fillText(includecomma(value), 0, 0);
            } else {
              ctx.fillStyle = '#000000';
              ctx.fillText(includecomma(value), barX, barY - 8);
            }
          }

          ctx.restore();
        });
      });
    }
  });

  window.barValuePluginRegistered = true;
}


var result = document.getElementById('currMonQut').value;

var jsonData = result;
var obj = JSON.parse(jsonData);

var mon = "";
var dataVal = "";
var dataVal1 = "";
var colo = "";

for (var i = 0; i < obj.length; i++) {
  if (i == 0) {
    mon += obj[i].month;
    dataVal += obj[i].value;
    dataVal1 += obj[i].value1;
    colo += obj[i].color;
  } else {
    mon += ", " + obj[i].month;
    dataVal += ", " + obj[i].value;
    dataVal1 += ", " + obj[i].value1;
    colo += ", " + obj[i].color;
  }
}

var month = mon.split(',');
var dataV = dataVal.split(',').map(Number);
var dataV1 = dataVal1.split(',').map(Number);

var barChartCanvasSec = $('#barChart2').get(0).getContext('2d');

var barChartDataSec = {
  labels: month,
  datasets: [
    {
      label: 'Kwh',
      backgroundColor: '#67b7dc',
      borderColor: '#67b7dc',
      data: dataV
    },
    {
      label: 'Cost',
      backgroundColor: '#fdd400',
      borderColor: '#fdd400',
      data: dataV1
    }
  ]
};

var barChartOptionsSec = {
  showBarValue: true,

  responsive: true,
  maintainAspectRatio: false,
  datasetFill: false,

  legend: {
    display: true,
    position: 'top',
    labels: {
      boxWidth: 50,
      fontSize: 12
    }
  },

  tooltips: {
    callbacks: {
      label: function(tooltipItem, data) {
        var label = data.datasets[tooltipItem.datasetIndex].label || '';
        var value = Math.round(tooltipItem.yLabel);
        return label + ': ' + includecomma(value);
      }
    }
  },

  scales: {
    xAxes: [{
      gridLines: {
        display: true
      },
      ticks: {
        autoSkip: false,
        maxRotation: 45,
        minRotation: 45,
        fontSize: 11
      },
      categoryPercentage: 0.75,
      barPercentage: 0.85
    }],

    yAxes: [{
      ticks: {
        beginAtZero: true,
        stepSize: 5000,
        fontSize: 11,
        callback: function(value) {
          return includecomma(value);
        }
      }
    }]
  }
};

var barChartSec = new Chart(barChartCanvasSec, {
  type: 'bar',
  data: barChartDataSec,
  options: barChartOptionsSec
});

</script>
<script type="text/javascript">

/* Daily Bar Value Plugin */
Chart.plugins.register({
  afterDatasetsDraw: function(chart) {
    if (!chart.options.showBarValue) return;

    var ctx = chart.ctx;

    chart.data.datasets.forEach(function(dataset, datasetIndex) {
      var meta = chart.getDatasetMeta(datasetIndex);

      meta.data.forEach(function(bar, index) {
        var value = dataset.data[index];

        if (value === null || value === undefined || value === '') return;

        value = Math.round(Number(value));

        var barX = bar._model.x;
        var barY = bar._model.y;
        var baseY = bar._model.base;
        var barHeight = baseY - barY;

        ctx.save();
        ctx.font = 'bold 10px Arial';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';

        /* Kwh small blue bar - show above */
        if (dataset.label == 'Kwh') {
          ctx.fillStyle = '#000000';
          ctx.fillText(includecomma(value), barX, barY - 8);
        }

        /* Cost yellow bar - show inside bar */
        if (dataset.label == 'Cost') {
          if (barHeight > 45) {
            ctx.fillStyle = '#ffffff';

            /* Rotate value inside yellow bar */
            ctx.translate(barX, barY + 28);
            ctx.rotate(-Math.PI / 2);
            ctx.fillText(includecomma(value), 0, 0);
          } else {
            ctx.fillStyle = '#000000';
            ctx.fillText(includecomma(value), barX, barY - 8);
          }
        }

        ctx.restore();
      });
    });
  }
});


var result = document.getElementById('currMonQutDaily').value;
var jsonData = result;
var obj = JSON.parse(jsonData);

var mon = "";
var dataVal = "";
var dataVal1 = "";
var colo = "";

for (var i = 0; i < obj.length; i++) {
  if (i == 0) {
    mon += obj[i].dateM;
    dataVal += obj[i].value;
    dataVal1 += obj[i].value1;
    colo += obj[i].color;
  } else {
    mon += ", " + obj[i].dateM;
    dataVal += ", " + obj[i].value;
    dataVal1 += ", " + obj[i].value1;
    colo += ", " + obj[i].color;
  }
}

var month = mon.split(',');
var dataV = dataVal.split(',').map(Number);
var dataV1 = dataVal1.split(',').map(Number);

var barChartCanvasSec = $('#DailybarChart2').get(0).getContext('2d');

var barChartDataSec = {
  labels: month,
  datasets: [
    {
      label: 'Kwh',
      backgroundColor: '#67b7dc',
      borderColor: '#67b7dc',
      data: dataV
    },
    {
      label: 'Cost',
      backgroundColor: '#fdd400',
      borderColor: '#fdd400',
      data: dataV1
    }
  ]
};

var barChartOptionsSec = {
  showBarValue: true,

  responsive: true,
  maintainAspectRatio: false,
  datasetFill: false,

  legend: {
    display: true,
    position: 'top',
    labels: {
      boxWidth: 50,
      fontSize: 12
    }
  },

  tooltips: {
    callbacks: {
      label: function(tooltipItem, data) {
        var label = data.datasets[tooltipItem.datasetIndex].label || '';
        var value = Math.round(tooltipItem.yLabel);
        return label + ': ' + includecomma(value);
      }
    }
  },

  scales: {
    xAxes: [{
      gridLines: {
        display: true
      },
      ticks: {
        autoSkip: false,
        maxRotation: 45,
        minRotation: 45,
        fontSize: 11
      },
      categoryPercentage: 0.75,
      barPercentage: 0.85
    }],

    yAxes: [{
      ticks: {
        beginAtZero: true,
        stepSize: 1000,
        fontSize: 11,
        callback: function(value) {
          return includecomma(value);
        }
      }
    }]
  }
};

var barChartSec = new Chart(barChartCanvasSec, {
  type: 'bar',
  data: barChartDataSec,
  options: barChartOptionsSec
});

</script>
 {/literal}

  {include file="footer.tpl"}
