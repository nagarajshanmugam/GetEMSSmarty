<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" type="image/png" href=""/>
    <!--<title>Condition Monitoring System</title> -->
    <title>{if $headervariable eq 'Temperature' && $smarty.session.CompanyName neq "Subros"}Temperature Monitoring System{elseif $smarty.session.CompanyName eq "Subros"}Power Factor Controller Monitoring{else}Energy Meter Monitoring System{/if}</title>
    
{literal}

 <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <!--<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">-->
   <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Select2 -->
  <link rel="stylesheet" href="plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
  <!-- Tempusdominus Bbootstrap 4 -->
  <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
   <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.css">
   <!-- JQVMap -->
  <link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
 <!-- daterange picker -->
  <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="plugins/summernote/summernote-bs4.css">
    <!-- SweetAlert2 -->
  <link rel="stylesheet" href="plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
  <!-- Toastr -->
  <link rel="stylesheet" href="plugins/toastr/toastr.min.css">
  <!-- Google Font: Source Sans Pro -->
 <!-- <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">--->
 <!-- <link href="dist/css/fontsgoogleapis.css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet"> -->
 
<!-- External Style file-->
 <link rel="stylesheet" href="dist/css/styleems.css">

  <script src="plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Select2 -->
<script src="plugins/select2/js/select2.full.min.js"></script>
<!-- InputMask -->
<script src="plugins/moment/moment.min.js"></script>
<script src="plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>
<!-- date-range-picker -->
<script src="plugins/daterangepicker/daterangepicker.js"></script>
<!-- ChartJS -->
<script src="plugins/chart.js/Chart.min.js"></script>
<!-- Sparkline -->
<script src="plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<script src="plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<!-- jQuery Knob Chart -->
<script src="plugins/jquery-knob/jquery.knob.min.js"></script>
<script src="plugins/datatables/jquery.dataTables.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>

<!-- Tempusdominus Bootstrap 4 -->
<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="plugins/sweetalert2/sweetalert2.min.js"></script>
<!-- Toastr -->
<script src="plugins/toastr/toastr.min.js"></script>
<script src="dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<!--<script src="dist/js/pages/dashboard.js"></script>--->
<script src="dist/js/addcomma.js"></script>
<script src="plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<script>
if ( window.history.replaceState ) {
  window.history.replaceState( null, null, window.location.href );
}
</script>

  <script>
  $(function () {
    $('#example1').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : true,
      'ordering'    : false,
      'info'        : false,
	  'pageLength': 50,
      'autoWidth'   : false
    })
  })
</script>
<style>
.pull-left{
    float: left !important;
}
.pull-right{
    float: right !important;
}
.pull-center{
    float: center !important;
}


span{display:block}
.openmenu li[class=""]{
    height:20px;
    overflow:hidden;
    
}
.menu-open{
    height:auto;
    overflow:visible;
    
}
</style>

	{/literal}
	 </head>
<body class="hold-transition sidebar-mini layout-fixed text-sm">
<div class="wrapper">
      <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
   {if $smarty.session.USER_GROUP neq 'Super Admin' AND $smarty.session.CompanyName eq 'Tecno Doors Pvt Ltd'}
    <a href="dashboard.php" class="brand-link logo-switch">
  <img src="images/CompanyLogo/fermatoSmallLogo.jpg" alt="AdminLTE Docs Logo Small" class="brand-image-xl logo-xs">
  <img src="images/CompanyLogo/{$smarty.session.CompanyLogo}" alt="AdminLTE Docs Logo Large" class="brand-image-xs logo-xl" style="left: 2px">
</a>
{elseif $smarty.session.USER_GROUP neq 'Super Admin'}
<a href="#" class="brand-link logo-switch">
  <img src="images/CompanyLogoSmall/{$smarty.session.CompanyLogoSmall}" alt="AdminLTE Logo Small" class="brand-image-xl logo-xs">
  <img src="images/CompanyLogo/{$smarty.session.CompanyLogo}" alt="AdminLTE Docs Logo Large" class="brand-image-xs logo-xl" style="left: 2px">
</a>
{else}
<a href="#" class="brand-link logo-switch">
  <img src="images/CompanyLogoSmall/{$smarty.session.CompanyLogoSmall}" alt="AdminLTE Logo Small" class="brand-image-xl logo-xs">
  <img src="images/CompanyLogo/{$smarty.session.CompanyLogo}" alt="AdminLTE Docs Logo Large" class="brand-image-xs logo-xl" style="left: 2px">
</a>
{/if}

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <!--<div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="dist/img/user2-160x160.jpg" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="#" class="d-block">Alexander Pierce</a>
        </div>
      </div>-->
      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar nav-legacy nav-compact nav-flat flex-column" data-widget="treeview" role="menu" data-accordion="false">
         {assign var="fooVar" value=$smarty.server.PHP_SELF}
		  {assign var="urlVal" value="/"|explode:$fooVar}
          {foreach from=$MainList item=roles}
          {if $roles.url eq '#' && $urlVal[1] neq 'dashboard.php' && $urlVal[1] neq 'companyDashboard.php' && $urlVal[1] neq 'ac_acDashboard.php' && $urlVal[1] neq 'hvac_acReports.php' && $urlVal[1] neq 'meterDashboard.php' && $urlVal[1] neq 'temperature_temperatureDashboard.php' && $urlVal[1] neq 'DashboardTemperature.php' && $urlVal[1] neq 'subdashboard.php' && $urlVal[1] neq 'dailyReports.php' && $urlVal[1] neq 'shiftWiseReports.php' && $urlVal[1] neq 'logReports.php' && $urlVal[1] neq 'listIncidentLog.php' && $urlVal[1] neq 'customizeReportList.php' && $urlVal[1] neq 'energyConstructionReport.php' && $urlVal[1] neq 'listBilling.php' && $urlVal[1] neq 'temperature_temperatureLog.php' && $urlVal[1] neq 'temperatureDashboard.php'}
          <li class="nav-item has-treeview ">
		  {else}
		  <li class="nav-item has-treeview">
		  {/if}
            
		  {if $roles.url eq $urlVal[1] || $roles.url eq '#' && $urlVal[1] neq 'dashboard.php' && $urlVal[1] neq 'companyDashboard.php' && $urlVal[1] neq 'ac_acDashboard.php' && $urlVal[1] neq 'hvac_acReports.php' && $urlVal[1] neq 'meterDashboard.php' && $urlVal[1] neq 'temperature_temperatureDashboard.php' && $urlVal[1] neq 'DashboardTemperature.php' && $urlVal[1] neq 'subdashboard.php' && $urlVal[1] neq 'dailyReports.php' && $urlVal[1] neq 'shiftWiseReports.php' && $urlVal[1] neq 'logReports.php' && $urlVal[1] neq 'listIncidentLog.php' && $urlVal[1] neq 'customizeReportList.php' && $urlVal[1] neq 'energyConstructionReport.php' && $urlVal[1] neq 'listBilling.php' && $urlVal[1] neq 'temperature_temperatureLog.php' && $urlVal[1] neq 'temperatureDashboard.php'}
            <a href="{$roles.url}" class="nav-link active">
			{else}
			<a href="{$roles.url}" class="nav-link ">
			{/if}
              <i class="nav-icon far {$roles.faIcon}"></i>
              <p>
               {$roles.menuName}
			   {if $roles.url eq '#'}
			   <i class="right fas fa-angle-left"></i>
			   {/if}
              </p>
            </a>
			{if $roles.url eq '#'}
			<ul class="nav nav-treeview">
			{foreach from=$SubList item=roleSub}
						{if $roleSub.parent_id eq $roles.slNo}
              <li class="nav-item">
                   {if $roleSub.url eq $urlVal[1]}
                <a href="{$roleSub.url}" class="nav-link active">
				{assign var="subAct" value=$roleSub.parent_id}
                    {else}
			<a href="{$roleSub.url}" class="nav-link">
			{/if}
                  <i class="nav-icon far {$roleSub.faIcon}"></i>
                  <p>{if $roleSub.menuName eq 'Energy Dashboard' || $roleSub.menuName eq 'Temperature Dashboard' || $roleSub.menuName eq 'AC Dashboard'}Dashboard{else}{$roleSub.menuName}{/if}</p>
                </a>
              </li>
              {/if}
			  {/foreach}
            </ul>
			{/if}
          </li>
          {/foreach}
          
           {if $smarty.session.USER_GROUP eq 'Company Admin' ||  $smarty.session.USER_GROUP eq 'Branch Admin'}
            {assign var="fooVar" value=$smarty.server.PHP_SELF}
		  {assign var="urlVal" value="/"|explode:$fooVar}
		     
		     
		  
		
		
		 {if $urlVal[1] eq 'dailyReports.php' || $urlVal[1] eq 'shiftWiseReports.php' || $urlVal[1] eq 'logReports.php' || $urlVal[1] eq 'listIncidentLog.php' || $urlVal[1] eq 'customizeReportList.php' || $urlVal[1] eq 'energyConstructionReport.php' || $urlVal[1] eq 'listBilling.php' || $urlVal[1] eq 'temperature_temperatureLog.php'}
           <li class="nav-item has-treeview menu-open" > 
           {else}
           <li class="nav-item has-treeview" >
           {/if}
               {if $urlVal[1] eq 'mainEnergyMeter.php' || $urlVal[1] eq 'dailyReports.php' || $urlVal[1] eq 'shiftWiseReports.php' || $urlVal[1] eq 'logReports.php' || $urlVal[1] eq 'listIncidentLog.php' || $urlVal[1] eq 'customizeReportList.php' || $urlVal[1] eq 'energyConstructionReport.php' || $urlVal[1] eq 'temperature_temperatureLog.php'}
               <a href="#" class="nav-link active">
                    <i class="nav-icon far fa fa-list"></i>
              <p>
                Reports<i class="right fas fa-angle-left"></i>
              </p>
            </a>
               {else}
               <a href="#" class="nav-link">
                    <i class="nav-icon far fa fa-list"></i>
              <p>
                Reports<i class="right fas fa-angle-left"></i>
              </p>
            </a>
               {/if}
			   <ul class="nav nav-treeview">
                <li class="nav-item">
               {if $urlVal[1] eq 'mainEnergyMeter.php'}
               <a href="mainEnergyMeter.php" class="nav-link active">
               {else}
               <a href="mainEnergyMeter.php" class="nav-link">
               {/if}
               <i class="nav-icon fa fa-bar-chart"></i>
              <p>
               Main Meter Reports
              </p></a>
                    </li>
                </ul>
            <ul class="nav nav-treeview">
                <li class="nav-item">
               {if $urlVal[1] eq 'energyConstructionReport.php'}
               <a href="energyConstructionReport.php" class="nav-link active">
               {else}
               <a href="energyConstructionReport.php" class="nav-link">
               {/if}
               <i class="nav-icon fa fa-bar-chart"></i>
              <p>
                Energy Consumption Reports
              </p></a>
                    </li>
                </ul>
                <ul class="nav nav-treeview">
                <li class="nav-item">
               {if $urlVal[1] eq 'dailyReports.php'}
               <a href="dailyReports.php" class="nav-link active">
               {else}
               <a href="dailyReports.php" class="nav-link">
               {/if}
               <i class="nav-icon fa fa-bar-chart"></i>
              <p>
                Daily Reports
              </p></a>
                    </li>
                </ul>
				<ul class="nav nav-treeview">
                <li class="nav-item">
               {if $urlVal[1] eq 'dayToDayReport.php'}
               <a href="dayToDayReport.php" class="nav-link active">
               {else}
               <a href="dayToDayReport.php" class="nav-link">
               {/if}
               <i class="nav-icon fa fa-bar-chart"></i>
              <p>
                Monthly Reports
              </p></a>
                    </li>
                </ul>
             <!--   
				<ul class="nav nav-treeview">
                <li class="nav-item">
                    {if  $urlVal[1] eq 'shiftWiseReports.php'}
                    <a href="shiftWiseReports.php" class="nav-link active">
                    {else}
                    <a href="shiftWiseReports.php" class="nav-link">
                    {/if}
                    <i class="nav-icon fa fa-bar-chart"></i>
              <p>
                Shift Wise Reports
              </p></a>
                    </li>
                </ul>-->
<!--              <ul class="nav nav-treeview">
                <li class="nav-item">
               {if $urlVal[1] eq 'customizeReportList.php'}
               <a href="customizeReportList.php" class="nav-link active">
               {else}
               <a href="customizeReportList.php" class="nav-link">
               {/if}
               <i class="nav-icon fa fa-bar-chart"></i>
              <p>
                Customized Reports
              </p></a>
                    </li>
                </ul>-->
                 
            
				<ul class="nav nav-treeview">
                <li class="nav-item">
                    {if $urlVal[1] eq 'logReports.php'}
                    <a href="logReports.php" class="nav-link active">
                    {else}
                    <a href="logReports.php" class="nav-link">
                    {/if}
                    <i class="nav-icon fa fa-bar-chart"></i>
              <p>
                Log Reports
              </p></a>
                    </li>
                </ul>
				<ul class="nav nav-treeview">
                <li class="nav-item">
               {if $urlVal[1] eq 'listIncidentLog.php'}
                <a href="listIncidentLog.php" class="nav-link active">
               {else}
                <a href="listIncidentLog.php" class="nav-link">
               {/if}
               <i class="nav-icon fa fa-bar-chart"></i>
              <p>
                Recent Incidents 
              </p></a>
                    </li>
                </ul>
                
               <!-- <ul class="nav nav-treeview">
                <li class="nav-item">
               {if $urlVal[1] eq 'temperature_temperatureLog.php'}
                <a href="temperature_temperatureLog.php" class="nav-link active">
               {else}
                <a href="temperature_temperatureLog.php" class="nav-link">
               {/if}
               <i class="nav-icon fa fa-bar-chart"></i>
              <p>
               Temperature Log Reports
              </p></a>
                    </li>
                </ul>-->
               <!-- 
				{if $smarty.session.billing_module eq '1'}
				<ul class="nav nav-treeview">
                <li class="nav-item">
               {if $urlVal[1] eq 'listBilling.php'}
                <a href="listBilling.php" class="nav-link active">
               {else}
                <a href="listBilling.php" class="nav-link">
               {/if}
               <i class="nav-icon fa fa-bar-chart"></i>
              <p>
                List Billing 
              </p></a>
                    </li>
              </ul>
			  {/if} -->
          </li>
       
           {/if}
          <!--<li class="nav-item">
            <a href="feederList.php" class="nav-link">
              <i class="nav-icon far fa fa-lightbulb"></i>
              <p>
                List Sensor
              </p>
            </a>
          </li>-->
         <!-- <li class="nav-item">
            <a href="userRoleList.php" class="nav-link">
              <i class="nav-icon far fa fa-user-md"></i>
              <p>
                User Role
              </p>
            </a>
          </li>
          
          <li class="nav-item">
            <a href="userList.php" class="nav-link">
              <i class="nav-icon far fa fa-user"></i>
              <p>
                User
              </p>
            </a>
          </li>
          
          <li class="nav-item">
            <a href="companyList.php" class="nav-link">
              <i class="nav-icon far fa fa-building"></i>
              <p>
                Company
              </p>
            </a>
          </li>-->
  
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>
        

{include file="header.tpl"}
