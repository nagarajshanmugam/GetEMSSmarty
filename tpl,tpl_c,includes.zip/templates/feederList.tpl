	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">List Energy Meter</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			</div>
		</div>
		<form name="meterList" method="post" id="meterList">
		<div class="row">
			<div class="col-12">
				<div class="card">
				{if $SuccessMessage neq "" || $ErrorMessage neq ""}
					<div class="card-body">
					{if $SuccessMessage neq ""}
						<div class="isa_success">
						<i class="fa fa-check"></i>
						{$SuccessMessage}		 
						</div>
					{/if}
					{if $ErrorMessage neq ""}
						<div class="isa_error">
						<i class="fa fa-check"></i>
						{$ErrorMessage}		 
						</div>
					{/if}
					</div>
				{/if}
				<div class="card-body table-responsive">{if $smarty.session.COMPANY_ID neq '4' && $smarty.session.USER_GROUP neq "Branch Admin" || $smarty.session.USER_GROUP neq "Branch Admin" }<a href="feederAddEdit.php?companyId={$smarty.get.companyId}&branchId={$smarty.get.branchId}"><button type="button" style="float:right;margin-top:-6PX" class="btn btn-info"> Create Energy Meter</button></a>
				<span style="float:right;">&ensp;</span>
				<a href="feederTree.php?companyId={$smarty.get.companyId}&branchId={$smarty.get.branchId}"><button type="button" style="float:right;margin-top:-6PX" class="btn btn-primary"> Mimic SLD</button></a><span style="float:right;">&ensp;</span>
				{/if}
				{if $smarty.session.USER_GROUP eq "Super Admin"}<a href="gatewayList.php?companyId={$smarty.get.companyId}&branchId={$smarty.get.branchId}"><button type="button" style="float:right;margin-top:-6PX" class="btn btn-primary"> List Gateway</button></a><span style="float:right;">&ensp;</span>{/if}
				{if $smarty.session.USER_GROUP eq "Super Admin" || $smarty.session.USER_GROUP eq "Company Admin"}<a href="branchList.php?companyId={$smarty.get.companyId}"><button type="button" style="float:right;margin-top:-6PX" class="btn btn-primary"> List Branch</button></a>{/if}
				{if $ListFeedForm.0.feeder_master_id eq ""}&ensp;<br />{/if}
				<table id="example" class="table table-bordered table-hover">
				<thead>
				<tr>
				<th class="slNo">#</th>
				<th class="name">Energy Meter Name / Installation Place</th>
				<th class="slNo">Meter Id</th>
				{if $smarty.session.COMPANY_ID neq '4'} <th class="type">Energy Meter Type</th>{/if}
				<!--<th class="name">Sensor Name</th>-->
				{if $smarty.session.COMPANY_ID neq '4'} <th class="code">Unit Rate</th>{/if}
				<th class="isactive">Status</th>
				<th class="action">Action</th>
				</tr>
				</thead>
				<tbody>
				{foreach from=$ListFeedForm item=List}
    				<tr id="{$j++}">
    				<td >{$j}</td>
    				<td>{$List.sensorName}</td>
					<td align="right">{$List.modbus_slave_id}</td>
    			{if $smarty.session.COMPANY_ID neq '4'} <td>{$List.feeder_type}</td>{/if}
    			<!--	<td>{$List.sensor_name}</td>-->
    			{if $smarty.session.COMPANY_ID neq '4'} <td align="right">{$List.unit_rate}</td>{/if}
    				<td align="center">{if $List.isActive eq "1"}<span style="color:#009900"><b>Active</b></span>{else}<span style="color:#FF0000;"><b>Inactive</b></span>{/if}</td>
    				<td align="right">
    				{if $List.sensorModel neq "TE" } <a href="#"  onClick="Javascript:alertCats('{$List.slNo}','{$List.sensorCode}','{$List.company_id}','{$List.branch_id}','{$List.gateway_id}','Update=Y')" title="Alert Parameter"><i class="fa fa-window-restore"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{/if}
    		
    			{if $smarty.session.COMPANY_ID neq '4'}<a href="meterDashboard.php?companyId={$List.company_id|base64_encode}&branchId={$List.branch_id|base64_encode}&sensorCode={$List.sensorCode|base64_encode}&gatewayCode={$List.gateway_id|base64_encode}"   title="Meter Dasboard"><i class="fa fa-cloud"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    			{/if}
    				<a href="#"  onClick="Javascript:editCats('{$List.slNo}','{$List.sensorCode}','{$List.company_id}','{$List.branch_id}','{$List.gateway_id}','Update=Y')" title="Edit"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    				</td>
    				</tr>
    			{foreachelse}
    				<tr><td colspan="6"><center>No Records Found</center></td></tr>
				{/foreach}
				</tbody>
				</table>
				</div>
				</div>
			</div>
		</form>
	</section>
	</div>
	{literal}
	<style>
	.slNo{
	width:5%;
	}
	.code{
	width:10%;
	}
	.type{
	width:15%;
	}
	.name{
	width:20%;
	}
	.isactive{
	width:10%;
	text-align:center;
	}
	.action{
	text-align:right;
	width:15%;
	}
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>
	<script type="text/javascript">
	$(document).ready(function (){
	
	var table = $('#example').DataTable({
	"ordering" : false,
	language: {
	"infoFiltered": "",
	search: "_INPUT_",
	searchPlaceholder: "Search..."
	},
	dom: '<"pull-left" f><bottom>p',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: '<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p',
	//dom: '<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p',
	
	initComplete: function(){
	//$("div.toolbar").html('<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>');   	
	}       
	}); 
	}); 
	
	function unitPriceCats(slNoIdent,metIdIdent,compIdent,locIdIdent) {
		var sid = btoa(slNoIdent); var mid = btoa(metIdIdent); var comId = btoa(compIdent); var lId = btoa(locIdIdent);
		FormName		= document.meterList;
		FormName.action ='unitPriceList.php?sl_no='+sid+'&companyId='+comId+'&location_id='+lId+'&meter_id='+mid;
		FormName.submit();
	}
	function editCats(slNoIdent,metIdIdent,compIdent,branIdent,gateIdent,Update) {
		var sid = btoa(slNoIdent); var mid = btoa(metIdIdent);  var comId = btoa(compIdent); var gId = btoa(gateIdent);var bId = btoa(branIdent);
		FormName		= document.meterList;
		FormName.action ='feederAddEdit.php?sl_no='+sid+'&sensor_id='+mid+'&companyId='+comId+'&gatewayId='+gId+'&branchId='+bId+'&Update=y';
		FormName.submit();
	}
	function alertCats(slNoIdent,metIdIdent,compIdent,branIdent,gateIdent,Update) {
		var sid = btoa(slNoIdent); var mid = btoa(metIdIdent);  var comId = btoa(compIdent); var gId = btoa(gateIdent);var bId = btoa(branIdent);
		FormName		= document.meterList;
		FormName.action ='feederAlertParameter.php?sl_no='+sid+'&sensor_id='+mid+'&companyId='+comId+'&gatewayId='+gId+'&branchId='+bId+'&Update=y';
		FormName.submit();
	}
	</script>
	<script type="text/javascript">
	function deleteCats(slNoIdent,serialIdIdent,compIdent,branIdent,gateIdent){
		var sid = btoa(slNoIdent); var scId = btoa(serialIdIdent);var comId = btoa(compIdent); var gId = btoa(gateIdent);var bId = btoa(branIdent);
		if(confirm("Are you sure to Delete this Content?")){
		FormName		= document.meterList;
		FormName.action= 'sensorList.php?gatewayId='+gId+'&companyId='+comId+'&branchId='+bId+'&sl_no='+sid+'&sen_code='+scId;
		FormName.submit();
		}
	}
	</script>
	{/literal}
	{include file="footer.tpl"}