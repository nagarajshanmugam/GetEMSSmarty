    <div class="content-wrapper">
	<section class="content-header">
	  <div class="card">
		 <div class="card-header">
			<table style="margin-bottom:-10px;">
			<tr><td style="font-size:15PX;font-weight: bold;">List Company</font>&nbsp;</td></tr>
			<tr><td style="color:#999999;font-size:10PX;">&nbsp;</td><td>&nbsp;</td></tr>
			</table>
		 </div>
	  </div>
		<div class="row">
			<div class="col-12">
				<div class="card">
				{if $SuccessMessage neq ""}
					<div class="card-body">
					<div class="isa_success">
					<i class="fa fa-check"></i>
					{$SuccessMessage}		 
					</div>
					</div>
				{/if}
				{if $ErrorMessage neq ""}
					<div class="card-body">
					<div class="isa_error">
					<i class="fa fa-check"></i>
					{$ErrorMessage}		 
					</div>
					</div>
				{/if}
					<div class="card-body table-responsive">
					<a href="AddEditcompany.php"> <button type="button" class="btn btn-create" value="Create Userrole" style="float:right;margin-top:-6PX">Create Company</button></a>
						<form name="companyList" id="companyList" method="post">
							<table id="example" class="table table-hover table-bordered">
							<thead>
							<tr>
							<th class="slno">#</th>
							<th>Company Code</th>
							<th>Company Name</th>
							<th>Contact Person</th>
							<th>Phone</th>
							<th>User</th>
							<th>SMS</th>
							<th>Status</th>
							<th>Action</th>
							</tr>
							</thead>
							<tbody>
							{foreach from=$ListView item=master_dtls}
							<tr id="{$i++}">
							<td class="slNo">{$i}</td>
							<td class="code">{$master_dtls.companyCode}</td>
							<td class="name">{$master_dtls.companyName}</td>
							<td class="text_left">{$master_dtls.contactPerson}</td>
							<td class="phone">{if $master_dtls.phone neq ""}{$master_dtls.phone}{else}<center>-</center>{/if}</td>
							<td class="limit">{$master_dtls.userLimit}</td>
							<td class="limit">{$master_dtls.smsLimit}</td>
							<td class="isactive">{if $master_dtls.isActive eq "1"}<span style="color:#009900"><b>Active</b></span>{else}<span style="color:#FF0033;"><b>Inactive</b></span>{/if}</td>
							<td class="amount">
							<a href="companyDashboard.php?companyId={$master_dtls.slNo|base64_encode}"  title="Visit {$master_dtls.companyName} Dashboard" target="_blank"><i class="fa fa-cloud"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
							<a href="userList.php?companyId={$master_dtls.slNo|base64_encode}" title="List User"><i class="fa fa-user"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
							<a href="#" onClick="Javascript:branchCats('{$master_dtls.slNo}')" title="List Branch"><i class="fas fa-code-branch"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
							<a href="#" onclick="Javascript:editCats('{$master_dtls.slNo}')" title="Edit"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
							<a href="#" onClick="Javascript:deleteCats('{$master_dtls.slNo}')" title="Delete"><i class="fa fa-trash"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;		     
							</td>
							</tr>
							{foreachelse}
							<tr><td colspan="10"><center>No Records Found</center></td></tr>
							{/foreach}
							</tbody>
							</table>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
    </div>
	{literal}
		<script type="text/javascript">
		$(document).ready(function (){
		
		var table = $('#example').DataTable({
		"ordering" : false,
		language: {
		"infoFiltered": "",
		search: "_INPUT_",
		searchPlaceholder: "Search..."
		},
		dom: '<"pull-left" f><bottom>p',
		tableTools: {
		"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
		},
		//dom: '<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p',
		//dom: '<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p',
		buttons: [
		{
		text: 'Create Box',
		className: 'btn btn-create',
		titleAttr: 'Create Box',
		action: function ( e, dt, button, config ) {
		window.location = 'AddEditBox.php';
		}        
		}
		],
		initComplete: function(){
		$("div.toolbar").html('<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>');   
		
		
		}       
		}); 
		
		}); 
		
		function branchCats(compIdent) {
		var comId = btoa(compIdent);
		FormName		= document.companyList;
		FormName.action ='branchList.php?companyId='+comId;
		FormName.submit();
		}
		function editCats(slNoIdent) {
		var sid = btoa(slNoIdent);
		FormName		= document.companyList;
		FormName.action ='AddEditcompany.php?companyId='+sid+'&Update=y';
		FormName.submit();
		}
		function deleteCats(CatIdent){
		if(confirm("Are you sure to Delete this Content?")){
		FormName		= document.companyList;
		FormName.action= "companyList.php?cId="+CatIdent;
		FormName.submit();
		}
		}
		</script>
		<script>
		$(function () {
		$("#example1").DataTable();
		$('#example2').DataTable({
		"paging": true,
		"lengthChange": false,
		"searching": false,
		"ordering": true,
		"info": true,
		"autoWidth": false,
		});
		});
		</script>
		<style>
		.slNo{
		width:5%;
		}
		.code{
		width:10%;
		}
		.name{
		width:20%;
		}
		.limit{
		width:5%;
		}
		.phone{
		width:10%;
		}
		.isactive{
		width:10%;
		text-align:center;
		
		}
		.action{
		text-align:right;
		}
		
		.isa_success
		{
		color:#4F8A10;
		background-color:#DFF2BF;
		}
		.error
		{
		color:#D8000C;
		/*background-color:#FFBABA;*/
		}
		.isa_error
		{
		color:#D8000C;
		background-color:#FFBABA;
		}
		.isa_success i,.isa_error i
		{
		margin:10px 22px;
		font-size:2em;
		/*vertical-align:middle;*/
		}
		
		</style>
	{/literal}
	{include file="footer.tpl"}