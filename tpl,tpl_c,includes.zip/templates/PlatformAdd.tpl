	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">{if $smarty.get.gateway_id eq ""}Assign IoT Platform{else}Edit IoT Platform{/if}</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:10PX;color:#999999;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			<a href="branchList.php?companyId={$smarty.get.companyId}"><button type="button" style="float:right;;margin-top:-40PX" class="btn btn-primary">List Branch</button></a>
			<a href="platformList.php"><button type="button" style="float:right;;margin-top:-40PX" class="btn btn-primary">List IoT Platform</button></a>
			</div>
		</div>
		<div class="card">
			<div class="card-body">
				<form role="form" name="gatewayRegForm" id="gatewayRegForm" method="post" onsubmit="return createValidation();" >
					<input type="hidden" name="hdAction" />
					<input type="hidden" id="check_id" name="check_id" value="{$smarty.post.check_id}">
					<input type="hidden" id="checkVal" name="checkVal" value="{$smarty.post.checkVal}" />
					<input type="hidden" id="company_id" name="company_id" value="{$smarty.get.companyId|base64_decode}" />
					<input type="hidden" id="branch_id" name="branch_id" value="{$smarty.get.branchId|base64_decode}" />
					<input type="hidden" id="platId" name="platId" value="{$ListEditView.0.slNo}" />
					<input type="hidden" id="item_id" name="item_id" value="{$smarty.post.item_id}" />
					<input id="created_by" name="created_by" class="date-picker form-control" type="hidden" value="{$smarty.session.UserName}" readonly="true">
				    <input type="hidden" class="form-control" id="timestamp" name="timestamp" value="{$smarty.now|date_format:'%Y-%m-%d &amp; %I:%M:%S %p'}">
				    <input type="hidden" class="form-control" id="created_time" name="created_time" placeholder="Time" Value="{$smarty.now|date_format:'%I:%M:%S %p'}">
				<div class="row">
				{foreach from=$PlatformList item=ListEditView}
					<div class="form-group col-md-4">
						<div class="custom-control custom-checkbox">
						<input class="" type="checkbox" id="customCheckbox2" name="customCheckbox2[]" value="{$ListEditView.slNo}" tabindex="7" checked="checked">&nbsp;&nbsp;
						<label for="" class="">{$ListEditView.segmentName}</label>
						</div>
					</div>
				{/foreach}
				{foreach from=$APlatformList item=ListEditView}
					<div class="form-group col-md-4">
						<div class="custom-control custom-checkbox">
						<input class="" type="checkbox" id="customCheckbox2" name="customCheckbox2[]" value="{$ListEditView.slNo}" tabindex="7">&nbsp;&nbsp;
						<label for="" class="">{$ListEditView.segmentName}</label>
						</div>
					</div>
				{/foreach}
				<br />
				<br />
				<br />
				</div>
					<div align="center">
					<input type="submit" value="Submit" class="btn btn-create" tabindex="8" />
					</div>
				</form>
			</div>
		</div>
	</div>
	</section>
	</div>
	{literal}
	<script type="text/javascript">
	function createValidation()
	{
		var segmentCode = $('#segmentCode').val();
		var segmentName = $('#segmentName').val();
		var isActive = document.getElementById("customCheckbox2").checked;
		var bar_code = [];
	$.each($("input[name='customCheckbox2']:checked"), function()
	{ 
		bar_code.push($(this).val());  
	});
		id=bar_code.join("','");
		document.getElementById("item_id").value = id;
	if (isActive == false) 
	{
		document.getElementById('checkVal').value='0';
	}
	else
	{
		document.getElementById('checkVal').value='1';
	}
	$(".error").remove();
	if (segmentCode.length < 1) {
		$('#segmentCode').after('<span class="error">This field is required</span>');
		$('#segmentCode').focus();
		return false;					
	}
	else if (segmentName < 1) {
		$('#segmentName').after('<span class="error">This field is required</span>');
		$('#segmentName').focus();
		return false;					
	}
		FormName		= document.gatewayRegForm;
		FormName.method	= "POST";
		FormName.submit();
	}
	function GoBack()
	{
		window.history.back();
	}
	</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	{/literal}
	{include file="footer.tpl"}