	{literal}
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<!-- Resources -->
	
	<style type="text/css">
	.thal
	{
	text-align:left;
	}
	.thar
	{
	text-align:right;
	}
	.bclass
	{
	font:Geneva, Arial, Helvetica, sans-serif;
	font-size:14px;
	font-weight:600;
	}
	
	</style>
	<!-- Styles -->
	
	<!----     Line Chart         ------------->
	
	
	<!----       AmChart Bar Chart       ---------->
	
	
	<!--<script src="https://www.amcharts.com/lib/3/gauge.js"></script>
	<script src="https://www.amcharts.com/lib/3/plugins/export/export.min.js"></script>
	<link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
	-->
	
	
	
	
	{/literal}
	<div class="content-wrapper ">
	<div class="content-header">
	<div class="container-fluid ">
	<div class="row"> <div class="col-md-12">
	<div class="card">
	<div class="card-body">
	
	<table style="margin-bottom:-10px;">
	<tr><td style="font-size:15PX;font-weight: bold;">Electric Vehicle Meter Monitoring&nbsp;&nbsp;</td>
	<!--<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
	<td style="font-size:15PX;font-weight: bold;">{$LoctList.0.branch_name}&ensp;&ensp;</td>
	<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
	<td style="font-size:15PX;font-weight: bold;">{$LoctList.0.sensorName} <!---({$LoctList.0.gateway_id} / {$LoctList.0.sensorCode})</font>&nbsp;</td>--></tr>
	
	
	<tr><td style="font-size:10PX;color:#999999;"></td>
	<td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
	<td style="font-size:10PX;color:#999999;"></td>
	<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
	<td style="color:#999999;font-size:10PX;"> </td><td>&nbsp;</td>
	</tr>
	
	</table>
	<input type="hidden" id="gatewayCode" value="{$smarty.get.gatewayCode}" />
	<input type="hidden" id="sensorCode" value="{$smarty.get.sensorCode}" />
	
	<div  style="margin-top:-40PX;float:right" class="col-md-3"  >
	<h3 style="font-size:15PX;font-weight: bold;"> Technical Support By Illayaraja</h3>
	</div>        
	
	</div>
	</div>
	</div>
	
	<!--<div class="col-md-12 >
	
	<div class="info-box">
	<div class="info-box-content">
	<span class="pull-left text-info"><h5><b>{$LoctList.0.companyName}&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp; {$LoctList.0.branch_name}&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp; {$LoctList.0.gateway_id}&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;{$LoctList.0.sensorName}</b></h5></span>
	</div>
	</div>
	</div>-->
	</div>
	<div class="row">
	<div class="col-md-4">
	<!-- Widget: user widget style 2 -->
	<div class="card card-widget widget-user-2">
	<!-- Add the bg color to the header using any of the bg-* classes -->
	<div class="widget-user-header info-box ">
	<div class="widget-user-image">
	
	<!--<img class="img-circle elevation-2" src="../dist/img/user7-128x128.jpg" alt="User Avatar">-->
	</div>
	<!-- /.widget-user-image -->
	<h5 class="widget-user-text  text-bold">Charging </h5></center>
	<center><span class="info-box-icon"><img src="./images/batteryCharging.png" ></span></center>
	</div>
	<div class="card-footer p-0">
	<ul class="nav flex-column">
	<li class="nav-item">
	<a href="#" class="nav-link">
	Kwh <span class="float-right badge bg-green">{$evDatList.0.kwh_ch1}</span>
	</a>
	</li>
	<li class="nav-item">
	<a href="#" class="nav-link">
	Amps <span class="float-right badge bg-green">{$evDatList.0.amps_ch1}</span>
	</a>
	</li>
	<li class="nav-item">
	<a href="#" class="nav-link">
	Last Updated Date Time <span class="float-right badge bg-green">{$evDatList.0.recorded_date_time|date_format:"%e-%b-%y %I:%M %p"}</span>
	</a>
	</li>
	
	</ul>
	</div>
	</div>
	<!-- /.widget-user -->
	</div>
	<div class="col-md-4">
	<!-- Widget: user widget style 2 -->
	<div class="card card-widget widget-user-2">
	<!-- Add the bg color to the header using any of the bg-* classes -->
	<div class="widget-user-header info-box ">
	<div class="widget-user-image">
	
	<!--<img class="img-circle elevation-2" src="../dist/img/user7-128x128.jpg" alt="User Avatar">-->
	</div>
	<!-- /.widget-user-image -->
	<h5 class="widget-user-text  text-bold">Discharging </h5></center>
	<center><span class="info-box-icon"><img src="./images/batteryDischarging.png" ></span></center>
	</div>
	<div class="card-footer p-0">
	<ul class="nav flex-column">
	<li class="nav-item">
	<a href="#" class="nav-link">
	Kwh <span class="float-right badge bg-danger">{$evDatList.0.kwh_ch2}</span>
	</a>
	</li>
	<li class="nav-item">
	<a href="#" class="nav-link">
	Amps <span class="float-right badge bg-danger">{$evDatList.0.amps_ch2}</span>
	</a>
	</li>
	<li class="nav-item">
	<a href="#" class="nav-link">
	Last Updated Date Time <span class="float-right badge bg-danger">{$evDatList.0.recorded_date_time|date_format:"%e-%b-%y %I:%M %p"}</span>
	</a>
	</li>
	
	</ul>
	</div>
	</div>
	<!-- /.widget-user -->
	</div>
	</div>
	<!-- /.row -->
	
	<div class="row">
	<div class="col-md-12">
	<div class="card card-primary card-tabs">
	<div class="card-header p-0 pt-1 border-bottom-0">
	
	<ul class="nav nav-tabs" id="custom-content-below-tab" role="tablist">
	<li class="nav-item">
	<a class="nav-link active" id="custom-content-below-voltage-tab" data-toggle="pill" href="#tab-1" role="tab" aria-controls="custom-content-below-voltage" aria-selected="true">Voltage Trend</a>
	</li>
	<li class="nav-item">
	<a class="nav-link " id="custom-content-below-profile-tab" data-toggle="pill" href="#tab-2" role="tab" aria-controls="custom-content-below-profile" aria-selected="true">Charging Trend</a>
	</li>
	<li class="nav-item">
	<a class="nav-link " id="custom-content-below-home-tab" data-toggle="pill" href="#tab-3" role="tab" aria-controls="custom-content-below-home" aria-selected="false">Discharging Trend</a>
	</li> <!---->
	<!--<li class="nav-item">
	<a class="nav-link " id="custom-content-below-home-tab" data-toggle="pill" href="#tab-2" role="tab" aria-controls="custom-content-below-home" aria-selected="false">Meter View</a>
	</li>-->
	
	<li class="nav-item">
	<a class="nav-link" id="custom-content-below-messages-tab" data-toggle="pill" href="#tab-4" role="tab" aria-controls="custom-content-below-messages" aria-selected="false">Log Report</a>
	</li>
	
	<!--   <li class="nav-item">
	<a class="nav-link" id="custom-content-below-messages-tab" data-toggle="pill" href="#tab-4" role="tab" aria-controls="custom-content-below-messages" aria-selected="false">Daily Report</a>
	</li>
	-->
	</ul>
	</div>
	
	
	
	
	<div class="tab-content" >
			<div id="tab-1" class="tab-pane active">
			<!--<div class="loader"></div>-->
				<iframe  height="820px" width="98%" src="./evVoltageTrendGraph.php?gatewayCode=TRB145-3&sensorCode=EVDC-1" style="border:1px;"></iframe> 
				<!--<iframe id="chargingTrendGraph" height="820px" width="98%" src="" style="border:1px;"></iframe>-->
			</div>
			<div id="tab-2" class="tab-pane active">
			<!--<div class="loader"></div>-->
				<iframe  height="820px" width="98%" src="./chargingTrendGraph.php?gatewayCode=TRB145-3&sensorCode=EVDC-1" style="border:1px;"></iframe> 
				<!--<iframe id="chargingTrendGraph" height="820px" width="98%" src="" style="border:1px;"></iframe>-->
			</div>
			<div id="tab-3" class="tab-pane ">
												<iframe  height="820px" width="98%" src="./dischargingTrendGraph.php?gatewayCode=TRB145-3&sensorCode=EVDC-1" style="border:1px;"></iframe> 
	
				<!--<iframe id="disChargingTrendGraph" height="820px" width="98%" src="" style="border:1px;"></iframe>-->
			</div><!---->
		<!--	<div id="tab-2" class="tab-pane ">
				<iframe height="820px" width="98%"   src="./onlineTrendGraph.php?gatewayCode={$smarty.get.gatewayCode}&sensorCode={$smarty.get.sensorCode}" style="border:1px;"></iframe>
			</div>-->
		
		<!--<div id="tab-3" class="tab-pane">
			<div class="loader" style="background-color:#999999"></div>
			
			<iframe id="log_report" height="820px" width="98%" src="" style="border:1px;"></iframe>
			</div>-->
			<div id="tab-4" class="tab-pane">
			<!--<div class="loader" style="background-color:#999999"></div>-->
			
			<iframe  height="820px" width="98%" src="./evLogReport.php?gatewayCode=TRB145-3&sensorCode=EVDC-1" style="border:1px;"></iframe>
			</div>
			<div id="tab-4" class="tab-pane" >
			<div class="loader"></div>
			
			<iframe id="daily_report" height="820px" width="98%" src="" style="border:1px;"></iframe>
			</div>
			
		</div>
	</div>
	</div>
	
	</div>
	</div>
	</div>
	</div>
	{literal}
	<script>
	var gId="TRB145-3";
	var sId="EVDC-1";
	var pageURL = $(location).attr("href");
	// alert($(location).attr('hostname'));
	window.onload = function(){
	// alert(gId);
	//  document.getElementById('chargingTrendGraph').src = './chargingTrendGraph.php?gatewayCode='+gId+'&sensorCode='+sId;
	// document.getElementById('disChargingTrendGraph').src = './dischargingTrendGraph.php?gatewayCode='+gId+'&sensorCode='+sId;
	/*   document.getElementById('daily_report').src = './energyMeterDailyReport.php?gatewayCode='+gId+'&sensorCode='+sId;
	setTimeout(function(){ $(".loader").hide();},2000);*/
	
	
	};
	</script>
	
	<script type="text/javascript">
	/*$(document).ready(function(){
	setTimeout(function(){  
	$("#loadDate").show();
	}, 1000);
	
	});*/
	var gId=$("#gatewayCode").val();
	var sId=$("#sensorCode").val();
	var pageURL = $(location).attr("href");
	//          alert($(location).attr('hostname'));
	
	
	window.onload = function(){
	setTimeout(function(){
	// alert(gId);
	document.getElementById('trendGraph').src = './trendsGraph.php?gatewayCode='+gId+'&sensorCode='+sId;
	document.getElementById('log_report').src = './icd_log_report.php?gatewayCode='+gId+'&sensorCode='+sId;
	document.getElementById('daily_report').src = './energyMeterDailyReport.php?gatewayCode='+gId+'&sensorCode='+sId;
	setTimeout(function(){ $(".loader").hide();},2000);
	
	},2000);
	};
	/*$(document).ready(function() {
	$("#ttt").delay(1000).fadeIn(1000);
	});*/
	function postFeeder()
	{
	var feederName=document.getElementById("feederPost").value;
	var feedSplit= feederName.split("/");
	var senCod=feedSplit[1];
	var gatCod=feedSplit[2];
	var comId=feedSplit[3];
	var branId=feedSplit[4];
	FormName		= document.dashboard;
	FormName.action= "meterDashboard.php?companyId="+comId+"&branchId="+branId+"&sensorCode="+senCod+"&gatewayCode="+gatCod;
	FormName.submit();
	
	}
	</script>
	
	{/literal}
	{include file="footer.tpl"}