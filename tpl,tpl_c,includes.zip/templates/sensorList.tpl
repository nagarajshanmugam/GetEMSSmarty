	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{if $branchDetail.0.branch_name neq ""}
					<td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>{/if}
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">List Sensor</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			</div>
		</div>
		<form name="meterList" method="post" id="meterList">
		<div class="row">
			<div class="col-12">
				<div class="card">
				{if $SuccessMessage neq "" || $ErrorMessage neq ""}
					<div class="card-body">
					{if $SuccessMessage neq ""}
						<div class="isa_success">
						<i class="fa fa-check"></i>
						{$SuccessMessage}		 
						</div>
					{/if}
					{if $ErrorMessage neq ""}
						<div class="isa_error">
						<i class="fa fa-check"></i>
						{$ErrorMessage}		 
						</div>
					{/if}
					</div>
				{/if}
					<div class="card-body table-responsive">
					<a href="sensorMasterAddEdit.php?companyId={$smarty.get.companyId}&gatewayId={$smarty.get.gatewayId}&branchId={$smarty.get.branchId}"><button type="button" style="float:right;margin-top:-6PX" class="btn btn-create">Create Sensor</button></a><span style="float:right;">&ensp;</span>
					<a href="gatewayList.php?companyId={$smarty.get.companyId}&branchId={$smarty.get.branchId}"><button type="button" style="float:right;margin-top:-6PX" class="btn btn-primary"> List Gateway</button></a>{if $smarty.session.USER_GROUP eq "Super Admin"}<span style="float:right;">&ensp;</span>
					<a href="branchList.php?companyId={$smarty.get.companyId}"><button type="button" style="float:right;margin-top:-6PX" class="btn btn-primary"> List Branch</button></a>{/if}
					{if $ListSensorView.0.slNo eq ""}&ensp;<br /><br />{/if}
						<table id="example" class="table table-bordered table-hover">
						<thead>
						<tr>
						<th class="slno">#</th>
					<!--	<th class="code">Sensor Code</th>-->
					    <th class="name">Sensor Model</th>
						<th class="name">Sensor Name</th>
						<th class="name">ID</th>
						<th class="json">Data to server JSON Format</th>
						<th class="apiKey">URL</th>
						<th class="isactive">Status</th>
						<th class="action">Action</th>
						</tr>
						</thead>
						<tbody>
						{foreach from=$ListSensorView item=List}
						{assign var=tot value={"ID":"%i","apiKey":"}
						{assign var=tot4 value='"'}
						{assign var=tot1 value=$List.api_key}
						{assign var=tot2 value=" ,"ST":"%s","TS":"%t","DT":"%d","VR":"%a"}
						{assign var=tot3 value='"'}
						{assign var=all value=$tot''$tot1''$tot2''$tot3}
						<tr id="{$j++}">
						<td >{$j}</td>
					<!--	<td>{$List.sensorCode}</td>-->
					    <td>{$List.model_name}</td>
						<td>{$List.sensorName}</td>
						<td>{$List.modbus_slave_id}</td>
						<td><span id="apik{$j}" style="display:none;">{$tot}{$tot4}{$tot1}{$tot2}{$tot3}}</span>{$all|truncate:30:"...":true}&nbsp;&nbsp;<a href="#" onclick="Javascript:copy_password('apik{$j}')" title="Copy to clipboard"><i class="fas fa-clipboard" ></i></a></td>
						<td><span id="apiu{$j}" style="display:none;">{$List.api_url}</span>{$List.api_url|truncate:30:"...":true}&nbsp;&nbsp;<a href="#" onclick="Javascript:copy_password('apiu{$j}')" title="Copy to clipboard"><i class="fas fa-clipboard"></i></a></td>
						<td align="center">{if $List.isActive eq "1"}<span style="color:#009900"><b>Active</b></span>{else}<span style="color:#FF0000;"><b>Inactive</b></span>{/if}</td>
						<td align="right">
						{if $List.sensorModel neq "TE" } <a href="#"  onClick="Javascript:alertCats('{$List.slNo}','{$List.sensorCode}','{$List.company_id}','{$List.branch_id}','{$List.gateway_id}','Update=Y')" title="Alert Parameter"><i class="fa fa-window-restore"></i></a>&nbsp;&nbsp;&nbsp;{/if}
						<a href="#"  onClick="Javascript:editFeederCats('{$List.slNo}','{$List.sensorCode}','{$List.company_id}','{$List.branch_id}','{$List.gateway_id}','Update=Y')" title="Sensor Feeder Update"><i class="fa fa-share"></i></a>&nbsp;&nbsp;&nbsp;
						{if $List.sensorModel eq "RGA20S"}<a href="capacityList.php?slNo={$List.slNo|base64_encode}&sensorCode={$List.sensorCode|base64_encode}&companyId={$List.company_id|base64_encode}&branchId={$List.branch_id|base64_encode}&gatewayId={$List.gateway_id|base64_encode}"  title="List Capacitor Value"><i class="fa fa-list"></i></a>&nbsp;&nbsp;&nbsp;{/if}
						{foreach from=$IconList item=icon}
						{if $icon.menuName eq "Add Alert Contact"}<a href="addAlertContact.php?slNo={$List.slNo|base64_encode}&sensorCode={$List.sensorCode|base64_encode}&companyId={$List.company_id|base64_encode}&branchId={$List.branch_id|base64_encode}&gatewayId={$List.gateway_id|base64_encode}"  title="Add Alert Contact"><i class="{$icon.faIcon}"></i></a>&nbsp;&nbsp;&nbsp;{/if}
						
						{if $icon.menuName eq "Edit Sensor"}<a href="#"  onClick="Javascript:editCats('{$List.slNo}','{$List.sensorCode}','{$List.company_id}','{$List.branch_id}','{$List.gateway_id}','Update=Y')" title="Edit"><i class="{$icon.faIcon}"></i></a>&nbsp;&nbsp;&nbsp;{/if}
						{if $icon.menuName eq "Delete Sensor"}<a href="#"  onClick="Javascript:deleteCats('{$List.slNo}','{$List.sensorCode}','{$List.company_id}','{$List.branch_id}','{$List.gateway_id}')" title="Delete"><i class="fa fa-trash"></i></a>&nbsp;&nbsp;&nbsp;{/if}
						{/foreach}
						</td>
						</tr>
						{foreachelse}
						<tr><td colspan="7"><center>No Records Found</center></td></tr>
						{/foreach}
						</tbody>
						</table>
					</div>
				</div>
			</div>
		</form>
	</section>
	</div>
	{literal}
	<style>
	.slno{
	width:5%;
	}
	.code{
	width:10%;
	}
	.apiKey{
	width:15%;
	}
	.name{
	width:10%;
	}
	.json{
	width:15%;
	}
	.isactive{
	width:10%;
	text-align:center;
	}
	.action{
	text-align:right;
	width:10%;
	}
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>
	<script type="text/javascript">
	$(document).ready(function (){
	
	var table = $('#example').DataTable({
	"ordering" : false,
	language: {
	"infoFiltered": "",
	search: "_INPUT_",
	searchPlaceholder: "Search..."
	},
	dom: '<"pull-left" f><bottom>p',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: '<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p',
	//dom: '<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p',
	
	initComplete: function(){
	//$("div.toolbar").html('<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>');   
	}       
	}); 
	}); 
	
	function unitPriceCats(slNoIdent,metIdIdent,compIdent,locIdIdent) 
	{
		var sid = btoa(slNoIdent); var mid = btoa(metIdIdent); var comId = btoa(compIdent); var lId = btoa(locIdIdent);
		FormName		= document.meterList;
		FormName.action ='unitPriceList.php?sl_no='+sid+'&companyId='+comId+'&location_id='+lId+'&meter_id='+mid;
		FormName.submit();
	}
	
	function editCats(slNoIdent,metIdIdent,compIdent,branIdent,gateIdent,Update) 
	{
		var sid = btoa(slNoIdent); var mid = btoa(metIdIdent);  var comId = btoa(compIdent); var gId = btoa(gateIdent);var bId = btoa(branIdent);
		FormName		= document.meterList;
		FormName.action ='sensorMasterAddEdit.php?sl_no='+sid+'&sensor_id='+mid+'&companyId='+comId+'&gatewayId='+gId+'&branchId='+bId+'&Update=y';
		FormName.submit();
	}
	</script>
	<script type="text/javascript">
	function deleteCats(slNoIdent,serialIdIdent,compIdent,branIdent,gateIdent)
	{
		var sid = btoa(slNoIdent); var scId = btoa(serialIdIdent);var comId = btoa(compIdent); var gId = btoa(gateIdent);var bId = btoa(branIdent);
		if(confirm("Are you sure to Delete this Content?")){
		FormName		= document.meterList;
		FormName.action= 'sensorList.php?gatewayId='+gId+'&companyId='+comId+'&branchId='+bId+'&sl_no='+sid+'&sen_code='+scId;
		FormName.submit();
		}
	}
		function alertCats(slNoIdent,metIdIdent,compIdent,branIdent,gateIdent,Update) {
		var sid = btoa(slNoIdent); var mid = btoa(metIdIdent);  var comId = btoa(compIdent); var gId = btoa(gateIdent);var bId = btoa(branIdent);
		FormName		= document.meterList;
		FormName.action ='feederAlertParameter.php?sl_no='+sid+'&sensor_id='+mid+'&companyId='+comId+'&gatewayId='+gId+'&branchId='+bId+'&Update=y';
		FormName.submit();
	}
		function editFeederCats(slNoIdent,metIdIdent,compIdent,branIdent,gateIdent,Update) {
		var sid = btoa(slNoIdent); var mid = btoa(metIdIdent);  var comId = btoa(compIdent); var gId = btoa(gateIdent);var bId = btoa(branIdent);
		FormName		= document.meterList;
		FormName.action ='feederAddEdit.php?sl_no='+sid+'&sensor_id='+mid+'&companyId='+comId+'&gatewayId='+gId+'&branchId='+bId+'&Update=y';
		FormName.submit();
	}
	</script>
	<script type="text/javascript">
	function myFunction(id) 
	{
		var copyText = document.getElementById(id);
		copyText.select();
		copyText.setSelectionRange(0, 99999);
		document.execCommand("copy");
		alert("Copied the text: " + copyText.value);
	}
	function copy_password(id) 
	{
		var copyText = document.getElementById(id);
		var textArea = document.createElement("textarea");
		textArea.value = copyText.textContent;
		document.body.appendChild(textArea);
		textArea.select();
		document.execCommand("Copy");
		textArea.remove();
	}
	</script>
	{/literal}
	{include file="footer.tpl"}
