	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">{if $smarty.get.slNo eq ""}Create Gateway Model{else}Edit Gateway Model{/if}</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			<a href="gatewayModelList.php"><button type="button" style="float:right;margin-top:-40PX" class="btn btn-primary">List Gateway Model</button></a>
			</div>
		</div>     
		<div class="card">
			<div class="card-body">
				<form role="form" name="gatewayRegForm" id="gatewayRegForm" method="post" onsubmit="return createValidation();" >
					<input type="hidden" name="hdAction" />
					<input type="hidden" id="check_id" name="check_id" value="{$smarty.post.check_id}">
					<input type="hidden" id="checkVal" name="checkVal" value="{$smarty.post.checkVal}" />
					<input type="hidden" id="company_id" name="company_id" value="{$comId}" />
					<input type="hidden" id="modelSlNo" name="modelSlNo" value="{$ListEditView.0.sl_no}" />
					<div class="row">
						<div class="form-group col-md-6">
							<label for="exampleInputgatewayId">Gateway Model Code <span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm" id="modelCode" name="modelCode" placeholder="Enter Gateway Model Code" value="{if $ListEditView.0.model_code neq ""}{$ListEditView.0.model_code}{/if}" tabindex="1" autocomplete="Off">
						</div>
						<div class="form-group col-md-6">
							<label for="exampleInputserialNo">Gateway Model Name <span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm" id="modelName" name="modelName" placeholder="Enter Gateway Model Name" value="{if $ListEditView.0.model_name neq ""}{$ListEditView.0.model_name}{/if}" tabindex="2" autocomplete="Off">
						</div>
						<div class="form-group col-md-6">
							<div class="custom-control custom-checkbox">
							{if $ListEditView.0.is_active eq '1'}
								<input class="custom-control-input" type="checkbox" id="customCheckbox2"  name="customCheckbox2" tabindex="7" checked="checked">
								<label for="customCheckbox2" class="custom-control-label">Is Active</label>
							{elseif $ListEditView.0.is_active eq '0'}
								<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="7">
								<label for="customCheckbox2" class="custom-control-label">Is Active</label>
							{else}
								<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="7" checked="checked">
								<label for="customCheckbox2" class="custom-control-label">Is Active</label>
							{/if}
							</div>
							<input id="created_by" name="created_by" class="date-picker form-control" type="hidden" value="{$smarty.session.UserName}" readonly="true">
							<input type="hidden" class="form-control" id="timestamp" name="timestamp" value="{$smarty.now|date_format:'%Y-%m-%d &amp; %I:%M:%S %p'}">
							<input type="hidden" class="form-control" id="created_time" name="created_time" placeholder="Time" Value="{$smarty.now|date_format:'%I:%M:%S %p'}">
						</div>
					</div>
					<div align="center">
					<input type="submit" value="Submit" class="btn btn-create" tabindex="8" />
					</div>
				</form>
			</div>
		</div>
	</div>
	</section>
	</div>
	{literal}
		<script type="text/javascript">
		function createValidation()
		{
			var modelCode = $('#modelCode').val();
			var modelName = $('#modelName').val();
			var isActive = document.getElementById("customCheckbox2").checked;
		if (isActive == false) 
		{
			document.getElementById('checkVal').value='0';
		}
		else
		{
			document.getElementById('checkVal').value='1';
		}
			$(".error").remove();
		if (modelCode.length < 1) {
			$('#modelCode').after('<span class="error">This field is required</span>');
			$('#modelCode').focus();
			return false;					
		}
		else if (modelName < 1) {
			$('#modelName').after('<span class="error">This field is required</span>');
			$('#modelName').focus();
			return false;					
		}
			FormName		= document.gatewayRegForm;
			FormName.method	= "POST";
			FormName.submit();
		}
		function GoBack()
		{
			window.history.back();
		}
		</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	{/literal}
	{include file="footer.tpl"}