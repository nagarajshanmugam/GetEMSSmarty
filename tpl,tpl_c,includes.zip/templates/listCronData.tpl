	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">List Cron Data</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			</div>
		</div>
		<form name="meterList" method="post" id="meterList">
		<div class="row">
			<div class="col-12">
				<div class="card">
				{if $SuccessMessage neq "" || $ErrorMessage neq ""}
					<div class="card-body">
					{if $SuccessMessage neq ""}
						<div class="isa_success">
						<i class="fa fa-check"></i>
						{$SuccessMessage}		 
						</div>
					{/if}
					{if $ErrorMessage neq ""}
						<div class="isa_error">
						<i class="fa fa-check"></i>
						{$ErrorMessage}		 
						</div>
					{/if}
					</div>
				{/if}
					<div class="card-body table-responsive">
						<div class="col-sm-3"  style="float:right;margin-top:12PX">
						<select class="form-control" id="sensorName" name="sensorName"  tabindex="1"  >
						{if $smarty.post.sensorName eq ''}
						<option value="">--  Select Feeder  --</option>
						{/if}
						{foreach from=$ListSensorView item=ListMod}
						{if $smarty.post.sensorName eq $ListMod.sensorCode}<option value="{$ListMod.sensorCode}" selected="selected">{$ListMod.sensorName}</option>{/if}
						{if $smarty.post.sensorName neq $ListMod.sensorCode}<option value="{$ListMod.sensorCode}">{$ListMod.sensorName}</option>{/if}
						{/foreach}
						</select>
						</div>&nbsp;&nbsp;<div class="col-sm-2"  style="float:right;margin-top:-7PX" > To Date: <input type="text" id="toDate" name="toDate" value="{if $smarty.post.sensorName neq '' && $smarty.post.toDate eq ''}{$smarty.now|date_format:'%Y-%m-%d'}{elseif $smarty.post.sensorName neq '' && $smarty.post.toDate neq ''}{$smarty.post.toDate}{/if}" class="form-control" autocomplete="off" readonly="true"></div>&nbsp;&nbsp;<div class="col-sm-2"  style="float:right;margin-top:-7PX">From Date: <input type="text" id="fromDate" name="fromDate" value="{if $smarty.post.sensorName neq '' && $smarty.post.fromDate eq ''}{$smarty.now|date_format:'%Y-%m-01'}{elseif $smarty.post.sensorName neq '' && $smarty.post.fromDate neq ''}{$smarty.post.fromDate}{/if}" class="form-control" autocomplete="off" readonly="true" ></div>
					{if $ListPostData.0.recorded_date eq ''}<p>&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;<br /></p>{/if}
					<table id="example" class="table table-bordered table-hover">
					<thead>
					<tr>
					<th class="slNo">#</th>
					<th class="">Date</th>
					<th class="">Start Kwh</th>
					<th class="">End Kwh</th>
					<th class="">Total Kwh</th>
					<th class="">Unit Rate</th>
					<th class="">Total Cost</th>
					<th>Action</th>
					</tr>
					</thead>
					<tbody>
					{foreach from=$ListPostData item=List}
					{if $List.recorded_date lte $smarty.now|date_format:'%Y-%m-%d'}
					<tr id="{$j++}">
					<td >{$j}</td>
					<td>{$List.recorded_date|date_format:"%e-%b-%Y"}</td>
					<td id="skwh{$j}"><script type="text/javascript">includecomma1('{$List.start_cum_kwh}','skwh{$j}');</script></td>
					<td id="ekwh{$j}"><script type="text/javascript">includecomma1('{$List.end_cum_kwh}','ekwh{$j}');</script></td>
					<td id="ckwh{$j}"><script type="text/javascript">includecomma1('{$List.consuption_kwh}','ckwh{$j}');</script></td>
					<td id="cost{$j}"><script type="text/javascript">includecomma1('{$List.cost}','cost{$j}');</script></td>
					<td id="ccost{$j}"><script type="text/javascript">includecomma1('{$List.consuption_cost}','ccost{$j}');</script></td>
					<td align="right">
					{if $List.manual_update eq '1'}<span style="color:#FF0000; font-weight:bold"> Cron Completed</span>{else}
					<a href="#"  onClick="Javascript:editCats('{$List.recorded_date}','{$List.sensor_code}','{$smarty.session.UserName}')" title="Run Manual Cron"><i class="fa fa-recycle"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{/if}
					</td>
					</tr>
					{/if}
					{foreachelse}
					<tr><td colspan="8"><center>No Records Found</center></td></tr>
					{/foreach}
					</tbody>
					</table>
					</div>
				
				<!-- /.card-body -->
				</div>
			<!-- /.card -->
			</div>
		</form>
	</section>
	<!-- /.content -->
	</div>
	<!-- /.content-wrapper -->
	{literal}
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	<link rel="stylesheet" href="/resources/demos/style.css">
	<!--  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	-->  <script>
	$( function() {
	$( "#fromDate" ).datepicker({changeMonth: true,
	changeYear: true,maxDate: '0',dateFormat:'yy-mm-dd'});
	$( "#toDate" ).datepicker({changeMonth: true,
	changeYear: true,maxDate: '0',dateFormat:'yy-mm-dd'});
	} );
	</script>
	<script type="text/javascript">
	
	$(document).ready(function() {
	$('#sensorName').on('change', function() {
	this.form.submit();
	});
	});
	
	</script>
	<style>
	.slNo{
	width:5%;
	}
	.code{
	width:10%;
	}
	.apiKey{
	width:30%;
	}
	.name{
	width:40%;
	}
	.isactive{
	width:10%;
	text-align:center;
	
	}
	.action{
	text-align:right;
	}
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	/*background-color:#FFBABA;*/
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	/*vertical-align:middle;*/
	}
	</style>
	<script type="text/javascript">
	$(document).ready(function (){
	
	var table = $('#example').DataTable({
	"ordering" : false,
	"pageLength": 50,
	language: {
	"infoFiltered": "",
	search: "_INPUT_",
	searchPlaceholder: "Search..."
	},
	dom: '<"pull-left" f><bottom>p',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: '<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p',
	//dom: '<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p',
	
	initComplete: function(){
	//  $("div.toolbar").html('<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>');   
	
	
	}       
	}); 
	
	}); 
	
	function editCats(recordedDate,sensorCode,userName) 
	{
	var sid = recordedDate;
	var mid = sensorCode;  
	var comId = userName; 
	$.ajax({
	type: "POST",
	url: "cronEnergyMeterData.php",
	data: {recorded_date:recordedDate,sensor_code:sensorCode,userName:userName},
	dataType: "text",
	cache: false,
	success: function(result){
	var len = result.length;
	//$("#testDate").val(result);
	//alert(result);
	location.reload(true);
	},
	error: function(result) {
	alert('error');
	}
	});
	}
	
	</script>
	<script type="text/javascript">
	function deleteCats(slNoIdent,serialIdIdent,compIdent,branIdent,gateIdent){
	var sid = btoa(slNoIdent); var scId = btoa(serialIdIdent);var comId = btoa(compIdent); var gId = btoa(gateIdent);var bId = btoa(branIdent);
	if(confirm("Are you sure to Delete this Content?")){
	FormName		= document.meterList;
	FormName.action= 'sensorList.php?gatewayId='+gId+'&companyId='+comId+'&branchId='+bId+'&sl_no='+sid+'&sen_code='+scId;
	FormName.submit();
	}
	}
	
	</script>
	{/literal}
	{include file="footer.tpl"}