	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
				<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">List Gateway Group</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:10PX;color:#999999;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
				<a href="gatewayGroupAddEdit.php?companyId={if $smarty.get.companyId eq ""}{$smarty.session.COMPANY_ID|base64_encode}{else}{$smarty.get.companyId}{/if}&branchId={if $smarty.get.branchId eq ""}{$smarty.session.branch_id|base64_encode}{else}{$smarty.get.branchId}{/if}"><button type="button" style="float:right;margin-top:-40PX;" class="btn btn-create">Create Gateway Group</button></a>
			</div>
		</div>
	<section class="content">
		<form name="location_list" method="post" id="location_list">
		<div class="row">
			<div class="col-12">
				<div class="card">
				
				{if $SuccessMessage neq "" || $ErrorMessage neq ""}
					<div class="card-body">
					{if $SuccessMessage neq ""}
						<div class="isa_success">
						<i class="fa fa-check"></i>
						{$SuccessMessage}		 
						</div>
					{/if}
					{if $ErrorMessage neq ""}
						<div class="isa_error">
						<i class="fa fa-check"></i>
						{$ErrorMessage}		 
						</div>
					{/if}
					</div>
				{/if}
				<div class="card-body">
				<table id="example1" class="table table-bordered table-hover">
				<thead>
				<tr>
				<th class="slno">#</th>
				<th>Group Name</th>
				<th>Status</th>
				<th>Action</th>
				</tr>
				</thead>
				<tbody>
				{foreach from=$ListView item=List}
				<tr id="{$j++}">
				<td class="slno">{$j}</td>
				<td class="code">{$List.groupName}</td>
				<td class="action">{if $List.isActive eq "1"}<span style="color:#00A520"><b>Active</b></span>{else}<span style="color:#FF0000;"><b>Inactive</b></span>{/if}</td>
				<td class="amount action">
				{foreach from=$IconList item=icon}
				{if $icon.menuName eq "Edit Gateway Group"}<a href="#"  onClick="Javascript:editCats('{$List.groupName}','{$List.companyId}','{$List.branchId}','Update=Y')" title="Edit"><i class="{$icon.faIcon}"></i></a>&nbsp;&nbsp;&nbsp;{/if}
				{if $icon.menuName eq "Delete Gateway Group"} <a href="#"  onClick="Javascript:deleteCats('{$List.groupName}','{$List.companyId}','{$List.branchId}')" title="Delete"><i class="{$icon.faIcon}"></i></a>{/if}
				{/foreach}
				</td>
				</tr>
				{foreachelse}
				<tr><td colspan="5"><center>No Records Found</center></td></tr>
				{/foreach}
				</tbody>
				</table>
				</div>
				</div>
			</div>
		</form>
	</section>
	</div>
	{literal}
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>
	<script type="text/javascript">
	
	function meterCats(slNoIdent,compIdent,locIdIdent) {
	var sid = btoa(slNoIdent);  var comId = btoa(compIdent); var lid = btoa(locIdIdent);
	FormName		= document.location_list;
	FormName.action ='meterList.php?sl_no='+sid+'&companyId='+comId+'&location_id='+lid;
	FormName.submit();
	}
	
	function sensorCats(slNoIdent,compIdent,locIdIdent) {
	var sid = btoa(slNoIdent);  var comId = btoa(compIdent); var lid = btoa(locIdIdent);
	FormName		= document.location_list;
	FormName.action ='sensorList.php?sl_no='+sid+'&companyId='+comId+'&location_id='+lid;
	FormName.submit();
	}
	
	
	function gatewayCats(slNoIdent,compIdent,branchIdent) {
	var sid = btoa(slNoIdent);  var comId = btoa(compIdent); var bid = btoa(branchIdent);
	FormName		= document.location_list;
	FormName.action ='gatewayList.php?companyId='+comId+'&branchId='+sid;
	FormName.submit();
	}
	
	function editCats(slNoIdent,compIdent,locIdIdent) {
	var sid = btoa(slNoIdent); var comId = btoa(compIdent); var bid = btoa(locIdIdent);
	FormName		= document.location_list;
	FormName.action ='gatewayGroupAddEdit.php?companyId='+comId+'&branchId='+bid+'&groupName='+sid+'&Update=y';
	FormName.submit();
	}
	function listGatewayGroup(slNoIdent,compIdent,locIdIdent)
	{
	var sid = btoa(slNoIdent);  var comId = btoa(compIdent); var lid = btoa(locIdIdent);
	FormName		= document.location_list;
	FormName.action ='gatewayGroupList.php?sl_no='+sid+'&companyId='+comId+'&location_id='+lid;
	FormName.submit();
	}
	</script>
	<script type="text/javascript">
	function deleteCats(slNoIdent,compIdent,locIdIdent){
	var sid = btoa(slNoIdent); var comId = btoa(compIdent); var bid = btoa(locIdIdent);
	if(confirm("Are you sure to Delete this Content?")){
	FormName		= document.location_list;
	FormName.action= 'gatewayGroupList.php?companyId='+comId+'&branchId='+bid+'&deleteName='+sid;
	FormName.submit();
	}
	}
	</script>
	{/literal}
	{include file="footer.tpl"}