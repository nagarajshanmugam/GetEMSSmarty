	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
			<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				
			    <td style="font-size:15PX;font-weight: bold;">{if $GetModelName.0.model_name neq ""}{$GetModelName.0.model_name}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				
				{if $smarty.get.sl_no neq ""}
			<td style="font-size:15PX;font-weight: bold;">{$ListParameterEditView.0.parameter_name}&nbsp;&nbsp;</td>
		
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
			{/if}
			<td style="font-size:15PX;font-weight: bold;">{if $smarty.get.sl_no eq ""}Create {else}Edit {/if} Parameter</font>&nbsp;</td></tr>
				<td style="color:#999999;font-size:10PX;"></td>
			     </tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:10PX;color:#999999;">Sensor Model Name</td>
				{if $smarty.get.sl_no neq ""}
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:10PX;color:#999999;">Parameter Name</td>
				{/if}
			
				</tr>
				</table>
			<a href="sensorModelParameterList.php?sen_model={$smarty.get.sen_model}"><button type="button" style="float:right;margin-top:-40Px" class="btn btn-primary">List Sensor Model Parameter</button></a>
			</div>
		</div>
		<div class="card">
		{if $SuccessMessage neq ""}
			<div class="card-body">
				<div class="isa_success">
				<i class="fa fa-check"></i>
				{$SuccessMessage}		 
				</div>
			</div>
		{/if}
		{if $ErrorMessage neq ""}
			<div class="card-body">
				<div class="isa_error">
				<i class="fa fa-check"></i>
				{$ErrorMessage}		 
				</div>
			</div>
		{/if} 
			<div class="card-body">
				<form role="form" name="sensorModelParameterForm" id="sensorModelParameterForm" method="post" onsubmit="return createValidation();" >
					<input type="hidden" name="hdAction" />
					<input type="hidden" id="company_id" name="company_id" value="{$smarty.get.companyId}" />
					<input type="hidden" id="check_id" name="check_id" value="{$smarty.post.check_id}">
					<input type="hidden" id="checkVal" name="checkVal" value="{$smarty.post.checkVal}" />
					<div class="row">					
						<div class="form-group col-md-6" style="margin-top:-5PX">
							<label for="exampleInputgatewayId">Parameter Name <span style="color:red;">*</span></label>
	<input type="text" class="form-control form-control-sm" id="parameterName" name="parameterName" placeholder="Enter Parameter Name" value="{if $ListParameterEditView.0.parameter_name neq ''}{$ListParameterEditView.0.parameter_name}{else}{$smarty.post.parameterName}{/if}" tabindex="2">
						</div>
						<div class="form-group col-md-6">
						<label for="exampleInputmodel">Data Type <span style="color:red;">*</span></label>
						<select  id="dataType" name="dataType" class="form-control form-control-sm"  tabindex="7" onchange="GetDataLength(this.value);">
						<option value="0" >--- Select Data Type ----</option>
						{foreach from=$DataTypeExe item=dataT}
                        <option value="{$dataT.sl_no}|{$dataT.length}" {if $ListParameterEditView.0.data_type eq $dataT.data_type} selected{/if} >{$dataT.data_type}</option>
						{/foreach}
                        
						</select>
						</div>
						<div class="form-group col-md-6" style="margin-top:-5PX">
							<label for="exampleInputgatewayId">Length <span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm" id="parameterLength" name="parameterLength" placeholder="Enter Parameter Length" value="{if $ListParameterEditView.0.data_length neq ''}{$ListParameterEditView.0.data_length}{else}{$smarty.post.parameterLength}{/if}"  tabindex="2">
						</div>
                        
                        <div class="form-group col-md-6">
						<div class="form-group" style="margin-top:-5PX">
							<label for="exampleInputgatewayId">Priority <span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm" id="priority" name="priority" placeholder="Enter Parameter Priority" value="{if $ListParameterEditView.0.priority neq ''}{$ListParameterEditView.0.priority}{else}{$smarty.post.priority}{/if}">
						</div>
							<div class="custom-control custom-checkbox">
							{if $ListParameterEditView.0.is_active eq '1'}
								<input class="custom-control-input" type="checkbox" id="customCheckbox2"  name="customCheckbox2" tabindex="12" checked="checked">
								<label for="customCheckbox2" class="custom-control-label">Is Active</label>
							{elseif $ListParameterEditView.0.is_active eq '0'}
								<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="12">
								<label for="customCheckbox2" class="custom-control-label">Is Active</label>
							{else}
								<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="12" checked="checked">
								<label for="customCheckbox2" class="custom-control-label">Is Active</label>
							{/if}
							</div>
							<input id="created_by" name="created_by" class="date-picker form-control" type="hidden" value="{$smarty.session.UserName}" readonly="true">
							<input type="hidden" class="form-control" id="created_date_time" name="created_date_time" value="{$smarty.now|date_format:'%Y-%m-%d  %H:%M:%S'}">
							<input type="hidden" class="form-control" id="created_time" name="created_time" placeholder="Time" Value="{$smarty.now|date_format:'%I:%M:%S %p'}">
						</div>					
						
					</div>
					<div align="center">
					<input type="submit" value="Submit" class="btn btn-create" />
					</div>
				</form>
			</div>
		</div>
	</div>
	</section>
	</div>
	{literal}
	<script type="text/javascript">
	function createValidation()
	{
		var parameterName = $('#parameterName').val();
		var dataType = $('#dataType').val();
		var priority = $('#priority').val();
	
		var isActive = document.getElementById("customCheckbox2").checked;
	
	if (isActive == false) 
	{
		document.getElementById('checkVal').value='0';
	}
	else
	{
		document.getElementById('checkVal').value='1';
	}
		$(".error").remove();
	if (parameterName < 1) {
		$('#parameterName').after('<span class="error">This field is required</span>');
		$('#parameterName').focus();
		return false;					
	}
	else if (dataType == 0) {
		$('#dataType').after('<span class="error">This field is required</span>');
		$('#dataType').focus();
		return false;					
	}
	else if (priority < 1) {
		$('#priority').after('<span class="error">This field is required</span>');
		$('#priority').focus();
		return false;					
	}
	
		FormName		= document.sensorModelParameterForm;
		FormName.method	= "POST";
		FormName.submit();
	}
	
	function GoBack()
	{
		window.history.back();
	}
	
	function GetDataLength(cval)
	{
	var dataVal = cval;
	// Split the string by the | symbol
	var splitArray = dataVal.split('|');
	if(splitArray[1] != '' && splitArray[0] != 0){
	document.getElementById('parameterLength').value = splitArray[1];
	}else{
	document.getElementById('parameterLength').value = '';
	}
	
	}
	</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	{/literal}
	{include file="footer.tpl"}