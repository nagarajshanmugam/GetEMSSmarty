	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{if $branchDetail.0.branch_name neq ""}
					<td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>{/if}
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{if $sensorView.0.sensorName neq ""}
					<td style="font-size:15PX;font-weight: bold;">{$sensorView.0.sensorName}&ensp;&ensp;</td>{/if}
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">List Capacitor Value</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;">Sensor Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			</div>
		</div>
		<form name="meterList" method="post" id="meterList">
		    <input type="hidden" name="hdAction" id="hdAction">
		     <input type="hidden" id="item_id" name="item_id" value="{$smarty.post.item_id}">
		     <input type="hidden" id="sensorCode" name="sensorCode" value="{$smarty.get.sensorCode|base64_decode}" />
		     <input type="hidden" id="gatewayCode" name="gatewayCode" value="{$smarty.get.gatewayId|base64_decode}" />
		<div class="row">
			<div class="col-12">
				<div class="card">
				{if $SuccessMessage neq "" || $ErrorMessage neq ""}
					<div class="card-body">
					{if $SuccessMessage neq ""}
						<div class="isa_success">
						<i class="fa fa-check"></i>
						{$SuccessMessage}		 
						</div>
					{/if}
					{if $ErrorMessage neq ""}
						<div class="isa_error">
						<i class="fa fa-check"></i>
						{$ErrorMessage}		 
						</div>
					{/if}
					</div>
				{/if}
					<div class="card-body table-responsive">
					{if $ListCapacityView.0.slNo eq ""}<a href="capacityList.php?companyId={$smarty.get.companyId}&gatewayId={$smarty.get.gatewayId}&branchId={$smarty.get.branchId}&sensorCode={$smarty.get.sensorCode}&update=yes"><button type="button" style="float:right;margin-top:-6PX" class="btn btn-create">Create Capacitor Value</button></a><span style="float:right;">&ensp;</span>{/if}
					<a href="sensorList.php?companyId={$smarty.get.companyId}&branchId={$smarty.get.branchId}"><button type="button" style="float:right;margin-top:-6PX" class="btn btn-primary"> List Sensor</button></a>{if $smarty.session.USER_GROUP eq "Super Admin"}<span style="float:right;">&ensp;</span>
					<a href="branchList.php?companyId={$smarty.get.companyId}"><button type="button" style="float:right;margin-top:-6PX" class="btn btn-primary"> List Branch</button></a>{/if}
					{if $ListCapacityView.0.slNo eq ""}&ensp;<br /><br />{/if}
					<br /><br />
					
					
						<table id="example" class="table table-bordered table-hover">
						<thead>
						<tr>
						<th class="slno">#</th>
					<!--	<th class="code">Sensor Code</th>
					    <th class="name">Sensor Model</th>
					    <th class="name">Gateway Code</th>-->
						<th class="name">Step Number</th>
						<th class="json">Capacitor Value in VAr</th>
						</tr>
						</thead>
						<tbody>
						{foreach from=$ListCapacityView item=List}
						{assign var=someVar value="_"|explode:$List.stepNumber}
						<tr id="{$j++}">
						<td>{$j}</td>
						<!--<td>{$List.sensorCode}</td>
					    <td>{$List.sensorModel}</td>
					    <td>{$List.gatewayCode}</td>-->
						<td align="center"><input type="checkbox" id="product[{$j}]" name="product" value="{$j}" style="display:none;" checked="checked"><input type="text" id="sno[{$j}]"  name="sno[{$j}]" value="{$List.slNo}" style="display:none;"><input type="text" id="stepNumber[{$j}]"  name="stepNumber[{$j}]" value="{$List.stepNumber}" style="display:none;">{$someVar[0]|ucfirst}</td>
						<td align="right"> <input type="text" id="capacityValue[{$j}]"  name="capacityValue[{$j}]" value="{$List.capacityValue}" style="text-align:right;" onkeyup="numericFilter(this)"></td>
						</tr>
						{foreachelse}
						<tr><td colspan="7"><center>No Records Found</center></td></tr>
						{/foreach}
						</tbody>
						</table>
						 <div align="center">
							<center>
							<input type="submit" value="Submit" class="btn btn-create"  onclick="Validate();" />
							</center>
						</div>
					</div>
				</div>
			</div>
		</form>
	</section>
	</div>
	{literal}
	<style>
	.slno{
	width:5%;
	}
	.code{
	width:10%;
	}
	.apiKey{
	width:15%;
	}
	.name{
	width:40%;
	}
	.json{
	width:55%;
	}
	.isactive{
	width:10%;
	text-align:center;
	}
	.action{
	text-align:right;
	width:10%;
	}
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>
	<script type="text/javascript">
	$(document).ready(function (){
	
	var table = $('#example').DataTable({
	"ordering" : false,
	"paging": false,
	"bFilter": false,
    "bInfo": false,
	language: {
	"infoFiltered": "",
	search: "_INPUT_",
	searchPlaceholder: "Search..."
	},
	dom: '<"pull-left" f><bottom>p',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: '<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p',
	//dom: '<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p',
	
	initComplete: function(){
	//$("div.toolbar").html('<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>');   
	}       
	}); 
	}); 
	
	function unitPriceCats(slNoIdent,metIdIdent,compIdent,locIdIdent) 
	{
		var sid = btoa(slNoIdent); var mid = btoa(metIdIdent); var comId = btoa(compIdent); var lId = btoa(locIdIdent);
		FormName		= document.meterList;
		FormName.action ='unitPriceList.php?sl_no='+sid+'&companyId='+comId+'&location_id='+lId+'&meter_id='+mid;
		FormName.submit();
	}
	
	function editCats(slNoIdent,metIdIdent,compIdent,branIdent,gateIdent,Update) 
	{
		var sid = btoa(slNoIdent); var mid = btoa(metIdIdent);  var comId = btoa(compIdent); var gId = btoa(gateIdent);var bId = btoa(branIdent);
		FormName		= document.meterList;
		FormName.action ='sensorMasterAddEdit.php?sl_no='+sid+'&sensor_id='+mid+'&companyId='+comId+'&gatewayId='+gId+'&branchId='+bId+'&Update=y';
		FormName.submit();
	}
	</script>
	<script type="text/javascript">
	function deleteCats(slNoIdent,serialIdIdent,compIdent,branIdent,gateIdent)
	{
		var sid = btoa(slNoIdent); var scId = btoa(serialIdIdent);var comId = btoa(compIdent); var gId = btoa(gateIdent);var bId = btoa(branIdent);
		if(confirm("Are you sure to Delete this Content?")){
		FormName		= document.meterList;
		FormName.action= 'sensorList.php?gatewayId='+gId+'&companyId='+comId+'&branchId='+bId+'&sl_no='+sid+'&sen_code='+scId;
		FormName.submit();
		}
	}
		function alertCats(slNoIdent,metIdIdent,compIdent,branIdent,gateIdent,Update) {
		var sid = btoa(slNoIdent); var mid = btoa(metIdIdent);  var comId = btoa(compIdent); var gId = btoa(gateIdent);var bId = btoa(branIdent);
		FormName		= document.meterList;
		FormName.action ='feederAlertParameter.php?sl_no='+sid+'&sensor_id='+mid+'&companyId='+comId+'&gatewayId='+gId+'&branchId='+bId+'&Update=y';
		FormName.submit();
	}
		function editFeederCats(slNoIdent,metIdIdent,compIdent,branIdent,gateIdent,Update) {
		var sid = btoa(slNoIdent); var mid = btoa(metIdIdent);  var comId = btoa(compIdent); var gId = btoa(gateIdent);var bId = btoa(branIdent);
		FormName		= document.meterList;
		FormName.action ='feederAddEdit.php?sl_no='+sid+'&sensor_id='+mid+'&companyId='+comId+'&gatewayId='+gId+'&branchId='+bId+'&Update=y';
		FormName.submit();
	}
		function numericFilter(data)
	{
	data.value = data.value.replace(/[^.0-9^.+,-]/ig,"");
	}
	function text_filter(data)
	{
	data.value = data.value.replace(/[^ .a-z]/ig,"");
	
	}
	</script>
	<script type="text/javascript">
		function Validate()
		{
	
	var bar_code = [];
$.each($("input[name='product']:checked"), function(){ 
bar_code.push($(this).val());  
});
id=bar_code.join("','");//alert(id);
document.getElementById("item_id").value = id;
	
	
	if(id == '')
	{
	alert("Please Enter Capacity Value");
	return false;
	}
	else if(id.length >= 1)
{
meterList.hdAction.value = 1;
return true;
}
	}
	/*function alertBox(id)
	{
	alert(id);
	}*/
		</script>
	<script type="text/javascript">
	function myFunction(id) 
	{
		var copyText = document.getElementById(id);
		copyText.select();
		copyText.setSelectionRange(0, 99999);
		document.execCommand("copy");
		alert("Copied the text: " + copyText.value);
	}
	function copy_password(id) 
	{
		var copyText = document.getElementById(id);
		var textArea = document.createElement("textarea");
		textArea.value = copyText.textContent;
		document.body.appendChild(textArea);
		textArea.select();
		document.execCommand("Copy");
		textArea.remove();
	}
	</script>
	{/literal}
	{include file="footer.tpl"}