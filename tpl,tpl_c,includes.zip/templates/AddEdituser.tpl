	<div class="content-wrapper">
		<section class="content-header">
			<div class="card">
				<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				{if $smarty.get.branchId}  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>{/if}
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">{if $smarty.get.userId eq ""}Create User{elseif $smarty.get.userId neq "" && $smarty.get.Update eq "y"}Edit User {else}Edit Profile {/if}&nbsp;</td>
				</tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				{if $smarty.get.branchId}  <td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="font-size:10PX;color:#999999;">Branch Name</td>{/if}
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
				{if $ListEditView.0.userGroup eq 'Super Admin'}<a href="companyList.php"> <button type="button" class="btn btn-primary" value="List Company" style="float:right;margin-top:-40PX;">List Company</button></a>{else}<a href="userList.php"> <button type="button" class="btn btn-primary" value="List User" style="float:right;margin-top:-40PX;">List User</button></a>{/if}
				</div>
			</div>
		<div class="card">
		<!--<div class="card-header">
				<h3 class="card-title">{if $smarty.get.userId eq ""}Create User{elseif $smarty.get.userId neq "" && $smarty.get.Update eq "y"}Edit User {else}Edit Profile {/if}</h3>
				{if $smarty.session.USER_GROUP eq 'Super Admin'}
				<a href="companyList.php"> <button type="button" class="btn btn-primary" value="List Company" style="float:right">List Company</button></a>
				{/if}
				</div>-->
		{if $SuccessMessage neq ""}
		<div class="card-body">
			<div class="isa_success">
			<i class="fa fa-check"></i>
			{$SuccessMessage}		 
			</div>
		</div>
		{/if}
		{if $ErrorMessage neq ""}
		<div class="card-body">
			<div class="isa_error">
			<i class="fa fa-check"></i>
			{$ErrorMessage}		 
			</div>
		</div>
		{/if}
		
		<div class="card-body">
		<form name="userReg" id="userReg" method="post" role="form" enctype="multipart/form-data" onSubmit="return ValidateFields()">
		<input type="hidden" name="hdAction" id="hdAction">
		<input type="hidden" id="userId" name="userId" value="{$ListEditView.0.slNo}" />
		<input type="hidden" id="companyId" name="companyId" value="{if $smarty.get.companyId eq ""}{$ListEditView.0.company_id}{else}{$smarty.get.companyId}{/if}" />
		<input type="hidden" id="checkVal" name="checkVal" value="{$smarty.post.checkVal}" />
		<input type="text" id="textVal" name="textVal" value="{$smarty.post.textVal}" style="display:none;" />
		<input type="hidden" id="hdn_add_dtls" name="hdn_add_dtls" value="">
		<div class="row">
		<div class="form-group col-md-6">
		<label for="inputEmail3">Name <span class="required"><b>*</b></span></label>
		<input type="text" name="userName" class="form-control form-control-sm" id="userName" placeholder="Name" autocomplete="Off" tabindex="1" value="{if $ListEditView.0.userName neq ""}{$ListEditView.0.userName}{/if}">
		</div>
		
		<div class="form-group col-md-6">
		<label for="inputEmail3">Email Id <span class="required"><b>*</b></span></label>
		<input type="text" name="emailId" class="form-control form-control-sm" id="emailId" placeholder="Email Id" autocomplete="Off" tabindex="5" value="{if $ListEditView.0.emailId neq ""}{$ListEditView.0.emailId}{/if}" onblur="ValidateEmail(this);"  onChange="getcompany();">
		</div>
		{if $smarty.get.Update neq 'p'}
		<div class="form-group col-md-6">
		<label for="inputEmail3">User Group <span class="required"><b>*</b></span></label>
		{if $ListEditView.0.userGroup eq ""}
		
			<select class="form-control form-control-sm" id="userGroup" name="userGroup" tabindex="2">
			<option value="0">--Select--</option>
			{foreach from=$ListGroup item=grp}
			<option value="{$grp.usergroupName}">{$grp.usergroupName}</option>
			{/foreach}
		</select>
		{else}
		<select class="form-control form-control-sm" id="userGroup" name="userGroup" tabindex="2">
		<option id"{$ListEditView.0.userGroup}" value="{$ListEditView.0.userGroup}" selected="selected">{$ListEditView.0.userGroup}</option>
		{foreach from=$ListGroup item=grp}
		{if $ListEditView.0.userGroup neq $grp.usergroupName}
		<option value="{$grp.usergroupName}">{$grp.usergroupName}</option>
		{/if}
		{/foreach}
		</select>
		{/if}
		</div>{else}
		<input type="hidden" name="userGroup" id="userGroup" value="{$ListEditView.0.userGroup}"/>
		{/if}
		
		<div class="form-group col-md-6">
		<label for="inputEmail3">Phone</label>
		<input type="text" name="phone" class="form-control form-control-sm" id="phone" placeholder="Phone" autocomplete="Off" tabindex="6" onKeyUp="numericFilter(this);" value="{if $ListEditView.0.phone neq ""}{$ListEditView.0.phone}{/if}" maxlength="15">
		</div>
		<div class="form-group col-md-6">
		<label for="inputEmail3">Mobile No <span class="required"><b>*</b></span></label>
		<input type="text" name="mobileNo" class="form-control form-control-sm" id="mobileNo" placeholder="Mobile No" autocomplete="Off" tabindex="3" onKeyUp="numericFilter(this);" value="{if $ListEditView.0.mobileNo neq ""}{$ListEditView.0.mobileNo}{/if}" maxlength="10">
		</div>
		<div class="form-group col-md-6">
		<label for="inputEmail3">Password <span class="required"><b>*</b></span></label>
		<input type="password" name="password" class="form-control form-control-sm" id="password" placeholder="Password" autocomplete="Off" tabindex="7" value="{if $ListEditView.0.password neq ""}{$ListEditView.0.password}{/if}" onkeyup="check_length(this.value);" maxlength="8">
		</div>
		<div class="form-group col-md-6">
		<label for="inputEmail3">User Image </label>
		<input type="hidden" name="profileImageName" id="profileImageName" value="{if $ListEditView.0.userImage neq ""}{$ListEditView.0.userImage}{/if}">
		{if $ListEditView.0.slNo neq ''} 
		<a href="images/UserImages/{$ListEditView.0.userImage}" target="_blank"><img src="images/UserImages/{$ListEditView.0.userImage}" width="100" height="100" id="imgFile" name="imgFile" /></a>
		<a href="#" onclick="Showfile();" id="edit" name="edit"><i class="fa fa-edit"></i></a>
		<input type="file"  id="profileImage" value="{$smarty.post.profileImage}" name="profileImage" accept="image/x-jpg,image/png" tabindex="4" autocomplete="Off" class="form-control form-control-sm" value="{$master_dtls.userImage}" style="display:none;" onblur="ValidateFields2('profileImage');"><span style="display:none; color:#FF0000; font-size:12px;" id="spanMsg">Only JPG,PNG images are allowed / Width * Height - 256 * 256 / Below - 500KB</span>
		{else}
		<input type="file"  id="profileImage" value="{$smarty.post.profileImage}" name="profileImage" tabindex="4" accept="image/x-jpg,image/png" autocomplete="Off" class="form-control form-control-sm"><span style="color:#FF0000; font-size:12px;">Only JPG,PNG images are allowed / Width * Height - 256 * 256 / Below - 500KB</span>
		{/if}
		</div>
		<div class="form-group col-md-6">
		<div class="custom-control custom-checkbox">
		{if $ListEditView.0.userName neq ''}
		{if $ListEditView.0.isActive eq "1"}
		<input class="custom-control-input" type="checkbox" id="customCheckbox2"  name="customCheckbox2" tabindex="8" checked="checked">
		<label for="customCheckbox2" class="custom-control-label">Is Active <span class="required"><b>*</b></span></label>
		{else}
		<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="8">
		<label for="customCheckbox2" class="custom-control-label">Is Active <span class="required"><b>*</b></span></label>
		{/if}
		{else}
		<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="8" checked="checked">
		<label for="customCheckbox2" class="custom-control-label">Is Active <span class="required"><b>*</b></span></label>
		{/if}
		</div>
		<input id="created_by" name="created_by" class="date-picker form-control" type="hidden" value="{$smarty.session.UserName}" readonly="true">
		<input type="hidden" class="form-control" id="timestamp" name="timestamp" value="{$smarty.now|date_format:'%Y-%m-%d &amp; %I:%M:%S %p'}">
		<input type="hidden" class="form-control" id="created_time" name="created_time" placeholder="Time" Value="{$smarty.now|date_format:'%I:%M:%S %p'}">
		</div>
		</div>
		<div align="center">
		<center>
		{if $smarty.get.userId eq ''}
		<input type="submit" value="Submit" class="btn btn-create" tabindex="9" onclick="ValidateFields();" />		
		{else}
		<input type="submit" value="Submit" class="btn btn-create" tabindex="9" onclick="ValidateFieldsImage();" />
		{/if}
		</center>
		</div>
		</form>
		</div>
		</div>
		</section>	
	</div>
	{literal}
	<script type="text/javascript">
	function numericFilter(data)
	{
	data.value = data.value.replace(/[^.0-9^.+,-]/ig,"");
	}
	function text_filter(data)
	{
	data.value = data.value.replace(/[^ .a-z]/ig,"");
	}
	function Showfile()
	{
	document.getElementById('profileImage').style.display="block";
	document.getElementById('imgFile').style.display="none";
	document.getElementById('edit').style.display="none";
	document.getElementById('spanMsg').style.display="block";
	}
	
	function ValidateFields2(id)
	{
	var val = document.getElementById(id).value;
	if(val == '' || val == '0')
	{
	$(".error").remove();
	$("#"+id).after('<span class="error">This field is required</span>');
	$("#"+id).focus();
	return false;		
	}
	else
	{
	$(".error").remove();
	return true;
	}
	}
	</script>
	<script type="text/javascript">
	function ValidateFields()	
	{
	var userName = $('#userName').val();
	var userGroup = $('#userGroup').val();
	var mobileNo = $('#mobileNo').val();
	var emailId = $('#emailId').val();	
	var password = $('#password').val();
	var isActive = document.getElementById("customCheckbox2").checked;
	var company_name = $('#textVal').val();
	var mailformat = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
	if (isActive == false) 
	{
	document.getElementById('checkVal').value='0';
	}
	else
	{
	document.getElementById('checkVal').value='1';
	}
	$(".error").remove();
	if (userName.length < 1) {
	$('#userName').after('<span class="error">This field is required</span>');
	$('#userName').focus();
	return false;					
	}
	else if (userGroup == '0') {
	$('#userGroup').after('<span class="error">This field is required</span>');
	$('#userGroup').focus();
	return false;					
	}
	else if (mobileNo.length < 1) {
	$('#mobileNo').after('<span class="error">This field is required</span>');
	$('#mobileNo').focus();
	return false;					
	}
	else if (mobileNo.length < 10) {
	$('#mobileNo').after('<span class="error">Mobile Number should be 10 digits</span>');
	$('#mobileNo').focus();
	return false;					
	}
	else if (emailId.length < 1) {
	$('#emailId').after('<span class="error">This field is required</span>');
	$('#emailId').focus();
	return false;					
	}
	else if(!mailformat.test(emailId)) {
	$("#emailId").after('<span class="error">Enter a valid email address.</span>');
	$('#emailId').focus();
	return false;	
    }
	else if (password.length < 1) {
	$('#password').after('<span class="error">This field is required</span>');
	$('#password').focus();
	return false;					
	}
	else if (password.length < 6) {
	$('#password').after('<span class="error">Password length should be between 6 and 8 character</span>');
	$('#password').focus();
	return false;					
	}
	else if(company_name == emailId)
	{
	$('#emailId').after('<span class="error">Email ID already exist</span>');
	$('#emailId').focus();
	return false;
	}
	userReg.hdAction.value = 1;
	return true;
	}
	</script>
	<script type="text/javascript">
	function getcompany()
	{
	var company_name=document.getElementById("emailId").value;
	if (window.XMLHttpRequest)
	{
	xmlhttp=new XMLHttpRequest();
	}	
	else
	{
	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange=function()
	{
	if (xmlhttp.readyState==4 && xmlhttp.status==200)
	{
	var x;
	if(xmlhttp.responseText)
	{
	x=xmlhttp.responseText;
	document.getElementById("hdn_add_dtls").value=x;
	var add_dtls=x.split("_");
	document.getElementById("textVal").value=add_dtls[0];
	var ename=document.getElementById("textVal").value;
	if(company_name == ename)
	{
	$('#emailId').after('<span class="error">Email ID already exist</span>');
	$('#emailId').focus();
	return false;
	}
	else
	{
	return true;
	}
	}
	else
	{
	document.getElementById("emailId").innerHTML="<option value='0'>Please select Company Name</option>";
	}
	}
	}
	xmlhttp.open("GET","AddEdituser.php?bill_from="+company_name,true);
	xmlhttp.send();
	}
	</script>
	<script type="text/javascript">	
	function GoBack()
	{
	window.history.back();
	}
	</script>
	<script type="text/javascript">
	function check_length(val)
	{$(".error").remove();
	var test = val.length;
	if(test >= '6' && test <= '8')
	{
	$(".error").remove();
	return true;
	}
	else
	{
	$('#password').after('<span class="error">Password length should be between 6 and 8 character</span>');
	$('#password').focus();
	return false;
	}
	}
	</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}	
	.required
	{
	color:#FF0000;
	}
	</style>
	{/literal}
	{include file="footer.tpl"}