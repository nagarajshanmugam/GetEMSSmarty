	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				{if $smarty.get.branchId}
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>
				{/if}
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">{if $smarty.get.sl_no eq ""}Create Alert Parameter{else}Edit Alert Parameter{/if}</font>&nbsp;</td></tr>	
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			{if $smarty.get.sl_no eq "" && $smarty.session.USER_GROUP eq "Branch Admin"} <a href="feederList.php?companyId={$smarty.get.companyId}&gatewayId={$smarty.get.gatewayId}&branchId={$smarty.get.branchId}"><button type="button" style="float:right;margin-top:-40PX" class="btn btn-primary">List {if $smarty.session.COMPANY_ID neq '4'}Feeder{else}Sensor{/if}</button></a>{else}
	{if	$smarty.session.USER_GROUP eq "Branch Admin"}	<a href="feederList.php?companyId={$smarty.get.companyId}&branchId={$smarty.get.branchId}"><button type="button" style="float:right;;margin-top:-40PX" class="btn btn-primary" >List {if $smarty.session.COMPANY_ID neq '4'}Feeder{else}Sensor{/if}</button></a>{/if}
			{/if}
			</div>
		</div>
		<div class="card">
			<div class="card-body">
				<form role="form" name="alertParameterReg" id="alertParameterReg" method="post" onsubmit="return createValidation();" >
					<input type="hidden" name="hdAction" />
				{if $smarty.get.sl_no neq ""}
					<input type="hidden" id="sensor_id" name="sensor_id" value="{$EditViewFeedForm.0.sensorCode}" />
					<input type="hidden" id="gateway_id" name="gateway_id" value="{$EditViewFeedForm.0.gateway_id}" />
					<input type="hidden" id="company_id" name="company_id" value="{$EditViewFeedForm.0.company_id}" />
					<input type="hidden" id="branch_id" name="branch_id" value="{$EditViewFeedForm.0.branch_id}" />
					<input type="hidden" id="sensor_model_id" name="sensor_model_id" value="{$EditViewFeedForm.0.sl_no}" />
				{else}
					<input type="hidden" id="sensor_id" name="sensor_id" value="{$EditViewFeedForm.0.sensorCode}" />
					<input type="hidden" id="gateway_id" name="gateway_id" value="{$EditViewFeedForm.0.gateway_id}" />
					<input type="hidden" id="company_id" name="company_id" value="{$EditViewFeedForm.0.company_id}" />
					<input type="hidden" id="branch_id" name="branch_id" value="{$EditViewFeedForm.0.branch_id}" />
					<input type="hidden" id="sensor_model_id" name="sensor_model_id" value="{$EditViewFeedForm.0.sl_no}" />
				{/if}
					<input type="hidden" id="check_id" name="check_id" value="{$smarty.post.check_id}">
					<input type="hidden" id="checkVal" name="checkVal" value="{$smarty.post.checkVal}" />
					<div class="row">				
						<div class="form-group col-md-6" >
							<label for="exampleInputmeterName">Sensor Name  /  Installation Place<span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm" id="feederName" name="feederName" placeholder="Enter Feeder Name" value="{if $EditViewFeedForm.0.sensorName neq ""} {$EditViewFeedForm.0.sensorName}{/if}" autocomplete="Off"  readonly="true">
						</div>
						<div class="form-group col-md-6" >
							<label for="exampleInputmeterName">Sensor Model Name <span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm"  value="{if $EditViewFeedForm.0.model_name neq ""} {$EditViewFeedForm.0.model_name}{/if}" autocomplete="Off"  readonly="true">
						</div>
						<div class="form-group col-md-6" >
							<label for="exampleInputmeterName">Parameter<span style="color:red;">*</span></label>
							<select name="parameterName" class="form-control form-control-sm" id="parameterName"  tabindex="1">
							<option value="" >-- Select Parameter --</option>
						{foreach from=$sensorParam item=ListPlat}
							<option value="{$ListPlat.parameter_name}">{$ListPlat.parameter_name}</option>
						{/foreach}
							</select>
						</div>
						<div class="form-group col-md-6 hideDiv"  style="display:none">
							<label for="exampleInputmeterName">Min Alert Value  <span style="color:red;">*</span></label>
							<input type="text" class="form-control" id="minAlertValue" name="minAlertValue" placeholder="Min Alert Value" value="" autocomplete="Off" tabindex="2" onKeyUp="numericFilter(this);">
						</div>
						<div class="form-group col-md-6 hideDiv"  style="display:none" >
						<label for="exampleInputmeterName">Max Alert Value <span style="color:red;">*</span></label>
						<input type="text" class="form-control" id="maxAlertValue" name="maxAlertValue" placeholder="Max Alert Value" value="" autocomplete="Off" tabindex="3" onKeyUp="numericFilter(this);">
					</div>
					</div>
					<div align="center">
					<input type="submit" value="Submit" class="btn btn-create" tabindex="6"/>
					</div>
				</form>
			<br/>
			{if $SuccessMessage neq "" || $ErrorMessage neq ""}
				<div class="card-body">
				{if $SuccessMessage neq ""}
					<div class="isa_success">
					<i class="fa fa-check"></i>
					{$SuccessMessage}		 
					</div>
				{/if}
				{if $ErrorMessage neq ""}
					<div class="isa_error">
					<i class="fa fa-check"></i>
					{$ErrorMessage}		 
					</div>
				{/if}
				</div>
			{/if}
				<form name="parameterList" method="post" id="parameterList">
					<input type="hidden" id="hdAction2" name="hdAction2">
					<table id="example" class="table table-bordered table-hover">
					<thead>
					<tr>
					<th class="slNo">#</th>
					<th class="name">Parameter Name</th>
					<th class="type">Min Alert Value</th>
					<th class="name">Max Alert Value</th>
					<th>Action</th>
					</tr>
					</thead>
					<tbody>
					{foreach from=$alertParameterList item=List}
					<tr id="{$j++}">
					<td >{$j}</td>
					<td>{$List.parameter_name}</td>
					<td align="right">{$List.min_alert_value}</td>
					<td align="right">{$List.max_alert_value}</td>
					<td align="right">
					<a href="#"  onClick="Javascript:deleteCats('{$List.alert_parameter_id|base64_encode}')" title="Delete"><i class="fa fa-trash"></i></a>
					</td>
					</tr>
					{foreachelse}
					<tr><td colspan="6"><center>No Records Found</center></td></tr>
					{/foreach}
					</tbody>
					</table>
				</form>
			</div>
		</div>
	</div>
	</section>
	</div>
	{literal}
	<script type="text/javascript">
	$('#parameterName').on('change', function() {
		$('.hideDiv').show();
	});
	$(document).ready(function(){
		$("#mainMeter").hide();
		$("#subMeter").hide();
		$("#Meter").hide();
	});
	</script>
	<script type="text/javascript">
	function deleteCats(slNoIdent){
		var url= window.location.href;
		var resSplit = url.split("&succ");
		var passUrl=resSplit[0];
		if(confirm("Are you sure to Delete this Alert Parmeter?")){
		FormName		= document.parameterList;
		FormName.action= passUrl+'&Delete='+slNoIdent;
		FormName.submit();
		}
	}
	</script>
	<script type="text/javascript">
	function numericFilter(data)
	{
	data.value = data.value.replace(/[^.0-9^.+,-]/ig,"");
	}
	function text_filter(data)
	{
	data.value = data.value.replace(/[^ .a-z]/ig,"");
	
	}
	function createValidation(){
		var parameterName = $('#parameterName').val();
		var minAlertValue = $('#minAlertValue').val();
		var maxAlertValue = $('#maxAlertValue').val();
		$(".error").remove();
	if (parameterName < 1) {
		$('#parameterName').after('<span class="error">This field is required</span>');
		$('#parameterName').focus();
		return false;					
	}
	else if (minAlertValue < 1) {
		$('#minAlertValue').after('<span class="error">This field is required</span>');
		$('#minAlertValue').focus();
		return false;					
	}
	else if (maxAlertValue < 1) {
		$('#maxAlertValue').after('<span class="error">This field is required</span>');
		$('#maxAlertValue').focus();
		return false;					
	}
		FormName = document.alertParameterReg;
		FormName.method = "POST";
		FormName.submit();
	}
	function GoBack()
	{
		window.history.back();
	}
	</script>
	<script type="text/javascript">
	function locationDecode(){
		var lid = {$smarty.get.location_id};
		var uri_lid = decodeURIComponent(lid);
		alert(uri_lid);
	}
	</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	{/literal}
	{include file="footer.tpl"}