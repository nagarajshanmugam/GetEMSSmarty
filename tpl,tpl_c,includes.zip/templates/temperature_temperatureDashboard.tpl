{literal}
<script type="text/javascript">
     function secondsToDhms(seconds,v) {//alert(seconds);
var seconds = Number(seconds);
var d = Math.floor(seconds / (3600*24));
var h = Math.floor(seconds % (3600*24) / 3600);
var m = Math.floor(seconds % 3600 / 60);
var s = Math.floor(seconds % 60);

var dDisplay = d > 0 ? d + (d == 1 ? " day, " : " days, ") : "";
var hDisplay = h > 0 ? h + (h == 1 ? " hr, " : " hrs, ") : "";
var mDisplay = m > 0 ? m + (m == 1 ? " min, " : " min's, ") : "";
var sDisplay = s > 0 ? s + (s == 1 ? " sec" : " sec's") : "";
//var res= 'Last Updated' + ' ' + dDisplay + hDisplay + mDisplay + sDisplay;
var res= dDisplay + hDisplay + mDisplay + sDisplay;
document.getElementById(v).innerHTML=res;
}

 </script>
 <style type="text/css">
     .padclass
	{
	    padding-top:18px;
	    padding-bottom:3px;
	}
 </style>
 
{/literal}
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<body onLoad="doOnLoad();">
	<div class="content-wrapper">
	<div class="content-header">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-body">
						<table style="margin-bottom:-10px;">
						<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
						<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
						<td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>
						<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
						<td style="font-size:15PX;font-weight: bold;">Temperature  <!---({$LoctList.0.gateway_id} / {$LoctList.0.sensorCode})--></font>&nbsp;</td></tr>
						<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
						<td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
						<td style="font-size:10PX;color:#999999;">Branch Name</td>
						<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
						<td style="color:#999999;font-size:10PX;">Dashboard</td><td>&nbsp;</td>
						</tr>
						</table>
					</div>
				</div>
			</div>
		</div>
        
       <!-- <textarea id="currMonQut" name="currMonQut"  style="display:none;">{$getCurMonQut}</textarea>-->
        
        
        <div class="row">        

            {foreach from=$TempList item=List}
            <tr id="{$j++}">
          <div class="col-md-3">
            <!-- Box Comment -->
            <div class="card card-widget card-primary">
              <div class="card-header" style="margin-bottom:-15px;">
                <div class="card-title">
                  <center><span class="username"><b><a href="DashboardTemperature.php?companyId={if  $smarty.get.companyId neq ""}{$smarty.get.companyId}{else}{$smarty.session.CustomerId|base64_encode}{/if}&branchId={if $smarty.get.branchId neq ""}{$smarty.get.branchId}{else}{$smarty.session.branch_id|base64_encode}{/if}&sensorCode={$List.sensor_code|base64_encode}&gatewayCode={$List.gateway_code|base64_encode}">{$List.feeder_name}</a></b></span></center>
                </div>
              </div>
              
              <div class="card-body">
                  
              
			 <!-- {$ListIncidentLog.posted_date_time|date_format:"%H:%M %S"}
			  {$smarty.now|date_format:"%H:%M:%S"}--->
			  {if $List.secs lt '2100' && $List.secs neq ''}
                <div class="row">
                    {if $List.TemHum eq "Both"}
                  <div class="col-sm-6">
                    <div class="description-block">
                         <img class="img-circle elevation-2" src="./images/temperature.jpg" alt="User Image" width="70" height="70">
                      <h5 class="description-header" style="color:#15b5f0;padding-top:6px;"><b>{$List.temperature_c} &deg; C</b></h5>
                      <span class="description-text"></span>
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="description-block">
                        <img class="img-circle elevation-2" src="./images/humidity.jpg" alt="User Image" width="70" height="70">
                      <h5 class="description-header" style="color:#7db616;padding-top:6px;"><b>{$List.humidity} %</b></h5>
                      <span class="description-text"></span>
                    </div>
                  </div>
                  {/if}
				  {if $List.TemHum eq "Temperature"}
                  <div class="col-sm-12">
                    <div class="description-block">
                         <img class="img-circle elevation-2" src="./images/temperature.jpg" alt="User Image" width="70" height="70">
                      <h5 class="description-header" style="color:#15b5f0;padding-top:6px;"><b>{$List.temperature_c} &deg; C</b></h5>
                      <span class="description-text"></span>
                    </div>
                  </div>
                  {/if}
				  {if $List.TemHum eq "Humidity"}
                  <div class="col-sm-12">
                    <div class="description-block">
                        <img class="img-circle elevation-2" src="./images/humidity.jpg" alt="User Image" width="70" height="70">
                      <h5 class="description-header" style="color:#7db616;padding-top:6px;"><b>{$List.humidity} %</b></h5>
                      <span class="description-text"></span>
                    </div>
                  </div>
                  {/if}
                </div>
				
               
                <center ><b><span class="text-muted" style="margin-bottom:-15px;margin-top:-5px;" id="{$j}" ><script type="text/javascript">secondsToDhms('{$List.secs}','{$j}');</script> ago</span></b></center>
				{else}
				<div class="row overlay ">
                    {if $List.TemHum eq "Both"}
                  <div class="col-sm-6 overlay ">
                    <div class="description-block">
                         <img class="img-circle elevation-2" src="./images/temperatureCrayScale.png" alt="User Image" width="70" height="70">
                      <h5 class="description-header" style="color:#15b5f0;padding-top:6px;"><b></b></h5>
                      <span class="description-text"></span>
                    </div>
                  </div>
                  <div class="col-sm-6 overlay">
                    <div class="description-block">
                        <img class="img-circle elevation-2" src="./images/humidityGrayScale.png" alt="User Image" width="70" height="70">
                      <h5 class="description-header" style="color:#7db616;padding-top:6px;"><b></b></h5>
                      <span class="description-text"></span>
                    </div>
                  </div>
                  {/if}
				  {if $List.TemHum eq "Temperature"}
                  <div class="col-sm-12 overlay">
                    <div class="description-block">
                         <img class="img-circle elevation-2 " src="./images/temperatureCrayScale.png" alt="User Image" width="70" height="70">
                      <h5 class="description-header" style="color:#15b5f0;padding-top:6px;"><b></b></h5>
                      <span class="description-text"></span>
                    </div>
                  </div>
                  {/if}
				  {if $List.TemHum eq "Humidity"}
                  <div class="col-sm-12 overlay ">
                    <div class="description-block">
                        <img class="img-circle elevation-2 " src="./images/humidityGrayScale.png" alt="User Image" width="70" height="70">
                      <h5 class="description-header" style="color:#7db616;padding-top:6px;"><b></b></h5>
                      <span class="description-text"></span>
                    </div>
                  </div>
                  {/if}
                </div>
				
               <br>
                <center ><b><span class="text-muted" style="margin-bottom:-15px;margin-top:-5px;" id="{$j}" >Sensor Off Status</span></b></center>
				{/if}
              </div>
              
              <div class="card-footer card-comments">
                  <div class="comment-text" ><span class="username" style="color:#15b5f0; margin-top:-5px;"><!--<b>Latest Incidents</b>--></span></div>
               {foreach from=$allincidentList[$List.sensor_code] item=ListIncidentLog}
    {if $ListIncidentLog.sensor_code eq $List.sensor_code}
        <div class="card-comment">
            <div class="comment-text" style="margin:-5px;">
                <span class="username">
                    {$ListIncidentLog.sensor_code}
                    <span class="text-muted float-right">
                        {$ListIncidentLog.posted_date_time|date_format:"%e-%b-%Y %I:%M %p"}
                    </span>
                </span>

                {if $List.TemHum eq "Both"}
                    T - {$ListIncidentLog.temperature_c} &deg; C &nbsp;&nbsp;&nbsp;&nbsp;
                    H - {$ListIncidentLog.humidity} %
                {/if}

                {if $List.TemHum eq "Temperature"}
                    T - {$ListIncidentLog.temperature_c} &deg; C
                {/if}

                {if $List.TemHum eq "Humidity"}
                    H - {$ListIncidentLog.humidity} %
                {/if}
            </div>
        </div>
    {/if}
{/foreach}
              </div>
              
              <div class="card-footer">
                   <center> <span>
                      <a href="DashboardTemperature.php?companyId={if  $smarty.get.companyId neq ""}{$smarty.get.companyId}{else}{$smarty.session.CustomerId|base64_encode}{/if}&branchId={if $smarty.get.branchId neq ""}{$smarty.get.branchId}{else}{$smarty.session.branch_id|base64_encode}{/if}&sensorCode={$List.sensor_code|base64_encode}&gatewayCode={$List.gateway_code|base64_encode}"><button type="submit" class="btn btn-success">View More</button></a>
                    </span></center>
              </div>
             
            </div>
            <!-- /.card -->
          </div>
          </tr>
          {/foreach}
          <!-- /.col -->
        </div>
    
    
    <div class="row">
			<div class="col-md-10">
            <div class="card card-outline card-primary">
            <div class="card-header">
						<h3 class="card-title">
						<i class="fa fa-list"></i>
						&nbsp;&nbsp;List of Temperature Sensor
						</h3>
						
						</div>
               <div class="card-body table-responsive no-padding">
			 <div class="row">
<input type="hidden" id="cid" name="cid" value="{if $smarty.get.companyId neq ""}{$smarty.get.companyId}{else}{$smarty.session.customerId}{/if}" />
				<input type="hidden" id="bid" name="bid" value="{$smarty.get.branchId}" />
				<input type="hidden" value="{$Dashboard.0.segmentName}" />
    <div id="list_books" class="col-12">
			  <table id="example" class="table table-bordered table-hover">
                <thead>
                <tr>
    			  <th class="slNo" rowspan="2" >#</th>
                  <th class="name" rowspan="2">Place Of Installation</th>
                  <th class="gate" rowspan="2">Gateway</th>
				   <!--<th class="status" rowspan="2">Status</th>-->
                  <th  colspan="2" class="code" >Temperature</th>
                   <th  class="status" rowspan="2">Humidity</th>
                  <th class="action" rowspan="2">Date Time</th>
                  <th class="last" rowspan="2">Last Comm</th>
                  
          
                </tr>
                <tr>
    			 
                  <th class="cost">&deg; C</th>
                  <th class="cost" >&deg; F</th>
                  
                </tr>
                </thead>
                <tbody>
				{foreach from=$TempList item=List}
                {assign var=pid value=$List.feeder_master_id|base64_encode}
                <tr id="{$k++}">
				 <td >{$k}</td>
				 	
                 <td><a href="DashboardTemperature.php?companyId={if $smarty.get.companyId neq ""}{$smarty.get.companyId}{else}{$smarty.session.CustomerId|base64_encode}{/if}&branchId={if $smarty.get.branchId neq ""}{$smarty.get.branchId}{else}{$smarty.session.branch_id|base64_encode}{/if}&sensorCode={$List.sensor_code|base64_encode}&gatewayCode={$List.gateway_code|base64_encode}" style="text-decoration:underline;color:#000000;" title="Meter Details" >{$List.feeder_name}</a>{foreach from=$selQryS item=sub}{if $List.feeder_type eq "Main Meter" &&  $List.slNo eq $sub.parent_id}&ensp;&ensp;<a href="subdashboard.php?parent_id={$pid}&companyId={$smarty.get.companyId}&branchId={$smarty.get.branchId}"><i class="fa fa-sitemap" aria-hidden="true" title="Submeter List"></i></a>{/if}{/foreach}</td>
                 <td >{$List.gateway_code}</td>
            <td align="right">
                {if isset($List.temperature_c) && $List.temperature_c neq ''}
                    {$List.temperature_c}
                {else}
                    -
                {/if}
                 </td>
            <td align="right">
                {if isset($List.temperature_f) && $List.temperature_f neq ''}
                    {$List.temperature_f}
                {else}
                    -
                {/if}
                 </td>
                 <td align="right">
                {if isset($List.humidity) && $List.humidity neq ''}
                    {$List.humidity}
                {else}
                    -
                {/if}
                 </td>               
				  <td>{$List.posted_date_time|date_format:"%d-%b-%Y %I:%M:%S %p"}</td>
		       <td id="t{$k}"><script type="text/javascript">secondsToDhms('{$List.secs}','t{$k}');</script> ago</td>
			   
            
                </tr>
                {foreachelse}
                <tr><td colspan="8"><center>No Records Found</center></td></tr>
                {/foreach}
               
               
                </tbody>
                
              </table>
			  </div>
</div>
</div>
<div class="card-body table-responsive">
            <div class="row">
        </div>
        </div>
      </div>
    </div>
	<div class="col-md-2">
			<div class="card card-primary card-outline">
			<div class="card-header">
			<h3 class="card-title">Gateway List</h3>
			</div>
			<div class="card-body p-0">
			<ul class="products-list product-list-in-card pl-2 pr-2">
			
			{foreach from=$TempList item=List}
			{foreach from=$gateList item=gate}
			 {if $List.gateway_code neq $gatewayCode}
			<li class="item">
			{$gate.gateway_code}
			{if $gate.gateway_code eq $List.gateway_code && $gate.gateway_date_time gte $dateSec|date_format:'%Y-%m-%d %H:%M:%S' }
                <span class="badge badge-success float-right"> 
                ON
				</span>
                 {assign var="tog" value='1'}
                {elseif $gate.gateway_code eq $List.gateway_code && $gate.gateway_date_time lt $dateSec|date_format:'%Y-%m-%d %H:%M:%S'}
                 <span class="badge badge-danger float-right">
                OFF
				</span>
                 {assign var="tog" value='1'}
                {/if}
			</li>
				
				{/if}
               {assign var=gatewayCode value=$List.gateway_code}
                {/foreach}
				{/foreach}
				{assign var="tog" value=''}
			</ul>
			</div>
		<!--	<div class="card-footer text-center">
			<a href="listIncidentLog.php" class="uppercase">View All Incidents</a>
			</div> -->
			</div>
			</div>
  </div>
    
	</div>
	</div>
	</div>
	</body>
	{literal}
    
	<style>
.slNo
 {
 width:3%;
 }
 .name
 {
 width:18%;
 }
 .gate
 {
 width:10%;
 }
 .status
 {
 width:5%;
 }
 .code
 {
 width:10%;
 }
 .cost
 {
 width:5%;
 }
 .action
 {
 width:15%;
 }
 .last
 {
 width:11%;
 }
 .uline
 {
 text-decoration:underline;
 }
	 #barChart2 {
	width	: 100%;
	height	: 450px;
	}
	</style>
	<script type="text/javascript">
 function doOnLoad()
 {
 setInterval(Add_Item, 3000);
 }
 </script>
      <script type="text/javascript">
	function Add_Item()
{
var cid =$('#cid').val() ;
var bid =$('#bid').val() ;//alert(bid)
$.ajax({
		type: "POST",
		url: "getTemptable.php",
		data: {cid:cid,bid:bid},
		success: function(data) {
		$("#list_books").html(data);
		}
		});
}
	</script>
    <!--<script type="text/javascript">
var result = document.getElementById('currMonQut').value;

var jsonData=result;
var obj = JSON.parse(jsonData);
var mon = "";
var dataVal = "";
var dataVal1 = "";
var colo = "";
var i;
for (i = 0; i < obj.length; i++) {
if(i==0){
  mon += obj[i].month ;
  dataVal += obj[i].value;
  dataVal1 += obj[i].value1;
   colo += obj[i].color;
   }
  else
  {
  mon += ", "+ obj[i].month;
  dataVal += ", "+ obj[i].value;
   dataVal1 += ", "+ obj[i].value1;
   colo += ', '+ obj[i].color;
 }
}
// loop  variable concatinate each  record  as an array
var monthVal = mon;
var dataValue =dataVal;
var dataValue1 =dataVal1;
var colors =colo;


// above mentioned  array variable  split by comma to plot the variable in lable and data in chart
var month =  monthVal.split(',');
var dataV=  dataVal.split(',');//alert(numberWithCommas(dataV));
//alert(dataV);
 
  var dis = Math.round(dataV);//alert(dis);
  var vad = addcomma(dis);//alert(vad);
//var dataV=addCommas(dataV);
var dataV1=  dataVal1.split(',');
var clr=  colors.split(',');
  var barChartCanvas = $('#barChart2').get(0).getContext('2d');
 

  var barChartData = {
    labels  :  month,
    datasets: [
      {
          label               : 'Kwh',
          backgroundColor     : '#67b7dc',
          borderColor         :  '#67b7dc',
          pointRadius          : false,
          pointColor          :  '#67b7dc',
          pointStrokeColor    :  '#67b7dc',
          pointHighlightFill  :  '#67b7dc',
          pointHighlightStroke:  '#67b7dc',
		  fillColor: "#67b7dc",
          data                : dataV
      },
      {
        label                 : 'Cost',
          backgroundColor     : '#fdd400',
          borderColor         :  '#fdd400',
          pointRadius         : false,
          pointColor          :  '#fdd400',
          pointStrokeColor    :  '#fdd400',
          pointHighlightFill  :  '#fdd400',
          pointHighlightStroke:  '#fdd400',
		  fillColor: "#fdd400",
          data                : dataV1
      }
    ]
  };
  
   
  
    var barChartOptions = {
	tooltips: {
        callbacks: {
            label: function(tooltipItem) {
			var dis = Math.round(tooltipItem.yLabel);
  var vad = includecomma(dis);
                return  vad;
            }
        }
    },
      responsive              : true,
      maintainAspectRatio     : true,
      datasetFill             : true,
	    scales: {
		yAxes: [{
              ticks:{
                  stepSize : 5000,

              }
			  }]
		}
	      };


    var barChart = new Chart(barChartCanvas, {
      type: 'bar', 
      data: barChartData,
      options: barChartOptions,
    });
	
	barChart.Bar(barChartData, barChartOptions);
	
</script>-->
    
	{/literal}
	
	{include file="footer.tpl"}