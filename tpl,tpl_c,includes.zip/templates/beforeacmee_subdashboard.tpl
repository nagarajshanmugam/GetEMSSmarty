{literal}
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script type="text/javascript">
     function secondsToDhms(seconds,v) {//alert(seconds);
var seconds = Number(seconds);
var d = Math.floor(seconds / (3600*24));
var h = Math.floor(seconds % (3600*24) / 3600);
var m = Math.floor(seconds % 3600 / 60);
var s = Math.floor(seconds % 60);

var dDisplay = d > 0 ? d + (d == 1 ? " day, " : " days, ") : "";
var hDisplay = h > 0 ? h + (h == 1 ? " hr, " : " hrs, ") : "";
var mDisplay = m > 0 ? m + (m == 1 ? " min, " : " min's, ") : "";
var sDisplay = s > 0 ? s + (s == 1 ? " sec" : " sec's") : "";
var res=  dDisplay + hDisplay + mDisplay + sDisplay;
document.getElementById(v).innerHTML=res;
}
 </script>
 <script type="text/javascript">
	function includecomma1(c,v)
{
//var x=Math.round(c);
//var x=c.toFixed(2);

var x=c.split(".");
var ld=x[1];
var ty=typeof(x[1]);//alert(ty);
if(ty == 'undefined')
{
   
    var ld='00';
}
else
{
var ld=x[1].slice(0, 2);
}
x=x[0].toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != '')
{
lastThree = ',' + lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
}
else
{
lastThree =  lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
}
//var res = res+'.00';
var res = res+'.'+ld;
document.getElementById(v).innerHTML=res;
}
</script>
{/literal}

<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<body onLoad="doOnLoad();">
<div class="content-wrapper">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <div class="content-header">

      <div class="container-fluid">

            <div class="row"> <div class="col-md-12">
            <div class="card">
            <div class="card-body">

			 <table style="margin-bottom:-10px;">
		  <tr><td style="font-size:15PX;font-weight: bold;">{$companyDetail.0.companyName}&nbsp;&nbsp;</td>
		  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  <td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>
		  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  <td style="font-size:15PX;font-weight: bold;">{$senDashboard.0.sensorName}&ensp;&ensp;</td>
		  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  <td style="font-size:15PX;font-weight: bold;">Energy Meter  <!---({$LoctList.0.gateway_id} / {$LoctList.0.sensorCode})--></font>&nbsp;</td></tr>
		  
		
		  <tr><td style="font-size:10PX;color:#999999;">Company Name</td>
		  <td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  <td style="font-size:10PX;color:#999999;">Branch Name</td>
		  <td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  <td style="font-size:10PX;color:#999999;">Meter Name</td>
		  <td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  <td style="color:#999999;font-size:10PX;">Dashboard</td><td>&nbsp;</td>
		  </tr>
		  
		  </table>
		             

		    </div>
			</div>
			</div>
          <!--<div class="col-md-12 >
		  
            <div class="info-box">
              <div class="info-box-content">
                 <span class="pull-left text-info"><h5><b>{$LoctList.0.companyName}&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp; {$LoctList.0.branch_name}&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp; {$LoctList.0.gateway_id}&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;{$LoctList.0.sensorName}</b></h5></span>
              </div>
            </div>
          </div>-->
          </div>

<div class="row">
          <div class="col-12 col-sm-6 col-md-2">
            <div class="info-box card-outline card-primary">
              <span class="info-box-icon bg-info elevation-1"><i class="fa fa-rupee"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Today Cost&ensp;&ensp;&ensp;&ensp;</span>
                <span class="info-box-number">
                  {if $todayCostKWH.0.cost eq ''}0.00{else}{$todayCostKWH.0.cost}{/if}
                  <small></small>
                </span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-12 col-sm-6 col-md-2">
            <div class="info-box mb-2 card-outline card-danger">
              <span class="info-box-icon bg-danger elevation-1"><i class="fa fa-bolt"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Today KWH &ensp;&ensp;&ensp;&ensp;</span>
                <span class="info-box-number">{if $todayCostKWH.0.TOTAL_KWH eq ''}0.00{else}{$todayCostKWH.0.TOTAL_KWH}{/if}</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->

          <!-- fix for small devices only -->
          <div class="clearfix hidden-md-up"></div>

          <div class="col-12 col-sm-6 col-md-2">
            <div class="info-box mb-2 card-outline card-primary">
              <span class="info-box-icon bg-info elevation-1"><i class="fa fa-rupee"></i></span>

              <div class="info-box-content">
                <span class="info-box-text"><!--{$smarty.now|date_format:"%B"}-->This Month Cost</span>
                <span class="info-box-number"><!--{assign var="monthCost" value=$monthCostKWH.0.cost+$todayCostKWH.0.cost}-->{if $monthCostKWH.0.cost eq ''}0.00{else}{$monthCostKWH.0.cost}{/if}</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-12 col-sm-6 col-md-2">
            <div class="info-box mb-2 card-outline card-danger">
              <span class="info-box-icon bg-danger elevation-1"><i class="fa fa-bolt"></i></span>

              <div class="info-box-content">
                <span class="info-box-text"><!--{$smarty.now|date_format:"%B"}-->This Month KWH</span>
                <span class="info-box-number"><!--{assign var="monthKwh" value=$monthCostKWH.0.TOTAL_KWH+$todayCostKWH.0.TOTAL_KWH}-->{if $monthCostKWH.0.TOTAL_KWH eq ''}0.00{else}{$monthCostKWH.0.TOTAL_KWH}{/if}</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="clearfix hidden-md-up"></div>

          <div class="col-12 col-sm-6 col-md-2">
            <div class="info-box mb-2 card-outline card-primary">
              <span class="info-box-icon bg-info elevation-1"><i class="fa fa-rupee"></i></span>

              <div class="info-box-content">
                <span class="info-box-text"><!--{$smarty.now|date_format:"%B"}-->Last Month Cost</span>
                <span class="info-box-number">{if $LastMonthCostKWH.0.cost eq ''}0.00{else}{$LastMonthCostKWH.0.cost}{/if}</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-12 col-sm-6 col-md-2">
            <div class="info-box mb-2 card-outline card-danger">
              <span class="info-box-icon bg-danger elevation-1"><i class="fa fa-bolt"></i></span>

              <div class="info-box-content">
                <span class="info-box-text"><!--{$smarty.now|date_format:"%B"}-->Last Month KWH</span>
                <span class="info-box-number">{if $LastMonthCostKWH.0.TOTAL_KWH eq ''}0.00{else}{$LastMonthCostKWH.0.TOTAL_KWH}{/if}</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
         
        </div>
        <!-- /.row -->
            <div class="row">

			<div class="col-md-12">

            <div class="card card-outline card-primary">
<div class="card-header">
						<h3 class="card-title">
						<i class="fa fa-list"></i>
						&nbsp;&nbsp;List of Sub Energy Meter
						</h3>
						
						</div>
               <div class="card-body table-responsive no-padding">
			 <div class="row">

            

            
<input type="hidden" id="cid" name="cid" value="{if $smarty.get.companyId neq ""}{$smarty.get.companyId}{else}{$smarty.session.customerId}{/if}" />
    <input type="hidden" id="bid" name="bid" value="{$smarty.get.branchId}" />
     <input type="hidden" id="parentid" name="parentid" value="{$smarty.get.parent_id}" />
            <input type="hidden" value="{$Dashboard.0.segmentName}" />

   
<!--<div class="col-md-4" onclick="window.location='./meterDashboard.php?companyId={if $smarty.get.companyId neq ""}{$smarty.get.companyId}{else}{$smarty.session.CustomerId|base64_encode}{/if}&branchId={if $smarty.get.branchId neq ""}{$smarty.get.branchId}{else}{$smarty.session.branch_id|base64_encode}{/if}&sensorCode={$master_dtls.sensor_code|base64_encode}&gatewayCode={$master_dtls.gateway_code|base64_encode}'" style="cursor:pointer;">

            <div class="card card-widget widget-user-2">

              <div class="card card-outline card-primary">

			  <div class="widget-user-header bg-primary">
			  <div class="widget-user-image">
                  <img class="img-circle elevation-2" src="images/meterImage.png" alt="User Avatar">
                </div>
			   <h5 class="widget-user-username" style="text-align:left"><b>{$master_dtls.feeder_name}</b><span class="float-right badge bg-warning"></span></h5>

			  </div>
			  </div>
			   
				  <div class="card-footer p-0">
                <ul class="nav flex-column">
								  <li class="nav-item">
                    <a href="#" class="nav-link" style="text-decoration:none;color:black">
                     <b> Status  -  {$master_dtls.recorded_date_time|date_format:"%d-%b-%Y %I:%M %p"} </b><span class="float-right badge bg-success">Last Logged</span>
                    </a>
                  </li>

				{foreach from=$CostKWH item=costKwh}
					 {if $costKwh.sensor_code eq $master_dtls.sensor_code}
					   <li class="nav-item">
						<a href="#" class="nav-link" style="text-decoration:none;color:black">
						  <b>Today KWH</b> <span class="float-right badge bg-success">{$costKwh.TOTAL_KWH}</span>
						</a>
					   </li>
					   <li class="nav-item">
						<a href="#" class="nav-link" style="text-decoration:none;color:black">
						  <b>Today Cost</b> <span class="float-right badge bg-success">Rs.{$costKwh.cost}</span>
						</a>
					   </li>
					  {/if}
				  {/foreach}
                </ul>
              </div>
			  </div>
			  </div>-->
			  <div id="list_books" class="col-12">
<table id="example" class="table table-bordered table-hover">
                <thead>
                <tr>
    			  <th class="slNo" rowspan="2" >#</th>
                  <th class="name" rowspan="2">Place Of Installation</th>
                  <th class="code" rowspan="2">Gateway</th>
				   <th class="status" rowspan="2">Status</th>
                  <th  colspan="2" class="code" >Today</th>
                  <th class="action" rowspan="2">Date Time</th>
                  <th class="last" rowspan="2">Last Comm</th>
                  
          
                </tr>
                <tr>
    			 
                  <th class="cost" >KWH</th>
                  <th class="cost" >Cost</th>
                  
                </tr>
                </thead>
                <tbody>
				{foreach from=$MeterList item=List}
                {assign var=pid value=$List.feeder_master_id|base64_encode}
                <tr id="{$j++}">
				 <td >{$j}</td>
                 <td><a href="meterDashboard.php?companyId={$smarty.get.companyId}&branchId={$smarty.get.branchId}&sensorCode={$List.sensor_code|base64_encode}&gatewayCode={$List.gateway_code|base64_encode}"><span style="color:#000000;" title="Meter Details" class="uline">{$List.feeder_name}</span></a>&ensp; &ensp;{if $List.feeder_type eq "Main Meter"}<a href="subdashboard.php?parent_id={$pid}&companyId={$smarty.get.companyId}&branchId={$smarty.get.branchId}"><i class="fa fa-sitemap" aria-hidden="true" title="Submeter List"></i></a>{/if}</td>
                 <td >{$List.gateway_code}</td>
				 
				 
		
				
				<td>
				{foreach from=$gateList item=gate}
				
				{if $gate.gateway_code neq 'YMN-1' && $gate.gateway_code eq $List.gateway_code && $gate.gateway_date_time gte $dateSec|date_format:'%Y-%m-%d %H:%M:%S' }
                 <img  src="./images/on.png">
                 {assign var="tog" value='1'}
                {elseif $gate.gateway_code neq 'YMN-1' && $gate.gateway_code eq $List.gateway_code && $gate.gateway_date_time lt $dateSec|date_format:'%Y-%m-%d %H:%M:%S'}
                <img  src="./images/off.png">
                 {assign var="tog" value='1'}
                {/if}
                
                {if $gate.gateway_code eq 'YMN-1' && $gate.gateway_code eq $List.gateway_code && $gate.gateway_date_time gte $dateSec1|date_format:'%Y-%m-%d %H:%M:%S' }
                 <img  src="./images/on.png">
                 {assign var="tog" value='1'}
                {elseif $gate.gateway_code eq 'YMN-1' && $gate.gateway_code eq $List.gateway_code && $gate.gateway_date_time lt $dateSec1|date_format:'%Y-%m-%d %H:%M:%S'}
                <img  src="./images/off.png">
                 {assign var="tog" value='1'}
                {/if}
               
                {/foreach}
                {if $tog eq ''}
                <img  src="./images/off.png">
                {/if}
                 {assign var="tog" value=''}
                </td>
				
				
			
                 
             {foreach from=$CostKWH item=costKwh}
            {assign var="tkwh" value=$tkwh+$costKwh.TOTAL_KWH}
             {assign var="tcost" value=$tcost+$costKwh.cost}
					 {if $costKwh.sensor_code eq $List.sensor_code}
                 <td align="right">{$costKwh.TOTAL_KWH} </td>
                 <td align="right">{$costKwh.cost} </td>
                  {/if}
                  {foreachelse}
                  <td align="right">0.00</td>
                 <td align="right">0.00</td>
				  {/foreach}
				  <td>{$List.recorded_date_time|date_format:"%d-%b-%Y %I:%M:%S %p"}</td>
		       <td id="{$j}"><script type="text/javascript">secondsToDhms('{$List.secs}','{$j}');</script> ago</td>
			   
            
                </tr>
                {foreachelse}
                <tr><td colspan="8"><center>No Records Found</center></td></tr>
                {/foreach}
               
               
                </tbody>
                <tr>
                     {assign var="kwh" value=$todayCostKWH.0.TOTAL_KWH-$todayCostKWHSub.0.TOTAL_KWH}
                 {assign var="cost" value=$todayCostKWH.0.cost-$todayCostKWHSub.0.cost}
                 {assign var="tkwh" value=$tkwh+$kwh}
                 {assign var="tcost" value=$tcost+$cost}
                    <td>{$j+1}</td>
                    <td>Others</td>
                    <td>{$List.gateway_code}</td>
                   <!-- <td><img  src="./images/off.png"></td>-->
                    	<td>
				{foreach from=$gateList item=gate}
				
				{if $gate.gateway_code neq 'YMN-1' && $gate.gateway_code eq $List.gateway_code && $gate.gateway_date_time gte $dateSec|date_format:'%Y-%m-%d %H:%M:%S' }
                 <img  src="./images/on.png">
                 {assign var="tog" value='1'}
                {elseif $gate.gateway_code neq 'YMN-1' && $gate.gateway_code eq $List.gateway_code && $gate.gateway_date_time lt $dateSec|date_format:'%Y-%m-%d %H:%M:%S'}
                <img  src="./images/off.png">
                 {assign var="tog" value='1'}
                {/if}
                
                {if $gate.gateway_code eq 'YMN-1' && $gate.gateway_code eq $List.gateway_code && $gate.gateway_date_time gte $dateSec1|date_format:'%Y-%m-%d %H:%M:%S' }
                 <img  src="./images/on.png">
                 {assign var="tog" value='1'}
                {elseif $gate.gateway_code eq 'YMN-1' && $gate.gateway_code eq $List.gateway_code && $gate.gateway_date_time lt $dateSec1|date_format:'%Y-%m-%d %H:%M:%S'}
                <img  src="./images/off.png">
                 {assign var="tog" value='1'}
                {/if}
               
                {/foreach}
                {if $tog eq ''}
                <img  src="./images/off.png">
                {/if}
                 {assign var="tog" value=''}
                </td>
                    <td align="right">{$kwh}</td>
                    <td align="right">{$cost}</td>
                    <td>{$List.recorded_date_time|date_format:"%d-%b-%Y %I:%M:%S %p"}</td>
                    <td id="otot"><script type="text/javascript">secondsToDhms('{$List.secs}','otot');</script> ago</td>
                     
                    </tr>
                     <tr>
                    <td colspan="4" align="right"><b>Total</b></td>
                    <td align="right"><b><span id="tk"><script type="text/javascript">includecomma1('{$tkwh}','tk');</script></span></b></td>
                    <td align="right"><b> <span id="tc"><script type="text/javascript">includecomma1('{$tcost}','tc');</script></span></b></td>
                    <td colspan="2"></td>
                    </tr>
              </table>
              </div>
        


</div>
</div>
									<div class="card-body table-responsive">

            <div class="row">

          
        </div>

        </div>


								

        

        

	  

	   

        


      </div>

    </div>

  </div>

  </div>

  </div>

  </div>
</body>
 {literal}
 <style>
  .slNo
 {
 width:3%;
 }
 .name
 {
 width:18%;
 }
 .gate
 {
 width:10%;
 }
 .status
 {
 width:5%;
 }
 .code
 {
 width:10%;
 }
 .cost
 {
 width:5%;
 }
 .action
 {
 width:15%;
 }
 .last
 {
 width:11%;
 }
 .uline
 {
 text-decoration:underline;
 }
 </style>
  <script type="text/javascript">
 function doOnLoad()
 {
 setInterval(Add_Item, 3000);
 }
 </script>
 <script type="text/javascript">
  $("input[data-bootstrap-switch]").each(function(){
      $(this).bootstrapSwitch('state', $(this).prop('checked'));
    });
	</script>
	  <script type="text/javascript">
	function Add_Item()
{
var cid =$('#cid').val() ;
var bid =$('#bid').val() ;//alert(bid)
var parentid =$('#parentid').val() ;
$.ajax({
		type: "POST",
		url: "getSubTableData.php",
		data: {cid:cid,bid:bid,parentid:parentid},
		success: function(data) {
		$("#list_books").html(data);
		}
		});
}
	</script>
 {/literal}

  {include file="footer.tpl"}