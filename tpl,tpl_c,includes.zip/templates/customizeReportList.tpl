	<div class="content-wrapper">
		<section class="content-header">
			<div class="card">
				<div class="card-header">
					<table style="margin-bottom:-10px;">
					<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
					<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
					{if $branchDetail.0.branch_name neq ""} 
					<td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}</td>
					<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>{/if}
					<td style="font-size:15PX;font-weight: bold;">List Customized Report</font>&nbsp;</td></tr>
					<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
					<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{if $branchDetail.0.branch_name neq ""}	<td style="color:#999999;font-size:10PX;">Branch Name</td>{/if}
					<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
					</tr>
					</table>
				</div>
			</div>
			<form name="shiftList" method="post" id="shiftList">
			<div class="row">
					<div class="col-12">
						<div class="card">
						{if $SuccessMessage neq "" || $ErrorMessage neq ""}
							<div class="card-body">
							{if $SuccessMessage neq ""}
								<div class="isa_success">
								<i class="fa fa-check"></i>
								{$SuccessMessage}		 
								</div>
							{/if}
							{if $ErrorMessage neq ""}
								<div class="isa_error">
								<i class="fa fa-check"></i>
								{$ErrorMessage}		 
								</div>
							{/if}
							</div>
						{/if}
						<div class="card-body table-responsive">
						<a href="customizeReportAddEdit.php"><button type="button" style="float:right;margin-top:-6PX" class="btn btn-info"> Create Customized Report</button></a><span style="float:right">&ensp;</span>
						<span style="float:right;">&ensp;</span>
					{if $GetReportList.0.reportName eq ""}<br /><br />{/if}
							<table id="example" class="table table-bordered table-hover">
								<thead>
								<tr>
								<th class="slNo">#</th>
								<th class="name">Report Name</th>
								<th class="isactive">Status</th>
								<th class="action">Action</th>
								</tr>
								</thead>
								<tbody>
								{foreach from=$GetReportList item=List}
								<tr id="{$j++}">
								<td >{$j}</td>
								<td>{$List.reportName}</td>
								<td align="center">{if $List.isActive eq "1"}<span style="color:#009900"><b>Active</b></span>{else}<span style="color:#FF0000;"><b>Inactive</b></span>{/if}</td>
								<td align="right">
								<a href="#"  onClick="Javascript:editCats('{$List.slNo}','{$List.company_id}','{$List.branch_id}','Update=Y')" title="Edit"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <a href="customizeReportView.php?companyId={$List.company_id|base64_encode}&branchId={$List.branch_id|base64_encode}&slNo={$List.slNo|base64_encode}"  title="View"><i class="fa fa-search-plus"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
								<a href="#"  onClick="Javascript:deleteCats('{$List.slNo}','{$List.company_id}','{$List.branch_id}')" title="Delete"><i class="fa fa-trash"></i></a>
								</td>
								</tr>
								{foreachelse}
								<tr><td colspan="6"><center>No Records Found</center></td></tr>
								{/foreach}
								</tbody>
							</table>
						</div>
						</div>
					</div>
			</form>
		</section>
	</div>
	{literal}
	<style>
	.slNo{
	width:5%;
	}
	.code{
	width:10%;
	}
	.type{
	width:15%;
	}
	.name{
	width:20%;
	}
	.isactive{
	width:10%;
	text-align:center;
	
	}
	.action{

	text-align:right;
	width:15%;
	}
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>
	<script type="text/javascript">
	$(document).ready(function (){
	
	var table = $('#example').DataTable({
	"ordering" : false,
	language: {
	"infoFiltered": "",
	search: "_INPUT_",
	searchPlaceholder: "Search..."
	},
	dom: '<"pull-left" f><bottom>p',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: '<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p',
	//dom: '<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p',
	
	initComplete: function(){
	//  $("div.toolbar").html('<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>');   
	}       
	}); 
	}); 
	function editCats(slNoIdent,compIdent,branIdent,Update) {
	var sid = btoa(slNoIdent);  var comId = btoa(compIdent); var bId = btoa(branIdent);
	FormName		= document.shiftList;
	FormName.action ='customizeReportAddEdit.php?slNo='+sid+'&companyId='+comId+'&branchId='+bId+'&Update=y';
	FormName.submit();
	}
	</script>
	<script type="text/javascript">
	function deleteCats(slNoIdent,compIdent,branIdent){
	var sid = btoa(slNoIdent); var comId = btoa(compIdent);var bId = btoa(branIdent);
	if(confirm("Are you sure to Delete this Shift?")){
	FormName		= document.shiftList;
	FormName.action= 'customizeReportList.php?companyId='+comId+'&branchId='+bId+'&slNo='+sid+'&Del=delete';
	FormName.submit();
	}
	}
	</script>
    <script type="text/javascript">
	function viewCats(slNoIdent,compIdent,branIdent){
	var sid = btoa(slNoIdent); var comId = btoa(compIdent);var bId = btoa(branIdent);
	if(confirm("Are you sure to Delete this Shift?")){
	FormName		= document.shiftList;
	FormName.action= 'customizeReportView.php?companyId='+comId+'&branchId='+bId+'&slNo='+sid+'&Del=delete';
	FormName.submit();
	}
	}
	</script>
	{/literal}
	{include file="footer.tpl"}