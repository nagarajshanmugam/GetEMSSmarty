	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">{if $ListBranchGet.0.branch_name neq ""}{$ListBranchGet.0.branch_name}{else}{$smarty.session.branch_name}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">{if $smarty.get.locId eq ""}Create Location{else}Edit Location{/if}</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:10PX;color:#999999;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			<a href="locationList.php?companyId={$smarty.get.companyId}&branchId={$smarty.get.branchId}"><button type="button" style="float:right;margin-top:-40PX" class="btn btn-primary">List Location</button></a>
			</div>
				{if $SuccessMessage neq "" || $ErrorMessage neq ""}
					<div class="card-body">
					{if $SuccessMessage neq ""}
						<div class="isa_success">
						<i class="fa fa-check"></i>
						{$SuccessMessage}		 
						</div>
					{/if}
					{if $ErrorMessage neq ""}
						<div class="isa_error">
						<i class="fa fa-check"></i>
						{$ErrorMessage}		 
						</div>
					{/if}
					</div>
				{/if}
		</div>    
		<div class="card">
			<div class="card-body">
				<form role="form" name="locationRegForm" id="locationRegForm" method="post" onsubmit="return createValidation();" >
					<input type="hidden" name="hdAction" />
					<input type="hidden" id="check_id" name="check_id" value="{$smarty.post.check_id}">
					<input type="hidden" id="checkVal" name="checkVal" value="{$smarty.post.checkVal}" />
					<input type="hidden" id="company_id" name="company_id" value="{$comId}" />
					<input type="hidden" id="platId" name="platId" value="{$ListEditView.0.slNo}" />
					<input type="hidden" id="updateYesNo" name="updateYesNo" value="{$otherLocationId}" />
					<input type="hidden" id="locMasId" name="locMasId" value="{$smarty.get.locId|base64_decode}" />
					<input type="hidden" id="changeSensorId" name="changeSensorId" value="" />
					<input type="hidden" id="PreviousSensorId" name="PreviousSensorId" value="{$ListEditView.0.sensor_id}" />
					<div class="row">
					{if $smarty.get.locId}
						<div class="form-group col-md-6">
							<label for="exampleInputgatewayId">Location Code <span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm" id="locationCode" name="locationCode" placeholder="Enter Location Code" value="{if $ListEditView.0.location_code neq ""}{$ListEditView.0.location_code}{else}{$smarty.post.locationCode}{/if}" tabindex="1" readonly autocomplete="Off">
						</div>
					{/if}		
						<div class="form-group col-md-6">
							<label for="exampleInputserialNo">Location Name <span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm" id="locationName" name="locationName" placeholder="Enter Location Name" value="{if $ListEditView.0.location_name neq ""}{$ListEditView.0.location_name}{else}{$smarty.post.locationName}{/if}" tabindex="2" autocomplete="Off">
						</div>
						<div class="form-group col-md-6">
						<label for="exampleInputmodel">Sensor <span style="color:red;">*</span></label>

							<select id="sensor" name="sensor" class="form-control form-control-sm" tabindex="7" onchange="sensorCheck(this.value);">
							<option value="">--- Select Sensor ---</option>
							{foreach from=$ListSensorView item=sensorDet}
							<option value="{$sensorDet.slNo}"
							{if isset($smarty.post.sensor) && $smarty.post.sensor == $sensorDet.slNo}
							selected="selected"
							{elseif $ListEditView.0.sensor_id == $sensorDet.slNo}
							selected="selected"
							{/if}
							>
							{$sensorDet.sensorName}
							</option>
							{/foreach}
							</select>
						</div>
						<div class="form-group col-md-6">
						<label for="exampleInputmodel">IOT Device <span style="color:red;">*</span></label>
						<select  id="iotDevice" name="iotDevice" class="form-control form-control-sm"  tabindex="7" onchange="ChangeMake(this.value);">
						<option value="">--- Select IOT Device ---</option>
                        {foreach from=$ListGatewayView item=gatewayDet}
							
						<option value="{$gatewayDet.gateway_sl_no}"
						{if isset($smarty.post.iotDevice) && $smarty.post.iotDevice == $gatewayDet.gateway_sl_no}
							selected="selected"
						{elseif $ListEditView.0.iot_id == $gatewayDet.gateway_sl_no}
							selected="selected"
						{/if}
						>
						{$gatewayDet.gateway_id}						
						</option>
						{/foreach}
						</select>
						</div>
                           <div class="form-group col-md-6">
							<label for="exampleInputgatewayId">Branch <span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm" id="branch" name="branch" placeholder="Enter Branch" value="{if $ListBranchView.0.branch_name neq ''}{$ListBranchView.0.branch_name}{/if}" tabindex="1" readonly >
						</div>
						<div class="form-group col-md-6">
							<div class="custom-control custom-checkbox">
							{if $ListEditView.0.is_active eq '1'}
								<input class="custom-control-input" type="checkbox" id="customCheckbox2"  name="customCheckbox2" tabindex="7" checked="checked">
								<label for="customCheckbox2" class="custom-control-label">Is Active</label>
							{elseif $ListEditView.0.is_active eq '0'}
								<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="7">
								<label for="customCheckbox2" class="custom-control-label">Is Active</label>
							{else}
								<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="7" checked="checked">
								<label for="customCheckbox2" class="custom-control-label">Is Active</label>
							{/if}
							</div>
							<input id="created_by" name="created_by" class="date-picker form-control" type="hidden" value="{$smarty.session.UserName}" readonly="true">
							<input type="hidden" class="form-control" id="timestamp" name="timestamp" value="{$smarty.now|date_format:'%Y-%m-%d &amp; %H:%M:%S'}">
							<input type="hidden" class="form-control" id="created_time" name="created_time" placeholder="Time" Value="{$smarty.now|date_format:'%I:%M:%S %p'}">
						</div>
					</div>
					<div align="center">
					<input type="submit" value="Submit" class="btn btn-create" tabindex="8" />
					</div>
				</form>
			</div>
		</div>
	</div>	
	</section>
	</div>
	{literal}
	<script type="text/javascript">

	var previousSensorValue = $('#PreviousSensorId').val();   // global variable

function sensorCheck(postsensorId){

    // Set the value in the input
    $('#changeSensorId').val(postsensorId);

    // Now get the updated value
    var postsensorIdVal = $('#changeSensorId').val();

    // Get location value
    var locationMasId = $('#locMasId').val();

    // Show alerts
    //alert("Sensor Id"+postsensorIdVal);
    //alert("Location Id"+locationMasId);

    // Ajax call
    $.ajax({
        type: "POST",
        url: "ajaxLocationSensor.php",
        data: {
            postsensorVal: postsensorIdVal,
            locMas: locationMasId
        },
        dataType: "JSON",
        cache: false,
        success: function(result){
            //alert(result);
            var len = result.length;
			var existingLoc = result[0]["location_master_id"];
			var existingLocCode = result[0]["location_code"];
			
			if (existingLoc !== '' && existingLoc !== null) {

            // Show confirmation alert
            if (confirm("This sensor is already active in "+existingLocCode+" location.Do you want to update it?")) {
                // User clicked OK
                // Call another function or continue update
                //alert("Updating...");

            } else {
                // User clicked Cancel
                alert("Update cancelled.");
				// Cancel → reset to previous selection
                $('#sensor').val(previousSensorValue);
                return false;
            }
        }

        },
        error: function(result) {
            alert('error');
        }
    });

}
</script>

		<script type="text/javascript">
		function createValidation()
		{
			//var locationCode = $('#locationCode').val();
			var locationName = $('#locationName').val();
			var sensor = $('#sensor').val();
			var iotDevice = $('#iotDevice').val();
			var branch = $('#branch').val();
			var isActive = document.getElementById("customCheckbox2").checked;
		if (isActive == false) 
		{
			document.getElementById('checkVal').value='0';
		}
		else
		{
			document.getElementById('checkVal').value='1';
		}
		
			$(".error").remove();
		/* if (locationCode.length < 1) {
			$('#locationCode').after('<span class="error">This field is required</span>');
			$('#locationCode').focus();
			return false;					
		}else */
		if (locationName < 1) {
			$('#locationName').after('<span class="error">This field is required</span>');
			$('#locationName').focus();
			return false;					
		}
		else if (sensor < 1) {
			$('#sensor').after('<span class="error">This field is required</span>');
			$('#sensor').focus();
			return false;					
		}
		else if (iotDevice < 1) {
			$('#iotDevice').after('<span class="error">This field is required</span>');
			$('#iotDevice').focus();
			return false;					
		}
		else if (branch < 1) {
			$('#branch').after('<span class="error">This field is required</span>');
			$('#branch').focus();
			return false;					
		}
		
			FormName		= document.locationRegForm;
			FormName.method	= "POST";
			FormName.submit();
		}
		
		function GoBack()
		{
			window.history.back();
		}
		</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	{/literal}
	{include file="footer.tpl"}