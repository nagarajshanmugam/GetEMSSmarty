   {literal}

 <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <!--<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">-->
   <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Select2 -->
  <link rel="stylesheet" href="plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
  <!-- Tempusdominus Bbootstrap 4 -->
  <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
   <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.css">
   <!-- JQVMap -->
  <link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
 <!-- daterange picker -->
  <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="plugins/summernote/summernote-bs4.css">
    <!-- SweetAlert2 -->
  <link rel="stylesheet" href="plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
  <!-- Toastr -->
  <link rel="stylesheet" href="plugins/toastr/toastr.min.css">
  <!-- Google Font: Source Sans Pro -->
 <!-- <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">--->
  <link href="dist/css/fontsgoogleapis.css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
<!-- External Style file-->
 <link rel="stylesheet" href="dist/css/styleems.css">

  <script src="plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Select2 -->
<script src="plugins/select2/js/select2.full.min.js"></script>
<!-- InputMask -->
<script src="plugins/moment/moment.min.js"></script>
<script src="plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>
<!-- date-range-picker -->
<script src="plugins/daterangepicker/daterangepicker.js"></script>
<!-- ChartJS -->
<script src="plugins/chart.js/Chart.min.js"></script>
<!-- Sparkline -->
<script src="plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<script src="plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<!-- jQuery Knob Chart -->
<script src="plugins/jquery-knob/jquery.knob.min.js"></script>
<script src="plugins/datatables/jquery.dataTables.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>

<!-- Tempusdominus Bootstrap 4 -->
<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="plugins/sweetalert2/sweetalert2.min.js"></script>
<!-- Toastr -->
<script src="plugins/toastr/toastr.min.js"></script>
<script src="dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
  <script src="https://www.amcharts.com/lib/3/amcharts.js"></script>
<script src="https://www.amcharts.com/lib/3/serial.js"></script>
<script src="https://www.amcharts.com/lib/3/themes/light.js"></script>
<style type="text/css">
#chartdiv {
	width	: 100%;
	height	: 500px;
}
</style>
<script>
  $(function () {
    $('#example1').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : true,
      'ordering'    : false,
      'info'        : false,
	  'pageLength': 50,
      'autoWidth'   : false
    })
  })
</script>
<style type="text/css">
form {

  overflow-x: hidden;
}
</style>
	{/literal}
  
   
		   <form method="POST" role="form" name="dataraange">
         
          <textarea id="mutiLinedataProvider" name="mutiLinedataProvider" style="display:none;">{$ChartData}</textarea>
          <div class="row">
           <div class="form-group col-md-3">
                    <label for="exampleInputserialNo">From Date <span style="color:red;">*</span></label>
                    <input type="text" size="15" id="date1" name="date1" autocomplete="OFF" class="form-control form-control-sm" readonly="true" value= "{if $fdate neq ""}{$fdate|date_format:'%e-%b-%Y'}{else}{$smarty.now|date_format:'%e-%b-%Y'}{/if}"/>
                  </div>
                  
                  <div class="form-group col-md-3">
                    <label for="exampleInputserialNo">To Date <span style="color:red;">*</span></label>
                    <input type="text" size="15" id="date2" name="date2" autocomplete="OFF" class="form-control form-control-sm" readonly="true" value= "{if $tdate neq ""}{$tdate|date_format:'%e-%b-%Y'}{else}{$smarty.now|date_format:'%e-%b-%Y'}{/if}"/>
                  </div>
 <div class="form-group col-md-3"  style="margin-top:8px;"><br />
           <input name="submit" type="submit" class="btn btn-sm" onClick="formvalidate();" value="Submit" style="color:#FFFFFF; background-color:#17a2b8;"/>
			</div>
           </div>
		   </form>
	<center>	 <table class="table table-bordered table-hover" >
        <tr >
          <th colspan="5" bgcolor="#17a2b8" style="color:#FFFFFF" class="style3 style1" scope="row"><span class="style3"> Historical Trend Graph From  &nbsp;&nbsp;{if $fdate neq ""}{$fdate|date_format:'%e-%b-%Y'}{else}{$smarty.now|date_format:'%e-%b-%Y'}{/if}&nbsp;&nbsp;
                  &nbsp;&nbsp;To &nbsp;&nbsp;{if $tdate neq ""}{$tdate|date_format:'%e-%b-%Y'}{else}{$smarty.now|date_format:'%e-%b-%Y'}{/if}&nbsp;&nbsp;<?php 
	 </span></th>
        </tr></table></center>
		
		<div id="chartdiv" style="height:500px; width:100%;">
		
		</div>		
		  <div class="clear"></div>

  <!-- /.content-wrapper -->
  {literal}
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script>
  $( function() {
    $( "#date1" ).datepicker({changeMonth: true,
    changeYear: true,maxDate: '0',dateFormat:'yy-mm-dd'});
	 $( "#date2" ).datepicker({changeMonth: true,
    changeYear: true,maxDate: '0',dateFormat:'yy-mm-dd'});
  } );
  </script>
<script type="text/javascript">
function createValidation(){
var segmentCode = $('#segmentCode').val();
var segmentName = $('#segmentName').val();
var isActive = document.getElementById("customCheckbox2").checked;

if (isActive == false) 
{
document.getElementById('checkVal').value='0';
}
else
{
document.getElementById('checkVal').value='1';
}

$(".error").remove();
if (segmentCode.length < 1) {
$('#segmentCode').after('<span class="error">This field is required</span>');
$('#segmentCode').focus();
return false;					
}
else if (segmentName < 1) {
$('#segmentName').after('<span class="error">This field is required</span>');
$('#segmentName').focus();
return false;					
}

FormName		= document.gatewayRegForm;
FormName.method	= "POST";
FormName.submit();
}
 
  function GoBack()
{
window.history.back();
}


var disp = document.getElementById('mutiLinedataProvider').value;//alert(disp);
var disp = JSON.parse(disp);//alert(disp);
var chart = AmCharts.makeChart("chartdiv", {
    "type": "serial",
    "theme": "light",
    "marginTop":0,
    "marginRight": 80,
    "dataProvider":disp,
    "valueAxes": [{
        "axisAlpha": 0,
        "position": "left"
    }],
    "graphs": [{
        "id":"g1",
        "balloonText": "TM :[[category]]<br><b><span style='font-size:14px;'> temperature_c  : [[value]]</span></b>",
        "bullet": "round",
        "bulletSize": 2,         
        "lineColor": "Red",
        "lineThickness": 1,
        "negativeLineColor": "#637bb6",
        "type": "smoothedLine",
        "valueField": "temperature_c"
    },{
        "id":"g2",
        "balloonText": "TM :[[category]]<br><b><span style='font-size:14px;'> temperature_f : [[value]]</span></b>",
        "bullet": "round",
        "bulletSize": 2,         
        "lineColor": "Yellow",
        "lineThickness": 1,
        "negativeLineColor": "#637bb6",
        "type": "smoothedLine",
        "valueField": "temperature_f"
    },{
        "id":"g3",
        "balloonText": "TM :[[category]]<br><b><span style='font-size:14px;'> Humidity  : [[value]]</span></b>",
        "bullet": "round",
        "bulletSize": 2,         
        "lineColor": "Blue",
        "lineThickness": 1,
        "negativeLineColor": "#637bb6",
        "type": "smoothedLine",
        "valueField": "humidity"
    }],
    "chartCursor": {
        "categoryBalloonDateFormat": "YYYY  ",
        "cursorAlpha": 0,
        "valueLineEnabled":true,
        "valueLineBalloonEnabled":true,
        "valueLineAlpha":0.5,
        "labelRotation": 90,
        "fullWidth":true
    },
    "categoryField": "tm",
    "chartScrollbar": {
        "graph":"g1",
        "gridAlpha":0,
        "color":"#888888",
        "scrollbarHeight":55,
        "backgroundAlpha":0,
        "selectedBackgroundAlpha":0.1,
        "selectedBackgroundColor":"#888888",
        "graphFillAlpha":0,
        "autoGridCount":false,
        "selectedGraphFillAlpha":0,
        "graphLineAlpha":0.2,
        "graphLineColor":"#c2c2c2",
        "selectedGraphLineColor":"#888888",
        "selectedGraphLineAlpha":1
    },
    "categoryAxis": {
        "parseDates": false,
        "minorGridAlpha": 0.1,
		"labelRotation": 90,
        "minorGridEnabled": true
    },
	
    "export": {
        "enabled": true
    }
});
  </script>
 
  <style>
.isa_success
{
color:#4F8A10;
background-color:#DFF2BF;
}
.error
{
color:#D8000C;
/*background-color:#FFBABA;*/
}
.isa_error
{
color:#D8000C;
background-color:#FFBABA;
}
.isa_success i,.isa_error i
{
margin:10px 22px;
font-size:2em;
/*vertical-align:middle;*/
}
.required
{
color:#FF0000;
}
</style>
  {/literal}
