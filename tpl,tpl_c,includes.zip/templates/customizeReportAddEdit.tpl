		<body onload="GetSensorList();">
        <div class="content-wrapper">
			<section class="content-header">
			<div class="card">
				<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				{if $branchDetail.0.branch_name neq ""}  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}</td>{/if}
                     <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;"> {if $smarty.get.slNo eq ''}Create Customized Report{else}Edit Customized Report{/if}&nbsp;</td>
				</tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{if $branchDetail.0.branch_name neq ""}
				<td style="font-size:10PX;color:#999999;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{/if}
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>				
				</div>
			</div>
			</section>
			<section class="content">
				<div class="card">
				<div class="">
				<a href="customizeReportList.php"><button type="button" style="float:right;margin-top:6PX;margin-right:16px;" class="btn btn-info"> List Customized Report</button></a>
				</div>
                {if $SuccessMessage neq ""}
				<div class="card-body">
					<div class="isa_success">
					<i class="fa fa-check"></i>
					{$SuccessMessage}		 
					</div>
				</div>
			{/if}
			{if $ErrorMessage neq ""}
				<div class="card-body">
					<div class="isa_error">
					<i class="fa fa-check"></i>
					{$ErrorMessage}		 
					</div>
				</div>
			{/if}
					<div class="card-body">
						<form name="locationRegForm" id="locationRegForm" method="post" onsubmit="return createValidation();" >
							<input type="hidden" name="hdAction" id="hdAction" />
							<input type="hidden" id="check_id" name="check_id" value="{$smarty.post.check_id}">
							<input type="hidden" id="checkVal" name="checkVal" value="{$smarty.post.checkVal}" />
                            <input type="hidden" id="item_id" name="item_id" value="{$smarty.post.item_id}">
                            <input type="hidden" id="slNoReport" name="slNoReport" value="{$ListEditMaster.0.slNo}" />
                            <input type="hidden" class="form-control form-control-sm" id="branchId" name="branchId"  value="{if $ListEditMaster.0.branch_id neq ""}{$ListEditMaster.0.branch_id}{/if}">
                            <input type="hidden" class="form-control form-control-sm" id="companyId" name="companyId"  value="{if $ListEditMaster.0.company_id neq ""}{$ListEditMaster.0.company_id}{/if}">
							<div class="row">
							<div class="form-group col-md-6">
								<label for="exampleInputlocationName">Report Name <span style="color:red;">*</span></label>
								<input type="text" class="form-control form-control-sm" id="reportName" name="reportName" placeholder="Enter Report Name" value="{if $ListEditMaster.0.reportName neq ""}{$ListEditMaster.0.reportName}{/if}" autocomplete="off">
                                <input id="created_by" name="created_by" class="date-picker form-control" type="hidden" value="{$smarty.session.UserName}" readonly="true">
							</div>
                            
                            <div class="form-group col-md-6">
								<label for="exampleInputlocationName">Branch Name <span style="color:red;">*</span></label>
								 {if $smarty.session.USER_GROUP eq 'Branch Admin' || $smarty.session.USER_GROUP eq 'Branch User'}
						<select class="form-control form-control-sm" id="branchName" name="branchName"  tabindex="1" disabled>
						    {else}
						    <select class="form-control form-control-sm" id="branchName" name="branchName"  tabindex="1" onchange="GetSensorList();">
						    {/if}
						    <option value="">--Select Branch--</option>
						    {if $smarty.session.USER_GROUP eq 'Branch Admin' || $smarty.session.USER_GROUP eq 'Branch User'}
						    <option value="{$branchDetail.0.sl_no}" selected="selected">{$branchDetail.0.branch_name}</option>
						    {else}
						{foreach from=$ListBranch item=ListBnh}
						{if $smarty.post.branchName eq ''}
						{if $smarty.get.branchId|base64_decode eq $ListBnh.sl_no} <option value="{$ListBnh.sl_no}" selected="selected">{$ListBnh.branch_name}</option>{/if}
						{if $smarty.get.branchId|base64_decode neq $ListBnh.sl_no}<option value="{$ListBnh.sl_no}">{$ListBnh.branch_name}</option>{/if}
						{else}
						{if $smarty.post.branchName eq $ListBnh.sl_no && $smarty.get.branchId|base64_decode eq $ListBnh.sl_no} <option value="{$ListBnh.sl_no}" selected="selected">{$ListBnh.branch_name}</option>{/if}
						{if $smarty.post.branchName neq $ListBnh.sl_no}<option value="{$ListBnh.sl_no}">{$ListBnh.branch_name}</option>{/if}
						{/if}
						{/foreach}
						{/if}
						</select>
							</div>
							
                            <div class="form-group col-md-6" style="display:none;">
							<div class="custom-control custom-checkbox">
							{if $ListEditMaster.0.isActive eq "1"}
								<input class="custom-control-input" type="checkbox" id="activec"  name="activec" tabindex="8" checked="checked">
								<label for="activec" class="custom-control-label">Is Active <span class="required"><b>*</b></span></label>
							{else}
								<input class="custom-control-input" type="checkbox" id="activec" name="activec" tabindex="8" checked="checked">
								<label for="activec" class="custom-control-label">Is Active <span class="required"><b>*</b></span></label>
							{/if}
							
							</div>
						</div>
							</div>
                            
                            <!--<div class="row">
                             {foreach from=$GetSensorView item=sensor}
							<div class="form-group col-md-3">
                            <div class="custom-control custom-checkbox">
                             <input class="custom-control-input" type="checkbox" id="sensorName[{$sensor.slNo}]"  name="sensorName" tabindex="8" value="{$sensor.slNo}">
								<label for="sensorName[{$sensor.slNo}]" class="custom-control-label">{$sensor.sensorName}</label>
                                </div>
                            </div>
                            {/foreach}
                            </div>-->
                           <div id='list_books'></div>
                          
                            
                           
                            <br>
							<div align="center">
							<center>
							<input type="submit" value="Submit" class="btn btn-create"  onclick="createValidation();" />
							</center>
						</div>
						</form>
					</div>
				
				</div>
			</div>	
            </body>	
		</section>
	</div>
	{literal}
    <script type="text/javascript">
	$(document).ready(function() {
$('#submitButton').on('click', function() {
	this.form.submit();
});
});
	</script>
	<script type="text/javascript">
	function createValidation(){
	var reportName = $('#reportName').val();
	var isActive = document.getElementById("activec").checked;
var bar_code = [];
    $.each($("input[name='sensorName']:checked"), function(){ 
	      bar_code.push($(this).val());  
	});
	id=bar_code.join(",");
	
	document.getElementById("item_id").value = id;
	
	
	if (isActive == false) 
	{
	document.getElementById('checkVal').value='0';
	}
	else
	{
	document.getElementById('checkVal').value='1';
	}
	
	$(".error").remove();
	if(reportName.length < 1) {
	$('#reportName').after('<span class="error">This field is required</span>');
	$('#reportName').focus();
	return false;					
	}
	
	if(id == '')
	{
	alert("Please Select Any Sensor");
	return false;
	}

	}
	function GoBack()
	{
	window.history.back();
	}
	</script>
<script type="text/javascript">
function GetSensorList()
{
	var branchName= $('#branchName').val();
	var companyId= $('#companyId').val();
	var slNoReport= $('#slNoReport').val(); 
	
	if(branchName != '' || slNoReport != '')
	{
		$.ajax({
		type: "POST",
		url: "getSensorList.php",
		data: {branchName:branchName,companyId:companyId,slNoReport:slNoReport},
		success: function(data) {
		$("#list_books").html(data);
		}
		});
		}
		}
</script>
	<style>
	div.a {
  border: 1px solid black;
/*  outline: 1px solid black;*/
  border-radius: 10px;
  padding:6px;
}
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;

	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	{/literal}
	{include file="footer.tpl"}