	<!-- Content Wrapper. Contains page content -->
	<div class="content-wrapper">
	
	<!-- Main content -->
		<section class="content-header">
		<div class="card">
		<div class="card-header">
		
		<table style="margin-bottom:-10px;">
		<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
		<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="font-size:15PX;font-weight: bold;">List Branch</font>&nbsp;</td></tr>
		
		
		<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
		<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
		</tr>
		
		</table>
		
		</div>
		
		</div>
			<form name="location_list" method="post" id="location_list">
			<div class="row">
			
				<div class="col-12">
					<div class="card">
					
					
					{if $SuccessMessage neq "" || $ErrorMessage neq ""}
					<div class="card-body">
					{if $SuccessMessage neq ""}
					<div class="isa_success">
					<i class="fa fa-check"></i>
					{$SuccessMessage}		 
					</div>
					{/if}
					{if $ErrorMessage neq ""}
					<div class="isa_error">
					<i class="fa fa-check"></i>
					{$ErrorMessage}		 
					</div>
					{/if}
					</div>
					{/if}
					<!-- /.card-header -->
						<div class="card-body table-responsive">
						{if $smarty.session.USER_GROUP eq "Super Admin"}<a href="branchAddEdit.php?companyId={$smarty.get.companyId}"><button type="button" style="float:right;margin-top:-6PX" class="btn btn-create">Create Branch</button></a><span style="float:right">&ensp;</span>
						<a href="companyList.php?companyId={$smarty.get.companyId}"><button type="button"  style="float:right;margin-top:-6PX" class="btn btn-primary">List Company</button></a> {/if}{if $ListView.0.branch_id eq ""}<br />{/if}
							<table id="example" class="table table-bordered table-hover">
								<thead>
								<tr>
								<th class="slNo" >#</th>
								<th class="code">Branch Code</th>
								<th class="name">Branch Name</th>
								<th class="isactive">Status</th>
								<th class="action" >Action</th>
								</tr>
								</thead>
								<tbody>
								{foreach from=$ListView item=List}
								<tr id="{$j++}">
								<td >{$j}</td>
								<td >{$List.branch_id}</td>
								<td >{$List.branch_name}</td>
								<td align="center">{if $List.is_active eq "1"}<span style="color:#00A520"><b>Active</b></span>{else}<span style="color:#FF0000;"><b>Inactive</b></span>{/if}</td>
								<td align="right">
								<a href="utility_dashboard2.php?companyId={$smarty.get.companyId}&branchId={$List.sl_no|base64_encode}" title="Visit Utility Dashboard" target="_blank"><i class="fa fa-building"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;   
								{foreach from=$platformView item=dashName}
									    
								{if $dashName.segmentName eq "Energy Meter" && $dashName.branch_id eq $List.sl_no}
									<a href="dashboard.php?companyId={$smarty.get.companyId}&branchId={$List.sl_no|base64_encode}"  title="Visit {$List.branch_name} Energy Dashboard" target="_blank"><i class="fa fa-desktop"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
								{/if}
								{if $dashName.segmentName eq "Temperature" && $dashName.branch_id eq $List.sl_no}
									<a href="temperature_temperatureDashboard.php?companyId={$smarty.get.companyId}&branchId={$List.sl_no|base64_encode}"  title="Visit {$List.branch_name} Temperature Dashboard" target="_blank"><i class="fa fa-thermometer-half"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
								{/if}
								{/foreach}
								{if $smarty.session.USER_GROUP eq "Super Admin" || $smarty.session.USER_GROUP eq "Company Admin"} 
									<a href="shiftList.php?companyId={$smarty.get.companyId}&branchId={$List.sl_no|base64_encode}"  title="List Shift"><i class="fa fa-list"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
								{/if}
								{if $smarty.session.USER_GROUP eq "Super Admin"}	
									 <a href="#" onClick="Javascript:platformCats('{$List.sl_no}','{if $smarty.get.companyId neq ""}{$smarty.get.companyId|base64_decode}{else}{$smarty.session.CustomerId}{/if}')" title="List IoT Platform"><i class="fa fa-spinner"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;                                {/if}
									<a href="userList.php?companyId={if  $smarty.get.companyId neq ""}{$smarty.get.companyId}{else}{$smarty.session.CustomerId|base64_encode}{/if}&branchId={$List.sl_no|base64_encode}"  title="List User"><i class="fa fa-user"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
									<a href="contactMasterList.php?companyId={if  $smarty.get.companyId neq ""}{$smarty.get.companyId}{else}{$smarty.session.CustomerId|base64_encode}{/if}&branchId={$List.sl_no|base64_encode}" title="List Alert Contact"><i class="fa fa-bell"></i></a>
								{if $smarty.session.billing_module eq '1'} 
									&nbsp;&nbsp;&nbsp;&nbsp;
									<a href="listBilling.php?companyId={if  $smarty.get.companyId neq ""}{$smarty.get.companyId}{else}{$smarty.session.CustomerId|base64_encode}{/if}&branchId={$List.sl_no|base64_encode}" title="List Billing"><i class="fas fa-file-invoice"></i></a>
								{/if}
								&nbsp;&nbsp;&nbsp;&nbsp;
								{if $smarty.session.USER_GROUP eq "Super Admin" || $smarty.session.USER_GROUP eq "Company Admin"} 
									<a href="#"  onClick="Javascript:listGatewayGroup('{$List.company_id}','{$List.sl_no}')" title="Gateway Mapping"><i class="fa fa-podcast"></i></a>
								{/if}
								&nbsp;&nbsp;&nbsp;&nbsp;	
								{if $smarty.session.USER_GROUP neq "Super Admin"}	 
									<a href="feederList.php?companyId={$smarty.get.companyId}&branchId={$List.sl_no|base64_encode}" title="List Feeder"><i class="fa fa-lightbulb"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
								{/if}
								{foreach from=$IconList item=icon}								
								{if $icon.menuName eq "List Gateway"}
									<a href="#"  onClick="Javascript:gatewayCats('{$List.sl_no}','{$List.company_id}','{$List.branch_id}')" title="List Gateway"><i class="{$icon.faIcon}"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
								{/if}
								{if $icon.menuName eq "Location List"}
									<a href="#"  onClick="Javascript:locationCats('{$List.sl_no}','{$List.company_id}','{$List.branch_id}')" title="List Lcation"><i class="{$icon.faIcon}"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
								{/if}
								
								{if $icon.menuName eq "Edit Branch"}
									<a href="#"  onClick="Javascript:editCats('{$List.sl_no}','{$List.company_id}','{$List.branch_id}','Update=Y')" title="Edit"><i class="{$icon.faIcon}"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
								{/if}
								{if $icon.menuName eq "Delete Branch"}
									 <a href="#"  onClick="Javascript:deleteCats('{$List.sl_no}','{$List.company_id}','{$List.branch_id}')" title="Delete"><i class="{$icon.faIcon}"></i></a>
								 {/if}
								{/foreach}&nbsp;&nbsp;&nbsp;&nbsp;
								</td>
								</tr>
								{foreachelse}
								<tr><td colspan="5"><center>No Records Found</center></td></tr>
								{/foreach}
								</tbody>
							</table>
						</div>
					
					<!-- /.card-body -->
					</div>
				<!-- /.card -->
				</div>
			</form>
		</section>
	<!-- /.content -->
	</div>
	<!-- /.content-wrapper -->
	{literal}
	
	<style>
	.slNo{
	width:5%;
	}
	.code{
	width:10%;
	}
	.name{
	width:40%;
	}
	.isactive{
	width:10%;
	text-align:center;
	
	}
	.action{
	text-align:right;
	}
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	/*background-color:#FFBABA;*/
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	/*vertical-align:middle;*/
	}
	</style>
	<script type="text/javascript">
	$(document).ready(function (){
	
	var table = $('#example').DataTable({
	"ordering" : false,
	language: {
	"infoFiltered": "",
	search: "_INPUT_",
	searchPlaceholder: "Search..."
	},
	dom: '<"pull-left" f><bottom>p',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: '<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p',
	//dom: '<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p',
	
	initComplete: function(){
	//  $("div.toolbar").html('<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>');   
	
	
	}       
	}); 
	
	}); 
	
	function platformCats(branchId,companyId) {
	var comId = btoa(companyId);
	var branId = btoa(branchId);
	FormName		= document.location_list;
	FormName.action ='platformAdd.php?companyId='+comId+'&branchId='+branId;
	FormName.submit();
	}	
	function gatewayCats(slNoIdent,compIdent,branchIdent) {
	var sid = btoa(slNoIdent);  var comId = btoa(compIdent); var bid = btoa(branchIdent);
	FormName		= document.location_list;
	FormName.action ='gatewayList.php?companyId='+comId+'&branchId='+sid;
	FormName.submit();
	}
	function locationCats(slNoIdent,compIdent,branchIdent) {
	var sid = btoa(slNoIdent);  var comId = btoa(compIdent); var bid = btoa(branchIdent);
	FormName		= document.location_list;
	FormName.action ='locationList.php?companyId='+comId+'&branchId='+sid;
	FormName.submit();
	}
	function editCats(slNoIdent,compIdent,locIdIdent) {
	var sid = btoa(slNoIdent); var comId = btoa(compIdent); var bid = btoa(locIdIdent);
	FormName		= document.location_list;
	FormName.action ='branchAddEdit.php?companyId='+comId+'&branch_id='+bid+'&sl_no='+sid+'&Update=y';
	FormName.submit();
	}
	function listGatewayGroup(compIdent,locIdIdent)
	{
	var comId = btoa(compIdent); var lid = btoa(locIdIdent);
	FormName		= document.location_list;
	FormName.action ='gatewayGroupList.php?companyId='+comId+'&branchId='+lid;
	FormName.submit();
	}
	</script>
	<script type="text/javascript">
	function deleteCats(slNoIdent,compIdent,locIdIdent){
	var sid = btoa(slNoIdent); var comId = btoa(compIdent); var bid = btoa(locIdIdent);
	if(confirm("Are you sure to Delete this Content?")){
	FormName		= document.location_list;
	FormName.action= 'branchList.php?companyId='+compIdent+'&branch_id='+locIdIdent+'&sl_no='+slNoIdent;
	FormName.submit();
	}
	}
	</script>
	{/literal}
	{include file="footer.tpl"}