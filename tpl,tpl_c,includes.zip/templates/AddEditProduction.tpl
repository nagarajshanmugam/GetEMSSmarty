	<div class="content-wrapper">	
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">{if $branchDetail.0.branch_name neq ""}{$branchDetail.0.branch_name}{else}Branch{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">Production </font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:10PX;color:#999999;"> Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			 <a href="listProductionShift.php"><button type="button" class="btn btn-primary" value="" style="float:right;margin-top:-40PX">List Productions</button></a> 
			</div>
		</div>
		<div class="card">
		{if $SuccessMessage neq ""}
			<div class="card-body">
				<div class="isa_success">
				<i class="fa fa-check"></i>
				{$SuccessMessage}		 
				</div>
			</div>
		{/if}
		{if $ErrorMessage neq ""}
			<div class="card-body">
				<div class="isa_error">
				<i class="fa fa-check"></i>
				{$ErrorMessage}		 
				</div>
			</div>
		{/if}
			<div class="card-body">
				<form class="form-horizontal" name="production" id="production" method="post" onsubmit="return ValidateFields();">
					<input type="hidden" name="hdAction" id="hdAction">
					
					<div class="row">
						<div class="form-group col-md-3">
							<label for="inputEmail3">Energy Meter     
			{if $smarty.get.pg eq "Update"}
							&ensp; &ensp; :  &ensp; &ensp;&ensp;&ensp;&ensp;{foreach from=$ListSens item=sesLis} {if $sesLis.sensorCode eq $smarty.post.sensorCode || $sesLis.sensorCode eq $smarty.get.sensorCode|base64_decode}{$sesLis.sensorName} <input type="hidden" name="sensorCode"  id="sensorCode" value="{$sesLis.sensorCode}">{/if} {/foreach}
			{else}
							<span class="required"><b>*</b></span></label>
							
							<select name="sensorCode" class="form-control form-control-sm" id="sensorCode">
							<option value="" {if $smart.post.sensorCode eq ''} selected="selected"{/if}> Choose Energy Meter</option>
							{foreach from=$ListSens item=sesLis}
								<option value="{$sesLis.sensorCode}" {if $sesLis.sensorCode eq $smarty.post.sensorCode || $sesLis.sensorCode eq $smarty.get.sensorCode|base64_decode} selected="selected"{/if}>{$sesLis.sensorName}</option>
								
							{/foreach}
							</select>
			{/if}
						</div>
							<div class="form-group col-md-3">
							<label for="inputEmail3">Productin Date 
							
			{if $smarty.get.pg eq "Update"}
							&ensp; &ensp; :  &ensp; &ensp;&ensp;&ensp;&ensp;{assign var=ptDate value=$smarty.get.prodDate|base64_decode}{$ptDate|date_format:"%e-%b-%Y"} <input type="hidden" name="prodDate"  id="prodDate" value="{$smarty.get.prodDate|base64_decode}">
			{else}
							<span class="required"><b>*</b></span></label>
							
							<select name="prodDate" class="form-control form-control-sm" id="prodDate">
							<option value="" {if $smart.post.sensorCode eq ''} selected="selected"{/if}> Choose Production Date</option>
							{foreach from=$ListProductionDate item=proDate}
								<option value="{$proDate.recorded_date}" {if $proDate.recorded_date eq $smart.post.prodDate || $proDate.recorded_date eq $smarty.get.prodDate|base64_decode} selected="selected"{/if}>{$proDate.recorded_date|date_format:"%e-%b-%Y"}</option>
							{/foreach}
							</select>
			{/if}
						</div>
					
					</div>
					
						{if $prodShiftList.0.shift_wise_data_id neq ''}
						<div class="card-body table-responsive col-md-8">
						<table id="example" class="table table-bordered table-hover">
						<thead>
						<tr>
						<th>#</th>
					    <th>Shift Name</th>
						<th>Shift Range</th>
						<th>Production</th>
						</tr>
						</thead>
						<tbody>
						{foreach from=$prodShiftList item=shiftList}
							<tr id="{$i++}">
							<td>{$i}</td>
							<td>{$shiftList.shift_name}</td>
<!--							<td align="center">{$shiftList.from_date_time|date_format:"%e-%b-%Y %I:%M %p"}  to  {$shiftList.to_date_time|date_format:"%e-%b-%Y %I:%M %p"}</td>
-->							<td align="center">{$shiftList.from_date_time|date_format:"%I:00 %p"}  to  {$shiftList.to_date_time|date_format:"%I:%M %p"}</td>
							<td><input class="form-control form-control-sm" name="production{$i}" id="production{$i}"  value="{$shiftList.production}" style=" text-align:right" onKeyUp="numericFilter(this);">
							<input type="hidden" id="cronShift{$i}" name="cronShift{$i}" value="{$shiftList.shift_wise_data_id}"></td>
							</tr>
						{/foreach}
						</tbody>
						</table>
						</div>
						<input type="hidden" id="shiftCount" name="shiftCount" value="{$i}" />
						
					<div align="center">
						<input type="submit" value="Submit" class="btn btn-create " onclick="ValidateFields();" />
					</div>
					{/if}
					
				</form>
			</div>
		</div>
	</section>
	</div>
	{literal}
	<script type="text/javascript">
	function numericFilter(data)
	{
	data.value = data.value.replace(/[^.0-9^.+,-]/ig,"");
	}
	function text_filter(data)
	{
	data.value = data.value.replace(/[^ .a-z]/ig,"");
	}
	</script>
	<script type="text/javascript">
	$(document).ready(function(){
	$("#sensorCode").change(function(){
		var sensorCode= $("#sensorCode").val();
		var senCod= btoa(sensorCode);
	window.location.href = "AddEditProduction.php?sensorCode="+senCod;
	});
	$("#prodDate").change(function(){
		var sensorCode= $("#sensorCode").val();
		var prodDate= $("#prodDate").val();
		var prodDt=btoa(prodDate);
		var senCod= btoa(sensorCode);
		//alert(prodDate);
		//alert("AddEditProduction.php?sensorCode="+senCod+"&prodDate="+prodDt);
	window.location.href = "AddEditProduction.php?sensorCode="+senCod+"&prodDate="+prodDt;
	});
	});
	function ValidateFields1(id)
	{
		var val = document.getElementById(id).value;
	if(val == '' || val == '0')
	{
		$(".error").remove();
		$("#"+id).after('<span class="error">This field is required</span>');
		$("#"+id).focus();
		return false;		

	}
	else
	{
		$(".error").remove();
		return true;
	}
	}
	function ValidateFields()
	{
		var sensorCode = $('#sensorCode').val();
		var prodDate = $('#prodDate').val();
		

	
		$(".error").remove();
	if (sensorCode.length < 1) {
		$('#sensorCode').after('<span class="error">This field is required</span>');
		$('#sensorCode').focus();
		return false;					
	}else if (prodDate.length < 1) {
		$('#prodDate').after('<span class="error">This field is required</span>');
		$('#prodDate').focus();
		return false;					
	}
	
		production.hdAction.value = 1;
		return true;
	}
	function GoBack()
	{
		window.history.back();
	}
	</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	{/literal}
	{include file="footer.tpl"}