		<div class="content-wrapper">
			<section class="content-header">
			<div class="card">
				<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{if $smarty.get.sl_no neq ""}<td style="font-size:15PX;font-weight: bold;">{$ListEditView.0.branch_name}</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{/if}
				<td style="font-size:15PX;font-weight: bold;"> Branch Update&nbsp;</td>
				</tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{if $smarty.get.sl_no neq ""}
				<td style="font-size:10PX;color:#999999;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{/if}
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>				
				</div>
			</div>
			</section>
			<section class="content">
				<div class="card">
				<!--<div class="card-header">
			{if $smarty.session.USER_GROUP eq "Super Admin"}	{if $smarty.get.sl_no eq ""}
				<h3 class="card-title">Create Branch</h3>
				<a href="branchList.php?companyId={$smarty.get.companyId}"><button type="button" style="float:right;" class="btn btn-primary">List Branch</button></a>
				{else}
				<h3 class="card-title">Edit Branch</h3>
				<a href="branchList.php?companyId={$smarty.get.companyId}"><button type="button" style="float:right;" class="btn btn-primary">List Branch</button></a>
				{/if}{/if}
				</div>-->
                {if $SuccessMessage neq ""}
				<div class="card-body">
					<div class="isa_success">
					<i class="fa fa-check"></i>
					{$SuccessMessage}		 
					</div>
				</div>
			{/if}
			{if $ErrorMessage neq ""}
				<div class="card-body">
					<div class="isa_error">
					<i class="fa fa-check"></i>
					{$ErrorMessage}		 
					</div>
				</div>
			{/if}
					<div class="card-body">
						<form role="form" name="locationRegForm" id="locationRegForm" method="post" onsubmit="return createValidation();" >
							<input type="hidden" name="hdAction" />
							<input type="hidden" id="check_id" name="check_id" value="{$smarty.post.check_id}">
							<input type="hidden" id="checkVal" name="checkVal" value="{$smarty.post.checkVal}" />
                            <input type="hidden" class="form-control form-control-sm" id="branchId" name="branchId"  value="{if $ListEditView.0.sl_no neq ""}{$ListEditView.0.sl_no}{/if}">
                            <input type="hidden" class="form-control form-control-sm" id="companyId" name="companyId"  value="{if $ListEditView.0.company_id neq ""}{$ListEditView.0.company_id}{/if}">
							<div class="row">
							<div class="form-group col-md-6">
								<label for="exampleInputlocationName">Branch Name <span style="color:red;">*</span></label>
								<input type="text" class="form-control form-control-sm" id="branchName" name="branchName" placeholder="Enter Branch name" value="{if $ListEditView.0.branch_name neq ""}{$ListEditView.0.branch_name}{/if}" autocomplete="off">
							</div>
							<div class="form-group col-md-6" style="margin-top:8px;"><br>
							<input type="submit" value="Submit" class="btn btn-create btn-sm" />
								<input id="created_by" name="created_by" class="date-picker form-control" type="hidden" value="{$smarty.session.UserName}" readonly="true">
							</div>
							</div>
							
						</form>
					</div>
				
				</div>
			</div>		
		</section>
	</div>
	{literal}
	<script type="text/javascript">
	function createValidation(){
	var branchId = $('#branchId').val();
	var branchName = $('#branchName').val();
	var isActive = document.getElementById("customCheckbox2").checked;
	
	if (isActive == false) 
	{
	document.getElementById('checkVal').value='0';
	}
	else
	{
	document.getElementById('checkVal').value='1';
	}
	
	$(".error").remove();
	if(locationId.length < 1) {
	$('#branchId').after('<span class="error">This field is required</span>');
	$('#branchId').focus();
	return false;					
	}
	else if(branchName.length < 1 && branchId.length > 1) {
	
	$('#branchName').after('<span class="error">This field is required</span>');
	$('#branchName').focus();
	return false;
	
	}	
	FormName		= document.locationRegForm;
	FormName.method	= "POST";
	FormName.submit();
	}
	function GoBack()
	{
	window.history.back();
	}
	</script>
<!--	<script>
	function CheckDuplicateLocName()
	{
	var locationId = $("#locationId").val();
	$.ajax({
	type: "POST",
	url: "AjaxLocationCode.php",
	data: {locationId:locationId},
	dataType:"TEXT",
	cache: false,
	
	success: function(result){
	var obj = JSON.parse(result);
	var feild= $("#locationId").val();
	if(obj[0].location_id = feild ){
	document.getElementById("locationId").value ='';
	alert('Your enter data already exist ...');
	createValidation();
	return false;	
	}
	},
	error: function(result) {
	alert('error');
	}
	});
	} 
	</script>-->
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	{/literal}
	{include file="footer.tpl"}