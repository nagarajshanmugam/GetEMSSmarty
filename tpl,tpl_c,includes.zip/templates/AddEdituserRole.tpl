	<div class="content-wrapper">	
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">{if $smarty.get.roleId eq ""}Create Role{else}Edit Role{/if}</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			<a href="userRoleList.php"><button type="button" class="btn btn-primary" value="" style="float:right;margin-top:-40PX">List Role</button></a>
			</div>
		</div>
		<div class="card">
		{if $SuccessMessage neq ""}
			<div class="card-body">
				<div class="isa_success">
				<i class="fa fa-check"></i>
				{$SuccessMessage}		 
				</div>
			</div>
		{/if}
		{if $ErrorMessage neq ""}
			<div class="card-body">
				<div class="isa_error">
				<i class="fa fa-check"></i>
				{$ErrorMessage}		 
				</div>
			</div>
		{/if}
			<div class="card-body">
				<form class="form-horizontal" name="userRoleReg" id="userRoleReg" method="post" onsubmit="return ValidateFields();">
					<input type="hidden" name="hdAction" id="hdAction">
					<input type="hidden" id="roleId" name="roleId" value="{$ListEditView.0.slNo}" />
					<input type="hidden" id="checkVal" name="checkVal" value="{$smarty.post.checkVal}" />
					<div class="row">
						<div class="form-group col-md-6">
							<label for="inputEmail3">Menu Name <span class="required"><b>*</b></span></label>
							<input type="text" name="menuName" class="form-control form-control-sm" id="menuName" placeholder="Menu Name" autocomplete="Off" tabindex="1" value="{if $ListEditView.0.menuName neq ""}{$ListEditView.0.menuName}{/if}" onblur="ValidateFields1('menuName');">
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">URL <span class="required"><b>*</b></span></label>
							<input type="text" name="url" class="form-control form-control-sm" id="url" placeholder="URL" autocomplete="Off" tabindex="4" value="{if $ListEditView.0.url neq ""}{$ListEditView.0.url}{/if}" onblur="ValidateFields1('url');">
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">Menu Type <span class="required"><b>*</b></span></label>
						{if $ListEditView.0.menuType neq ""}
							<select class="form-control form-control-sm" id="menuType" name="menuType" tabindex="2" onblur="ValidateFields1('menuType');">
								<option id"{$ListEditView.0.menuType}" value="{$ListEditView.0.menuType}" selected="selected">{$ListEditView.0.menuType}</option>
												{if $ListEditView.0.menuType neq "Main Menu"}
								<option value="Main Menu">Main Menu</option>
							{/if}
							{if $ListEditView.0.menuType neq "Sub Menu"}
								<option value="Sub Menu">Sub Menu</option>
							{/if}
							{if $ListEditView.0.menuType neq "Icon"}
								<option value="Icon">Icon</option>
							{/if}
							{if $ListEditView.0.menuType neq "Button"}
								<option value="Button">Button</option>
							{/if}
							</select>
						{else}
							<select class="form-control form-control-sm" id="menuType" name="menuType" tabindex="2" onblur="ValidateFields1('menuType');"> 
								<option value="0">--Select--</option>
								<option value="Main Menu">Main Menu</option>
								<option value="Sub Menu">Sub Menu</option>
								<option value="Icon">Icon</option>
								<option value="Button">Button</option>
							</select>
						{/if}
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">Priority <span class="required"><b>*</b></span></label>
							<input type="text" name="priority" class="form-control form-control-sm" id="priority" placeholder="Priority" autocomplete="Off" tabindex="5" value="{if $ListEditView.0.priority neq ""}{$ListEditView.0.priority}{/if}" onblur="ValidateFields1('priority');">
						</div>
						<div class="form-group col-md-6" id="parentM">
							<label for="inputEmail3">Parent Menu<span class="required"><b>*</b></span></label>
						{if $ListEditView.0.parent_id neq "0" }
							<select class="form-control form-control-sm" id="parentMenu" name="parentMenu" tabindex="3" onblur="ValidateFields1('parentMenu');" >
										{foreach from=$ListparMenu item=partMenu}
										{if $ListEditView.0.parent_id eq $partMenu.slNo}
								<option value="{$partMenu.slNo}" Selected>{$partMenu.menuName}</option>
							{/if}
							{if $ListEditView.0.parent_id neq $partMenu.slNo}
								<option value="{$partMenu.slNo}">{$partMenu.menuName}</option>
							{/if}
							{/foreach}
							</select>
						{else}
							<select class="form-control form-control-sm" id="parentMenu" name="parentMenu" tabindex="3" onblur="ValidateFields1('parentMenu');" > 
								<option value="0">--Select--</option>
							{foreach from=$ListparMenu item=partMenu}
								<option value="{$partMenu.slNo}">{$partMenu.menuName}</option>
							{/foreach}
							</select>
						{/if}
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">FA Icon <span class="required"><b>*</b></span></label>
							<input type="text" name="faIcon" class="form-control form-control-sm" id="faIcon" placeholder="FA Icon" autocomplete="Off" tabindex="3" value="{if $ListEditView.0.faIcon neq ""}{$ListEditView.0.faIcon}{/if}" onblur="ValidateFields1('faIcon');">
						</div>
						<div class="form-group col-md-6">
							<div class="custom-control custom-checkbox">
							{if $ListEditView.0.menuName neq ''}
							{if $ListEditView.0.isActive eq "1"}
								<input class="custom-control-input" type="checkbox" id="customCheckbox2"  name="customCheckbox2" tabindex="7" checked="checked">
								<label for="customCheckbox2" class="custom-control-label">Is Active <span class="required"><b>*</b></span></label>
							{else}
								<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="7">
								<label for="customCheckbox2" class="custom-control-label">Is Active <span class="required"><b>*</b></span></label>
							{/if}
							{else}
								<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="7" checked="checked">
								<label for="customCheckbox2" class="custom-control-label">Is Active <span class="required"><b>*</b></span></label>
							{/if}
							</div>
							<input id="created_by" name="created_by" class="date-picker form-control" type="hidden" value="{$smarty.session.UserName}" readonly="true">
							<input type="hidden" class="form-control" id="timestamp" name="timestamp" value="{$smarty.now|date_format:'%Y-%m-%d &amp; %I:%M:%S %p'}">
							<input type="hidden" class="form-control" id="created_time" name="created_time" placeholder="Time" Value="{$smarty.now|date_format:'%I:%M:%S %p'}">
						</div>
					</div>
					<div align="center">
						<input type="submit" value="Submit" class="btn btn-create" onclick="ValidateFields();" />
					</div>
				</form>
			</div>
		</div>
	</section>
	</div>
	{literal}
	<script type="text/javascript">
	$(document).ready(function(){
		var menTyp= $("#menuType").val();
	if(menTyp=='Sub Menu'){
		$("#parentM").show();
	}
	else{
		$("#parentM").hide();
	}
	$("#menuType").change(function(){
		var menTyp= $("#menuType").val();
	if(menTyp=='Sub Menu'){
		$("#parentM").show();
	}
	else{
		$("#parentM").hide();
	}
	});
	});
	function ValidateFields1(id)
	{
		var val = document.getElementById(id).value;
	if(val == '' || val == '0')
	{
		$(".error").remove();
		$("#"+id).after('<span class="error">This field is required</span>');
		$("#"+id).focus();
		return false;		
	}
	else
	{
		$(".error").remove();
		return true;
	}
	}
	function ValidateFields()
	{
		var menuName = $('#menuName').val();
		var menuType = $('#menuType').val();
		var parentMenu = $('#parentMenu').val();
		var faIcon = $('#faIcon').val();
		var url = $('#url').val();
		var priority = $('#priority').val();
		var isActive = document.getElementById("customCheckbox2").checked;
	
	if (isActive == false) 
	{
		document.getElementById('checkVal').value='0';
	}
	else
	{
		document.getElementById('checkVal').value='1';
	}
	
		$(".error").remove();
	if (menuName.length < 1) {
		$('#menuName').after('<span class="error">This field is required</span>');
		$('#menuName').focus();
		return false;					
	}
	else if (menuType == '0') {
		$('#menuType').after('<span class="error">This field is required</span>');
		$('#menuType').focus();
		return false;					
	}
	else if (menuType == 'Sub Menu' && parentMenu == '0') {
		$('#parentMenu').after('<span class="error">This field is required</span>');
		$('#parentMenu').focus();
		return false;					
	}
	else if (faIcon.length < 1) {
		$('#faIcon').after('<span class="error">This field is required</span>');
		$('#faIcon').focus();
		return false;					
	}
	else if (url.length < 1) {
		$('#url').after('<span class="error">This field is required</span>');
		$('#url').focus();
		return false;					
	}
	else if (priority.length < 1) {
		$('#priority').after('<span class="error">This field is required</span>');
		$('#priority').focus();
		return false;					
	}
		userRoleReg.hdAction.value = 1;
		return true;
	}
	function GoBack()
	{
		window.history.back();
	}
	</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	{/literal}
	{include file="footer.tpl"}