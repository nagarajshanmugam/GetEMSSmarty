	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">List Teltonika Data</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			</div>
		</div>
		<div class="row">
			<div class="col-12">
				<div class="card">
				{if $SuccessMessage neq ""}
					<div class="card-body">
						<div class="isa_success">
						<i class="fa fa-check"></i>
						{$SuccessMessage}		 
						</div>
					</div>
				{/if}
				{if $ErrorMessage neq ""}
					<div class="card-body">
						<div class="isa_error">
						<i class="fa fa-check"></i>
						{$ErrorMessage}		 
						</div>
					</div>
				{/if}
					<div class="card-body table-responsive">
				<a href="#" onclick="get_excel();"> <button type="button" class="btn btn-create" value="Create Userrole" style="float:right;margin-top:-6PX">Download Excel</button></a><span style="float:right;">&ensp;</span>
					<a href="teltonika_data.php?del=Delete" onclick="return confirm('Are you sure want to delete all Data?')"> <button type="button" class="btn btn-create" value="Create Userrole" style="float:right;margin-top:-6PX">Delete All Data</button></a> {if $ListView.0.json_data eq ""}<br /><br />{/if}
						<form name="companyList" id="companyList" method="post">
							<table id="example" class="table table-hover table-bordered">
							<thead>
							    
							<tr>
							<th class="slno">#</th>
							<th >DATE TIME</th>
							<th>Json Data (URL = https://emslte.arkaautomaations.com/teltonika_test.php)</th>

							</tr>
							</thead>
							<tbody>
							{foreach from=$ListView item=listDet}
							<tr id="{$i++}">
							<td class="slNo">{$i}</td>
								<td class="datetime" >{$listDet.M_timestamp|date_format:'%d-%b-%Y  %r'}</td>
							<td class="text_left">{$listDet.json_data}</td>
						
							</tr>
							{foreachelse}
							<tr><td colspan="10"><center>No Records Found</center></td></tr>
							{/foreach}
							</tbody>
							</table>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
	</div>
	{literal}
	<script>
	$(document).ready(function (){
	var table = $('#example').DataTable({
	"ordering" : false,
	language: {
	"infoFiltered": "",
	search: "_INPUT_",
	searchPlaceholder: "Search..."
	},
	dom: '<"pull-left" f><bottom>p',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: '<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p',
	//dom: '<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p',
	buttons: [
	{
	text: 'Create Box',
	className: 'btn btn-create',
	titleAttr: 'Create Box',
	action: function ( e, dt, button, config ) {
	window.location = 'AddEditBox.php';
	}        
	}
	],
	initComplete: function(){
	$("div.toolbar").html('<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>');   	
	}       
	}); 
	}); 
	$(function () {
	$("#example1").DataTable();
	$('#example2').DataTable({
	"paging": true,
	"lengthChange": false,
	"searching": false,
	"ordering": true,
	"info": true,
	"autoWidth": false,
	});
	});
	</script>
	 <script type="text/javascript">
	function get_excel()
	{
	window.location.href="teltonika_report_xl.php";
	}
	</script>
	<style>
	.datetime
	{
	width:20%;
	}
	.slNo
	{
	width:5%;
	}
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	
	</style>
	{/literal}
	{include file="footer.tpl"}