	<div class="content-wrapper">
		<section class="content-header">
			<div class="card">
				<div class="card-header">
					<table style="margin-bottom:-10px;">
					<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
					<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="font-size:15PX;font-weight: bold;">{$BranchView.0.branch_name}&nbsp;&nbsp;</td>
					<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="font-size:15PX;font-weight: bold;">List Shift</font>&nbsp;</td></tr>
					<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
					<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="color:#999999;font-size:10PX;">Branch Name</td>
					<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
					</tr>
					</table>
				</div>
			</div>
			<form name="shiftList" method="post" id="shiftList">
			<div class="row">
					<div class="col-12">
						<div class="card">
						{if $SuccessMessage neq "" || $ErrorMessage neq ""}
							<div class="card-body">
							{if $SuccessMessage neq ""}
								<div class="isa_success">
								<i class="fa fa-check"></i>
								{$SuccessMessage}		 
								</div>
							{/if}
							{if $ErrorMessage neq ""}
								<div class="isa_error">
								<i class="fa fa-check"></i>
								{$ErrorMessage}		 
								</div>
							{/if}
							</div>
						{/if}
						<div class="card-body table-responsive">
						    {if $smarty.session.USER_GROUP eq 'Super Admin'}
						<a href="shiftAddEdit.php?companyId={$smarty.get.companyId}&branchId={$smarty.get.branchId}"><button type="button" style="float:right;margin-top:PX" class="btn btn-info"> Create Shift</button></a><span style="float:right">&ensp;</span>
						<a href="companyList.php?companyId={$smarty.get.companyId}"><button type="button"  style="float:right;margin-top:PX" class="btn btn-primary">List Company</button></a><br>
						{/if}
						<span style="float:right;">&ensp;</span>
						{if $ListFeedForm.0.feeder_master_id eq ""}&ensp;<br />{/if}
							<table id="example" class="table table-bordered table-hover">
								<thead>
								<tr>
								<th class="slNo">#</th>
								<th class="name">Shift Name</th>
								<th class="type">From Time</th>
								<th class="name">To Time</th>
								<th class="isactive">Status</th>
								<th class="action">Action</th>
								</tr>
								</thead>
								<tbody>
								{foreach from=$ListShiftView item=List}
								<tr id="{$j++}">
								<td >{$j}</td>
								<td>{$List.shift_name}</td>
								<td align="center">{$List.start_time|date_format:"%I:%M %p"}</td>
								<td align="center">{$List.end_time|date_format:"%I:%M %p"}</td>
								<td align="center">{if $List.is_active eq "1"}<span style="color:#009900"><b>Active</b></span>{else}<span style="color:#FF0000;"><b>Inactive</b></span>{/if}</td>
								<td align="right">
								<a href="#"  onClick="Javascript:editCats('{$List.shift_master_id}','{$List.company_id}','{$List.branch_id}','Update=Y')" title="Edit"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							{if $smarty.session.USER_GROUP eq 'Super Admin'}	<a href="#"  onClick="Javascript:deleteCats('{$List.shift_master_id}','{$List.company_id}','{$List.branch_id}')" title="Delete"><i class="fa fa-trash"></i></a>{/if}
								</td>
								</tr>
								{foreachelse}
								<tr><td colspan="6"><center>No Records Found</center></td></tr>
								{/foreach}
								</tbody>
							</table>
						</div>
						</div>
					</div>
			</form>
		</section>
	</div>
	{literal}
	<style>
	.slNo{
	width:5%;
	}
	.code{
	width:10%;
	}
	.type{
	width:15%;
	}
	.name{
	width:20%;
	}
	.isactive{
	width:10%;
	text-align:center;
	
	}
	.action{
	text-align:right;
	width:15%;
	}
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>
	<script type="text/javascript">
	$(document).ready(function (){
	
	var table = $('#example').DataTable({
	"ordering" : false,
	"searching" : false,
	language: {
	"infoFiltered": "",
	search: "_INPUT_",
	searchPlaceholder: "Search..."
	},
	dom: '<"pull-left" f><bottom>p',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: '<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p',
	//dom: '<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p',
	
	initComplete: function(){
	//  $("div.toolbar").html('<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>');   
	}       
	}); 
	}); 
	function editCats(slNoIdent,compIdent,branIdent,Update) {
	var sid = btoa(slNoIdent);  var comId = btoa(compIdent); var bId = btoa(branIdent);
	FormName		= document.shiftList;
	FormName.action ='shiftAddEdit.php?shift_master_id='+sid+'&companyId='+comId+'&branchId='+bId+'&Update=y';
	FormName.submit();
	}
	</script>
	<script type="text/javascript">
	function deleteCats(slNoIdent,compIdent,branIdent){
	var sid = btoa(slNoIdent); var comId = btoa(compIdent);var bId = btoa(branIdent);
	if(confirm("Are you sure to Delete this Shift?")){
	FormName		= document.shiftList;
	FormName.action= 'shiftList.php?companyId='+comId+'&branchId='+bId+'&shift_master_id='+sid+'&Del=delete';
	FormName.submit();
	}
	}
	</script>
	{/literal}
	{include file="footer.tpl"}