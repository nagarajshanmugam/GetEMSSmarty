

<meta name="viewport" content="width=device-width, initial-scale=1.0"/><div class="content-wrapper">

<!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> -->
<link rel="stylesheet" href="./font-awesome/css/font-awesome.css">

    <div class="content-header">

      <div class="container-fluid">

            <div class="row"> <div class="col-md-12">
            <div class="card">
            <div class="card-body">

			 <table style="margin-bottom:-10px;">
		  <tr><td style="font-size:15PX;font-weight: bold;">{$companyDetail.0.companyName}&nbsp;&nbsp;</td>
		  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  <td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>
		  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  <td style="font-size:15PX;font-weight: bold;">Heinn IoT  <!---({$LoctList.0.gateway_id} / {$LoctList.0.sensorCode})--></font>&nbsp;</td></tr>
		  
		
		  <tr><td style="font-size:10PX;color:#999999;">Company Name</td>
		  <td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  <td style="font-size:10PX;color:#999999;">Branch Name</td>
		  <td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  <td style="color:#999999;font-size:10PX;">Dashboard Live</td><td>&nbsp;</td>
		  </tr>
		  
		  </table>
		             

		    </div>
			</div>
			</div>
          <!--<div class="col-md-12 >
		  
            <div class="info-box">
              <div class="info-box-content">
                 <span class="pull-left text-info"><h5><b>{$LoctList.0.companyName}&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp; {$LoctList.0.branch_name}&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp; {$LoctList.0.gateway_id}&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;{$LoctList.0.sensorName}</b></h5></span>
              </div>
            </div>
          </div>-->
          </div>

<div class="row">
{foreach from=$exeDashboard item=List}
          <div class="col-md-4">

            <!-- Profile Image -->
            <div class="card card-primary card-outline">
              <div class="card-body box-profile">
                <div class="text-center">
                  <img class="profile-user-img img-fluid img-circle"
                       src="images/{if $List.machine_status eq "ON"}on_status{else}off_status{/if}.png"
                       alt="User profile picture">
		       </div>

                <h3 class="profile-username text-center">{$List.sensorName}</h3>

                <p class="text-muted text-center"><!--Xpert Pro--></p>

                <ul class="list-group list-group-unbordered mb-3">
                  <li class="list-group-item">
                    <b>Machine Status <a class="float-right" style="color:{if $List.machine_status eq "ON"}green{else}red{/if}" >{$List.machine_status}</a></b>
                  </li>
				  <li class="list-group-item">
                    <b>Bearing 1 Temperature <a class="float-right"  >{$List.bearing_1_temperature}&#176;C</a></b>
                  </li>
				  
                  <!--<li class="list-group-item">
                    <b>Curr MSB</b> <a class="float-right" id="curMsb{$List.machine_id}">0</a>
                  </li>-->
                  <li class="list-group-item">
                    <b>Logged at</b> <a class="float-right" >{$List.recorded_date_time|date_format:"%e-%b-%Y %I:%M %p"}</a>
                  </li>
                </ul>
				

              <a href="heinn_log_data.php" class="btn btn-primary btn-block"><b>View</b></a> 
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

            <!-- About Me Box -->
            
            <!-- /.card -->

          </div>

{/foreach}
<!--<div class="col-md-5">
			<div class="card card-primary card-outline">
			<div class="card-header">
			<h3 class="card-title">Recent Incidents</h3>
			</div>
			<div class="card-body p-0">
			<ul class="products-list product-list-in-card pl-2 pr-2">
			{foreach from=$incidentList item=ListIncidentLog}
			{assign var="alertMsg0" value=$ListIncidentLog.alert_message|replace:'Hi!':''}
			{assign var="alertMsg1" value=$alertMsg0|replace:'Best regards,':''}
			{assign var="alertMsg" value=$alertMsg1|replace:'Arka Automaations Limited.':''}
			{assign var="alertBreak" value=","|explode:$alertMsg}
			{assign var="l" value=0}
			<li class="item">
			<div class="product-img">
			<a href="javascript:void(0)" class="product-title">{$ListIncidentLog.sensor_code} - ( {$ListIncidentLog.recorded_date_time|date_format:"%e-%b-%Y %I:%M %p"} )</a>
			{if $ListIncidentLog.alert_status eq "Low"}<span class="badge badge-warning"  style="float:right;">{$ListIncidentLog.alert_status}</span>{elseif $ListIncidentLog.alert_status eq "Normal"}<span class="badge badge-info"  style="float:right;">{$ListIncidentLog.alert_status}</span>{elseif $ListIncidentLog.alert_status eq "Normal"}<span class="badge badge-danger"  style="float:right;">{$ListIncidentLog.alert_status}</span>{/if}
			<span class="product-description" style="font-size:12px">
			{section name=i loop=$alertBreak}
			{assign var="l" value=$l+1}
			{$alertBreak[i]|escape},{if $l eq '1'}<br />{/if}
			{/section}
			</span>
			</div>
			</li>
			{/foreach}
			</ul>
			</div>
			<div class="card-footer text-center">
		<!--	<a href="listIncidentLog.php" class="uppercase">View All Incidents</a>
			</div>
			</div>
			</div>-->
          <!-- /.col -->
          
          <!-- /.col -->
        </div>
  </div>

  </div>

  </div>

 {literal}
<script>
function graphReports(mId,cId,bId,senCode){
	//alert(tId);
	
	window.location.href="graphReport.php?machineId="+btoa(mId)+"&companyId="+btoa(cId)+"&branchId="+btoa(bId)+"&sensorCode="+btoa(senCode);
}
</script>
 <style>
 .slNo{
 width:5%;
 }
 .name{
 width:15%;
 }.status{
 width:10%;
 }
 </style>
 {/literal}

  {include file="footer.tpl"}
