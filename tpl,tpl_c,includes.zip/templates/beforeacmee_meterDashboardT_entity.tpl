{literal}

	<script src="amcharts/amcharts.js"></script>
	<script src="amcharts/serial.js"></script>
	<script src="amcharts/themes/light.js"></script>
<!--     Gauge Script      --->
<script src="./amChart/amchart.js"></script>
<script src="./js/gaugeChart/gauge.js"></script>
<script src="./js/gaugeChart/export.min.js"></script>
	
	<script src="amcharts/plugins/export/export.min.js"></script>
	<link rel="stylesheet" href="amcharts/plugins/export/export.css" type="text/css" media="all" />
	<script src="./amChart/amchartLight.js"></script>
<script src="./amChart/amchartColumnChart.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <style type="text/css">
 iframe{
    overflow:hidden;
}
  .thal
  {
  text-align:left;
  }
  .thar
  {
  text-align:right;
  }
.bclass
{
font:Geneva, Arial, Helvetica, sans-serif;
font-size:14px;
font-weight:600;
}

  </style>
  <!-- Styles -->
<style>
#chartdiv {
  width: 100%;
  height: 500px;
}
#chartdiv2 {
  width: 100%;
  height: 500px;
}
#chartdiv3 {
  width: 100%;
  height: 500px;
}
#Barchartdiv {
  width: 100%;
  height: 500px;
}
#Linechartdiv {
  width	: 100%;
  height	: 800px;
}	
</style>
<!----     Line Chart         ------------->
<script>
var chart = AmCharts.makeChart("Linechartdiv", {
    "type": "serial",
    "theme": "none",
    "marginTop":5,
	"marginBottom":0,
    "marginRight": 50,
    "dataProvider": {/literal}{$LineGraphData}{literal},
    "valueAxes": [{
        "axisAlpha": 0,
        "position": "left",
		"gridAlpha": 0.2,
    "dashLength": 0
    }],
    "graphs": [{
        "id":"g1",
        "balloonText": "[[category]]<br><b><span style='font-size:14px;'>[[EB]] kwh</span></b>",
        "bullet": "round",
        "bulletSize": 8,
        "lineColor": "#d1655d",
        "lineThickness": 2,
        "negativeLineColor": "#637bb6",
        "type": "smoothedLine",
        "valueField": "EB",
		"animationPlayed": true
    }],
    "chartScrollbar": {
	    "enabled" :false, //true if you need drag  option in top
        "graph":"g1",
        "gridAlpha":0,
        "color":"#888888",
        "scrollbarHeight":55,
        "backgroundAlpha":0,
        "selectedBackgroundAlpha":0.1,
        "selectedBackgroundColor":"#888888",
        "graphFillAlpha":0,
        "autoGridCount":true,
        "selectedGraphFillAlpha":0,
        "graphLineAlpha":0.2,
        "graphLineColor":"#c2c2c2",
        "selectedGraphLineColor":"#888888",
        "selectedGraphLineAlpha":1

    },
    "chartCursor": {
        "categoryBalloonDateFormat": "YYYY",
        "cursorAlpha": 0,
        "valueLineEnabled":true,
        "valueLineBalloonEnabled":true,
        "valueLineAlpha":0.5,
        "fullWidth":true,
		"zoomable": false //true if line chart need zoom option

    },
    "categoryField": "month",
    "export": {
        "enabled": true
    }
});
Linechart.addListener("rendered", zoomChart);
if(Linechart.zoomChart){
  Linechart.zoomChart();
}

function zoomChart(){
    Linechart.zoomToIndexes(Math.round(Linechart.dataProvider.length * 0.4), Math.round(Linechart.dataProvider.length * 0.55));
}

</script>

<!----       AmChart Bar Chart       ---------->
<script>
//var plotBarGraphData=JSON.parse(bGraphData);
var Barchart = AmCharts.makeChart( "Barchartdiv", {
  "type": "serial",
  "theme": "none",
  "dataProvider": {/literal}{$BarGraphData}{literal},
  "valueAxes": [ {
    "gridColor": "#FFFFFF",
    "gridAlpha": 0.2,
    "dashLength": 0
  } ],
  "gridAboveGraphs": true,
  "startDuration": 1,
  "graphs": [ {
    "balloonText": "[[category]]: <b>Rs.[[value]]</b>",
    "fillAlphas": 0.8,
    "lineAlpha": 0.2,
    "type": "column",
    "valueField": "cost"
  } ],
  "chartCursor": {
    "categoryBalloonEnabled": false,
    "cursorAlpha": 0,
    "zoomable": false
  },
  "categoryField": "month",
  "categoryAxis": {
    "gridPosition": "start",
    "gridAlpha": 0,
    "tickPosition": "start",
    "tickLength": 5 // length for x axis bottom line
  },
  "export": {
    "enabled": true
  }

} );
</script>

<!--<script src="https://www.amcharts.com/lib/3/gauge.js"></script>
<script src="https://www.amcharts.com/lib/3/plugins/export/export.min.js"></script>
<link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
-->
  <script>
var chart = AmCharts.makeChart("chartdiv", {
  "theme": "none",
  "type": "gauge",
  "axes": [{
    "topTextFontSize": 20,
    "topTextYOffset": 70,
    "axisColor": "#31d6ea",
    "axisThickness": 1,
    "endValue": {/literal}{$KW_MAX}{literal},
    "gridInside": true,
    "inside": true,
    "radius": "60%",
    "valueInterval": {/literal}{$KW_INT}{literal},
    "tickColor": "#67b7dc",
    "startAngle": -90,
    "endAngle": 90,
    "unit": "",
	"labelsEnabled":true,
    "bandOutlineAlpha": 0,
    "bands": [{
      "color": "#0080ff",
      "endValue": {/literal}{$KW_MAX}{literal},
      "innerRadius": "105%",
      "radius": "170%",
      "gradientRatio": [0.5, 0, -0.5],
      "startValue": 0
    }, {
      "color": "#3cd3a3",
      "endValue": 0,
      "innerRadius": "105%",
      "radius": "170%",
      "gradientRatio": [0.5, 0, -0.5],
      "startValue": 0
    }]
  }],
  "arrows": [{
    "alpha": 1,
    "innerRadius": "35%",
    "nailRadius": 0,
    "radius": "170%"
  }]
});

setInterval(randomValue, 500);

// set random value
function randomValue() {
  var value = {/literal}{$ListFeederDet.0.SUM_KW}{literal};
  chart.arrows[0].setValue(value);
  chart.axes[0].setTopText(value + " KW");
  // adjust darker band to new value
  chart.axes[0].bands[1].setEndValue(value);
}
</script>

 {/literal}
<div class="content-wrapper ">
    <div class="content-header">
      <div class="container-fluid ">
      <div class="row"> <div class="col-md-12">
            <div class="card">
            <div class="card-body">

			 <table style="margin-bottom:-10px;">
		  <tr><td style="font-size:15PX;font-weight: bold;">{$LoctList.0.companyName}&nbsp;&nbsp;</td>
		  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  <td style="font-size:15PX;font-weight: bold;">{$LoctList.0.branch_name}&ensp;&ensp;</td>
		  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  <td style="font-size:15PX;font-weight: bold;">{$LoctList.0.sensorName} <!---({$LoctList.0.gateway_id} / {$LoctList.0.sensorCode})--></font>&nbsp;</td>
		  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  <td style="font-size:15PX;font-weight: bold;">{$LoctList.0.gateway_id} - {if $LoctList.0.gateway_id eq $gateList.0.gateway_code && $gateList.0.gateway_date_time gte $dateSec|date_format:'%Y-%m-%d %H:%M:%S' }<a style="color: #00CC00;"> ON</a> {else} <a style="color: #FF0000;"> OFF </a>{/if}</font>&nbsp;</td>
		   </tr>
		  
		
		  <tr><td style="font-size:10PX;color:#999999;">Company Name</td>
		  <td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  <td style="font-size:10PX;color:#999999;">Branch Name</td>
		  <td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  <td style="color:#999999;font-size:10PX;">Feeder Name (Place of Installation)</td>
		  <td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  <td style="color:#999999;font-size:10PX;">Gateway Name - Status</td>
		  </tr>
		  
		  </table>
		  <input type="hidden" id="gatewayCode" value="{$smarty.get.gatewayCode}" />
		  <input type="hidden" id="sensorCode" value="{$smarty.get.sensorCode}" />
		  
		              <form name="dashboard" id="dashboard" method="post">

   <div  style="margin-top:-40PX;float:right" class="col-md-4"  >

                  <b>Select Feeder &nbsp;&nbsp;: &nbsp;&nbsp;</b><select  id="feederPost" name="feederPost"  style="width:200PX" onchange="postFeeder();">

                     
					  {foreach from=$ListFeeder item=listDet}
					  {if $LoctList.0.sensorName eq $listDet.sensorName}
					   <option value="{$listDet.sensorName}/{$listDet.sensorCode|base64_encode}/{$listDet.gateway_id|base64_encode}/{$listDet.company_id|base64_encode}/{$listDet.branch_id|base64_encode}"  selected="selected">{$LoctList.0.sensorName}</option> {/if}
					   {if $LoctList.0.sensorName neq $listDet.sensorName}
					   <option value="{$listDet.sensorName}/{$listDet.sensorCode|base64_encode}/{$listDet.gateway_id|base64_encode}/{$listDet.company_id|base64_encode}/{$listDet.branch_id|base64_encode}">{$listDet.sensorName}</option>
					   {/if}
					  {/foreach}

                    </select>


                    
                    </div>
					</form>

		    </div>
			</div>
			</div>
			
          <!--<div class="col-md-12 >
		  
            <div class="info-box">
              <div class="info-box-content">
                 <span class="pull-left text-info"><h5><b>{$LoctList.0.companyName}&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp; {$LoctList.0.branch_name}&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp; {$LoctList.0.gateway_id}&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;{$LoctList.0.sensorName}</b></h5></span>
              </div>
            </div>
          </div>-->
          </div>
		  <div class="row">
          <div class="row col-4">
          <div class="col-12 col-sm-6 col-md-6">
            <div class="info-box card-outline card-primary">
              <span class="info-box-icon bg-info elevation-1"><i class="fa fa-rupee"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Today Cost&ensp;&ensp;&ensp;&ensp;</span>
                <span class="info-box-number">
                  {if $todayCostKWH.0.cost eq ''}0.00{else}{$todayCostKWH.0.cost}{/if}
                  <small></small>
                </span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-12 col-sm-6 col-md-6">
            <div class="info-box mb-2 card-outline card-danger">
              <span class="info-box-icon bg-danger elevation-1"><i class="fa fa-bolt"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Today KWH&ensp;&ensp;&ensp;&ensp;</span>
                <span class="info-box-number">{if $todayCostKWH.0.TOTAL_KWH eq ''}0.00{else}{$todayCostKWH.0.TOTAL_KWH}{/if}</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->

          <!-- fix for small devices only -->
          <div class="clearfix hidden-md-up"></div>

          <div class="col-12 col-sm-6 col-md-6">
            <div class="info-box mb-2 card-outline card-primary">
              <span class="info-box-icon bg-info elevation-1"><i class="fa fa-rupee"></i></span>

              <div class="info-box-content">
                <span class="info-box-text"><!--{$smarty.now|date_format:"%B"}--> This Month Cost</span>
                <span class="info-box-number"><!--{assign var="monthCost" value=$monthCostKWH.0.cost+$todayCostKWH.0.cost}-->{if $monthCostKWH.0.cost eq ''}0.00{else}{$monthCostKWH.0.cost}{/if}</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-12 col-sm-6 col-md-6">
            <div class="info-box mb-2 card-outline card-danger">
              <span class="info-box-icon bg-danger elevation-1"><i class="fa fa-bolt"></i></span>

              <div class="info-box-content">
                <span class="info-box-text"><!--{$smarty.now|date_format:"%B"}-->This Month KWH</span>
                <span class="info-box-number"><!--{assign var="monthKwh" value=$monthCostKWH.0.TOTAL_KWH+$todayCostKWH.0.TOTAL_KWH}-->{if $monthCostKWH.0.TOTAL_KWH eq ''}0.00{else}{$monthCostKWH.0.TOTAL_KWH}{/if}</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <!-- fix for small devices only -->
          <div class="clearfix hidden-md-up"></div>

          <div class="col-12 col-sm-6 col-md-6">
            <div class="info-box mb-2 card-outline card-primary">
              <span class="info-box-icon bg-info elevation-1"><i class="fa fa-rupee"></i></span>

              <div class="info-box-content">
                <span class="info-box-text"><!--{$smarty.now|date_format:"%B"}-->Last Month Cost</span>
                <span class="info-box-number">{if $LastMonthCostKWH.0.cost eq ''}0.00{else}{$LastMonthCostKWH.0.cost}{/if}</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-12 col-sm-6 col-md-6">
            <div class="info-box mb-2 card-outline card-danger">
              <span class="info-box-icon bg-danger elevation-1"><i class="fa fa-bolt"></i></span>

              <div class="info-box-content">
                <span class="info-box-text"><!--{$smarty.now|date_format:"%B"}-->Last Month KWH</span>
                <span class="info-box-number">{if $LastMonthCostKWH.0.TOTAL_KWH eq ''}0.00{else}{$LastMonthCostKWH.0.TOTAL_KWH}{/if}</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
        </div>
		<div class="col-md-4" >

            <div class="card card-widget widget-user-2">

              <div class="card card-outline card-primary">

			  <div class="card-header">
			   <h5 class="" style="text-align:left"><b>KW </b><!--<span class="float-right badge bg-warning">9.60</span>--></h5>

			  </div>
			  </div>
			   <div class="card-footer" style="height:200PX">

                <ul class="nav flex-column" >
                    <li class="nav-item" style="backgroud-color:white">

  			 <div id="chartdiv" style="margin-top:-115PX"></div>

                   

                  </li>
				  
				  </ul>
				  </div>
			  </div>
			  </div>
			  <div class="col-md-4">
            <!-- Widget: user widget style 2 -->
            <div class="card card-widget widget-user-2">
              <!-- Add the bg color to the header using any of the bg-* classes -->
              
              <div class="card-footer p-0">
                <ul class="nav flex-column">
				  <li class="nav-item">
                    <a href="#" class="nav-link" style="text-decoration:none;color:black">
                      <b>Feeder Name </b><span class="float-right badge bg-success">{$ListFeederDet.0.sensorName}</span>
                    </a>
                  </li>

                  <li class="nav-item">
                    <a href="#" class="nav-link" style="text-decoration:none;color:black">
                      <b>KWH</b> <span class="float-right badge bg-danger">{$ListFeederDet.0.KWH}</span>
                    </a>
                  </li>
				  <li class="nav-item">
                    <a href="#" class="nav-link" style="text-decoration:none;color:black">
                     <b> Status - {$ListFeederDet.0.recorded_date_time|date_format:"%d-%b-%Y %I:%M %p"} </b><span class="float-right badge bg-success">Last Logged</span>
                    </a>
                  </li>
                  
                </ul>
              </div>
            </div>
            <!-- /.widget-user -->
          </div>
		</div>
        <!-- /.row -->
		  {if $ListFeederDet2 eq "0"}
		  <div class="row">
            <div class="col-md-12">
            <div class="card">
            <div class="card-body">
			<h1 align="center" style="color:#FF0000"> No Records Found  </h1>
			</div>
			</div></div></div>
		  {else}
            <div class="row">
            <div class="col-md-12">
            <div class="card">
            <div class="card-body">
			 
			 
			 
<!--            <div class="row" style="display:none" id="ttt">
-->            

<div class="row">
<div class="col-md-6">
            <!-- Bar chart -->
            <div class="card card-primary card-outline">
              <div class="card-header">
                <h3 class="card-title">
                  <i class="far fa-chart-bar"></i>
                  Cost Chart
                </h3>

                <!--<div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>-->
              </div>
             
                <div id="Barchartdiv" style="height: 300px;"></div>
              
              <!-- /.card-body-->
            </div>
            <!-- /.card -->

            <!-- Donut chart -->
            
            <!-- /.card -->
          </div>
          <div class="col-md-6">
            <!-- Line chart -->
            <div class="card card-primary card-outline">
              <div class="card-header">
                <h3 class="card-title">
                  <i class="far fa-chart-bar"></i>
                  Kwh Chart
                </h3>

         <!--       <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
                  </button>
                </div>-->
              </div>
              <div class="card-body">
                <div id="Linechartdiv" style="height: 260px;"></div>
              </div>
              <!-- /.card-body-->
            </div>
            <!-- /.card -->

            <!-- Area chart -->
            
            <!-- /.card -->

          </div>
          <!-- /.col -->

          
          <!-- /.col -->
        </div>
        <div class="row">
       <div class="col-md-12">
            <div class="card card-primary card-tabs">
              <div class="card-header p-0 pt-1 border-bottom-0">
            <ul class="nav nav-tabs" id="custom-content-below-tab" role="tablist">
            <!-- <li class="nav-item">
                <a class="nav-link active" id="custom-content-below-profile-tab" data-toggle="pill" href="#tab-1" role="tab" aria-controls="custom-content-below-profile" aria-selected="true">Historical Trend</a>
              </li>-->
			  <!--  <li class="nav-item">
                <a class="nav-link " id="custom-content-below-home-tab" data-toggle="pill" href="#tab-2" role="tab" aria-controls="custom-content-below-home" aria-selected="false">Online Trend</a>
              </li>-->
              <!--<li class="nav-item">
                <a class="nav-link " id="custom-content-below-home-tab" data-toggle="pill" href="#tab-2" role="tab" aria-controls="custom-content-below-home" aria-selected="false">Meter View</a>
              </li>-->
             
              <li class="nav-item">
                <a class="nav-link active" id="custom-content-below-messages-tab" data-toggle="pill" href="#tab-3" role="tab" aria-controls="custom-content-below-messages" aria-selected="false">Log Report</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="custom-content-below-messages-tab" data-toggle="pill" href="#tab-4" role="tab" aria-controls="custom-content-below-messages" aria-selected="false">Daily Report</a>
              </li>
              
            </ul>
            </div>
            
            
            
            
            <div class="tab-content" >
            	              <div id="tab-3" class="tab-pane active">
								<div class="loader" style="background-color:#999999"></div>
                        		<!--	<iframe  height="820px" width="98%" src="./icd_meter_log.php?id={$smarty.get.this1}" style="border:1px;"></iframe> -->
                        		<div class="card-body">
                        		<iframe id="log_report" height="820px" width="98%"  src="" style="border:1px;"></iframe>
                                </div>
                                </div>
                                <div id="tab-4" class="tab-pane" >
								<div class="loader"></div>
								<div class="card-body">
                        		<!--	<iframe  height="820px" width="98%" src="./icd_meter_log.php?id={$smarty.get.this1}" style="border:1px;"></iframe> -->
                        		<iframe id="daily_report" height="820px" width="98%" src="" style="border:1px;"></iframe>
                                </div>
                                
                            </div>
          </div>
        </div>
        
        </div>
      </div>
    </div>
  </div>
  </div>{/if}
  </div>
  </div>
  </div>
  {literal}
 <style>
 .loader {
  margin: 200px auto;
  font-size: 25px;
  width: 1em;
  height: 1em;
  border-radius: 50%;
  position: relative;
  text-indent: -9999em;
  -webkit-animation: load5 1.1s infinite ease;
  animation: load5 1.1s infinite ease;
  -webkit-transform: translateZ(0);
  -ms-transform: translateZ(0);
  transform: translateZ(0);
}
@-webkit-keyframes load5 {
  0%,
  100% {
    box-shadow: 0em -2.6em 0em 0em #0a7b6e, 1.8em -1.8em 0 0em rgba(10,123,110, 0.2), 2.5em 0em 0 0em rgba(10,123,110, 0.2), 1.75em 1.75em 0 0em rgba(10,123,110, 0.2), 0em 2.5em 0 0em rgba(10,123,110, 0.2), -1.8em 1.8em 0 0em rgba(10,123,110, 0.2), -2.6em 0em 0 0em rgba(10,123,110, 0.5), -1.8em -1.8em 0 0em rgba(10,123,110, 0.7);
  }
  12.5% {
    box-shadow: 0em -2.6em 0em 0em rgba(10,123,110, 0.7), 1.8em -1.8em 0 0em #0a7b6e, 2.5em 0em 0 0em rgba(10,123,110, 0.2), 1.75em 1.75em 0 0em rgba(10,123,110, 0.2), 0em 2.5em 0 0em rgba(10,123,110, 0.2), -1.8em 1.8em 0 0em rgba(10,123,110, 0.2), -2.6em 0em 0 0em rgba(10,123,110, 0.2), -1.8em -1.8em 0 0em rgba(10,123,110, 0.5);
  }
  25% {
    box-shadow: 0em -2.6em 0em 0em rgba(10,123,110, 0.5), 1.8em -1.8em 0 0em rgba(10,123,110, 0.7), 2.5em 0em 0 0em #0a7b6e, 1.75em 1.75em 0 0em rgba(10,123,110, 0.2), 0em 2.5em 0 0em rgba(10,123,110, 0.2), -1.8em 1.8em 0 0em rgba(10,123,110, 0.2), -2.6em 0em 0 0em rgba(10,123,110, 0.2), -1.8em -1.8em 0 0em rgba(10,123,110, 0.2);
  }
  37.5% {
    box-shadow: 0em -2.6em 0em 0em rgba(10,123,110, 0.2), 1.8em -1.8em 0 0em rgba(10,123,110, 0.5), 2.5em 0em 0 0em rgba(10,123,110, 0.7), 1.75em 1.75em 0 0em #0a7b6e, 0em 2.5em 0 0em rgba(10,123,110, 0.2), -1.8em 1.8em 0 0em rgba(10,123,110, 0.2), -2.6em 0em 0 0em rgba(10,123,110, 0.2), -1.8em -1.8em 0 0em rgba(10,123,110, 0.2);
  }
  50% {
    box-shadow: 0em -2.6em 0em 0em rgba(10,123,110, 0.2), 1.8em -1.8em 0 0em rgba(10,123,110, 0.2), 2.5em 0em 0 0em rgba(10,123,110, 0.5), 1.75em 1.75em 0 0em rgba(10,123,110, 0.7), 0em 2.5em 0 0em #0a7b6e, -1.8em 1.8em 0 0em rgba(10,123,110, 0.2), -2.6em 0em 0 0em rgba(10,123,110, 0.2), -1.8em -1.8em 0 0em rgba(10,123,110, 0.2);
  }
  62.5% {
    box-shadow: 0em -2.6em 0em 0em rgba(10,123,110, 0.2), 1.8em -1.8em 0 0em rgba(10,123,110, 0.2), 2.5em 0em 0 0em rgba(10,123,110, 0.2), 1.75em 1.75em 0 0em rgba(10,123,110, 0.5), 0em 2.5em 0 0em rgba(10,123,110, 0.7), -1.8em 1.8em 0 0em #0a7b6e, -2.6em 0em 0 0em rgba(10,123,110, 0.2), -1.8em -1.8em 0 0em rgba(10,123,110, 0.2);
  }
  75% {
    box-shadow: 0em -2.6em 0em 0em rgba(10,123,110, 0.2), 1.8em -1.8em 0 0em rgba(10,123,110, 0.2), 2.5em 0em 0 0em rgba(10,123,110, 0.2), 1.75em 1.75em 0 0em rgba(10,123,110, 0.2), 0em 2.5em 0 0em rgba(10,123,110, 0.5), -1.8em 1.8em 0 0em rgba(10,123,110, 0.7), -2.6em 0em 0 0em #0a7b6e, -1.8em -1.8em 0 0em rgba(10,123,110, 0.2);
  }
  87.5% {
    box-shadow: 0em -2.6em 0em 0em rgba(10,123,110, 0.2), 1.8em -1.8em 0 0em rgba(10,123,110, 0.2), 2.5em 0em 0 0em rgba(10,123,110, 0.2), 1.75em 1.75em 0 0em rgba(10,123,110, 0.2), 0em 2.5em 0 0em rgba(10,123,110, 0.2), -1.8em 1.8em 0 0em rgba(10,123,110, 0.5), -2.6em 0em 0 0em rgba(10,123,110, 0.7), -1.8em -1.8em 0 0em #0a7b6e;
  }
}
@keyframes load5 {
  0%,
  100% {
    box-shadow: 0em -2.6em 0em 0em #0a7b6e, 1.8em -1.8em 0 0em rgba(10,123,110, 0.2), 2.5em 0em 0 0em rgba(10,123,110, 0.2), 1.75em 1.75em 0 0em rgba(10,123,110, 0.2), 0em 2.5em 0 0em rgba(10,123,110, 0.2), -1.8em 1.8em 0 0em rgba(10,123,110, 0.2), -2.6em 0em 0 0em rgba(10,123,110, 0.5), -1.8em -1.8em 0 0em rgba(10,123,110, 0.7);
  }
  12.5% {
    box-shadow: 0em -2.6em 0em 0em rgba(10,123,110, 0.7), 1.8em -1.8em 0 0em #0a7b6e, 2.5em 0em 0 0em rgba(10,123,110, 0.2), 1.75em 1.75em 0 0em rgba(10,123,110, 0.2), 0em 2.5em 0 0em rgba(10,123,110, 0.2), -1.8em 1.8em 0 0em rgba(10,123,110, 0.2), -2.6em 0em 0 0em rgba(10,123,110, 0.2), -1.8em -1.8em 0 0em rgba(10,123,110, 0.5);
  }
  25% {
    box-shadow: 0em -2.6em 0em 0em rgba(10,123,110, 0.5), 1.8em -1.8em 0 0em rgba(10,123,110, 0.7), 2.5em 0em 0 0em #0a7b6e, 1.75em 1.75em 0 0em rgba(10,123,110, 0.2), 0em 2.5em 0 0em rgba(10,123,110, 0.2), -1.8em 1.8em 0 0em rgba(10,123,110, 0.2), -2.6em 0em 0 0em rgba(10,123,110, 0.2), -1.8em -1.8em 0 0em rgba(10,123,110, 0.2);
  }
  37.5% {
    box-shadow: 0em -2.6em 0em 0em rgba(10,123,110, 0.2), 1.8em -1.8em 0 0em rgba(10,123,110, 0.5), 2.5em 0em 0 0em rgba(10,123,110, 0.7), 1.75em 1.75em 0 0em #0a7b6e, 0em 2.5em 0 0em rgba(10,123,110, 0.2), -1.8em 1.8em 0 0em rgba(10,123,110, 0.2), -2.6em 0em 0 0em rgba(10,123,110, 0.2), -1.8em -1.8em 0 0em rgba(10,123,110, 0.2);
  }
  50% {
    box-shadow: 0em -2.6em 0em 0em rgba(10,123,110, 0.2), 1.8em -1.8em 0 0em rgba(10,123,110, 0.2), 2.5em 0em 0 0em rgba(10,123,110, 0.5), 1.75em 1.75em 0 0em rgba(10,123,110, 0.7), 0em 2.5em 0 0em #0a7b6e, -1.8em 1.8em 0 0em rgba(10,123,110, 0.2), -2.6em 0em 0 0em rgba(10,123,110, 0.2), -1.8em -1.8em 0 0em rgba(10,123,110, 0.2);
  }
  62.5% {
    box-shadow: 0em -2.6em 0em 0em rgba(10,123,110, 0.2), 1.8em -1.8em 0 0em rgba(10,123,110, 0.2), 2.5em 0em 0 0em rgba(10,123,110, 0.2), 1.75em 1.75em 0 0em rgba(10,123,110, 0.5), 0em 2.5em 0 0em rgba(10,123,110, 0.7), -1.8em 1.8em 0 0em #0a7b6e, -2.6em 0em 0 0em rgba(10,123,110, 0.2), -1.8em -1.8em 0 0em rgba(10,123,110, 0.2);
  }
  75% {
    box-shadow: 0em -2.6em 0em 0em rgba(10,123,110, 0.2), 1.8em -1.8em 0 0em rgba(10,123,110, 0.2), 2.5em 0em 0 0em rgba(10,123,110, 0.2), 1.75em 1.75em 0 0em rgba(10,123,110, 0.2), 0em 2.5em 0 0em rgba(10,123,110, 0.5), -1.8em 1.8em 0 0em rgba(10,123,110, 0.7), -2.6em 0em 0 0em #0a7b6e, -1.8em -1.8em 0 0em rgba(10,123,110, 0.2);
  }
  87.5% {
    box-shadow: 0em -2.6em 0em 0em rgba(10,123,110, 0.2), 1.8em -1.8em 0 0em rgba(10,123,110, 0.2), 2.5em 0em 0 0em rgba(10,123,110, 0.2), 1.75em 1.75em 0 0em rgba(10,123,110, 0.2), 0em 2.5em 0 0em rgba(10,123,110, 0.2), -1.8em 1.8em 0 0em rgba(10,123,110, 0.5), -2.6em 0em 0 0em rgba(10,123,110, 0.7), -1.8em -1.8em 0 0em #0a7b6e;
  }
}
 </style>
<script type="text/javascript">
/*$(document).ready(function(){
setTimeout(function(){  
   $("#loadDate").show();
  }, 1000);
    
});*/
var gId=$("#gatewayCode").val();
var sId=$("#sensorCode").val();
var pageURL = $(location).attr("href");
  //          alert($(location).attr('hostname'));


window.onload = function(){
 setTimeout(function(){
// alert(gId);
 //  document.getElementById('trendGraph').src = './trendsGraph.php?gatewayCode='+gId+'&sensorCode='+sId;
   document.getElementById('log_report').src =  './icdMeterLog.php?gatewayCode='+gId+'&sensorCode='+sId;
   document.getElementById('daily_report').src = './energyMeterDlyReport.php?gatewayCode='+gId+'&sensorCode='+sId;
   setTimeout(function(){ $(".loader").hide();},2000);

 },2000);
};
/*$(document).ready(function() {
    $("#ttt").delay(1000).fadeIn(1000);
});*/
function postFeeder()
{
 var feederName=document.getElementById("feederPost").value;
 var feedSplit= feederName.split("/");
 var senCod=feedSplit[1];
 var gatCod=feedSplit[2];
 var comId=feedSplit[3];
 var branId=feedSplit[4];
  FormName		= document.dashboard;
  FormName.action= "meterDashboard.php?companyId="+comId+"&branchId="+branId+"&sensorCode="+senCod+"&gatewayCode="+gatCod;
  FormName.submit();

}
</script>

  {/literal}
  {include file="footer.tpl"}