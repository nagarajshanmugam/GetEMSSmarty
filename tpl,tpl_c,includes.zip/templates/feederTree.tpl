	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				{if $smarty.get.branchId}  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
						<td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>{/if}
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">Mimic SLD</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			{if $smarty.get.sl_no eq ""} 
			<a href="feederList.php?companyId={$smarty.get.companyId}&gatewayId={$smarty.get.gatewayId}&branchId={$smarty.get.branchId}"><button type="button" style="float:right;margin-top:-40PX" class="btn btn-primary">List Feeder</button></a>
			{else}
			<a href="feederList.php?companyId={$smarty.get.companyId}&gatewayId={$smarty.get.gatewayId}&branchId={$smarty.get.branchId}"><button type="button" style="float:right;;margin-top:-40PX" class="btn btn-primary" >List Feeder </button></a>
			{/if}
			</div>
		</div>
		<div class="card">
			<div class="card-body">
			 <!--------------  Tree Diagram Starts here     -------------------->
				<div class="tree" style="display:flex;flex-wrap:wrap;justify-content: center;" >
					<ul>
					{foreach from=$ListMainMeter item=ListMain}
					<li>
					<a href="#" style="background-color:#FF0000;color:#FFFFFF; font-size:15PX;font-weight: bold;">{$ListMain.feeder_name}</a>
					<ul>
					{foreach from=$ListSubMeter item=ListSub}
					{if $ListMain.feeder_master_id eq $ListSub.parent_id}
					<li>
					<a href="#"  style="background-color:#0000CC;color:#FFFFFF;font-size:15PX;font-weight: bold;">{$ListSub.feeder_name}</a>
					<ul>
						{foreach from=$ListSubSubMeter item=ListSubSub}
							{if $ListMain.feeder_master_id eq $ListSubSub.parent_id && $ListSub.feeder_master_id eq $ListSubSub.submeter_id }
							<li>
								<a href="#"  style="background-color:#33FF33;color:#FFFFFF;font-size:15PX;font-weight: bold;">{$ListSubSub.feeder_name}</a>
							</li>
							{/if}
						{/foreach}
					</ul>
					</li>
					{/if}
					{/foreach}
					</ul>
					</li>
					{/foreach}
					</ul>
				</div>
			<!--------------  Tree Diagram End here     -------------------->
			</div>
		</div>
	</div>
	</section>
	</div>
	{literal}
		<script >
		function GoBack()
		{
			window.history.back();
		}
		</script>
		<script type="text/javascript">
		function locationDecode(){
			var lid = {$smarty.get.location_id};
			var uri_lid = decodeURIComponent(lid);
			alert(uri_lid);
		}
		</script>
		<style>
		/*Now the CSS*/
		* {margin: 0; padding: 0;}
		.tree ul {
		padding-top: 20px; position: relative;
		
		transition: all 0.5s;
		-webkit-transition: all 0.5s;
		-moz-transition: all 0.5s;
		}
		.tree li {
		float: left; text-align: center;
		list-style-type: none;
		position: relative;
		padding: 20px 5px 0 5px;
		transition: all 0.5s;
		-webkit-transition: all 0.5s;
		-moz-transition: all 0.5s;
		}
		/*We will use ::before and ::after to draw the connectors*/
		.tree li::before, .tree li::after{
		content: '';
		position: absolute; top: 0; right: 50%;
		border-top: 1px solid #ccc;
		width: 50%; height: 20px;
		}
		.tree li::after{
		right: auto; left: 50%;
		border-left: 1px solid #ccc;
		}
		/*We need to remove left-right connectors from elements without 
		any siblings*/
		.tree li:only-child::after, .tree li:only-child::before {
		display: none;
		}
		/*Remove space from the top of single children*/
		.tree li:only-child{ padding-top: 0;}
		/*Remove left connector from first child and 
		right connector from last child*/
		.tree li:first-child::before, .tree li:last-child::after{
		border: 0 none;
		}
		/*Adding back the vertical connector to the last nodes*/
		.tree li:last-child::before{
		border-right: 1px solid #ccc;
		border-radius: 0 5px 0 0;
		-webkit-border-radius: 0 5px 0 0;
		-moz-border-radius: 0 5px 0 0;
		}
		.tree li:first-child::after{
		border-radius: 5px 0 0 0;
		-webkit-border-radius: 5px 0 0 0;
		-moz-border-radius: 5px 0 0 0;
		}
		/*Time to add downward connectors from parents*/
		.tree ul ul::before{
		content: '';
		position: absolute; top: 0; left: 50%;
		border-left: 1px solid #ccc;
		width: 0; height: 20px;
		}
		.tree li a{
		border: 1px solid #ccc;
		padding: 5px 10px;
		text-decoration: none;
		color: #666;
		font-family: arial, verdana, tahoma;
		font-size: 11px;
		display: inline-block;
		border-radius: 5px;
		-webkit-border-radius: 5px;
		-moz-border-radius: 5px;
		transition: all 0.5s;
		-webkit-transition: all 0.5s;
		-moz-transition: all 0.5s;
		}
		/*Time for some hover effects*/
		/*We will apply the hover effect the the lineage of the element also*/
		.tree li a:hover, .tree li a:hover+ul li a {
		background: #c8e4f8; color: #000; border: 1px solid #94a0b4;
		}
		/*Connector styles on hover*/
		.tree li a:hover+ul li::after, 
		.tree li a:hover+ul li::before, 
		.tree li a:hover+ul::before, 
		.tree li a:hover+ul ul::before{
		border-color:  #94a0b4;
		}
		</style>
	
		<style>
		
		.isa_success
		{
		color:#4F8A10;
		background-color:#DFF2BF;
		}
		.error
		{
		color:#D8000C;
		}
		.isa_error
		{
		color:#D8000C;
		background-color:#FFBABA;
		}
		.isa_success i,.isa_error i
		{
		margin:10px 22px;
		font-size:2em;
		}
		.required
		{
		color:#FF0000;
		}
		</style>
	{/literal}
	{include file="footer.tpl"}