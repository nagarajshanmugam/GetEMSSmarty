	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
					<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="font-size:15PX;font-weight: bold;">{$ListEditView.0.location_code}&nbsp;&nbsp;</td>
					<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
						<td style="font-size:15PX;font-weight: bold;">{$ListEditView.0.location_name}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">Location Details</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:10PX;color:#999999;">Location Code</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:10PX;color:#999999;">Location Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			</div>
		</div>
		<form name="location_detail_form" method="post" id="location_detail_form">
		<div class="row">
			<div class="col-12">
				<div class="card">
				{if $SuccessMessage neq "" || $ErrorMessage neq ""}
					<div class="card-body">
					{if $SuccessMessage neq ""}
						<div class="isa_success">
						<i class="fa fa-check"></i>
						{$SuccessMessage}		 
						</div>
					{/if}
					{if $ErrorMessage neq ""}
						<div class="isa_error">
						<i class="fa fa-check"></i>
						{$ErrorMessage}		 
						</div>
					{/if}
					</div>
				{/if}
					<div class="card-body table-responsive">
					<a href="locationList.php?companyId={$smarty.get.companyId}&branchId={$smarty.get.branchId}"><button type="button" style="float:right;margin-top:-6px" class="btn btn-primary">List Location</button></a>
						<table id="example" class="table table-bordered table-hover">
						<thead>
						<tr>
						<th>#</th>
						<th>Sensor</th>
						<th>IOT</th>
						<th>Start Date Time</th>
						<th>End Date Time</th>
						</tr>
						</thead>
						<tbody>
						{foreach from=$GetLocationData item=Detail}
						<tr id="{$j++}">
						<td class="slno">{$j}</td>
						<td>{$Detail.sensorName}</td>
						<td>{$Detail.gateway_id}</td>
						<td>{$Detail.start_date_time|date_format:'%d-%b-%Y  %r'}</td>
                        <td>
                        {if $Detail.end_date_time != '' 
                        && $Detail.end_date_time != '0000-00-00 00:00:00' 
                        && $Detail.end_date_time != 'NULL'}
                        {$Detail.end_date_time|date_format:'%d-%b-%Y  %r'}
                        {else}
                        <span style="color:#009900"><b>Till Now</b></span>
                        {/if}
                        </td>
						</tr>
						{foreachelse}
						<tr><td colspan="8"><center>No Records Found</center></td></tr>
						{/foreach}						
						</tbody>
						</table>
					</div>
				</div>
			</div>
		</form>
	</section>
	</div>
	{literal}
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>
	<script type="text/javascript">
	$(document).ready(function (){
	var table = $('#example').DataTable({
	"ordering" : false,
	language: {
	"infoFiltered": "",
	search: "_INPUT_",
	searchPlaceholder: "Search..."
	},
	dom: '<"pull-left" f><bottom>p',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: '<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p',
	//dom: '<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p',
	buttons: [
	{
	text: 'Create Box',
	className: 'btn btn-create',
	titleAttr: 'Create Box',
	action: function ( e, dt, button, config ) {
	window.location = 'AddEditBox.php';
	}        
	}
	],
	initComplete: function(){
	$("div.toolbar").html('<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>');   	
	}       
	}); 
	}); 
	
	function editCats(slNoIdent, comId, branchId) {
	
		var sid = btoa(slNoIdent);
		var cid = btoa(comId);
		var bid = btoa(branchId);

		FormName		= document.location_detail_form;
		FormName.action ='locationAddEdit.php?locId='+sid+'&companyId='+cid+'&branchId='+bid+'&Update=y';
		FormName.submit();
	}

	function detailCats(slNoIdent, comId, branchId) {
	
		var sid = btoa(slNoIdent);
		var cid = btoa(comId);
		var bid = btoa(branchId);

		FormName		= document.location_detail_form;
		FormName.action ='locationDetails.php?locId='+sid+'&companyId='+cid+'&branchId='+bid+'&Update=y';
		FormName.submit();
	}
	


	</script>
	<script type="text/javascript">
	function deleteCats(slNoIdent, comId, branchId){
		var sid = btoa(slNoIdent);
		var cid = btoa(comId);
		var bid = btoa(branchId);
		if(confirm("Are you sure to Delete this Record?")){
			FormName		= document.location_detail_form;
			FormName.action= 'locationList.php?locId='+sid+'&companyId='+cid+'&branchId='+bid;
			FormName.submit();
		}
	}
	</script>
	{/literal}
	{include file="footer.tpl"}