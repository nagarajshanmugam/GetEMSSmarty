 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <!--<section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
		  <ol class="breadcrumb float-sm">
              <li class="breadcrumb-item">{$GetCompanyView.0.companyName}</li>
			  <li class="breadcrumb-item">{$BranchView.0.branch_name}</li>
               <li class="breadcrumb-item">{$smarty.get.gatewayId|base64_decode}</li>
              <li class="breadcrumb-item active">List Sensor</li>
            </ol>
          </div>
          <div class="col-sm-6">
            
          </div>
        </div>
      </div>
    </section>-->

     <!-- Main content -->
     <section class="content-header">
	<div class="card">
            <div class="card-header">

		   <table style="margin-bottom:-10px;">
		  <tr><td style="font-size:15PX;font-weight: bold;">{$companyDetail.0.companyName}&nbsp;&nbsp;</td>
           <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
           {if $branchDetail.0.branch_name neq ""}
            <td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&nbsp;&nbsp;</font>&nbsp;</td>
			<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
            {/if}
		  <td style="font-size:15PX;font-weight: bold;">{$smarty.get.monthData|base64_decode}</font>&nbsp;</td>
		  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  <td style="font-size:15PX;font-weight: bold;">View Unit Rate</font>&nbsp;</td>
          </tr>
		  
		
		  <tr><td style="font-size:10PX;color:#999999;">Company Name</td>
		  <td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  {if $branchDetail.0.branch_name neq ""}
			<td style="color:#999999;font-size:10PX;">Branch Name</td>
            <td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
            {/if}
		  <td style="color:#999999;font-size:10PX;">Month Name</td>
          <td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  <td style="color:#999999;font-size:10PX;"></td>
		  </tr>
		  
		  </table></div>
        
      </div>
	 <form name="meterList" method="post" id="meterList" onsubmit="return ValidateFields();">
      <input type="hidden" name="hdAction" id="hdAction">
              <input type="hidden" id="companyId" name="companyId" value="{$smarty.get.companyId}" />
               <input type="hidden" id="branch_id" name="branch_id" value="{$smarty.get.branch_id}" />
              <input type="hidden" id="monthData" name="monthData" value="{$smarty.get.monthData}" />
              <input type="hidden" id="item_id" name="item_id" value="{$smarty.post.item_id}" />
              <input type="hidden" id="checkVal" name="checkVal" value="0" />
      <div class="row">
	 
        <div class="col-12">
          <div class="card">
		  
            
            {if $SuccessMessage neq "" || $ErrorMessage neq ""}
            <div class="card-body">
					{if $SuccessMessage neq ""}
					<div class="isa_success">
					<i class="fa fa-check"></i>
					{$SuccessMessage}		 
					</div>
					{/if}
					{if $ErrorMessage neq ""}
					<div class="isa_error">
					<i class="fa fa-check"></i>
					{$ErrorMessage}		 
					</div>
					{/if}
					</div>
                    {/if}
            <!-- /.card-header -->
        <div class="card-body">
       {if $smarty.session.USER_GROUP eq "Branch User" || $smarty.session.USER_GROUP eq "Branch Admin"} <a href="listBilling.php?companyId={$smarty.get.companyId}&branchId={$smarty.get.branchId}"> <button type="button" class="btn btn-create" value="Create Userrole" style="float:right;margin-top:-6PX">List Billing</button></a>{else}<a href="listBilling.php?companyId={$smarty.get.companyId}"> <button type="button" class="btn btn-create" value="Create Userrole" style="float:left;margin-top:-6PX">List Billing</button></a>{/if}
                 <!-- <div class="col-sm-3" style="float:right;">
                  <div class="custom-control custom-checkbox">
                   <label for="" style="margin-top:-15%; margin-left:-25%;">Unit Rate For All</label>
                   <input class="custom-control-input" type="checkbox" id="customCheckbox2"  name="customCheckbox2" tabindex="6" onclick="setCheck();" style="margin-top:-15%; margin-left:25%;">
                   <label for="customCheckbox2" class="custom-control-label" style="margin-top:; margin-left:25%;"></label>
                   <input type="text" class="form-control form-control-sm disrate" id="unitrate" name="unitrate" placeholder="Unit Rate" value="{$smarty.post.unitrate}" tabindex="1" autocomplete="Off" style="margin-top:-15%;margin-left:50%; width:45%;" onkeyup="numericFilter(this);setCheckVal();" readonly>
                   
                          
                        </div>
                         </div>-->
                  
					<br />	<br />

					         
             <table id="example" class="table table-bordered table-hover">
                <thead>
                <tr>
    			  <th class="slNo">#</th>
				   <th class="">Place Of Installation</th>
                   <th class="">Unit Rate</th>
                 
                </tr>
                </thead>
                <tbody>
				{foreach from=$ListMonthData item=List}
				
                <tr id="{$j++}">
				 <td >{$j}</td>
				 <td>{$List.sensorName} ( {$List.feeder_type} )</td>
                 <td align="right">{$List.unit_rate}</td>
              
                  
                </tr>
				
               {foreachelse}
                <tr><td colspan="8"><center>No Records Found</center></td></tr>
                {/foreach}
               
               
                </tbody>
              </table>
            </div>
<!--<div align="center">
                 <input type="submit" value="Submit" class="btn btn-create" tabindex="8" />
                </div>-->
                <br />
         <!-- /.card-body -->
          </div>
          <!-- /.card -->
          </div>
		  </form>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  {literal}
 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
<!--  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
-->  <script>
  $( function() {
    $( "#fromDate" ).datepicker({changeMonth: true,
    changeYear: true,maxDate: '0',dateFormat:'yy-mm-dd'});
	 $( "#toDate" ).datepicker({changeMonth: true,
    changeYear: true,maxDate: '0',dateFormat:'yy-mm-dd'});
  } );
  </script>
  <script type="text/javascript">
  
        $(document).ready(function() {
            $('#monthName').on('change', function() {
                this.form.submit();
            });
        });
		
        </script>
  <style>
  .slNo{
  width:5%;
  }
  .code{
  width:10%;
  }
  .apiKey{
  width:30%;
  }
  .name{
  width:40%;
  }
  .isactive{
  width:10%;
  text-align:center;

  }
   .action{
  text-align:right;
    }
.isa_success
{
color:#4F8A10;
background-color:#DFF2BF;
}
.error
{
color:#D8000C;
/*background-color:#FFBABA;*/
}
.isa_error
{
color:#D8000C;
background-color:#FFBABA;
}
.isa_success i,.isa_error i
{
margin:10px 22px;
font-size:2em;
/*vertical-align:middle;*/
}
</style>

  <script type="text/javascript">
    $(document).ready(function (){

var table = $('#example').DataTable({
	 "ordering" : false,
	 "pageLength": 50,
      language: {
	    "infoFiltered": "",
        search: "_INPUT_",
        searchPlaceholder: "Search...",
		search:false
    },
	dom: '<"pull-left" f><bottom>p',
	tableTools: {
          "sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
        },
	//dom: '<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p',
	//dom: '<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p',
	
       initComplete: function(){
        //  $("div.toolbar").html('<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>');   
		
		 
       }       
    }); 

}); 

  
  function unitPriceCats(slNoIdent,metIdIdent,compIdent,locIdIdent) {
    var sid = btoa(slNoIdent); var mid = btoa(metIdIdent); var comId = btoa(compIdent); var lId = btoa(locIdIdent);
   FormName		= document.meterList;
   FormName.action ='unitPriceList.php?sl_no='+sid+'&companyId='+comId+'&location_id='+lId+'&meter_id='+mid;
   FormName.submit();
}
  
function setCats(recordedDate,comId,bId) {
window.location.href='unitPriceList.php?monthData='+recordedDate+'&companyId='+comId+'&branch_id='+bId;
target = "_blank";
done=1;
}
  
  </script>
  <script type="text/javascript">
  function deleteCats(slNoIdent,serialIdIdent,compIdent,branIdent,gateIdent){
  var sid = btoa(slNoIdent); var scId = btoa(serialIdIdent);var comId = btoa(compIdent); var gId = btoa(gateIdent);var bId = btoa(branIdent);
  if(confirm("Are you sure to Delete this Content?")){
  FormName		= document.meterList;
  FormName.action= 'sensorList.php?gatewayId='+gId+'&companyId='+comId+'&branchId='+bId+'&sl_no='+sid+'&sen_code='+scId;
  FormName.submit();
  }
 }
 
 </script>
<script type="text/javascript">
function ValidateFields()
{
var bar_code = [];
$.each($("input[name='product']:checked"), function(){ 
bar_code.push($(this).val());  
});
id=bar_code.join("','");
document.getElementById("item_id").value = id;

var isActive = document.getElementById("customCheckbox2").checked;

if (isActive == false) 
{
document.getElementById('checkVal').value='0';
}
else
{
document.getElementById('checkVal').value='1';
}

var cval = document.getElementById('checkVal').value;

$(".error").remove();
if (cval == 1) {
meterList.hdAction.value = 1;
return true;
}
else if (cval == 0 && id.length < 1) {
$('.rate').after('<span class="error">Please Enter Unit Rate</span>');
$('#rate').focus();
return false;					
}
else if(id.length >= 1)
{
meterList.hdAction.value = 1;
return true;
}
}
</script>
 <script type="text/javascript">
 function numericFilter(data)
{
   data.value = data.value.replace(/[^.0-9^.+,-]/ig,"");
}
function text_filter(data)
{
   data.value = data.value.replace(/[^ .a-z]/ig,"");

}
function checkBox(code)
{
document.getElementById('product['+code+']').checked=true;
}
function setCheck()
{
//$( ".disrate" ).toggle();
var checkBox = document.getElementById("customCheckbox2");
// var urate = document.getElementById('unitrate').value;
if (checkBox.checked == true)
  {
      document.getElementById('unitrate').readOnly = false;
//	$('.rate').val(urate);
  } 
  else if(checkBox.checked == false)
  {
  window.location.reload();
  }
}
function setCheckVal()
{
 var checkBox = document.getElementById("customCheckbox2");
 var urate = document.getElementById('unitrate').value;
  if (checkBox.checked == true)
  {
	$('.rate').val(urate);
  } 
  else if(checkBox.checked == false)
  {
  window.location.reload();
  }
}
 </script>
  {/literal}
  {include file="footer.tpl"}