	{literal}
	<script type="text/javascript">
	function includecomma1old(c,v)
{
var x=Math.round(c);
x=x.toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != '')
lastThree = ',' + lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
//var res = res.toFixed(4);
//var res =number_format(res, 2);
var res = res+'.00';
document.getElementById(v).innerHTML=res;
}
</script>
<script type="text/javascript">
	function includecomma1(c,v)
{
//var x=Math.round(c);
//var x=c.toFixed(2);

var x=c.split(".");
var ld=x[1];
var ty=typeof(x[1]);//alert(ty);
if(ty == 'undefined')
{
   
    var ld='00';
}
else
{
var ld=x[1].slice(0, 2);
}
x=x[0].toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != '')
{
lastThree = ',' + lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
}
else
{
lastThree =  lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
}
//var res = res+'.00';
var res = res+'.'+ld;
document.getElementById(v).innerHTML=res;
}
</script>
	<script src="amcharts/amcharts.js"></script>
	<script src="amcharts/serial.js"></script>
	<script src="amcharts/themes/light.js"></script>
<!--     Gauge Script      --->
<script src="./amChart/amchart.js"></script>
<script src="./js/gaugeChart/gauge.js"></script>
<script src="./js/gaugeChart/export.min.js"></script>
	
	<script src="amcharts/plugins/export/export.min.js"></script>
	<link rel="stylesheet" href="amcharts/plugins/export/export.css" type="text/css" media="all" />
	<script src="./amChart/amchartLight.js"></script>
<script src="./amChart/amchartColumnChart.js"></script>
	<style type="text/css">
	.thal
	{
	text-align:left;
	}
	.thar
	{
	text-align:right;
	}
	.bclass
	{
	font:Geneva, Arial, Helvetica, sans-serif;
	font-size:14px;
	font-weight:600;
	}
	</style>
	<!-- Styles -->
	<style>
	#chartdiv {
	width: 100%;
	height: 500px;
	}
	#chartdiv2 {
	width: 100%;
	height: 500px;
	}
	#chartdiv3 {
	width: 100%;
	height: 500px;
	}
	#chartdiv4 {
	width: 100%;
	height: 500px;
	}
	#chartdiv5 {
	width: 100%;
	height: 500px;
	}
	#chartdiv6 {
	width: 100%;
	height: 500px;
	}
	#Barchartdiv {
	width: 100%;
	height: 500px;
	}
	#Linechartdiv {
	width	: 100%;
	height	: 800px;
	}	
	#dgBarchartdiv {
	width: 100%;
	height: 500px;
	}
	#dgLinechartdiv {
	width	: 100%;
	height	: 800px;
	}	
	.noscroll,.tab-content
	{
	overflow-x:hidden;
	}
	#barChart2 {
	width	: 100%;
	height	: 450px;
	}#barChart3 {
	width	: 100%;
	height	: 450px;
	}	
	#barChart4 {
	width	: 100%;
	height	: 450px;
	}	
	</style>
	<!----    EB Line Chart         ------------->
	<script>
	var chart = AmCharts.makeChart("Linechartdiv", {
	"type": "serial",
	"theme": "none",
	"marginTop":5,
	"marginBottom":0,
	"marginRight": 50,
	"dataProvider": {/literal}{$LineGraphData}{literal},
	"valueAxes": [{
	"axisAlpha": 0,
	"position": "left",
	"gridAlpha": 0.2,
	"dashLength": 0
	}],
	"graphs": [{
	"id":"g1",
	"balloonText": "[[category]]<br><b><span style='font-size:14px;'>[[kwh]] kwh</span></b>",
	"bullet": "round",
	"bulletSize": 8,
	"lineColor": "#17a2b8", // line color 
	"lineThickness": 2,
	"negativeLineColor": "#637bb6",
	"type": "smoothedLine",
	"valueField": "kwh",
	"animationPlayed": true
	}],
	"chartScrollbar": {
	"enabled" :false, //true if you need drag  option in top
	"graph":"g1",
	"gridAlpha":0,
	"color":"#888888",
	"scrollbarHeight":55,
	"backgroundAlpha":0,
	"selectedBackgroundAlpha":0.1,
	"selectedBackgroundColor":"#888888",
	"graphFillAlpha":0,
	"autoGridCount":true,
	"selectedGraphFillAlpha":0,
	"graphLineAlpha":0.2,
	"graphLineColor":"#c2c2c2",
	"selectedGraphLineColor":"#888888",
	"selectedGraphLineAlpha":1
	
	},
	"chartCursor": {
	"categoryBalloonDateFormat": "YYYY",
	"cursorAlpha": 0,
	"valueLineEnabled":true,
	"valueLineBalloonEnabled":true,
	"valueLineAlpha":0.5,
	"fullWidth":true,
	"zoomable": false //true if line chart need zoom option
	
	},
	"categoryField": "month",
	"export": {
	"enabled": true
	}
	});
	Linechart.addListener("rendered", zoomChart);
	if(Linechart.zoomChart){
	Linechart.zoomChart();
	}
	
	function zoomChart(){
	Linechart.zoomToIndexes(Math.round(Linechart.dataProvider.length * 0.4), Math.round(Linechart.dataProvider.length * 0.55));
	}
	
	</script>
	
	<!----       EB Bar Chart       ---------->
	<script>
	//var plotBarGraphData=JSON.parse(bGraphData);
	var Barchart = AmCharts.makeChart( "Barchartdiv", {
	"type": "serial",
	"theme": "none",
	"dataProvider": {/literal}{$BarGraphData}{literal},
	"valueAxes": [ {
	"gridColor": "#FFFFFF",
	"gridAlpha": 0.2,
	"dashLength": 0
	} ],
	"gridAboveGraphs": true,
	"startDuration": 1,
	"graphs": [ {
	"balloonText": "[[category]]: <b>Rs.[[value]]</b>",
	"fillAlphas": 0.8,
	"lineAlpha": 0.2,
	"type": "column",
	"fillColors": "#17a2b8", // color for bar
	"valueField": "cost"
	} ],
	"chartCursor": {
	"categoryBalloonEnabled": false,
	"cursorAlpha": 0,
	"zoomable": false
	},
	"categoryField": "month",
	"categoryAxis": {
	"gridPosition": "start",
	"gridAlpha": 0,
	"tickPosition": "start",
	"tickLength": 5 // length for x axis bottom line
	},
	"export": {
	"enabled": true
	}
	} );
	</script>
	<!---------      EB Bar Chart End        ---------------->
		<!----    DG Line Chart Start        ------------->
	<script>
	var dgChart = AmCharts.makeChart("dgLinechartdiv", {
	"type": "serial",
	"theme": "none",
	"marginTop":5,
	"marginBottom":0,
	"marginRight": 50,
	"dataProvider": {/literal}{$dgLineGraphData}{literal},
	"valueAxes": [{
	"axisAlpha": 0,
	"position": "left",
	"gridAlpha": 0.2,
	"dashLength": 0
	}],
	"graphs": [{
	"id":"g1",
	"balloonText": "[[category]]<br><b><span style='font-size:14px;'>[[kwh]] kwh</span></b>",
	"bullet": "round",
	"bulletSize": 8,
	"lineColor": "#dc3545", // line color 
	"lineThickness": 2,
	"negativeLineColor": "#637bb6",
	"type": "smoothedLine",
	"valueField": "kwh",
	"animationPlayed": true
	}],
	"chartScrollbar": {
	"enabled" :false, //true if you need drag  option in top
	"graph":"g1",
	"gridAlpha":0,
	"color":"#888888",
	"scrollbarHeight":55,
	"backgroundAlpha":0,
	"selectedBackgroundAlpha":0.1,
	"selectedBackgroundColor":"#888888",
	"graphFillAlpha":0,
	"autoGridCount":true,
	"selectedGraphFillAlpha":0,
	"graphLineAlpha":0.2,
	"graphLineColor":"#c2c2c2",
	"selectedGraphLineColor":"#888888",
	"selectedGraphLineAlpha":1
	
	},
	"chartCursor": {
	"categoryBalloonDateFormat": "YYYY",
	"cursorAlpha": 0,
	"valueLineEnabled":true,
	"valueLineBalloonEnabled":true,
	"valueLineAlpha":0.5,
	"fullWidth":true,
	"zoomable": false //true if line chart need zoom option
	
	},
	"categoryField": "month",
	"export": {
	"enabled": true
	}
	});
	Linechart.addListener("rendered", zoomChart);
	if(Linechart.zoomChart){
	Linechart.zoomChart();
	}
	
	function zoomChart(){
	Linechart.zoomToIndexes(Math.round(Linechart.dataProvider.length * 0.4), Math.round(Linechart.dataProvider.length * 0.55));
	}
	
	</script>
	
	<!----       DG Bar Chart Start      ---------->
	<script>
	//var plotBarGraphData=JSON.parse(bGraphData);
	var dgBarchart = AmCharts.makeChart( "dgBarchartdiv", {
	"type": "serial",
	"theme": "none",
	"dataProvider": {/literal}{$dgBarGraphData}{literal},
	"valueAxes": [ {
	"gridColor": "#FFFFFF",
	"gridAlpha": 0.2,
	"dashLength": 0
	} ],
	"gridAboveGraphs": true,
	"startDuration": 1,
	"graphs": [ {
	"balloonText": "[[category]]: <b>Rs.[[value]]</b>",
	"fillAlphas": 0.8,
	"lineAlpha": 0.2,
	"type": "column",
	"fillColors": "#dc3545", // color for bar
	"valueField": "cost"
	} ],
	"chartCursor": {
	"categoryBalloonEnabled": false,
	"cursorAlpha": 0,
	"zoomable": false
	},
	"categoryField": "month",
	"categoryAxis": {
	"gridPosition": "start",
	"gridAlpha": 0,
	"tickPosition": "start",
	"tickLength": 5 // length for x axis bottom line
	},
	"export": {
	"enabled": true
	}
	} );
	</script>
<!------       DG Bar Chart  Ends                    -------->
	<script>
	var chart = AmCharts.makeChart("chartdiv", {
	"theme": "none",
	"type": "gauge",
	"axes": [{
	"topTextFontSize": 20,
	"topTextYOffset": 70,
	"axisColor": "#31d6ea",
	"axisThickness": 1,
	"endValue": {/literal}{$KW_MAX}{literal},
	"gridInside": true,
	"inside": true,
	"radius": "60%",
	"valueInterval": {/literal}{$KW_INT}{literal},
	"tickColor": "#67b7dc",
	"startAngle": -90,
	"endAngle": 90,
	"unit": "",
	"labelsEnabled":true,
	"bandOutlineAlpha": 0,
	"bands": [{
	"color": "#0080ff",
	"endValue": {/literal}{$KW_MAX}{literal},
	"innerRadius": "105%",
	"radius": "170%",
	"gradientRatio": [0.5, 0, -0.5],
	"startValue": 0
	}, {
	"color": "#3cd3a3",
	"endValue": 0,
	"innerRadius": "105%",
	"radius": "170%",
	"gradientRatio": [0.5, 0, -0.5],
	"startValue": 0
	}]
	}],
	"arrows": [{
	"alpha": 1,
	"innerRadius": "35%",
	"nailRadius": 0,
	"radius": "170%"
	}]
	});
	setInterval(randomValue, 500);
	// set random value
	function randomValue() {
	var value = {/literal}{$ListFeederDet.0.SUM_KW}{literal};
	chart.arrows[0].setValue(value);
	chart.axes[0].setTopText(value + " KW");
	// adjust darker band to new value
	chart.axes[0].bands[1].setEndValue(value);
	}
	</script>
	<script>
	var chart2 = AmCharts.makeChart("chartdiv2", {
	"theme": "none",
	"type": "gauge",
	"axes": [{
	"topTextFontSize": 20,
	"topTextYOffset": 70,
	"axisColor": "#31d6ea",
	"axisThickness": 1,
	"endValue": {/literal}{$KVA_MAX}{literal},
	"gridInside": true,
	"inside": true,
	"radius": "60%",
	"valueInterval": {/literal}{$KVA_INT}{literal},
	"tickColor": "#67b7dc",
	"startAngle": -90,
	"endAngle": 90,
	"unit": "",
	"labelsEnabled":true,
	"bandOutlineAlpha": 0,
	"bands": [{
	"color": "#0080ff",
	"endValue": {/literal}{$KVA_MAX}{literal},
	"innerRadius": "105%",
	"radius": "170%",
	"gradientRatio": [0.5, 0, -0.5],
	"startValue": 0
	}, {
	"color": "#3cd3a3",
	"endValue": 0,
	"innerRadius": "105%",
	"radius": "170%",
	"gradientRatio": [0.5, 0, -0.5],
	"startValue": 0
	}]
	}],
	"arrows": [{
	"alpha": 1,
	"innerRadius": "35%",
	"nailRadius": 0,
	"radius": "170%"
	}]
	});
	setInterval(randomValue2, 500);
	// set random value
	function randomValue2() {
	var value = {/literal}{$ListFeederDet.0.SUM_KVA}{literal};
	chart2.arrows[0].setValue(value);
	chart2.axes[0].setTopText(value + " KVA");
	// adjust darker band to new value
	chart2.axes[0].bands[1].setEndValue(value);
	}
	</script>
	<script>
	var chart3 = AmCharts.makeChart("chartdiv3", {
	"theme": "none",
	"type": "gauge",
	"axes": [{
	"topTextFontSize": 20,
	"topTextYOffset": 70,
	"axisColor": "#31d6ea",
	"axisThickness": 1,
	"endValue": {/literal}{$KVAR_MAX}{literal},
	"gridInside": true,
	"inside": true,
	"radius": "60%",
	"valueInterval": {/literal}{$KVAR_INT}{literal},
	"tickColor": "#67b7dc",
	"startAngle": -90,
	"endAngle": 90,
	"unit": "",
	
	"labelsEnabled":true,
	"bandOutlineAlpha": 0,
	"bands": [{
	"color": "#0080ff",
	"endValue": {/literal}{$KVAR_MAX}{literal},
	"innerRadius": "105%",
	"radius": "170%",
	"gradientRatio": [0.5, 0, -0.5],
	"startValue": 0
	}, {
	"color": "#3cd3a3",
	"endValue": 0,
	"innerRadius": "105%",
	"radius": "170%",
	"gradientRatio": [0.5, 0, -0.5],
	"startValue": 0
	}]
	}],
	"arrows": [{
	"alpha": 1,
	"innerRadius": "35%",
	"nailRadius": 0,
	"radius": "170%"
	}]
	});
	setInterval(randomValue3, 500);
	// set random value
	function randomValue3() {
	var value = {/literal}{$ListFeederDet.0.SUM_KVAR}{literal};
	chart3.arrows[0].setValue(value);
	chart3.axes[0].setTopText(value + " KVAR");
	// adjust darker band to new value
	chart3.axes[0].bands[1].setEndValue(value);
	}
	</script>
	
	<!------------------         DG Gauge Script Starts        --------------------->
		<script>
	//	alert({/literal}{$KW_MAX}+"-"+{$KW_INT}+"-"+{$ListFeederDet.0.DG_KWH}{literal});
	var chart4 = AmCharts.makeChart("chartdiv4", {
	"theme": "none",
	"type": "gauge",
	"axes": [{
	"topTextFontSize": 20,
	"topTextYOffset": 70,
	"axisColor": "#31d6ea",
	"axisThickness": 1,
	"endValue": {/literal}{$KWH_MAX}{literal},
	"gridInside": true,
	"inside": true,
	"radius": "60%",
	"valueInterval": {/literal}{$KWH_INT}{literal},
	"tickColor": "#67b7dc",
	"startAngle": -90,
	"endAngle": 90,
	"unit": "",
	"labelsEnabled":true,
	"bandOutlineAlpha": 0,
	"bands": [{
	"color": "#ff0019",
	"endValue": {/literal}{$KWH_MAX}{literal},
	"innerRadius": "105%",
	"radius": "170%",
	"gradientRatio": [0.5, 0, -0.5],
	"startValue": 0
	}, {
	"color": "#3cd3a3",
	"endValue": 0,
	"innerRadius": "105%",
	"radius": "170%",
	"gradientRatio": [0.5, 0, -0.5],
	"startValue": 0
	}]
	}],
	"arrows": [{
	"alpha": 1,
	"innerRadius": "35%",
	"nailRadius": 0,
	"radius": "170%"
	}]
	});
	setInterval(randomValue4, 500);
	// set random value
	function randomValue4() {
	var value = {/literal}{$ListFeederDet.0.DG_KWH}{literal};
	chart4.arrows[0].setValue(value);
	chart4.axes[0].setTopText(value + " KWH");
	// adjust darker band to new value
	chart4.axes[0].bands[1].setEndValue(value);
	}
	</script>
	<script>
	var chart5 = AmCharts.makeChart("chartdiv5", {
	"theme": "none",
	"type": "gauge",
	"axes": [{
	"topTextFontSize": 20,
	"topTextYOffset": 70,
	"axisColor": "#31d6ea",
	"axisThickness": 1,
	"endValue": {/literal}{$KVAH_MAX}{literal},
	"gridInside": true,
	"inside": true,
	"radius": "60%",
	"valueInterval": {/literal}{$KVAH_INT}{literal},
	"tickColor": "#67b7dc",
	"startAngle": -90,
	"endAngle": 90,
	"unit": "",
	"labelsEnabled":true,
	"bandOutlineAlpha": 0,
	"bands": [{
	"color": "#ff0019",
	"endValue": {/literal}{$KVAH_MAX}{literal},
	"innerRadius": "105%",
	"radius": "170%",
	"gradientRatio": [0.5, 0, -0.5],
	"startValue": 0
	}, {
	"color": "#3cd3a3",
	"endValue": 0,
	"innerRadius": "105%",
	"radius": "170%",
	"gradientRatio": [0.5, 0, -0.5],
	"startValue": 0
	}]
	}],
	"arrows": [{
	"alpha": 1,
	"innerRadius": "35%",
	"nailRadius": 0,
	"radius": "170%"
	}]
	});
	setInterval(randomValue5, 500);
	// set random value
	function randomValue5() {
	var value = {/literal}{$ListFeederDet.0.DG_KVAH}{literal};
	chart5.arrows[0].setValue(value);
	chart5.axes[0].setTopText(value + " KVAH");
	// adjust darker band to new value
	chart5.axes[0].bands[1].setEndValue(value);
	}
	</script>
	<script>
	var chart6 = AmCharts.makeChart("chartdiv6", {
	"theme": "none",
	"type": "gauge",
	"axes": [{
	"topTextFontSize": 20,
	"topTextYOffset": 70,
	"axisColor": "#31d6ea",
	"axisThickness": 1,
	"endValue": {/literal}{$KVARH_MAX}{literal},
	"gridInside": true,
	"inside": true,
	"radius": "60%",
	"valueInterval": {/literal}{$KVARH_INT}{literal},
	"tickColor": "#67b7dc",
	"startAngle": -90,
	"endAngle": 90,
	"unit": "",
	
	"labelsEnabled":true,
	"bandOutlineAlpha": 0,
	"bands": [{
	"color": "#ff0019",
	"endValue": {/literal}{$KVARH_MAX}{literal},
	"innerRadius": "105%",
	"radius": "170%",
	"gradientRatio": [0.5, 0, -0.5],
	"startValue": 0
	}, {
	"color": "#3cd3a3",
	"endValue": 0,
	"innerRadius": "105%",
	"radius": "170%",
	"gradientRatio": [0.5, 0, -0.5],
	"startValue": 0
	}]
	}],
	"arrows": [{
	"alpha": 1,
	"innerRadius": "35%",
	"nailRadius": 0,
	"radius": "170%"
	}]
	});
	setInterval(randomValue6, 500);
	// set random value
	function randomValue6() {
	var value = {/literal}{$ListFeederDet.0.DG_KVARH}{literal};
	chart6.arrows[0].setValue(value);
	chart6.axes[0].setTopText(value + " KVARH");
	// adjust darker band to new value
	chart6.axes[0].bands[1].setEndValue(value);
	}
	</script>
	{/literal}
	<div class="content-wrapper ">
	<div class="content-header">
	<div class="container-fluid ">
	<div class="row"> <div class="col-md-12">
	<div class="card">
	<div class="card-body">
		<table style="margin-bottom:-10px;">
		<tr><td style="font-size:15PX;font-weight: bold;">{$LoctList.0.companyName}&nbsp;&nbsp;</td>
		<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="font-size:15PX;font-weight: bold;">{$LoctList.0.branch_name}&ensp;&ensp;</td>
		<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="font-size:15PX;font-weight: bold;">{$LoctList.0.sensorName}</font>&nbsp;</td>
		<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="font-size:15PX;font-weight: bold;">{$LoctList.0.place_of_installation} - {if $LoctList.0.gateway_id eq $gateList.0.gateway_code && $gateList.0.gateway_date_time gte $dateSec|date_format:'%Y-%m-%d %H:%M:%S' } <a style="color: #00CC00;">ON</a> {else} <a style="color: #FF0000;">OFF</a> {/if}</font>&nbsp;</td>
		
			</tr>
		
		
		<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
		<td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="font-size:10PX;color:#999999;">Branch Name</td>
		<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="color:#999999;font-size:10PX;">Energy Meter Name (Place of Installation)</td>
		<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="color:#999999;font-size:10PX;">Gateway Name - Status</td>
			</tr>
		</table>
		 <textarea id="currMonQut" name="currMonQut" style="display:none;" >{$BarGraphData}</textarea>
            <textarea id="currMonQut2" name="currMonQut2" style="display:none;">{$LineGraphData}</textarea>
       <textarea id="mutiLinegraph" name="mutiLinegraph" style="display:none;">{$LineGraphData2}</textarea>
<textarea id="mutiLinedataProvider" name="mutiLinedataProvider" style="display:none;" >{$LineGraphData}</textarea>
		<input type="hidden" id="gatewayCode" value="{$smarty.get.gatewayCode}" />
		<input type="hidden" id="sensorCode" value="{$smarty.get.sensorCode}" />
		<form name="dashboard" id="dashboard" method="post">
		<div  style="margin-top:-40PX;float:right" class="col-md-4"  >
	<b>Select Feeder &nbsp;: &nbsp;</b><select  id="feederPost" name="feederPost"  style="width:200PX" onchange="postFeeder();">
	{foreach from=$ListFeeder item=listDet}
	{if $LoctList.0.sensorName eq $listDet.sensorName}
	<option value="{$listDet.sensorName}|{$listDet.sensorCode|base64_encode}|{$listDet.gateway_id|base64_encode}|{$listDet.company_id|base64_encode}|{$listDet.branch_id|base64_encode}"  selected="selected">{$LoctList.0.sensorName}</option> {/if}
	{if $LoctList.0.sensorName neq $listDet.sensorName}
	<option value="{$listDet.sensorName}|{$listDet.sensorCode|base64_encode}|{$listDet.gateway_id|base64_encode}|{$listDet.company_id|base64_encode}|{$listDet.branch_id|base64_encode}">{$listDet.sensorName}</option>
	{/if}
	{/foreach}
	</select>
	</div>
	</form>
	</div>
	</div>
	</div>
	</div>
	<div class="row ">&ensp;
	<!--------  EB Data Starts      ------>
	<div class="row col-md-6">
	<div class="card card-widget card-outline card-primary widget-user-2 col-md-12 ">
								
									<div class="card-header">
									<h5 class="" style="text-align:left"><b>EB Data</b></h5>
									
								</div>
							<br />	
		<div class="row  ">
			<div class="col-12 col-sm-6 col-md-4">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-info elevation-1"><i class="fa fa-bolt"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">Today KWH&ensp;&ensp;&ensp;&ensp;</span>
			<span class="info-box-number" id="tckw">
			<script type="text/javascript">includecomma1('{$todayCostKWH.0.TOTAL_KWH}','tckw');</script>
			</span>
			</div>
			</div>
		</div>
			<div class="col-12 col-sm-6 col-md-4">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-info elevation-1"><i class="fa fa-bolt"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">This Month KWH</span>
			<span class="info-box-number" id="mck">
			<script type="text/javascript">includecomma1('{$monthCostKWH.0.TOTAL_KWH}','mck');</script>
			</span>
			</div>
			</div>
			</div>
		
		<div class="col-12 col-sm-6 col-md-4">
		<div class="info-box mb-2">
		<span class="info-box-icon bg-info elevation-1"><i class="fa fa-bolt"></i></span>
		<div class="info-box-content">
		<span class="info-box-text">Last Month KWH</span>
		<span class="info-box-number" id="lmk">
		<script type="text/javascript">includecomma1('{$LastMonthCostKWH.0.TOTAL_KWH}','lmk');</script>
		</span>
		</div>
		</div>
		</div>
		<div class="col-12 col-sm-6 col-md-4">
			<div class="info-box">
			<span class="info-box-icon bg-info elevation-1"><i class="fa fa-rupee"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">Today Cost&ensp;&ensp;&ensp;&ensp;</span>
			<span class="info-box-number" id="tc">
			<script type="text/javascript">includecomma1('{$todayCostKWH.0.cost}','tc');</script>
			<small></small>
			</span>
			</div>
			</div>
		</div>
		
	<!-- fix for small devices only -->
	
			<div class="col-12 col-sm-6 col-md-4">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-info elevation-1"><i class="fa fa-rupee"></i></span>
			<div class="info-box-content">
			<span class="info-box-text"> This Month Cost</span>
			<span class="info-box-number" id="mc">
			<script type="text/javascript">includecomma1('{$monthCostKWH.0.cost}','mc');</script>
			</span>
			</div>
			</div>
			</div>
			<div class="col-12 col-sm-6 col-md-4">
		<div class="info-box mb-2">
		<span class="info-box-icon bg-info elevation-1"><i class="fa fa-rupee"></i></span>
		<div class="info-box-content">
		<span class="info-box-text">Last Month Cost</span>
		<span class="info-box-number" id="lckw">
		<script type="text/javascript">includecomma1('{$LastMonthCostKWH.0.cost}','lckw');</script>
		</span>
		</div>
		</div>
		</div>
		
		


		</div></div>
	</div>
	<!--------  EB Data Ends      ------>
	<div>&ensp;</div>
	<!--------  DG Data Starts      ------>&ensp;
	<div class="row col-md-6">
	<div class="card card-widget card-outline card-danger widget-user-2 col-md-12 ">
								
									<div class="card-header">
									<h5 class="" style="text-align:left"><b>DG Data  </b></h5>
									
								</div>
							<br />	
		<div class="row  ">
				

	<div class="col-12 col-sm-6 col-md-4">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-danger elevation-1"><i class="fa fa-bolt"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">Today KWH&ensp;&ensp;&ensp;&ensp;</span>
			<span class="info-box-number" id="tk">
			<script type="text/javascript">includecomma1('{$todayCostKWH.0.dg_TOTAL_KWH}','tk');</script>
			</span>
			</div>
			</div>
		</div>
			<div class="col-12 col-sm-6 col-md-4">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-danger elevation-1"><i class="fa fa-bolt"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">This Month KWH</span>
			<span class="info-box-number" id="ck">
			<script type="text/javascript">includecomma1('{$monthCostKWH.0.dg_TOTAL_KWH}','ck');</script>
			</span>
			</div>
			</div>
			</div>
		
		<div class="col-12 col-sm-6 col-md-4">
		<div class="info-box mb-2">
		<span class="info-box-icon bg-danger elevation-1"><i class="fa fa-bolt"></i></span>
		<div class="info-box-content">
		<span class="info-box-text">Last Month KWH</span>
		<span class="info-box-number" id="lk">
		<script type="text/javascript">includecomma1('{$LastMonthCostKWH.0.dg_TOTAL_KWH}','lk');</script>
		</span>
		</div>
		</div>
		</div>
		<div class="col-12 col-sm-6 col-md-4">
			<div class="info-box">
			<span class="info-box-icon bg-danger elevation-1"><i class="fa fa-rupee"></i></span>
			<div class="info-box-content">
			<span class="info-box-text">Today Cost&ensp;&ensp;&ensp;&ensp;</span>
			<span class="info-box-number" id="tkc">
			<script type="text/javascript">includecomma1('{$todayCostKWH.0.dg_cost}','tkc');</script>
			<small></small>
			</span>
			</div>
			</div>
		</div>
		
	<!-- fix for small devices only -->
	
			<div class="col-12 col-sm-6 col-md-4">
			<div class="info-box mb-2">
			<span class="info-box-icon bg-danger elevation-1"><i class="fa fa-rupee"></i></span>
			<div class="info-box-content">
			<span class="info-box-text"> This Month Cost</span>
			<span class="info-box-number" id="cck">
			<script type="text/javascript">includecomma1('{$monthCostKWH.0.dg_cost}','cck');</script>
			</span>
			</div>
			</div>
			</div>
			<div class="col-12 col-sm-6 col-md-4">
		<div class="info-box mb-2">
		<span class="info-box-icon bg-danger elevation-1"><i class="fa fa-rupee"></i></span>
		<div class="info-box-content">
		<span class="info-box-text">Last Month Cost</span>
		<span class="info-box-number" id="lck">
		<script type="text/javascript">includecomma1('{$LastMonthCostKWH.0.dg_cost}','lck');</script>
		</span>
		</div>
		</div>
		</div>
		

		</div></div>
	</div>
	<!--------  DG Data Ends      ------>
	</div>
	{if $ListFeederDet2 eq "0"}
	<div class="row" >
		<div class="col-md-12">
			<div class="card">
				<div class="card-body">
				<h1 align="center" style="color:#FF0000"> No Records Found  </h1>
				</div>
			</div>
		</div>
	</div>
	{else}
	<div class="row  ">
		<div class="col-md-12">
			<div class="card">   
				<div class="card-body">
					<div class="row">
						<div class="col-md-4 " >
							<div class="card card-widget widget-user-2">
								<div class="card card-outline card-primary">
									<div class="card-header">
									<h5 class="" style="text-align:left"><b>KW</b></h5>
									</div>
								</div>
								<div class="card-footer" style="height:200PX">
									<ul class="nav flex-column" >
									<li class="nav-item" style="backgroud-color:white">
									<div id="chartdiv" style="margin-top:-115PX"></div>
									</li>
									</ul>
								</div>
							</div>
						</div><div class="col-md-4" >
					<div class="card card-widget widget-user-2">
						<div class="card card-outline card-primary">
							<div class="card-header">
							<h5 class="" style="text-align:left"><b>KVA</b></h5>
							</div>
						</div>
						<div class="card-footer" style="height:200PX">
							<ul class="nav flex-column" >
							<li class="nav-item" style="backgroud-color:white">
							<div id="chartdiv2" style="margin-top:-115PX"></div>
							</li>
							</ul>
						</div>
					</div>
					</div>
						<div class="col-md-4" >
							<div class="card card-widget widget-user-2">
								<div class="card card-outline card-primary">
									<div class="card-header">
									<h5 class="" style="text-align:left"><b>KVAR</b></h5>
									</div>
								</div>
								<div class="card-footer" style="height:200PX">
									<ul class="nav flex-column" >
									<li class="nav-item" style="backgroud-color:white">
									<div id="chartdiv3" style="margin-top:-115PX"></div>
									</li>
									</ul>
								</div>
							</div>
						</div>
        				</div>
					<div class="row">
						<div class="col-md-4">
							<div class="card card-widget widget-user-2">
								<div class="card-footer p-0">
									<ul class="nav flex-column">
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b>VR</b> <span class="float-right badge bg-danger">{$ListFeederDet.0.R_VOLTAGE}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> VY </b><span class="float-right badge bg-warning">{$ListFeederDet.0.Y_VOLTAGE}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> VB</b> <span class="float-right badge bg-primary">{$ListFeederDet.0.B_VOLTAGE}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> Status - {$ListFeederDet.0.recorded_date_time|date_format:"%d-%b-%Y %I:%M %p"} </b><span class="float-right badge bg-success">Last Logged</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b>Feeder Name </b><span class="float-right badge bg-success">{$ListFeederDet.0.sensorName}</span>
										</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="card card-widget widget-user-2">
								<div class="card-footer p-0">
									<ul class="nav flex-column">
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> VRY </b><span class="float-right badge bg-danger">{$ListFeederDet.0.RY_VOLTAGE}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b>VYB</b> <span class="float-right badge bg-warning">{$ListFeederDet.0.YB_VOLTAGE}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> VBR</b> <span class="float-right badge bg-primary">{$ListFeederDet.0.BR_VOLTAGE}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> PF</b> <span class="float-right badge bg-success">{$ListFeederDet.0.SUM_PF}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> Frequency </b> <span class="float-right badge bg-success">{$ListFeederDet.0.FREQUENCY}</span>
										</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="card card-widget widget-user-2">					
								<div class="card-footer p-0">
									<ul class="nav flex-column">
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b>IR</b> <span class="float-right badge bg-danger">{$ListFeederDet.0.R_CURRENT}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b>IY</b> <span class="float-right badge bg-warning">{$ListFeederDet.0.Y_CURRENT}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> IB</b> <span class="float-right badge bg-primary">{$ListFeederDet.0.B_CURRENT}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black" >
										<b>KWH</b> <span class="float-right badge bg-success">{$ListFeederDet.0.KWH}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black" >
										<b> Run Hr</b> <span class="float-right badge bg-success">{$ListFeederDet.0.RUN_HOUR}</span>
										</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<!-----------------        DG Data Starts                               --------------->
					<!--<div class="row">
						<div class="col-md-4" >
							<div class="card card-widget widget-user-2">
								<div class="card card-outline card-danger">
									<div class="card-header">
									<h5 class="" style="text-align:left"><b>DG KWH </b></h5>
									</div>
								</div>
								<div class="card-footer" style="height:200PX">
									<ul class="nav flex-column" >
									<li class="nav-item" style="backgroud-color:white">
									<div id="chartdiv4" style="margin-top:-115PX"></div>
									</li>
									</ul>
									
								</div>
							</div>
						</div><div class="col-md-4" >
					<div class="card card-widget widget-user-2">
						<div class="card card-outline card-danger">
							<div class="card-header">
							<h5 class="" style="text-align:left"><b>DG KVAH</b></h5>
							</div>
						</div>
						<div class="card-footer" style="height:200PX">
							<ul class="nav flex-column" >
							<li class="nav-item" style="backgroud-color:white">
							<div id="chartdiv5" style="margin-top:-115PX"></div>
							</li>
							</ul>
						</div>
					</div>
					</div>
						<div class="col-md-4" >
							<div class="card card-widget widget-user-2">
								<div class="card card-outline card-danger">
									<div class="card-header">
									<h5 class="" style="text-align:left"><b>DG KVARH </b></h5>
									</div>
								</div>
								<div class="card-footer" style="height:200PX">
									<ul class="nav flex-column" >
									<li class="nav-item" style="backgroud-color:white">
								<div id="chartdiv6" style="margin-top:-115PX"></div>
									</li>
									</ul>
								</div>
							</div>
						</div>
        				</div>-->
					<!--<div class="row">
						<div class="col-md-4">
							<div class="card card-widget widget-user-2">
								<div class="card-footer p-0">
									<ul class="nav flex-column">
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b>VR</b> <span class="float-right badge bg-danger">{$ListFeederDet.0.R_VOLTAGE}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> VY </b><span class="float-right badge bg-warning">{$ListFeederDet.0.Y_VOLTAGE}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> VB</b> <span class="float-right badge bg-primary">{$ListFeederDet.0.B_VOLTAGE}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> Status - {$ListFeederDet.0.recorded_date_time|date_format:"%d-%b-%Y %I:%M %p"} </b><span class="float-right badge bg-success">Last Logged</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b>Feeder Name </b><span class="float-right badge bg-success">{$ListFeederDet.0.sensorName}</span>
										</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="card card-widget widget-user-2">
								<div class="card-footer p-0">
									<ul class="nav flex-column">
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> VRY </b><span class="float-right badge bg-danger">{$ListFeederDet.0.RY_VOLTAGE}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b>VYB</b> <span class="float-right badge bg-warning">{$ListFeederDet.0.YB_VOLTAGE}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> VBR</b> <span class="float-right badge bg-primary">{$ListFeederDet.0.BR_VOLTAGE}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> PF</b> <span class="float-right badge bg-success">{$ListFeederDet.0.SUM_PF}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> Frequency </b> <span class="float-right badge bg-success">{$ListFeederDet.0.FREQUENCY}</span>
										</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="card card-widget widget-user-2">					
								<div class="card-footer p-0">
									<ul class="nav flex-column">
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b>IR</b> <span class="float-right badge bg-danger">{$ListFeederDet.0.R_CURRENT}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b>IY</b> <span class="float-right badge bg-warning">{$ListFeederDet.0.Y_CURRENT}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black">
										<b> IB</b> <span class="float-right badge bg-primary">{$ListFeederDet.0.B_CURRENT}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black" >
										<b>KWH</b> <span class="float-right badge bg-success">{$ListFeederDet.0.KWH}</span>
										</a>
										</li>
										<li class="nav-item">
										<a href="#" class="nav-link" style="text-decoration:none;color:black" >
										<b> Run Hr</b> <span class="float-right badge bg-success">{$ListFeederDet.0.RUN_HOUR}</span>
										</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>-->
					<!-----------------        DG Data Ends                                 --------------->
			<!--	<div class="row">
					<div class="col-md-6">
						<div class="card card-primary card-outline">
							<div class="card-header">
							<h3 class="card-title">
							<i class="far fa-chart-bar"></i>
							EB - DG Cost Chart
							</h3>
							</div>
						
						<div class="chart">
        <canvas id="barChart2" style="height: 300px;" ></canvas>
        </div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="card card-primary card-outline">
							<div class="card-header">
							<h3 class="card-title">
							<i class="far fa-chart-bar"></i>
							EB - DG Kwh Chart
							</h3>
							</div>
							<div class="chart">
							
							 <div id="barChart4" style="height: 300px;"></div>
							</div>
						</div>
					</div>
				</div>-->
				<!--------        DG Charts Start  -------------->
				<!--<div class="row">
					<div class="col-md-6">
						<div class="card card-danger card-outline">
							<div class="card-header">
							<h3 class="card-title">
							<i class="far fa-chart-bar"></i>
							DG Cost Chart
							</h3>
							</div>
						<div id="dgBarchartdiv" style="height: 300px;"></div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="card card-danger card-outline">
							<div class="card-header">
							<h3 class="card-title">
							<i class="far fa-chart-bar"></i>
							DG Kwh Chart
							</h3>
							</div>
							<div class="card-body">
							<div id="dgLinechartdiv" style="height: 260px;"></div>
							</div>
						</div>
					</div>
				</div>-->
				<div class="row">
					<div class="col-md-12">
						<div class="card card-primary card-tabs">
							<div class="card-header p-0 pt-1 border-bottom-0">
								<ul class="nav nav-tabs" id="custom-content-below-tab" role="tablist">
								<li class="nav-item">
									<a class="nav-link active" id="custom-content-below-messages-tab" data-toggle="pill" href="#tab-4" role="tab" aria-controls="custom-content-below-messages" aria-selected="false" >Daily Report</a>
									</li>
									<li class="nav-item">
									<a class="nav-link" id="custom-content-below-messages-tab" data-toggle="pill" href="#tab-3" role="tab" aria-controls="custom-content-below-messages" aria-selected="false" >Log Report</a>
									</li>
									<li class="nav-item">
									<a class="nav-link " id="custom-content-below-profile-tab" data-toggle="pill" href="#tab-1" role="tab" aria-controls="custom-content-below-profile" aria-selected="true" >Historical Trend</a>
									</li>
									
									
									<li class="nav-item">
									<a class="nav-link" id="custom-content-below-messages-tab" data-toggle="pill" href="#tab-5" role="tab" aria-controls="custom-content-below-messages" aria-selected="false">DG Log Report</a>
									</li>
									<li class="nav-item">
									<a class="nav-link" id="custom-content-below-messages-tab" data-toggle="pill" href="#tab-6" role="tab" aria-controls="custom-content-below-messages" aria-selected="false" >DG Daily Report</a>
									</li>
								</ul>
							</div>
							 <div class="tab-content" >
							 	<div id="tab-4" class="tab-pane active" >
									<!--<div class="loader"></div>-->
										<div class="card-body">
										<iframe  id="daily_report" height="820px" width="98%" src="" style="border:1px;"></iframe></div>
									</div>
									<div id="tab-3" class="tab-pane">
									<div class="loader" style="background-color:#999999"></div>
										<div class="card-body">
										<iframe id="log_report" height="820px" width="98%" src="" style="border:1px;"></iframe>
										</div>
									</div>
									<div id="tab-1" class="tab-pane ">
									<div class="loader"></div>
											<div class="card-body">
											<iframe id="trendGraph" height="820px" width="100%" src="" style="border:1px;"></iframe></div>
									</div>
									
								
									<div id="tab-5" class="tab-pane" >
									<div class="loader"></div>
										<div class="card-body">
										<iframe id="dg_log_report" height="820px" width="98%" src="" style="border:1px;"></iframe></div>
									</div>
									<div id="tab-6" class="tab-pane" >
									<div class="loader"></div>
										<div class="card-body">
										<iframe id="dg_daily_report" height="820px" width="98%" src="" style="border:1px;"></iframe></div>
									</div>
							</div>
						</div>
					</div>
				</div>
				</div>
			</div>
		</div>
	</div>{/if}
	</div>
	</div>
	</div>
	{literal}
	    <script type="text/javascript">
var result = document.getElementById('currMonQut').value;
//var result = {/literal}{$BarGraphData}{literal};
//alert("here1");
var jsonData=result;
var obj = JSON.parse(jsonData);
//var obj = jsonData;//alert(obj);
var mon = "";
var dataVal = "";
var dataVal1 = "";
var colo = "";
var i;
for (i = 0; i < obj.length; i++) {
if(i==0){
  mon += obj[i].month ;
  dataVal += obj[i].cost;
  dataVal1 += obj[i].dgcost;
   //colo += obj[i].color;
   }
  else
  {
  mon += ", "+ obj[i].month;
  dataVal += ", "+ obj[i].cost;
   dataVal1 += ", "+ obj[i].dgcost;
 //  colo += ', '+ obj[i].color;
 }
}
// loop  variable concatinate each  record  as an array
var monthVal = mon;//alert(monthVal);
var dataValue =dataVal;//alert(dataValue);
var dataValue1 =dataVal1;//alert(dataValue1);
//var colors =colo;


// above mentioned  array variable  split by comma to plot the variable in lable and data in chart
var month =  monthVal.split(',');
var dataV=  dataValue.split(',');
var dataV1=  dataValue1.split(',');
//var barChartCanvas = $('#barChart2').get(0).getContext('2d');
var barChartCanvas = document.getElementById("barChart2").getContext("2d");
  var barChartData = {
    labels  :  month,
    datasets: [
      {
          label               : 'EB Cost',
          backgroundColor     : '#67b7dc',
          borderColor         :  '#67b7dc',
          pointRadius          : false,
          pointColor          :  '#67b7dc',
          pointStrokeColor    :  '#67b7dc',
          pointHighlightFill  :  '#67b7dc',
          pointHighlightStroke:  '#67b7dc',
		  fillColor: "#67b7dc",
          data                : dataV
      },
      {
        label                 : 'DG Cost',
          backgroundColor     : '#dc3545',
          borderColor         :  '#dc3545',
          pointRadius         : false,
          pointColor          :  '#dc3545',
          pointStrokeColor    :  '#dc3545',
          pointHighlightFill  :  '#dc3545',
          pointHighlightStroke:  '#dc3545',
		  fillColor: "#dc3545",
          data                : dataV1
      }
    ]
  };
  
    var barChartOptions = {
	tooltips: {
        callbacks: {
            label: function(tooltipItem) {
			var dis = tooltipItem.yLabel;
             var vad = dis;
                return  vad;
            }
        }
    },
      responsive              : true,
      maintainAspectRatio     : true,
      datasetFill             : true,
	    scales: {
		yAxes: [{
              ticks:{
                  stepSize :1000,

              }
			  }]
		}
	      };


    var barChart = new Chart(barChartCanvas, {
      type: 'bar', 
      data: barChartData,
      options: barChartOptions,
    });
	
	barChart.Bar(barChartData, barChartOptions);
	
</script>
<script type="text/javascript">
var result = document.getElementById('currMonQut2').value;
//var result = {/literal}{$BarGraphData}{literal};
//alert("here1");
var jsonData=result;
var obj = JSON.parse(jsonData);
//var obj = jsonData;//alert(obj);
var mon = "";
var dataVal = "";
var dataVal1 = "";
var colo = "";
var i;
for (i = 0; i < obj.length; i++) {
if(i==0){
  mon += obj[i].month ;
  dataVal += obj[i].kwh;
  dataVal1 += obj[i].dgkwh;
   //colo += obj[i].color;
   }
  else
  {
  mon += ", "+ obj[i].month;
  dataVal += ", "+ obj[i].kwh;
   dataVal1 += ", "+ obj[i].dgkwh;
 //  colo += ', '+ obj[i].color;
 }
}
// loop  variable concatinate each  record  as an array
var monthVal = mon;//alert(monthVal);
var dataValue =dataVal;//alert(dataValue);
var dataValue1 =dataVal1;//alert(dataValue1);
//var colors =colo;


// above mentioned  array variable  split by comma to plot the variable in lable and data in chart
var month =  monthVal.split(',');
var dataV=  dataValue.split(',');
var dataV1=  dataValue1.split(',');
//var barChartCanvas = $('#barChart2').get(0).getContext('2d');
var barChartCanvas = document.getElementById("barChart3").getContext("2d");
  var barChartData = {
    labels  :  month,
    datasets: [
      {
          label               : 'EB Kwh',
          backgroundColor     : '#67b7dc',
          borderColor         :  '#67b7dc',
          pointRadius          : false,
          pointColor          :  '#67b7dc',
          pointStrokeColor    :  '#67b7dc',
          pointHighlightFill  :  '#67b7dc',
          pointHighlightStroke:  '#67b7dc',
		  fillColor: "#67b7dc",
          data                : dataV
      },
      {
        label                 : 'DG Kwh',
          backgroundColor     : '#dc3545',
          borderColor         :  '#dc3545',
          pointRadius         : false,
          pointColor          :  '#dc3545',
          pointStrokeColor    :  '#dc3545',
          pointHighlightFill  :  '#dc3545',
          pointHighlightStroke:  '#dc3545',
		  fillColor: "#dc3545",
          data                : dataV1
      }
    ]
  };
  
    var barChartOptions = {
	tooltips: {
        callbacks: {
            label: function(tooltipItem) {
			/*var dis = Math.round(tooltipItem.yLabel);*/
			var dis = tooltipItem.yLabel;
             var vad = dis;
                return  vad;
            }
        }
    },
      responsive              : true,
      maintainAspectRatio     : true,
      datasetFill             : true,
	    scales: {
		yAxes: [{
              ticks:{
                  stepSize :1000,

              }
			  }]
		}
	      };


    var barChart = new Chart(barChartCanvas, {
      type: 'bar', 
      data: barChartData,
      options: barChartOptions,
    });
	
	barChart.Bar(barChartData, barChartOptions);
	
</script>
<script>
//	alert("hai");

	//mutiLinedataProvider
var dataProvider = document.getElementById('mutiLinedataProvider').value;
var Graphs = document.getElementById('mutiLinegraph').value;
//alert(Graphs);alert(dataProvider);
var jsondataProvider = JSON.parse(dataProvider);
var jsondataGraph = JSON.parse(Graphs);
	//alert(jsondataGraph);
//	alert(dataProvider);alert(Graphs);
	var linechart = AmCharts.makeChart("barChart4", {
	"type": "serial",
	"theme": "light",
	"dataProvider": jsondataProvider,
	"valueAxes": [{
	"gridColor": "#FFFFFF",
	"gridAlpha": 0.2,
	"dashLength": 0
	}],
	"gridAboveGraphs": true,
	"startDuration": 0.3,
	"graphs":jsondataGraph,
	"fontSize": 14,
	"chartCursor": {
	"categoryBalloonEnabled": false,
	"cursorAlpha": 0,
	"zoomable": false
	},
	"categoryField": "month",
	"categoryAxis": {
	"gridPosition": "start",
	"gridAlpha": 0
	},
	"export": {
	"enabled": true // false- If don't need to dowload option 
	}
	});
	</script>

	<script type="text/javascript">
	var gId=$("#gatewayCode").val();
	var sId=$("#sensorCode").val();
	var pageURL = $(location).attr("href");	
	window.onload = function(){
	setTimeout(function(){
	document.getElementById('trendGraph').src = './trendGraph.php?gatewayCode='+gId+'&sensorCode='+sId;
	document.getElementById('log_report').src = './icdMeterLog.php?gatewayCode='+gId+'&sensorCode='+sId;
	document.getElementById('daily_report').src = './energyMeterDlyReport.php?gatewayCode='+gId+'&sensorCode='+sId;
	ocument.getElementById('dg_log_report').src = './dgicdMeterLog.php?gatewayCode='+gId+'&sensorCode='+sId;
	document.getElementById('dg_daily_report').src = './dgenergyMeterDlyReport.php?gatewayCode='+gId+'&sensorCode='+sId;
	//setTimeout(function(){ $(".loader").hide();},500);
	},500);
	};
/*	function dailyReport(){
	var gId=$("#gatewayCode").val();
	var sId=$("#sensorCode").val();
	document.getElementById('daily_report').src = './energyMeterDlyReport.php?gatewayCode='+gId+'&sensorCode='+sId;
	$(".loader").hide();
	}
	function trentGraph(){
	var gId=$("#gatewayCode").val();
	var sId=$("#sensorCode").val();
	document.getElementById('trendGraph').src = './trendGraph.php?gatewayCode='+gId+'&sensorCode='+sId;
	$(".loader").hide();
	}
		function logReport(){
	var gId=$("#gatewayCode").val();
	var sId=$("#sensorCode").val();
	document.getElementById('log_report').src = './icdMeterLog.php?gatewayCode='+gId+'&sensorCode='+sId;
	$(".loader").hide();
	}
		function dgLogReport(){
	var gId=$("#gatewayCode").val();
	var sId=$("#sensorCode").val();
	document.getElementById('dg_log_report').src = './dgicdMeterLog.php?gatewayCode='+gId+'&sensorCode='+sId;
	$(".loader").hide();
	}
		function dgDailyReport(){
	var gId=$("#gatewayCode").val();
	var sId=$("#sensorCode").val();
	document.getElementById('dg_daily_report').src = './dgenergyMeterDlyReport.php?gatewayCode='+gId+'&sensorCode='+sId;
	$(".loader").hide();
	}*/
	function postFeeder()
	{
		var feederName=document.getElementById("feederPost").value;
		var feedSplit= feederName.split("|");
		var senCod=feedSplit[1];
		var gatCod=feedSplit[2];
		var comId=feedSplit[3];
		var branId=feedSplit[4];
		FormName		= document.dashboard;
		FormName.action= "meterDashboard.php?companyId="+comId+"&branchId="+branId+"&sensorCode="+senCod+"&gatewayCode="+gatCod;
		FormName.submit();
	}
	</script>
	<style type="text/css">
	iframe {
		overflow-x: hidden;
		overflow-y: scroll;
	}
	</style>
	{/literal}
	{include file="footer.tpl"}