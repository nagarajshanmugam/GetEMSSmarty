	<div class="content-wrapper">
	<section class="content-header">
	<div class="card">
				<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr>{if $smarty.get.companyId neq ""}<td style="font-size:15PX;font-weight: bold;">{$ListEditView.0.companyName}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>{/if}
				<td style="font-size:15PX;font-weight: bold;">Company update&nbsp;</td>
				</tr>
				<tr>{if $smarty.get.companyId neq ""}<td style="font-size:10PX;color:#999999;">Company Name</td>{/if}
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>				
				</div>
			</div>
<!--	</section>
		<section class="content">
-->			<div class="card">
				
			
			{if $SuccessMessage neq ""}
				<div class="card-body">
					<div class="isa_success">
					<i class="fa fa-check"></i>
					{$SuccessMessage}		 
					</div>
				</div>
			{/if}
			{if $ErrorMessage neq ""}
				<div class="card-body">
					<div class="isa_error">
					<i class="fa fa-check"></i>
					{$ErrorMessage}		 
					</div>
				</div>
			{/if}
				<div class="card-body">
					<form class="form-horizontal" name="companyReg" id="companyReg" enctype="multipart/form-data" method="post" onsubmit="return ValidateFields();">
						<input type="hidden" name="hdAction" id="hdAction">
						<input type="hidden" id="companyId" name="companyId" value="{$ListEditView.0.slNo}" />
						<input type="hidden" id="imageval" name="imageval" class="form-control" />
						<div class="row">
						<div class="form-group col-md-6">
							<label for="inputEmail3">Company Name <span class="required"><b>*</b></span></label>
							<input type="text" name="companyMaster" class="form-control form-control-sm" id="companyMaster" placeholder="Company Name" autocomplete="Off" tabindex="1" value="{if $ListEditView.0.companyName neq ""}{$ListEditView.0.companyName}{/if}">
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">Address <span class="required"><b>*</b></span></label>
							<textarea name="address" class="form-control form-control-sm" id="address" autocomplete="Off" tabindex="9" placeholder="Address">{if $ListEditView.0.address neq ""}{$ListEditView.0.address}{/if}</textarea>
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">Area </label>
							<input type="text" name="area" class="form-control form-control-sm" id="area" placeholder="Area" autocomplete="Off" tabindex="10" value="{if $ListEditView.0.area neq ""}{$ListEditView.0.area}{/if}">
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">Contact Person <span class="required"><b>*</b></span></label>
							<input type="text" name="contactPerson" class="form-control form-control-sm" id="contactPerson" placeholder="Contact Person" autocomplete="Off" tabindex="3" value="{if $ListEditView.0.contactPerson neq ""}{$ListEditView.0.contactPerson}{/if}">
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">City <span class="required"><b>*</b></span></label>
							<input type="text" name="city" class="form-control form-control-sm" id="city" placeholder="City" autocomplete="Off" tabindex="11" value="{if $ListEditView.0.city neq ""}{$ListEditView.0.city}{/if}">
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">Phone</label>
							<input type="text" class="form-control form-control-sm" id="phone" name="phone" placeholder="Phone" autocomplete="Off" tabindex="4" onKeyUp="numericFilter(this);" value="{if $ListEditView.0.phone neq ""}{$ListEditView.0.phone}{/if}" maxlength="15">
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">Pincode <span class="required"><b>*</b></span></label>
							<input type="text" name="pincode" class="form-control form-control-sm" id="pincode" placeholder="Pincode" autocomplete="Off" tabindex="12" onKeyUp="numericFilter(this);" value="{if $ListEditView.0.pincode neq ""}{$ListEditView.0.pincode}{/if}" maxlength="6">
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">Email Id <span class="required"><b>*</b></span></label>
							<input type="text" name="email" class="form-control form-control-sm" id="email" placeholder="Email Id" autocomplete="Off" tabindex="5" value="{if $ListEditView.0.email neq ""}{$ListEditView.0.email}{/if}">
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">State <span class="required"><b>*</b></span></label>
							<input type="text" name="state" class="form-control form-control-sm" id="state" placeholder="State" autocomplete="Off" tabindex="13" value="{if $ListEditView.0.state neq ""}{$ListEditView.0.state}{/if}">
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">PAN No </label>
							<input type="text" name="panNo" class="form-control form-control-sm" id="panNo" placeholder="PAN No" autocomplete="Off" tabindex="14" value="{if $ListEditView.0.panNo neq ""}{$ListEditView.0.panNo}{/if}">
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">GST No </label>
							<input type="text" name="gstNo" class="form-control form-control-sm" id="gstNo" placeholder="GST No" autocomplete="Off" tabindex="15" value="{if $ListEditView.0.gstin neq ""}{$ListEditView.0.gstin}{/if}">
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">Company Logo <span class="required"><b>*</b></span></label>                     
							<input type="hidden" name="imageName" class="form-control form-control-sm" id="imageName" autocomplete="Off" tabindex="16" value="{if $ListEditView.0.companyLogo neq ""}{$ListEditView.0.companyLogo}{/if}" >
						{if $ListEditView.0.slNo neq ""}
							<a href="./images/CompanyLogo/{$ListEditView.0.companyLogo}" target="_blank"><img src="./images/CompanyLogo/{$ListEditView.0.companyLogo}" width="250px" height="50px" id="imgFile" name="imgFile" /></a>
							<a href="#" onclick="Showfile();" id="edit" name="edit"><i class="fa fa-edit"></i></a>
							<input type="file"  id="image" value="{$smarty.post.image}" name="image" tabindex="16" autocomplete="Off" class="form-control form-control-sm" value="{$master_dtls.companyLogo}" accept="image/x-jpg,image/png" style="display:none;"  onblur="ValidateFields1('image');"><span style="display:none; color:#FF0000; font-size:12px;" id="spanMsg">Only JPG,PNG images are allowed / Width * Height - 250 * 50 / Below - 500KB</span>
						{else}
							<input type="file"  id="image" value="{$smarty.post.image}" accept="image/x-jpg,image/png" onchange="return ValidateFileUpload()" name="image" tabindex="16" autocomplete="Off" class="form-control form-control-sm"><span style="color:#FF0000; font-size:12px;">Only JPG,PNG images are allowed / Width * Height - 250 * 55 / Below - 500KB</span>
						{/if}
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail3">Company Logo Small <span class="required"><b>*</b></span></label>                     
							<input type="hidden" name="smallImageName" class="form-control form-control-sm" id="smallImageName" autocomplete="Off" tabindex="16" value="{if $ListEditView.0.companyLogoSmall neq ""}{$ListEditView.0.companyLogoSmall}{/if}" >
						{if $ListEditView.0.slNo neq ""}
							<a href="./images/companyLogoSmall/{$ListEditView.0.companyLogoSmall}" target="_blank"><img src="./images/CompanyLogoSmall/{$ListEditView.0.companyLogoSmall}" width="100" height="100" id="smallImgFile" name="smallImgFile" /></a>
							<a href="#" onclick="Showfile1();" id="edit1" name="edit1"><i class="fa fa-edit"></i></a>
							<input type="file"  id="smallImage" value="{$smarty.post.smallImage}" name="smallImage" tabindex="16" autocomplete="Off" class="form-control form-control-sm" value="{$master_dtls.companyLogoSmall}" accept="image/x-jpg,image/png" style="display:none;"  onblur="ValidateFields1('smallImage');"><span style="display:none; color:#FF0000; font-size:12px;" id="spanMsg1">Only JPG,PNG images are allowed / Width * Height - 80 * 60 / Below - 200KB</span>
						{else}
							<input type="file"  id="smallImage" value="{$smarty.post.smallImage}" accept="image/x-jpg,image/png" name="smallImage" tabindex="16" autocomplete="Off" class="form-control form-control-sm"><span style="color:#FF0000; font-size:12px;">Only JPG,PNG images are allowed / Width * Height - 80 * 60 / Below - 200KB</span>
						{/if}
						</div>
						 
						
						</div>
						<div align="center">
							<center>
							<input type="submit" value="Submit" class="btn btn-create"  onclick="ValidateFields();" />
							</center>
						</div>
					</form>
				</div>
			</div>
		</section>
	</div>
	{literal}
	<script type="text/javascript">
	$(document).ready(function() { 
	$("#email").change(function(){  
	$(".error").remove();
	var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
	
	var emailaddressVal = $("#email").val();
	
	if(!emailReg.test(emailaddressVal)) {
	$("#email").after('<span class="error">Enter a valid email address.</span>');
	$('#email').focus();
	return false;
	}
	});
	});
	</script>
	<script type="text/javascript">
	function numericFilter(data)
	{
	data.value = data.value.replace(/[^.0-9^.+,-]/ig,"");
	}
	function text_filter(data)
	{
	data.value = data.value.replace(/[^ .a-z]/ig,"");
	}
	function Showfile()
	{
	document.getElementById('image').style.display="block";
	document.getElementById('imgFile').style.display="none";
	document.getElementById('edit').style.display="none";
	document.getElementById('spanMsg').style.display="block";
	}
	function Showfile1()
	{
	document.getElementById('smallImage').style.display="block";
	document.getElementById('smallImgFile').style.display="none";
	document.getElementById('edit1').style.display="none";
	document.getElementById('spanMsg1').style.display="block";
	}
	function ValidateFields1(id)
	{
	
	var val = document.getElementById(id).value;
	if(val == '')
	{
	$(".error").remove();
	$("#"+id).after('<span class="error">This field is required</span>');
	$("#"+id).focus();
	return false;		
	}
	else
	{
	$(".error").remove();
	return true;
	}
	}
	function ValidateFields()
	{
	var companyMaster = $('#companyMaster').val();
	var contactPerson = $('#contactPerson').val();
	var phone = $('#phone').val();
	var email = $('#email').val();
	var image = $('#image').val();
	var smallImage = $('#smallImage').val();
	var imageName = $('#imageName').val(); 
	var smallImageName = $('#smallImageName').val(); 
	var address = $('#address').val();
	var area = $('#area').val();
	var city = $('#city').val();
	var pincode = $('#pincode').val();
	var state = $('#state').val();
	var isActive = document.getElementById("customCheckbox2").checked;
	var mailformat = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
	$(".error").remove();
	if (companyMaster.length < 1) {
	$('#companyMaster').after('<span class="error">This field is required</span>');
	$('#companyMaster').focus();
	return false;					
	}
	else if (contactPerson.length < 1) {
	$('#contactPerson').after('<span class="error">This field is required</span>');
	$('#contactPerson').focus();
	return false;					
	}
	else if (email.length < 1) {
	$('#email').after('<span class="error">This field is required</span>');
	$('#email').focus();
	return false;					
	}
    else if(!mailformat.test(email)) {
	$("#email").after('<span class="error">Enter a valid email address.</span>');
	$('#email').focus();
	return false;	
    }
	else if (address.length < 1) {
	$('#address').after('<span class="error">This field is required</span>');
	$('#address').focus();
	return false;					
	}
	else if (city.length < 1) {
	$('#city').after('<span class="error">This field is required</span>');
	$('#city').focus();
	return false;					
	}
	else if (pincode.length < 1) {
	$('#pincode').after('<span class="error">This field is required</span>');
	$('#pincode').focus();
	return false;					
	}
	else if (pincode.length < 6) {
	$('#pincode').after('<span class="error">Pincode Should be 6 digits</span>');
	$('#pincode').focus();
	return false;					
	}
	else if (state.length < 1) {
	$('#state').after('<span class="error">This field is required</span>');
	$('#state').focus();
	return false;					
	}
	else if (image.length < 1 && imageName.length < 1) {
	$('#image').after('<span class="error">This field is required</span>');
	$('#image').focus();
	return false;					
	}
	else if (smallImage.length < 1 && smallImageName.length < 1) {
	$('#smallImage').after('<span class="error">This field is required</span>');
	$('#smallImage').focus();
	return false;					
	}
	}
	function GoBack()
	{
	window.history.back();
	}

function ValidateEmail(inputText)
{
var mailformat = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
if(inputText.value.match(mailformat))
{
alert("Valid email address!");
document.companyReg.email.focus();
return true;
}
else
{
alert("You have entered an invalid email addressz!");
document.companyReg.email.focus();
}
}

	</script>
	<script type="text/javascript">
	function ValidateFileUpload() {
	var imageData = document.getElementById('image');
	var FileUploadPath = imageData.value;
	
	//To check if user upload any file
	if (FileUploadPath == '') {
	alert("Please upload an image");
	
	} else {
	var Extension = FileUploadPath.substring(
	FileUploadPath.lastIndexOf('.') + 1).toLowerCase();
	
	//The file uploaded is an image
	
	if (Extension == "png" || Extension == "jpg") {
	
	// To Display
	if (imageData.files && imageData.files[0]) {
	var reader = new FileReader();
	
	reader.onload = function(e) {
	$('#blah').attr('src', e.target.result);
	}
	
	reader.readAsDataURL(imageData.files[0]);
	}
	
	} 
	
	//The file upload is NOT an image
	else {
	alert("Only  JPG and PNG types are accepted");
	document.getElementById('image').focus();
	document.getElementById('image').value="";
	
	}
	}
	//To Check the file size an image	
	const fi  = document.getElementById('image');
	if (fi .files.length > 0) { 
	for (const i = 0; i <= fi .files.length - 1; i++) { 
	
	const fsize = fi .files.item(i).size; 
	const file = Math.round((fsize / 1024)); 
	// The size of the file. 
	if (file >= 3000) { 
	alert( 
	"File too Big, please select a file less than 1mb"); 
	document.getElementById('image').focus();
	document.getElementById('image').value="";
	} 
	} 
	} 
	
	}
	
	</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	/*background-color:#FFBABA;*/
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	/*vertical-align:middle;*/
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	{/literal}
	{include file="footer.tpl"}