{literal}
<script type="text/javascript">
     function secondsToDhms(seconds,v) {//alert(seconds);
var seconds = Number(seconds);
var d = Math.floor(seconds / (3600*24));
var h = Math.floor(seconds % (3600*24) / 3600);
var m = Math.floor(seconds % 3600 / 60);
var s = Math.floor(seconds % 60);

var dDisplay = d > 0 ? d + (d == 1 ? " day, " : " days, ") : "";
var hDisplay = h > 0 ? h + (h == 1 ? " hr, " : " hrs, ") : "";
var mDisplay = m > 0 ? m + (m == 1 ? " min, " : " min's, ") : "";
var sDisplay = s > 0 ? s + (s == 1 ? " sec" : " sec's") : "";
var res= 'Last Updated' + ' ' + dDisplay + hDisplay + mDisplay + sDisplay;
document.getElementById(v).innerHTML=res;
}
 </script>
 <style type="text/css">
     .padclass
	{
	    padding-top:18px;
	    padding-bottom:3px;
	}
 </style>
 
{/literal}
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/><div class="content-wrapper">
	<div class="content-header">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-body">
						<table style="margin-bottom:-10px;">
						<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
						<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
						<td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>
						<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="font-size:15PX;font-weight: bold;">{$LoctList.0.sensorName}</font>&nbsp;</td>
		<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="font-size:15PX;font-weight: bold;">{$LoctList.0.gateway_id} - {if $LoctList.0.gateway_id eq $gateList.0.gateway_code && $gateList.0.gateway_date_time gte $dateSec|date_format:'%Y-%m-%d %H:%M:%S' } <a style="color: #00CC00;">ON</a> {else} <a style="color: #FF0000;">OFF</a> {/if}</font>&nbsp;</td>
		
						</tr>
						
						
						<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
						<td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
						<td style="font-size:10PX;color:#999999;">Branch Name</td>
						<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="color:#999999;font-size:10PX;">Feeder Name (Place of Installation)</td>
		<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="color:#999999;font-size:10PX;">Gateway Name - Status</td>
						</tr>
						</table>
					</div>
				</div>
			</div>
		</div>
        
       <textarea id="mutiLinegraph" name="mutiLinegraph" style="display:none;">{$LineGraphData}</textarea>
<textarea id="mutiLinegraph2" name="mutiLinegraph2" style="display:none;">{$LineGraphData2}</textarea>
<textarea id="mutiLinedataProviderT" name="mutiLinedataProviderT" style="display:none;">{$LineGraphDataT}</textarea>
<textarea id="mutiLinedataProviderH" name="mutiLinedataProviderH" style="display:none;">{$LineGraphDataH}</textarea>
  
        <div class="row">
        <div class="col-md-9">
        <div class="card card-primary card-outline">
						<div class="card-header">
						<h3 class="card-title">
						<i class="far fa-chart-bar"></i>
						Temperature Chart
						</h3>
						</div>                    
                  <div class="chart">
							 <div id="linechartdiv" style="height: 285px;"></div>
                             </div>
                            <center><b><span id="rd"></span></b></center><br/>
        </div>
        
        <div class="card card-primary card-outline">
						<div class="card-header">
						<h3 class="card-title">
						<i class="far fa-chart-bar"></i>
						 Humidity Chart
						</h3>
						</div>                    
                  <div class="chart">
						 <div id="linechartdiv1" style="height: 285px;"></div>
							</div>
							
							<center><b><span id="rd1"></span></b></center><br/>
        </div>
                   
					</div>
					 {foreach from=$TempSenList item=List}
            <tr id="{$j++}">
          <div class="col-md-3">
            <!-- Box Comment -->
            <div class="card card-widget card-primary">
              <div class="card-header" style="margin-bottom:-15px;">
                <div class="card-title">
                  <center><span class="username"><b><a href="#">{$List.sensorName}</a></b></span></center>
                </div>
              </div>
              
              <div class="card-body">
                  
              
                <div class="row">
                    
                  <div class="col-sm-6">
                    <div class="description-block">
                         <img class="img-circle elevation-2" src="./images/ticon.jpg" alt="User Image" width="70" height="70">
                      <h5 class="description-header" style="color:#15b5f0;padding-top:6px;"><b>{$List.temperature_c} &deg; C</b></h5>
                      <span class="description-text"></span>
                    </div>
                  </div>

                  <div class="col-sm-6">
                    <div class="description-block">
                        <img class="img-circle elevation-2" src="./images/hiconf.png" alt="User Image" width="70" height="70">
                      <h5 class="description-header" style="color:#7db616;padding-top:6px;"><b>{$List.humidity} %</b></h5>
                      <span class="description-text"></span>
                    </div>
                  </div>
                  
                </div>
             
               
                <center ><b><span class="text-muted" style="margin-bottom:-15px;margin-top:-5px;" id="{$j}" ><script type="text/javascript">secondsToDhms('{$List.secs}','{$j}');</script> ago</span></b></center>
              </div>
              
              <div class="card-footer card-comments">
                  <div class="comment-text" ><span class="username" style="color:#15b5f0; margin-top:-5px;"><b>Latest Incidents</b></span></div>
                {foreach from=$incidentList item=ListIncidentLog}
				 
                     <div class="card-comment">
                  <div class="comment-text" style="margin:-5px;">
                    <span class="username">
                      {$ListIncidentLog.sensor_code}
                      <span class="text-muted float-right"> {$ListIncidentLog.recorded_date_time|date_format:"%e-%b-%Y %I:%M %p"}</span>
                    </span>
                   T - {$ListIncidentLog.temperature_c} &deg; C &nbsp;&nbsp;&nbsp;&nbsp;
                   H - {$ListIncidentLog.humidity} %
                  </div>
                </div>

{/foreach}
              </div>
              
              
             
            </div>
            <!-- /.card -->
          </div>
          </tr>
          {/foreach}
				
       
           
          <!-- /.col -->
        </div>
    
    
    
    
	</div>
	</div>
	</div>
	{literal}
    
	<style>
	.slNo{
	width:5%;
	}
	.name{
	width:15%;
	}.status{
	width:10%;
	}

	#linechartdiv {
	width	: 100%;
	height	: 400px;
	}
	
	#dgLinechartdiv {
	width	: 100%;
	height	: 800px;
	}
	</style>
   <script src="amcharts/amcharts.js"></script>
	<script src="amcharts/serial.js"></script>
	<script src="amcharts/themes/light.js"></script>
<!--     Gauge Script      --->
<script src="./amChart/amchart.js"></script>
<script src="./js/gaugeChart/gauge.js"></script>
<script src="./js/gaugeChart/export.min.js"></script>
	
	<script src="amcharts/plugins/export/export.min.js"></script>
	<link rel="stylesheet" href="amcharts/plugins/export/export.css" type="text/css" media="all" />
	<script src="./amChart/amchartLight.js"></script>
<script src="./amChart/amchartColumnChart.js"></script>
    <script>
	//mutiLinedataProvider
	var dataProvider = document.getElementById('mutiLinedataProviderT').value;
var Graphs = document.getElementById('mutiLinegraph').value;
//alert(Graphs);alert(dataProvider);
var jsondataProvider = JSON.parse(dataProvider);
var jsondataGraph = JSON.parse(Graphs);
	//alert(jsondataGraph);
//	alert(dataProvider);alert(Graphs);
var ndat = jsondataProvider[0].rdate; 
document.getElementById("rd").innerHTML='Date : '+ndat;
	var linechart = AmCharts.makeChart("linechartdiv", {
	"type": "serial",
	"theme": "light",
	"dataProvider": jsondataProvider,
	"valueAxes": [{
	"gridColor": "#FFFFFF",
	"gridAlpha": 0.2,
	"dashLength": 0
	}],
	"gridAboveGraphs": true,
	"startDuration": 0.3,
	"graphs":jsondataGraph,
	"fontSize": 12,
	"chartCursor": {
	"categoryBalloonEnabled": false,
	"cursorAlpha": 0,
	"zoomable": false
	},
	"categoryField": "month",
	"categoryAxis": {
	"gridPosition": "start",
	"gridAlpha": 0,
	"labelRotation":80
	},
	"export": {
	"enabled": true // false- If don't need to dowload option 
	}
	});
	</script>
    <script>
	

	//mutiLinedataProvider
	var dataProvider = document.getElementById('mutiLinedataProviderH').value;
var Graphs = document.getElementById('mutiLinegraph2').value;
//alert(Graphs);alert(dataProvider);
var jsondataProvider = JSON.parse(dataProvider);
var jsondataGraph = JSON.parse(Graphs);
	//alert(jsondataGraph);
//	alert(jsondataProvider);
var ndat = jsondataProvider[0].rdate; 
document.getElementById("rd1").innerHTML='Date : '+ndat;
	var linechart = AmCharts.makeChart("linechartdiv1", {
	"type": "serial",
	"theme": "light",
	"dataProvider": jsondataProvider,
	"valueAxes": [{
	"gridColor": "#FFFFFF",
	"Color": "#000000",
	"gridAlpha": 0.2,
	"dashLength": 0
	}],
	"gridAboveGraphs": true,
	"startDuration": 0.3,
	"graphs":jsondataGraph,
	"fontSize": 12,
	"chartCursor": {
	"categoryBalloonEnabled": false,
	"cursorAlpha": 0,
	"zoomable": false
	},
	"categoryField": "month",
	"categoryAxis": {
	"gridPosition": "start",
	"gridAlpha": 0,
	"labelRotation":80
	},
	"export": {
	"enabled": true // false- If don't need to dowload option 
	}
	});
	</script>
    
	{/literal}
	
	{include file="footer.tpl"}