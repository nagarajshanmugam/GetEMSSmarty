{literal}
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script type="text/javascript">
     function secondsToDhms(seconds,v) {//alert(seconds);
var seconds = Number(seconds);
var d = Math.floor(seconds / (3600*24));
var h = Math.floor(seconds % (3600*24) / 3600);
var m = Math.floor(seconds % 3600 / 60);
var s = Math.floor(seconds % 60);

var dDisplay = d > 0 ? d + (d == 1 ? " day, " : " days, ") : "";
var hDisplay = h > 0 ? h + (h == 1 ? " hr, " : " hrs, ") : "";
var mDisplay = m > 0 ? m + (m == 1 ? " min, " : " min's, ") : "";
var sDisplay = s > 0 ? s + (s == 1 ? " sec" : " sec's") : "";
var res=  dDisplay + hDisplay + mDisplay + sDisplay;
document.getElementById(v).innerHTML=res;
}
 </script>
 
<script type="text/javascript">
    function includecomma1old(c,v)
{
var x=Math.round(c);
x=x.toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != '')
lastThree = ',' + lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
//var res = res.toFixed(4);
//var res =number_format(res, 2);
var res = res+'.00';
document.getElementById(v).innerHTML=res;
}
</script>
<script type="text/javascript">
	function includecomma1(c,v)
{
//var x=Math.round(c);
//var x=c.toFixed(2);

var x=c.split(".");
var ld=x[1];
var ty=typeof(x[1]);//alert(ty);
if(ty == 'undefined')
{
   
    var ld='00';
}
else
{
var ld=x[1].slice(0, 2);
}
x=x[0].toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != '')
{
lastThree = ',' + lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
}
else
{
lastThree =  lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
}
//var res = res+'.00';
var res = res+'.'+ld;
document.getElementById(v).innerHTML=res;
}
</script>
{/literal}

<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<body onLoad="doOnLoad();">
<div class="content-wrapper">
    <div class="content-header">

      <div class="container-fluid">
            <div class="row"> 
				<div class="col-md-12">
					<div class="card">
						<div class="card-body">
						  <table style="margin-bottom:-10px;">
						  <tr><td style="font-size:15PX;font-weight: bold;">{$companyDetail.0.companyName}&nbsp;&nbsp;</td>
						  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
						  <td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>
						  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
						  <td style="font-size:15PX;font-weight: bold;">Energy Meter</font>&nbsp;</td></tr>
						  <tr><td style="font-size:10PX;color:#999999;">Company Name</td>
						  <td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
						  <td style="font-size:10PX;color:#999999;">Branch Name</td>
						  <td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
						  <td style="color:#999999;font-size:10PX;">Dashboard</td><td>&nbsp;</td>
						  </tr>
						  </table>
						</div>
					</div>
				</div>
          </div>
     <div class="row">
          <div class="col-12 col-sm-6 col-md-2">
            <div class="info-box card-outline card-primary">
              <span class="info-box-icon bg-info elevation-1"><i class="fa fa-rupee"></i></span>
              <div class="info-box-content">
                <span class="info-box-text">Today Cost&ensp;&ensp;&ensp;&ensp;</span>
                <span class="info-box-number" id="tc">
                  
                  <script type="text/javascript">includecomma1('{$todayCostKWH.0.cost}','tc');</script>
                  <small></small>
                </span>
              </div>
            </div>
          </div>
          <div class="col-12 col-sm-6 col-md-2">
            <div class="info-box mb-2 card-outline card-danger">
              <span class="info-box-icon bg-danger elevation-1"><i class="fa fa-bolt"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Today KWH &ensp;&ensp;&ensp;&ensp;</span>
                <span class="info-box-number" id="tk">
                    <script type="text/javascript">includecomma1('{$todayCostKWH.0.TOTAL_KWH}','tk');</script>
                    </span>
              </div>
            </div>
          </div>
          <div class="clearfix hidden-md-up"></div>
          <div class="col-12 col-sm-6 col-md-2">
            <div class="info-box mb-2 card-outline card-primary">
              <span class="info-box-icon bg-info elevation-1"><i class="fa fa-rupee"></i></span>
              <div class="info-box-content">
                <span class="info-box-text">This Month Cost</span>
                <span class="info-box-number" id="cmc">
                    <script type="text/javascript">includecomma1('{$monthCostKWH.0.cost}','cmc');</script>
                    </span>
              </div>
            </div>
          </div>
          <div class="col-12 col-sm-6 col-md-2">
            <div class="info-box mb-2 card-outline card-danger">
              <span class="info-box-icon bg-danger elevation-1"><i class="fa fa-bolt"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">This Month KWH</span>
                <span class="info-box-number" id="cmk">
                    <script type="text/javascript">includecomma1('{$monthCostKWH.0.TOTAL_KWH}','cmk');</script>
                </span>
              </div>
            </div>
          </div>
          <div class="clearfix hidden-md-up"></div>
          <div class="col-12 col-sm-6 col-md-2">
            <div class="info-box mb-2 card-outline card-primary">
              <span class="info-box-icon bg-info elevation-1"><i class="fa fa-rupee"></i></span>
              <div class="info-box-content">
                <span class="info-box-text">Last Month Cost</span>
                <span class="info-box-number" id="lmc">
                <script type="text/javascript">includecomma1('{$LastMonthCostKWH.0.cost}','lmc');</script>
                </span>
              </div>
            </div>
          </div>
          <div class="col-12 col-sm-6 col-md-2">
            <div class="info-box mb-2 card-outline card-danger">
              <span class="info-box-icon bg-danger elevation-1"><i class="fa fa-bolt"></i></span>
              <div class="info-box-content">
                <span class="info-box-text">Last Month KWH</span>
                <span class="info-box-number" id="lmk">
                    <script type="text/javascript">includecomma1('{$LastMonthCostKWH.0.TOTAL_KWH}','lmk');</script>
                    </span>
              </div>
            </div>
          </div>
        </div>
        
        
        <textarea id="currMonQut1" name="currMonQut1"  style="display:none;">{$getCurMonQut1}</textarea>
        <textarea id="currMonQut2" name="currMonQut2" style="display:none;">{$getCurMonQut2}</textarea>
        <textarea id="currMonQut3" name="currMonQut3"  style="display:none;">{$getCurMonQut3}</textarea>
         <div class="row">
             <div class="col-md-6">
     <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">This month - Cost</h3>
              </div>
              <div class="card-body">
                <canvas id="pieChart4" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
              </div>
            </div>
            </div>
            
             <!--<div class="col-md-3">
     <div class="card card-danger">
              <div class="card-header">
                <h3 class="card-title">This month - Kwh</h3>
              </div>
              <div class="card-body">
                <canvas id="pieChart1" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
              </div>
            </div>
            </div>-->
            
            <div class="col-md-6">
     <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Last month - Cost</h3>
              </div>
              <div class="card-body">
                <canvas id="pieChart3" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
              </div>
            </div>
            </div>
            
         <!--<div class="col-md-3">
     <div class="card card-danger">
              <div class="card-header">
                <h3 class="card-title">Last month - Kwh</h3>
              </div>
              <div class="card-body">
                <canvas id="pieChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
              </div>
            </div>
            </div>-->
            
           
            
           <!-- <div class="col-md-4">
     <div class="card card-danger">
              <div class="card-header">
                <h3 class="card-title">Kwh - Today</h3>
              </div>
              <div class="card-body">
                <canvas id="pieChart2" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
              </div>
            </div>
            </div>-->
            
         
            
            
            
            <!--<div class="col-md-4">
     <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Cost - Today</h3>
              </div>
              <div class="card-body">
                <canvas id="pieChart5" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
              </div>
            </div>
            </div>-->
            </div>
        
        
        <textarea id="currMonQut" name="currMonQut"  style="display:none;">{$getCurMonQut}</textarea>
        <div class="row">
				<div class="col-md-8">
			
					<div class="card card-primary card-outline">
						<div class="card-header">
						<h3 class="card-title">
						<i class="far fa-chart-bar"></i>
						Cost Chart
						</h3>
						</div>
                        
					<!--<div id="linechartdiv" style="height: 260px;"></div><br />-->
                    
                    <div class="chart">
        <canvas id="barChart2" style="height: 278px;" ></canvas>
        </div>
                    
					</div>
				</div>
			
			
			
			<div class="col-md-4">
			<div class="card card-primary card-outline">
			<div class="card-header">
			<h3 class="card-title">Recent Incidents</h3>
			</div>
			<div class="card-body p-0">
			<ul class="products-list product-list-in-card pl-2 pr-2">
			{foreach from=$incidentList item=ListIncidentLog}
			{assign var="alertMsg0" value=$ListIncidentLog.alert_message|replace:'Hi!':''}
			{assign var="alertMsg1" value=$alertMsg0|replace:'Best regards,':''}
			{assign var="alertMsg" value=$alertMsg1|replace:'Arka Automaations Limited.':''}
			{assign var="alertBreak" value=","|explode:$alertMsg}
			{assign var="l" value=0}
			<li class="item">
			<div class="product-img">
			<a href="javascript:void(0)" class="product-title">{$ListIncidentLog.sensor_code} - ( {$ListIncidentLog.recorded_date_time|date_format:"%e-%b-%Y %I:%M %p"} )</a>
			{if $ListIncidentLog.alert_status eq "Low"}<span class="badge badge-warning float-right">{elseif $ListIncidentLog.alert_status eq "Normal"}<span class="badge badge-info float-right">{elseif $ListIncidentLog.alert_status eq "High"}<span class="badge badge-danger float-right">{/if}{$ListIncidentLog.alert_status}</span>
			<span class="product-description" style="font-size:12px">
			{section name=i loop=$alertBreak}
			{assign var="l" value=$l+1}
			{$alertBreak[i]|escape},{if $l eq '1'}<br />{/if}
			{/section}
			</span>
			</div>
			</li>
			{/foreach}
			</ul>
			</div>
			<div class="card-footer text-center">
			<a href="listIncidentLog.php" class="uppercase">View All Incidents</a>
			</div>
			</div>
			</div>
			</div>
        
        
            <div class="row">
			<div class="col-md-12">
            <div class="card card-outline card-primary">
            <div class="card-header">
						<h3 class="card-title">
						<i class="fa fa-list"></i>
						&nbsp;&nbsp;List of Energy Meter
						</h3>
						
						</div>
               <div class="card-body table-responsive no-padding">
			 <div class="row">
<input type="hidden" id="cid" name="cid" value="{if $smarty.get.companyId neq ""}{$smarty.get.companyId}{else}{$smarty.session.customerId}{/if}" />
				<input type="hidden" id="bid" name="bid" value="{$smarty.get.branchId}" />
				<input type="hidden" value="{$Dashboard.0.segmentName}" />
    <div id="list_books" class="col-12">
			  <table id="example" class="table table-bordered table-hover">
                <thead>
                <tr>
    			  <th class="slNo" rowspan="2" >#</th>
                  <th class="name" rowspan="2">Place Of Installation</th>
                  <th class="gate" rowspan="2">Gateway</th>
				   <th class="status" rowspan="2">Status</th>
                  <th  colspan="2" class="code" >Today</th>
                  <th class="action" rowspan="2">Date Time</th>
                  <th class="last" rowspan="2">Last Comm</th>
                  
          
                </tr>
                <tr>
    			 
                  <th class="cost" >KWH</th>
                  <th class="cost" >Cost</th>
                  
                </tr>
                </thead>
                <tbody>
				{foreach from=$MeterList item=List}
                {assign var=pid value=$List.slNo|base64_encode}
                <tr id="{$j++}">
				 <td >{$j}</td>
				 	
                 
                     <td><a href="meterDashboard.php?companyId={$List.company_id|base64_encode}&branchId={$List.branch_id|base64_encode}&sensorCode={$List.sensor_code|base64_encode}&gatewayCode={$List.gateway_code|base64_encode}" style="text-decoration:underline;color:#000000;" title="Meter Details" >{$List.feeder_name}</a>{foreach from=$selQryS item=sub}{if $List.feeder_type eq "Main Meter" &&  $List.slNo eq $sub.parent_id}&ensp;&ensp;<a href="subdashboard.php?parent_id={$pid}&companyId={$smarty.get.companyId}&branchId={$smarty.get.branchId}"><i class="fa fa-sitemap" aria-hidden="true" title="Submeter List"></i></a>{/if}{/foreach}</td>
                 
                 <td >{$List.gateway_code}</td>
				 
				 
		
				<td>
				{foreach from=$gateList item=gate}
			
				{if $gate.gateway_code neq "YMN-1" && $gate.gateway_code eq $List.gateway_code && $gate.gateway_date_time gte $dateSec|date_format:'%Y-%m-%d %H:%M:%S' }
                
                <img  src="./images/on.png">
                 {assign var="tog" value='1'}
                {elseif $gate.gateway_code neq "YMN-1" && $gate.gateway_code eq $List.gateway_code && $gate.gateway_date_time lt $dateSec|date_format:'%Y-%m-%d %H:%M:%S'}
                
                <img  src="./images/off.png">
                 {assign var="tog" value='1'}
                {/if}
                
                
                {if $gate.gateway_code eq "YMN-1" && $gate.gateway_code eq $List.gateway_code && $gate.gateway_date_time gte $dateSec1|date_format:'%Y-%m-%d %H:%M:%S' }
                
                <img  src="./images/on.png">
                 {assign var="tog" value='1'}
                {elseif $gate.gateway_code eq "YMN-1" && $gate.gateway_code eq $List.gateway_code && $gate.gateway_date_time lt $dateSec1|date_format:'%Y-%m-%d %H:%M:%S'}
                
                <img  src="./images/off.png">
                 {assign var="tog" value='1'}
                {/if}
               
                {/foreach}
                {if $tog eq ''}
                
                <img  src="./images/off.png">
                {/if}
                 {assign var="tog" value=''}
                </td>
				
				
			
                 
             {foreach from=$CostKWH item=costKwh}
             
				  {if $costKwh.sensor_code eq $List.sensor_code}
				  
                    <td align="right" id="{$j}kwh"> <script type="text/javascript">includecomma1('{$costKwh.TOTAL_KWH}','{$j}kwh');</script></td>
                    <td align="right" id="{$j}cost"> <script type="text/javascript">includecomma1('{$costKwh.cost}','{$j}cost');</script></td>
                  {/if}
				  {/foreach}
				  <td>{$List.recorded_date_time|date_format:"%d-%b-%Y %I:%M:%S %p"}</td>
		       <td id="{$j}"><script type="text/javascript">secondsToDhms('{$List.secs}','{$j}');</script> ago</td>
			   
            
                </tr>
                {foreachelse}
                <tr><td colspan="8"><center>No Records Found</center></td></tr>
                {/foreach}
               
               
                </tbody>
                
              </table>
			  </div>
</div>
</div>
<div class="card-body table-responsive">
            <div class="row">
        </div>
        </div>
      </div>
    </div>
  </div>
  </div>
  </div>
  </div>
  </body>
 {literal}
 <style>
 .slNo
 {
 width:3%;
 }
 .name
 {
 width:18%;
 }
 .gate
 {
 width:10%;
 }
 .status
 {
 width:5%;
 }
 .code
 {
 width:10%;
 }
 .cost
 {
 width:5%;
 }
 .action
 {
 width:15%;
 }
 .last
 {
 width:11%;
 }
 .uline
 {
 text-decoration:underline;
 }
 #barChart2 {
	width	: 100%;
	height	: 450px;
	}	
 </style>
  <script>
  $(function () {
    $('#example1').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : true,
      'ordering'    : false,
      'info'        : false,
	  'pageLength': 50,
      'autoWidth'   : false,
      "columnDefs": [{
                "targets": '_all',
                "createdCell": function (th, cellData, rowData, row, col) {
                    $(th).css('padding', '10px')
                }
            }]
    })
  })
  
</script>
 <script type="text/javascript">
 function doOnLoad()
 {
 setInterval(Add_Item, 3000);
 }
 </script>
 <script type="text/javascript">
  $("input[data-bootstrap-switch]").each(function(){
      $(this).bootstrapSwitch('state', $(this).prop('checked'));
    });
	</script>
	    <script type="text/javascript">
	function Add_Item()
{
var cid =$('#cid').val() ;
var bid =$('#bid').val() ;//alert(bid)
$.ajax({
		type: "POST",
		url: "getTableData.php",
		data: {cid:cid,bid:bid},
		success: function(data) {
		$("#list_books").html(data);
		}
		});
}
	</script>
	<style>
	    .dataTable thead .sorting_asc,
 .dataTable thead .sorting_desc,
.dataTable thead .sorting {
    padding-left: 2.2rem !important;
    padding-right: 0.75rem !important;
 }
	</style>
	 <script type="text/javascript">
    function addcomma(c)
{
var x=c;
x=x.toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != '')
    lastThree = ',' + lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
return res;
}

function includecomma(c)
{
var x=c;
x=x.toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != '')
    lastThree = ',' + lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
return res;
}
</script>
<script type="text/javascript">
var result = document.getElementById('currMonQut1').value;

var jsonData=result;
var obj = JSON.parse(jsonData);
var sensor = "";
var dataVal = "";
var dataVal1 = "";
var colo = "";
var i;
for (i = 0; i < obj.length; i++) {
if(i==0){
  sensor += obj[i].sensorcode ;
  dataVal += obj[i].kwh;
  dataVal1 += obj[i].cost;
   colo += obj[i].color;
   }
  else
  {
  sensor += ", "+ obj[i].sensorcode;
  dataVal += ", "+ obj[i].kwh;
   dataVal1 += ", "+ obj[i].cost;
   colo += ', '+ obj[i].color;
 }
}

var sensorVal = sensor;
var dataValue =dataVal;
var dataValue1 =dataVal1;
var colors =colo;


var sensor =  sensorVal.split(',');
var dataV=  dataVal.split(',');
var dataV1=  dataVal1.split(',');
var colors=  colo.split(',');
 
var dis = Math.round(dataV);
var vad = addcomma(dis);

var barChartData = {
labels  :  sensor,
datasets: [
{
label               : 'Kwh',
backgroundColor     : colors,
hoverBackgroundColor: colors,
hoverBorderColor    : colors,
borderColor         :  colors,
pointRadius          : false,
pointColor          :  colors,
pointStrokeColor    :  colors,
pointHighlightFill  :  colors,
pointHighlightStroke:  colors,
fillColor: colors,
data                : dataV
}
]
};
 
	var barChartDataCost = {
labels  :  sensor,
datasets: [
{
label               : 'Cost',
backgroundColor     : colors,
hoverBackgroundColor: colors,
hoverBorderColor    : colors,
borderColor         :  colors,
pointRadius          : false,
pointColor          :  colors,
pointStrokeColor    :  colors,
pointHighlightFill  :  colors,
pointHighlightStroke:  colors,
fillColor: colors,
data                : dataV1
}
]
};

	
	
	var pieChartCanvas = $('#pieChart3').get(0).getContext('2d')
    var pieData        = barChartDataCost;
    var pieOptions     = {
      maintainAspectRatio : false,
      responsive : true,
      legend: {
        position: 'right',
      }
    }
      var pieChart = new Chart(pieChartCanvas, {
      type: 'pie',
      data: pieData,
      options: pieOptions      
    })
	
	var result = document.getElementById('currMonQut2').value;

var jsonData=result;
var obj = JSON.parse(jsonData);
var sensor = "";
var dataVal = "";
var dataVal1 = "";
var colo = "";
var i;
for (i = 0; i < obj.length; i++) {
if(i==0){
  sensor += obj[i].sensorcode ;
  dataVal += obj[i].kwh;
  dataVal1 += obj[i].cost;
   colo += obj[i].color;
   }
  else
  {
  sensor += ", "+ obj[i].sensorcode;
  dataVal += ", "+ obj[i].kwh;
   dataVal1 += ", "+ obj[i].cost;
   colo += ', '+ obj[i].color;
 }
}

var sensorVal = sensor;
var dataValue =dataVal;
var dataValue1 =dataVal1;
var colors =colo;


var sensor =  sensorVal.split(',');
var dataV=  dataVal.split(',');
var dataV1=  dataVal1.split(',');
var colors=  colo.split(',');
 
var dis = Math.round(dataV);
var vad = addcomma(dis);

var barChartData = {
labels  :  sensor,
datasets: [
{
label               : 'Kwh',
backgroundColor     : colors,
hoverBackgroundColor: colors,
hoverBorderColor    : colors,
borderColor         :  colors,
pointRadius          : false,
pointColor          :  colors,
pointStrokeColor    :  colors,
pointHighlightFill  :  colors,
pointHighlightStroke:  colors,
fillColor: colors,
data                : dataV
}
]
};
 
	var barChartDataCost = {
labels  :  sensor,
datasets: [
{
label               : 'Cost',
backgroundColor     : colors,
hoverBackgroundColor: colors,
hoverBorderColor    : colors,
borderColor         :  colors,
pointRadius          : false,
pointColor          :  colors,
pointStrokeColor    :  colors,
pointHighlightFill  :  colors,
pointHighlightStroke:  colors,
fillColor: colors,
data                : dataV1
}
]
};
	

	
	var pieChartCanvas = $('#pieChart4').get(0).getContext('2d')
    var pieData        = barChartDataCost;
    var pieOptions     = {
      maintainAspectRatio : false,
      responsive : true,
      legend: {
        position: 'right',
      }
    }
      var pieChart = new Chart(pieChartCanvas, {
      type: 'pie',
      data: pieData,
      options: pieOptions      
    })
	
	
var result = document.getElementById('currMonQut3').value;
var jsonData=result;
var obj = JSON.parse(jsonData);
var sensor = "";
var dataVal = "";
var dataVal1 = "";
var colo = "";
var i;
for (i = 0; i < obj.length; i++) {
if(i==0){
  sensor += obj[i].sensorcode ;
  dataVal += obj[i].kwh;
  dataVal1 += obj[i].cost;
   colo += obj[i].color;
   }
  else
  {
  sensor += ", "+ obj[i].sensorcode;
  dataVal += ", "+ obj[i].kwh;
   dataVal1 += ", "+ obj[i].cost;
   colo += ', '+ obj[i].color;
 }
}

var sensorVal = sensor;
var dataValue =dataVal;
var dataValue1 =dataVal1;
var colors =colo;


var sensor =  sensorVal.split(',');
var dataV=  dataVal.split(',');
var dataV1=  dataVal1.split(',');
var colors=  colo.split(',');
 
var dis = Math.round(dataV);
var vad = addcomma(dis);

var barChartData = {
labels  :  sensor,
datasets: [
{
label               : 'Kwh',
backgroundColor     : colors,
hoverBackgroundColor: colors,
hoverBorderColor    : colors,
borderColor         :  colors,
pointRadius          : false,
pointColor          :  colors,
pointStrokeColor    :  colors,
pointHighlightFill  :  colors,
pointHighlightStroke:  colors,
fillColor: colors,
data                : dataV
}
]
};
 
	var barChartDataCost = {
labels  :  sensor,
datasets: [
{
label               : 'Cost',
backgroundColor     : colors,
hoverBackgroundColor: colors,
hoverBorderColor    : colors,
borderColor         :  colors,
pointRadius          : false,
pointColor          :  colors,
pointStrokeColor    :  colors,
pointHighlightFill  :  colors,
pointHighlightStroke:  colors,
fillColor: colors,
data                : dataV1
}
]
};
	
	var pieChartCanvas = $('#pieChart2').get(0).getContext('2d')
    var pieData        = barChartData;
    var pieOptions     = {
      maintainAspectRatio : false,
      responsive : true,
      legend: {
        position: 'right',
      }
    }
    //Create pie or douhnut chart
    // You can switch between pie and douhnut using the method below.
    var pieChart = new Chart(pieChartCanvas, {
      type: 'pie',
      data: pieData,
      options: pieOptions      
    })
	
	var pieChartCanvas = $('#pieChart5').get(0).getContext('2d')
    var pieData        = barChartDataCost;
    var pieOptions     = {
      maintainAspectRatio : false,
      responsive : true,
      legend: {
        position: 'right',
      }
    }
      var pieChart = new Chart(pieChartCanvas, {
      type: 'pie',
      data: pieData,
      options: pieOptions      
    })
</script>
    <script type="text/javascript">
var result = document.getElementById('currMonQut').value;

var jsonData=result;
var obj = JSON.parse(jsonData);
var mon = "";
var dataVal = "";
var dataVal1 = "";
var colo = "";
var i;
for (i = 0; i < obj.length; i++) {
if(i==0){
  mon += obj[i].month ;
  dataVal += obj[i].value;
  dataVal1 += obj[i].value1;
   colo += obj[i].color;
   }
  else
  {
  mon += ", "+ obj[i].month;
  dataVal += ", "+ obj[i].value;
   dataVal1 += ", "+ obj[i].value1;
   colo += ', '+ obj[i].color;
 }
}
// loop  variable concatinate each  record  as an array
var monthVal = mon;
var dataValue =dataVal;
var dataValue1 =dataVal1;
var colors =colo;


// above mentioned  array variable  split by comma to plot the variable in lable and data in chart
var month =  monthVal.split(',');
var dataV=  dataVal.split(',');//alert(numberWithCommas(dataV));
//alert(dataV);
 
  var dis = Math.round(dataV);//alert(dis);
  var vad = addcomma(dis);//alert(vad);
//var dataV=addCommas(dataV);
var dataV1=  dataVal1.split(',');
var clr=  colors.split(',');
  var barChartCanvas = $('#barChart2').get(0).getContext('2d');
 

  var barChartData = {
    labels  :  month,
    datasets: [
      {
          label               : 'Kwh',
          backgroundColor     : '#67b7dc',
          borderColor         :  '#67b7dc',
          pointRadius          : false,
          pointColor          :  '#67b7dc',
          pointStrokeColor    :  '#67b7dc',
          pointHighlightFill  :  '#67b7dc',
          pointHighlightStroke:  '#67b7dc',
		  fillColor: "#67b7dc",
          data                : dataV
      },
      {
        label                 : 'Cost',
          backgroundColor     : '#fdd400',
          borderColor         :  '#fdd400',
          pointRadius         : false,
          pointColor          :  '#fdd400',
          pointStrokeColor    :  '#fdd400',
          pointHighlightFill  :  '#fdd400',
          pointHighlightStroke:  '#fdd400',
		  fillColor: "#fdd400",
          data                : dataV1
      }
    ]
  };
  
   
  
    var barChartOptions = {
	tooltips: {
        callbacks: {
            label: function(tooltipItem) {
			var dis = Math.round(tooltipItem.yLabel);
  var vad = includecomma(dis);
                return  vad;
            }
        }
    },
      responsive              : true,
      maintainAspectRatio     : true,
      datasetFill             : true,
	    scales: {
		yAxes: [{
              ticks:{
                  stepSize : 5000,

              }
			  }]
		}
	      };


    var barChart = new Chart(barChartCanvas, {
      type: 'bar', 
      data: barChartData,
      options: barChartOptions,
    });
	
	barChart.Bar(barChartData, barChartOptions);
	
</script>
 {/literal}

  {include file="footer.tpl"}