	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				{if $smarty.get.branchId}  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>{/if}
					<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">{if $smarty.get.sl_no eq ""}Create Gateway{else}Edit Gateway{/if}</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				</tr>
				</table>
			<a href="gatewayList.php?companyId={$smarty.get.companyId}&branchId={$smarty.get.branchId}"><button type="button" style="float:right;;margin-top:-40Px" class="btn btn-primary">List Gateway</button></a>
			</div>
		</div>
	<div class="card ">
		<div class="card-body">
			<form role="form" name="gatewayRegForm" id="gatewayRegForm" method="post" onsubmit="return createValidation();" >
				<input type="hidden" name="hdAction" />
				<input type="hidden" id="check_id" name="check_id" value="{$smarty.post.check_id}">
				<input type="hidden" id="checkVal" name="checkVal" value="{$smarty.post.checkVal}" />
				<input type="hidden" id="company_id" name="company_id" value="{$smarty.get.companyId}" />
				<input type="hidden" id="branch_id" name="branch_id" value="{$smarty.get.branchId}" />
				<input type="hidden" id="oldModel" name="oldModel" value="{$ListEditView.0.model}" />
				<input type="hidden" id="gateWayId" name="gateWayId" value="{$ListEditView.0.gateway_id}" />
				
				<div class="row ">
					<div class="form-group col-md-6">
					<label for="exampleInputmodel">Model <span style="color:red;">*</span></label>
						<select class="form-control form-control-sm" id="model" name="model" >
						{if $ListEditView.0.model eq ""}
							<option value="">-- Select Model --</option>
						{/if}
						{foreach from=$exeMod item=modList}
						{if $ListEditView.0.model eq $modList.model_code}
						<option value="{$ListEditView.0.model}" selected="selected">{$modList.model_name}</option>
						{/if}
						{if $ListEditView.0.model neq $modList.model_code}
							<option value="{$modList.model_code}">{$modList.model_name}</option>
						{/if}
						{/foreach}
						</select>
					</div>
					<div class="col-md-3">&nbsp;</div>
					<div class="col-md-3">&nbsp;</div>
						<div class="form-group col-md-6">
							<label for="exampleInputserialNo">Serial No <!--<span style="color:red;">*</span>--></label>
							<input type="text" class="form-control form-control-sm" id="serialNo" name="serialNo" placeholder="Enter Serial No" value="{if $ListEditView.0.serial_no neq ""}{$ListEditView.0.serial_no}{/if}"> <p style="color:red">* Example : Gateway Serial No *</p>
						</div>
					<div class="col-md-3">&nbsp;</div>
					<div class="col-md-3">&nbsp;</div>
					<div class="form-group col-md-6" style="margin-top:-20PX">
						<label for="exampleInputInstall">Place Of Installation <span style="color:red;">*</span></label>
						<input type="text" class="form-control form-control-sm" id="instPlace" name="instPlace" placeholder="Place Of Installation" value="{if $ListEditView.0.place_of_installation neq ""}{$ListEditView.0.place_of_installation}{/if}">
					</div>
				<div class="col-md-3">&nbsp;</div>
				<div class="col-md-3">&nbsp;</div>
					<div class="form-group col-md-6">
					<label for="exampleInputmodel">Internet Type <span style="color:red;">*</span></label>
						<select class="form-control form-control-sm" id="internet_type" name="internet_type" >
						{if $ListEditView.0.internet_type neq ""}
							<option value="{$ListEditView.0.internet_type}" >{$ListEditView.0.internet_type}</option>{else}
							<option value="">-- Select Internet Type --</option>
						{/if}
							<option value="4G">4G</option>
							<option value="Wifi">Wifi</option>
							<option value="Ethernet">Ethernet</option>
						</select>
					</div>
				<div class="col-md-3">&nbsp;</div>
				<div class="col-md-3">&nbsp;</div>
					<div class="form-group col-md-6">
						<label>Remarks<span style="color:red;">*</span></label>
						<textarea class="form-control form-control-sm" rows="3" name="description" id="description" placeholder="Mobile No/ Wifi Details /Ethernet Details" >{if $ListEditView.0.description neq ""}{$ListEditView.0.description}{/if}</textarea>
					</div>
				<div class="col-md-3">&nbsp;</div>
				<div class="col-md-3">&nbsp;</div>
					<div class="form-group col-md-6">
						<div class="custom-control custom-checkbox">
						{if $ListEditView.0.is_active eq '1' AND $ListAlertGatewayView.0.gateway_id eq $ListEditView.0.gateway_id}
							<input class="custom-control-input" type="checkbox" id="customCheckbox2"  name="customCheckbox2" tabindex="4" checked="checked" disabled>
							<label for="customCheckbox2" class="custom-control-label">Is Active</label>
						{elseif $ListEditView.0.is_active eq '0'}
							<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="4">
							<label for="customCheckbox2" class="custom-control-label">Is Active</label>
						{else}
							<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="4" checked="checked">
							<label for="customCheckbox2" class="custom-control-label">Is Active</label>
						{/if}
						</div>
						<input id="created_by" name="created_by" class="date-picker form-control" type="hidden" value="{$smarty.session.UserName}" readonly="true">
						<input type="hidden" class="form-control" id="timestamp" name="timestamp" value="{$smarty.now|date_format:'%Y-%m-%d &amp; %I:%M:%S %p'}">
						<input type="hidden" class="form-control" id="created_time" name="created_time" placeholder="Time" Value="{$smarty.now|date_format:'%I:%M:%S %p'}">
					</div>
				</div>
				<div class="col-md-6"align="center">
					<input type="submit" value="Submit" class="btn btn-create" />
				</div>
			</form>
		</div>
	</div>
	</div>
	</section>
	</div>
	{literal}
		<script type="text/javascript">
		function createValidation(){
		var model = $('#model').val();
		var instPlace = $('#instPlace').val();
		var internet_type = $('#internet_type').val();
		var description = $('#description').val();
		var isActive = document.getElementById("customCheckbox2").checked;
		if (isActive == false) 
		{
			document.getElementById('checkVal').value='0';
		}
		else
		{
			document.getElementById('checkVal').value='1';
		}
		$(".error").remove();
		if (model < 1) {
			$('#model').after('<span class="error">This field is required</span>');
			$('#model').focus();
			return false;					
		}
		else if (instPlace < 1) {
			$('#instPlace').after('<span class="error">This field is required</span>');
			$('#instPlace').focus();
			return false;					
		}
		else if (internet_type < 1) {
			$('#internet_type').after('<span class="error">This field is required</span>');
			$('#internet_type').focus();
			return false;					
		}
		else if (description < 1) {
			$('#description').after('<span class="error">This field is required</span>');
			$('#description').focus();
			return false;					
		}
			FormName		= document.gatewayRegForm;
			FormName.method	= "POST";
			FormName.submit();
		}
		function GoBack()
		{
			window.history.back();
		}
		</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	{/literal}
	{include file="footer.tpl"}