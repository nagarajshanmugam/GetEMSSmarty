	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
			<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				
			    <td style="font-size:15PX;font-weight: bold;">{if $GetModelName.0.model_name neq ""}{$GetModelName.0.model_name}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				
				{if $smarty.get.sl_no neq ""}
			<td style="font-size:15PX;font-weight: bold;">{$ListStRegisterEditView.0.parameter_name}&nbsp;&nbsp;</td>
		
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
			{/if}
			<td style="font-size:15PX;font-weight: bold;">Start Register Assign</font>&nbsp;</td></tr>
				<td style="color:#999999;font-size:10PX;"></td>
			     </tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:10PX;color:#999999;">Sensor Model Name</td>
				{if $smarty.get.sl_no neq ""}
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:10PX;color:#999999;">Parameter Name</td>
				{/if}
			
				</tr>
				</table>
			<a href="sensorModelParameterList.php?sen_model={$smarty.get.sen_model}"><button type="button" style="float:right;margin-top:-40Px" class="btn btn-primary">List Sensor Model Parameter</button></a>
			</div>
		</div>
		<div class="card">
		{if $SuccessMessage neq ""}
			<div class="card-body">
				<div class="isa_success">
				<i class="fa fa-check"></i>
				{$SuccessMessage}		 
				</div>
			</div>
		{/if}
		{if $ErrorMessage neq ""}
			<div class="card-body">
				<div class="isa_error">
				<i class="fa fa-check"></i>
				{$ErrorMessage}		 
				</div>
			</div>
		{/if} 
			<div class="card-body">
				<form role="form" name="startRegisterForm" id="startRegisterForm" method="post" onsubmit="return createValidation();" >
					<input type="hidden" name="hdAction" />
					<input type="hidden" id="company_id" name="company_id" value="{$smarty.get.companyId}" />
					<input type="hidden" id="check_id" name="check_id" value="{$smarty.post.check_id}">
					<input type="hidden" id="checkVal" name="checkVal" value="{$smarty.post.checkVal}" />
					<input type="hidden" id="mapPriority" name="mapPriority" value="{$ListStRegisterEditView.0.priority}" />

					
					<div class="row">					
						<div class="form-group col-md-6" style="margin-top:-5PX">
							<label for="exampleInputgatewayId">Parameter Name <span style="color:red;">*</span></label>
							<input type="hidden" id="parameter_id" name="parameter_id" value="{$ListStRegisterEditView.0.sl_no}" />
	<input type="text" class="form-control form-control-sm" id="parameterName" name="parameterName" placeholder="Enter Parameter Name" value="{$ListStRegisterEditView.0.parameter_name}" tabindex="2" readonly>
						</div>

						<div class="form-group col-md-6">
						<label for="exampleInputmodel">Formula Type<span style="color:red;">*</span></label>
						<select  id="formula_type" name="formula_type" class="form-control form-control-sm"  tabindex="7">
                        <option value="Single" {if $StRegisterMapEditView.0.formula_type eq '' OR $StRegisterMapEditView.0.formula_type eq 'Single'} selected {/if}>Single</option>
						<option value="Multiple" {if $StRegisterMapEditView.0.formula_type eq 'Multiple'} selected {/if}>Multiple</option>
						</select>
						</div>

						<div class="form-group col-md-6">
						<label for="exampleInputmodel">Start Register Assign <span style="color:red;">*</span></label>
						<select  id="start_register" name="start_register" class="form-control form-control-sm"  tabindex="7" onchange="GetDataLength(this.value);">
						<option value="0" >--- Select Start Register ----</option>
						{foreach from=$SensorSegmentList item=segmentT}
                        <option value="{$segmentT.segment_id}" {if $StRegisterMapEditView.0.segment_id eq $segmentT.segment_id || $smarty.post.start_register eq $segmentT.segment_id} selected{/if} >{$segmentT.start_register_value}</option>
						{/foreach}
                        
						</select>
						</div>
						
						
                        
                        <div class="form-group col-md-6">
						<div class="form-group" style="margin-top:-5PX">
							<label for="exampleInputgatewayId">Register Order <span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm" id="register_order" name="register_order" placeholder="Enter Register Order" value="{if $StRegisterMapEditView.0.register_order neq ''}{$StRegisterMapEditView.0.register_order}{else}0{/if}" onkeyup="numericFilter(this);">
						</div>

							<input id="created_by" name="created_by" class="date-picker form-control" type="hidden" value="{$smarty.session.UserName}" readonly="true">
							<input type="hidden" class="form-control" id="created_date_time" name="created_date_time" value="{$smarty.now|date_format:'%Y-%m-%d  %H:%M:%S'}">
							<input type="hidden" class="form-control" id="created_time" name="created_time" placeholder="Time" Value="{$smarty.now|date_format:'%I:%M:%S %p'}">
						</div>		
<div class="form-group col-md-6">
						<div class="form-group" style="margin-top:-5PX">
							<label for="exampleInputgatewayId">Multiplication Factor <span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm" id="m_factor" name="m_factor" placeholder="Enter Multiplication Factor eg : *1000 or +10" value="{if $StRegisterMapEditView.0.multiplication_factor neq ''}{$StRegisterMapEditView.0.multiplication_factor}{else}{$smarty.post.m_factor}{/if}">
						</div>		
						</div>	
						
					</div>
					<div align="center">
					<input type="submit" value="Submit" class="btn btn-create" />
					</div>
				</form>
			</div>
		</div>
	</div>
	</section>
	</div>
	{literal}
	<script type="text/javascript">
		function numericFilter(data)
		{
		data.value = data.value.replace(/[^.0-9^.+,-]/ig,"");
		}
		</script>
	<script type="text/javascript">
	function createValidation()
	{
		var parameterName = $('#parameterName').val();
		var start_register = $('#start_register').val();
		var register_order = $('#register_order').val();
		var m_factor = $('#m_factor').val();
	
	
		$(".error").remove();
	if (parameterName < 1) {
		$('#parameterName').after('<span class="error">This field is required</span>');
		$('#parameterName').focus();
		return false;					
	}
	else if (start_register == 0) {
		$('#start_register').after('<span class="error">This field is required</span>');
		$('#start_register').focus();
		return false;					
	}
	else if (register_order == '') {
		$('#register_order').after('<span class="error">This field is required</span>');
		$('#register_order').focus();
		return false;					
	}
	else if (m_factor == '') {
		$('#m_factor').after('<span class="error">This field is required</span>');
		$('#m_factor').focus();
		return false;					
	}
	
		FormName		= document.startRegisterForm;
		FormName.method	= "POST";
		FormName.submit();
	}
	
	function GoBack()
	{
		window.history.back();
	}
	
	function GetDataLength(cval)
	{
	var dataVal = cval;
	// Split the string by the | symbol
	var splitArray = dataVal.split('|');
	if(splitArray[1] != '' && splitArray[0] != 0){
	document.getElementById('parameterLength').value = splitArray[1];
	}else{
	document.getElementById('parameterLength').value = '';
	}
	
	}
	</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	{/literal}
	{include file="footer.tpl"}