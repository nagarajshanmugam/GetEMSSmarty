	<div class="content-wrapper">
		<section class="content-header">
			<div class="card">
				<div class="card-header">
					<table style="margin-bottom:-10px;">
					<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
					{if $smarty.get.branchId}  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>{/if}
					<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="font-size:15PX;font-weight: bold;">List User</font>&nbsp;</td>
					</tr>
					<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
					{if $smarty.get.branchId}  <td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="font-size:10PX;color:#999999;">Branch Name</td>{/if}
					<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
					</tr>
					</table>
				</div>
			</div>
			<div class="row">
				<div class="col-12">
					<div class="card">
					{if $SuccessMessage neq "" || $ErrorMessage neq ""}
						<div class="card-body">
						{if $SuccessMessage neq ""}
							<div class="isa_success">
							<i class="fa fa-check"></i>
							{$SuccessMessage}		 
							</div>
						{/if}
						{if $ErrorMessage neq ""}
							<div class="isa_error">
							<i class="fa fa-check"></i>
							{$ErrorMessage}		 
							</div>
						{/if}
						</div>
					{/if}
						<div class="card-body table-responsive">
							<form name="userList" id="userList" method="post">
							{if $ListuserCount.0.userCount < $ListuserCount.0.companyUserCount}
								<a href="AddEdituser.php?companyId={if $smarty.session.USER_GROUP neq 'Super Admin' && $smarty.get.companyId eq ''}{$smarty.session.CustomerId|base64_encode}{else}{$smarty.get.companyId}{/if}&branchId={$smarty.get.branchId}"><button type="button" style="float:right;margin-top:-6PX" class="btn btn-create">Create User</button></a><span style="float:right;">&ensp;</span>
							{else}
								<b style="color:#FF0000;float:right;margin-top:-6PX">User Limit Exceeded</b>
							{/if}
							{if $smarty.session.USER_GROUP eq 'Super Admin'} 
								<a href="companyList.php?companyId={$company_id}"><button type="button"  style="float:right;margin-top:-6PX" class="btn btn-primary">List Company</button></a> 
							{/if}
							
							<table id="example" class="table table-hover table-bordered">
								<thead>
								<tr>
								<th class="slno">#</th>
								<th>User Name</th>
								<th>User Group</th>
								<th>Mobile No</th>
								<th>Email Id</th>
								<th>Status</th>
								<th>Action</th>
								</tr>
								</thead>
								<tbody>
								{foreach from=$ListView item=master_dtls}
									<tr id="{$i++}">
									<td class="slno">{$i}</td>
									<td class="text_left">{$master_dtls.userName}</td>
									<td class="text_left">{$master_dtls.userGroup}</td>
									<td class="text_right">{$master_dtls.mobileNo}</td>
									<td class="text_left">{$master_dtls.emailId}</td>
									<td class="text_left status">{if $master_dtls.isActive eq "1"}<span style="color: #009900"><b>Active</b></span>{else}<span style="color: #FF0033;"><b>Inactive</b></span>{/if}</td>
									<td class="amount action"><a href="#" onclick="Javascript:editCats('{$master_dtls.slNo}','{$master_dtls.company_id}','{$smarty.get.branchId}')" title="Edit"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;
									<a href="#" onClick="Javascript:deleteCats('{$master_dtls.slNo}','{$master_dtls.company_id}')" title="Delete"><i class="fa fa-trash"></i></a></td>
									</tr>
								{foreachelse}
									<tr><td colspan="8"><center>No Records Found</center></td></tr>
								{/foreach}
								</tbody>
							</table>
							</form>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>
	{literal}
	<script type="text/javascript">
	$(document).ready(function (){
	
	var table = $('#example').DataTable({
	"ordering" : false,
	language: {
	"infoFiltered": "",
	search: "_INPUT_",
	searchPlaceholder: "Search..."
	},
	dom: '<"pull-left" f><bottom>p',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: '<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p',
	//dom: '<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p',
	buttons: [
	{
	text: 'Create Box',
	className: 'btn btn-create',
	titleAttr: 'Create Box',
	action: function ( e, dt, button, config ) {
	window.location = 'AddEditBox.php';
	}        
	}
	],
	initComplete: function(){
	$("div.toolbar").html('<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>');   
	}       
	}); 
	}); 
	
	function editCats(slNoIdent,compIdent,branIdent) {
	var sid = btoa(slNoIdent);var comId = btoa(compIdent);
	FormName		= document.userList;
	FormName.action ='AddEdituser.php?companyId='+comId+'&branchId='+branIdent+'&userId='+sid+'&Update=y';
	FormName.submit();
	}
	
	function deleteCats(CatIdent,compIdent){
	var sid = btoa(CatIdent);var comId = btoa(compIdent);
	if(confirm("Are you sure to Delete this Content?")){
	FormName		= document.userList;
	FormName.action= 'userList.php?companyId='+comId+'&userId='+sid;
	FormName.submit();
	}
	}
	</script>
	<script>
	$(function () {
	$("#example1").DataTable();
	$('#example2').DataTable({
	"paging": true,
	"lengthChange": false,
	"searching": false,
	"ordering": false,
	"info": false,
	"autoWidth": false,
	});
	});
	</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>
	{/literal}
	{include file="footer.tpl"}