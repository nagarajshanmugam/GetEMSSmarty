	<div class="content-wrapper">
	<section class="content-header">
	<div class="card">
				<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{if $smarty.get.groupName neq ""}<td style="font-size:15PX;font-weight: bold;">{$ListEditView.0.groupName}</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>{/if}
				<td style="font-size:15PX;font-weight: bold;">{if $smarty.get.groupName eq ""}Create Gateway Group{else}Edit Gateway Group{/if}</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:10PX;color:#999999;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{if $smarty.get.groupName neq ""}<td style="font-size:10PX;color:#999999;">Group Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>{/if}
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
				<a href="gatewayGroupList.php?companyId={$smarty.get.companyId}&branchId={$smarty.get.branchId}"><button type="button" style="float:right;margin-top:-40PX;" class="btn btn-primary">List Gateway Group</button></a>
			</div>
		</div>
	</section>
	<section class="content">
	<div class="card">
	
		<div class="card-body">
			<form role="form" name="locationRegForm" id="locationRegForm" method="post" onsubmit="return createValidation();" >
				<input type="hidden" name="hdAction" />
				<input type="hidden" id="companyId" name="companyId" value="{$smarty.get.companyId|base64_decode}">
				<input type="hidden" id="branchId" name="branchId" value="{$smarty.get.branchId|base64_decode}">
				<input type="hidden" id="check_id" name="check_id" value="{$smarty.post.check_id}">
				<input type="hidden" id="checkVal" name="checkVal" value="{$smarty.post.checkVal}" />
				<div class="row">
					<div class="form-group col-md-6">
					<label for="exampleInputlocationName">Group Name <span style="color:red;">*</span></label>
					<input type="text" class="form-control form-control-sm" id="groupName" name="groupName" placeholder="Enter Group name" autocomplete="Off" value="{if $ListEditView.0.groupName neq ""}{$ListEditView.0.groupName}{/if}">
					</div>
					<div class="form-group col-md-6">
						<div class="custom-control custom-checkbox">
						{if $ListEditView.0.isActive eq '1'}
							<input class="custom-control-input" type="checkbox" id="customCheckbox2"  name="customCheckbox2" tabindex="4" checked="checked">
							<label for="customCheckbox2" class="custom-control-label">Is Active</label>
						{elseif $ListEditView.0.isActive eq '0'}
							<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="4">
							<label for="customCheckbox2" class="custom-control-label">Is Active</label>
						{else}
							<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="4" checked="checked">
							<label for="customCheckbox2" class="custom-control-label">Is Active</label>
						{/if}
						</div>
						<input id="created_by" name="created_by" class="date-picker form-control" type="hidden" value="{$smarty.session.UserName}" readonly="true">
					</div>
				<div class="form-group col-md-5">
				<div class="form-group">
					<label>Gateway Name <span style="color:red;">*</span></label>
					<select multiple class="form-control" name="exam16[]" id="exam16" value="{$smarty.post.exam16}" autocomplete="Off" tabindex="4">
									{foreach from=$GetGatewayView item=ListDet}
										<option value="{$ListDet.sl_no}">{$ListDet.place_of_installation}</option>	
									{/foreach}
					</select>
				</div>
				</div>
				<div class="form-group col-md-2" align="center" >
						<br><br>
					<input type="button" class="btn btn-sm btn-create m-t-n-xs" name="add" value=">>" onClick="moveOptionLeftToRight(this.form.exam16,this.form.dexam16)" id="roleadd" autocomplete="Off" ><br><br>
					<input type="button" class="btn btn-sm btn-create m-t-n-xs" name="remove" value="<<" onClick="moveOptionRightToLeft(this.form.dexam16, this.form.exam16)" id="roleremove" autocomplete="Off" >
						</div>
					<div class="form-group col-md-5">
						<div class="form-group">
							<label>&nbsp;&nbsp;&nbsp;</label>
						{if $ListEditView.0.groupName neq ""}
							<select class="form-control" multiple="multiple" name="dexam16[]" id="dexam16" value="{$smarty.post.dexam16}" autocomplete="Off" tabindex="5">
						{foreach from=$ListEditView item=ListDet}
							<option value="{$ListDet.gatewayId}">{$ListDet.place_of_installation}</option>	
						{/foreach}
						{else}
							<select class="form-control" multiple="multiple" name="dexam16[]" id="dexam16" value="{$smarty.post.dexam16}" autocomplete="Off" tabindex="5">
						{/if}
						</div>
					</div>
					<div class="form-group col-md-5">
						<div class="form-group">
						<input type="hidden" value="" />
						</div>
					</div>
					<div class="form-group col-md-12" align="center">
						<input type="submit" value="Submit" class="btn btn-create" />
					</div>
					<div class="form-group col-md-5">
						<div class="form-group">
						<input type="hidden" value="" />
						</div>
					</div>
				</div>
			</form>
		</div>
	</div>
	</section>
	</div>
	{literal}
		<script type="text/javascript">
		function createValidation()
		{
			var locationId = $('#groupName').val();
			var locationName = $('#dexam16').val();
			var isActive = document.getElementById("customCheckbox2").checked;
		
		if (isActive == false) 
		{
			document.getElementById('checkVal').value='0';
		}
		else
		{
			document.getElementById('checkVal').value='1';
		}
			listbox_selectall('dexam16', true);
			$(".error").remove();
		if(locationId.length < 1) {
			$('#groupName').after('<span class="error">This field is required</span>');
			$('#groupName').focus();
			return false;					
		}
		else if(locationName.length < 1 && locationId.length > 1) 
		{		
			$('#dexam16').after('<span class="error">This field is required</span>');
			$('#dexam16').focus();
			return false;
		}	
			FormName		= document.locationRegForm;
			FormName.method	= "POST";
			FormName.submit();
		}
		function GoBack()
		{
			window.history.back();
		}
		</script>
	<script type="text/javascript">
	//*************************************swapping start*********************************************//
	function moveOptionLeftToRight(objSourceElement,objTargetElement)
	{ 
		var aryTempSourceOptions = new Array();
		var x = 0;
	for (var i = 0; i < objSourceElement.length; i++){
	if (objSourceElement.options[i].selected){
	if(objTargetElement.options.length > 0 && objTargetElement.options[0].text == 'None'){
		objTargetElement.options.length = 0;		
	}
		var intTargetLen = objTargetElement.length++;
	if((objSourceElement.options[i].text=="Other")&&(objSourceElement.name=="exam16[]"))
	{
		statuschng1('specdosh',objSourceElement.name,objSourceElement.options[i].value)
	}
		objTargetElement.options[intTargetLen].text = objSourceElement.options[i].text;
		objTargetElement.options[intTargetLen].value = objSourceElement.options[i].value;
	}else{			
		var objTempValues = new Object();
		objTempValues.text = objSourceElement.options[i].text;
		objTempValues.value = objSourceElement.options[i].value;
		aryTempSourceOptions[x] = objTempValues;
		x++;
	}
	}
		objSourceElement.length = aryTempSourceOptions.length;	
	for (var i = 0; i < aryTempSourceOptions.length; i++) {
		objSourceElement.options[i].text = aryTempSourceOptions[i].text;
		objSourceElement.options[i].value = aryTempSourceOptions[i].value;
		objSourceElement.options[i].selected = false;
	}
		listbox_selectall('dexam16', true);
	}
	function moveOptionRightToLeft(objSourceElement, objTargetElement){
		var aryTempSourceOptions = new Array();
		var x = 0;
	if(objSourceElement.options.length > 0 && objSourceElement.options[0].text == 'None'){
		return false;
	}
	for (var i = 0; i < objSourceElement.length; i++){
	if (objSourceElement.options[i].selected){
		var intTargetLen = objTargetElement.length++;
		objTargetElement.options[intTargetLen].text = objSourceElement.options[i].text;
		objTargetElement.options[intTargetLen].value = objSourceElement.options[i].value;
	}else{			
		var objTempValues = new Object();
		objTempValues.text = objSourceElement.options[i].text;
		objTempValues.value = objSourceElement.options[i].value;
		aryTempSourceOptions[x] = objTempValues;
		x++;
	}
	}
		objSourceElement.length = aryTempSourceOptions.length;	
	for (var i = 0; i < aryTempSourceOptions.length; i++){
		objSourceElement.options[i].text = aryTempSourceOptions[i].text;
		objSourceElement.options[i].value = aryTempSourceOptions[i].value;
		objSourceElement.options[i].selected = false;
	}
	if(objSourceElement.options.length == 0){
		objSourceElement.options.length = 1;
		objSourceElement.options[0].text = 'None';
		objSourceElement.options[0].selected = false;
	}
		listbox_selectall('dexam16', true);
	}
	$(document).on("click", ".fa-edit", function () {
		var roleId = $(this).data('id');
		$(".modal-body #hdnGroupId").val(roleId);
	});
	function listbox_selectall(listID, isSelect) {
		var listbox = document.getElementById(listID);
	for(var count=0; count < listbox.options.length; count++) {
		listbox.options[count].selected = isSelect;
	}
	}
	</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	{/literal}
	{include file="footer.tpl"}