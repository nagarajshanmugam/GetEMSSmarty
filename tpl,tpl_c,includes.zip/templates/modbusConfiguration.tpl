	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">{if $smarty.get.sl_no eq ""}Modbus Configuration{else}Edit Sensor Model{/if}</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			<a href="sensorModelList.php"><button type="button" style="float:right;margin-top:-40Px" class="btn btn-primary">List Sensor Model</button></a>
			</div>
		</div>
		<div class="card">
			<div class="card-body">
				<form role="form" name="sensorModelForm" id="sensorModelForm" method="post" onsubmit="return createValidation();" >
					<input type="hidden" name="hdAction" />
					<input type="hidden" id="company_id" name="company_id" value="{$smarty.get.companyId}" />
					<input type="hidden" id="check_id" name="check_id" value="{$smarty.post.check_id}">
					<input type="hidden" id="checkVal" name="checkVal" value="{$smarty.post.checkVal}" />
					<input type="hidden" id="platForm" name="platForm" value="{$ListEditView.0.platform_id}" />
					<input type="hidden" id="sModel" name="sModel" value="{$smarty.get.sl_no|base64_decode}" />
					<input type="hidden" id="stReg" name="stReg" value="" />
					
					<div class="row">
						<div class="form-group col-md-6">
						<label for="exampleInputmodel">Sensor Model <span style="color:red;">*</span></label>
						<select  id="sensorModel" name="sensorModel" class="form-control form-control-sm"  tabindex="7">
						<option value=""> -- Select Sensor Model -- </option>
						{foreach from=$SenModelList item=sml}
						<option value="{$sml.sl_no}">{$sml.model_id}</option>
                        {/foreach}
						</select>
						</div>
						<div class="form-group col-md-6" id="sCounts">
							<label for="exampleInputgatewayId">Segment Count <span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm" id="segCount" name="segCount" placeholder="Enter Segment Count" tabindex="9" onchange="generateTextBoxes(this.value);" maxlength=2 onkeyup="numericFilter(this);" value="{if $ListEditView.0.segment_count neq ""}{$ListEditView.0.segment_count}{/if}">
						</div>
						<div id="startRegisterBoxContainer"></div>
						<div id="startRegisterArrayCountContainer"></div>
					
						<div class="form-group col-md-6" style="display:block;" id="sRegDiv">
						{foreach from=$ListSensorSegment item=seg}
							<label for="exampleInputgatewayId">Start Register {$seg.priority+1} <span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm" id="startReg" name="startReg" placeholder="Enter Start Register" tabindex="9" onchange="generateTextBoxes(this.value);" maxlength=2 onkeyup="numericFilter(this);" value="{if $ListSensorSegment.0.start_register_value neq ""}{$seg.start_register_value}{/if}" readonly>
							{/foreach}

							<input id="created_by" name="created_by" class="date-picker form-control" type="hidden" value="{$smarty.session.UserName}" readonly="true">
							<input type="hidden" class="form-control" id="created_date_time" name="created_date_time" value="{$smarty.now|date_format:'%Y-%m-%d  %H:%M:%S'}">
							<input type="hidden" class="form-control" id="created_time" name="created_time" placeholder="Time" Value="{$smarty.now|date_format:'%I:%M:%S %p'}">
						</div>					
						
					</div>
					<div align="center">
					<input type="submit" value="Submit" onclick="createValidation()"; class="btn btn-create" />
					</div>
				</form>
			</div>
		</div>
	</div>
	</section>
	</div>
	{literal}
	<script type="text/javascript">
		function numericFilter(data)
		{
		data.value = data.value.replace(/[^.0-9^.+,-]/ig,"");
		}
		</script>
		
	<script>
	// A $( document ).ready() block.
$(document).ready(function() {
    generateTextBoxes();
	/*var platFormVal = $('#platform').val();
	if(platFormVal == '1')
	{
	document.getElementById('mkwh').style.display="block";
	document.getElementById('sCount').style.display="block";
	}
	else
	{
	document.getElementById('mkwh').style.display="none";
	document.getElementById('sCount').style.display="none";
	}*/
	//document.getElementById('startRegisterBoxContainer').style.display="none";


});
</script>
	<script type="text/javascript">
        function generateTextBoxes() {
            // Get the number of text boxes to generate
            var numTextBoxes = document.getElementById('segCount').value;
            var container = document.getElementById('startRegisterBoxContainer');
			var arrayContainer = document.getElementById('startRegisterArrayCountContainer');
			

            // Clear existing text boxes
            container.innerHTML = '';
			 // Clear existing text boxes
			arrayContainer.innerHTML = '';

            // Generate new text boxes
            for (var i = 0; i < numTextBoxes; i++) {
                var label = document.createElement('label');
                label.htmlFor = 'startRegister_' + i;
                label.innerHTML = 'Start Register ' + (i + 1) + ': ';

				var arrayLabel = document.createElement('arrayLabel');
                arrayLabel.htmlFor = 'arrayCount' + i;
                arrayLabel.innerHTML = 'Array Count ' + (i + 1) + ': ';

                var input = document.createElement('input');
                input.type = 'text';
                input.id = 'startRegister_' + i;
                input.name = 'startRegister_' + i;

				var arrayInput = document.createElement('input');
                arrayInput.type = 'text';
                arrayInput.id = 'arrayCount_' + i;
                arrayInput.name = 'arrayCount_' + i;
				

                container.appendChild(label);
                container.appendChild(input);
                container.appendChild(document.createElement('br'));

				arrayContainer.appendChild(arrayLabel);
                arrayContainer.appendChild(arrayInput);
                arrayContainer.appendChild(document.createElement('br'));
            }
        }
    </script>
	<script type="text/javascript">
	function createValidation()
	{
		var sensorModel = $('#sensorModel').val();
		var segCount = $('#segCount').val();
		var startRegister = $('#startRegister').val();
		var sModel = $('#sModel').val();
		var container = document.getElementById('startRegisterBoxContainer');
		var arrayContainer = document.getElementById('startRegisterArrayCountContainer');
        var inputs = container.getElementsByTagName('input');
		var arrayInputs = arrayContainer.getElementsByTagName('input');
            
         
		$(".error").remove();
	if (sensorModel == '') {
		$('#sensorModel').after('<span class="error">This field is required</span>');
		$('#sensorModel').focus();
		return false;					
	}else if(segCount == '') {
		$('#segCount').after('<span class="error">This field is required</span>');
		$('#segCount').focus();
		return false;
	}
		
		

		 // Get the number of text boxes to generate
            var numTextBoxes = document.getElementById('segCount').value;
            var container = document.getElementById('startRegisterBoxContainer');
			var arrayContainer = document.getElementById('startRegisterArrayCountContainer');
   
            // Clear existing text boxes
            //container.innerHTML = '';

            // Generate new text boxes
            for (var i = 0; i < numTextBoxes; i++) {
				
                var label = document.createElement('label');
                label.htmlFor = 'startRegister_' + i;
                label.innerHTML = 'Start Register ' + (i + 1) + ': ';

                var input = document.createElement('input');
                input.type = 'text';
                input.id = 'startRegister_' + i;
                input.name = 'startRegister_' + i;
				//input.value = 'startRegister_' + i;

				var arrayLabel = document.createElement('arrayLabel');
                arrayLabel.htmlFor = 'arrayCount' + i;
                arrayLabel.innerHTML = 'Array Count ' + (i + 1) + ': ';

                var arrayInput = document.createElement('input');
                arrayInput.type = 'text';
                arrayInput.id = 'arrayCount_' + i;
                arrayInput.name = 'arrayCount_' + i;
				//arrayInput.value = 'arrayCount_' + i;
				
				//if(input.value == ''){
				
				   for (var i = 0; i <= numTextBoxes; i++) {
                if (inputs[i].value === '') {
                    alert("Enter Start Register Values in all text boxes");
                    //inputs[i].style.display = "block";  // Ensure the input is visible
                    //inputs[i].focus();  // Focus the empty input
                    return false;
                }
				if (arrayInputs[i].value === '') {
                    alert("Enter Array Count Values in all text boxes");
                    //arrayInputs[i].style.display = "block";  // Ensure the input is visible
                    //arrayInputs[i].focus();  // Focus the empty input
                    return false;
                }

				 if (isNaN(parseFloat(inputs[i].value))) {
				   alert("Only integers are allowed!");
                    inputs[i].value = inputs[i].value.replace(/[^.0-9^.+,-]/ig,"");
                    return false;
                }

				if (isNaN(parseFloat(arrayInputs[i].value))) {
				   alert("Only integers are allowed!");
				   arrayInputs[i].value = arrayInputs[i].value.replace(/[^.0-9^.+,-]/ig,"");
                    return false;
                }
				
				
				 // If all inputs have values, submit the form or perform your desired action
            //alert("All inputs are filled!");
            //return true;
			// Clear existing text boxes
            //container.innerHTML = '';
            }

           

				//}

                container.appendChild(label);
                container.appendChild(input);
                container.appendChild(document.createElement('br'));

				arrayContainer.appendChild(arrayLabel);
                arrayContainer.appendChild(arrayInput);
                arrayContainer.appendChild(document.createElement('br'));
            }
				
	
	
		FormName		= document.sensorModelForm;
		FormName.method	= "POST";
		FormName.submit();
	}
	
	function GoBack()
	{
		window.history.back();
	}
	
	</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	{/literal}
	{include file="footer.tpl"}