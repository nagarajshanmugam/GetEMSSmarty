	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">List Sensor Model</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			</div>
		</div>
		<form name="sensorModelList" method="post" id="sensorModelList">
		<div class="row">
			<div class="col-12">
				<div class="card">
				{if $SuccessMessage neq "" || $ErrorMessage neq ""}
					<div class="card-body">
					{if $SuccessMessage neq ""}
						<div class="isa_success">
						<i class="fa fa-check"></i>
						{$SuccessMessage}		 
						</div>
					{/if}
					{if $ErrorMessage neq ""}
						<div class="isa_error">
						<i class="fa fa-check"></i>
						{$ErrorMessage}		 
						</div>
					{/if}
					</div>
				{/if}
					<div class="card-body table-responsive">
					<a href="sensorModelAddEdit.php"><button type="button" style="float:right;margin-top:-6PX" class="btn btn-create">Create Sensor Model</button></a><span style="float:right">&ensp;</span>
					 {if $GetModel.0.model_name eq ""}<br><br />{/if}
						<table id="example" class="table table-bordered table-hover">
						<thead>
						<tr>
						<th class="slNo">#</th>
						<th class="code">Model Code</th>
						<th class="name">Model Name</th>
						<th class="commType">Comm Type</th>
						<th class="url">Api Url</th>
						<th class="isactive">Status</th>
						<th class="action">Action</th>
						</tr>
						</thead>
						<tbody>
						
						{foreach from=$GetModel item=List}
							
						<tr id="{$j++}">
						<td >{$j}</td>
						<td>{$List.model_id}</td>
						<td>{$List.model_name}</td>
						<td>{$List.communication_type}</td>
						<td>{$List.api_url}</td>
						<td align="center">{if $List.is_active eq "1"}<span style="color:#00A520"><b>Active</b></span>{else}<span style="color:#FF0000;"><b>Inactive</b></span>{/if}</td>
						<td align="right">
						<a href="#"  onClick="Javascript:mappingCats('{$List.sl_no}','{$List.model_id}','Update=Y')" title="Parameter Mapping"><i class="fa fa-map-signs"></i></a>&nbsp;&nbsp;
						{foreach from=$IconList item=icon}
						{if $icon.menuName eq "Parameter List"}
						
							<a href="#"  onClick="Javascript:parameterListCats('{$List.sl_no}','{$List.model_id}','Update=Y')" title="Parameter List">
							<span style="color:#218713"><b><i class="{$icon.faIcon}"></i></b></span>
						</a>&nbsp;&nbsp;
							
					    {/if}
						{if $icon.menuName eq "Edit Sensor"}<a href="#"  onClick="Javascript:editCats('{$List.sl_no}','{$List.model_id}','Update=Y')" title="Edit"><i class="{$icon.faIcon}"></i></a>&nbsp;&nbsp;{/if}
						{if $icon.menuName eq "Delete Sensor"}<a href="#"  onClick="Javascript:deleteCats('{$List.sl_no}')" title="Delete"><i class="fa fa-trash"></i></a>{/if}
						{/foreach}
						</td>
						</tr>
						{foreachelse}
						<tr><td colspan="6"><center>No Records Found</center></td></tr>
						{/foreach}
							
						</tbody>
						</table>
					</div>
				</div>
			</div>
		</form>
	</section>
	</div>
	{literal}
	<style>
	.slNo{
	width:5%;
	}
	.code{
	width:10%;
	}
	.commType{
	width:10%;
	}
	.name{
	width:15%;
	}
	.url{
	width:25%;
	}
	.isactive{
	width:10%;
	text-align:center;
	
	}
	.action{
	
	width:25%;
	text-align:right;
	}
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>
	<script type="text/javascript">
	$(document).ready(function (){
	
	var table = $('#example').DataTable({
	"ordering" : false,
	language: {
	"infoFiltered": "",
	search: "_INPUT_",
	searchPlaceholder: "Search..."
	},
	dom: '<"pull-left" f><bottom>p',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: '<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p',
	//dom: '<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p',
	
	initComplete: function(){
	//$("div.toolbar").html('<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>');   	
	}       
	}); 
	}); 
	
	function unitPriceCats(slNoIdent,metIdIdent,compIdent,locIdIdent) 
	{
		var sid = btoa(slNoIdent); var mid = btoa(metIdIdent); var comId = btoa(compIdent); var lId = btoa(locIdIdent);
		FormName		= document.sensorModelList;
		FormName.action ='unitPriceList.php?sl_no='+sid+'&companyId='+comId+'&location_id='+lId+'&meter_id='+mid;
		FormName.submit();
	}
	
	function parameterListCats(slNoIdent,metIdIdent,compIdent) 
	{
		var sid = btoa(slNoIdent); var mid = btoa(metIdIdent);  var comId = btoa(compIdent); 
		FormName		= document.sensorModelList;
		FormName.action ='sensorModelParameterList.php?sen_model='+sid+'&Update=y';
		FormName.submit();
	}
	function editCats(slNoIdent,metIdIdent,compIdent) 
	{
		var sid = btoa(slNoIdent); var mid = btoa(metIdIdent);  var comId = btoa(compIdent); 
		FormName		= document.sensorModelList;
		FormName.action ='sensorModelAddEdit.php?sl_no='+sid+'&Update=y';
		FormName.submit();
	}
	function mappingCats(slNoIdent,metIdIdent,compIdent) 
	{
		var sid = btoa(slNoIdent); var mid = btoa(metIdIdent);  var comId = btoa(compIdent); 
		FormName		= document.sensorModelList;
		FormName.action ='sensorModelParMapp.php?sl_no='+sid;
		FormName.submit();
	}
	</script>
	<script type="text/javascript">
	function deleteCats(slNoIdent)
	{
		var sid = btoa(slNoIdent);
		if(confirm("Are you sure to Delete Sensor Model?")){
		FormName		= document.sensorModelList;
		FormName.action= 'sensorModelList.php?slNo='+sid+'&delete=del';
		FormName.submit();
		}
	}
	</script>
	{/literal}
	{include file="footer.tpl"}