{literal}
<script type="text/javascript">
    function includecomma1old(c,v)
{
var x=Math.round(c);
x=x.toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != '')
lastThree = ',' + lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
//var res = res.toFixed(4);
//var res =number_format(res, 2);
var res = res+'.00';
document.getElementById(v).innerHTML=res;
}
</script>

{/literal}
	<div class="content-wrapper">
		<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">Dashboard</font>&nbsp;</td>
				 </tr>			
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			</div>
		</div>
            <textarea id="mutiLinegraph" name="mutiLinegraph" style="display:none;" >{$multiLineGraphsCost}</textarea>
<textarea id="mutiLinedataProvider" name="mutiLinedataProvider"  style="display:none;"  >{$multiLineDataProviderCost}</textarea>
			<div class="row">
				<div class="col-md-8">
			
					<div class="card card-primary card-outline">
						<div class="card-header">
						<h3 class="card-title">
						<i class="far fa-chart-bar"></i>
						Cost Chart
						</h3>
						
						</div>
					<div id="linechartdiv" style="height: 260px;"></div><br />
					</div>
				</div>
			
				<!--<div class="col-md-6">
					<div class="card card-primary card-outline">
						<div class="card-header">
						<h3 class="card-title">
						</h3>
						</div>
					<br />
					<br/>
					<br/>
					<br/>
					</div>
				</div>-->
			
			<div class="col-md-4">
			<div class="card card-primary card-outline">
			<div class="card-header">
			<h3 class="card-title">Recent Incidents</h3>
			</div>
			<div class="card-body p-0">
			<ul class="products-list product-list-in-card pl-2 pr-2">
			{foreach from=$incidentList item=ListIncidentLog}
			{assign var="alertMsg0" value=$ListIncidentLog.alert_message|replace:'Hi!':''}
			{assign var="alertMsg1" value=$alertMsg0|replace:'Best regards,':''}
			{assign var="alertMsg" value=$alertMsg1|replace:'Arka Automaations Limited.':''}
			{assign var="alertBreak" value=","|explode:$alertMsg}
			{assign var="l" value=0}
			<li class="item">
			<div class="product-img">
			<a href="javascript:void(0)" class="product-title">{$ListIncidentLog.sensor_code} - ( {$ListIncidentLog.recorded_date_time|date_format:"%e-%b-%Y %I:%M %p"} )</a>
			{if $ListIncidentLog.alert_status eq "Low"}<span class="badge badge-warning"  style="float:right;">{$ListIncidentLog.alert_status}</span>{elseif $ListIncidentLog.alert_status eq "Normal"}<span class="badge badge-info"  style="float:right;">{$ListIncidentLog.alert_status}</span>{elseif $ListIncidentLog.alert_status eq "Normal"}<span class="badge badge-danger"  style="float:right;">{$ListIncidentLog.alert_status}</span>{/if}
			<span class="product-description" style="font-size:12px">
			{section name=i loop=$alertBreak}
			{assign var="l" value=$l+1}
			{$alertBreak[i]|escape},{if $l eq '1'}<br />{/if}
			{/section}
			</span>
			</div>
			</li>
			{/foreach}
			</ul>
			</div>
			<div class="card-footer text-center">
			<a href="listIncidentLog.php" class="uppercase">View All Incidents</a>
			</div>
			</div>
			</div>
			</div>
			
            <!--command by shanmugakani (changed as list)-->
	<!--	<div class="row">
		<div class="col-md-12">
		<div class="card">
		<div class="card-body row">
		{foreach from=$branchList item=ListBranch}
		<div class="col-md-3">
		<div class="card card-widget widget-user">
		<a href="dashboard.php?companyId={$ListBranch.company_id|base64_encode}&branchId={$ListBranch.sl_no|base64_encode}"><div class="widget-user-header bg-info">
		<h3 class="widget-user-username">
		</h3>
		<h5 class="widget-user-desc">{$ListBranch.branch_name}</h5>
		</div></a>
		<a href="dashboard.php?companyId={$ListBranch.company_id|base64_encode}&branchId={$ListBranch.sl_no|base64_encode}"><div class="widget-user-image">
		<img class="img-circle elevation-2" src="images/meterImage.png" alt="User Avatar">
		</div></a>
		<div class="card-footer">
		<div class="row">
		<div class="col-sm-6 border-right">
		<div class="description-block">
		<h5 class="description-header">&#8377;{foreach from=$currMonthCostKWH item=List}
		{if $List.branch_id eq $ListBranch.sl_no}  {$List.cost}{/if}
		{/foreach}</h5>
		<span class="description-text">This Month Cost</span>
		</div>
		</div>
		<div class="col-sm-6 ">
		<div class="description-block">
		<h5 class="description-header">&#8377; {foreach from=$lastMonthCostKWH item=List}
		{if $List.branch_id eq $ListBranch.sl_no}  {$List.cost}{/if}
		{/foreach}</h5>
		<span class="description-text">Last Month Cost</span>
		</div>
		</div>
		</div>
		</div>
		</div>
		</div> 
        {/foreach} 
		</div>
		</div>
		</div>
		</div>-->
          <!--command by shanmugakani (changed as list)-->
          <form name="location_list" method="post" id="location_list">
          <div class="row">
		<div class="col-md-12">
		<div class="card card-primary card-outline">
        <div class="card-header">
						<h3 class="card-title">
						<i class="fa fa-list"></i>
						List of Branch
						</h3>
						 <a href="branchAddEdit.php?companyId={$smarty.session.COMPANY_ID}" ><button type="button" style="float:right;margin-top:-6PX" class="btn btn-create">Create Branch</button></a>
						</div>
		<div class="card-body table-responsive no-padding">
		   
        <table id="example" class="table table-bordered table-hover">
								<thead>
								<tr>
								<th class="slNo" rowspan="2">#</th>
								<th class="name" rowspan="2">Branch Name</th>
                                 <th  colspan="2" class="code" >This Month</th>
                                 <th  colspan="2" class="code" >Last Month</th>
								<th class="isactive" rowspan="2">Status</th>
								<th class="action" rowspan="2">Action</th>
								</tr>
                                 <tr>
    			 
                  <th class="cost" >KWH</th>
                  <th class="cost" >Cost</th>
                  <th class="cost" >KWH</th>
                  <th class="cost" >Cost</th>
                  
                </tr>
						</thead>
						<tbody>
						{foreach from=$ListView item=List}
						<tr id="{$j++}">
						<td >{$j}</td>
						<td >{$List.branch_name}</td>
						{foreach from=$currMonthCostKWH item=ListC}
						{if $ListC.branch_id eq $List.sl_no} 
						<td align="right" id="{$j}ck"><script type="text/javascript">includecomma1('{$ListC.TOTAL_KWH|default:"0.00"}','{$j}ck');</script></td>
						<td align="right" id="{$j}cc"><script type="text/javascript">includecomma1('{$ListC.cost|default:"0.00"}','{$j}cc');</script></td>
						{else}
						<td align="right" id="{$j}ck">0.00</td>
						<td align="right" id="{$j}cc">0.00</td>
						{/if}
						{foreachelse}
						<td align="right">0.00</td>
						<td align="right">0.00</td>
						{/foreach}

						
						{foreach from=$lastMonthCostKWH item=ListL}
						{if $ListL.branch_id eq $List.sl_no} 
						<td align="right" id="{$j}lk"><script type="text/javascript">includecomma1('{$ListL.TOTAL_KWH|default:"0.00"}','{$j}lk');</script></td>
						<td align="right" id="{$j}lc"><script type="text/javascript">includecomma1('{$ListL.cost|default:"0.00"}','{$j}lc');</script></td>
						{else}
						<td align="right" id="{$j}lk">0.00</td>
						<td align="right" id="{$j}lc">0.00</td>
						{/if}
						{foreachelse}
						<td align="right">0.00</td>
						<td align="right">0.00</td>
						{/foreach}
						
						<td align="center">{if $List.is_active eq "1"}<span style="color:#00A520"><b>Active</b></span>{else}<span style="color:#FF0000;"><b>Inactive</b></span>{/if}</td>
						<td align="right">
						{foreach from=$platformView item=dashName}
						{if $dashName.segmentName eq "Energy Meter" && $dashName.branch_id eq $List.sl_no}
							<a href="dashboard.php?companyId={if  $smarty.get.companyId neq ""}{$smarty.get.companyId}{else}{$smarty.session.CustomerId|base64_encode}{/if}&branchId={$List.sl_no|base64_encode}"  title="Visit {$List.branch_name} Energy Dashboard" target="_blank"><i class="fa fa-desktop"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
						{/if}
						{if $dashName.segmentName eq "Temperature" && $dashName.branch_id eq $List.sl_no}
							<a href="temperature_temperatureDashboard.php?companyId={$smarty.get.companyId}&branchId={$List.sl_no|base64_encode}"  title="Visit {$List.branch_name} Temperature Dashboard" target="_blank"><i class="fa fa-thermometer-half"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
						{/if}
						{/foreach}
						{if $smarty.session.USER_GROUP eq "Super Admin" || $smarty.session.USER_GROUP eq "Company Admin"} 
							<a href="shiftList.php?companyId={$smarty.get.companyId}&branchId={$List.sl_no|base64_encode}"  title="List Shift"><i class="fa fa-list"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
						{/if}
						{if $smarty.session.USER_GROUP eq "Super Admin"}	
								<a href="platformList.php?companyId={if  $smarty.get.companyId neq ""}{$smarty.get.companyId}{else}{$smarty.session.CustomerId|base64_encode}{/if}&branchId={$List.sl_no|base64_encode}" title="List IoT Platform"><i class="fa fa-spinner"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;                                {/if}
							<a href="userList.php?companyId={if  $smarty.get.companyId neq ""}{$smarty.get.companyId}{else}{$smarty.session.CustomerId|base64_encode}{/if}&branchId={$List.sl_no|base64_encode}"  title="List User"><i class="fa fa-user"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
							<a href="contactMasterList.php?companyId={if  $smarty.get.companyId neq ""}{$smarty.get.companyId}{else}{$smarty.session.CustomerId|base64_encode}{/if}&branchId={$List.sl_no|base64_encode}" title="List Alert Contact"><i class="fa fa-bell"></i></a>
						{if $smarty.session.billing_module eq '1'} 
							&nbsp;&nbsp;&nbsp;&nbsp;
							<a href="listBilling.php?companyId={if  $smarty.get.companyId neq ""}{$smarty.get.companyId}{else}{$smarty.session.CustomerId|base64_encode}{/if}&branchId={$List.sl_no|base64_encode}" title="List Billing"><i class="fas fa-file-invoice"></i></a>
						{/if}
					
						{if $smarty.session.USER_GROUP eq "Super Admin" || $smarty.session.USER_GROUP eq "Company Admin"} 
							&nbsp;&nbsp;&nbsp;&nbsp;
							<a href="#"  onClick="Javascript:listGatewayGroup('{$List.company_id}','{$List.sl_no}')" title="Gateway Mapping"><i class="fa fa-podcast"></i></a>
						{/if}
							
						{if $smarty.session.USER_GROUP neq "Super Admin" && $smarty.session.USER_GROUP neq "Company Admin"}	 
						&nbsp;&nbsp;&nbsp;&nbsp;
							<a href="feederList.php?companyId={$smarty.get.companyId}&branchId={$List.sl_no|base64_encode}" title="List Feeder"><i class="fa fa-lightbulb"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
						{/if}
						{foreach from=$IconList item=icon}								
						{if $icon.menuName eq "List Gateway"}
							&nbsp;&nbsp;
							<a href="#"  onClick="Javascript:gatewayCats('{$List.sl_no}','{$List.company_id}','{$List.branch_id}')" title="List Gateway" ><i class="{$icon.faIcon}"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
						{/if}
						{if $icon.menuName eq "Edit Branch"}
							<a href="#"  onClick="Javascript:editCats('{$List.sl_no}','{$List.company_id}','{$List.branch_id}','Update=Y')" title="Edit"><i class="{$icon.faIcon}"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
						{/if}
						{if $icon.menuName eq "Delete Branch" && $smarty.session.USER_GROUP eq "Super Admin"}
								<a href="#"  onClick="Javascript:deleteCats('{$List.sl_no}','{$List.company_id}','{$List.branch_id}')" title="Delete"><i class="{$icon.faIcon}"></i></a>
							{/if}
						{/foreach}&nbsp;&nbsp;&nbsp;&nbsp;
						</td>
						</tr>
						{foreachelse}
						<tr><td colspan="5"><center>No Records Found</center></td></tr>
						{/foreach}
						</tbody>
					</table>
                            </div>
                            </div>
                            </div>
                            </div>
                            </form>
                            
		
		</section>
	
	<!-- /.content -->
	</div>
	{literal}

<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>-->
<script src="./amcharts/amcharts.js"></script>
<script src="./amcharts/serial.js"></script>
<script src="./amcharts/plugins/export/export.min.js"></script>
<script src="./amcharts/themes/light.js"></script>
<!-- Resources -->
<script src="./amChart/amchart.js"></script>
<script src="./amChart/amchartPieChart.js"></script>
<!--<script src="https://www.amcharts.com/lib/3/plugins/export/export.js"></script>-->
<script src="./amChart/amchartLight.js"></script>
<script src="./amChart/amchartColumnChart.js"></script>
<link rel="stylesheet" href="./amcharts/plugins/export/export.css" type="text/css" media="all" />	<style>
	#linechartdiv {
	width	: 100%;
	height	: 400px;
	}	
	.name
	{
	    width:15%;
	}
	.slNo
	{
	     width:3%;
	}
	.code
	{
	     width:10%;
	}
	.isactive
	{
	     width:5%;
	}
	.action 
	{
	     width:20%;
	}
	</style>
	
	<script>
//	alert("hai");

	//mutiLinedataProvider
	var dataProvider = document.getElementById('mutiLinedataProvider').value;
var Graphs = document.getElementById('mutiLinegraph').value;
//alert(Graphs);
var jsondataProvider = JSON.parse(dataProvider);
var jsondataGraph = JSON.parse(Graphs);
	//alert(jsondataGraph);
//	alert(dataProvider);alert(Graphs);
	var linechart = AmCharts.makeChart("linechartdiv", {
	"type": "serial",
	"theme": "light",
	"dataProvider": jsondataProvider,
	"valueAxes": [{
	"gridColor": "#FFFFFF",
	"gridAlpha": 0.2,
	"dashLength": 0
	}],
	"gridAboveGraphs": true,
	"startDuration": 0.3,
	"graphs":jsondataGraph,
	"fontSize": 14,
	"chartCursor": {
	"categoryBalloonEnabled": false,
	"cursorAlpha": 0,
	"zoomable": false
	},
	"categoryField": "month",
	"categoryAxis": {
	"gridPosition": "start",
	"gridAlpha": 0
	},
	"export": {
	"enabled": true // false- If don't need to dowload option 
	}
	});
	</script>
	<script type="text/javascript">
	     function gatewayCats(slNoIdent,compIdent,branchIdent) {
   var sid = btoa(slNoIdent);  var comId = btoa(compIdent); var bid = btoa(branchIdent);
   FormName		= document.location_list;
   FormName.action ='gatewayList.php?companyId='+comId+'&branchId='+sid;
   FormName.submit();
}

function editCats(slNoIdent,compIdent,locIdIdent) {
	var sid = btoa(slNoIdent); var comId = btoa(compIdent); var bid = btoa(locIdIdent);
	FormName		= document.location_list;
	FormName.action ='branchAddEdit.php?companyId='+comId+'&branch_id='+bid+'&sl_no='+sid+'&Update=y';
	FormName.submit();
	}
	function listGatewayGroup(compIdent,locIdIdent)
  {
    var comId = btoa(compIdent); var lid = btoa(locIdIdent);
   FormName		= document.location_list;
   FormName.action ='gatewayGroupList.php?companyId='+comId+'&branchId='+lid;
   FormName.submit();
  }
	function deleteCats(slNoIdent,compIdent,locIdIdent){
	var sid = btoa(slNoIdent); var comId = btoa(compIdent); var bid = btoa(locIdIdent);
	if(confirm("Are you sure to Delete this Content?")){
	FormName		= document.location_list;
	FormName.action= 'branchList.php?companyId='+compIdent+'&branch_id='+locIdIdent+'&sl_no='+slNoIdent;
	FormName.submit();
	}
	}

	</script>
	{/literal}
	{include file="footer.tpl"}