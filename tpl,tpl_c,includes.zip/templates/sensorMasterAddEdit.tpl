	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
		{if $SuccessMessage neq ""}
				<div class="card-body">
					<div class="isa_success">
					<i class="fa fa-check"></i>
					{$SuccessMessage}		 
					</div>
				</div>
			{/if}
			{if $ErrorMessage neq ""}
				<div class="card-body">
					<div class="isa_error">
					<i class="fa fa-check"></i>
					{$ErrorMessage}		 
					</div>
				</div>
			{/if}
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				{if $branchDetail.0.branch_name neq ''}
					<td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>{/if}
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">{if $smarty.get.sl_no eq ""}Create Sensor{else}Edit Sensor{/if}</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;">  </td><td>&nbsp;</td>
				</tr>
				</table>
			{if $smarty.get.sl_no eq ""} 
				<a href="sensorList.php?companyId={$smarty.get.companyId}&gatewayId={$smarty.get.gatewayId}&branchId={$smarty.get.branchId}"><button type="button" style="float:right;margin-top:-40PX" class="btn btn-primary">List Sensor</button></a>
			{else}
				<a href="sensorList.php?companyId={$smarty.get.companyId}&gatewayId={$smarty.get.gatewayId}&branchId={$smarty.get.branchId}"><button type="button" style="float:right;;margin-top:-40PX" class="btn btn-primary" onclick="locationDecode();">List Sensor</button></a>
			{/if}
			</div>
		</div>
		<div class="card">
			<div class="card-body">
				<form role="form" name="sensorRegForm" id="sensorRegForm" method="post" onsubmit="return createValidation();" >
					<input type="hidden" name="hdAction" />
					<input type="hidden" id="sl_no" name="sl_no" value="{$smarty.get.sl_no|base64_decode}" />
				{if $smarty.get.sl_no neq ""}
					<input type="hidden" id="gateway_id" name="gateway_id" value="{$ListEditView.0.gateway_id}" />
					<input type="hidden" id="branch_id" name="branch_id" value="{$ListEditView.0.branch_id}" />
					<input type="hidden" id="company_id" name="company_id" value="{$ListEditView.0.company_id}" />
					<input type="hidden" id="sensorId" name="sensorId" value="{$smarty.get.sensor_id}" />
				{else}
					<input type="hidden" id="gateway_id" name="gateway_id" value="{$smarty.get.gatewayId|base64_decode}" />
					<input type="hidden" id="company_id" name="company_id" value="{$smarty.get.companyId|base64_decode}" />
					<input type="hidden" id="branch_id" name="branch_id" value="{$smarty.get.branchId|base64_decode}" />
				{/if}
					<input type="hidden" id="check_id" name="check_id" value="{$smarty.post.check_id}">
					<input type="hidden" id="checkVal" name="checkVal" value="{$smarty.post.checkVal}" />
				<div class="row">
					<div class="form-group col-md-6">
						<label for="exampleInputmake">Platform<span style="color:red;">*</span></label>
					{if $ListEditView.0.slNo neq ""}
						<input type="text"  class="form-control" id="platform" name="platform" value="{$ListEditView.0.segmentName}" readonly>
						<input type="hidden"  class="form-control" id="platformCode" name="platformCode" value="{$ListEditView.0.segmentCode}" readonly>
					{else}
					<select class="form-control" id="platform" name="platform"  tabindex="1" >
						<option value="">--  Select Platform  --</option>
					{foreach from=$ListPlatform item=ListMod}
					
						<option value="{$ListMod.platformId}">{$ListMod.segmentName}</option>
				
					{/foreach}
					</select>
					{/if}
					</div>
				{if $ListEditView.0.slNo neq ""} 
				<div class="form-group col-md-6">
					<label for="exampleInputmodel">Api Key </label>
					<textarea class="form-control" id="apiKey" name="apiKey" placeholder="Api Key"  autocomplete="Off" style="height:50PX" readonly="readonly">{$ListEditView.0.api_key}</textarea>
				</div>
				{/if}
					<div class="form-group col-md-6">
						<label for="exampleInputmake">Sensor Model <span style="color:red;">*</span></label>
					{if $ListEditView.0.slNo neq ""}
						<input type="text"  class="form-control" id="model" name="model" value="{$ListEditView.0.sensorModel}" readonly>
					{else}
						<select class="form-control" id="model" name="model"  tabindex="1">
						{if $ListEditView.0.sensorModel eq ""}<option value="">--  Select Model  --</option>
						{/if}
						{foreach from=$GetModel item=ListMod}
						{if $ListEditView.0.sensorModel eq $ListMod.model_id}
						<option value="{$ListMod.model_id}" selected="selected">{$ListMod.model_name}</option>
						{/if}
						{if $ListEditView.0.sensorModel neq $ListMod.model_id}
						<option value="{$ListMod.model_id}">{$ListMod.model_name}</option>
						{/if}
						{/foreach}
						</select>
					{/if}
					</div>
				{if $ListEditView.0.slNo neq ""}
					 <div class="form-group col-md-6">
						<label for="exampleInputmodel">Api Url </label>
						<textarea class="form-control" id="apiUrl" name="apiUrl" placeholder="Api Url"  autocomplete="Off" style="height:50PX" readonly="readonly">{$ListEditView.0.api_post_url}</textarea>
					</div>
				{/if}
				{if $ListEditView.0.slNo neq ""}  
					<div class="form-group col-md-6" style="margin-top:-10PX">
				{else}
					<div class="form-group col-md-6">
				{/if}
					<label for="exampleInputmeterName">Place of Installation (Sensor Name) <span style="color:red;">*</span></label>
					<input type="text" class="form-control" id="sensorName" name="sensorName" placeholder="Enter Sensor name" value="{if $ListEditView.0.sensorName neq ""}{$ListEditView.0.sensorName}{/if}" autocomplete="Off" tabindex="2">
				</div>
				{assign var=tot value={"ID":"%i","apiKey":"}
				{if $ListEditView.0.slNo neq ""}  
					 <div class="form-group col-md-6">
						<label for="exampleInputmodel">Data to server JSON Format </label>
						<textarea class="form-control" id="dataFormat" name="dataFormat" placeholder="Enter Sensor Specification"  autocomplete="Off" style="height:100PX" readonly="readonly">{$tot}{$ListEditView.0.api_key}" ,"ST":"%s","TS":"%t","DT":"%d","VR":"%a"}</textarea>
					</div>
				{/if}
				{if $ListEditView.0.slNo neq ""} 
				 <div class="form-group col-md-6" style="margin-top:-70px">
				 {else}
				 <div class="form-group col-md-6" >
				 {/if}
				<label for="exampleInputmodel">Set Value (in secs) <span style="color:red;">*</span></label>
				<input type="text" class="form-control" id="setValue" name="setValue" placeholder="Enter Set Value" value="{if $ListEditView.0.setValue neq ""}{$ListEditView.0.setValue}{else}120{/if}" autocomplete="Off" onkeyup="numericFilter(this);" tabindex="3">
				</div>
				
				{if $ListEditView.0.slNo neq ""}
				<div class="form-group col-md-6" style="margin-top:px" >
				{else}
				<div class="form-group col-md-6" >
				{/if}
					<label for="exampleInputmodel">Modbus Slave Id <span style="color:red;">*</span></label>
					<input type="text" class="form-control" id="modbusSlaveId" name="modbusSlaveId" placeholder="Enter Set Value" value="{if $ListEditView.0.modbus_slave_id neq ""}{$ListEditView.0.modbus_slave_id}{/if}" autocomplete="Off" onkeyup="numericFilter(this);" tabindex="3">
				</div>
				{if $ListEditView.0.slNo neq ""} 
				<div class="form-group col-md-6" style="margin-top:-70px">
					<label for="exampleInputmodel">Json Format From Teltonika</label>
					<textarea class="form-control" id="jsonFormat" name="jsonFormat" placeholder="Enter Sensor Specification"  autocomplete="Off" style="height:100PX" readonly="readonly">{$ListEditView.0.json_data_format|base64_decode|stripslashes}</textarea>
				</div>
				{/if}
				{if $ListEditView.0.slNo neq ""} 
				 <div class="form-group col-md-6" style="margin-top:px" >
				 {else}
				 <div class="form-group col-md-6">
				 {/if}
					<label for="exampleInputmodel">Sensor Specification</label>
					<textarea class="form-control" id="specification" name="specification" placeholder="Enter Sensor Specification"  autocomplete="Off" style="height:100PX" tabindex="4">{if $ListEditView.0.sensorSpecification neq ""}{$ListEditView.0.sensorSpecification}{/if}</textarea>
				</div>
				<div class="form-group col-md-6"  id="mMode" style="display:none">
						<label for="exampleInputmake">Meter Mode<span style="color:red;">*</span></label>
						{if $ListEditView.0.meterMode neq ""}
						<input type="text"  class="form-control" id="meterMode" name="meterMode" value="{$ListEditView.0.meterMode}" readonly>
					{else}
					<select class="form-control" id="meterMode" name="meterMode" onchange="meterUnitGet();"  tabindex="1" >
						<option value="">--  Select Meter Mode  --</option>
						<option value="EB">EB</option>
						<option value="DG">DG</option>
						<option value="Dual Source">Dual Source</option>
						<option value="Solar">Solar</option>
					</select>
					{/if}
					</div>
					<div class="form-group col-md-6" id="ebMode" style="display:none" >
					<label for="exampleInputmodel">EB Unit Rate<span style="color:red;">*</span></label>
					<input type="text" class="form-control" id="ebUnitRate" name="ebUnitRate" placeholder="Enter EB Unit Rate" value="{if $ListEditView.0.modbus_slave_id neq ""}{$ListEditView.0.modbus_slave_id}{/if}" autocomplete="Off" onkeyup="numericFilter(this);" tabindex="3">
				</div>
				<div class="form-group col-md-6" id="dgMode" style="display:none" >
					<label for="exampleInputmodel">DG Unit Rate<span style="color:red;">*</span></label>
					<input type="text" class="form-control" id="dgUnitRate" name="dgUnitRate" placeholder="Enter DG Unit Rate" value="{if $ListEditView.0.modbus_slave_id neq ""}{$ListEditView.0.modbus_slave_id}{/if}" autocomplete="Off" onkeyup="numericFilter(this);" tabindex="3">
				</div>
				<div class="form-group" id="dualMode" style="display:none">
				<div class="row">
				<div class="form-group col-md-6">
					<label for="exampleInputmodel">EB Unit Rate<span style="color:red;">*</span></label>
					<input type="text" class="form-control" id="dualEbUnitRate" name="dualEbUnitRate" placeholder="Enter EB Unit Rate" value="{if $ListEditView.0.modbus_slave_id neq ""}{$ListEditView.0.modbus_slave_id}{/if}" autocomplete="Off" onkeyup="numericFilter(this);" tabindex="3">
				</div>
				<div class="form-group col-md-6">
					<label for="exampleInputmodel">DG Unit Rate<span style="color:red;">*</span></label>
					<input type="text" class="form-control" id="dualDgUnitRate" name="dualDgUnitRate" placeholder="Enter DG Unit Rate" value="{if $ListEditView.0.modbus_slave_id neq ""}{$ListEditView.0.modbus_slave_id}{/if}" autocomplete="Off" onkeyup="numericFilter(this);" tabindex="3">
				</div>
				</div>
				</div>
				<div class="form-group col-md-6" id="solarMode" style="display:none" >
					<label for="exampleInputmodel">Solar Unit Rate<span style="color:red;">*</span></label>
					<input type="text" class="form-control" id="solarUnitRate" name="solarUnitRate" placeholder="Enter Solar Unit Rate" value="{if $ListEditView.0.modbus_slave_id neq ""}{$ListEditView.0.modbus_slave_id}{/if}" autocomplete="Off" onkeyup="numericFilter(this);" tabindex="3">
				</div>
				<div class="form-group col-md-6" id="fType" style="display:none">
					<label for="exampleInputmodel">Feeder Type <span style="color:red;">*</span></label>
					{if $ListEditView.0.feeder_type neq ""}
						<input type="text"  class="form-control" id="feederType" name="feederType" value="{$ListEditView.0.feeder_type}" readonly>
					{else}
					<select class="form-control form-control-sm" id="feederType" name="feederType"  tabindex="3" onchange="feederTypefun();">
					<option value="">--  Select  --</option>
					    <option value="Main Meter">Main Meter</option>
						<option value="Sub Meter">Sub Meter</option>
						<option value="Sub Sub Meter">Sub Sub Meter</option>
					</select>
					{/if}
					</div>
					<div class="form-group col-md-6" id="Meter">
					<label for="exampleInputmake" id="subMeter">Sub Meter<span style="color:red;">*</span></label>
					<label for="exampleInputmake" id="mainMeter">Main Meter<span style="color:red;">*</span></label>
					{if $ListEditView.0.parent_id neq "0" && $smarty.get.sl_no neq ""}
					<input type="text"  class="form-control" id="meterType" name="meterType" value="{$SelQueryPExe.0.parentMeter}" readonly>
					{else}
					<select class="form-control form-control-sm" id="meterType" name="meterType"  tabindex="4"><option value="">--  Select --</option>
					</select>
					{/if}
					</div>
				
				<div class="form-group col-md-6" id="kwVal" style="display:none">
					<label for="inputEmail3">KW Max Value </label>
					<input type="text" name="kwMaxValue" class="form-control form-control-sm" id="kwMaxValue" placeholder="KW Max Value"  tabindex="4" value="500" onkeyup="numericFilter(this)"  >
				</div>
				<div class="form-group col-md-6" id="kvaVal" style="display:none">
					<label for="inputEmail3">KVA Max Value </label>
					<input type="text" name="kvaMaxValue" class="form-control form-control-sm" id="kvaMaxValue" placeholder="KVA Max Value"  tabindex="4" value="500" onkeyup="numericFilter(this)"  >
				</div>
				<div class="form-group col-md-6" id="kvarVal" style="display:none">
					<label for="inputEmail3">KVAR Max Value </label>
					<input type="text" name="kvarMaxValue" class="form-control form-control-sm" id="kvarMaxValue" placeholder="KVAR Max Value"  tabindex="3" value="500" onkeyup="numericFilter(this)">
				</div>
				<div class="form-group col-md-6" id="kvarhVal" style="display:none">
					<label for="inputEmail3">KVARH Max Value </label>
					<input type="text" name="kvarhMaxValue" class="form-control form-control-sm" id="kvarhMaxValue" placeholder="KVARH Max value"  tabindex="4" value="500" onkeyup="numericFilter(this)" >
				</div>	
				<div class="form-group col-md-6" id="kwhVal" style="display:none">
					<label for="inputEmail3">KWH Max Value </label>
					<input type="text" name="kwhMaxValue" class="form-control form-control-sm" id="kwhMaxValue" placeholder="KWH Max Value"  tabindex="3" value="500" onkeyup="numericFilter(this)">
				</div>
				<div class="form-group col-md-6" id="kvahVal" style="display:none">
					<label for="inputEmail3">KVAH Max Value </label>
					<input type="text" name="kvahMaxValue" class="form-control form-control-sm" id="kvahMaxValue" placeholder="KVAH Max value"  tabindex="4" value="500" onkeyup="numericFilter(this)" >
				</div>
				
				{if $ListEditView.0.slNo neq ""}  
				<div class="form-group col-md-6" style="margin-top:-10PX;">
				{else} 
				<div class="form-group col-md-6" >&nbsp;</div> <div class="form-group col-md-6" style="margin-top:-10PX;" >
				{/if}
					<div class="custom-control custom-checkbox" >
					{if $ListEditView.0.isActive eq '1'}
						<input class="custom-control-input" type="checkbox" id="customCheckbox2"  name="customCheckbox2" tabindex="5" checked="checked">
						<label for="customCheckbox2" class="custom-control-label">Is Active</label>
					{elseif $ListEditView.0.isActive eq '0'}
						<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="5">
						<label for="customCheckbox2" class="custom-control-label">Is Active</label>
					{else}
						<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="5" checked="checked">
						<label for="customCheckbox2" class="custom-control-label">Is Active</label>
					{/if}
					</div>
					<input id="created_by" name="created_by" class="date-picker form-control" type="hidden" value="{$smarty.session.UserName}" readonly="true">
					<input type="hidden" class="form-control" id="timestamp" name="timestamp" value="{$smarty.now|date_format:'%Y-%m-%d &amp; %I:%M:%S %p'}">
					<input type="hidden" class="form-control" id="created_time" name="created_time" placeholder="Time" Value="{$smarty.now|date_format:'%I:%M:%S %p'}">
				</div>
				</div>
				<div align="center">
				<input type="submit" value="Submit" class="btn btn-create" onclick="createValidation();" tabindex="6"/>
				</div>
				</form>
			</div>
		</div>
	</div>
	</section>
	</div>
	{literal}
		<script type="text/javascript">
		function numericFilter(data)
		{
		data.value = data.value.replace(/[^.0-9^.+,-]/ig,"");
		}
		function text_filter(data)
		{
		data.value = data.value.replace(/[^ .a-z]/ig,"");
		
		}
		</script>
		<script type="text/javascript">
		function createValidation(){	
		var platform = $('#platform').val();
		var sensorName = $('#sensorName').val();
		var model = $('#model').val();
		var specification = $('#specification').val();
		var setValue = $('#setValue').val();
		var modbusSlaveId=$('#modbusSlaveId').val();
		if(platform == 1){
		var meterMode=$('#meterMode').val();
		var ebUnitRate=$('#ebUnitRate').val();
		var dgUnitRate=$('#dgUnitRate').val();
		var dualEbUnitRate=$('#dualEbUnitRate').val();
		var dualDgUnitRate=$('#dualDgUnitRate').val();
		var solarUnitRate=$('#solarUnitRate').val();
		var feederType=$('#feederType').val();
		var meterType=$('#meterType').val();
		
		}
		var isActive = document.getElementById("customCheckbox2").checked;
		if (isActive == false) 
		{
		document.getElementById('checkVal').value='0';
		}
		else
		{
		document.getElementById('checkVal').value='1';
		}
		$(".error").remove();
		if (platform == "") {
			$('#platform').after('<span class="error">This field is required</span>');
			$('#platform').focus();
			return false;					
		}else if (model == '') {
			$('#model').after('<span class="error">This field is required</span>');
			$('#model').focus();
			return false;					
		}
		else if (sensorName < 1) {
			$('#sensorName').after('<span class="error">This field is required</span>');
			$('#sensorName').focus();
			return false;					
		}
		else if (specification < 1) {
			$('#specification').after('<span class="error">This field is required</span>');
			$('#specification').focus();
			return false;					
		}
		else if (setValue < 1) {
			$('#setValue').after('<span class="error">This field is required</span>');
			$('#setValue').focus();
			return false;					
		}else if (modbusSlaveId < 1) {
			$('#modbusSlaveId').after('<span class="error">This field is required</span>');
			$('#modbusSlaveId').focus();
			return false;					
		}
		if(platform == 1){
		 if (meterMode == "") {
			$('#meterMode').after('<span class="error">This field is required</span>');
			$('#meterMode').focus();
			return false;					
		}else if (meterMode == "EB") {
		
				if (ebUnitRate == "") {
				$('#ebUnitRate').after('<span class="error">This field is required</span>');
				$('#ebUnitRate').focus();
				return false;					
		}					
		}
		else if (meterMode == "DG") {
		
				if (dgUnitRate == "") {
				$('#dgUnitRate').after('<span class="error">This field is required</span>');
				$('#dgUnitRate').focus();
				return false;					
		}					
		}
		else if (meterMode == "Dual Source") {
		
				if (dualEbUnitRate == "") {
				$('#dualEbUnitRate').after('<span class="error">This field is required</span>');
				$('#dualEbUnitRate').focus();
				return false;					
				}
				else if (dualDgUnitRate == "") {
				$('#dualDgUnitRate').after('<span class="error">This field is required</span>');
				$('#dualDgUnitRate').focus();
				return false;					
				}					
		}
		else if (meterMode == "Solar") {
		
				if (solarUnitRate == "") {
				$('#solarUnitRate').after('<span class="error">This field is required</span>');
				$('#solarUnitRate').focus();
				return false;					
		}					
		}
		if (feederType == "") {
				$('#feederType').after('<span class="error">This field is required</span>');
				$('#feederType').focus();
				return false;					
		}
		else if (feederType == "Sub Meter" || feederType == "Sub Sub Meter") {
		      if (meterType == "") {
				$('#meterType').after('<span class="error">This field is required</span>');
				$('#meterType').focus();
				return false;	
				}				
		}
		}
			FormName = document.sensorRegForm;
			FormName.method = "POST";
			FormName.submit();
		}
		</script>
		<script type="text/javascript">
		function GoBack()
		{
			window.history.back();
		}
		</script>
		<script type="text/javascript">
		function locationDecode()
		{
			var lid = {$smarty.get.location_id};
			var uri_lid = decodeURIComponent(lid);
			alert(uri_lid);
		}
		</script>
		<script>
		$('#platform').on('change', function() {
		   // alert("hai");
		    var platfromVal= $("#platform").val();
		    //alert(platfromVal);
		  if(platfromVal == "1"){
		  $("#mMode").css("display", "block");
		  $("#fType").css("display", "block");
		  $("#kwVal").css("display", "block");
		  $("#kvaVal").css("display", "block");
		  $("#kvarVal").css("display", "block");
		  $("#kvarhVal").css("display", "block");
		  $("#kwhVal").css("display", "block");
		  $("#kvahVal").css("display", "block");
		  
		  }
		    $.ajax({
            type: "POST",
            url: "ajaxPlatformSensorModel.php",
            data: {platform:platfromVal},
            dataType: "JSON",
            cache: false,
            success: function(result){
            //    alert(result);
                var len = result.length;
                            $("#model").empty();
            				var option="<option value=''>-- Select Model --</option>";
                            for( var i = 0; i<len; i++){
                                var mId = result[i]["model_id"];
                                var mName = result[i]["model_name"];
            					option +="<option value='"+mId+"'>"+mName+"</option>";
            	
                            }
            				$("#model").append(option);
            },
            error: function(result) {
            alert('error');
            }
            });


        });
        </script>
		<script type="text/javascript">
		function meterUnitGet()
		{
		var meterMode = $('#meterMode').val();
		if(meterMode == "EB"){
		  $("#ebMode").css("display", "block");
		  $("#dgMode").css("display", "none");
		  $("#dualMode").css("display", "none");
		  $("#solarMode").css("display", "none");
		}
		if(meterMode == "DG"){
		$("#dgMode").css("display", "block");
		$("#ebMode").css("display", "none");
		$("#dualMode").css("display", "none");
		$("#solarMode").css("display", "none");
		}
		if(meterMode == "Dual Source"){
		$("#dualMode").css("display", "block");
		$("#ebMode").css("display", "none");
		$("#dgMode").css("display", "none");
		$("#solarMode").css("display", "none");
		}
		if(meterMode == "Solar"){
		 $("#solarMode").css("display", "block");
		 $("#ebMode").css("display", "none");
		 $("#dgMode").css("display", "none");
		 $("#dualMode").css("display", "none");
		}
		}
		</script>
		<script type="text/javascript">
	$(document).ready(function(){
		$("#mainMeter").hide();
		$("#subMeter").hide();
		$("#Meter").hide();
		 var platfromVal= $("#platformCode").val();
		    //alert(platfromVal);
		  if(platfromVal == "1"){
		  $("#mMode").css("display", "block");
		  $("#fType").css("display", "block");
		  $("#kwVal").css("display", "block");
		  $("#kvaVal").css("display", "block");
		  $("#kvarVal").css("display", "block");
		  $("#kvarhVal").css("display", "block");
		  $("#kwhVal").css("display", "block");
		  $("#kvahVal").css("display", "block");
		  feederTypefun();
		  var meterMode = $('#meterMode').val();
		  //alert(meterMode);
		if(meterMode == "EB"){
		  $("#ebMode").css("display", "block");
		  $("#dgMode").css("display", "none");
		  $("#dualMode").css("display", "none");
		  $("#solarMode").css("display", "none");
		}
		if(meterMode == "DG"){
		$("#dgMode").css("display", "block");
		$("#ebMode").css("display", "none");
		$("#dualMode").css("display", "none");
		$("#solarMode").css("display", "none");
		}
		if(meterMode == "Dual Source"){
		$("#dualMode").css("display", "block");
		$("#ebMode").css("display", "none");
		$("#dgMode").css("display", "none");
		$("#solarMode").css("display", "none");
		}
		if(meterMode == "Solar"){
		 $("#solarMode").css("display", "block");
		 $("#ebMode").css("display", "none");
		 $("#dgMode").css("display", "none");
		 $("#dualMode").css("display", "none");
		}
		  }
	});
	</script>
	<script >
	function feederTypefun(){
		var feederType= $("#feederType").val();
		var branId=$("#branch_id").val();
		var comId=$("#company_id").val();
		//alert(feederType);
		//alert(branId);
	if(feederType =='Sub Meter')
	{
		$("#Meter").show();
		$("#mainMeter").show();
		$("#subMeter").hide();
	}else if(feederType=='Sub Sub Meter'){
		$("#Meter").show();
		$("#subMeter").show();
		$("#mainMeter").hide();
	}
	else if(feederType=='Main Meter'){
		$("#Meter").hide();
		$("#subMeter").hide();
		$("#mainMeter").hide();
		return false;
	}
	$.ajax({
	type: "POST",
	url: "ajaxFeederType.php",
	data: {feedType:feederType,branchId:branId,companyId:comId},
	dataType: "JSON",
	cache: false,
	success: function(result){
	//alert(result);
	var len = result.length;
	$("#meterType").empty();
	$("#meterType").append("<option value=''> -- Select -- </option>");
	var option;
	for( var i = 0; i<len; i++){
	var slNo = result[i]["slNo"];
	var sensorName = result[i]["sensorName"];
	var parentId = result[i]["parent_id"];
	var submeterId = result[i]["submeter_id"];
	option +="<option value='"+slNo+"/"+sensorName+"/"+parentId+"/"+submeterId+"'>"+sensorName+"</option>";
	}
	$("#meterType").append(option);
	},
	error: function(result) {
	alert('error');
	}
	});
	}
	</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	{/literal}
	{include file="footer.tpl"}