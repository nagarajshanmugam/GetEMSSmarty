<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" type="image/png" href=""/>
		<title>EMS | Log in</title>
		
		<!-- Font Awesome  for input field icon -->
		<link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
		<!-- Theme style Important -->
		<link rel="stylesheet" href="dist/css/adminlte.min.css">
	
	</head>
	<body class="hold-transition login-page" style=" background-image:url(images/emsBaner.png);">
		<div class="login-box">
			<div class="login-logo">
			<!---<a href="#" style="color:#FFFFFF;"><b>SITE UNDER MAINTENANCE</b></a>--->
			</div>
		<!-- /.login-logo -->
			<div class="card">
				<div class="card-body login-card-body">
					<p class="login-box-msg"><b>SITE UNDER MAINTENANCE !!!</b></p>
					<p class="blink" ><b>For any queries, Please contact EMS Team.</b></p>
					<p class="blink" ><b>Thank You.</b></p>
				
					
				</div>
			</div>
		</div>
		{literal}	

		<style>
		@keyframes blink {
    0% { opacity: 1; }
    50% { opacity: 0; }
    100% { opacity: 1; }
}

.blink {
    animation: blink 2.5s infinite;
	text-align: center;
	color:red;
}

		</style>	
		<style>
           .glow {
  font-size: 20px;
  color: #000000;
  text-align: center;
  animation: glow 1s ease-in-out infinite alternate;
}

@-webkit-keyframes glow {
  from {
    text-shadow: 0 0 10px #fff, 0 0 20px #fff, 0 0 30px #f44336, 0 0 40px #f44336, 0 0 50px #f44336, 0 0 60px #f44336, 0 0 70px #f44336;
  }
  
  to {
    text-shadow: 0 0 20px #fff, 0 0 30px #9fc5e8, 0 0 40px #9fc5e8, 0 0 50px #9fc5e8, 0 0 60px #9fc5e8, 0 0 70px #9fc5e8, 0 0 80px #9fc5e8;
  }
}
        </style>
		{/literal}
	</body>
	
</html>
