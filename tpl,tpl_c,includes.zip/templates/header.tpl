<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" style="color:#FFFFFF" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block"><a class="nav-link" style="color:#FFFFFF; margin-top:-8px;font-size:16px;"><b>{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if} - {if $headervariable eq 'Temperature' && $smarty.session.CompanyName neq "Subros"}Temperature Monitoring System{elseif $smarty.session.CompanyName eq "Subros"}Power Factor Controller Monitoring{else}Energy Meter Monitoring System{/if}<!--Condition Monitoring System--></b></a></li>
    
      <!--<li class="nav-item d-none d-sm-inline-block">
        <a href="#" class="nav-link">Contact</a>
      </li>-->
    </ul>

    <!-- SEARCH FORM -->
    <!--<form class="form-inline ml-3">
      <div class="input-group input-group-sm">
        <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
        <div class="input-group-append">
          <button class="btn btn-navbar" type="submit">
            <i class="fas fa-search"></i>
          </button>
        </div>
      </div>
    </form>-->

    <ul class="navbar-nav ml-auto">
	  <li class="nav-item d-none d-sm-inline-block" style="float:right">
        <a href="#" style="color:#FFFFFF; margin-top:-8px;font-size:18px;"><b>{$smarty.now|date_format:"%e-%b-%Y %I:%M:%S %p"}</b></a>
      </li>
      <li class="nav-item dropdown user-menu">
        <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
          <img src="./images/UserImages/{$smarty.session.UserImage}" class="user-image img-circle elevation-2" alt="User Image">
          <span class="d-none d-md-inline" style="color:#FFFFFF">{$smarty.session.UserName}</span>
        </a>
        <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <!-- User image -->
          <li class="user-header">
            <img src="./images/UserImages/{$smarty.session.UserImage}" class="img-circle elevation-2" alt="User Image">

            <p style="color:#FFFFFF">
              {$smarty.session.UserName}
             <!-- <small>Member since Nov. 2012</small> -->
            </p>
          </li>
          <!-- Menu Body -->
          <!--<li class="user-body">-->
            <!--<div class="row">
              <div class="col-4 text-center">
                <a href="#">Followers</a>
              </div>
              <div class="col-4 text-center">
                <a href="#">Sales</a>
              </div>
              <div class="col-4 text-center">
                <a href="#">Friends</a>
              </div>
            </div>-->
            <!-- /.row -->
         <!-- </li>-->
          <!-- Menu Footer-->
          <li class="user-footer">
            <a href="profile.php?userId={$smarty.session.User_ID|base64_encode}&Update=p" class="btn btn-default btn-flat">Update Profile</a>
            <a href="logout.php" class="btn btn-default btn-flat float-right">Sign out</a>
          </li>
        </ul>
      </li>
    </ul>
  </nav>
  {literal}
  
<style>
.main-header,.user-header{
/*background-color:#3c8dbc;*/
background-color:#17a2b8;;
}
</style>


 
{/literal}
