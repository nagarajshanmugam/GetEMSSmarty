	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">{if $smarty.get.sl_no eq ""}Create Sensor Model{else}Edit Sensor Model{/if}</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			<a href="sensorModelList.php"><button type="button" style="float:right;margin-top:-40Px" class="btn btn-primary">List Sensor Model</button></a>
			</div>
		</div>
		<div class="card">
			<div class="card-body">
				<form role="form" name="sensorModelForm" id="sensorModelForm" method="post" onsubmit="return createValidation();" >
					<input type="hidden" name="hdAction" />
					<input type="hidden" id="company_id" name="company_id" value="{$smarty.get.companyId}" />
					<input type="hidden" id="check_id" name="check_id" value="{$smarty.post.check_id}">
					<input type="hidden" id="checkVal" name="checkVal" value="{$smarty.post.checkVal}" />
					<input type="hidden" id="platForm" name="platForm" value="{$ListEditView.0.platform_id}" />
					<input type="hidden" id="sModel" name="sModel" value="{$smarty.get.sl_no|base64_decode}" />
					<input type="hidden" id="stReg" name="stReg" value="" />
					
					<div class="row">
						<div class="form-group col-md-6">
							<label for="exampleInputgatewayId">Sensor Model Name <span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm" id="modelName" name="modelName" placeholder="Enter Model Name" value="{if $ListEditView.0.model_name neq ""}{$ListEditView.0.model_name}{/if}" tabindex="1">
						</div>
						<div class="form-group col-md-6">
							<label for="exampleInputgatewayId">Api Url <span style="color:red;">*</span></label>
							<textarea type="text" class="form-control form-control-sm" id="apiUrl" name="apiUrl" placeholder="Enter Model Name" tabindex="6">{if $ListEditView.0.api_url neq ""}{$ListEditView.0.api_url}{/if}</textarea>
						</div>
					
						<div class="form-group col-md-6" style="margin-top:-5PX">
							<label for="exampleInputgatewayId">Sensor Model Short Code <span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm" id="modelCode" name="modelCode" placeholder="Enter Model Code" value="{if $ListEditView.0.model_id neq ""}{$ListEditView.0.model_id}{/if}" tabindex="2">
						</div>
						<div class="form-group col-md-6">
						<label for="exampleInputmodel">Make <span style="color:red;">*</span></label>
						<select  id="make" name="make" class="form-control form-control-sm"  tabindex="7" onchange="ChangeMake(this.value);">
						{if $ListEditView.0.make neq ""}
                        <option value="{$ListEditView.0.make}" selected="selected">{$ListEditView.0.make}</option>
                        {if $ListEditView.0.make eq "PFC"}
						<option value="Others">Others</option>
                        {elseif $ListEditView.0.make eq "Others"}
                        <option value="PFC">PFC</option>
                        {/if}
						{else}
						<option value="Others">Others</option>
						<option value="PFC">PFC</option>
                        {/if}
						</select>
						</div>
						<div class="form-group col-md-6">
						<label for="exampleInputmodel">Communication Type <span style="color:red;">*</span></label>
						<select  id="commType" name="commType" class="form-control form-control-sm"  tabindex="3">
						{if $ListEditView.0.communication_type neq ""}<option value="{$ListEditView.0.communication_type}">{$ListEditView.0.communication_type}</option>{else}
						<option value="">--  Select  --</option>
						{/if}
						<option value="Analog">Analog</option>
						<option value="Digital">Digital</option>
						<option value="RS232">RS232</option>
						<option value="RS422">RS422</option>
						<option value="RS485">RS485</option>
						</select>
						</div>
                        <div class="form-group col-md-6" style="display:none;" id="nstep">
							<label for="exampleInputgatewayId">No Of Steps <span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm" id="noOfSteps" name="noOfSteps" placeholder="Enter No Of Steps" tabindex="8" value="{if $ListEditView.0.no_of_steps neq ""}{$ListEditView.0.no_of_steps}{/if}">
						</div>
						<div class="form-group col-md-6">
							<label for="exampleInputgatewayId">Json Format <span style="color:red;">*</span></label>
							<textarea type="text" class="form-control form-control-sm" id="jsonFormat" name="jsonFormat" placeholder="Enter JSON Format" tabindex="4"  style="height:80PX" >{if $ListEditView.0.json_format neq ""}{$ListEditView.0.json_format|base64_decode|stripslashes}{/if}</textarea>
						</div>
                        <div class="form-group col-md-6" >
						<label for="exampleInputmodel">Plaftorm  <span style="color:red;">*</span></label>
						<select  id="platform" name="platform" class="form-control form-control-sm"  tabindex="5" onchange="ChangeMakeTemp(this.value);">
						   {if $ListEditView.0.platform_id eq "0" || $ListEditView.0.platform_id eq "" }<option value="" selected="selected"> -- Choose Platform -- </option>{/if}
						    {foreach from=$Platform item=listPlatform}
						    {if $ListEditView.0.platform_id eq $listPlatform.slNo}
						        <option value="{$listPlatform.slNo}" selected="selected">{$listPlatform.segmentName}</option>
						    {/if}
						    {if $ListEditView.0.platform_id neq $listPlatform.slNo}
						        <option value="{$listPlatform.slNo}">{$listPlatform.segmentName}</option>
						    {/if}
							{/foreach}
						</select>
						</div>
                        
                        
                        <div class="form-group col-md-6" style="display:none;" id="capa">
							<label for="exampleInputgatewayId">Capacity <span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm" id="capacity" name="capacity" placeholder="Enter Capacity" tabindex="9" value="{if $ListEditView.0.capacity neq ""}{$ListEditView.0.capacity}{/if}">
						</div>
						<div class="form-group col-md-6" style="display:none;" id="lvim">
							<label for="exampleInputgatewayId">Last Value in Meter <span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm" id="maxKWH" name="maxKWH" placeholder="Enter Last Value in Meter" tabindex="9" maxlength=15 value="{if $ListEditView.0.max_kwh neq ""}{$ListEditView.0.max_kwh}{/if}" onkeyup="numericFilter(this);">
						</div>
						<div class="form-group col-md-6" id="sCounts">
							<label for="exampleInputgatewayId">Segment Count <span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm" id="segCount" name="segCount" placeholder="Enter Segment Count" tabindex="9" onchange="generateTextBoxes(this.value);" maxlength=2 onkeyup="numericFilter(this);" value="{if $ListEditView.0.segment_count neq ""}{$ListEditView.0.segment_count}{/if}">
						</div>
						<div id="startRegisterBoxContainer"></div>
					
						<div class="form-group col-md-6" style="display:block;" id="sRegDiv">
						{foreach from=$ListSensorSegment item=seg}
							<label for="exampleInputgatewayId">Start Register {$seg.priority} <span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm" id="startReg" name="startReg" placeholder="Enter Start Register" tabindex="9" onchange="generateTextBoxes(this.value);" maxlength=2 onkeyup="numericFilter(this);" value="{if $ListSensorSegment.0.start_register_value neq ""}{$seg.start_register_value}{/if}" readonly>
							{/foreach}
						</div>
					
						
						<div class="form-group col-md-6" style="display:none;" id="tstep">
						<label for="exampleInputmodel">Temperature Sensor Type <span style="color:red;">*</span></label>
						<select  id="temHum" name="temHum" class="form-control form-control-sm"  tabindex="5">
						<option value="" selected="selected"> -- Choose Type -- </option>
						{if $ListEditView.0.TemHum eq "Temperature"}
						<option value="Temperature" selected="selected">Temperature</option>
						<option value="Humidity">Humidity</option>
						<option value="Both">Both</option>
						{elseif $ListEditView.0.TemHum eq "Humidity"}
						<option value="Humidity" selected="selected">Humidity</option>
						<option value="Temperature" >Temperature</option>
						<option value="Both">Both</option>
						{elseif $ListEditView.0.TemHum eq "Both"}
						<option value="Humidity">Humidity</option>
						<option value="Temperature" >Temperature</option>
						<option value="Both" selected="selected">Both</option>
						{else}
						<option value="Temperature">Temperature</option>
						<option value="Humidity">Humidity</option>
						<option value="Both">Both</option>
						{/if}
						</select>
						</div>
                        
                        <div class="form-group col-md-6" style="margin-top:-35PX;display:none;" id="lev1">
							<label for="exampleInputgatewayId">Level 1 (100 to)<span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm" id="level1" name="level1" placeholder="Enter Level 1" tabindex="10" value="{if $ListEditView.0.level1 neq ""}{$ListEditView.0.level1}{/if}">
						</div>
                        <div class="form-group col-md-6">
							<div class="custom-control custom-checkbox">
							{if $ListEditView.0.is_active eq '1'}
								<input class="custom-control-input" type="checkbox" id="customCheckbox2"  name="customCheckbox2" tabindex="12" checked="checked">
								<label for="customCheckbox2" class="custom-control-label">Is Active</label>
							{elseif $ListEditView.0.is_active eq '0'}
								<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="12">
								<label for="customCheckbox2" class="custom-control-label">Is Active</label>
							{else}
								<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="12" checked="checked">
								<label for="customCheckbox2" class="custom-control-label">Is Active</label>
							{/if}
							</div>
							<input id="created_by" name="created_by" class="date-picker form-control" type="hidden" value="{$smarty.session.UserName}" readonly="true">
							<input type="hidden" class="form-control" id="created_date_time" name="created_date_time" value="{$smarty.now|date_format:'%Y-%m-%d  %H:%M:%S'}">
							<input type="hidden" class="form-control" id="created_time" name="created_time" placeholder="Time" Value="{$smarty.now|date_format:'%I:%M:%S %p'}">
						</div>
                        
                        <div class="form-group col-md-6" style="margin-top:-35PX;display:none;" id="lev2">
							<label for="exampleInputgatewayId">Level 2 (40 to)<span style="color:red;">*</span></label>
							<input type="text" class="form-control form-control-sm" id="level2" name="level2" placeholder="Enter Level 2" tabindex="11" value="{if $ListEditView.0.level2 neq ""}{$ListEditView.0.level2}{/if}">
						</div>
						
						
					</div>
					<div align="center">
					<input type="submit" value="Submit" onclick="createValidation()"; class="btn btn-create" />
					</div>
				</form>
			</div>
		</div>
	</div>
	</section>
	</div>
	{literal}
	<script type="text/javascript">
		function numericFilter(data)
		{
		data.value = data.value.replace(/[^.0-9^.+,-]/ig,"");
		}
		</script>
		
	<script>
	// A $( document ).ready() block.
$(document).ready(function() {
    generateTextBoxes();
	/*var platFormVal = $('#platform').val();
	if(platFormVal == '1')
	{
	document.getElementById('mkwh').style.display="block";
	document.getElementById('sCount').style.display="block";
	}
	else
	{
	document.getElementById('mkwh').style.display="none";
	document.getElementById('sCount').style.display="none";
	}*/
	//document.getElementById('startRegisterBoxContainer').style.display="none";


});
</script>
	<script type="text/javascript">
        function generateTextBoxes() {
            // Get the number of text boxes to generate
            var numTextBoxes = document.getElementById('segCount').value;
            var container = document.getElementById('startRegisterBoxContainer');

            // Clear existing text boxes
            container.innerHTML = '';

            // Generate new text boxes
            for (var i = 0; i < numTextBoxes; i++) {
                var label = document.createElement('label');
                label.htmlFor = 'startRegister_' + i;
                label.innerHTML = 'Start Register ' + (i + 1) + ': ';

                var input = document.createElement('input');
                input.type = 'text';
                input.id = 'startRegister_' + i;
                input.name = 'startRegister_' + i;
				

                container.appendChild(label);
                container.appendChild(input);
                container.appendChild(document.createElement('br'));
            }
        }
    </script>
	<script type="text/javascript">
	function createValidation()
	{
		var modelName = $('#modelName').val();
		var modelCode = $('#modelCode').val();
		var commType = $('#commType').val();
		var apiUrl = $('#apiUrl').val();
		var jsonFormat = $('#jsonFormat').val();
		var platform = $('#platform').val();
		var segCount = $('#segCount').val();
		var maxKWH = $('#maxKWH').val();
		var startRegister = $('#startRegister').val();
		var sModel = $('#sModel').val();
		
		
		var isActive = document.getElementById("customCheckbox2").checked;

		var container = document.getElementById('startRegisterBoxContainer');
        var inputs = container.getElementsByTagName('input');
            
         
	
	if (isActive == false) 
	{
		document.getElementById('checkVal').value='0';
	}
	else
	{
		document.getElementById('checkVal').value='1';
	}
		$(".error").remove();
	if (modelName < 1) {
		$('#modelName').after('<span class="error">This field is required</span>');
		$('#modelName').focus();
		return false;					
	}
	else if (modelCode < 1) {
		$('#modelCode').after('<span class="error">This field is required</span>');
		$('#modelCode').focus();
		return false;					
	}
	else if (commType < 1) {
		$('#commType').after('<span class="error">This field is required</span>');
		$('#commType').focus();
		return false;					
	}
	else if (apiUrl < 1) {
		$('#apiUrl').after('<span class="error">This field is required</span>');
		$('#apiUrl').focus();
		return false;					
	}else if (jsonFormat < 1) {
		$('#jsonFormat').after('<span class="error">This field is required</span>');
		$('#jsonFormat').focus();
		return false;					
	}else if (platform == '') {
		$('#platform').after('<span class="error">This field is required</span>');
		$('#platform').focus();
		return false;	
		
	}
	if(platform != '3'){
	 if (maxKWH == '') {
		$('#maxKWH').after('<span class="error">This field is required</span>');
		$('#maxKWH').focus();
		return false;
	}
	}else if(segCount == '') {
		$('#segCount').after('<span class="error">This field is required</span>');
		$('#segCount').focus();
		return false;
	}
		
		

		 // Get the number of text boxes to generate
            var numTextBoxes = document.getElementById('segCount').value;
            var container = document.getElementById('startRegisterBoxContainer');
   
            // Clear existing text boxes
            //container.innerHTML = '';

            // Generate new text boxes
            for (var i = 0; i < numTextBoxes; i++) {
				
                var label = document.createElement('label');
                label.htmlFor = 'startRegister_' + i;
                label.innerHTML = 'Start Register ' + (i + 1) + ': ';

                var input = document.createElement('input');
                input.type = 'text';
                input.id = 'startRegister_' + i;
                input.name = 'startRegister_' + i;
				//input.value = 'startRegister_' + i;
				
				//if(input.value == ''){
				
				   for (var i = 0; i <= numTextBoxes; i++) {
                if (inputs[i].value === '') {
                    alert("Enter Start Register Values in all text boxes");
                    //inputs[i].style.display = "block";  // Ensure the input is visible
                    //inputs[i].focus();  // Focus the empty input
                    return false;
                }

				 if (isNaN(parseFloat(inputs[i].value))) {
				   alert("Only integers are allowed!");
                    inputs[i].value = inputs[i].value.replace(/[^.0-9^.+,-]/ig,"");
                    return false;
                }
				
				
				 // If all inputs have values, submit the form or perform your desired action
            //alert("All inputs are filled!");
            //return true;
			// Clear existing text boxes
            //container.innerHTML = '';
            }

           

				//}

                container.appendChild(label);
                container.appendChild(input);
                container.appendChild(document.createElement('br'));
            }
				
	
	
		FormName		= document.sensorModelForm;
		FormName.method	= "POST";
		FormName.submit();
	}
	
	function GoBack()
	{
		window.history.back();
	}
	
	function ChangeMake(cval)
	{
	if(cval == 'PFC')
	{
	document.getElementById('nstep').style.display="block";
	document.getElementById('capa').style.display="block";
	document.getElementById('lev1').style.display="block";
	document.getElementById('lev2').style.display="block";
	}
	else
	{
	document.getElementById('nstep').style.display="none";
	document.getElementById('capa').style.display="none";
	document.getElementById('lev1').style.display="none";
	document.getElementById('lev2').style.display="none";
	}
	
	}
	</script>
	<script>
	function ChangeMakeTemp(tval)
	{
	if(tval == '1' || tval != '3')
	{
	document.getElementById('lvim').style.display="block";
	document.getElementById('mkwh').style.display="block";
	document.getElementById('sCount').style.display="block";
	}
	else
	{
	document.getElementById('lvim').style.display="none";
	document.getElementById('mkwh').style.display="none";
	document.getElementById('sCount').style.display="none";
	}
	if(tval == '3')
	{
	
	document.getElementById('tstep').style.display="block";
	document.getElementById('lvim').style.display="none";
	}
	else
	{
	document.getElementById('lvim').style.display="block";
	document.getElementById('tstep').style.display="none";
	}
	
	}
	</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	</style>
	{/literal}
	{include file="footer.tpl"}