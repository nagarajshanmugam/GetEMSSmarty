	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				{if $smarty.get.branchId}  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>{/if}
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">List Alert Contact</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:10PX;color:#999999;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			</div>
		</div>
		<form name="contactMasterList" method="post" id="contactMasterList">
		<div class="row">
			<div class="col-12">
			{if $SuccessMessage neq ""}
				<div class="isa_success">
				<i class="fa fa-check"></i>
				{$SuccessMessage}		 
				</div>
			{/if}
			{if $ErrorMessage neq ""}
				<div class="isa_error">
				<i class="fa fa-check"></i>
				{$ErrorMessage}		 
				</div>
			{/if}
				<div class="card">
					<div class="card-body table-responsive">
					<a href="contactMasterAddEdit.php?companyId={$smarty.get.companyId}&branchId={$smarty.get.branchId}"><button type="button" style="float:right;margin-top:-6PX" class="btn btn-create">Create Alert Contact</button></a>{if $ListView.0.sl_no eq ''}<br /><br />{/if}
						<table id="example" class="table table-bordered table-hover">
						<thead>
						<tr>
						<th>#</th>
						<th>Contact Person Name</th>
						<th>Mobile</th>
						<th>Email</th>
						<th>Status</th>
						<th>Action</th>
						</tr>
						</thead>
						<tbody>
						{foreach from=$ListView item=List}
						<tr id="{$j++}">
						<td class="slNo">{$j}</td>
						<td class="name">{$List.person_name}</td>
						<td class="mobile">{if $List.sms_alert eq "1"}<span style="color:#009900"><b>{$List.mobile}</b></span>{else}<span style="color:#FF0000;"><b>{$List.mobile}</b></span>{/if}</td>
						<td class="email">{if $List.email_alert eq "1"}<span style="color:#009900"><b>{$List.email}</b></span>{else}<span style="color:#FF0000;"><b>{$List.email}</b></span>{/if}</td>
						<td class="isactive">{if $List.is_active eq "1"}<span style="color:#009900"><b>Active</b></span>{else}<span style="color:#FF0000;"><b>Inactive</b></span>{/if}</td>
						<td class="action">
						<a href="#"  onClick="Javascript:editCats('{$List.sl_no}','{$List.person_name}','{$List.mobile}','{$List.company_id}','{$List.branch_id}')" title="Edit Contact Master"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;&nbsp;
						<a href="#"  onClick="Javascript:deleteCats('{$List.sl_no}','{$List.person_name}','{$List.mobile}','{$List.company_id}','{$List.branch_id}')" title="Delete Contact Master"><i class="fa fa-trash"></i></a></td>
						</tr>
						{foreachelse}
						<tr><td colspan="6"><center>No Records Found</center></td></tr>
						{/foreach}
						</tbody>
						</table>
					</div>
				</div>
			</div>
		</form>
	</section>
	</div>
	{literal}
	<style>
	.slNo{
	width:5%;
	}
	.name{
	width:15%;
	}
	.mobile{
	width:10%;
	}
	.email{
	width:20%;
	}
	.isactive{
	width:10%;
	text-align:center;
	}
	.action{
	text-align:right;
	}
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	</style>
		<script type="text/javascript">
		$(document).ready(function (){
		
		var table = $('#example').DataTable({
		"ordering" : false,
		language: {
		"infoFiltered": "",
		search: "_INPUT_",
		searchPlaceholder: "Search..."
		},
		dom: '<"pull-left" f><bottom>p',
		tableTools: {
		"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
		},
		//dom: '<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p',
		//dom: '<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p',
		buttons: [
		{
		text: 'Create Box',
		className: 'btn btn-create',
		titleAttr: 'Create Box',
		action: function ( e, dt, button, config ) {
		window.location = 'AddEditBox.php';
		}        
		}
		],
		initComplete: function(){
		$("div.toolbar").html('<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>');   
		
		
		}       
		}); 
		
		}); 
		
		function editCats(slNoIdent,personIdent,mobIdent,compId,branId) {
		var sid = btoa(slNoIdent); var pid = btoa(personIdent); var mid = btoa(mobIdent);var cid = btoa(compId);var bid = btoa(branId);
		FormName		= document.contactMasterList;
		FormName.action ='contactMasterAddEdit.php?person_name='+pid+'&mobile='+mid+'&sl_no='+sid+'&companyId='+cid+'&branchId='+bid+'&Update=y';
		FormName.submit();
		}
		
		</script>
		<script type="text/javascript">
		function deleteCats(slNoIdent,personIdent,mobIdent,compId,branId){
		var sid = btoa(slNoIdent); var pid = btoa(personIdent); var mid = btoa(mobIdent);var cid = btoa(compId);var bid = btoa(branId);
		if(confirm("Are you sure to Delete this Contact Person?")){
		FormName		= document.contactMasterList;
		FormName.action= 'contactMasterList.php?person_name='+pid+'&mobile='+mid+'&sl_no='+sid+'&companyId='+cid+'&branchId='+bid+'&Delete=del';
		FormName.submit();
		}
		}
		</script>
	{/literal}
	{include file="footer.tpl"}