{literal}
 <link rel="stylesheet" href="/resources/demos/style.css">
<link rel="stylesheet" href="css/jquery-ui.css">
 <script>
$( function() {
	$( "#fromDate" ).datepicker({changeMonth: true,
	changeYear: true,maxDate: '-0',dateFormat:'yy-mm-dd'});
	$( "#toDate" ).datepicker({changeMonth: true,
	changeYear: true,maxDate: '-0',dateFormat:'yy-mm-dd'});
} );
</script>

<script type="text/javascript">
     function secondsToDhms(seconds,v) {//alert(seconds);
var seconds = Number(seconds);
var d = Math.floor(seconds / (3600*24));
var h = Math.floor(seconds % (3600*24) / 3600);
var m = Math.floor(seconds % 3600 / 60);
var s = Math.floor(seconds % 60);

var dDisplay = d > 0 ? d + (d == 1 ? " day, " : " days, ") : "";
var hDisplay = h > 0 ? h + (h == 1 ? " hr, " : " hrs, ") : "";
var mDisplay = m > 0 ? m + (m == 1 ? " min, " : " min's, ") : "";
var sDisplay = s > 0 ? s + (s == 1 ? " sec" : " sec's") : "";
var res=  dDisplay + hDisplay + mDisplay + sDisplay;
document.getElementById(v).innerHTML=res;
}
 </script>
 <script type="text/javascript">
	function includecomma1(c,v)
{
//var x=Math.round(c);
//var x=c.toFixed(2);

var x=c.split(".");
var ld=x[1];
var ty=typeof(x[1]);//alert(ty);
if(ty == 'undefined')
{
   
    var ld='00';
}
else
{
var ld=x[1].slice(0, 2);
}
x=x[0].toString();
var lastThree = x.substring(x.length-3);
var otherNumbers = x.substring(0,x.length-3);
if(otherNumbers != '')
{
lastThree = ',' + lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
}
else
{
lastThree =  lastThree;
var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
}
//var res = res+'.00';
var res = res+'.'+ld;
document.getElementById(v).innerHTML=res;
}
</script>
{/literal}

<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<body onLoad="doOnLoad();">
<div class="content-wrapper">

<!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
-->
    <div class="content-header">

      <div class="container-fluid">

            <div class="row"> <div class="col-md-12">
            <div class="card">
            <div class="card-body">
			

			 <table style="margin-bottom:-10px;">
		  <tr><td style="font-size:15PX;font-weight: bold;">{$companyDetail.0.companyName}&nbsp;&nbsp;</td>
		  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  <td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>
		  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
<!--		  <td style="font-size:15PX;font-weight: bold;">{$senDashboard.0.energy_meter_group_name}&ensp;&ensp;</td>
		  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
-->		  <td style="font-size:15PX;font-weight: bold;">List Main Meter  <!---({$LoctList.0.gateway_id} / {$LoctList.0.sensorCode})--></font>&nbsp;</td></tr>
		  
		
		  <tr><td style="font-size:10PX;color:#999999;">Company Name</td>
		  <td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		  <td style="font-size:10PX;color:#999999;">Branch Name</td>
		  <td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
<!--		  <td style="font-size:10PX;color:#999999;">Meter Group Name</td>
		  <td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>-->
		  <!--<td style="color:#999999;font-size:10PX;">Dashboard</td><td>&nbsp;</td>-->
		  </tr>
		  
		  </table>
		             

		    </div>
			</div>
			</div>
          </div>

       
            <div class="row">

			<div class="col-md-12">

            <div class="card card-outline card-primary">
               <div class="card-body table-responsive">
			   
			   
			 <div class="row"><form name="meterList" method="post" id="meterList">

            <div class="col-sm-12">
                  <div class="col-sm-4"  style="float:left;margin-top:10PX;">From Date: <input type="text" id="fromDate" name="fromDate" value="{if $smarty.post.fromDate neq ''}{$smarty.post.fromDate}{else}{$smarty.now|date_format:'%Y-%m-%d'}{/if}" class="form-control" autocomplete="off" readonly="true"></div>
                  
                  	<div class="col-sm-4"  style="float:left;margin-top:10PX;"> To Date: <input type="text" id="toDate" name="toDate" value="{if $smarty.post.toDate neq ''}{$smarty.post.toDate}{else}{$smarty.now|date_format:'%Y-%m-%d'}{/if}" class="form-control" autocomplete="off" readonly="true"></div>&nbsp;&nbsp;
				
                
                
                
                        
                        
                        
                        
                        
					<div class="col-sm-4"  style="float:left;margin-top:10PX;">
					<input type="button" value="Submit" id="submitButton" name="submitButton" class="btn btn-create"  onClick="submitButtonFun();">&nbsp;&nbsp;
                    <!--<a href="#" onClick="get_excel();"><img src="images/excel1.png"  height="23" width="23" alt="Excel" title="Xls" ></a>-->
                    <input type="button" value="Excel" id="excelButton" name="excelButton" class="btn btn-create" style="" title="Xls" onClick="get_excel();">
					</div>
                </div>
				
				<P><br><br><br></P>

            
<input type="hidden" id="cid" name="cid" value="{if $smarty.get.companyId neq ""}{$smarty.get.companyId}{else}{$smarty.session.customerId}{/if}" />
    <input type="hidden" id="bid" name="bid" value="{$smarty.get.branchId}" />
     <input type="hidden" id="parentid" name="parentid" value="{$smarty.get.parent_id}" />
            <input type="hidden" value="{$Dashboard.0.segmentName}" />


			  <div id="list_books" >
			 {if $smarty.post.fromDate neq '' && $smarty.post.toDate} <h5 style="color:#009900;" align="center"><b> From : {$smarty.post.fromDate|date_format:"%e-%b-%Y"} &ensp;&ensp;&ensp;&ensp; To : {$smarty.post.toDate|date_format:"%e-%b-%Y"} </b></h5>{/if}
<table id="example" class="table table-bordered table-hover">
                <thead>
                <tr>
    			  <th class="slNo" >#</th>
                  <th class="name"  >Energy Meter Name</th>
                  <th class="code"  >Gateway</th>
				  <th class="code"  >Meter Id</th>
<!--				   <th class="status" >Status</th>
-->                  <th class="cost" >KWH</th>
                  <th class="cost" >Cost</th>
                  <th class="action"   >Date Time</th>
                  <th class="last" >Last Comm</th>
                  
          
                </tr>
               <!-- <tr>
    			 
                  <th class="cost" >KWH</th>
                  <th class="cost" >Cost</th>
                  
                </tr>-->
                </thead>
                <tbody>
				{assign var="tkwh" value=0.00}
             {assign var="tcost" value=0.00}
				{foreach from=$MeterList item=List}
                {assign var=pid value=$List.feeder_master_id|base64_encode}
                <tr id="{$j++}">
				 <td >{$j}</td>
                 <td><a href="meterDashboard.php?companyId={$smarty.get.companyId}&branchId={$smarty.get.branchId}&sensorCode={$List.sensor_code|base64_encode}&gatewayCode={$List.gateway_code|base64_encode}"><span style="color:#000000;" title="Meter Details" class="uline">{$List.feeder_name}</span></a>&ensp; &ensp;</td>
                 <td  align="center">{$List.place_of_installation}</td>
				 <td align="center" >{$List.modbus_slave_id}</td>

				 
				 
		
				
				<!--<td>
				{foreach from=$gateList item=gate}
				
				{if $gate.gateway_code neq 'YMN-1' && $gate.gateway_code eq $List.gateway_code && $gate.gateway_date_time gte $dateSec|date_format:'%Y-%m-%d %H:%M:%S' }
                 <img  src="./images/on.png">
                 {assign var="tog" value='1'}
                {elseif $gate.gateway_code neq 'YMN-1' && $gate.gateway_code eq $List.gateway_code && $gate.gateway_date_time lt $dateSec|date_format:'%Y-%m-%d %H:%M:%S'}
                <img  src="./images/off.png">
                 {assign var="tog" value='1'}
                {/if}
                
                {if $gate.gateway_code eq 'YMN-1' && $gate.gateway_code eq $List.gateway_code && $gate.gateway_date_time gte $dateSec1|date_format:'%Y-%m-%d %H:%M:%S' }
                 <img  src="./images/on.png">
                 {assign var="tog" value='1'}
                {elseif $gate.gateway_code eq 'YMN-1' && $gate.gateway_code eq $List.gateway_code && $gate.gateway_date_time lt $dateSec1|date_format:'%Y-%m-%d %H:%M:%S'}
                <img  src="./images/off.png">
                 {assign var="tog" value='1'}
                {/if}
               
                {/foreach}
                {if $tog eq ''}
                <img  src="./images/off.png">
                {/if}
                 {assign var="tog" value=''}
                </td>-->
				
				
			
                 
             {foreach from=$CostKWH item=costKwh}
					 {if $costKwh.sensor_code eq $List.sensor_code}
					               {assign var="tkwh" value=$tkwh+$costKwh.TOTAL_KWH}
             						{assign var="tcost" value=$tcost+$costKwh.cost}

                 <td align="right">{$costKwh.TOTAL_KWH} </td>
                 <td align="right">{$costKwh.cost} </td>
                  {/if}
                  {foreachelse}
                  <td align="right">0.00</td>
                 <td align="right">0.00</td>
				  {/foreach}
				  <td>{$List.recorded_date_time|date_format:"%d-%b-%Y %I:%M:%S %p"}</td>
		       <td id="{$j}"><script type="text/javascript">secondsToDhms('{$List.secs}','{$j}');</script> ago</td>
			   
            
                </tr>
                {foreachelse}
                <tr><td colspan="8"><center>No Records Found</center></td></tr>
                {/foreach}
               
               
                </tbody>
                
                     <tr>
                    <td colspan="4" align="right"><b>Total</b></td>
                    <td align="right"><b><span id="tk"><script type="text/javascript">includecomma1('{$tkwh}','tk');</script></span></b></td>
                    <td align="right"><b> <span id="tc"><script type="text/javascript">includecomma1('{$tcost}','tc');</script></span></b></td>
                    <td colspan="2"></td>
                    </tr>
              </table>
              </div>
        
</form>

</div>

</div>
									<div class="card-body table-responsive">

            <div class="row">

          
        </div>

        </div>


								

        

        

	  

	   

        


      </div>

    </div>

  </div>

  </div>

  </div>

  </div>
</body>
 {literal}
 
 <style>
  .slNo
 {
 width:3%;
 }
 .name
 {
 width:35%;
 }
 .gate
 {
 width:10%;
 }
 .status
 {
 width:5%;
 }
 .code
 {
 width:10%;
 }
 .cost
 {
 width:5%;
 }
 .action
 {
 width:15%;
 }
 .last
 {
 width:11%;
 }
 .uline
 {
 text-decoration:underline;
 }
 </style>
  <script type="text/javascript">
  
  function submitButtonFun(){
 		var fromDate = document.getElementById("fromDate").value;
		var toDate = document.getElementById("toDate").value;
	//$(".error").remove();
	if((fromDate!='' || toDate !='') )
	{
		if(fromDate =='')
		{
			alert("Please Specify From Date");
			document.getElementById("fromDate").style.borderColor="red";
			return false;
		}
		else if(toDate =='')
		{
			alert("Please Specify To Date");
			document.getElementById("toDate").style.borderColor="red";
			return false;
		}
		else if(fromDate > toDate)
		{
			alert("Do Not enter From Date greater than to Date");
			document.getElementById("fromDate").style.borderColor="red";
			return false;
		}
		else
		{
		document.getElementById("meterList").submit();
		}
	}
  }
  
 </script>
<script type="text/javascript">
	function get_excel(){
		var fromDate = document.getElementById("fromDate").value;
		var toDate = document.getElementById("toDate").value;
		var parentid = document.getElementById("parentid").value;
	
	if((fromDate!='' || toDate !='') )
	{
	if(fromDate =='')
	{
		alert("Please Specify From Date");
		document.getElementById("fromDate").style.borderColor="red";
		return false;
	}
	else if(toDate =='')
	{
		alert("Please Specify To Date");
		document.getElementById("toDate").style.borderColor="red";
		return false;
	}
	else if(fromDate > toDate)
	{
		alert("Do Not enter From Date greater than to Date");
		document.getElementById("fromDate").style.borderColor="red";
		return false;
	}
	}
	window.location.href="main_energy_meter_xl.php?fromDate="+fromDate+"&toDate="+toDate;
	}
	</script>
 {/literal}

  {include file="footer.tpl"}

