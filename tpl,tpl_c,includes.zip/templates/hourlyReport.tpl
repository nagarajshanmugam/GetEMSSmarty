	<div class="content-wrapper">
	<section class="content-header">
		<div class="card">
			<div class="card-header">
				<table style="margin-bottom:-10px;">
				<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
				 <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
						  <td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>
				<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:15PX;font-weight: bold;">Hourly Report</font>&nbsp;</td></tr>
				<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="font-size:10PX;color:#999999;">Branch Name</td>
				<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
				</tr>
				</table>
			</div>
		</div>
		<form name="meterList" method="post" id="meterList">
		<div class="row">
			<div class="col-12">
				<div class="card">
				{if $SuccessMessage neq "" || $ErrorMessage neq ""}
					<div class="card-body">
					{if $SuccessMessage neq ""}
						<div class="isa_success">
						<i class="fa fa-check"></i>
						{$SuccessMessage}		 
						</div>
					{/if}
					{if $ErrorMessage neq ""}
						<div class="isa_error">
						<i class="fa fa-check"></i>
						{$ErrorMessage}		 
						</div>
					{/if}
					</div>
				{/if}
					<div class="card-body table-responsive">
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#" onClick="get_excel();" style="float:right;margin-top:12PX"><img src="images/excel1.png"  height="26" width="26" alt="Excel" title="Xls Download" ></a>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<div class="col-sm-3"  style="float:right;margin-top:12PX">
						<select class="form-control" id="sensorName" name="sensorName"  tabindex="1"  >
						{if $smarty.post.sensorName eq ''}
						<option value="">--  Select Feeder  --</option>
						{/if}
						{foreach from=$ListSensorShift item=ListMod}
						{if $smarty.post.sensorName eq $ListMod.sensorCode}<option value="{$ListMod.sensorCode}" selected="selected">{$ListMod.sensorName}</option>{/if}
						{if $smarty.post.sensorName neq $ListMod.sensorCode}<option value="{$ListMod.sensorCode}">{$ListMod.sensorName}</option>{/if}
						{/foreach}
						</select>
						</div>&nbsp;&nbsp;<div class="col-sm-2"  style="float:right;margin-top:-7PX" > To Date: <input type="text" id="toDate" name="toDate" value="{if $smarty.post.sensorName neq '' && $smarty.post.toDate eq ''}{$smarty.now|date_format:'%Y-%m-%d'}{elseif $smarty.post.sensorName neq '' && $smarty.post.toDate neq ''}{$smarty.post.toDate}{/if}" class="form-control" autocomplete="off" readonly="true"></div>
					{if $ListPostData.0.recorded_date eq ''}<p>&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;<br /></p>{/if}
					<table id="example" class="table table-bordered table-hover">
					<thead>
					<tr>
					<th class="slNo">#</th>
					<th class="">Start Date Time</th>
					<th class="">End Date Time</th>
					<th class="">Start Kwh</th>
					<th class="">End Kwh</th>
					<th class="">Total Kwh</th>
					<th class="">Unit Rate</th>
					<th class="">Total Cost</th>
					</tr>
					</thead>
					<tbody>
					{assign var=consKwh value=''}
					{assign var=consCost value=''}
					{foreach from=$ListHourlyRep item=List}
					{assign var=consKwh value=$consKwh+$List.consuption_kwh}
					{assign var=consCost value=$consCost+$List.consuption_cost}
					<tr id="{$j++}">
					<td >{$j}</td>
					<td>{$List.start_date_time|date_format:"%e-%b-%Y %I:%M %p"}</td>
					<td>{$List.end_date_time|date_format:"%e-%b-%Y %I:%M %p"}</td>
					<td id="skwh{$j}"><script type="text/javascript">includecomma1('{$List.start_cum_kwh}','skwh{$j}');</script></td>
					<td id="ekwh{$j}"><script type="text/javascript">includecomma1('{$List.end_cum_kwh}','ekwh{$j}');</script></td>
					<td id="ckwh{$j}"><script type="text/javascript">includecomma1('{$List.consuption_kwh}','ckwh{$j}');</script></td>
					<td id="cost{$j}"><script type="text/javascript">includecomma1('{$List.unit_rate}','cost{$j}');</script></td>
					<td id="ccost{$j}"><script type="text/javascript">includecomma1('{$List.consuption_cost}','ccost{$j}');</script></td>
					
					</tr>
					{foreachelse}
					<tr><td colspan="8"><center>No Records Found</center></td></tr>
					{/foreach}
					{if $j>0}<tr >
					<td ></td>
					<td></td>
					<td></td>
					<td></td>
					<td>Total</td>
					<td >{$consKwh}</td>
					<td ></td>
					<td >{$consCost}</td>
					
					</tr>
					{/if}
					</tbody>
					</table>
					</div>
				
				<!-- /.card-body -->
				</div>
			<!-- /.card -->
			</div>
		</form>
	</section>
	<!-- /.content -->
	</div>
	<!-- /.content-wrapper -->
	{literal}
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	<link rel="stylesheet" href="/resources/demos/style.css">
	<!--  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	-->  <script>
	$( function() {
	
	$( "#toDate" ).datepicker({changeMonth: true,
	"setDate": new Date(),
	changeYear: true,maxDate: '0',dateFormat:'yy-mm-dd'}).datepicker("setDate", "{/literal}{if $smarty.post.toDate neq ''}{$smarty.post.toDate}{else}0{/if}{literal}");
	} );
	</script>
	<script type="text/javascript">
	
	$(document).ready(function() {
	$('#sensorName').on('change', function() {
	this.form.submit();
	});
	});
	
	</script>
	<script type="text/javascript">
	function get_excel(){
		var sensorName = document.getElementById("sensorName").value;
		var toDate = document.getElementById("toDate").value;
	alert("Are You Sure want to download Excell Report");
	if(sensorName =='')
	{
		alert("Please Select any one Sensor to Download Report");
		document.getElementById("sensorName").style.borderColor="red";
		return false;
	}
	else if(toDate =='')
	{
		alert("Please Specify To Date");
		document.getElementById("toDate").style.borderColor="red";
		return false;
	}
	//alert(sensorName+' , '+toDate);
	window.location.href="hrly_report_xl.php?sensorCode="+sensorName+"&date1="+toDate;
	
	}
	</script>
	<style>
	.slNo{
	width:5%;
	}
	.code{
	width:10%;
	}
	.apiKey{
	width:30%;
	}
	.name{
	width:40%;
	}
	.isactive{
	width:10%;
	text-align:center;
	
	}
	.action{
	text-align:right;
	}
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	/*background-color:#FFBABA;*/
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	/*vertical-align:middle;*/
	}
	</style>
	<script type="text/javascript">
	$(document).ready(function (){
	
	var table = $('#example').DataTable({
	"ordering" : false,
	"pageLength": 50,
	language: {
	"infoFiltered": "",
	search: "_INPUT_",
	searchPlaceholder: "Search..."
	},
	//dom: '<"pull-left" f><bottom>p',
	dom: '',
	tableTools: {
	"sSwfPath": "media/swf/copy_csv_xls_pdf.swf"
	},
	//dom: '<"pull-left"lf> <"pull-right"<"toolbar">> <"pull-right"<"toolbar2">>rti<"bottom">p',
	//dom: '<"pull-left"f><"pull-right" <"row" <"col-md-4" <"toolbar">><"col-md-4"<"toolbar">><"col-md-4" <"toolbar">>>>rti<"bottom">p',
	
	initComplete: function(){
	//  $("div.toolbar").html('<a href="AddEditcompany.php.php"><button type="button" style="margin-top:-8PX" class="btn btn-create">Create Company</button></a><br>');   
	
	
	}       
	}); 
	
	}); 
	
	function editCats(recordedDate,sensorCode,userName) 
	{
	var sid = recordedDate;
	var mid = sensorCode;  
	var comId = userName; 
	$.ajax({
	type: "POST",
	url: "cronEnergyMeterData.php",
	data: {recorded_date:recordedDate,sensor_code:sensorCode,userName:userName},
	dataType: "text",
	cache: false,
	success: function(result){
	var len = result.length;
	//$("#testDate").val(result);
	//alert(result);
	location.reload(true);
	},
	error: function(result) {
	alert('error');
	}
	});
	}
	
	</script>
	<script type="text/javascript">
	function deleteCats(slNoIdent,serialIdIdent,compIdent,branIdent,gateIdent){
	var sid = btoa(slNoIdent); var scId = btoa(serialIdIdent);var comId = btoa(compIdent); var gId = btoa(gateIdent);var bId = btoa(branIdent);
	if(confirm("Are you sure to Delete this Content?")){
	FormName		= document.meterList;
	FormName.action= 'sensorList.php?gatewayId='+gId+'&companyId='+comId+'&branchId='+bId+'&sl_no='+sid+'&sen_code='+scId;
	FormName.submit();
	}
	}
	
	</script>
	{/literal}
	{include file="footer.tpl"}