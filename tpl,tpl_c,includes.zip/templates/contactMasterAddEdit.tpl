<div class="content-wrapper">
<section class="content-header">
	<div class="card">
		<div class="card-header">
			<table style="margin-bottom:-10px;">
			<tr><td style="font-size:15PX;font-weight: bold;">{if $companyDetail.0.companyName neq ""}{$companyDetail.0.companyName}{else}{$smarty.session.CompanyName}{/if}&nbsp;&nbsp;</td>
			{if $branchDetail.0.branch_name neq ''}  <td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td style="font-size:15PX;font-weight: bold;">{$branchDetail.0.branch_name}&ensp;&ensp;</td>{/if}
			<td style="font-size:15PX;font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;</td>
			<td style="font-size:15PX;font-weight: bold;">{if $smarty.get.sl_no eq ""}Create Alert Contact {else}Edit Alert Contact {/if}</font>&nbsp;</td></tr>
			<tr><td style="font-size:10PX;color:#999999;">Company Name</td>
			<td style="font-size:10PX;font-size:15PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
			<td style="font-size:10PX;color:#999999;">Branch Name</td>
			<td style="font-size:10PX;color:#999999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
			<td style="color:#999999;font-size:10PX;"></td><td>&nbsp;</td>
			</tr>
			</table>
		<a href="contactMasterList.php?companyId={$smarty.get.companyId}&branchId={$smarty.get.branchId}"><button type="button" style="float:right;margin-top:-40PX" class="btn btn-primary">List Alert Contact</button></a>
		</div>
	</div>
<div class="card">
	<div class="card-body">
		<form role="form" name="alertContactRegForm" id="alertContactRegForm" method="post" onsubmit="return createValidation();" >
			<input type="hidden" name="hdAction" />
			<input type="hidden" id="check_id" name="check_id" value="{$smarty.post.check_id}">
			<input type="hidden" id="checkVal" name="checkVal" value="{$smarty.post.checkVal}" />
			<input type="hidden" id="checkSms" name="checkSms" value="{$smarty.post.checkSms}" />
			<input type="hidden" id="checkEmail" name="checkEmail" value="{$smarty.post.checkEmail}" />
			<input type="hidden" id="company_id" name="company_id" value="{$comId}" />
			<div class="row">
				<div class="col-md-6">
					<div class="form-group">
					<label for="exampleInputpersonName">Person Name <span style="color:red;">*</span></label>
					<input type="text" class="form-control form-control-sm" id="personName" name="personName" placeholder="Enter Person Name" onkeyup="text_filter(this);" value="{if $ListEditView.0.person_name neq ""}{$ListEditView.0.person_name}{/if}" tabindex="1">
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<div class="form-group ">
					<label for="exampleInputmobile">Mobile <span style="color:red;">*</span></label>
					<input type="text" class="form-control form-control-sm" id="mobile" name="mobile" maxlength="10" placeholder="Enter Mobile Number" onkeyup="numericFilter(this);" value="{if $ListEditView.0.mobile neq ""}{$ListEditView.0.mobile}{/if}" tabindex="2">
					</div>
				</div>
				<div class="form-group row" style="margin-top:40px;">
				&ensp; &ensp; &ensp;
					<div class="custom-control custom-switch">
					{if $ListEditView.0.sms_alert eq '1'}
						<input type="checkbox" class="custom-control-input" id="customCheckbox3" name="customCheckbox3" checked="checked" tabindex="4">
					{elseif $ListEditView.0.sms_alert eq '0'}
						<input type="checkbox" class="custom-control-input" id="customCheckbox3" name="customCheckbox3" tabindex="4">
					{else}
						<input type="checkbox" class="custom-control-input" id="customCheckbox3" name="customCheckbox3" checked="checked" tabindex="4">
					{/if}
						<label class="custom-control-label" for="customCheckbox3">Sms Alert</label>
					</div>
				</div>
			</div>
			<div class="row">
				<div class=" col-md-6" >
					<div class="form-group">
					<label for="exampleInputemail">Email <span style="color:red;">*</span></label>
					<input type="text" class="form-control form-control-sm" id="email" name="email" placeholder="Enter Email"  value="{if $ListEditView.0.email neq ""}{$ListEditView.0.email}{/if}" tabindex="3">
					</div>
				</div>
				<div class="form-group row" style="margin-top:40px;">
				&ensp; &ensp; &ensp;
					<div class="custom-control custom-switch">
					{if $ListEditView.0.email_alert eq '1'}
						<input type="checkbox" class="custom-control-input" id="customCheckbox4" name="customCheckbox4" checked="checked" tabindex="4">
					{elseif $ListEditView.0.email_alert eq '0'}
						<input type="checkbox" class="custom-control-input" id="customCheckbox4" name="customCheckbox4" tabindex="4">
					{else}
						<input type="checkbox" class="custom-control-input" id="customCheckbox4" name="customCheckbox4" checked="checked" tabindex="4">
					{/if}
						<label class="custom-control-label" for="customCheckbox4">Email Alert</label>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<div class="form-group row" >
					&ensp; &ensp; &ensp;
						<div class="custom-control custom-checkbox">
						{if $ListEditView.0.is_active eq '1'}
							<input class="custom-control-input" type="checkbox" id="customCheckbox2"  name="customCheckbox2" tabindex="4" checked="checked" tabindex="4">
							<label for="customCheckbox2" class="custom-control-label">Is Active</label>
						{elseif $ListEditView.0.is_active eq '0'}
							<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="4" tabindex="4">
							<label for="customCheckbox2" class="custom-control-label">Is Active</label>
						{else}
							<input class="custom-control-input" type="checkbox" id="customCheckbox2" name="customCheckbox2" tabindex="4" checked="checked" tabindex="4">
							<label for="customCheckbox2" class="custom-control-label">Is Active</label>
						{/if}
						</div>
						<input id="created_by" name="created_by" class="date-picker form-control" type="hidden" value="{$smarty.session.UserName}" readonly="true">
						<input type="hidden" class="form-control" id="timestamp" name="timestamp" value="{$smarty.now|date_format:'%Y-%m-%d %H:%M:%S'}">
						<input type="hidden" class="form-control" id="created_time" name="created_time" placeholder="Time" Value="{$smarty.now|date_format:'%H:%M:%S'}">
					</div>
				</div>			
			</div>
			<div  align="center">
			<center>
				<input type="submit" value="Submit" class="btn btn-create" tabindex="5" />
			</center>
			</div>
		</form>
	</div>
</div>
</section>
</div>
{literal}
	<script type="text/javascript">
	function createValidation(){
	var personName = $('#personName').val();
	var mobile = $('#mobile').val();
	var email = $('#email').val();
	var isActive = document.getElementById("customCheckbox2").checked;
	var smsAlert = document.getElementById("customCheckbox3").checked;
	var emailAlert = document.getElementById("customCheckbox4").checked;
	
	if (isActive == false) 
	{
		document.getElementById('checkVal').value='0';
	}
	else
	{
		document.getElementById('checkVal').value='1';
	}
	if (smsAlert == false) 
	{
		document.getElementById('checkSms').value='0';
	}
	else
	{
		document.getElementById('checkSms').value='1';
	}
	if (emailAlert == false) 
	{
		document.getElementById('checkEmail').value='0';
	}
	else
	{
		document.getElementById('checkEmail').value='1';
	}
	$(".error").remove();
	if (personName.length < 1) {
		$('#personName').after('<span class="error">This field is required</span>');
		$('#personName').focus();
		return false;					
	}
	else if (mobile.length < 1) {
		$('#mobile').after('<span class="error">This field is required</span>');
		$('#mobile').focus();
		return false;					
	}
	else if (mobile.length < 10) {
		$('#mobile').after('<span class="error">Mobile Number should be 10 digits</span>');
		$('#mobile').focus();
		return false;					
	}
	else if (email.length < 1) {
		$('#email').after('<span class="error">This field is required</span>');
		$('#email').focus();
		return false;					
	}
		var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
		var inputText=document.getElementById('email');  
	if(inputText.value.match(mailformat))  
	{  
		document.form1.text1.focus();  
		return true;  
	}  
	else  
	{
		$('#email').after('<span class="error">You have entered an invalid email address!</span>');
		$('#email').focus();
		return false;
	} 
		FormName		= document.alertContactRegForm;
		FormName.method	= "POST";
		FormName.submit();
	}
	function GoBack()
	{
		window.history.back();
	}
	</script>
	<script>
	function numericFilter(data)
	{
	data.value = data.value.replace(/[^.0-9^.+,-]/ig,"");
	}
	function text_filter(data)
	{
	data.value = data.value.replace(/[^ .a-z]/ig,"");
	
	}
	</script>
	<script  type="text/javascript">
	function ValidateEmail()  
	{ 
		var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
		var inputText=document.getElementById('email');  
	if(inputText.value.match(mailformat))  
	{  
		document.form1.text1.focus();  
		return true;  
	}  
	else  
	{
		$('#email').after('<span class="error">You have entered an invalid email address!</span>');
		$('#email').focus();
		return false;
	} 
	}
	</script>
	<style>
	.isa_success
	{
	color:#4F8A10;
	background-color:#DFF2BF;
	}
	.error
	{
	color:#D8000C;
	}
	.isa_error
	{
	color:#D8000C;
	background-color:#FFBABA;
	}
	.isa_success i,.isa_error i
	{
	margin:10px 22px;
	font-size:2em;
	}
	.required
	{
	color:#FF0000;
	}
	</style>
{/literal}
{include file="footer.tpl"}