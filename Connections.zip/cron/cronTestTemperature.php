<?php
$min1=21.0;
$max1=28.0;
$num1 = mt_rand ($min1*10, $max1*10) / 10;
//echo $num1;echo "<br>";


$min2=69.8;
$max2=82.4;
$num2 = mt_rand ($min2*10, $max2*10) / 10;
//echo $num2;echo "<br>";

$min3=55.0;
$max3=60.0;
$num3 = mt_rand ($min3*10, $max3*10) / 10;
//echo $num3;echo "<br>";
date_default_timezone_set('Asia/Kolkata');
//echo date('d-m-Y H:i:s');
$fvar='[{"ID":"1","apiKey":"R1c6UlVUOTU1LTMvU0k6TUQwMi0xL1NNT0RFTDpNRDAy" ,"ST":"1","TS":"'.time().'","DT":"'.date("d/m/Y H:i:s").'","VR":"['.round($num1,1).','.round($num2,2).','.round($num3,2).']"}]';
//echo date().",".$fvar;exit;



/***********************************************/
$hostname_arkaems = "148.66.130.228";
$database_arkaems = "arkaauto_emslte";
$username_arkaems = "arkaauto_emslte_user";
$password_arkaems = "@M5!+@2o2i";
//$arkaerp = mysql_connect($hostname_arkaems, $username_arkaems, $password_arkaems) or trigger_error(mysql_error(),E_USER_ERROR);
//mysql_select_db($database_arkaems, $arkaerp) or die(mysql_error());


         $inputJSON = $fvar;
         $input= json_decode( $inputJSON, true); 
         
 //echo $inputJSON."<br>";
// print_r($input);
 // echo "<br>ia ma";
   // $api_key = test_input($_POST["api_key"]);
     $conn = new mysqli($hostname_arkaems, $username_arkaems, $password_arkaems, $database_arkaems);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } 
    $sqlSensor = "SELECT * FROM arka_sensor_master WHERE isActive='1' AND status='1' AND api_key='".$input[0]['apiKey']."'";
    $insSel = $conn->query($sqlSensor);
	
     $result = mysqli_query($conn, $sqlSensor);
	//  echo $input[0]['apiKey']." :apikeydecode<br>";

       
      

       
  if (mysqli_num_rows($result) > 0) {
          
       
        
         // Create connection
		   $apikeyDecd= base64_decode($input[0]['apiKey']);
	 
	  $apiDec =explode("/", $apikeyDecd);
	   $gatewayCode=str_replace("GW:","",$apiDec[0]);
	   $sensorCode=str_replace("SI:","",$apiDec[1]);
	  $sensorModel=str_replace("SMODEL:","",$apiDec[2]);
          $jsonDecd= str_replace(array('[', ',]', ']'), '', $input[0]['VR']);

           $str_arr= explode (",", $jsonDecd); 
          // $str_arr = explode (",", $jsonDecd);  
           $temp_c=$str_arr[0];
           $temp_f=$str_arr[1];
           $hum=$str_arr[2];
           
         $liuxTimeStamp=$input[0]['TS'];
		 
          if($liuxTimeStamp !="XXXXXX")
          {
              
             
              $recordedTimeStamp = date("Y-m-d H:i:s",$input[0]['TS']);
              $telDate =$input[0]['DT'];
              $teltonika_date = str_replace('/', '-', $telDate);
              $teltonikaTimeStamp =  date('Y-m-d H:i:s', strtotime($teltonika_date));
             
          }
          else
          {
              $liuxTimeStamp='';
              $recordedTimeStamp = ''; 
			  $teltonikaTimeStamp='';
          
          }
           
     
      $sql = "INSERT INTO temperature_data_master (gateway_code,sensor_code,sensor_model,temperature_c,temperature_f,humidity,VR_ARRAY_VALUE,`linux_date_time`,`teltonika_date_time`, `recorded_date_time`, `posted_date_time`) VALUES ('".$gatewayCode."','".$sensorCode."','".$sensorModel."','".$temp_c."','".$temp_f."','".$hum."','".$inputJSON."','".$liuxTimeStamp."','".$input[0]['DT']."','".$teltonikaTimeStamp."', DATE_ADD(NOW(),INTERVAL '00:00' HOUR_MINUTE))"; 
     // echo $sql;exit;
        $insSel = $conn->query($sql);
     
        
        if ($insSel === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
		
		
		
		$selectView= "SELECT * FROM `temperature_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."'";
	//	echo $selectView;
       $resultView = mysqli_query($conn, $selectView);
	   $rowcount=mysqli_num_rows($resultView);
	   
	   if($rowcount==0){
	          $sql2= "INSERT INTO temperature_data_master_view (gateway_code,sensor_code,sensor_model,temperature_c,temperature_f,humidity,VR_ARRAY_VALUE,`linux_date_time`,`teltonika_date_time`, `recorded_date_time`, `posted_date_time`) VALUES ('".$gatewayCode."','".$sensorCode."','".$sensorModel."','".$temp_c."','".$temp_f."','".$hum."','".$inputJSON."','".$liuxTimeStamp."','".$input[0]['DT']."','".$teltonikaTimeStamp."', DATE_ADD(NOW(),INTERVAL '00:00' HOUR_MINUTE))";
      }else{
	  	          $sql2= "UPDATE `temperature_data_master_view` SET `temperature_c`='".$temp_c."',`temperature_f`='".$temp_f."',humidity='".$hum."',VR_ARRAY_VALUE='".$inputJSON."', `linux_date_time`='".$liuxTimeStamp."', teltonika_date_time='".$input[0]['DT']."',`recorded_date_time`='".$teltonikaTimeStamp."', `posted_date_time`=CONVERT_TZ(NOW(),'+00:00','+00:00') WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."'";

	  
	  }
	//  echo $sql2;
        $insSel2 = $conn->query($sql2);
     
        
        if ($insSel2 === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $sql2 . "<br>" . $conn->error;
        }
       
        $conn->close();
    
 }
    else {
        echo "Wrong API Key provided.";
    }


?>