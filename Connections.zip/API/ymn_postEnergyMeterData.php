<?php

/*
  Rui Santos
  Complete project details at https://RandomNerdTutorials.com/esp32-esp8266-mysql-database-php/
  
  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files.
  
  The above copyright notice and this permission notice shall be included in all
  copies or substantial portions of the Software.
*/

//namespace PortoContactForm;

session_cache_limiter('nocache');
header('Expires: ' . gmdate('r', 0));

header('Content-type: application/json');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'php/php-mailer/src/PHPMailer.php';
require 'php/php-mailer/src/SMTP.php';
require 'php/php-mailer/src/Exception.php';

//echo  "hai"; exit;
require_once('../Connections/ARKAEMS.php'); 
$servername = $hostname_arkaems;

// REPLACE with your Database name
$dbname = $database_arkaems;
// REPLACE with Database user
$username = $username_arkaems;
// REPLACE with Database user password
$password = $password_arkaems;

/*$servername = "166.62.10.227";

// REPLACE with your Database name
$dbname = "emslte";
// REPLACE with Database user
$username = "emslte";
// REPLACE with Database user password
$password = "emslte@2020";*/
 
//exit;


// Keep this API Key value to be compatible with the ESP32 code provided in the project page. 
// If you change this value, the ESP32 sketch needs to match

//echo "hai"; exit;
   if ($_SERVER["REQUEST_METHOD"] == "POST") {
         $inputJSON = file_get_contents('php://input');
         $input= json_decode( $inputJSON, true); 
		// print_r($input);exit;
 // $api_key = test_input($_POST["api_key"]);
     $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } 
		
	
   $sqlSensor = "SELECT * FROM arka_sensor_master WHERE isActive='1' AND status='1' AND `gateway_id` LIKE '%YMN%' AND modbus_slave_id='".$input['sid']."'"; 
    $insSel = $conn->query($sqlSensor);
	
     $result = mysqli_query($conn, $sqlSensor);
	 $sensMasDet = mysqli_fetch_assoc($result);
	$recordedTimeStamp = date("Y-m-d H:i:s",strtotime($input['dtm']));
	
	$insGateLog	="INSERT INTO `gateway_ping_log`(`gateway_code`, `gateway_date_time`, `json_data`, `ping_date_time`) VALUES ('".$sensMasDet["gateway_id"]."','".$recordedTimeStamp."','".$inputJSON."', NOW())";		
			 $insGLog = $conn->query($insGateLog);
      

       	$apikeyDecd= base64_decode($input['apiKey']);
	 
	  $apiDec =explode("/", $apikeyDecd);
	   $gatewayCode=$sensMasDet["gateway_id"];//echo $gatewayCode;exit;
       $sensorCode=$sensMasDet["sensorCode"];
	   $sensorModel=$sensMasDet["sensorModel"];
      

       
  if (mysqli_num_rows($result) > 0) {
          
       
        
         // Create connection
	   

           /*$jsonDecd= str_replace(array('[', ',]', ']'), '', $input[0]['VR']);
           $str_arr= explode (",", $jsonDecd); */
		  
          // echo $input[0]['VR']."<br>"; print_r($str_arr); 
           
           
           if($sensorModel =='T3DS'){
		   
           /********************   Elmeasure 3 Phase variables   *********************/
		   
           $KW=$input['KW']/100;  //date post in database with calculated data from watts to kilo watts
           $Sys_PF=$input['Sys_PF']/1000;  //Date Just display Here Not inserted
           $Avg_VLL=$input['Avg_VLL']/100;  //Date Just display Here Not inserted
           $Avg_VLN=$input['Avg_VLN']/100;  //Date Just display Here Not inserted
           $Avg_Amps=$input['Avg_Amps']/100;  //date post in database with calculated data from watts to kilo watts
           $EB_KWh=$input['EB_KWh']/100;  //Date Just display Here Not inserted
           $Hz=$input['Hz']/100;  //Date Just display Here Not inserted
           $VRY=$input['VRY']/100;  //Date Just display Here Not inserted
           $VYB=$input['VYB']/100;  //date post in database 
           $VBR=$input['VBR']/100;  //Date Just display Here Not inserted
		   $VRN=$input['VRN']/100;  //Date Just display Here Not inserted
           $VYN=$input['VYN']/100;  //Date Just display Here Not inserted
           $VBN=$input['VBN']/100;  //Date Just display Here Not inserted
           $IR=$input['IR']/100;  //date post in database with calculated data from watts to kilo watts
           $IY=$input['IY']/100;  //Date Just display Here Not inserted
           $IB=$input['IB']/100;  //Date Just display Here Not inserted
           $DG_KWH=$input['DG_KWH']/100;  //Date Just display Here Not inserted
           $On_Hour=$input['On_Hour']/1;  //Date Just display Here Not inserted
           $On_Min=$input['On_Min']/1;  //date post in database
           $KVA=$input['KVA']/100;  //date post in database
           $EB_KVAH=$input['EB_KVAH']/100;  //date post in database
           $EB_Run_Hour=$input['EB_Run_Hour']/1;  //Date Just display Here Not inserted
           $EB_Run_Min=$input['EB_Run_Min']/1;  //date post in database
           $DG_KVAH=$input['DG_KVAH']/100;  //date post in database
           $DG_Run_Hour=$input['DG_Run_Hour']/1;  //date post in database
           $DG_Run_Min=$input['DG_Run_Min']/1;  //date post in database
           $EB_DG_STATUS=$input['EB_DG_STATUS'];  //Date Just display Here Not inserted
		  /* if($EB_DG_STATUS==2)
		   {
		   $EB_DG_STATUS="EB";
		   
		   }else
		   {
		   $EB_DG_STATUS="DG";
		   }
           */
           $R_VOLTAGE=$VRN;
           $Y_VOLTAGE=$VYN;
           $B_VOLTAGE=$VRN;
		   $RY_VOLTAGE=$VRY;
		   $YB_VOLTAGE=$VYB;
		   $BR_VOLTAGE=$VBR;
		   $R_CURRENT=$IR;
		   $Y_CURRENT=$IY;
		   $B_CURRENT=$IB;
		   $SUM_KVA=$KVA;
		   $SUM_KW=$KW;
		   $SUM_KVAR='';
		   $SUM_PF=$Sys_PF;
		   $FREQUENCY=''; 
		   $KWH_MSB='';
		   $KWH_LSB='';
		   $KWH=$EB_KWh;
		   $METER_TYPE_RUN_HOUR_MSB='';
		   $RUN_HOUR_LSB='';
		   $RUN_HOUR=$On_Hour;
		   $IMPORT_EXPORT='';
		   $DG_KWH=$DG_KWH;
		   $DG_KVAH=$DG_KVAH;
		   $DG_Run_Hour=$DG_Run_Hour;
		   $DG_Run_Min=$DG_Run_Min;
		   $EB_DG_Status=$EB_DG_STATUS;
           
		   if(isset($input['VR'])){
		       $VR_ARRAY_VALUE=$input['VR'];
		   }
		   else
		   {
		       $VR_ARRAY_VALUE=''; 
		   }

           
		   
		   }elseif($sensorModel =='TE'){
		   
           /********************   Trinity Entity  variables   *********************/
           $KW=$input['KWH']/100;  //date post in database with calculated data from watts to kilo watts
		   
		   
           $R_VOLTAGE='';
           $Y_VOLTAGE='';
           $B_VOLTAGE='';
		   $RY_VOLTAGE='';
		   $YB_VOLTAGE='';
		   $BR_VOLTAGE='';
		   $R_CURRENT='';
		   $Y_CURRENT='';
		   $B_CURRENT='';
		   $SUM_KVA='';
		   $SUM_KW='';
		   $SUM_KVAR='';
		   $SUM_PF='';
		   $FREQUENCY=''; 
		   $KWH_MSB='';
		   $KWH_LSB='';
		   $KWH=$KW;
		   $METER_TYPE_RUN_HOUR_MSB='';
		   $RUN_HOUR_LSB='';
		   $RUN_HOUR='';
		   $IMPORT_EXPORT='';
		   $DG_KWH='';
		   $DG_KVAH='';
		   $DG_Run_Hour='';
		   $DG_Run_Min='';
		   $EB_DG_Status='';
           
		   if(isset($input['VR'])){
		       $VR_ARRAY_VALUE=$input['VR'];
		   }
		   else
		   {
		       $VR_ARRAY_VALUE=''; 
		   }		   
		   }
          // $temp_c=$str_arr[0];
          // $temp_f=$str_arr[1];
          // $hum=$str_arr[2];
         // $liuxTimeStamp=$input['dtm'];
          $liuxTimeStamp=strtotime($input['dtm']);
		 
          if($liuxTimeStamp !="XXXXXX")
          {
             
             $recordedTimeStamp = date("Y-m-d H:i:s",strtotime($input['dtm']));
              $telDate =$input['dtm'];
              $teltonika_date = str_replace('/', '-', $telDate);
              $teltonikaTimeStamp =  date('d/m/Y H:i:s', strtotime($teltonika_date));
              
              
             
          }
          else
          {
              $liuxTimeStamp='';
              $recordedTimeStamp = ''; 
			  $teltonikaTimeStamp='';
          
          }
           
    // $sql= "INSERT INTO `energy_data_master`(`gateway_code`, `sensor_code`, `sensor_model`,`R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`, `SUM_PF`, `FREQUENCY`, `KWH_MSB`, `KWH_LSB`, `KWH`, `METER_TYPE_RUN_HOUR_MSB`, `RUN_HOUR_LSB`, `RUN_HOUR`, `IMPORT_EXPORT`,`VR_ARRAY_VALUE`,`linux_date_time`,`teltonika_date_time`, `recorded_date_time`, `posted_date_time`) VALUES ('".$gatewayCode."','".$sensorCode."','".$sensorModel."','".$R_VOLTAGE."','".$Y_VOLTAGE."','".$B_VOLTAGE."','".$RY_VOLTAGE."','".$YB_VOLTAGE."','".$BR_VOLTAGE."','".$R_CURRENT."','".$Y_CURRENT."','".$B_CURRENT."','".$SUM_KVA."','".$SUM_KW."','".$SUM_KVAR."','".$SUM_PF."','".$FREQUENCY."','".$KWH_MSB."','".$KWH_LSB."','".$KWH."','".$METER_TYPE_RUN_HOUR_MSB."','".$RUN_HOUR_LSB."','".$RUN_HOUR."','".$IMPORT_EXPORT."','".$inputJSON."','".$liuxTimeStamp."',DATE_ADD('".$teltonikaTimeStamp."',INTERVAL '05:30' HOUR_MINUTE),DATE_ADD(FROM_UNIXTIME('".$liuxTimeStamp."','%Y-%m-%d %h:%i:%s'),INTERVAL '12:30' HOUR_MINUTE), DATE_ADD(NOW(),INTERVAL '12:30' HOUR_MINUTE))";
	
	 if($sensorModel =='TEP'){
	 $sql= " INSERT INTO `energy_data_master`(`gateway_code`, `sensor_code`, `sensor_model`,`R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`, `SUM_PF`, `FREQUENCY`, `KWH`, `DG_KWH`, `DG_KVAH`,`EB_DG_STATUS`, `VR_ARRAY_VALUE`, `AVG_VPN`, `AVG_VPP`, `AVG_I`, `PF_R`, `PF_Y`, `PF_B`, `KW_R`, `KW_Y`, `KW_B`, `KVAR_R`, `KVAR_Y`, `KVAR_B`, `KVA_R`, `KVA_Y`, `KVA_B`, `KW_RISING_DEMAND`, `KW_MAX_DEMAND`, `KVA_RISING_DEMAND`, `KVA_MAX_DEMAND`, `DG_KVARH`, `EB_KWH`, `EB_KVARH`, `EB_KVAH`, `3RD_HVR`, `5TH_HVR`, `7TH_HVR`, `9TH_HVR`, `11TH_HVR`, `13TH_HVR`, `15TH_HVR`, `THD_VR`, `3RD_HIR`, `5TH_HIR`, `7TH_HIR`, `9TH_HIR`, `11TH_HIR`, `13TH_HIR`, `15TH_HIR`, `THD_IR`, `3RD_HVY`, `5TH_HVY`, `7TH_HVY`, `9TH_HVY`, `11TH_HVY`, `13TH_HVY`, `15TH_HVY`, `THD_VY`, `3RD_HIY`, `5TH_HIY`, `7TH_HIY`, `9TH_HIY`, `11TH_HIY`, `13TH_HIY`, `15TH_HIY`, `THD_IY`, `3RD_HVB`, `5TH_HVB`, `7TH_HVB`, `9TH_HVB`, `11TH_HVB`, `13TH_HVB`, `15TH_HVB`, `THD_VB`, `3RD_HIB`, `5TH_HIB`, `7TH_HIB`, `9TH_HIB`, `11TH_HIB`, `13TH_HIB`, `15TH_HIB`, `THD_IB`, `DG_STATUS`, `linux_date_time`, `teltonika_date_time`, `recorded_date_time`, `posted_date_time`) VALUES ('".$gatewayCode."','".$sensorCode."','".$sensorModel."','".$Vrn."','".$Vyn."','".$Vbn."','".$Vry."','".$Vyb."','".$Vbr."','".$Ir."','".$Iy."','".$Ib."','".$System_KVA."','".$System_KW."','".$System_KVAR."','".$System_PF."','".$Frequency."','".$EB_KWh."','".$DG_KWh."','".$DG_KVAh."','".$DG_Status."','".$inputJSON."','".$Avg_Vpn."','".$Avg_Vpp."','".$Avg_I."','".$PF_R."','".$PF_Y."','".$PF_B."','".$KW_R."','".$KW_Y."','".$KW_B."','".$KVAR_R."','".$KVAR_Y."','".$KVAR_B."','".$KVA_R."','".$KVA_Y."','".$KVA_B."','".$KW_Rising_Demand."','".$KW_Max_Demand."','".$KVA_Rising_Demand."','".$KVA_Max_Demand."','".$DG_KVARh."','".$EB_KWh."','".$EB_KVARh."','".$EB_KVAh."','".$_3rd_HVr."','".$_5th_HVr."','".$_7th_HVr."','".$_9th_HVr."','".$_11th_HVr."','".$_13th_HVr."','".$_15th_HVr."','".$THD_Vr."','".$_3rd_HIr."','".$_5th_HIr."','".$_7th_HIr."','".$_9th_HIr."','".$_11th_HIr."','".$_13th_HIr."','".$_15th_HIr."','".$THD_Ir."','".$_3rd_HVy."','".$_5th_HVy."','".$_7th_HVy."','".$_9th_HVy."','".$_11th_HVy."','".$_13th_HVy."','".$_15th_HVy."','".$THD_Vy."','".$_3rd_HIy."','".$_5th_HIy."','".$_7th_HIy."','".$_9th_HIy."','".$_11th_HIy."','".$_13th_HIy."','".$_15th_HIy."','".$THD_Iy."','".$_3rd_HVb."','".$_5th_HVb."','".$_7th_HVb."','".$_9th_HVb."','".$_11th_HVb."','".$_13th_HVb."','".$_15th_HVb."','".$THD_Vb."','".$_3rd_HIb."','".$_5th_HIb."','".$_7th_HIb."','".$_9th_HIb."','".$_11th_HIb."','".$_13th_HIb."','".$_15th_HIb."','".$THD_Ib."','".$DG_Status."','".$liuxTimeStamp."','".$input['dtm']."','".$teltonikaTimeStamp."',NOW())";
    }else{
      $sql= "INSERT INTO `energy_data_master`(`gateway_code`, `sensor_code`, `sensor_model`,`R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`, `SUM_PF`, `FREQUENCY`, `KWH_MSB`, `KWH_LSB`, `KWH`, `METER_TYPE_RUN_HOUR_MSB`, `RUN_HOUR_LSB`, `RUN_HOUR`, `IMPORT_EXPORT`, `DG_KWH`, `DG_KVAH`, `DG_RUN_HOUR`, `DG_RUN_MIN`, `EB_DG_STATUS`, `VR_ARRAY_VALUE`,`linux_date_time`,`teltonika_date_time`, `recorded_date_time`, `posted_date_time`) VALUES ('".$gatewayCode."','".$sensorCode."','".$sensorModel."','".$R_VOLTAGE."','".$Y_VOLTAGE."','".$B_VOLTAGE."','".$RY_VOLTAGE."','".$YB_VOLTAGE."','".$BR_VOLTAGE."','".$R_CURRENT."','".$Y_CURRENT."','".$B_CURRENT."','".$SUM_KVA."','".$SUM_KW."','".$SUM_KVAR."','".$SUM_PF."','".$FREQUENCY."','".$KWH_MSB."','".$KWH_LSB."','".$KWH."','".$METER_TYPE_RUN_HOUR_MSB."','".$RUN_HOUR_LSB."','".$RUN_HOUR."','".$IMPORT_EXPORT."','".$DG_KWH."','".$DG_KVAH."','".$DG_Run_Hour."','".$DG_Run_Min."','".$EB_DG_Status."','".$inputJSON."','".$liuxTimeStamp."','".$teltonikaTimeStamp."','".$recordedTimeStamp."', NOW())";
	  }
	   
        $insSel = $conn->query($sql);
     
        
        if ($insSel === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
       
	   $selectView= "SELECT * FROM `energy_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."'";
       $resultView = mysqli_query($conn, $selectView);
	   $rowcount=mysqli_num_rows($resultView);
	   if($rowcount==0){
			if($sensorModel =='TEP'){
		 $sql2= " INSERT INTO `energy_data_master_view`(`gateway_code`, `sensor_code`, `sensor_model`,`R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`, `SUM_PF`, `FREQUENCY`, `KWH`, `DG_KWH`, `DG_KVAH`,`EB_DG_STATUS`, `VR_ARRAY_VALUE`, `AVG_VPN`, `AVG_VPP`, `AVG_I`, `PF_R`, `PF_Y`, `PF_B`, `KW_R`, `KW_Y`, `KW_B`, `KVAR_R`, `KVAR_Y`, `KVAR_B`, `KVA_R`, `KVA_Y`, `KVA_B`, `KW_RISING_DEMAND`, `KW_MAX_DEMAND`, `KVA_RISING_DEMAND`, `KVA_MAX_DEMAND`, `DG_KVARH`, `EB_KWH`, `EB_KVARH`, `EB_KVAH`, `3RD_HVR`, `5TH_HVR`, `7TH_HVR`, `9TH_HVR`, `11TH_HVR`, `13TH_HVR`, `15TH_HVR`, `THD_VR`, `3RD_HIR`, `5TH_HIR`, `7TH_HIR`, `9TH_HIR`, `11TH_HIR`, `13TH_HIR`, `15TH_HIR`, `THD_IR`, `3RD_HVY`, `5TH_HVY`, `7TH_HVY`, `9TH_HVY`, `11TH_HVY`, `13TH_HVY`, `15TH_HVY`, `THD_VY`, `3RD_HIY`, `5TH_HIY`, `7TH_HIY`, `9TH_HIY`, `11TH_HIY`, `13TH_HIY`, `15TH_HIY`, `THD_IY`, `3RD_HVB`, `5TH_HVB`, `7TH_HVB`, `9TH_HVB`, `11TH_HVB`, `13TH_HVB`, `15TH_HVB`, `THD_VB`, `3RD_HIB`, `5TH_HIB`, `7TH_HIB`, `9TH_HIB`, `11TH_HIB`, `13TH_HIB`, `15TH_HIB`, `THD_IB`, `DG_STATUS`, `linux_date_time`, `teltonika_date_time`, `recorded_date_time`, `posted_date_time`) VALUES ('".$gatewayCode."','".$sensorCode."','".$sensorModel."','".$Vrn."','".$Vyn."','".$Vbn."','".$Vry."','".$Vyb."','".$Vbr."','".$Ir."','".$Iy."','".$Ib."','".$System_KVA."','".$System_KW."','".$System_KVAR."','".$System_PF."','".$Frequency."','".$EB_KWh."','".$DG_KWh."','".$DG_KVAh."','".$DG_Status."','".$inputJSON."','".$Avg_Vpn."','".$Avg_Vpp."','".$Avg_I."','".$PF_R."','".$PF_Y."','".$PF_B."','".$KW_R."','".$KW_Y."','".$KW_B."','".$KVAR_R."','".$KVAR_Y."','".$KVAR_B."','".$KVA_R."','".$KVA_Y."','".$KVA_B."','".$KW_Rising_Demand."','".$KW_Max_Demand."','".$KVA_Rising_Demand."','".$KVA_Max_Demand."','".$DG_KVARh."','".$EB_KWh."','".$EB_KVARh."','".$EB_KVAh."','".$_3rd_HVr."','".$_5th_HVr."','".$_7th_HVr."','".$_9th_HVr."','".$_11th_HVr."','".$_13th_HVr."','".$_15th_HVr."','".$THD_Vr."','".$_3rd_HIr."','".$_5th_HIr."','".$_7th_HIr."','".$_9th_HIr."','".$_11th_HIr."','".$_13th_HIr."','".$_15th_HIr."','".$THD_Ir."','".$_3rd_HVy."','".$_5th_HVy."','".$_7th_HVy."','".$_9th_HVy."','".$_11th_HVy."','".$_13th_HVy."','".$_15th_HVy."','".$THD_Vy."','".$_3rd_HIy."','".$_5th_HIy."','".$_7th_HIy."','".$_9th_HIy."','".$_11th_HIy."','".$_13th_HIy."','".$_15th_HIy."','".$THD_Iy."','".$_3rd_HVb."','".$_5th_HVb."','".$_7th_HVb."','".$_9th_HVb."','".$_11th_HVb."','".$_13th_HVb."','".$_15th_HVb."','".$THD_Vb."','".$_3rd_HIb."','".$_5th_HIb."','".$_7th_HIb."','".$_9th_HIb."','".$_11th_HIb."','".$_13th_HIb."','".$_15th_HIb."','".$THD_Ib."','".$DG_Status."','".$liuxTimeStamp."','".$input['dtm']."','".$teltonikaTimeStamp."',NOW())";
		}else{
				  $sql2= "INSERT INTO `energy_data_master_view`(`gateway_code`, `sensor_code`, `sensor_model`,`R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`, `SUM_PF`, `FREQUENCY`, `KWH_MSB`, `KWH_LSB`, `KWH`, `METER_TYPE_RUN_HOUR_MSB`, `RUN_HOUR_LSB`, `RUN_HOUR`, `IMPORT_EXPORT`, `DG_KWH`, `DG_KVAH`, `DG_RUN_HOUR`, `DG_RUN_MIN`, `EB_DG_STATUS`,`VR_ARRAY_VALUE`,`linux_date_time`,`teltonika_date_time`, `recorded_date_time`, `posted_date_time`) VALUES ('".$gatewayCode."','".$sensorCode."','".$sensorModel."','".$R_VOLTAGE."','".$Y_VOLTAGE."','".$B_VOLTAGE."','".$RY_VOLTAGE."','".$YB_VOLTAGE."','".$BR_VOLTAGE."','".$R_CURRENT."','".$Y_CURRENT."','".$B_CURRENT."','".$SUM_KVA."','".$SUM_KW."','".$SUM_KVAR."','".$SUM_PF."','".$FREQUENCY."','".$KWH_MSB."','".$KWH_LSB."','".$KWH."','".$METER_TYPE_RUN_HOUR_MSB."','".$RUN_HOUR_LSB."','".$RUN_HOUR."','".$IMPORT_EXPORT."','".$DG_KWH."','".$DG_KVAH."','".$DG_Run_Hour."','".$DG_Run_Min."','".$EB_DG_Status."','".$inputJSON."','".$liuxTimeStamp."','".$teltonikaTimeStamp."','".$recordedTimeStamp."', NOW())";
				  }
      }else{
		   		if($sensorModel =='TEP')
		  		 {
					 $sql2= " UPDATE `energy_data_master_view` SET `R_VOLTAGE`='".$Vrn."', `Y_VOLTAGE`='".$Vyn."', `B_VOLTAGE`='".$Vbn."', `RY_VOLTAGE`='".$Vry."', `YB_VOLTAGE`='".$Vyb."', `BR_VOLTAGE`='".$Vbr."', `R_CURRENT`='".$Ir."', `Y_CURRENT`='".$Iy."', `B_CURRENT`='".$Ib."', `SUM_KVA`='".$System_KVA."', `SUM_KW`='".$System_KW."', `SUM_KVAR`='".$System_KVAR."', `SUM_PF`='".$System_PF."', `FREQUENCY`='".$Frequency."', `KWH`='".$EB_KWh."', `DG_KWH`='".$DG_KWh."', `DG_KVAH`='".$DG_KVAh."',`EB_DG_STATUS`='".$DG_Status."', `VR_ARRAY_VALUE`='".$inputJSON."', `AVG_VPN`='".$Avg_Vpn."', `AVG_VPP`='".$Avg_Vpp."', `AVG_I`='".$Avg_I."', `PF_R`='".$PF_R."', `PF_Y`='".$PF_Y."', `PF_B`='".$PF_B."', `KW_R`='".$KW_R."', `KW_Y`='".$KW_Y."', `KW_B`='".$KW_B."', `KVAR_R`='".$KVAR_R."', `KVAR_Y`='".$KVAR_Y."', `KVAR_B`='".$KVAR_B."', `KVA_R`='".$KVA_R."', `KVA_Y`='".$KVA_Y."', `KVA_B`='".$KVA_B."', `KW_RISING_DEMAND`='".$KW_Rising_Demand."', `KW_MAX_DEMAND`='".$KW_Max_Demand."', `KVA_RISING_DEMAND`='".$KVA_Rising_Demand."', `KVA_MAX_DEMAND`='".$KVA_Max_Demand."', `DG_KVARH`='".$DG_KVARh."', `EB_KWH`='".$EB_KWh."', `EB_KVARH`='".$EB_KVARh."',`EB_KVAH`='".$EB_KVAh."', `3RD_HVR`='".$_3rd_HVr."', `5TH_HVR`='".$_5th_HVr."', `7TH_HVR`='".$_7th_HVr."', `9TH_HVR`='".$_9th_HVr."', `11TH_HVR`='".$_11th_HVr."', `13TH_HVR`='".$_13th_HVr."', `15TH_HVR`='".$_15th_HVr."', `THD_VR`='".$THD_Vr."', `3RD_HIR`='".$_3rd_HIr."', `5TH_HIR`='".$_5th_HIr."', `7TH_HIR`='".$_7th_HIr."', `9TH_HIR`='".$_9th_HIr."', `11TH_HIR`='".$_11th_HIr."', `13TH_HIR`='".$_13th_HIr."', `15TH_HIR`='".$_15th_HIr."', `THD_IR`='".$THD_Ir."', `3RD_HVY`='".$_3rd_HVy."', `5TH_HVY`='".$_5th_HVy."', `7TH_HVY`='".$_7th_HVy."', `9TH_HVY`='".$_9th_HVy."', `11TH_HVY`='".$_11th_HVy."', `13TH_HVY`='".$_13th_HVy."', `15TH_HVY`='".$_15th_HVy."',`THD_VY`='".$THD_Vy."', `3RD_HIY`='".$_3rd_HIy."', `5TH_HIY`='".$_5th_HIy."', `7TH_HIY`='".$_7th_HIy."', `9TH_HIY`='".$_9th_HIy."', `11TH_HIY`='".$_11th_HIy."', `13TH_HIY`='".$_13th_HIy."', `15TH_HIY`='".$_15th_HIy."', `THD_IY`='".$THD_Iy."', `3RD_HVB`='".$_3rd_HVb."', `5TH_HVB`='".$_5th_HVb."', `7TH_HVB`='".$_7th_HVb."', `9TH_HVB`='".$_9th_HVb."', `11TH_HVB`='".$_11th_HVb."', `13TH_HVB`='".$_13th_HVb."', `15TH_HVB`='".$_15th_HVb."', `THD_VB`='".$THD_Vb."', `3RD_HIB`='".$_3rd_HIb."', `5TH_HIB`='".$_5th_HIb."', `7TH_HIB`= '".$_7th_HIb."',`9TH_HIB`='".$_9th_HIb."', `11TH_HIB`='".$_11th_HIb."', `13TH_HIB`='".$_13th_HIb."', `15TH_HIB`='".$_15th_HIb."', `THD_IB`='".$THD_Ib."', `DG_STATUS`='".$DG_Status."', `linux_date_time`='".$liuxTimeStamp."', `teltonika_date_time`='".$input['dtm']."', `recorded_date_time`='".$teltonikaTimeStamp."', `posted_date_time`=NOW()  WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."'";
				}
				else
				{
					  $sql2= "UPDATE `energy_data_master_view` SET `R_VOLTAGE`='".$R_VOLTAGE."',`Y_VOLTAGE`='".$Y_VOLTAGE."',B_VOLTAGE='".$B_VOLTAGE."', `RY_VOLTAGE`='".$RY_VOLTAGE."', `YB_VOLTAGE`='".$YB_VOLTAGE."', `BR_VOLTAGE`='".$BR_VOLTAGE."', `R_CURRENT`='".$R_CURRENT."', `Y_CURRENT`='".$Y_CURRENT."', `B_CURRENT`='".$B_CURRENT."', `SUM_KVA`='".$SUM_KVA."', `SUM_KW`='".$SUM_KW."', `SUM_KVAR`='".$SUM_KVAR."', `SUM_PF`='".$SUM_PF."', `FREQUENCY`='".$FREQUENCY."', `KWH_MSB`='".$KWH_MSB."', `KWH_LSB`='".$KWH_LSB."', `KWH`='".$KWH."', `METER_TYPE_RUN_HOUR_MSB`='".$METER_TYPE_RUN_HOUR_MSB."', `RUN_HOUR_LSB`='".$RUN_HOUR_LSB."', `RUN_HOUR`='".$RUN_HOUR."', `IMPORT_EXPORT`='".$IMPORT_EXPORT."',`DG_KWH`='".$DG_KWH."',`DG_KVAH`='".$DG_KVAH."',`DG_RUN_HOUR`='".$DG_Run_Hour."',`DG_RUN_MIN`='".$DG_Run_Min."',`EB_DG_STATUS`='".$EB_DG_Status."',`VR_ARRAY_VALUE`='".$inputJSON."',`linux_date_time`='".$liuxTimeStamp."',`teltonika_date_time`='".$teltonikaTimeStamp."', `recorded_date_time`='".$recordedTimeStamp."', `posted_date_time`=NOW() WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."'";
				}

	  
	  }
        $insSel2 = $conn->query($sql2);
     
        
        if ($insSel2 === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $sql2 . "<br>" . $conn->error;
        }
		
		
		/*******************************************             Mail Trigger  Starts            ****************************************************/
	   $selAlertCont= "SELECT email FROM `arka_alert_contact_master` WHERE email_alert=1 AND is_active=1 AND `company_id`='".$sensMasDet['company_id']."' AND `branch_id`='".$sensMasDet['branch_id']."'";
       $ExeAlertCont = mysqli_query($conn, $selAlertCont);
	   if (mysqli_num_rows($ExeAlertCont) > 0) 
	   {
			 $alertContact='';
			 while($alertCont = mysqli_fetch_assoc($ExeAlertCont)) 
			{
			// Fetch all
			   $alertContact .= $alertCont['email'].",";
			}
		//	$string = rtrim($string, ".");
			$alertEmail= rtrim($alertContact, ",");
			echo $alertEmail." -- EmailId from Table <br>";
       } 
	   
	echo   $selAlertPar= "SELECT * FROM `alert_parameter_mapping` WHERE `sensor_code`='".$sensorCode."'";
       $ExeAlertPar = mysqli_query($conn, $selAlertPar);
	   
	   if (mysqli_num_rows($ExeAlertPar) > 0) 
	   {
	      echo "alert parameter Mapping";
            while($parameter = mysqli_fetch_assoc($ExeAlertPar)) 
			{ 
			 echo $parameter['parameter_name']."-  Parameter Name <br>";
			  echo $parameter['mail_alert_status'];
				$parameterName=$parameter['parameter_name'];
				if($parameter['mail_alert_status']=="Normal")
				{
              echo $selectEnergy= "SELECT ".$parameterName." FROM `energy_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND (".$parameterName." <= '".$parameter['min_alert_value']."' OR ".$parameterName." >= '".$parameter['max_alert_value']."')";
			  $ExeEnergy = mysqli_query($conn, $selectEnergy);
	           $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
				  if($ReadingValue > $parameter['max_alert_value']){
				  $alertStatus='High';
				  $alertValueName='Max Value Reached';
				  }
				  elseif($ReadingValue < $parameter['min_alert_value']){
				  $alertStatus='Low';
				  $alertValueName='Min Value Reached';
				  }
			  }else if($parameter['mail_alert_status']=="High"){
			  $selectEnergy= "SELECT ".$parameterName." FROM `energy_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND (".$parameterName." > '".$parameter['min_alert_value']."' AND ".$parameterName." < '".$parameter['max_alert_value']."')";
			  $ExeEnergy = mysqli_query($conn, $selectEnergy);
			  if (mysqli_num_rows($ExeEnergy) == 0) 
				{
				 $selectEnergy= "SELECT ".$parameterName." FROM `energy_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND ".$parameterName." <= '".$parameter['min_alert_value']."'";
			   $ExeEnergy = mysqli_query($conn, $selectEnergy);
	           $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='Low';
			   $alertValueName='Min Value Reached';
			   
			   }
			   else{
			   
			   $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='Normal';
			   $alertValueName='Normal Value Reached';
			   
			   }
			  }
			  else if($parameter['mail_alert_status']=="Low" ){
			  $selectEnergy= "SELECT ".$parameterName." FROM `energy_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND (".$parameterName." > '".$parameter['min_alert_value']."' AND ".$parameterName." < '".$parameter['max_alert_value']."')";
			  $ExeEnergy = mysqli_query($conn, $selectEnergy);
	          if (mysqli_num_rows($ExeEnergy) == 0) 
				{
				 $selectEnergy= "SELECT ".$parameterName." FROM `energy_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND ".$parameterName." >= '".$parameter['max_alert_value']."'";
			   $ExeEnergy = mysqli_query($conn, $selectEnergy);
	           $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='High';
			   $alertValueName='Max Value Reached';
			   
			   }
			   else{
			   
			   $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='Normal';
			   $alertValueName='Normal Value Reached';
			   
			   }
			  }
			  
			 /* $message .= "Hi!<br><br><br>
	
								<b>Feeder Name</b>      : ".$parameter['feeder_name'].",<br>
								<b>Parameter Name</b>   : ".$parameter['parameter_name'].",<br>
								<b>".$alertValueName."</b>  : ".$ReadingValue.".<br><br><br><br><br>
	
	
								
                                <b>Best regards</b>,<br>
                                <b>Arka Automaations Limited.</b><br>
								";
								
				  $contentData=strip_tags($message);
								
			 $insAlertLog	="INSERT INTO `alert_log_master`(`company_id`, `branch_id`, `sensor_code`, `alert_type`, `parameter_name`, `alert_message`, `send_to`, `alert_status`, `recorded_date_time`, `posted_date_time`) VALUES ('".$sensMasDet['company_id']."','".$sensMasDet['branch_id']."','".$sensorCode."','Mail','".$parameter['parameter_name']."','".$contentData."','".$alertEmail."','".$alertStatus."','".$teltonikaTimeStamp."',DATE_ADD(NOW(),INTERVAL '00:00' HOUR_MINUTE))";		
			 $insLog = $conn->query($insAlertLog);*/
			  
			echo   $alertStatus." --alert Status <br>".$alertValueName." --alert Value <br>".mysqli_num_rows($ExeEnergy);
			   
			    if (mysqli_num_rows($ExeEnergy) > 0) 
				{
				
			    echo $updateAlertPar= "UPDATE `alert_parameter_mapping` SET mail_alert_status='".$alertStatus."'  WHERE `alert_parameter_id`='".$parameter['alert_parameter_id']."'";
       			 $ExeAlertPar = mysqli_query($conn, $updateAlertPar);
				     echo $ReadingValue."-  Reading Value <br>";
				     echo $alertEmail."-  MailId <br>"; 
				     
				     $selectSensor= "SELECT sensorName FROM `arka_sensor_master` WHERE `sensorCode`='".$parameter['sensor_code']."' AND status='1' AND isActive='1'";
			   $ExeSensor = mysqli_query($conn, $selectSensor);
	           $ExeSensorArr = mysqli_fetch_assoc($ExeSensor);
			  
				     
				  // Step 1 - Enter your email address below.
$email = 'aal@arkaautomaations.com';

// If the e-mail is not working, change the debug option to 2 | $debug = 2;
$debug = 0;

// If contact form don't has the subject input change the value of subject here
//$subject = 'Parameter Alert';
$subject = $parameter['feeder_name'] - $ExeSensorArr['sensorName'];
$message = '';

				   $message .= "ARKA EMS - Alert Message!<br><br><br>
	
								<b>Feeder Name</b>      : ".$parameter['feeder_name'].",<br>
								<b>Parameter Name</b>   : ".$parameter['parameter_name'].",<br>
								<b>".$alertValueName."</b>  : ".$ReadingValue.".<br><br><br><br><br>
	
	
								
                                <br>
								";
								
				  $contentData=strip_tags($message);
							
			$liuxTimeStamp=$input['dtm'];
			$recordedTimeStamp = date("Y-m-d H:i:s",$input['dtm']);
              $telDate =$input['dtm'];
              $teltonika_date = str_replace('/', '-', $telDate);
              $teltonikaTimeStamp =  date('Y-m-d H:i:s', strtotime($teltonika_date));
								
			 $insAlertLog	="INSERT INTO `alert_log_master`(`company_id`, `branch_id`, `sensor_code`, `alert_type`, `parameter_name`, `alert_message`, `send_to`, `alert_status`, `recorded_date_time`, `posted_date_time`) VALUES ('".$sensMasDet['company_id']."','".$sensMasDet['branch_id']."','".$sensorCode."','Mail','".$parameter['parameter_name']."','".$contentData."','".$alertEmail."','".$alertStatus."','".$teltonikaTimeStamp."',DATE_ADD(NOW(),INTERVAL '00:00' HOUR_MINUTE))";		
			 $insLog = $conn->query($insAlertLog);
     
        
        if ($insLog === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $insAlertLog . "<br>" . $conn->error;
        }
            	    
$mail = new PHPMailer(true);

try {

	$mail->SMTPDebug = $debug;                                 // Debug Mode

	// Step 2 (Optional) - If you don't receive the email, try to configure the parameters below:

	$mail->IsSMTP();                                         // Set mailer to use SMTP
	$mail->Host = 'smtpout.asia.secureserver.net';				       // Specify main and backup server
	$mail->SMTPAuth = true;                                  // Enable SMTP authentication
//	$mail->Username = 'info@plumtekerp.in';                    // SMTP username
//	$mail->Password = 'Admin@2020';
//	$mail->Username = 'aal@arkaautomaations.com';                    // SMTP username
//  $mail->Password = 'Arka@2020';// SMTP password
     $mail->Username = 'tpl@tiebarfactory.com';                    // SMTP username
   //  $mail->Password = 'tpl6k@2020';// SMTP password
     $mail->Password = 'tpl@tiebar';
	$mail->SMTPAutoTLS = false;                               // Enable encryption, 'ssl' also accepted
	$mail->Port = 80;   								       // TCP port to connect to

//	$mail->AddAddress('vishalchandran11@gmail.com');	 						       // Add another recipient
    
	//  ***************     To Mail Starts  *************************
	$toMailArr =explode(",",$alertEmail);
    $toMailCount = count($toMailArr);
    $mailC=0;
    for($mailC==0; $mailC<$toMailCount; $mailC++){
        $mail->AddAddress($toMailArr[$mailC]);
    }   
	//  *************  To Mail Ends.... ***************************
	 
	//$mail->AddAddress($alertEmail);     // Add a secondary recipient
//	$mail->AddCC('karthikeyan@arkagroup.co.in');          // Add a "Cc" address. 
	//$mail->AddBCC('person4@domain.com', 'Person 4');         // Add a "Bcc" address. 

	// From - Name
	$fromName = 'Arka Automaations Limited';
	$mail->SetFrom($email, $fromName);

	// Repply To
/*	if( isset($_POST['email']) ) {
		$mail->AddReplyTo($_POST['email'], $fromName);
	}*/

	$mail->IsHTML(true);                                       // Set email format to HTML

	$mail->CharSet = 'UTF-8';

	$mail->Subject = $subject;
	$mail->Body    = $message;

	$mail->Send();
	$arrResult = array ('response'=>'success');

} catch (Exception $e) {
	$arrResult = array ('response'=>'error','errorMessage'=>$e->errorMessage());
} catch (\Exception $e) {
	$arrResult = array ('response'=>'error','errorMessage'=>$e->getMessage());
}


$selAlertCont= "SELECT mobile FROM `arka_alert_contact_master` WHERE sms_alert=1 AND is_active=1 AND `company_id`='".$sensMasDet['company_id']."' AND `branch_id`='".$sensMasDet['branch_id']."'";
       $ExeAlertCont = mysqli_query($conn, $selAlertCont);
	   
	    $selBranchCont= "SELECT branch_name FROM `arka_branch_master` WHERE record_status=1 AND is_active=1 AND `company_id`='".$sensMasDet['company_id']."' AND `sl_no`='".$sensMasDet['branch_id']."'";
       $ExeBranchCont = mysqli_query($conn, $selBranchCont);
	   $BranchCont = mysqli_fetch_assoc($ExeBranchCont);
	   
	   if (mysqli_num_rows($ExeAlertCont) > 0) 
	   {
			 $alertContact='';
			 while($alertCont = mysqli_fetch_assoc($ExeAlertCont)) 
			{
			// Fetch all
			   $alertContact .= $alertCont['mobile'].",";
			   
								$apiKey = urlencode('bdv8P3QD1RM-00HgVBfsXFz4FiL7WN35p7HCcrGj1M');
// Message details
//$numbers = urlencode('919884422723'); //Mobile number on which you want to send message
$numbers = urlencode($alertContact);
$sender = urlencode('AALIOT');
/*$message = rawurlencode('Device Code : dev1001,
Installed at : Guindy,
 R_Voltagr : 100, 
at 08/11/2021 10:58:00'); */

$teltonikaTimeStamp = str_replace('-', '/', $teltonikaTimeStamp);
$teltonikaTimeStamp =  date('H:i d/m/Y', strtotime($teltonika_date));
$devId=$parameter['feeder_name'];
$area=$BranchCont['branch_name'];
$datVar=$parameter['parameter_name'];
$datVal=$ReadingValue.'-'.$alertValueName;
$datTime=$teltonikaTimeStamp;

/*$devId='dev1001';
$area='Guindy';
$datVar='R_Voltagr';
$datVal='100';
$datTime='08/11/2021 17:35:00';*/

$message = rawurlencode('Device Code : '.$devId.',
Installed at : '.$area.',
 '.$datVar.' : '.$datVal.', 
at '.$datTime.'');

// Prepare data for POST request
$data = 'apikey=' . $apiKey . '&numbers=' . $numbers . "&sender=" . $sender . "&message=" . $message;
// Send the GET request with cURL
$ch = curl_init('https://api.textlocal.in/send/?' . $data);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);
// Process your response here
echo $response;
			}
			}

		if ($debug == 0) {
	echo json_encode($arrResult);
}	
				 	
			 }
			   
            }
       } 
	   

//mail("vishalchandran11@gmail.com", "Test Mail", "Test");

		/*******************************************             Mail Trigger   End          ****************************************************/
        $conn->close();
    
 }
    else {
        echo "Wrong API Key provided.";
    }
}
else {
    echo "No data posted with HTTP POST.";
}



function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>
