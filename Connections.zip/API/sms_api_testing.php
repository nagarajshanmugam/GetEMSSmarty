<?php
// Account details
$apiKey = urlencode('bdv8P3QD1RM-00HgVBfsXFz4FiL7WN35p7HCcrGj1M');
// Message details
$numbers = urlencode('919884422723'); //Mobile number on which you want to send message
$sender = urlencode('Shanmugakani');
$message = rawurlencode('123456 is OTP for platform verification. Valid for 30 Minutes.');

// Prepare data for POST request
//$data = 'apikey=' . $apiKey . '&numbers=' . $numbers . "&sender=" . $sender . "&message=" . $message;
$data = array('apikey' => $apiKey, 'numbers' => $numbers, 'sender' => $sender, 'message' => $message);
// Send the GET request with cURL
$ch = curl_init('https://api.textlocal.in/send/');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);
// Process your response here
echo $response;
?>