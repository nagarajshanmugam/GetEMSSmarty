<?php

// Account details
$apiKey = urlencode('bdv8P3QD1RM-00HgVBfsXFz4FiL7WN35p7HCcrGj1M');
// Message details
$numbers = urlencode('919884422487, 919176014979'); //Mobile number on which you want to send message
$sender = urlencode('AALIOT');
/*$message = rawurlencode('Device Code : dev1001,
Installed at : Guindy,
 R_Voltagr : 100, 
at 08/11/2021 10:58:00'); */
$devId='dev1001';
$area='Guindy';
$datVar='R_Voltagr';
$datVal='100';
$datTime='08/11/2021 17:35:00';
$message = rawurlencode('Device Code : '.$devId.',
Installed at : '.$area.',
 '.$datVar.' : '.$datVal.', 
at '.$datTime.'');

// Prepare data for POST request
$data = 'apikey=' . $apiKey . '&numbers=' . $numbers . "&sender=" . $sender . "&message=" . $message;
// Send the GET request with cURL
$ch = curl_init('https://api.textlocal.in/send/?' . $data);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);
// Process your response here
echo $response;
?>