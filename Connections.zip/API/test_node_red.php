<?php require_once('../Connections/ARKAEMS.php'); 

mysql_select_db($database_arkaems, $arkaerp) or die(mysql_error());


			mysql_select_db($database_arkaems, $arkaerp);
			$query_rs1 = "SELECT * FROM gateway_ping_log ORDER BY ping_date_time DESC LIMIT 0,1";
		
	//	echo $query_rs1;
		$mt2 = mysql_query($query_rs1, $arkaerp) or die(mysql_error());
$recNumRow= mysql_num_rows($mt2);
$res=mysql_fetch_assoc($mt2);
//echo $res["gateway_code"];
echo JSON_encode($res); 
?>