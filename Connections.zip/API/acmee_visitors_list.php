<?php require_once('../Connections/ARKAEMS.php'); 

mysql_select_db($database_arkaems, $arkaerp) or die(mysql_error());


			mysql_select_db($database_arkaems, $arkaerp);
			$query_rs1 = "SELECT * FROM acmee_contacts_list ORDER BY acmee_id DESC";
		
	//	echo $query_rs1;
		$mt2 = mysql_query($query_rs1, $arkaerp) or die(mysql_error());
$recNumRow= mysql_num_rows($mt2);
//echo $recNumRow; exit;

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" type="image/png" href="../images/arkaLogoNew.png"/>

<link rel="stylesheet" type="text/css" media="screen" href="css/style.css">

<title>Condition Monitoring Systems</title>
<style type="text/css">
<!--
.style3 {font-family: Arial, Helvetica, sans-serif; font-size: 13px;}
.style8 {font-family: Arial, Helvetica, sans-serif; font-size: 13px; }
.style10 {font-size: 9px}
table.sample {
	border-width: 1px;
	border-spacing: 2px;
	border-style: outset;
	border-color: gray;
	border-collapse: collapse;
	background-color: white;
}
table.sample th {
	border-width: 1px;
	padding: 5px;
	border-style: inset;
	border-color: gray;
	-moz-border-radius: ;
}
table.sample td {
	border-width: 1px;
	padding: 5px;
	border-style: inset;
	border-color: gray;
	background-color: white;
	-moz-border-radius: ;
}
.style1 {font-size: 13px}

input {
    margin: .4rem 0;
}
</style>
</head>
<script src="http://www.amcharts.com/lib/3/amcharts.js"></script>
<script src="http://www.amcharts.com/lib/3/serial.js"></script>
<script src="http://www.amcharts.com/lib/3/themes/light.js"></script>
<script type="text/javascript" src="dhtmlxMessage/codebase/dhtmlxcalendar.js" ></script>
<script type="text/javascript" src="./codebase/dhtmlxcalendar.js"></script>
<script type="text/javascript" src="./codebase/dhtmlxcommon.js"></script>
<style type="text/css">
#chartdiv {
	width	: 100%;
	height	: 500px;
}
</style>
			<link rel="stylesheet" type="text/css" href="css/datepickier_main.css">
	 	    <link rel="stylesheet" type="text/css" href="css/jquery-ui.css">
	  		<link rel="stylesheet" href="./codebase/dhtmlxcalendar.css" type="text/css">
			<link rel="stylesheet" href="./codebase/dhtmlxcalendar_dhx_skyblue.css" type="text/css"> 
			<link rel="stylesheet" href="./codebase/skins/dhtmlxmessage_dhx_skyblue.css" type="text/css">
			<link rel="stylesheet" type="text/css" href="css/datepicker.css">
		<script src="jquery/jquery-1.5.1.js"></script>
		<script src="jquery/jquery.ui.core.js"></script>
		<script src="jquery/jquery.ui.widget.js"></script>
		<script src="jquery/jquery.ui.datepicker.js"></script>
		
		 
        
    

	
</head>



<body style="background-color:#FFFFFF; overflow-x:auto;" onload="doOnLoad();">
<div class="bigblockright">
	  
	  </div>

 
		
		<table   border="1PX solid black" align="center" class="sample" >
   <tr align="center">

    <th colspan="18" bgcolor="#17a2b8" style="color:#FFFFFF" class="style3 style1" scope="row"><img src="../images/1133035.png" height="14" width="14">&nbsp;&nbsp;<span >Acmee Visitors Log  
  </span><span style="float:right"> No Of Records : <?php echo $recNumRow;?></span>   <!--    <div align="center" class="style10">

         <div align="left" class="style14">

           <div align="center" class="style21"></div>

        </div>

     </div>--></th></tr>
	 <tr bgcolor="#FF6666" align="center">
	 <th  bgcolor="#CCCCCC" class="style3 style1" scope="row"><span class="">Acmee Id</span></th>
     <th bordercolor="#CCCCCC" bgcolor="#CCCCCC" class="style3 style1"><span class="">Date Time</span></th>
     <th bordercolor="#CCCCCC" bgcolor="#CCCCCC" class="style3 style1"><span class="">Company Name</span></th>
     <th bordercolor="#CCCCCC" bgcolor="#CCCCCC" class="style3 style1"><span class="">Name</span></th>
     <th bordercolor="#CCCCCC" bgcolor="#CCCCCC" class="style3 style1"><span class="">Mobile</span></th>
     <th bordercolor="#CCCCCC" bgcolor="#CCCCCC" class="style3 style1"><span class="">Designation</span></th>
    </tr>
<?php while($mt_rs2=mysql_fetch_array($mt2))
			{
	
	
?>
		
    <tr bgcolor="#FF6666" align="left">
   <td  bgcolor="#ffffff" class="style3 style1" scope="row"><div align="center" class=""><?php if($mt_rs2['acmee_id_no']==''){echo "0";}else{ echo $mt_rs2['acmee_id_no']; } ?></div></td>
   <td  bgcolor="#ffffff" class="style3 style1" scope="row" style="font-size:11px"><div align="center" class=""><?php if($mt_rs2['visited_date_time']==''){echo "0000-00-00 00:00:00";}else{ $orgDate = $mt_rs2['visited_date_time'];  
    $newDate = date("d-M-Y h:i A", strtotime($orgDate));  echo $newDate; } ?></div></td>
   <td  bgcolor="#ffffff" class="style3 style1" scope="row"><div align="center" class=""><?php if($mt_rs2['company_name']==''){echo "0";}else{echo $mt_rs2['company_name']; }?></div></td>


    <td  bgcolor="#ffffff" class="style3 style1" scope="row"><div align="center" class=""><?php if($mt_rs2['name']==''){echo "0";}else{echo $mt_rs2['name']; }?></div></td>
 <td  bgcolor="#ffffff" class="style3 style1" scope="row"><div align="center" class=""><?php if($mt_rs2['mobile_no']==''){echo "0";}else{echo $mt_rs2['mobile_no']; }?></div></td>
 <td  bgcolor="#ffffff" class="style3 style1" scope="row"><div align="center" class=""><?php if($mt_rs2['designation']==''){echo "0";}else{echo $mt_rs2['designation']; }?></div></td>


   </tr>

  <?php }?>
  <!--<tr bgcolor="#FF6666" align="center">
	 <td   bordercolor="#CCCCCC" bgcolor="#CCCCCC" class="style3 style1" scope="row" colspan="9"><div align="center" class=""><b>Total</b></div></td>
     <!--<td  bgcolor="#CCCCCC" class="style3 style1" scope="row"><div align="center" class=""><?php// if($sumKVA==''){echo "0";}else{echo $sumKVA; }?></div></td>
     <td  bgcolor="#CCCCCC" class="style3 style1" scope="row"><div align="center" class=""><?php//if($sumKW==''){echo "0";}else{echo $sumKW; }?></div></td>
     <td  bgcolor="#CCCCCC" class="style3 style1" scope="row"><div align="center" class=""><?php//  if($sumKVAR==''){echo "0";}else{ echo $sumKVAR; } ?></div></td>
     <td  bgcolor="#CCCCCC" class="style3 style1" scope="row"><div align="center" class=""><?php// if($sumPF==''){echo "0";}else{ echo $sumPF; } ?></div></td>
     <td  bgcolor="#CCCCCC" class="style3 style1" scope="row"><div align="center" class=""><?php// if($sumKWH==''){echo "0";}else{ echo $sumKWH; } ?></div></td>

    

   

   </tr>-->
</table>   
		
		
		
		
	
</body>
</html>
