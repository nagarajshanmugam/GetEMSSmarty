<?php

/*
  Rui Santos
  Complete project details at https://RandomNerdTutorials.com/esp32-esp8266-mysql-database-php/
  
  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files.
  
  The above copyright notice and this permission notice shall be included in all
  copies or substantial portions of the Software.
*/

require_once('../Connections/ARKAEMS.php'); 
$servername = $hostname_arkaems;

// REPLACE with your Database name
$dbname = $database_arkaems;
// REPLACE with Database user
$username = $username_arkaems;
// REPLACE with Database user password
$password = $password_arkaems;
 
//exit;


// Keep this API Key value to be compatible with the ESP32 code provided in the project page. 
// If you change this value, the ESP32 sketch needs to match


   if ($_SERVER["REQUEST_METHOD"] == "POST") {
         $inputJSON = file_get_contents('php://input');
         $input= json_decode( $inputJSON, true); 
 //echo $inputJSON."<br>";
// print_r($input);
  echo "<br>ia ma";
   // $api_key = test_input($_POST["api_key"]);
     $conn = new mysqli($servername, $username, $password, $dbname);
     mysqli_query($conn,"SET SESSION sql_mode = 'NO_ENGINE_SUBSTITUTION'");
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } 
   echo $sqlSensor = "SELECT * FROM arka_sensor_master WHERE isActive='1' AND status='1' AND api_key='".$input['apiKey']."'";
    $insSel = $conn->query($sqlSensor);
	
     $result = mysqli_query($conn, $sqlSensor);
	  echo $input['apiKey']." :apikeydecode<br>";

       
      

       
  if (mysqli_num_rows($result) > 0) {
          
       
        
         // Create connection
		   $apikeyDecd= base64_decode($input['apiKey']);
	 
	  $apiDec =explode("/", $apikeyDecd);
	   $gatewayCode=str_replace("GW:","",$apiDec[0]);
	   $sensorCode=str_replace("SI:","",$apiDec[1]);
	  $sensorModel=str_replace("SMODEL:","",$apiDec[2]);
           $jsonDecd= $input['VR'];
          // $str_arr = explode (",", $jsonDecd);  
           $temp_c=$jsonDecd[0];
           $temp_f=round(($temp_c * 1.8)+32);
           //$temp_f=$jsonDecd[1];
           $hum=$jsonDecd[2];
          $liuxTimeStamp=$input['TS'];
          if($liuxTimeStamp !="XXXXXX")
          {
             
              $recordedTimeStamp = date("Y-m-d H:M:S",$input['TS']);
          }
          else
          {
              $liuxTimeStamp='';
              $recordedTimeStamp = ''; 
          
          }
           
     
      $sql = "INSERT INTO temperature_data_master (gateway_code,sensor_code,sensor_model,temperature_c,temperature_f,humidity,linux_date_time,recorded_date_time,posted_date_time) VALUES ('".$gatewayCode."','".$sensorCode."','".$sensorModel."','".$temp_c."','".$temp_f."','".$hum."','".$liuxTimeStamp."',CONVERT_TZ(NOW(),'+00:00','+00:00'),CONVERT_TZ(NOW(),'+00:00','+00:00'))"; 
        $insSel = $conn->query($sql);
     
        
        if ($insSel === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
		
		
		
		$selectView= "SELECT * FROM `temperature_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."'";
		echo $selectView;
       $resultView = mysqli_query($conn, $selectView);
	   $rowcount=mysqli_num_rows($resultView);
	   
	   if($rowcount==0){
	          $sql2= "INSERT INTO temperature_data_master_view (gateway_code,sensor_code,sensor_model,temperature_c,temperature_f,humidity,linux_date_time,recorded_date_time,posted_date_time) VALUES ('".$gatewayCode."','".$sensorCode."','".$sensorModel."','".$temp_c."','".$temp_f."','".$hum."','".$liuxTimeStamp."',CONVERT_TZ(NOW(),'+00:00','+00:00'),CONVERT_TZ(NOW(),'+00:00','+00:00'))";
      }else{
	  	          $sql2= "UPDATE `temperature_data_master_view` SET `temperature_c`='".$temp_c."',`temperature_f`='".$temp_f."',humidity='".$hum."', `linux_date_time`='".$liuxTimeStamp."', `recorded_date_time`=CONVERT_TZ(NOW(),'+00:00','+00:00'), `posted_date_time`=CONVERT_TZ(NOW(),'+00:00','+00:00') WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."'";

	  
	  }
	  echo $sql2;
        $insSel2 = $conn->query($sql2);
     
        
        if ($insSel2 === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $sql2 . "<br>" . $conn->error;
        }
       
        $conn->close();
    
 }
    else {
        echo "Wrong API Key provided.";
    }

}
else {
    echo "No data posted with HTTP POST.";
}


function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
