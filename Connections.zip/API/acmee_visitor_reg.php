
<?php

//require_once "../config.php";
require_once('../config.php'); 
$servername = $config['DBHost'];

// REPLACE with your Database name
$dbname = $config['DBName'];
// REPLACE with Database user
$username = $config['DBUser'];
// REPLACE with Database user password
$password = $config['DBPassword'];
//echo $dbname; exit;
if(isset($_POST["visitorData"]))
{
 
    	$conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } 
     $scanData =explode(",", $_POST["visitorData"]); 
     $company_name= $scanData[0];
     $mobile_no= $scanData[1];
     $mail_id= $scanData[2];
     $acmee_id_no= $scanData[3];
     $pass_type= $scanData[4];
     $name= $scanData[5];
     $designation= $scanData[6];
     
     
        
     //  $insLog = "INSERT INTO `gateway_ping_log` (`gateway_code`,`gateway_date_time`,`json_data`,`ping_date_time`) VALUES ('".$_GET["gatewayCode"]."','".$teltonikaTimeStamp."','".$inputJSON."',NOW())";
       $insLog = "INSERT INTO `acmee_contacts_list` (`scan_data`,`company_name`,`mobile_no`,`mail_id`,`acmee_id_no`,`pass_type`,`name`,`designation`,`enquiry_type`,`enquiry_status`,`remarks`,`visited_date_time`) VALUES ('".$_POST["visitorData"]."','".$company_name."','".$mobile_no."','".$mail_id."','".$acmee_id_no."','".$pass_type."','".$name."','".$designation."','".$_POST["enquiry_type"]."','".$_POST["enquiry_status"]."','".$_POST["remarks"]."',NOW())";
    $insSel = $conn->query($insLog);

    
}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" type="image/png" href="../images/arkaLogoNew.png"/>
		<title>Arka | Acmee 2021 </title>
		
		<!-- Font Awesome  for input field icon -->
		<link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
		<!-- Theme style Important -->
		<link rel="stylesheet" href="../dist/css/adminlte.min.css">
	
	</head>
	<body class="hold-transition login-page" style=" background-image:url(../images/emsBaner.png);">
		<div class="login-box">
			<div class="login-logo">
			<a href="#" style="color:#FFFFFF;"><b>Arka</b>Acmee 2021</a>
			</div>
		<!-- /.login-logo -->
			<div class="card">
			<?php if(isset($_POST["visitorData"])) { ?>
					<div class="isa_success">
						<i class="fa fa-check"></i>
					<?php echo "Visitor Created Success"; ?>	 
					</div>
			<?php	} ?>
			 	
			
				<div class="card-body login-card-body">
					<p class="login-box-msg">Acmee Visitors Scan</p>
				
					<form name="stafflogin" action="acmee_visitor_reg.php" method="post" onSubmit="return StaffvalidateForm()" >
						<input type="hidden" id="hdAction" name="hdAction">
						<div class="input-group mb-3">
							<textarea  name="visitorData" id="visitorData" class="form-control"  autocomplete="off" placeholder="Scan Here" autofocus></textarea>
							<div class="input-group-append">
								<div class="input-group-text">
									<span class="fas fa-qrcode"></span>
								</div>
							</div>
						</div>
						<div class="input-group mb-3">
							<select class="form-control" id="enquiry_type" name="enquiry_type">
							     <option value="Others">Others</option>
							    <option value="All">All</option>
							    <option value="Products">Products</option>
							    <option value="Solutions">Solutions</option>
							    
							</select>
						<!--	<div class="input-group-append">
								<div class="input-group-text">
									<span class="fas fa-envelope"></span>
								</div>
							</div>-->
						</div>
						<div class="input-group mb-3">
							<select class="form-control" id="enquiry_status" name="enquiry_status">
							    <option value="Visitor">Visitor</option>
							    <option value="Important">Important</option>
							</select>
						<!--	<div class="input-group-append">
								<div class="input-group-text">
									<span class="fas fa-envelope"></span>
								</div>
							</div>-->
						</div>
						<div class="input-group mb-3">
							<textarea  name="remarks" id="remarks" class="form-control"  autocomplete="off" placeholder="Remarks"></textarea>
							<div class="input-group-append">
								<div class="input-group-text">
									<span class="fas fa-envelope"></span>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-12">
								<center><button type="submit" class="btn btn-primary btn-create">Submit</button></center>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
		
		<script  type="text/javascript">
		
		function StaffvalidateForm()
		{
			var x=document.forms["stafflogin"]["visitorData"].value;
			if (x==null || x=="")
			{
				dhtmlx.alert({
					title: "Scan Data Empty !",
					type:"alert-error",
					text: "Please Scan Data",	
				});
				
				document.getElementById("visitorData").focus();
				document.getElementById("visitorData").style.borderColor = 'red';
				return false;
			}
			
			stafflogin.hdAction.value = 1;
			return true;
		}

		</script>
<!--		<script>
$('form').each(function() {
    this.reset();
});
</script> -->
	
		<!-- for input field Alert Message-->
		<script type="text/javascript" src='../dhtmlxMessage/codebase/dhtmlxmessage.js'></script>
		<link rel="stylesheet" href= "../codebase/skins/dhtmlxmessage_dhx_skyblue.css" type="text/css" media="all"/>
		
		<style type="text/css">
		.isa_success
		{
			color:#4F8A10;
			background-color:#DFF2BF;
		}
		
		.isa_error
		{
			color:#D8000C;
			background-color:#FFBABA;
		}
		.isa_success i,.isa_error i
		{
			margin:10px 22px;
			font-size:2em;
		/*vertical-align:middle;*/
		}
		</style>
	
	</body>
</html>
