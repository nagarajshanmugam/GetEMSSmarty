<?php

session_cache_limiter('nocache');
header('Expires: ' . gmdate('r', 0));

header('Content-type: application/json');


//echo  "hai"; exit;
//require_once('../Connections/ARKAEMS.php'); 
$servername = "148.66.130.228";

// REPLACE with your Database name
$dbname = "greatelephanttec_ems";
// REPLACE with Database user
$username = "greatelephanttec_ems_user";
// REPLACE with Database user password
$password = "GetEms@2025";

/*
require_once('../Connections/ARKAEMS.php'); 
$servername = $hostname_arkaems;
$dbname = $database_arkaems;
$username = $username_arkaems;
$password = $password_arkaems; */

/*$hostname_arkaems = "148.66.130.228";
$database_arkaems = "greatelephanttec_ems";
$username_arkaems = "greatelephanttec_ems_user";
$password_arkaems = "GetEms@2025"; */


if(function_exists('date_default_timezone_set')) {
		date_default_timezone_set("Asia/Kolkata");
}


/*$servername = "166.62.10.227";

// REPLACE with your Database name
$dbname = "emslte";
// REPLACE with Database user
$username = "emslte";
// REPLACE with Database user password
$password = "emslte@2020";*/
 
//exit;


// Keep this API Key value to be compatible with the ESP32 code provided in the project page. 
// If you change this value, the ESP32 sketch needs to match

//echo "hai"; exit;
//echo $_GET['jsonValue']; exit;
   if ($_SERVER["REQUEST_METHOD"] == "POST") {
	//if ($_GET['jsonValue']) {
         $inputJSON = file_get_contents('php://input');
		 //$inputJSON = $_GET['jsonValue'];
		  //$inputJSON = $_POST['jsonValue'];
		 //echo $inputJSON; exit;
         $lastVal=substr($inputJSON,-1);
		 //echo 'Last Value:'.$lastVal;
		 if($lastVal=="]"){
		 $lastChar="";
		 }else{
		 $lastChar="]";
		 }
		 $inputJSON =$inputJSON."".$lastChar;
		 //echo  $inputJSON; 
         $input= json_decode( $inputJSON, true); 
		 //echo  $input; 
		 $elementCount  = count($input);

		 //echo 'Element Count :'.$elementCount; exit;
	//	 echo $inputJSON; exit;
	//$apiKey="R1c6VFJCMTQ1LTIvU0k6U19FTTRNLTEvU01PREVMOlNfRU00TQ==";
 // $api_key = test_input($_POST["api_key"]);
  $apiKey = $input[0]['apiKey'];
     $conn = new mysqli($servername, $username, $password, $dbname);
     mysqli_query($conn,"SET SESSION sql_mode = 'NO_ENGINE_SUBSTITUTION'");
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } 

		  $apikeyDecd= base64_decode($apiKey);
	 
	  $apiDec =explode("/", $apikeyDecd);
	   $gatewayCode=str_replace("GW:","",$apiDec[0]);
	   $sensorCode=str_replace("SI:","",$apiDec[1]);
	   $sensorModel=str_replace("SMODEL:","",$apiDec[2]);
	   


    $sqlSensor = "SELECT * FROM arka_sensor_master WHERE isActive='1' AND status='1' AND api_key='".trim($apiKey)."'"; 
    $insSel = $conn->query($sqlSensor);
	
     $result = mysqli_query($conn, $sqlSensor);
	 $sensMasDet = mysqli_fetch_assoc($result);
	 $sensMasDetCount = mysqli_num_rows($result);
	 
	 mysqli_free_result($insSel);
	 
	  $cost=$sensMasDet["unit_rate"];
	  $mType=$sensMasDet["feeder_type"];
	  $sId=$sensMasDet["slNo"];
	  $segId=$sensMasDet["segmentCode"];
	  $comId=$sensMasDet["company_id"];
	  $bid=$sensMasDet["branch_id"];




	  $sqlGateway = "SELECT * FROM arka_gateway_master WHERE is_active='1' AND record_status='1' AND gateway_id='".$gatewayCode."'"; 
    $selGatewayQry = $conn->query($sqlGateway);
	
     $resultGateway = mysqli_query($conn, $sqlGateway);
	 $gatewayMasDet = mysqli_fetch_assoc($resultGateway);
	 $gatewayMasDetCount = mysqli_num_rows($resultGateway);
	 
	 mysqli_free_result($selGatewayQry);

	  $gId=$gatewayMasDet["sl_no"];


       
	  "Sensor Master Det Count :".$sensMasDetCount; 

       
  if ($sensMasDetCount > 0) {
        
         // Create connection
		   $apikeyDecd= base64_decode($apiKey);
	 
	  $apiDec =explode("/", $apikeyDecd);
	   $gatewayCode=str_replace("GW:","",$apiDec[0]);
	   $sensorCode=str_replace("SI:","",$apiDec[1]);
	   $sensorModel=str_replace("SMODEL:","",$apiDec[2]);
	   

           $jsonDecd= str_replace(array('[', ',]', ']'), '', $input[0]['VR']);
           $str_arr= explode (",", $jsonDecd); 

		   $liuxTimeStamp=$input[0]['TS'];
           
		 
			if($liuxTimeStamp !="XXXXXX")
			{
				$recordedTimeStamp = date("Y-m-d H:i:s",$input[0]['TS']);
				$telDate =$input[0]['DT'];
				$teltonika_date = str_replace('/', '-', $telDate);
				$teltonikaTimeStamp =  date('Y-m-d H:i:s', strtotime($teltonika_date));
			}
			else
			{
				$liuxTimeStamp='';
				$recordedTimeStamp = ''; 
				$teltonikaTimeStamp='';
			
			}

		   
		    $sqllocationMas = "SELECT * FROM location_master WHERE is_active='1' AND status='1' AND sensor_id='".$sId."' AND iot_id='".$gId."'"; 
          $locSel = $conn->query($sqllocationMas);
		  $locMasDet = mysqli_fetch_assoc($locSel);
	      $locMasDetCount = mysqli_num_rows($locSel);
		  //echo $locMasDetCount; exit;
		  $loc_mas_code = $locMasDet["location_code"];
		  $loc_table_name = $locMasDet["table_name"];

    if ($locMasDetCount > 0) {
		   
	 $selSensorMasterQry = 'SELECT * FROM `sensor_model_master` WHERE model_id = "'.$sensorModel.'" AND status = "1"'; 
	 $ExeSensorMasterQry = mysqli_query($conn, $selSensorMasterQry);
	 if (!$ExeSensorMasterQry) {
		die("Query failed: " . mysqli_error($conn));
	}
	
	$rsltSensorMaster = mysqli_fetch_assoc($ExeSensorMasterQry);
	 $sensorModelId= $rsltSensorMaster['sl_no'];
	$sensorModelSegmentCount= $rsltSensorMaster['segment_count'];

	//echo "element Count : ". $elementCount."<br/>";
	//echo "Segment Model Count : ". $sensorModelSegmentCount."<br/>";
	
	if ($elementCount >= $sensorModelSegmentCount) {
    $allFields = [];
$allValues = [];

// Loop through each segment and collect fields/values
for ($x = 0; $x < $elementCount; $x++) {
    $stRegValue = $input[$x]['ST']; //Start Register : $input[1]['ST'] = 100
    $vrValue = $input[$x]['VR'];
    //echo $stRegValue;
    // Get segment_id
      $segQry = "SELECT segment_id FROM arka_sensor_model_segment_details WHERE sensor_model_id='$sensorModelId' AND start_register_value='$stRegValue' AND status=1"; 
    $segRes = mysqli_query($conn, $segQry);
    if (!$segRes) {
        echo "Segment ID Error: " . mysqli_error($conn) . "<br>SQL: $segQry<br>";
        continue;
    }

    while ($sensorModelSegPara = mysqli_fetch_assoc($segRes)) {
        $mapping_segment_id = $sensorModelSegPara['segment_id'];

        // Parameter mapping query
         $mapParamQry = "SELECT smpm.parameter_name, srpm.register_order FROM sensor_model_parameter_master smpm JOIN start_register_parameter_mapping srpm ON smpm.sl_no = srpm.parameter_id WHERE smpm.sensor_model_id='$sensorModelId' AND srpm.segment_id='$mapping_segment_id' AND srpm.status=1 ORDER BY srpm.map_priority";
        $mapParamRes = mysqli_query($conn, $mapParamQry);
        if (!$mapParamRes) {
            echo "Mapping Error: " . mysqli_error($conn) . "<br>SQL: $mapParamQry<br>";
            continue;
        }

        // Decode VR
        $VrJsonDecd = str_replace(['[', ']', ',]'], '', $vrValue);
		//echo $VrJsonDecd;
        $vr_str_arr = explode(",", $VrJsonDecd);
       //echo "Vr Array".$vr_str_arr[0];
        // Get formula values
         $selFormulaQry = "SELECT smpm.parameter_name, srpm.formula_type, srpm.multiplication_factor, srpm.map_priority, srpm.segment_id, srpm.register_order FROM arka_sensor_model_segment_details smsd
                          JOIN start_register_parameter_mapping srpm ON srpm.segment_id = smsd.segment_id
                          JOIN sensor_model_parameter_master smpm ON srpm.parameter_id = smpm.sl_no
                          WHERE smsd.sensor_model_id='$sensorModelId' AND smsd.start_register_value='$stRegValue'
                          AND smsd.status=1 AND srpm.status=1 AND smpm.status=1
                          ORDER BY srpm.map_priority"; 
        $ExeselFormulaQry = mysqli_query($conn, $selFormulaQry);
        if (!$ExeselFormulaQry) {
            echo "Formula Query Error: " . mysqli_error($conn) . "<br>SQL: $selFormulaQry<br>";
            continue;
        }

        while ($row = mysqli_fetch_assoc($ExeselFormulaQry)) {
            $param = $row['parameter_name'];
            $f_type = $row['formula_type'];
            $mf = $row['multiplication_factor'];
            //$regOrder = $row['map_priority'];
			$regOrder = $row['register_order'];
			$seg_id = $row['segment_id'];

            if ($f_type == 'Single') {

                $index = ($regOrder == 0) ? 0 : $regOrder;
                $rawVal = isset($vr_str_arr[$index]) ? $vr_str_arr[$index] : 0;
				//echo "Index".$index;
				//echo "Row Value".$rawVal."<br>";
				//echo "Row Value Index".$vr_str_arr[$index];
                $evalFormula = str_replace("value", $rawVal, $mf);
                @eval("\$mulFormResult = $evalFormula;");
            } else {
                preg_match_all('/\d+\[(\d+)\]/', $mf, $matches);
                foreach ($matches[1] as $i) {
                    $val = isset($vr_str_arr[$i]) ? $vr_str_arr[$i] : 0;
                    $mf = preg_replace('/\d+\[' . $i . '\]/', $val, $mf);
                }
                @eval("\$mulFormResult = $mf;");
            }

            $allFields[$param] = "`$param`";              // ensures unique field names
            $allValues[$param] = "'$mulFormResult'";
			//echo $param."<br/>";
			//echo $mulFormResult."<br/>";
        }
		//exit;
    }
	
}
//exit;
//echo $allFields; exit;
// Add fixed/shared fields
$fixedFields = [
    'company_id' => "'$comId'",
    'branch_id' => "'$bid'",
	'location_code' => "'$loc_mas_code'",
    'gateway_code' => "'$gatewayCode'",
    'sensor_code' => "'$sensorCode'",
    'sensor_name' => "'$sensorModel'",
    'sensor_model' => "'$sensorModel'",
    'feeder_type' => "'$mType'",
    'unit_rate' => "'$cost'",
	'raw_data' => "'$inputJSON'",
    'linux_date_time' => "'$liuxTimeStamp'",
    'teltonika_date_time' => "'{$input[0]['DT']}'",
    'recorded_date' => "'$teltonikaTimeStamp'",
    'posted_date_time' => "NOW()",
    'is_active' => "'1'",
    'status' => "'1'"
];

// Merge with dynamic fields
$allFields = array_merge($fixedFields, $allFields);

// Build SQL with pretty formatting
$fieldNames = [];
$valueList = [];

// Add dynamic fields first
foreach ($allValues as $key => $value) {
    $fieldNames[] = "`$key`";
    $valueList[] = quoteValue($value);  // Correctly quotes or preserves NOW()
}

// Add fixed/shared fields
foreach ($fixedFields as $key => $value) {
    $fieldNames[] = "`$key`";
    $valueList[] = quoteValue($value);  // Ensures clean quoting
}

//$sensorTableName = str_replace("-", "_", $sensorCode);

$sensorTableName = $loc_table_name;

/******************For Create current month hourly cron table starts ******************/


/**** For Get Selected IOT platform details and table format in Update page Start ****/ 

		$SelIotQuerys = 'SELECT * FROM arka_iot_platform WHERE slNo="'.$segId.'" AND status=1';
		$SelIotDataQuery = mysqli_query($conn, $SelIotQuerys);
        $SelIotData = mysqli_fetch_assoc($SelIotDataQuery);
		$segment_code = $SelIotData['segmentCode'];
		$segment_name = $SelIotData['segmentName'];


		$SelMonthQuerys = "SELECT DATE_FORMAT(CURDATE(), '%b') AS month_short_code, YEAR(CURDATE()) AS current_year";
		$SelMonthDataQuery = mysqli_query($conn, $SelMonthQuerys);
		$SelMonthData = mysqli_fetch_assoc($SelMonthDataQuery);
		$monthShortCode = $SelMonthData['month_short_code']; // JAN, FEB...
		$yearShortCode = $SelMonthData['current_year'];

		$SelCompQuerys	= 'SELECT companyCode FROM `arka_company_master` WHERE slNo="'.$comId.'" AND status=1';
		$SelCompQuerysData = mysqli_query($conn, $SelCompQuerys);
		$SelCompData = mysqli_fetch_assoc($SelCompQuerysData);
		$com_code = $SelCompData['companyCode'];


		$SelBranchQuerys	= 'SELECT branch_id FROM `arka_branch_master` WHERE sl_no="'.$bid.'" AND record_status=1';
        $SelBranchQuerysData = mysqli_query($conn, $SelBranchQuerys);
		$SelBranchData = mysqli_fetch_assoc($SelBranchQuerysData);
		$branch_code = $SelBranchData['branch_id'];


		$com_branch_code = $com_code."_".$branch_code; 



		$com_branch_segment_code = $com_branch_code."_".$segment_code;
		$com_branch_segment_monthly_code = $com_branch_code."_".$segment_code."_cron_monthly";
		$com_branch_segment_daily_code   = $com_branch_code."_".$segment_code."_cron_daily";
		$com_branch_segment_hourly_code  = $com_branch_code."_".$segment_code."_cron_hourly_".$monthShortCode."_".$yearShortCode;

		$monthlyTable = $com_branch_segment_monthly_code;
		$dailyTable   = $com_branch_segment_daily_code;
		$hourlyTable  = $com_branch_segment_hourly_code;

		


		$platformFields = array(

    "Temperature" => "
        min_temperature_c DOUBLE(25,2) NOT NULL,
        max_temperature_c DOUBLE(25,2) NOT NULL,
        avg_temperature_c DOUBLE(25,2) NOT NULL,
        min_temperature_f DOUBLE(25,2) NOT NULL,
        max_temperature_f DOUBLE(25,2) NOT NULL,
        avg_temperature_f DOUBLE(25,2) NOT NULL,
        min_humidity DOUBLE(25,2) NOT NULL,
        max_humidity DOUBLE(25,2) NOT NULL,
        avg_humidity DOUBLE(25,2) NOT NULL,
		cdd_c DOUBLE(25,2) NOT NULL,
		cdd_f DOUBLE(25,2) NOT NULL
    ",

    "Flow Meter" => "
        flow DOUBLE(25,2) NOT NULL,
        totalizer DOUBLE(25,2) NOT NULL,
		start_cum_date datetime NOT NULL,
		end_cum_date datetime NOT NULL
    ",

    "Water Level" => "
        water_level DOUBLE(25,2) NOT NULL,
        totalizer DOUBLE(25,2) NOT NULL,
		start_cum_date datetime NOT NULL,
		end_cum_date datetime NOT NULL
    ",

    "Bus Bar Temperature" => "
        set_point DOUBLE(25,2) NOT NULL,
        break_point DOUBLE(25,2) NOT NULL,
        sensor_temp DOUBLE(25,2) NOT NULL,
        sensor_bat DOUBLE(25,2) NOT NULL
    ",

    "Energy Meter" => "
        start_kwh DOUBLE(25,2) NOT NULL,
        end_kwh DOUBLE(25,2) NOT NULL,
		start_cum_date datetime NOT NULL,
		end_cum_date datetime NOT NULL,
        consuption_kwh DOUBLE(25,2) NOT NULL,
        consuption_cost DOUBLE(25,2) NOT NULL,
        dg_start_kwh DOUBLE(25,2) NOT NULL,
        dg_end_kwh DOUBLE(25,2) NOT NULL,
		dg_start_cum_date datetime NOT NULL,
		dg_end_cum_date datetime NOT NULL,
        dg_consuption_kwh DOUBLE(25,2) NOT NULL,
        dg_consuption_cost DOUBLE(25,2) NOT NULL
    ",

    "Solar Inverter" => "
	    solar_ac_start_kwh DOUBLE(25,2) NOT NULL,
        solar_ac_end_kwh DOUBLE(25,2) NOT NULL,
		solar_ac_start_cum_date datetime NOT NULL,
		solar_ac_end_cum_date datetime NOT NULL,
        solar_ac_consuption_kwh DOUBLE(25,2) NOT NULL,
        solar_ac_consuption_cost DOUBLE(25,2) NOT NULL,
        solar_dg_start_kwh DOUBLE(25,2) NOT NULL,
        solar_dg_end_kwh DOUBLE(25,2) NOT NULL,
		solar_dg_start_cum_date datetime NOT NULL,
		solar_dg_end_cum_date datetime NOT NULL,
        solar_dg_consuption_kwh DOUBLE(25,2) NOT NULL,
        solar_dg_consuption_cost DOUBLE(25,2) NOT NULL
    ",

    "Electric Vehicle" => "
        charging_status INT(2) NOT NULL,
        voltage DOUBLE(25,2) NOT NULL,
        current DOUBLE(25,2) NOT NULL,
        power DOUBLE(25,2) NOT NULL,
        energy DOUBLE(25,2) NOT NULL
    ",

    "Power Factor" => "
        r_phase_pf DOUBLE(10,2) NOT NULL,
        y_phase_pf DOUBLE(10,2) NOT NULL,
        b_phase_pf DOUBLE(10,2) NOT NULL,
        avg_pf DOUBLE(10,2) NOT NULL
    ",

    "Battery Monitoring System" => "
        battery_voltage DOUBLE(25,2) NOT NULL,
        battery_current DOUBLE(25,2) NOT NULL,
        soc DOUBLE(10,2) NOT NULL,
        soh DOUBLE(10,2) NOT NULL,
        temperature DOUBLE(10,2) NOT NULL
    ",

    "Heinn IoT" => "
        parameter_1 DOUBLE(25,2) NOT NULL,
        parameter_2 DOUBLE(25,2) NOT NULL,
        parameter_3 DOUBLE(25,2) NOT NULL
    "
);


if (isset($platformFields[$segment_name])) {
    $tableField = $platformFields[$segment_name];
} else {
    $tableField = "
        start_kwh DOUBLE(25,2) NOT NULL,
        end_kwh DOUBLE(25,2) NOT NULL,
		start_cum_date datetime NOT NULL,
		end_cum_date datetime NOT NULL,
        consuption_kwh DOUBLE(25,2) NOT NULL,
        consuption_cost DOUBLE(25,2) NOT NULL
    ";
}

//echo "Table Field".$tableField; 
/**** For Create Cron Table Start ****/
//echo $segment_name; exit;
    $sqlSensor = "SELECT * FROM arka_sensor_master WHERE isActive='1' AND status='1' AND api_key='".trim($apiKey)."'"; 
    $insSel = $conn->query($sqlSensor);
	
     $result = mysqli_query($conn, $sqlSensor);
	 $sensMasDet = mysqli_fetch_assoc($result);
	 $sensMasDetCount = mysqli_num_rows($result);
	 
	 mysqli_free_result($insSel);

	  $comId=$sensMasDet["company_id"];
	  $bid=$sensMasDet["branch_id"];
	//echo "Company Id".$comId;

	


function createDynamicTable($conn, $tableName, $tableField, $shortby, $comId, $bid)
{

 // Add hour_data only for hourly table
    $hourField = '';
    if ($shortby === 'hourly') {
        $hourField = "hour_data VARCHAR(55) NOT NULL,";
    }

	// Add avg_data only for monthly table
    $avgField = '';
    if ($shortby === 'monthly') {
        $avgField = "avg_data DOUBLE(25,2) NOT NULL,
		              last_six_month_avg_data DOUBLE(25,2) NOT NULL,";
    }

    // Create table query
     $createTableSql = "CREATE TABLE IF NOT EXISTS `$tableName` (
        slNo INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        company_id INT(6) NOT NULL,
        branch_id INT(6) NOT NULL,
        location_code VARCHAR(155) NOT NULL,
        gateway_code VARCHAR(155) NOT NULL,
        sensor_code VARCHAR(155) NOT NULL,
        sensor_name VARCHAR(155) NOT NULL,
        sensor_model VARCHAR(155) NOT NULL,
        feeder_type VARCHAR(155) NOT NULL,
        unit_rate FLOAT(11,2) NOT NULL,
        $tableField,
		$hourField
		$avgField
		raw_data LONGTEXT,
        linux_date_time VARCHAR(55) NOT NULL,
        teltonika_date_time VARCHAR(55) NOT NULL,
        recorded_date DATE NOT NULL,
        posted_date_time DATETIME,
        M_TIMESTAMP TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
		created_by VARCHAR(155) NOT NULL,
        is_active INT(6) DEFAULT 1 NOT NULL,
        status INT(6) DEFAULT 1 NOT NULL
    ) ENGINE=InnoDB"; 
    $conn->query($createTableSql);
    

    // Insert cron table details
    if (!empty($tableName)) {

          $InsQuery = "INSERT INTO cron_table_details (
            company_id,
            branch_id,
            short_by,
            cron_table_name,
            is_active,
            status
        ) VALUES (
            '".$comId."',
            '".$bid."',
            '".$shortby."',
            '".$tableName."',
            '1',
            '1'
        )"; 
      $conn->query($InsQuery);
        
    }
}

/**** For Create Cron Table End ****/

createDynamicTable($conn, $monthlyTable, $tableField, "monthly", $comId, $bid);
createDynamicTable($conn, $dailyTable, $tableField, "daily", $comId, $bid);
createDynamicTable($conn, $hourlyTable, $tableField, "hourly", $comId, $bid);

/**** For Update Cron Hourly Table Month Starts  ****/

$com_branch_segment_code = mysqli_real_escape_string($conn, $com_branch_segment_code);

// 1️⃣ Check current month + year hourly table exists
$SelHourlyTableQuerys = "
SELECT *,
       DATE_FORMAT(CURDATE(), '%b') AS month_short_code,
       YEAR(CURDATE()) AS current_year
FROM cron_table_details
WHERE cron_table_name = CONCAT(
    '".$com_branch_segment_code."_cron_hourly_',
    DATE_FORMAT(CURDATE(), '%b'),
    '_',
    YEAR(CURDATE())
)";

$SelHourlyTableResult = mysqli_query($conn, $SelHourlyTableQuerys);
$SelHourlyTableDataCount = mysqli_num_rows($SelHourlyTableResult);

// 2️⃣ If NOT exists → update old hourly table name
if ($SelHourlyTableDataCount == 0) {

    // Get existing hourly table
    $SelCronHourlyQuerys = "SELECT * FROM cron_table_details WHERE cron_table_name LIKE '".$com_branch_segment_code."_cron_hourly_%' AND short_by = 'hourly' LIMIT 1";
    $SelCronHourlyResult = mysqli_query($conn, $SelCronHourlyQuerys);

    if ($SelCronHourlyResult && mysqli_num_rows($SelCronHourlyResult) > 0) {

        $SelCronHourlyData = mysqli_fetch_assoc($SelCronHourlyResult);

        $oldHourTable   = $SelCronHourlyData['cron_table_name'];
        $oldHourTableId = $SelCronHourlyData['slNo'];
        $newHourTable   = $com_branch_segment_hourly_code;

        // Update table name
        $UpdateQuery = "UPDATE cron_table_details SET cron_table_name = '".$newHourTable."' WHERE slNo = '".$oldHourTableId."'";
	   mysqli_query($conn, $UpdateQuery);
    }
}

/**** For Update Cron Hourly Table Month End  ****/




/**** For Get Selected IOT platform details and table format in Create page End ****/ 

/******************For Create current month hourly cron table Ends */

  $finalSql = "INSERT INTO `$sensorTableName` (\n    " 
    . implode(", ", $fieldNames) . "\n) VALUES (\n    " 
    . implode(", ", $valueList) . "\n);";  

	
	


//echo "<br><b>Final Combined SQL:</b><br><pre>$finalSql</pre><br><br>"; exit;

}


/*************** if condition loop end ************/

//echo "am outside of condition"; exit;

$insSel = $conn->query($finalSql);



		  
if ($insSel === TRUE) {

	 $senModelTableQuery = "SELECT * FROM $sensorTableName WHERE sensor_code='".$sensorCode."' AND status='1' ORDER BY slNo DESC LIMIT 0,1"; 
	$senModelTableData = mysqli_query($conn, $senModelTableQuery);
	$senModelTableDataResult = mysqli_fetch_assoc($senModelTableData);

// 	// Get field names
//    $fields = $senModelTableData->fetch_fields();

// foreach ($fields as $field) {
//     echo $field->name . "<br>";
// }

$extraFields = "";
$extraValues = "";

if($segment_name == 'Energy Meter'){
	$KWH = $senModelTableDataResult['KWH'];
	$DG_KWH = $senModelTableDataResult['DG_KWH'];
	$DG_KWHHr = $senModelTableDataResult['DG_KWH'];

}elseif ($segment_name == 'Temperature') {
	$tem_c = $senModelTableDataResult['temperature_c'];
	$tem_f = $senModelTableDataResult['temperature_f'];
	$hum = $senModelTableDataResult['humidity'];
}elseif ($segment_name == 'Water Level' || $segment_name == 'Flow Meter') {
	$flow_data = $senModelTableDataResult['flow'];
	$totali_data = $senModelTableDataResult['totalizer'];
}elseif ($segment_name == 'Solar Inverter') {
	$AC_kwh = $senModelTableDataResult['AC_KWH'];
	$DG_kwh = $senModelTableDataResult['DG_KWH'];
}else{

	$KWH = $senModelTableDataResult['KWH'];
	$DG_KWH = $senModelTableDataResult['DG_KWH'];
	$DG_KWHHr = $senModelTableDataResult['DG_KWH'];

}
 
 //echo "Flow Data = ".$flow_data."<br/> Totalizer Data = ".$totali_data; exit;
 
//echo $KWH; exit;
	echo "New record created successfully";
} 
else {
	echo "Error: " . $finalSql . "<br>" . $conn->error;
}       
      
}else{

	die("Wrong Sensor and IOT Data.");
}   
       

/*********For Insert into the Specific Cron Tables Starts */

	
	

	/****************     Cron Data Post Starts            **********************/
		$deliverytime = new DateTime(date($teltonikaTimeStamp));
		//echo $teltonikaTimeStamp; 
		//echo $deliverytime->format('H');exit;
		$hour = $deliverytime->format('H');
		$recDate =$deliverytime->format('Y-m-d');
		$hour=intval($hour);
		$currDate=$recDate;
		//$currDate=date('Y-m-d');
		$date2=date_create($currDate);
		date_sub($date2,date_interval_create_from_date_string("1 days"));
		$prevDate=date_format($date2,"Y-m-d");

		/******** Current Date Start *********/
		
		     $selCronDailyData="SELECT * FROM `$com_branch_segment_daily_code` WHERE sensor_code='".$sensorCode."' AND recorded_date='".$currDate."'"; 
		$exeCronDailySel = mysqli_query($conn, $selCronDailyData);
		$cronDataFet = mysqli_fetch_assoc($exeCronDailySel);
		$cronDataCount = mysqli_num_rows($exeCronDailySel);
		mysqli_free_result($exeCronDailySel);
		
		/******** Current Date End *********/

		/******** Previuos Date Start *********/
		
		     $selCronDataYes="SELECT * FROM `$com_branch_segment_daily_code` WHERE sensor_code='".$sensorCode."' AND recorded_date=DATE_SUB('".$currDate."',INTERVAL 1 DAY)";  
		$exeCronSelYes = mysqli_query($conn, $selCronDataYes);
		$cronDataFetYes = mysqli_fetch_assoc($exeCronSelYes);
		$cronDataCountYes = mysqli_num_rows($exeCronSelYes);
		mysqli_free_result($exeCronSelYes);
		
		/******** Previuos Date End *********/
		
		if($cronDataCount>0){
			
		
			/**************** EB Condition *****************/

		if($segment_name == 'Energy Meter'){

			if($cronDataFet["start_kwh"]>0){
				if($cronDataCountYes>0 && $cronDataFetYes["end_cum_date"]>0){
					//echo "<br> if";
					$startKWH=$cronDataFetYes["end_kwh"];
					$startDate=$cronDataFetYes["end_cum_date"];

				}else{

				    $startKWH=$cronDataFet["end_kwh"];
					$startDate=$cronDataFet["start_cum_date"];
					//echo "<br> else<br>";
				}
				$updateSetVal="";
			}
			else{

				if($cronDataCountYes>0 && $cronDataFetYes["end_cum_date"]>0){
					$startKWH=$cronDataFetYes["end_kwh"];
					$startDate=$cronDataFetYes["end_cum_date"];
					//echo "<br> START KWH >".$startKWH."<br>else> if";
				}else{  
					$startKWH=$KWH;
					$startDate=$teltonikaTimeStamp;
					//echo "<br>else> else";
				}
				
				$updateSetVal="start_kwh='".$startKWH."', `start_cum_date`='".$startDate."', ";
				//echo $KWH."<br>start: ".$startKWH;

			}

			$endKWH=$KWH;
			$endDate=$teltonikaTimeStamp;
			
			$consuptionKWH=$endKWH-$startKWH;
            /*echo "Consuption KWH".$consuptionKWH."</br>";
			echo "Start KWH".$startKWH."</br>";
			echo "End KWH".$endKWH."</br>";  */
			if($startKWH > $endKWH){
				$selSensorMasterMaxKwhQry = 'SELECT * FROM `sensor_model_master` WHERE model_id = "'.$sensorModel.'" AND status = "1"';  
				$ExeSensorMasterMaxKwhQry = mysqli_query($conn, $selSensorMasterMaxKwhQry);
				$rsltSensorMasterMaxKwh = mysqli_fetch_assoc($ExeSensorMasterMaxKwhQry);
				$max_kwm_in_meter = $rsltSensorMasterMaxKwh['max_kwh'];
				$consuptionKWH = ($max_kwm_in_meter - $startKWH)+$endKWH;

			}

			//$consuptionKWH=$endKWH-$startKWH;
			$consuptionCost=$consuptionKWH*$cost;
			//echo "Consuption  Cost".$consuptionCost."</br>"; 
			/**************** DG Condition *****************/
			
			if($sensMasDet['meterMode']=='DG'){
				$DG_KWH = $KWH;
			}

			if($cronDataFet["dg_start_kwh"]>0){
				if($cronDataCountYes>0 && $cronDataFetYes["dg_end_cum_date"]>0){
					//echo "<br> if";
					$startDgKWH=$cronDataFetYes["dg_end_kwh"];
					$startDgDate=$cronDataFetYes["dg_end_cum_date"];

				}else{
					$startDgKWH=$cronDataFet["dg_start_kwh"];
					$startDgDate=$cronDataFet["dg_start_cum_date"];
					//echo "<br> else<br>";
				}
				$updateDgSetVal="";
			}
			else{
				if($cronDataCountYes>0 && $cronDataFetYes["dg_end_cum_date"]>0){
					$startDgKWH=$cronDataFetYes["dg_end_kwh"];
					$startDgDate=$cronDataFetYes["dg_end_cum_date"];
					//echo "<br> START KWH >".$startKWH."<br>else> if";
				}else{
					$startDgKWH=$DG_KWH;
					$startDgDate=$teltonikaTimeStamp;
					//echo "<br>else> else";
				}
				$updateDgSetVal=" dg_start_kwh='".$startDgKWH."', `dg_start_cum_date`='".$startDgDate."', ";
				//echo $KWH."<br>start: ".$startKWH;

			}
			//echo $KWH."<br>start: ".$startKWH;

                    
                    $startKWH=$cronDataFetYes["end_kwh"];
					$startDate=$cronDataFetYes["end_cum_date"];



						
			$endDgKWH=$DG_KWH;
			$endDgDate=$teltonikaTimeStamp;
			$costDg=$sensMasDet["dg_unit_rate"];
			$consuptionDgKWH=$endDgKWH-$startDgKWH;
			$consuptionDgCost=$consuptionDgKWH*$costDg;

		}elseif($segment_name == 'Temperature'){


			  $selTemMinMaxAvgQry ="SELECT MIN(temperature_c) AS min_t_c,MAX(temperature_c) AS max_t_c,AVG(temperature_c) AS avg_t_c,MIN(temperature_f) AS min_t_f,MAX(temperature_f) AS max_t_f,AVG(temperature_f) AS avg_t_f,MIN(humidity) AS min_hum,MAX(humidity) AS max_hum,AVG(humidity) AS avg_hum FROM ".$sensorTableName." WHERE sensor_code = '".$sensorCode."' AND recorded_date >= CURDATE() AND recorded_date < CURDATE() + INTERVAL 1 DAY"; 

				$ExeSelTemMinMaxAvgQry = mysqli_query($conn, $selTemMinMaxAvgQry);
				$rsltTemMinMaxAvg = mysqli_fetch_assoc($ExeSelTemMinMaxAvgQry);

				$min_tem_c = isset($rsltTemMinMaxAvg['min_t_c']) ? $rsltTemMinMaxAvg['min_t_c'] : 0;
				$max_tem_c = isset($rsltTemMinMaxAvg['max_t_c']) ? $rsltTemMinMaxAvg['max_t_c'] : 0;
				$avg_tem_c = isset($rsltTemMinMaxAvg['avg_t_c']) ? $rsltTemMinMaxAvg['avg_t_c'] : 0;

				$min_tem_f = isset($rsltTemMinMaxAvg['min_t_f']) ? $rsltTemMinMaxAvg['min_t_f'] : 0;
				$max_tem_f = isset($rsltTemMinMaxAvg['max_t_f']) ? $rsltTemMinMaxAvg['max_t_f'] : 0;
				$avg_tem_f = isset($rsltTemMinMaxAvg['avg_t_f']) ? $rsltTemMinMaxAvg['avg_t_f'] : 0;

				$min_tem_hum = isset($rsltTemMinMaxAvg['min_hum']) ? $rsltTemMinMaxAvg['min_hum'] : 0;
				$max_tem_hum = isset($rsltTemMinMaxAvg['max_hum']) ? $rsltTemMinMaxAvg['max_hum'] : 0;
				$avg_tem_hum = isset($rsltTemMinMaxAvg['avg_hum']) ? $rsltTemMinMaxAvg['avg_hum'] : 0;
				
				// Base temperatures
				$base_f = 65;
				$base_c = 18;

				// Mean temperature calculation
				$mean_f = ($max_tem_f + $min_tem_f) / 2;
				$mean_c = ($max_tem_c + $min_tem_c) / 2;

				// CDD calculation
				$cdd_f = ($mean_f > $base_f) ? ($mean_f - $base_f) : 0;
				$cdd_c = ($mean_c > $base_c) ? ($mean_c - $base_c) : 0;


		}elseif($segment_name == 'Water Level' || $segment_name == 'Flow Meter'){

							$start_flow = $flow_data;
							$totali = $totali_data;

						}elseif ($segment_name == 'Solar Inverter') {
							
				$AC_KWH = $AC_kwh;
				$DG_KWH = $DG_kwh;

				/**************** Solar AC KWH Condition *****************/


				if($cronDataFet["solar_ac_start_kwh"]>0){
				if($cronDataCountYes>0 && $cronDataFetYes["solar_ac_end_cum_date"]>0){
					//echo "<br> if";
					$solarAcStartKWH=$cronDataFetYes["solar_ac_end_kwh"];
					$solarAcStartDate=$cronDataFetYes["solar_ac_end_cum_date"];

				}else{

				    $solarAcStartKWH=$cronDataFet["solar_ac_end_kwh"];
					$solarAcStartDate=$cronDataFet["solar_ac_start_cum_date"];
					//echo "<br> else<br>";
				}
				$updateSetVal="solar_ac_start_kwh='".$solarAcStartKWH."', `solar_ac_start_cum_date`='".$solarAcStartDate."', ";
			}
			else{

				if($cronDataCountYes>0 && $cronDataFetYes["solar_ac_end_cum_date"]>0){
					$solarAcStartKWH=$cronDataFetYes["solar_ac_end_kwh"];
					$solarAcStartDate=$cronDataFetYes["solar_ac_end_cum_date"];
					//echo "<br> START KWH >".$startKWH."<br>else> if";
				}else{  
					$solarAcStartKWH=$AC_KWH;
					$solarAcStartDate=$teltonikaTimeStamp;
					//echo "<br>else> else";
				}
				
				$updateSetVal="solar_ac_start_kwh='".$solarAcStartKWH."', `solar_ac_start_cum_date`='".$solarAcStartDate."', ";
				//echo $KWH."<br>start: ".$startKWH;

			}

			$solarAcEndKWH=$AC_KWH;
			$solarAcEndDate=$teltonikaTimeStamp;
			
			$consuptionKWH=$solarAcEndKWH-$solarAcStartKWH;
            /*echo "Consuption KWH".$consuptionKWH."</br>";
			echo "Start KWH".$startKWH."</br>";
			echo "End KWH".$endKWH."</br>";  */
			if($solarAcStartKWH > $solarAcEndKWH){
				$selSensorMasterMaxKwhQry = 'SELECT * FROM `sensor_model_master` WHERE model_id = "'.$sensorModel.'" AND status = "1"';  
				$ExeSensorMasterMaxKwhQry = mysqli_query($conn, $selSensorMasterMaxKwhQry);
				$rsltSensorMasterMaxKwh = mysqli_fetch_assoc($ExeSensorMasterMaxKwhQry);
				$max_kwm_in_meter = $rsltSensorMasterMaxKwh['max_kwh'];
				$consuptionKWH = ($max_kwm_in_meter - $solarAcStartKWH)+$solarAcEndKWH;

			}

			//$consuptionKWH=$endKWH-$startKWH;
			$consuptionCost=$consuptionKWH*$cost;
			//echo "Consuption  Cost".$consuptionCost."</br>"; 


			/**************** Solar DG KWH Condition *****************/
			
			if($sensMasDet['meterMode']=='DG'){
				$DG_KWH = $KWH;
			}

			if($cronDataFet["solar_dg_start_kwh"]>0){

			//echo"am in if";
				if($cronDataCountYes>0 && $cronDataFetYes["solar_dg_end_cum_date"]>0){
					//echo "<br> if";
					$solarStartDgKWH=$cronDataFetYes["solar_dg_end_kwh"];
					$solarStartDgDate=$cronDataFetYes["solar_dg_end_cum_date"];

				}else{
					$solarStartDgKWH=$cronDataFet["solar_dg_end_kwh"];
					$solarStartDgDate=$cronDataFet["solar_dg_start_cum_date"];
					//echo "<br> else<br>";
				}

				$solarEndDgKWH=$DG_KWH;

				$updateDgSetVal=" solar_dg_start_kwh='".$solarStartDgKWH."', `solar_dg_start_cum_date`='".$solarStartDgDate."', ";
			}
			else{
				//echo"am in else";
				if($cronDataCountYes>0 && $cronDataFetYes["solar_dg_end_cum_date"]>0){
					$solarStartDgKWH=$cronDataFetYes["solar_dg_end_kwh"];
					$solarStartDgDate=$cronDataFetYes["solar_dg_end_cum_date"];
					//echo "<br> START KWH >".$startKWH."<br>else> if";
				}else{
					$solarStartDgKWH=$cronDataFet["solar_dg_end_kwh"];
					$solarStartDgDate=$cronDataFet["solar_dg_end_kwh"];
					//echo "<br>else> else";
				}
				$updateDgSetVal=" solar_dg_start_kwh='".$solarStartDgKWH."', `solar_dg_start_cum_date`='".$solarStartDgDate."', ";
				//echo $KWH."<br>start: ".$startKWH;

			}
			//echo $DG_KWH."<br>start: ".$solarStartDgKWH;

                    
                    $solarStartKWH=$cronDataFetYes["solar_ac_end_kwh"];
					$solarStartAcDate=$cronDataFetYes["solar_ac_end_cum_date"];



						
			$solarEndDgKWH=$DG_KWH;
			$solarEndDgDate=$teltonikaTimeStamp;
			$costDg=$sensMasDet["dg_unit_rate"];
			$consuptionDgKWH=$solarEndDgKWH-$solarStartDgKWH;
			$consuptionDgCost=$consuptionDgKWH*$costDg;

			

			//echo "consuptionDgKWH = ".$solarEndDgKWH."-".$solarStartDgKWH."<br/>";

			
        }
		//echo "Solar DG End KWH".$solarEndDgKWH."<br>";
		//echo "Solar DG Start KWH".$solarStartDgKWH."<br>";
		//echo "DG Consuption KWH".$consuptionDgKWH; exit;
			$extraFieldsValues = "";
   
				if($segment_name == 'Energy Meter'){

				$extraFieldsValues = "unit_rate='".$sensMasDet['unit_rate']."', end_kwh='".$endKWH."', end_cum_date='".$endDate."', 
				consuption_kwh='".$consuptionKWH."', consuption_cost='".$consuptionCost."', 
				dg_start_kwh'".$startDgKWH."', dg_end_kwh='".$endDgKWH."', dg_start_cum_date='".$startDgDate."', dg_end_cum_date='".$endDgDate."', 
				dg_consuption_kwh='".$consuptionDgKWH."', dg_consuption_cost='".$consuptionDgCost."'";

				}elseif ($segment_name == 'Temperature') {

				//echo "am in temperature"; 

				  $extraFieldsValues = "min_temperature_c='".$min_tem_c."',max_temperature_c='".$max_tem_c."',avg_temperature_c='".$avg_tem_c."', min_temperature_f='".$min_tem_f."',max_temperature_f='".$max_tem_f."',avg_temperature_f='".$avg_tem_f."', min_humidity='".$min_tem_hum."',max_humidity='".$max_tem_hum."',avg_humidity='".$avg_tem_hum."',cdd_c='".$cdd_c."',cdd_f='".$cdd_f."'"; 
				  $updateSetVal = "";
				  $updateDgSetVal = "";

				}elseif($segment_name == 'Water Level' || $segment_name == 'Flow Meter'){

                  $extraFieldsValues = "flow='".$start_flow."',totalizer='".$totali."'";  
				  $updateSetVal = "";
				  $updateDgSetVal = "";

				}elseif ($segment_name == 'Solar Inverter') {



					 $extraFieldsValues = "unit_rate='".$sensMasDet['unit_rate']."',solar_ac_end_kwh='".$solarAcEndKWH."',solar_ac_end_cum_date='".$solarAcEndDate."', solar_ac_consuption_kwh='".$consuptionKWH."', solar_ac_consuption_cost='".$consuptionCost."',  solar_dg_end_kwh='".$solarEndDgKWH."', solar_dg_end_cum_date='".$solarEndDgDate."', solar_dg_consuption_kwh='".$consuptionDgKWH."', solar_dg_consuption_cost='".$consuptionDgCost."'"; 
					
        }
		//echo "updateSetVal Fields".$updateSetVal."<br>";
		//echo "updateDgSetVal Fields".$updateDgSetVal."<br>"; 
		//echo "extraFields Values".$extraFieldsValues; exit;

//echo $extraFieldsValues; exit;

			            $UpdateDailyCronQry="UPDATE `$com_branch_segment_daily_code` SET ".$updateSetVal." `feeder_type`='".$sensMasDet["feeder_type"]."', ".$extraFieldsValues.", `raw_data` = '".$inputJSON."',`posted_date_time`=NOW(),".$updateDgSetVal." `created_by`='API' WHERE `company_id`='".$sensMasDet['company_id']."' AND `branch_id`='".$sensMasDet['branch_id']."' AND `gateway_code`='".$sensMasDet['gateway_id']."' AND sensor_code='".$sensorCode."' AND `recorded_date`='".$currDate."'";   

			$conn->query($UpdateDailyCronQry);
		
		
		}else{

		//echo"am in else"; exit;

		   if($segment_name == 'Energy Meter'){
			/***************   EB Condition Starts     ***********************/
				if($cronDataCountYes>0 && $cronDataFetYes["end_cum_date"] >0){


						$startKWH=$cronDataFetYes["end_kwh"];					
					    $startDate=$cronDataFetYes["end_cum_date"];

				}else{

					$startKWH=$KWH;					
					$startDate=$teltonikaTimeStamp;

				}
				$endKWH=$KWH;
				$endDate=$teltonikaTimeStamp;
				$cost=$sensMasDet["unit_rate"];

				$consuptionKWH=$endKWH-$startKWH;
			if($startKWH > $endKWH){
				$selSensorMasterMaxKwhQry = 'SELECT * FROM `sensor_model_master` WHERE model_id = "'.$sensorModel.'" AND status = "1"';  
				$ExeSensorMasterMaxKwhQry = mysqli_query($conn, $selSensorMasterMaxKwhQry);
				$rsltSensorMasterMaxKwh = mysqli_fetch_assoc($ExeSensorMasterMaxKwhQry);
				$max_kwm_in_meter = $rsltSensorMasterMaxKwh['max_kwh'];
				$consuptionKWH = ($max_kwm_in_meter - $startKWH)+$endKWH;

			}

				//$consuptionKWH=$endKWH-$startKWH;
				$consuptionCost=$consuptionKWH*$cost;
				if($consuptionKWH<=0){
				  $consuptionCost=0;  
				}

				/***************   DG Condition Starts     ***********************/
				
				if($sensMasDet['meterMode']=='DG'){
					$DG_KWH = $KWH;
				}

				if($cronDataCountYes>0 && $cronDataFetYes["dg_end_cum_date"] >0){
					$startDgKWH=$cronDataFetYes["dg_end_kwh"];
					$startDgDate=$cronDataFetYes["dg_end_cum_date"];

				}else{
					$startDgKWH=$DG_KWH;
					$startDgDate=$teltonikaTimeStamp;

				}
				$endDgKWH=$DG_KWH;
				$endDgDate=$teltonikaTimeStamp;
				$costDg=$sensMasDet["dg_unit_rate"];
				$consuptionDgKWH=$endDgKWH-$startDgKWH;
				$consuptionDgCost=$consuptionDgKWH*$costDg;
				//echo "am in else1"; exit;	
				

				$extraFields = "unit_rate, start_kwh, end_kwh, start_cum_date, end_cum_date, 
				consuption_kwh, consuption_cost, 
				dg_start_kwh, dg_end_kwh, dg_start_cum_date, dg_end_cum_date, 
				dg_consuption_kwh, dg_consuption_cost";

				$extraValues = "'".$cost."',
				'".$startKWH."',
				'".$endKWH."',
				'".$startDate."',
				'".$endDate."',
				'".$consuptionKWH."',
				'".$consuptionCost."',
				'".$startDgKWH."',
				'".$endDgKWH."',
				'".$startDgDate."',
				'".$endDgDate."',
				'".$consuptionDgKWH."',
				'".$consuptionDgCost."'";

				}elseif ($segment_name == 'Temperature') {

				//echo "am in temperature"; 


				          $min_tem_c = $cronDataFetYes["min_temperature_c"];
						  $max_tem_c = $cronDataFetYes["max_temperature_c"];
						  $avg_tem_c = $cronDataFetYes["avg_temperature_c"];
						  $min_tem_f = $cronDataFetYes["min_temperature_f"];
						  $max_tem_f = $cronDataFetYes["max_temperature_f"];
						  $avg_tem_f = $cronDataFetYes["avg_temperature_f"];
						  $min_tem_hum = $cronDataFetYes["min_humidity"];
						  $max_tem_hum = $cronDataFetYes["max_humidity"];
						  $avg_tem_hum = $cronDataFetYes["avg_humidity"];
						  $cdd_f = $cronDataFetYes["cdd_f"];
						  $cdd_c = $cronDataFetYes["cdd_c"];
						 

							
				$extraFields = "min_temperature_c,max_temperature_c,avg_temperature_c, min_temperature_f,max_temperature_f,avg_temperature_f, min_humidity,max_humidity,avg_humidity,cdd_c,cdd_f";

				$extraValues = "'".$min_tem_c."',
				'".$max_tem_c."',
				'".$avg_tem_c."','".$min_tem_f."',
				'".$max_tem_f."',
				'".$avg_tem_f."','".$min_tem_hum."',
				'".$max_tem_hum."',
				'".$avg_tem_hum."',
				'".$cdd_c."',
				'".$cdd_f."'";
				}elseif($segment_name == 'Water Level' || $segment_name == 'Flow Meter'){

				$extraFields = "flow,totalizer";

				$start_flow = $cronDataFetYes['flow'];
				$totali = $cronDataFetYes['totalizer'];
				
				$extraValues = "'".$start_flow."','".$totali."'";


				}elseif($segment_name == 'Solar Inverter'){

     /***************  Solar AC KWH Condition Starts     ***********************/

	            $AC_KWH = $AC_kwh;
				$DG_KWH = $DG_kwh;

				if($cronDataCountYes>0 && $cronDataFetYes["solar_ac_end_cum_date"] >0){


						$solarAcStartKWH=$cronDataFetYes["solar_ac_end_kwh"];					
					    $solarAcStartDate=$cronDataFetYes["solar_ac_end_cum_date"];

				}else{

					$solarAcStartKWH=$AC_KWH;					
					$solarAcStartDate=$teltonikaTimeStamp;

				}
				$solarAcEndKWH=$AC_KWH;
				$solarAcEndDate=$teltonikaTimeStamp;
				$cost=$sensMasDet["unit_rate"];
				
//echo "Solar AC Start KWH".$solarAcStartKWH; exit;
				$consuptionKWH=$solarAcEndKWH-$solarAcStartKWH;
			if($solarAcStartKWH > $solarAcEndKWH){
				$selSensorMasterMaxKwhQry = 'SELECT * FROM `sensor_model_master` WHERE model_id = "'.$sensorModel.'" AND status = "1"';  
				$ExeSensorMasterMaxKwhQry = mysqli_query($conn, $selSensorMasterMaxKwhQry);
				$rsltSensorMasterMaxKwh = mysqli_fetch_assoc($ExeSensorMasterMaxKwhQry);
				$max_kwm_in_meter = $rsltSensorMasterMaxKwh['max_kwh'];
				$consuptionKWH = ($max_kwm_in_meter - $solarAcStartKWH)+$solarAcEndKWH;

			}

				//$consuptionKWH=$endKWH-$startKWH;
				$consuptionCost=$consuptionKWH*$cost;
				if($consuptionKWH<=0){
				  $consuptionCost=0;  
				}

				


				/***************   Solar DG KWH Condition Starts     ***********************/
				
				if($sensMasDet['meterMode']=='DG'){
					$DG_KWH = $KWH;
				}

				if($cronDataCountYes>0 && $cronDataFetYes["solar_dg_end_cum_date"] >0){
					$solarStartDgKWH=$cronDataFetYes["solar_dg_end_kwh"];
					$solarStartDgDate=$cronDataFetYes["solar_dg_end_cum_date"];

				}else{
					$solarStartDgKWH=$DG_KWH;
					$solarStartDgDate=$teltonikaTimeStamp;

				}
				$solarEndDgKWH=$DG_KWH;
				$solarEndDgDate=$teltonikaTimeStamp;
				$costDg=$sensMasDet["dg_unit_rate"];
				$consuptionDgKWH=$solarEndDgKWH-$solarStartDgKWH;
				$consuptionDgCost=$consuptionDgKWH*$costDg;
				//echo "am in else1"; exit;	

     // echo "Extra Fields".$extraFieldsValues."<br>";
		//echo "solar_ac_start_kwh ".$solarAcStartKWH."<br>";
		//echo "solar_ac_end_kwh".$solarAcEndKWH; exit;

				$extraFields = "unit_rate, solar_ac_start_kwh, solar_ac_end_kwh, solar_ac_start_cum_date, solar_ac_end_cum_date, 
				solar_ac_consuption_kwh, solar_ac_consuption_cost, 
				solar_dg_start_kwh, solar_dg_end_kwh, solar_dg_start_cum_date, solar_dg_end_cum_date, 
				solar_dg_consuption_kwh, solar_dg_consuption_cost";

				$extraValues = "'".$sensMasDet['unit_rate']."',
				'".$solarAcStartKWH."',
				'".$solarAcEndKWH."',
				'".$solarAcStartDate."',
				'".$solarAcEndDate."',
				'".$consuptionKWH."',
				'".$consuptionCost."',
				'".$solarStartDgKWH."',
				'".$solarEndDgKWH."',
				'".$solarStartDgDate."',
				'".$solarEndDgDate."',
				'".$consuptionDgKWH."',
				'".$consuptionDgCost."'";



				}

				//echo "Extra Fields".$extraFields."<br>";
				//echo "Extra Values".$extraValues; exit;

				
				  $insDailyQueryCron = "INSERT INTO $com_branch_segment_daily_code 
				(company_id, branch_id, location_code, gateway_code, sensor_code,
				sensor_name, sensor_model, feeder_type, raw_data, linux_date_time,
				teltonika_date_time, recorded_date, posted_date_time, created_by"

				.($extraFields != "" ? ",".$extraFields : "").")

				VALUES
				('".$sensMasDet['company_id']."',
				'".$sensMasDet['branch_id']."',
				'".$loc_mas_code."',
				'".$sensMasDet['gateway_id']."',
				'".$sensorCode."',
				'".$sensorModel."',
				'".$sensorModel."',
				'".$sensMasDet["feeder_type"]."',
				'".$inputJSON."',
				'".$liuxTimeStamp."',
				'".$input[0]['DT']."',
				'".$teltonikaTimeStamp."',
				NOW(),
				'Cron'"

				.($extraValues != "" ? ",".$extraValues : "").")";
			
			if (!$conn->query($insDailyQueryCron)) {
    		echo "SQL Error: " . $conn->error;
				}
		}
		
		
		
		/****************     Cron Daily Data Post Ends        **********************/
//echo "am outside"; exit;
		/****************     Cron Hourly Data Post Starts           **********************/

		if($hour==0){
			$prevHour=23;
			$lastHourDate=$currDate;
		}else{
			$prevHour=$hour-1;
			$lastHourDate=$currDate;
		}
			$currHour=$hour;
		
		//echo $currDate."Curr Date <br>";
		//echo $prevDate."Prvi Date <br>";
		/******** Current Date Start *********/
		
		      $selCronDataHrly="SELECT * FROM `$com_branch_segment_hourly_code` WHERE sensor_code='".$sensorCode."' AND recorded_date='".$currDate."' AND hour_data='".$currHour."'";    
		$exeCronSelHrly = mysqli_query($conn, $selCronDataHrly);
		$cronDataFetHrly = mysqli_fetch_assoc($exeCronSelHrly);
		$cronDataCountHrly = mysqli_num_rows($exeCronSelHrly);
		mysqli_free_result($exeCronSelHrly);
		
		/******** Current Date End *********/

		/******** Previuos Date Start *********/
		
		   $selCronDataYesHrly="SELECT * FROM `$com_branch_segment_hourly_code` WHERE sensor_code='".$sensorCode."' AND recorded_date='".$lastHourDate."' AND hour_data='".$prevHour."'";   
		$exeCronSelYesHrly = mysqli_query($conn, $selCronDataYesHrly);
		$cronDataFetYesHrly = mysqli_fetch_assoc($exeCronSelYesHrly);
		$cronDataCountYesHrly = mysqli_num_rows($exeCronSelYesHrly);
		mysqli_free_result($exeCronSelYesHrly);

		
		/******** Previuos Date End *********/
		
		if($cronDataCountHrly>0){
		
			/**************** EB Condition *****************/

			if($segment_name == 'Energy Meter'){

			if($cronDataFetHrly["start_kwh"]>0){
				if($cronDataCountYesHrly>0 && $cronDataFetYesHrly["end_cum_date"]>0){
					//echo "<br> if";
					$startKWHHr=$cronDataFetYesHrly["end_kwh"];
					$startDateHr=$cronDataFetYesHrly["end_cum_date"];

				}else{
					$startKWHHr=$cronDataFetHrly["start_kwh"];
					$startDateHr=$cronDataFetHrly["start_cum_date"];
					//echo "<br> else<br>";
				}
				$updateSetValHr="";
			}
			else{
				if($cronDataCountYesHrly>0 && $cronDataFetYesHrly["end_cum_date"]>0){
					$startKWHHr=$cronDataFetYesHrly["end_kwh"];
					$startDateHr=$cronDataFetYesHrly["end_cum_date"];
					//echo "<br> START KWH >".$startKWH."<br>else> if";
				}else{
					$startKWHHr=$KWH;
					$startDateHr=$teltonikaTimeStamp;
					//echo "<br>else> else";
				}
				$updateSetVal='start_kwh="'.$startKWHHr.'", `start_cum_date`="'.$startDateHr.'", ';
				//echo $KWH."<br>start: ".$startKWH;

			}
			$endKWHHr=$KWH;
			$endDateHr=$teltonikaTimeStamp;
			$costHr=$sensMasDet["unit_rate"];

			$consuptionKWHHr=$endKWHHr-$startKWHHr;
			if($startKWHHr > $endKWHHr){
				$selSensorMasterMaxKwhHrQry = 'SELECT * FROM `sensor_model_master` WHERE model_id = "'.$sensorModel.'" AND status = "1"';  
				$ExeSensorMasterMaxKwhHrQry = mysqli_query($conn, $selSensorMasterMaxKwhHrQry);
				$rsltSensorMasterMaxKwhHr = mysqli_fetch_assoc($ExeSensorMasterMaxKwhHrQry);
				$max_kwm_in_meter_Hr = $rsltSensorMasterMaxKwhHr['max_kwh'];
				$consuptionKWHHr = ($max_kwm_in_meter_Hr - $startKWHHr)+$endKWHHr;

			}
			//$consuptionKWHHr=$endKWHHr-$startKWHHr;
			$consuptionCostHr=$consuptionKWHHr*$costHr;
			
			/**************** DG Condition *****************/
			
			if($cronDataFetHrly["dg_start_kwh"]>0){
				if($cronDataCountYesHrly>0 && $cronDataFetYesHrly["dg_end_cum_date"]>0){
					//echo "<br> if";
					$startDgKWHHr=$cronDataFetYesHrly["dg_end_kwh"];
					$startDgDateHr=$cronDataFetYesHrly["dg_end_cum_date"];

				}else{
					$startDgKWHHr=$cronDataFetHrly["dg_start_kwh"];
					$startDgDateHr=$cronDataFetHrly["dg_start_cum_date"];
					//echo "<br> else<br>";
				}
				$updateDgSetValHr="";
			}
			else{
				if($cronDataCountYesHrly>0 && $cronDataFetYesHrly["dg_end_cum_date"]>0){
					$startDgKWHHr=$cronDataFetYesHrly["dg_end_kwh"];
					$startDgDateHr=$cronDataFetYesHrly["dg_end_cum_date"];
					//echo "<br> START KWH >".$startKWH."<br>else> if";
				}else{
					$startDgKWHHr=$DG_KWH;
					$startDgDateHr=$teltonikaTimeStamp;
					//echo "<br>else> else";
				}
				$updateDgSetValHr=' dg_start_kwh="'.$startDgKWHHr.'", `dg_start_cum_date`="'.$startDgDateHr.'", ';
				//echo $KWH."<br>start: ".$startKWH;

			}
			//echo $KWH."<br>start: ".$startKWH;

						
			$endDgKWHHr=$DG_KWH;
			$endDgDateHr=$teltonikaTimeStamp;
			$costDgHr=$sensMasDet["dg_unit_rate"];
			$consuptionDgKWHHr=$endDgKWHHr-$startDgKWHHr;
			$consuptionDgCostHr=$consuptionDgKWHHr*$costDgHr;

			}elseif($segment_name == 'Temperature'){

                          
				 $selTemMinMaxAvgQry ="SELECT MIN(temperature_c) AS min_t_c,MAX(temperature_c) AS max_t_c,AVG(temperature_c) AS avg_t_c,MIN(temperature_f) AS min_t_f,MAX(temperature_f) AS max_t_f,AVG(temperature_f) AS avg_t_f,MIN(humidity) AS min_hum,MAX(humidity) AS max_hum,AVG(humidity) AS avg_hum FROM ".$sensorTableName." WHERE sensor_code = '".$sensorCode."' AND recorded_date >= CURDATE() AND recorded_date < CURDATE() + INTERVAL 1 DAY"; 

				$ExeSelTemMinMaxAvgQry = mysqli_query($conn, $selTemMinMaxAvgQry);
				$rsltTemMinMaxAvgHr = mysqli_fetch_assoc($ExeSelTemMinMaxAvgQry);

				$min_tem_c = isset($rsltTemMinMaxAvgHr['min_t_c']) ? $rsltTemMinMaxAvgHr['min_t_c'] : 0;
				$max_tem_c = isset($rsltTemMinMaxAvgHr['max_t_c']) ? $rsltTemMinMaxAvgHr['max_t_c'] : 0;
				$avg_tem_c = isset($rsltTemMinMaxAvgHr['avg_t_c']) ? $rsltTemMinMaxAvgHr['avg_t_c'] : 0;

				$min_tem_f = isset($rsltTemMinMaxAvgHr['min_t_f']) ? $rsltTemMinMaxAvgHr['min_t_f'] : 0;
				$max_tem_f = isset($rsltTemMinMaxAvgHr['max_t_f']) ? $rsltTemMinMaxAvgHr['max_t_f'] : 0;
				$avg_tem_f = isset($rsltTemMinMaxAvgHr['avg_t_f']) ? $rsltTemMinMaxAvgHr['avg_t_f'] : 0;

				$min_tem_hum = isset($rsltTemMinMaxAvgHr['min_hum']) ? $rsltTemMinMaxAvgHr['min_hum'] : 0;
				$max_tem_hum = isset($rsltTemMinMaxAvgHr['max_hum']) ? $rsltTemMinMaxAvgHr['max_hum'] : 0;
				$avg_tem_hum = isset($rsltTemMinMaxAvgHr['avg_hum']) ? $rsltTemMinMaxAvgHr['avg_hum'] : 0;
						
						// Base temperatures
				$base_f = 65;
				$base_c = 18;

				// Mean temperature calculation
				$mean_f = ($max_tem_f + $min_tem_f) / 2;
				$mean_c = ($max_tem_c + $min_tem_c) / 2;

				// CDD calculation
				$cdd_f = ($mean_f > $base_f) ? ($mean_f - $base_f) : 0;
				$cdd_c = ($mean_c > $base_c) ? ($mean_c - $base_c) : 0; 
							  


						}elseif($segment_name == 'Water Level' || $segment_name == 'Flow Meter'){

							$start_flowHr = $flow_data;
							$totaliHr = $totali_data;

						}elseif($segment_name == 'Solar Inverter'){



				$AC_KWH = $AC_kwh;
				$DG_KWH = $DG_kwh;

				/**************** Solar AC KWH Condition *****************/


				if($cronDataFetHrly["solar_ac_start_kwh"]>0){
				if($cronDataCountYesHrly>0 && $cronDataFetYesHrly["solar_ac_end_cum_date"]>0){
					//echo "<br> if";
					$solarAcStartKWHHr=$cronDataFetYesHrly["solar_ac_end_kwh"];
					$solarAcStartDateHr=$cronDataFetYesHrly["solar_ac_end_cum_date"];

				}else{

				    $solarAcStartKWHHr=$cronDataFetHrly["solar_ac_end_kwh"];
					$solarAcStartDateHr=$cronDataFetHrly["solar_ac_start_cum_date"];
					//echo "<br> else<br>";
				}
				$updateSetValHr="";
			}
			else{

				if($cronDataCountYesHrly>0 && $cronDataFetYesHrly["solar_ac_end_cum_date"]>0){
					$solarAcStartKWHHr=$cronDataFetYesHrly["solar_ac_end_kwh"];
					$solarAcStartDateHr=$cronDataFetYesHrly["solar_ac_end_cum_date"];
					//echo "<br> START KWH >".$startKWH."<br>else> if";
				}else{  
					$solarAcStartKWHHr=$AC_KWH;
					$solarAcStartDateHr=$teltonikaTimeStamp;
					//echo "<br>else> else";
				}
				
				$updateSetValHr="solar_ac_start_kwh='".$solarAcStartKWHHr."', `solar_ac_start_cum_date`='".$solarAcStartDateHr."', ";
				//echo $KWH."<br>start: ".$startKWH;

			}

			$solarAcEndKWHHr=$AC_KWH;
			$solarAcEndDateHr=$teltonikaTimeStamp;
			
			$consuptionKWHHr=$solarAcEndKWHHr-$solarAcStartKWHHr;
            /*echo "Consuption KWH".$consuptionKWH."</br>";
			echo "Start KWH".$startKWH."</br>";
			echo "End KWH".$endKWH."</br>";  */
			if($solarAcStartKWHHr > $solarAcEndKWHHr){
				$selSensorMasterMaxKwhQry = 'SELECT * FROM `sensor_model_master` WHERE model_id = "'.$sensorModel.'" AND status = "1"';  
				$ExeSensorMasterMaxKwhQry = mysqli_query($conn, $selSensorMasterMaxKwhQry);
				$rsltSensorMasterMaxKwh = mysqli_fetch_assoc($ExeSensorMasterMaxKwhQry);
				$max_kwm_in_meter = $rsltSensorMasterMaxKwh['max_kwh'];
				$consuptionKWHHr = ($max_kwm_in_meter - $solarAcStartKWHHr)+$solarAcEndKWHHr;

			}

			//$consuptionKWH=$endKWH-$startKWH;
			$consuptionCostHr=$consuptionKWHHr*$cost;
			//echo "Consuption  Cost".$consuptionCost."</br>"; 


			/**************** Solar DG KWH Condition *****************/
			
			if($sensMasDet['meterMode']=='DG'){
				$DG_KWH = $KWH;
			}

			if($cronDataFetHrly["solar_dg_start_kwh"]>0){
				if($cronDataCountYesHrly>0 && $cronDataFetYesHrly["solar_dg_end_cum_date"]>0){
					//echo "<br> if";
					$solarStartDgKWHHr=$cronDataFetYesHrly["solar_dg_start_kwh"];
					$solarStartDgDateHr=$cronDataFetYesHrly["solar_dg_end_cum_date"];

				}else{
					$solarStartDgKWHHr=$cronDataFetHrly["solar_dg_start_kwh"];
					$solarStartDgDateHr=$cronDataFetHrly["solar_dg_start_cum_date"];
					//echo "<br> else<br>";
				}
				
			}
			else{
				if($cronDataCountYesHrly>0 && $cronDataFetYesHrly["solar_dg_end_cum_date"]>0){
					$solarStartDgKWHHr=$cronDataFetYesHrly["solar_dg_end_kwh"];
					$solarStartDgDateHr=$cronDataFetYesHrly["solar_dg_end_cum_date"];
					//echo "<br> START KWH >".$startKWH."<br>else> if";
				}else{
					$solarStartDgKWHHr=$DG_KWH;
					$solarStartDgDateHr=$teltonikaTimeStamp;
					//echo "<br>else> else";
				}
				
				//echo $KWH."<br>start: ".$startKWH;

			}
			//echo $KWH."<br>start: ".$startKWH;
			$updateDgSetValHr=" solar_dg_start_kwh='".$solarStartDgKWHHr."', `solar_dg_start_cum_date`='".$solarStartDgDateHr."', ";

                    
                    $solarStartKWHHr=$cronDataFetYesHrly["solar_ac_end_kwh"];
					$solarStartAcDateHr=$cronDataFetYesHrly["solar_ac_end_cum_date"];



						
			$solarEndDgKWHHr=$DG_KWH;
			$solarEndDgDateHr=$teltonikaTimeStamp;
			$costDg=$sensMasDet["dg_unit_rate"];
			$consuptionDgKWHHr=$solarEndDgKWHHr-$solarStartDgKWHHr;
			$consuptionDgCostHr=$consuptionDgKWHHr*$costDg;

			


			
        }
		//echo "Solar DG End KWH Hrly".$solarEndDgKWHHr."<br>";
		//echo "Solar DG Start KWH Hrly".$solarStartDgKWHHr."<br>";
		//echo "DG Consuption KWH Hrly".$consuptionDgKWHHr; exit;


						
			$extraFieldsValuesHr = "";
   
				if($segment_name == 'Energy Meter'){

				$extraFieldsValuesHr = "unit_rate='".$sensMasDet['unit_rate']."', end_kwh='".$endKWHHr."', end_cum_date='".$endDateHr."', 
				consuption_kwh='".$consuptionKWHHr."', consuption_cost='".$consuptionCostHr."', 
				dg_start_kwh'".$startDgKWHHr."', dg_end_kwh='".$endDgKWHHr."', dg_start_cum_date='".$startDgDateHr."', dg_end_cum_date='".$endDgDateHr."', 
				dg_consuption_kwh='".$consuptionDgKWHHr."', dg_consuption_cost='".$consuptionDgCostHr."'";

				}elseif ($segment_name == 'Temperature') {

				//echo "am in temperature"; 

$extraFieldsValuesHr = "min_temperature_c='".$min_tem_c."',max_temperature_c='".$max_tem_c."',avg_temperature_c='".$avg_tem_c."', min_temperature_f='".$min_tem_f."',max_temperature_f='".$max_tem_f."',avg_temperature_f='".$avg_tem_f."', min_humidity='".$min_tem_hum."',max_humidity='".$max_tem_hum."',avg_humidity='".$avg_tem_hum."',cdd_c='".$cdd_c."',cdd_f='".$cdd_f."'";

				$updateSetValHr = "";
				$updateDgSetValHr = "";

				}elseif($segment_name == 'Water Level' || $segment_name == 'Flow Meter'){

               $extraFieldsValuesHr = "flow='".$start_flowHr."',totalizer='".$totaliHr."'";  
				  $updateSetVal = "";
				  $updateDgSetVal = "";

				}elseif($segment_name == 'Solar Inverter'){

              $extraFieldsValuesHr = "unit_rate='".$sensMasDet['unit_rate']."',solar_ac_end_kwh='".$solarAcEndKWHHr."',solar_ac_end_cum_date='".$solarAcEndDateHr."', solar_ac_consuption_kwh='".$consuptionKWHHr."', solar_ac_consuption_cost='".$consuptionCostHr."',  solar_dg_end_kwh='".$solarEndDgKWHHr."', solar_dg_end_cum_date='".$solarEndDgDateHr."', solar_dg_consuption_kwh='".$consuptionDgKWHHr."', solar_dg_consuption_cost='".$consuptionDgCostHr."', hour_data='".$currHour."'";
					
        }
		//echo "Extra Fields".$extraFieldsValues."<br>";
		//echo "updateSetVal Fields".$updateSetVal."<br>";
		//echo "updateDgSetVal Values".$updateDgSetVal; exit;

//echo $extraFieldsValues; exit;
               // echo "Update Set Value Fileld".$updateSetValHr."<br>".exit;
				//echo "Extra Fileld".$extraFieldsValuesHr; exit;

			       $UpdateCronQryHrly="UPDATE `$com_branch_segment_hourly_code` SET ".$updateSetValHr." `feeder_type`='".$sensMasDet["feeder_type"]."', ".$extraFieldsValuesHr.", `raw_data` = '".$inputJSON."',`posted_date_time`=NOW(),".$updateDgSetValHr." `created_by`='API' WHERE `company_id`='".$sensMasDet['company_id']."' AND `branch_id`='".$sensMasDet['branch_id']."' AND `gateway_code`='".$sensMasDet['gateway_id']."' AND sensor_code='".$sensorCode."' AND `recorded_date`='".$currDate."'";   

			$conn->query($UpdateCronQryHrly);
		
		
		}else{

		

		       if($segment_name == 'Energy Meter'){
				/***************   EB Condition Starts     ***********************/
				if($cronDataCountYesHrly>0 && $cronDataFetYesHrly["end_cum_date"] >0){
					$startKWHHr=$cronDataFetYesHrly["end_kwh"];
					$startDateHr=$cronDataFetYesHrly["end_cum_date"];

				}else{
					$startKWHHr=$KWH;
					$startDateHr=$teltonikaTimeStamp;

				}
				$endKWHHr=$KWH;
				$endDateHr=$teltonikaTimeStamp;
				$costHr=$sensMasDet["unit_rate"];
				$consuptionKWHHr=$endKWHHr-$startKWHHr;
				$consuptionCostHr=$consuptionKWHHr*$costHr;

				/***************   DG Condition Starts     ***********************/

					
				if($sensMasDet['meterMode']=='DG'){
					$DG_KWHHr = $KWH;
				}

				if($cronDataCountYesHrly>0 && $cronDataFetYesHrly["dg_end_cum_date"] >0){
					$startDgKWHHr=$cronDataFetYesHrly["dg_end_kwh"];
					$startDgDateHr=$cronDataFetYesHrly["dg_end_cum_date"];

				}else{
					$startDgKWHHr=$DG_KWHHr;
					$startDgDateHr=$teltonikaTimeStamp;

				}
				$endDgKWHHr=$DG_KWHHr;
				$endDgDateHr=$teltonikaTimeStamp;
				$costDgHr=$sensMasDet["dg_unit_rate"];
				$consuptionDgKWHHr=$endDgKWHHr-$startDgKWHHr;
				$consuptionDgCostHr=$consuptionDgKWHHr*$costDgHr;

				$extraFieldsHr = "unit_rate, start_kwh, end_kwh, start_cum_date, end_cum_date, 
				consuption_kwh, consuption_cost, 
				dg_start_kwh, dg_end_kwh, dg_start_cum_date, dg_end_cum_date, 
				dg_consuption_kwh, dg_consuption_cost,hour_data";

				$extraValuesHr = "'".$costHr."',
				'".$startKWHHr."',
				'".$endKWHHr."',
				'".$startDateHr."',
				'".$endDateHr."',
				'".$consuptionKWHHr."',
				'".$consuptionCostHr."',
				'".$startDgKWHHr."',
				'".$endDgKWHHr."',
				'".$startDgDateHr."',
				'".$endDgDateHr."',
				'".$consuptionDgKWHHr."',
				'".$consuptionDgCostHr."',
				'".$currHour."'";
					
			   }elseif ($segment_name == 'Temperature') {

				//echo "am in temperature"; 

				         $min_tem_c = $cronDataFetYesHrly["min_temperature_c"];
						  $max_tem_c = $cronDataFetYesHrly["max_temperature_c"];
						  $avg_tem_c = $cronDataFetYesHrly["avg_temperature_c"];
						  $min_tem_f = $cronDataFetYesHrly["min_temperature_f"];
						  $max_tem_f = $cronDataFetYesHrly["max_temperature_f"];
						  $avg_tem_f = $cronDataFetYesHrly["avg_temperature_f"];
						  $min_tem_hum = $cronDataFetYesHrly["min_humidity"];
						  $max_tem_hum = $cronDataFetYesHrly["max_humidity"];
						  $avg_tem_hum = $cronDataFetYesHrly["avg_humidity"];
						  $cdd_c = $cronDataFetYesHrly["cdd_c"];
						  $cdd_f = $cronDataFetYesHrly["cdd_f"];

							
				$extraFieldsHr = "min_temperature_c,max_temperature_c,avg_temperature_c, min_temperature_f,max_temperature_f,avg_temperature_f, min_humidity,max_humidity,avg_humidity,cdd_c,cdd_f,hour_data";

				$extraValuesHr = "'".$min_tem_c."',
				'".$max_tem_c."',
				'".$avg_tem_c."','".$min_tem_f."',
				'".$max_tem_f."',
				'".$avg_tem_f."','".$min_tem_hum."',
				'".$max_tem_hum."',
				'".$avg_tem_hum."',
				'".$cdd_c."',
				'".$cdd_f."',
				'".$currHour."'";
				}elseif($segment_name == 'Water Level' || $segment_name == 'Flow Meter'){

					$extraFieldsHr = "flow,totalizer,hour_data";

				   $start_flowHr = $cronDataFetYesHrly['flow'];
				   $totaliHr = $cronDataFetYesHrly['totalizer'];

				
				   $extraValuesHr = "'".$start_flowHr."','".$totaliHr."','".$currHour."'";

				}elseif($segment_name == 'Solar Inverter'){





				/***************  Solar AC KWH Condition Starts     ***********************/

	            $AC_KWH = $AC_kwh;
				$DG_KWH = $DG_kwh;

				if($cronDataCountYesHrly>0 && $cronDataFetYesHrly["solar_ac_end_cum_date"] >0){


						$solarAcStartKWHHrly=$cronDataFetYes["solar_ac_end_kwh"];					
					    $solarAcStartDateHrly=$cronDataFetYes["solar_ac_end_cum_date"];

				}else{

					$solarAcStartKWHHrly=$AC_KWH;					
					$solarAcStartDateHrly=$teltonikaTimeStamp;

				}
				$solarAcEndKWHHrly=$AC_KWH;
				$solarAcEndDateHrly=$teltonikaTimeStamp;
				$cost=$sensMasDet["unit_rate"];
				

				$consuptionKWHHrly=$solarAcEndKWHHrly-$solarAcStartKWHHrly;
			if($solarAcStartKWHHrly > $solarAcEndKWHHrly){
				$selSensorMasterMaxKwhQry = 'SELECT * FROM `sensor_model_master` WHERE model_id = "'.$sensorModel.'" AND status = "1"';  
				$ExeSensorMasterMaxKwhQry = mysqli_query($conn, $selSensorMasterMaxKwhQry);
				$rsltSensorMasterMaxKwh = mysqli_fetch_assoc($ExeSensorMasterMaxKwhQry);
				$max_kwm_in_meter = $rsltSensorMasterMaxKwh['max_kwh'];
				$consuptionKWHHrly = ($max_kwm_in_meter - $solarAcStartKWHHrly)+$solarAcEndKWHHrly;

			}

				//$consuptionKWH=$endKWH-$startKWH;
				$consuptionCostHrly=$consuptionKWH*$cost;
				if($consuptionKWHHrly<=0){
				  $consuptionCostHrly=0;  
				}

				


				/***************   Solar DG KWH Condition Starts     ***********************/
				
				if($sensMasDet['meterMode']=='DG'){
					$DG_KWH = $KWH;
				}

				if($cronDataCountYesHrly>0 && $cronDataFetYesHrly["solar_dg_end_cum_date"] >0){
					$solarStartDgKWHHrly=$cronDataFetYesHrly["solar_dg_end_kwh"];
					$solarStartDgDateHrly=$cronDataFetYesHrly["solar_dg_end_cum_date"];

				}else{
					$solarStartDgKWHHrly=$DG_KWH;
					$solarStartDgDateHrly=$teltonikaTimeStamp;

				}
				$solarEndDgKWHHrly=$DG_KWH;
				$solarEndDgDateHrly=$teltonikaTimeStamp;
				$costDg=$sensMasDet["dg_unit_rate"];
				$consuptionDgKWHHrly=$solarEndDgKWHHrly-$solarStartDgKWHHrly;
				$consuptionDgCostHrly=$consuptionDgKWHHrly*$costDg;
				//echo "am in else1"; exit;	

     // echo "Extra Fields".$extraFieldsValues."<br>";
		//echo "solar_ac_start_kwh ".$solarAcStartKWH."<br>";
		//echo "solar_ac_end_kwh".$solarAcEndKWH; exit;

				$extraFieldsHr = "unit_rate, solar_ac_start_kwh, solar_ac_end_kwh, solar_ac_start_cum_date, solar_ac_end_cum_date, 
				solar_ac_consuption_kwh, solar_ac_consuption_cost, 
				solar_dg_start_kwh, solar_dg_end_kwh, solar_dg_start_cum_date, solar_dg_end_cum_date, 
				solar_dg_consuption_kwh, solar_dg_consuption_cost,hour_data";

				$extraValuesHr = "'".$sensMasDet['unit_rate']."',
				'".$solarAcStartKWHHrly."',
				'".$solarAcEndKWHHrly."',
				'".$solarAcStartDateHrly."',
				'".$solarAcEndDateHrly."',
				'".$consuptionKWHHrly."',
				'".$consuptionCostHrly."',
				'".$solarStartDgKWHHrly."',
				'".$solarEndDgKWHHrly."',
				'".$solarStartDgDateHrly."',
				'".$solarEndDgDateHrly."',
				'".$consuptionDgKWHHrly."',
				'".$consuptionDgCostHrly."',
				'".$currHour."'";



				}

				//echo "Extra Fields".$extraFields."<br>";
				//echo "Extra Values".$extraValues; exit;



			

				 $insQueryCronHrly = "INSERT INTO $com_branch_segment_hourly_code 
				(company_id, branch_id, location_code, gateway_code, sensor_code,
				sensor_name, sensor_model, feeder_type, raw_data, linux_date_time,
				teltonika_date_time, recorded_date, posted_date_time, created_by"

				.($extraFieldsHr != "" ? ",".$extraFieldsHr : "").")

				VALUES
				('".$sensMasDet['company_id']."',
				'".$sensMasDet['branch_id']."',
				'".$loc_mas_code."',
				'".$sensMasDet['gateway_id']."',
				'".$sensorCode."',
				'".$sensorModel."',
				'".$sensorModel."',
				'".$sensMasDet["feeder_type"]."',
				'".$inputJSON."',
				'".$liuxTimeStamp."',
				'".$input[0]['DT']."',
				'".$teltonikaTimeStamp."',
				NOW(),
				'Cron'"

				.($extraValuesHr != "" ? ",".$extraValuesHr : "").")";     
			
			if (!$conn->query($insQueryCronHrly)) {
    		echo "SQL Error: " . $conn->error;
				}

		}
		
		
		
		/****************     Cron Hourly Data Post Ends            **********************/


	$finalMonthlySql = "INSERT INTO `$com_branch_segment_monthly_code` (\n    " 
    . implode(", ", $fieldNames) . "\n) VALUES (\n    " 
    . implode(", ", $valueList) . "\n);"; 
          

/*********For Insert into the Specific Cron Tables Ends */


		/****************     Cron Hourly Data Post            **********************/
		/****************    Only For Overall Main Meter Cron Slot Wise Data            **********************/
		
	/**********************  Slot Wise only for Overall Main Meter ************************/	
		/*******************************************             Mail Trigger  Starts            ****************************************************/
	   $selAlertCont= "SELECT email FROM `arka_alert_contact_master` WHERE email_alert=1 AND is_active=1 AND `company_id`='".$sensMasDet['company_id']."' AND `branch_id`='".$sensMasDet['branch_id']."'";
       $ExeAlertCont = mysqli_query($conn, $selAlertCont);
	   if (mysqli_num_rows($ExeAlertCont) > 0) 
	   {
			 $alertContact='';
			 while($alertCont = mysqli_fetch_assoc($ExeAlertCont)) 
			{
			// Fetch all
			   $alertContact .= $alertCont['email'].",";
			}
		//	$string = rtrim($string, ".");
			$alertEmail= rtrim($alertContact, ",");
			echo $alertEmail." -- EmailId from Table <br>";
       } 
	   
	   $selAlertPar= "SELECT * FROM `alert_parameter_mapping` WHERE `sensor_code`='".$sensorCode."'";
       $ExeAlertPar = mysqli_query($conn, $selAlertPar);
	   
	   if (mysqli_num_rows($ExeAlertPar) > 0) 
	   {
	      echo "alert parameter Mapping";
            while($parameter = mysqli_fetch_assoc($ExeAlertPar)) 
			{ 
			 echo $parameter['parameter_name']."-  Parameter Name <br>";
			  echo $parameter['mail_alert_status'];
				$parameterName=$parameter['parameter_name'];
				if($parameter['mail_alert_status']=="Normal")
				{
               $selectEnergy= "SELECT ".$parameterName." FROM `energy_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND (".$parameterName." <= '".$parameter['min_alert_value']."' OR ".$parameterName." >= '".$parameter['max_alert_value']."')";
			  $ExeEnergy = mysqli_query($conn, $selectEnergy);
	           $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
				  if($ReadingValue > $parameter['max_alert_value']){
				  $alertStatus='High';
				  $alertValueName='Max Value Reached';
				  }
				  elseif($ReadingValue < $parameter['min_alert_value']){
				  $alertStatus='Low';
				  $alertValueName='Min Value Reached';
				  }
			  }else if($parameter['mail_alert_status']=="High"){
			  $selectEnergy= "SELECT ".$parameterName." FROM `energy_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND (".$parameterName." > '".$parameter['min_alert_value']."' AND ".$parameterName." < '".$parameter['max_alert_value']."')";
			  $ExeEnergy = mysqli_query($conn, $selectEnergy);
			  if (mysqli_num_rows($ExeEnergy) == 0) 
				{
				 $selectEnergy= "SELECT ".$parameterName." FROM `energy_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND ".$parameterName." <= '".$parameter['min_alert_value']."'";
			   $ExeEnergy = mysqli_query($conn, $selectEnergy);
	           $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='Low';
			   $alertValueName='Min Value Reached';
			   
			   }
			   else{
			   
			   $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='Normal';
			   $alertValueName='Normal Value Reached';
			   
			   }
			  }
			  else if($parameter['mail_alert_status']=="Low" ){
			  $selectEnergy= "SELECT ".$parameterName." FROM `energy_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND (".$parameterName." > '".$parameter['min_alert_value']."' AND ".$parameterName." < '".$parameter['max_alert_value']."')";
			  $ExeEnergy = mysqli_query($conn, $selectEnergy);
	          if (mysqli_num_rows($ExeEnergy) == 0) 
				{
				 $selectEnergy= "SELECT ".$parameterName." FROM `energy_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND ".$parameterName." >= '".$parameter['max_alert_value']."'";
			   $ExeEnergy = mysqli_query($conn, $selectEnergy);
	           $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='High';
			   $alertValueName='Max Value Reached';
			   
			   }
			   else{
			   
			   $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='Normal';
			   $alertValueName='Normal Value Reached';
			   
			   }
			  }
			  
			 /* $message .= "Hi!<br><br><br>
	
								<b>Feeder Name</b>      : ".$parameter['feeder_name'].",<br>
								<b>Parameter Name</b>   : ".$parameter['parameter_name'].",<br>
								<b>".$alertValueName."</b>  : ".$ReadingValue.".<br><br><br><br><br>
	
	
								
                                <b>Best regards</b>,<br>
                                <b>Arka Automaations Limited.</b><br>
								";
								
				  $contentData=strip_tags($message);
								
			 $insAlertLog	="INSERT INTO `alert_log_master`(`company_id`, `branch_id`, `sensor_code`, `alert_type`, `parameter_name`, `alert_message`, `send_to`, `alert_status`, `recorded_date_time`, `posted_date_time`) VALUES ('".$sensMasDet['company_id']."','".$sensMasDet['branch_id']."','".$sensorCode."','Mail','".$parameter['parameter_name']."','".$contentData."','".$alertEmail."','".$alertStatus."','".$teltonikaTimeStamp."',DATE_ADD(NOW(),INTERVAL '00:00' HOUR_MINUTE))";		
			 $insLog = $conn->query($insAlertLog);*/
			  
			//echo   $alertStatus." --alert Status <br>".$alertValueName." --alert Value <br>".mysqli_num_rows($ExeEnergy);
			   
			    if (mysqli_num_rows($ExeEnergy) > 0) 
				{
				
			     $updateAlertPar= "UPDATE `alert_parameter_mapping` SET mail_alert_status='".$alertStatus."'  WHERE `alert_parameter_id`='".$parameter['alert_parameter_id']."'";
       			 $ExeAlertPar = mysqli_query($conn, $updateAlertPar);
				     echo $ReadingValue."-  Reading Value <br>";
				     echo $alertEmail."-  MailId <br>"; 
				     
			  $selectSensor= "SELECT * FROM `arka_sensor_master` WHERE `sensorCode`='".$parameter['sensor_code']."' AND status='1' AND isActive='1'";
			  $ExeSensor = mysqli_query($conn, $selectSensor);
	          $ExeSensorArr = mysqli_fetch_assoc($ExeSensor);
			  $sensorNameVal = $ExeSensorArr['sensorName'];
			  


$message = '';

				   $message .= "EMS - Alert Message!<br><br><br>
	
								<b>Energy Meter Name</b>      : ".$parameter['feeder_name'].",<br>
								<b>Parameter Name</b>   : ".$parameter['parameter_name'].",<br>
								<b>".$alertValueName."</b>  : ".$ReadingValue.".<br><br><br><br><br>
	
	
								
                                <br>
								";
								
				  $contentData=strip_tags($message);
								
							
			 $insAlertLog	="INSERT INTO `alert_log_master`(`company_id`, `branch_id`, `sensor_code`, `alert_type`, `parameter_name`, `alert_message`, `send_to`, `alert_status`, `recorded_date_time`, `posted_date_time`) VALUES ('".$sensMasDet['company_id']."','".$sensMasDet['branch_id']."','".$sensorCode."','Mail','".$parameter['parameter_name']."','".$contentData."','".$alertEmail."','".$alertStatus."','".$teltonikaTimeStamp."',DATE_ADD(NOW(),INTERVAL '00:00' HOUR_MINUTE))";		
			 $insLog = $conn->query($insAlertLog);
     
        
        if ($insLog === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $insAlertLog . "<br>" . $conn->error;
        }
            	    



				 	
			 }
			   
            }
       } 
	   

//mail("vishalchandran11@gmail.com", "Test Mail", "Test");
	mysqli_free_result($ExeSensor);
	mysqli_free_result($ExeEnergy);
	mysqli_free_result($ExeAlertPar);
	mysqli_free_result($ExeAlertCont);
//	mysqli_free_result($resultView);
	mysqli_free_result($result);
	
		/*******************************************             Mail Trigger   End          ****************************************************/
        $conn->close();
    
 }
    else {
        echo "Wrong API Key provided.";
    }

}
else {
    echo "No data posted with HTTP POST.";
}


function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function quoteValue($value) {
    return is_numeric($value) || strtoupper($value) === 'NOW()' ? $value : "'" . str_replace("'", "", $value) . "'";
}

?>
