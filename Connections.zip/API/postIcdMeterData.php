<?php require_once('../Connections/ARKAEMS.php'); 

//echo 'dasds';
mysql_select_db($database_arkaems, $arkaerp) or die(mysql_error());
//echo $this1;		
//echo $database_arka;
//echo $_POST['METER_ID']."METER ID:<br>";
//echo $_POST['KWH']."KWH:";
if(isset($_POST['METER_ID']) && isset($_POST['KWH']))
		{
		    $GetQuery11 = 'INSERT INTO `energy_data_master`(`gateway_code`,`sensor_code`,`sensor_model`,`METER_ID`, `R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`, `SUM_PF`, `FREQUENCY`, `KWH_MSB`, `KWH_LSB`, `KWH`, `METER_TYPE_RUN_HOUR_MSB`, `RUN_HOUR_LSB`, `RUN_HOUR`, `IMPORT_EXPORT`,`recorded_date_time`,`posted_date_time`) VALUES ("RASPI3-1","ICD3-1","ICD3","'.$_POST['METER_ID'].'","'.$_POST['R_VOLTAGE'].'","'.$_POST['Y_VOLTAGE'].'","'.$_POST['B_VOLTAGE'].'","'.$_POST['RY_VOLTAGE'].'","'.$_POST['YB_VOLTAGE'].'","'.$_POST['BR_VOLTAGE'].'","'.$_POST['R_CURRENT'].'","'.$_POST['Y_CURRENT'].'","'.$_POST['B_CURRENT'].'","'.$_POST['SUM_KVA'].'","'.$_POST['SUM_KW'].'","'.$_POST['SUM_KVAR'].'","'.$_POST['SUM_PF'].'","'.$_POST['FREQUENCY'].'","'.$_POST['KWH_MSB'].'","'.$_POST['KWH_LSB'].'","'.$_POST['KWH'].'","'.$_POST['METER_TYPE_RUN_HOUR_MSB'].'","'.$_POST['RUN_HOUR_LSB'].'","'.$_POST['RUN_HOUR'].'","'.$_POST['IMPORT_EXPORT'].'",CONVERT_TZ(NOW(),"+00:00","+00:00"),CONVERT_TZ(NOW(),"+00:00","+00:00"))';
		$mt21 = mysql_query($GetQuery11, $arkaerp) or die(mysql_error());
	
	//	mysql_select_db($database_arkaems, $arkaerp);
    /*	$GetQuery1 = 'INSERT INTO `arka_icd_meter`(`METER_ID`, `R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`, `SUM_PF`, `FREQUENCY`, `KWH_MSB`, `KWH_LSB`, `KWH`, `METER_TYPE_RUN_HOUR_MSB`, `RUN_HOUR_LSB`, `RUN_HOUR`, `IMPORT_EXPORT`) VALUES ("'.$_POST['METER_ID'].'","'.$_POST['R_VOLTAGE'].'","'.$_POST['Y_VOLTAGE'].'","'.$_POST['B_VOLTAGE'].'","'.$_POST['RY_VOLTAGE'].'","'.$_POST['YB_VOLTAGE'].'","'.$_POST['BR_VOLTAGE'].'","'.$_POST['R_CURRENT'].'","'.$_POST['Y_CURRENT'].'","'.$_POST['B_CURRENT'].'","'.$_POST['SUM_KVA'].'","'.$_POST['SUM_KW'].'","'.$_POST['SUM_KVAR'].'","'.$_POST['SUM_PF'].'","'.$_POST['FREQUENCY'].'","'.$_POST['KWH_MSB'].'","'.$_POST['KWH_LSB'].'","'.$_POST['KWH'].'","'.$_POST['METER_TYPE_RUN_HOUR_MSB'].'","'.$_POST['RUN_HOUR_LSB'].'","'.$_POST['RUN_HOUR'].'","'.$_POST['IMPORT_EXPORT'].'")';
		$mt2 = mysql_query($GetQuery1, $arkaerp) or die(mysql_error());
		 */
		$selMeter='SELECT * FROM energy_data_master_view WHERE gateway_code="RASPI3-1" AND sensor_code="ICD3-1"';
		$meterList = mysql_query($selMeter, $arkaerp) or die(mysql_error());
        $recNumRow= mysql_num_rows($meterList);
		 if($recNumRow==0){
	          $GetQuery12= 'INSERT INTO `energy_data_master_view`(`gateway_code`,`sensor_code`,`sensor_model`,`METER_ID`, `R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`, `SUM_PF`, `FREQUENCY`, `KWH_MSB`, `KWH_LSB`, `KWH`, `METER_TYPE_RUN_HOUR_MSB`, `RUN_HOUR_LSB`, `RUN_HOUR`, `IMPORT_EXPORT`,`recorded_date_time`,`posted_date_time`) VALUES ("RASPI3-1","ICD3-1","ICD3","'.$_POST['METER_ID'].'","'.$_POST['R_VOLTAGE'].'","'.$_POST['Y_VOLTAGE'].'","'.$_POST['B_VOLTAGE'].'","'.$_POST['RY_VOLTAGE'].'","'.$_POST['YB_VOLTAGE'].'","'.$_POST['BR_VOLTAGE'].'","'.$_POST['R_CURRENT'].'","'.$_POST['Y_CURRENT'].'","'.$_POST['B_CURRENT'].'","'.$_POST['SUM_KVA'].'","'.$_POST['SUM_KW'].'","'.$_POST['SUM_KVAR'].'","'.$_POST['SUM_PF'].'","'.$_POST['FREQUENCY'].'","'.$_POST['KWH_MSB'].'","'.$_POST['KWH_LSB'].'","'.$_POST['KWH'].'","'.$_POST['METER_TYPE_RUN_HOUR_MSB'].'","'.$_POST['RUN_HOUR_LSB'].'","'.$_POST['RUN_HOUR'].'","'.$_POST['IMPORT_EXPORT'].'",CONVERT_TZ(NOW(),"+00:00","+00:00"),CONVERT_TZ(NOW(),"+00:00","+00:00"))';
      }else{
	  	          $GetQuery12= "UPDATE `energy_data_master_view` SET `R_VOLTAGE`='".$_POST['R_VOLTAGE']."',`Y_VOLTAGE`='".$_POST['Y_VOLTAGE']."',B_VOLTAGE='".$_POST['B_VOLTAGE']."', `RY_VOLTAGE`='".$_POST['RY_VOLTAGE']."', `YB_VOLTAGE`='".$_POST['YB_VOLTAGE']."', `BR_VOLTAGE`='".$_POST['BR_VOLTAGE']."', `R_CURRENT`='".$_POST['R_CURRENT']."', `Y_CURRENT`='".$_POST['Y_CURRENT']."', `B_CURRENT`='".$_POST['B_CURRENT']."', `SUM_KVA`='".$_POST['SUM_KVA']."', `SUM_KW`='".$_POST['SUM_KW']."', `SUM_KVAR`='".$_POST['SUM_KVAR']."', `SUM_PF`='".$_POST['SUM_PF']."', `FREQUENCY`='".$_POST['FREQUENCY']."', `KWH_MSB`='".$_POST['KWH_MSB']."', `KWH_LSB`='".$_POST['KWH_LSB']."', `KWH`='".$_POST['KWH']."', `METER_TYPE_RUN_HOUR_MSB`='".$_POST['METER_TYPE_RUN_HOUR_MSB']."', `RUN_HOUR_LSB`='".$_POST['RUN_HOUR_LSB']."', `RUN_HOUR`='".$_POST['RUN_HOUR']."', `IMPORT_EXPORT`='".$_POST['IMPORT_EXPORT']."', `recorded_date_time`=CONVERT_TZ(NOW(),'+00:00','+00:00'), `posted_date_time`=CONVERT_TZ(NOW(),'+00:00','+00:00') WHERE gateway_code='RASPI3-1' AND sensor_code='ICD3-1'";

	  
	  }
	  		 mysql_query($GetQuery12, $arkaerp) or die(mysql_error());

	   
        echo "Meter data Inserted Sucessfully...";
		}else{
		    echo "Post data not received ...";
		}

?>
