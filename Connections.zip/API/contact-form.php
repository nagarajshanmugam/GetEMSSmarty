<?php
/*
Name: 			Contact Form
Written by: 	Okler Themes - (http://www.okler.net)
Theme Version:	7.5.0
*/

//namespace PortoContactForm;

session_cache_limiter('nocache');
header('Expires: ' . gmdate('r', 0));

header('Content-type: application/json');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'php/php-mailer/src/PHPMailer.php';
require 'php/php-mailer/src/SMTP.php';
require 'php/php-mailer/src/Exception.php';

//echo "hai"; exit;
// Step 1 - Enter your email address below.
$email = 'aal@arkaautomaations.com';

// If the e-mail is not working, change the debug option to 2 | $debug = 2;
$debug = 0;

// If contact form don't has the subject input change the value of subject here
$subject = 'Temperature Alert';

$message = '';
$message .="Ac Temperature : 16 C <br>\n";

$mail = new PHPMailer(true);

try {

	$mail->SMTPDebug = $debug;                                 // Debug Mode

	// Step 2 (Optional) - If you don't receive the email, try to configure the parameters below:

	$mail->IsSMTP();                                         // Set mailer to use SMTP
	$mail->Host = 'smtpout.asia.secureserver.net';				       // Specify main and backup server
	$mail->SMTPAuth = true;                                  // Enable SMTP authentication
//	$mail->Username = 'info@plumtekerp.in';                    // SMTP username
//	$mail->Password = 'Admin@2020';
	$mail->Username = 'aal@arkaautomaations.com';                    // SMTP username
    $mail->Password = 'Arka@2020';// SMTP password
	$mail->SMTPAutoTLS = false;                               // Enable encryption, 'ssl' also accepted
	$mail->Port = 80;   								       // TCP port to connect to

	

	$mail->AddAddress('vishal@arkagroup.co.in');     // Add a secondary recipient
	$mail->AddAddress('vishalchandran11@gmail.com');	// Add another recipient
	$mail->AddCC('nagaraj@arkagroup.co.in');          // Add a "Cc" address. 
	//$mail->AddBCC('person4@domain.com', 'Person 4');         // Add a "Bcc" address. 

	// From - Name
	$fromName = 'Arka Automaations Limited';
	$mail->SetFrom($email, $fromName);

	// Repply To
/*	if( isset($_POST['email']) ) {
		$mail->AddReplyTo($_POST['email'], $fromName);
	}*/

	$mail->IsHTML(true);                                       // Set email format to HTML

	$mail->CharSet = 'UTF-8';

	$mail->Subject = $subject;
	$mail->Body    = $message;

	$mail->Send();
	$arrResult = array ('response'=>'success');

} catch (Exception $e) {
	$arrResult = array ('response'=>'error','errorMessage'=>$e->errorMessage());
} catch (\Exception $e) {
	$arrResult = array ('response'=>'error','errorMessage'=>$e->getMessage());
}

if ($debug == 0) {
	echo json_encode($arrResult);
}


?>