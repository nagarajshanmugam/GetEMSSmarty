<?php

/*
  Rui Santos
  Complete project details at https://RandomNerdTutorials.com/esp32-esp8266-mysql-database-php/
  
  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files.
  
  The above copyright notice and this permission notice shall be included in all
  copies or substantial portions of the Software.
*/
	header('Access-Control-Allow-Origin: *'); 
    header("Access-Control-Allow-Credentials: true");
    header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
    header('Access-Control-Max-Age: 1000');
    header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');

require_once('../Connections/ARKAEMS.php'); 
$servername = $hostname_arkaems;

// REPLACE with your Database name
$dbname = $database_arkaems;
// REPLACE with Database user
$username = $username_arkaems;
// REPLACE with Database user password
$password = $password_arkaems;
 
//exit;


// Keep this API Key value to be compatible with the ESP32 code provided in the project page. 
// If you change this value, the ESP32 sketch needs to match
//$api_key_value = "arkatemp1001";

//$api_key= $sensor = $location = $value1 = "";


   /* $jsonResponce='[{"ID":"30","apiKey":"R1c6VFJCMTQ1LTQvU0k6RlQzNjAtMS9TTU9ERUw6RlQzNjA=" ,"ST":"1","TS":"1710316460","DT":"13/03/2024 13:24:20","VR":"[2305,352,0,64977,6,0,0,0,0,2,2,0,0,0,59946,69,0,0,0,0]"}]';*/
   if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $inputJSON = file_get_contents('php://input');
     //  echo $inpuJSON;
        $input= json_decode( $inputJSON, true); 
		$elementCount  = count($input);
		//echo $elementCount; exit;
         // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } 
		$sqlSensor = "SELECT * FROM arka_sensor_master WHERE isActive='1' AND status='1' AND api_key='".$input[0]['apiKey']."'"; 
		$insSel = $conn->query($sqlSensor);
		
		$result = mysqli_query($conn, $sqlSensor);
		$sensMasDet = mysqli_fetch_assoc($result);
		if (mysqli_num_rows($result) > 0) {
  
		if($elementCount>=1){
           /********************   FLOW METER   *********************/
					$arrRemoveFirstSegment= str_replace(array('[', ',]', ']'), '', $input[0]['VR']);
					$firstSegment= explode (",", $arrRemoveFirstSegment); 
					
					$flow=($firstSegment[13] * 65536 + $firstSegment[12]) * 0.01 ;        // ( Actual flow formula : (registor no.14 * 65536 +register no.13) * 0.01 )
					$totalizer=($firstSegment[15] * 65536 + $firstSegment[14]) * 0.01;    // ( Actual Totalizer formula: (registor no.16 * 65536 +register no.15)* 0.01 )
					
		   $apikeyDecd= base64_decode($input[0]['apiKey']);
		   $apiDec =explode("/", $apikeyDecd);
		   $gatewayCode=str_replace("GW:","",$apiDec[0]);
		   $sensorCode=str_replace("SI:","",$apiDec[1]);
		   $sensorModel=str_replace("SMODEL:","",$apiDec[2]);

		   $liuxTimeStamp=$input[0]['TS'];
		   
		   if($liuxTimeStamp !="XXXXXX")
		   {
			  $recordedTimeStamp = date("Y-m-d H:i:s",$input[0]['TS']);
			  $telDate =$input[0]['DT'];
			  $teltonika_date = str_replace('/', '-', $telDate);
			  $teltonikaTimeStamp =  date('Y-m-d H:i:s', strtotime($teltonika_date));
		   }
		   else
		   {
			  $recordedTimeStamp='';
			  $liuxTimeStamp='';
			  $recordedTimeStamp = ''; 
			  $teltonikaTimeStamp='';
		  
		   }
		   
		}
	            
		
	 	$insMas = "INSERT INTO `flow_data_master` (`gateway_code`, `sensor_code`, `sensor_model`,`flow`, `totalizer`, `json_data`, `linux_date_time`, `teltonika_date_time`, `recorded_date_time`, `posted_date_time`) VALUES ('".$gatewayCode."','".$sensorCode."','".$sensorModel."', '".$flow."', '".$totalizer."','".$inputJSON."', '".$liuxTimeStamp."', '".$telDate."', '".$teltonikaTimeStamp."', NOW())";
        $insMas = $conn->query($insMas);
		if($insMas)
        {
        	echo "Data Inserted Successfully.";
       	}

        $SelQuery	= "SELECT * FROM `flow_data_master_view` WHERE `sensor_code`='".$sensorCode."'"; 
    	$exec = mysqli_query($conn, $SelQuery); 
	   	$flowViewCount=mysqli_num_rows($exec);
     
		
    	    
    	    if($flowViewCount==0){
                $insMasViewSel = "INSERT INTO `flow_data_master_view` (`gateway_code`, `sensor_code`, `sensor_model`,`flow`, `totalizer`, `json_data`, `linux_date_time`, `teltonika_date_time`, `recorded_date_time`, `posted_date_time`) VALUES ('".$gatewayCode."','".$sensorCode."','".$sensorModel."', '".$flow."', '".$totalizer."','".$inputJSON."', '".$liuxTimeStamp."', '".$telDate."', '".$teltonikaTimeStamp."', NOW())"; 
                $insMasViewSel = $conn->query($insMasViewSel);
            
    	    }else{
    	        
    	        $insMasViewSel = "UPDATE `flow_data_master_view` SET `gateway_code`='".$gatewayCode."', `sensor_code`='".$sensorCode."', `sensor_model`='".$sensorModel."', `flow`='".$flow."', `totalizer`='".$totalizer."', `json_data`='".$inputJSON."', `linux_date_time`='".$liuxTimeStamp."', `teltonika_date_time`='".$telDate."', `recorded_date_time`='".$teltonikaTimeStamp."', `posted_date_time`=NOW() WHERE `sensor_code`='".$sensorCode."'"; 
                $insMasView = $conn->query($insMasViewSel);
    	    }
     
            if($insMasView)
            {
                 echo "Data Inserted Successfully.";
            }
			   
  }
    else {
        echo "Wrong API Key provided.";
    }
  $conn->close();     
}
else {
    echo "No data posted with HTTP POST.";
}



function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>