<?php

/*
  Rui Santos
  Complete project details at https://RandomNerdTutorials.com/esp32-esp8266-mysql-database-php/
  
  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files.
  
  The above copyright notice and this permission notice shall be included in all
  copies or substantial portions of the Software.
*/

//namespace PortoContactForm;

session_cache_limiter('nocache');
header('Expires: ' . gmdate('r', 0));

header('Content-type: application/json');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'php/php-mailer/src/PHPMailer.php';
require 'php/php-mailer/src/SMTP.php';
require 'php/php-mailer/src/Exception.php';

//echo  "hai"; exit;
require_once('../Connections/ARKAEMS.php'); 
$servername = $hostname_arkaems;

// REPLACE with your Database name
$dbname = $database_arkaems;
// REPLACE with Database user
$username = $username_arkaems;
// REPLACE with Database user password
$password = $password_arkaems;

/*$servername = "166.62.10.227";

// REPLACE with your Database name
$dbname = "emslte";
// REPLACE with Database user
$username = "emslte";
// REPLACE with Database user password
$password = "emslte@2020";*/
 
//exit;


// Keep this API Key value to be compatible with the ESP32 code provided in the project page. 
// If you change this value, the ESP32 sketch needs to match

//echo "hai"; exit;
   if ($_SERVER["REQUEST_METHOD"] == "POST") {
         $inputJSON = file_get_contents('php://input');
         $input= json_decode( $inputJSON, true); 
 // $api_key = test_input($_POST["api_key"]);
     $conn = new mysqli($servername, $username, $password, $dbname);
     mysqli_query($conn,"SET SESSION sql_mode = 'NO_ENGINE_SUBSTITUTION'");
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } 
   echo $sqlSensor = "SELECT * FROM arka_sensor_master WHERE isActive='1' AND status='1' AND api_key='".$input[0]['apiKey']."'"; 
    $insSel = $conn->query($sqlSensor);
	
     $result = mysqli_query($conn, $sqlSensor);
	 $sensMasDet = mysqli_fetch_assoc($result);
	 

       
      

       
  if (mysqli_num_rows($result) > 0) {
          
       
        
         // Create connection
		   $apikeyDecd= base64_decode($input[0]['apiKey']);
	 
	  /* $apiDec =explode("/", $apikeyDecd);
	   $gatewayCode=str_replace("GW:","",$apiDec[0]);
	   $sensorCode=str_replace("SI:","",$apiDec[1]);
	   $sensorModel=str_replace("SMODEL:","",$apiDec[2]); */
	   
	   
	   //$apiDec =explode("/", $apikeyDecd);
	   $gatewayCode=$sensMasDet["gateway_id"];
	   $sensorCode=$sensMasDet["sensorCode"];
	   $sensorModel=$sensMasDet["sensorModel"];
	//   echo "gatewYcODE:".$gatewayCode; exit;
	   

           $jsonDecd= str_replace(array('[', ',]', ']'), '', $input[0]['VR']);
           $str_arr= explode (",", $jsonDecd); 
		  
          // echo $input[0]['VR']."<br>"; print_r($str_arr); 
           if($sensorModel =='YMN'){
		//   [{"TS": "1625477654", "D": "05/07/2021 15:04:14", "data": [0.000000,12.320000,0.000000,6.190000]}]	
		   
			$mA1=$str_arr[3];
			$mA2=$str_arr[4];
			$mA3=$str_arr[5];
			$mA4=$str_arr[6];
			$LRV=4;
			$spanV=16;
			$spanT=200;
			$LRVT=0;
			$machine_status_value= $str_arr[1]; //date post in database
			if(isset($str_arr[3])){
			$pvInnerForCal1=($mA1-$LRV)/$spanV;
			$pv1=($pvInnerForCal1 * $spanT) + $LRVT;
			}else{
			$pv1=0;
			}
			if(isset($str_arr[4])){
			$pvInnerForCal2=($mA2-$LRV)/$spanV;
			$pv2=($pvInnerForCal2 * $spanT) + $LRVT;
			}else{
			$pv2=0;
			}
			if(isset($str_arr[5])){
			$pvInnerForCal3=($mA3-$LRV)/$spanV;
			$pv3=($pvInnerForCal3 * $spanT) + $LRVT;
			}else{
			$pv3=0;
			}
			if(isset($str_arr[6])){
			$pvInnerForCal4=($mA4-$LRV)/$spanV;
			$pv4=($pvInnerForCal4 * $spanT) + $LRVT;
			}else{
			$pv4=0;
			}
			
			if($str_arr[1]> 0){
				$machine_status='ON';
			}else{
				$machine_status='OFF';
			}
			
           
		   $machine_status_value= $str_arr[1]; //date post in database
		   $bearing_1_amps=$str_arr[3];
           $bearing_1_temperature=$pv1; //date post in database
		   $bearing_2_amps=$str_arr[4];
           $bearing_2_temperature=$pv2;  //date post in database
		   $bearing_3_amps=$str_arr[5];
           $bearing_3_temperature=$pv3;  //date post in database
		   $bearing_4_amps=$str_arr[6];
           $bearing_4_temperature=$pv4; //date post in database
           
       
		  
          }
         
          $liuxTimeStamp=$input[0]['TS'];
		 
          if($liuxTimeStamp !="XXXXXX")
          {
             
              $recordedTimeStamp = date("Y-m-d H:i:s",$input[0]['TS']);
              $telDate =$input[0]['DT'];
              $teltonika_date = str_replace('/', '-', $telDate);
              $teltonikaTimeStamp =  date('Y-m-d H:i:s', strtotime($teltonika_date));
             
          }
          else
          {
              $liuxTimeStamp='';
              $recordedTimeStamp = ''; 
			  $teltonikaTimeStamp='';
          
          }
           
    // $sql= "INSERT INTO `energy_data_master`(`gateway_code`, `sensor_code`, `sensor_model`,`R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`, `SUM_PF`, `FREQUENCY`, `KWH_MSB`, `KWH_LSB`, `KWH`, `METER_TYPE_RUN_HOUR_MSB`, `RUN_HOUR_LSB`, `RUN_HOUR`, `IMPORT_EXPORT`,`VR_ARRAY_VALUE`,`linux_date_time`,`teltonika_date_time`, `recorded_date_time`, `posted_date_time`) VALUES ('".$gatewayCode."','".$sensorCode."','".$sensorModel."','".$R_VOLTAGE."','".$Y_VOLTAGE."','".$B_VOLTAGE."','".$RY_VOLTAGE."','".$YB_VOLTAGE."','".$BR_VOLTAGE."','".$R_CURRENT."','".$Y_CURRENT."','".$B_CURRENT."','".$SUM_KVA."','".$SUM_KW."','".$SUM_KVAR."','".$SUM_PF."','".$FREQUENCY."','".$KWH_MSB."','".$KWH_LSB."','".$KWH."','".$METER_TYPE_RUN_HOUR_MSB."','".$RUN_HOUR_LSB."','".$RUN_HOUR."','".$IMPORT_EXPORT."','".$inputJSON."','".$liuxTimeStamp."',DATE_ADD('".$teltonikaTimeStamp."',INTERVAL '05:30' HOUR_MINUTE),DATE_ADD(FROM_UNIXTIME('".$liuxTimeStamp."','%Y-%m-%d %h:%i:%s'),INTERVAL '12:30' HOUR_MINUTE), DATE_ADD(NOW(),INTERVAL '12:30' HOUR_MINUTE))";
	
	
      $sql= "INSERT INTO `heinn_iot_data_master`(`gateway_code`, `sensor_code`, `sensor_model`,`machine_status_value`,`machine_status`,`bearing_1_amps`, `bearing_1_temperature`,`bearing_2_amps`, `bearing_2_temperature`,`bearing_3_amps`, `bearing_3_temperature`,`bearing_4_amps`, `bearing_4_temperature`,`json_data`,`linux_date_time`,`teltonika_date_time`, `recorded_date_time`, `posted_date_time`) VALUES ('".$gatewayCode."','".$sensorCode."','".$sensorModel."','".$machine_status_value."','".$machine_status."','".$bearing_1_amps."','".$bearing_1_temperature."','".$bearing_2_amps."','".$bearing_2_temperature."','".$bearing_3_amps."','".$bearing_3_temperature."','".$bearing_4_amps."','".$bearing_4_temperature."','".$inputJSON."','".$liuxTimeStamp."','".$input[0]['DT']."','".$teltonikaTimeStamp."', NOW())";
	 
        $insSel = $conn->query($sql);
     
        
        if ($insSel === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
       
	   $selectView= "SELECT * FROM `heinn_iot_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."'";
       $resultView = mysqli_query($conn, $selectView);
	   $rowcount=mysqli_num_rows($resultView);
	   if($rowcount==0){
		
				  $sql2= "INSERT INTO `heinn_iot_data_master_view`(`gateway_code`, `sensor_code`, `sensor_model`,`machine_status_value`,`machine_status`,`bearing_1_amps`, `bearing_1_temperature`,`bearing_2_amps`, `bearing_2_temperature`,`bearing_3_amps`, `bearing_3_temperature`,`bearing_4_amps`, `bearing_4_temperature`,`json_data`,`linux_date_time`,`teltonika_date_time`, `recorded_date_time`, `posted_date_time`) VALUES ('".$gatewayCode."','".$sensorCode."','".$sensorModel."','".$machine_status_value."','".$machine_status."','".$bearing_1_amps."','".$bearing_1_temperature."','".$bearing_2_amps."','".$bearing_2_temperature."','".$bearing_3_amps."','".$bearing_3_temperature."','".$bearing_4_amps."','".$bearing_4_temperature."','".$inputJSON."','".$liuxTimeStamp."','".$input[0]['DT']."','".$teltonikaTimeStamp."', NOW())";
	 
				 
      }else{
		   	
					  $sql2= "UPDATE `heinn_iot_data_master_view` SET `machine_status_value`='".$machine_status_value."',`machine_status`='".$machine_status."',`bearing_1_amps`='".$bearing_1_amps."',`bearing_1_temperature`='".$bearing_1_temperature."',bearing_2_amps='".$bearing_2_amps."',bearing_2_temperature='".$bearing_2_temperature."',`bearing_3_amps`='".$bearing_3_temperature."', `bearing_3_temperature`='".$bearing_3_temperature."',`bearing_4_amps`='".$bearing_4_amps."', `bearing_4_temperature`='".$bearing_4_temperature."',`json_data`='".$inputJSON."',`linux_date_time`='".$liuxTimeStamp."',`teltonika_date_time`='".$input[0]['DT']."', `recorded_date_time`='".$teltonikaTimeStamp."', `posted_date_time`=NOW() WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."'";
			
	  }
        $insSel2 = $conn->query($sql2);
     
        
        if ($insSel2 === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $sql2 . "<br>" . $conn->error;
        }
		
		
		/*******************************************             Mail Trigger  Starts            ****************************************************/
	   $selAlertCont= "SELECT email FROM `arka_alert_contact_master` WHERE email_alert=1 AND is_active=1 AND `company_id`='".$sensMasDet['company_id']."' AND `branch_id`='".$sensMasDet['branch_id']."'";
       $ExeAlertCont = mysqli_query($conn, $selAlertCont);
	   if (mysqli_num_rows($ExeAlertCont) > 0) 
	   {
			 $alertContact='';
			 while($alertCont = mysqli_fetch_assoc($ExeAlertCont)) 
			{
			// Fetch all
			   $alertContact .= $alertCont['email'].",";
			}
		//	$string = rtrim($string, ".");
			$alertEmail= rtrim($alertContact, ",");
			echo $alertEmail." -- EmailId from Table <br>";
       } 
	   
	 echo  $selAlertPar= "SELECT * FROM `alert_parameter_mapping` WHERE `sensor_code`='".$sensorCode."'";
       $ExeAlertPar = mysqli_query($conn, $selAlertPar);
	   
	   if (mysqli_num_rows($ExeAlertPar) > 0) 
	   {
	      echo "alert parameter Mapping";
            while($parameter = mysqli_fetch_assoc($ExeAlertPar)) 
			{ 
			     echo $parameter['parameter_name']."-  Parameter Name <br>";
				$parameterName=$parameter['parameter_name'];
				if($parameter['mail_alert_status']=="Normal")
				{
              echo $selectEnergy= "SELECT ".$parameterName." FROM `heinn_iot_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND (".$parameterName." <= '".$parameter['min_alert_value']."' OR ".$parameterName." >= '".$parameter['max_alert_value']."')";
			  $ExeEnergy = mysqli_query($conn, $selectEnergy);
	           $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
				  if($ReadingValue > $parameter['max_alert_value']){
				  $alertStatus='High';
				  $alertValueName='Max Value Reached';
				  }
				  elseif($ReadingValue < $parameter['min_alert_value']){
				  $alertStatus='Low';
				  $alertValueName='Min Value Reached';
				  }
			  }else if($parameter['mail_alert_status']=="High"){
			  $selectEnergy= "SELECT ".$parameterName." FROM `heinn_iot_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND (".$parameterName." > '".$parameter['min_alert_value']."' AND ".$parameterName." < '".$parameter['max_alert_value']."')";
			  $ExeEnergy = mysqli_query($conn, $selectEnergy);
			  if (mysqli_num_rows($ExeEnergy) == 0) 
				{
				 $selectEnergy= "SELECT ".$parameterName." FROM `heinn_iot_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND ".$parameterName." <= '".$parameter['min_alert_value']."'";
			   $ExeEnergy = mysqli_query($conn, $selectEnergy);
	           $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='Low';
			   $alertValueName='Min Value Reached';
			   
			   }
			   else{
			   
			   $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='Normal';
			   $alertValueName='Normal Value Reached';
			   
			   }
			  }
			  else if($parameter['mail_alert_status']=="Low" ){
			  $selectEnergy= "SELECT ".$parameterName." FROM `heinn_iot_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND (".$parameterName." > '".$parameter['min_alert_value']."' AND ".$parameterName." < '".$parameter['max_alert_value']."')";
			  $ExeEnergy = mysqli_query($conn, $selectEnergy);
	          if (mysqli_num_rows($ExeEnergy) == 0) 
				{
				 $selectEnergy= "SELECT ".$parameterName." FROM `heinn_iot_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND ".$parameterName." >= '".$parameter['max_alert_value']."'";
			   $ExeEnergy = mysqli_query($conn, $selectEnergy);
	           $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='High';
			   $alertValueName='Max Value Reached';
			   
			   }
			   else{
			   
			   $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='Normal';
			   $alertValueName='Normal Value Reached';
			   
			   }
			  }
			  echo $alertStatus." --alert Status <br>".$alertValueName." --alert Value <br>".mysqli_num_rows($ExeEnergy);
			   
			    if (mysqli_num_rows($ExeEnergy) > 0) 
				{
				
			    echo $updateAlertPar= "UPDATE `alert_parameter_mapping` SET mail_alert_status='".$alertStatus."'  WHERE `alert_parameter_id`='".$parameter['alert_parameter_id']."'";
       			 $ExeAlertPar = mysqli_query($conn, $updateAlertPar);
				     echo $ReadingValue."-  Reading Value <br>";
				     echo $alertEmail."-  MailId <br>"; 
				     
				  // Step 1 - Enter your email address below.
$email = 'aal@arkaautomaations.com';

// If the e-mail is not working, change the debug option to 2 | $debug = 2;
$debug = 0;

// If contact form don't has the subject input change the value of subject here
$subject = 'Parameter Alert';

$message = '';

				   $message .= "Hi!<br><br><br>
	
								<b>Feeder Name</b>      : ".$parameter['feeder_name'].",<br>
								<b>Parameter Name</b>   : ".$parameter['parameter_name'].",<br>
								<b>Date Time</b>   : ".$parameter['recorded_date_time'].",<br>
								<b>".$alertValueName."</b>  : ".$ReadingValue.".<br><br><br><br><br>
	
	
								
                                <b>Best regards</b>,<br>
                                <b>Arka Automaations Limited.</b><br>
								";
								
				  $contentData=strip_tags($message);
								
			 $insAlertLog	="INSERT INTO `alert_log_master`(`company_id`, `branch_id`, `sensor_code`, `alert_type`, `parameter_name`, `alert_message`, `send_to`, `alert_status`, `recorded_date_time`, `posted_date_time`) VALUES ('".$sensMasDet['company_id']."','".$sensMasDet['branch_id']."','".$sensorCode."','Mail','".$parameter['parameter_name']."','".$contentData."','".$alertEmail."','".$alertStatus."','".$teltonikaTimeStamp."',DATE_ADD(NOW(),INTERVAL '00:00' HOUR_MINUTE))";		
			 $insLog = $conn->query($insAlertLog);
     
        
        if ($insLog === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $insAlertLog . "<br>" . $conn->error;
        }
            	    
$mail = new PHPMailer(true);

try {

	$mail->SMTPDebug = $debug;                                 // Debug Mode

	// Step 2 (Optional) - If you don't receive the email, try to configure the parameters below:

	$mail->IsSMTP();                                         // Set mailer to use SMTP
	$mail->Host = 'smtpout.asia.secureserver.net';				       // Specify main and backup server
	$mail->SMTPAuth = true;                                  // Enable SMTP authentication
//	$mail->Username = 'info@plumtekerp.in';                    // SMTP username
//	$mail->Password = 'Admin@2020';
//	$mail->Username = 'aal@arkaautomaations.com';                    // SMTP username
//  $mail->Password = 'Arka@2020';// SMTP password
     $mail->Username = 'tpl@tiebarfactory.com';                    // SMTP username
     $mail->Password = 'tpl6k@2020';// SMTP password
	$mail->SMTPAutoTLS = false;                               // Enable encryption, 'ssl' also accepted
	$mail->Port = 80;   								       // TCP port to connect to

//	$mail->AddAddress('vishalchandran11@gmail.com');	 						       // Add another recipient
    
	//  ***************     To Mail Starts  *************************
	$toMailArr =explode(",",$alertEmail);
    $toMailCount = count($toMailArr);
    $mailC=0;
    for($mailC==0; $mailC<$toMailCount; $mailC++){
        $mail->AddAddress($toMailArr[$mailC]);
    }   
	//  *************  To Mail Ends.... ***************************
	 
	//$mail->AddAddress($alertEmail);     // Add a secondary recipient
//	$mail->AddCC('karthikeyan@arkagroup.co.in');          // Add a "Cc" address. 
	//$mail->AddBCC('person4@domain.com', 'Person 4');         // Add a "Bcc" address. 

	// From - Name
	$fromName = 'Arka Automaations Limited';
	$mail->SetFrom($email, $fromName);

	// Repply To
/*	if( isset($_POST['email']) ) {
		$mail->AddReplyTo($_POST['email'], $fromName);
	}*/

	$mail->IsHTML(true);                                       // Set email format to HTML

	$mail->CharSet = 'UTF-8';

	$mail->Subject = $subject;
	$mail->Body    = $message;

	$mail->Send();
	$arrResult = array ('response'=>'success');

} catch (Exception $e) {
	$arrResult = array ('response'=>'error','errorMessage'=>$e->errorMessage());
} catch (\Exception $e) {
	$arrResult = array ('response'=>'error','errorMessage'=>$e->getMessage());
}

		if ($debug == 0) {
	echo json_encode($arrResult);
}	
				 	
			 }
			   
            }
       } 
	   

//mail("vishalchandran11@gmail.com", "Test Mail", "Test");

		/*******************************************             Mail Trigger   End          ****************************************************/
        $conn->close();
    
 }
    else {
        echo "Wrong API Key provided.";
    }

}
else {
    echo "No data posted with HTTP POST.";
}


function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>
