
<?php

//require_once "../config.php";
require_once('../config.php'); 
$servername = $config['DBHost'];

// REPLACE with your Database name
$dbname = $config['DBName'];
// REPLACE with Database user
$username = $config['DBUser'];
// REPLACE with Database user password
$password = $config['DBPassword'];
//echo $dbname; exit;
if(isset($_GET["gatewayCode"]))
{
    $inputJSON = file_get_contents('php://input');
    $input= json_decode( $inputJSON, true); 
    // $liuxTimeStamp=$input[0]['TS'];
    // $recordedTimeStamp = date("Y-m-d H:i:s",$input[0]['TS']);
     $telDate =$input[0]['D'];
     $teltonika_date = str_replace('/', '-', $telDate);
     $teltonikaTimeStamp =  date('Y-m-d H:i:s', strtotime($teltonika_date));
              
    	$conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } 
     //  $insLog = "INSERT INTO `gateway_ping_log` (`gateway_code`,`gateway_date_time`,`json_data`,`ping_date_time`) VALUES ('".$_GET["gatewayCode"]."','".$teltonikaTimeStamp."','".$inputJSON."',NOW())";
   // echo   $insLog = "INSERT INTO `gateway_ping_log` (`gateway_code`,`gateway_date_time`,`json_data`,`ping_date_time`) VALUES ('".$_GET["gatewayCode"]."',NOW(),'".$inputJSON."',NOW())";
     //  $insSel = $conn->query($insLog);
       
        $selectView= "SELECT * FROM `gateway_ping_log_view` WHERE `gateway_code`='".$_GET['gatewayCode']."'";
       $resultView = mysqli_query($conn, $selectView);
	   $rowcount=mysqli_num_rows($resultView);
	   if($rowcount==0){
	        $insLog2 = "INSERT INTO `gateway_ping_log_view` (`gateway_code`,`gateway_date_time`,`json_data`,`ping_date_time`) VALUES ('".$_GET["gatewayCode"]."',NOW(),'".$inputJSON."',NOW())";
            $insSel2 = $conn->query($insLog2);
	   }
	   else{
	       
	        $insLog2 = "UPDATE `gateway_ping_log_view` SET `gateway_date_time`=NOW(), `json_data`='".$inputJSON."', `ping_date_time`=NOW() WHERE gateway_code='".$_GET["gatewayCode"]."'";
            $insSel2 = $conn->query($insLog2);
	   }

    
}
?>