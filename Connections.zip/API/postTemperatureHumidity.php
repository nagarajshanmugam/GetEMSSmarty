<?php

/*
  Rui Santos
  Complete project details at https://RandomNerdTutorials.com/esp32-esp8266-mysql-database-php/
  
  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files.
  
  The above copyright notice and this permission notice shall be included in all
  copies or substantial portions of the Software.
*/
session_cache_limiter('nocache');
header('Expires: ' . gmdate('r', 0));

header('Content-type: application/json');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'php/php-mailer/src/PHPMailer.php';
require 'php/php-mailer/src/SMTP.php';
require 'php/php-mailer/src/Exception.php';
require_once('../Connections/ARKAEMS.php'); 
$servername = $hostname_arkaems;

// REPLACE with your Database name
$dbname = $database_arkaems;
// REPLACE with Database user
$username = $username_arkaems;
// REPLACE with Database user password
$password = $password_arkaems;
 
//exit;


// Keep this API Key value to be compatible with the ESP32 code provided in the project page. 
// If you change this value, the ESP32 sketch needs to match


   if ($_SERVER["REQUEST_METHOD"] == "POST") {
         $inputJSON = file_get_contents('php://input');
      //  $inputJSON = '{"apiKey": "R1c6RVNQMzItMS9TSTpBTTA1LTMvU01PREVMOkFNMDU=","temperature_c": 28.3,"humidity": 55.8}';
         $input= json_decode( $inputJSON, true); 
 echo $inputJSON."<br>";
 print_r($input);
  echo "<br>ia ma";
   // $api_key = test_input($_POST["api_key"]);
     $conn = new mysqli($servername, $username, $password, $dbname);
     mysqli_query($conn,"SET SESSION sql_mode = 'NO_ENGINE_SUBSTITUTION'");
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } 
   echo $sqlSensor = "SELECT * FROM arka_sensor_master WHERE isActive='1' AND status='1' AND api_key='".$input['apiKey']."'";
    $insSel = $conn->query($sqlSensor);
	
     $result = mysqli_query($conn, $sqlSensor);
	  echo $input['apiKey']." :apikeydecode<br>";
$sensMasDet = mysqli_fetch_assoc($result);
       
      

       
  if (mysqli_num_rows($result) > 0) {
          
       
        
         // Create connection
		   $apikeyDecd= base64_decode($input['apiKey']);
	 
	   $apiDec =explode("/", $apikeyDecd);
	   $gatewayCode=str_replace("GW:","",$apiDec[0]);
	   $sensorCode=str_replace("SI:","",$apiDec[1]);
	   $sensorModel=str_replace("SMODEL:","",$apiDec[2]);
           
           $temp_c= $input['temperature_c'];
           $temp_f= round(($temp_c * 1.8)+32);
           $hum= $input['humidity'];;
           date_default_timezone_set('Asia/Kolkata');
//echo "The time is " . date("Y-m-d H:i:sa");
          $recordedTimeStamp = date("Y-m-d H:i:s");
          $liuxTimeStamp=strtotime($recordedTimeStamp);
          
              
              $telDate =date("d/m/Y H:i:s");;
              $teltonika_date = str_replace('/', '-', $telDate);
              $teltonikaTimeStamp =  date('Y-m-d H:i:s', strtotime($teltonika_date));
        
       $insLog = "INSERT INTO `gateway_ping_log` (`gateway_code`,`gateway_date_time`,`json_data`,`ping_date_time`) VALUES ('".$gatewayCode."',NOW(),'".$inputJSON."',NOW())";
        $conn->query($insLog);
     
      $sql = "INSERT INTO temperature_data_master (gateway_code,sensor_code,sensor_model,temperature_c,temperature_f,humidity,VR_ARRAY_VALUE,linux_date_time,teltonika_date_time,recorded_date_time,posted_date_time) VALUES ('".$gatewayCode."','".$sensorCode."','".$sensorModel."','".$temp_c."','".$temp_f."','".$hum."','".$inputJSON."','".$liuxTimeStamp."','".$telDate."','".$teltonikaTimeStamp."',NOW())"; 
      $insSel = $conn->query($sql);
      echo $sql;
        
        if ($insSel === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
		
		
		
		$selectView= "SELECT * FROM `temperature_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."'";
       $resultView = mysqli_query($conn, $selectView);
	   $rowcount=mysqli_num_rows($resultView);
	   echo $selectView;
	   echo $rowcount;
	   if($rowcount==0){
	          $sql2= "INSERT INTO temperature_data_master_view (gateway_code,sensor_code,sensor_model,temperature_c,temperature_f,humidity,VR_ARRAY_VALUE,linux_date_time,teltonika_date_time,recorded_date_time,posted_date_time) VALUES ('".$gatewayCode."','".$sensorCode."','".$sensorModel."','".$temp_c."','".$temp_f."','".$hum."','".$inputJSON."','".$liuxTimeStamp."','".$telDate."','".$teltonikaTimeStamp."',NOW())";
      }else{
	  	      $sql2= "UPDATE `temperature_data_master_view` SET `temperature_c`='".$temp_c."',`temperature_f`='".$temp_f."',humidity='".$hum."',VR_ARRAY_VALUE='".$inputJSON."', `linux_date_time`='".$liuxTimeStamp."',teltonika_date_time='".$telDate."', `recorded_date_time`='".$teltonikaTimeStamp."', `posted_date_time`=NOW() WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."'";

	  
	  }
	  echo $sql2;
        $insSel2 = $conn->query($sql2);
      
        
        if ($insSel2 === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $sql2 . "<br>" . $conn->error;
        }
		/*****************************************************   Temp Query same temperature insert From Guindy to ambattur TTPL company    AM2305           *************************************************************************************************************************************************************************************************************/
       if($input['apiKey']=="R1c6UlVUOTU1LTMvU0k6QU0wNS01L1NNT0RFTDpBTTA1"){
	   

     
      $sqlT = "INSERT INTO temperature_data_master (gateway_code,sensor_code,sensor_model,temperature_c,temperature_f,humidity,VR_ARRAY_VALUE,linux_date_time,teltonika_date_time,recorded_date_time,posted_date_time) VALUES ('TRB145-4','AM05-7','".$sensorModel."','".$temp_c."','".$temp_f."','".$hum."','".$inputJSON."','".$liuxTimeStamp."','".$telDate."','".$teltonikaTimeStamp."',NOW())"; 
      $insSelT = $conn->query($sqlT);
      echo $sqlT;
        
        if ($insSelT === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $sqlT . "<br>" . $conn->error;
        }
		
		
		
		$selectViewT= "SELECT * FROM `temperature_data_master_view` WHERE `gateway_code`='TRB145-4' AND `sensor_code`='AM05-7'";
       $resultViewT = mysqli_query($conn, $selectViewT);
	   $rowcountT=mysqli_num_rows($resultViewT);
	   echo $selectViewT;
	   echo $rowcountT;
	   if($rowcountT==0){
	          $sql2T= "INSERT INTO temperature_data_master_view (gateway_code,sensor_code,sensor_model,temperature_c,temperature_f,humidity,VR_ARRAY_VALUE,linux_date_time,teltonika_date_time,recorded_date_time,posted_date_time) VALUES ('TRB145-4','AM05-7','".$sensorModel."','".$temp_c."','".$temp_f."','".$hum."','".$inputJSON."','".$liuxTimeStamp."','".$telDate."','".$teltonikaTimeStamp."',NOW())";
      }else{
	  	      $sql2T= "UPDATE `temperature_data_master_view` SET `temperature_c`='".$temp_c."',`temperature_f`='".$temp_f."',humidity='".$hum."',VR_ARRAY_VALUE='".$inputJSON."', `linux_date_time`='".$liuxTimeStamp."',teltonika_date_time='".$telDate."', `recorded_date_time`='".$teltonikaTimeStamp."', `posted_date_time`=NOW() WHERE gateway_code='TRB145-4' AND sensor_code='AM05-7'";

	  
	  }
	  echo $sql2T;
        $insSel2T = $conn->query($sql2T);
		
		
		
	   
	   }
	   /*****************************************************   Temp Query same temperature insert From Guindy to ambattur TTPL company    AM2305    Ends       *************************************************************************************************************************************************************************************************************/

       	/*******************************************             Mail Trigger  Starts            ****************************************************/
	   $selAlertCont= "SELECT email FROM `arka_alert_contact_master` WHERE email_alert=1 AND is_active=1 AND `company_id`='".$sensMasDet['company_id']."' AND `branch_id`='".$sensMasDet['branch_id']."'";
       $ExeAlertCont = mysqli_query($conn, $selAlertCont);
	   if (mysqli_num_rows($ExeAlertCont) > 0) 
	   {
			 $alertContact='';
			 while($alertCont = mysqli_fetch_assoc($ExeAlertCont)) 
			{
			// Fetch all
			   $alertContact .= $alertCont['email'].",";
			}
		//	$string = rtrim($string, ".");
			$alertEmail= rtrim($alertContact, ",");
			echo $alertEmail." -- EmailId from Table <br>";
       } 
	   
	echo   $selAlertPar= "SELECT * FROM `alert_parameter_mapping` WHERE `sensor_code`='".$sensorCode."'";
       $ExeAlertPar = mysqli_query($conn, $selAlertPar);
	   
	   if (mysqli_num_rows($ExeAlertPar) > 0) 
	   {
	      echo "alert parameter Mapping";
            while($parameter = mysqli_fetch_assoc($ExeAlertPar)) 
			{ 
			 echo $parameter['parameter_name']."-  Parameter Name <br>";
			  echo $parameter['mail_alert_status'];
				$parameterName=$parameter['parameter_name'];
				if($parameter['mail_alert_status']=="Normal")
				{
              echo $selectEnergy= "SELECT ".$parameterName." FROM `temperature_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND (".$parameterName." <= '".$parameter['min_alert_value']."' OR ".$parameterName." >= '".$parameter['max_alert_value']."')";
			  $ExeEnergy = mysqli_query($conn, $selectEnergy);
	           $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
				  if($ReadingValue > $parameter['max_alert_value']){
				  $alertStatus='High';
				  $alertValueName='Max Value Reached';
				  }
				  elseif($ReadingValue < $parameter['min_alert_value']){
				  $alertStatus='Low';
				  $alertValueName='Min Value Reached';
				  }
			  }else if($parameter['mail_alert_status']=="High"){
			 echo $selectEnergy= "SELECT ".$parameterName." FROM `temperature_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND (".$parameterName." > '".$parameter['min_alert_value']."' AND ".$parameterName." < '".$parameter['max_alert_value']."')";
			  $ExeEnergy = mysqli_query($conn, $selectEnergy);
			  if (mysqli_num_rows($ExeEnergy) == 0) 
				{
				 $selectEnergy= "SELECT ".$parameterName." FROM `temperature_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND ".$parameterName." <= '".$parameter['min_alert_value']."'";
			   $ExeEnergy = mysqli_query($conn, $selectEnergy);
	           $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='Low';
			   $alertValueName='Min Value Reached';
			   
			   }
			   else{
			   
			   $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='Normal';
			   $alertValueName='Normal Value Reached';
			   
			   }
			  }
			  else if($parameter['mail_alert_status']=="Low" ){
			  $selectEnergy= "SELECT ".$parameterName." FROM `temperature_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND (".$parameterName." > '".$parameter['min_alert_value']."' AND ".$parameterName." < '".$parameter['max_alert_value']."')";
			  $ExeEnergy = mysqli_query($conn, $selectEnergy);
	          if (mysqli_num_rows($ExeEnergy) == 0) 
				{
				 $selectEnergy= "SELECT ".$parameterName." FROM `temperature_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND ".$parameterName." >= '".$parameter['max_alert_value']."'";
			   $ExeEnergy = mysqli_query($conn, $selectEnergy);
	           $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='High';
			   $alertValueName='Max Value Reached';
			   
			   }
			   else{
			   
			   $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='Normal';
			   $alertValueName='Normal Value Reached';
			   
			   }
			  }
			  
			 /* $message .= "Hi!<br><br><br>
	
								<b>Feeder Name</b>      : ".$parameter['feeder_name'].",<br>
								<b>Parameter Name</b>   : ".$parameter['parameter_name'].",<br>
								<b>".$alertValueName."</b>  : ".$ReadingValue.".<br><br><br><br><br>
	
	
								
                                <b>Best regards</b>,<br>
                                <b>Arka Automaations Limited.</b><br>
								";
								
				  $contentData=strip_tags($message);
								
			 $insAlertLog	="INSERT INTO `alert_log_master`(`company_id`, `branch_id`, `sensor_code`, `alert_type`, `parameter_name`, `alert_message`, `send_to`, `alert_status`, `recorded_date_time`, `posted_date_time`) VALUES ('".$sensMasDet['company_id']."','".$sensMasDet['branch_id']."','".$sensorCode."','Mail','".$parameter['parameter_name']."','".$contentData."','".$alertEmail."','".$alertStatus."','".$teltonikaTimeStamp."',DATE_ADD(NOW(),INTERVAL '00:00' HOUR_MINUTE))";		
			 $insLog = $conn->query($insAlertLog);*/
			  
			echo   $alertStatus." --alert Status <br>".$alertValueName." --alert Value <br>".mysqli_num_rows($ExeEnergy);
			   
			    if (mysqli_num_rows($ExeEnergy) > 0) 
				{
				
			    echo $updateAlertPar= "UPDATE `alert_parameter_mapping` SET mail_alert_status='".$alertStatus."'  WHERE `alert_parameter_id`='".$parameter['alert_parameter_id']."'";
       			 $ExeAlertPar = mysqli_query($conn, $updateAlertPar);
				     echo $ReadingValue."-  Reading Value <br>";
				     echo $alertEmail."-  MailId <br>"; 
				     
				     $selectSensor= "SELECT * FROM `arka_sensor_master` WHERE `sensorCode`='".$parameter['sensor_code']."' AND status='1' AND isActive='1'";
			   $ExeSensor = mysqli_query($conn, $selectSensor);
	           $ExeSensorArr = mysqli_fetch_assoc($ExeSensor);
			  $sensorNameVal = $ExeSensorArr['sensorName'];
				     
				  // Step 1 - Enter your email address below.
$email = 'aal@arkaautomaations.com';

// If the e-mail is not working, change the debug option to 2 | $debug = 2;
$debug = 0;

// If contact form don't has the subject input change the value of subject here
//$subject = 'Parameter Alert';
$subject = $parameter['feeder_name'];
$message = '';

				   $message .= "ARKA EMS - Alert Message!<br><br><br>
	
								<b>Feeder Name</b>      : ".$parameter['feeder_name'].",<br>
								<b>Parameter Name</b>   : ".$parameter['parameter_name'].",<br>
								<b>".$alertValueName."</b>  : ".$ReadingValue.".<br><br><br><br><br>
	
	
								
                                <br>
								";
								
				  $contentData=strip_tags($message);
								
							
			 $insAlertLog	="INSERT INTO `alert_log_master`(`company_id`, `branch_id`, `sensor_code`, `alert_type`, `parameter_name`, `alert_message`, `send_to`, `alert_status`, `recorded_date_time`, `posted_date_time`) VALUES ('".$sensMasDet['company_id']."','".$sensMasDet['branch_id']."','".$sensorCode."','Mail','".$parameter['parameter_name']."','".$contentData."','".$alertEmail."','".$alertStatus."','".$teltonikaTimeStamp."',DATE_ADD(NOW(),INTERVAL '00:00' HOUR_MINUTE))";		
			 $insLog = $conn->query($insAlertLog);
     
        
        if ($insLog === TRUE) {
            echo "New record created successfully1";
        } 
        else {
            echo "Error: " . $insAlertLog . "<br>" . $conn->error;
        }
            echo $alertStatus;	    
$mail = new PHPMailer(true);

try {
if($alertStatus<>"Normal")
{echo "here";
	$mail->SMTPDebug = $debug;                                 // Debug Mode

	// Step 2 (Optional) - If you don't receive the email, try to configure the parameters below:

	$mail->IsSMTP();                                         // Set mailer to use SMTP
	$mail->Host = 'smtpout.asia.secureserver.net';				       // Specify main and backup server
	$mail->SMTPAuth = true;                                  // Enable SMTP authentication
//	$mail->Username = 'info@plumtekerp.in';                    // SMTP username
//	$mail->Password = 'Admin@2020';
//	$mail->Username = 'aal@arkaautomaations.com';                    // SMTP username
//  $mail->Password = 'Arka@2020';// SMTP password
     $mail->Username = 'tpl@tiebarfactory.com';                    // SMTP username
   //  $mail->Password = 'tpl6k@2020';// SMTP password
     $mail->Password = 'tpl@tiebar';
	$mail->SMTPAutoTLS = false;                               // Enable encryption, 'ssl' also accepted
	$mail->Port = 80;   								       // TCP port to connect to

//	$mail->AddAddress('vishalchandran11@gmail.com');	 						       // Add another recipient
    
	//  ***************     To Mail Starts  *************************
	$toMailArr =explode(",",$alertEmail);
    $toMailCount = count($toMailArr);
    $mailC=0;
    for($mailC==0; $mailC<$toMailCount; $mailC++){
        $mail->AddAddress($toMailArr[$mailC]);
    }   
	//  *************  To Mail Ends.... ***************************
	 
	//$mail->AddAddress($alertEmail);     // Add a secondary recipient
//	$mail->AddCC('karthikeyan@arkagroup.co.in');          // Add a "Cc" address. 
	//$mail->AddBCC('person4@domain.com', 'Person 4');         // Add a "Bcc" address. 

	// From - Name
	$fromName = 'Arka Automaations Limited';
	$mail->SetFrom($email, $fromName);

	// Repply To
/*	if( isset($_POST['email']) ) {
		$mail->AddReplyTo($_POST['email'], $fromName);
	}*/

	$mail->IsHTML(true);                                       // Set email format to HTML

	$mail->CharSet = 'UTF-8';

	$mail->Subject = $subject;
	$mail->Body    = $message;

	$mail->Send();
	$arrResult = array ('response'=>'success');
}
} catch (Exception $e) {
	$arrResult = array ('response'=>'error','errorMessage'=>$e->errorMessage());
} catch (\Exception $e) {
	$arrResult = array ('response'=>'error','errorMessage'=>$e->getMessage());
}
print_r($arrResult);

echo $selAlertCont= "SELECT mobile FROM `arka_alert_contact_master` WHERE sms_alert=1 AND is_active=1 AND `company_id`='".$sensMasDet['company_id']."' AND `branch_id`='".$sensMasDet['branch_id']."'";
       $ExeAlertCont = mysqli_query($conn, $selAlertCont);
	   
	    $selBranchCont= "SELECT branch_name FROM `arka_branch_master` WHERE record_status=1 AND is_active=1 AND `company_id`='".$sensMasDet['company_id']."' AND `sl_no`='".$sensMasDet['branch_id']."'";
       $ExeBranchCont = mysqli_query($conn, $selBranchCont);
	   $BranchCont = mysqli_fetch_assoc($ExeBranchCont);
	   
	   if (mysqli_num_rows($ExeAlertCont) > 0) 
	   {
			 $alertContact='';
			 while($alertCont = mysqli_fetch_assoc($ExeAlertCont)) 
			{
			// Fetch all
			   $alertContact .= $alertCont['mobile'].",";
			   
								$apiKey = urlencode('bdv8P3QD1RM-00HgVBfsXFz4FiL7WN35p7HCcrGj1M');
// Message details
//$numbers = urlencode('919884422723'); //Mobile number on which you want to send message
$numbers = urlencode($alertContact);
$sender = urlencode('AALIOT');
/*$message = rawurlencode('Device Code : dev1001,
Installed at : Guindy,
 R_Voltagr : 100, 
at 08/11/2021 10:58:00'); */
$teltonikaTimeStamp = str_replace('-', '/', $teltonikaTimeStamp);
$teltonikaTimeStamp =  date('H:i d/m/Y', strtotime($teltonika_date));
$devId=$parameter['feeder_name'];
$area=$BranchCont['branch_name'];
$datVar=$parameter['parameter_name'];
$datVal=$ReadingValue.'-'.$alertValueName;
$datTime=$teltonikaTimeStamp;

/*$devId='dev1001';
$area='Guindy';
$datVar='R_Voltagr';
$datVal='100';
$datTime='08/11/2021 17:35:00';*/

$message = rawurlencode('Device Code : '.$devId.',
Installed at : '.$area.',
 '.$datVar.' : '.$datVal.', 
at '.$datTime.'');

// Prepare data for POST request
$data = 'apikey=' . $apiKey . '&numbers=' . $numbers . "&sender=" . $sender . "&message=" . $message;
// Send the GET request with cURL
$ch = curl_init('https://api.textlocal.in/send/?' . $data);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);
// Process your response here
echo $response;
			}
			}

		if ($debug == 0) {
	echo json_encode($arrResult);
}	
				 	
			 }
			   
            }
       } 
	   

//mail("vishalchandran11@gmail.com", "Test Mail", "Test");

		/*******************************************             Mail Trigger   End          ****************************************************/

       
       
        $conn->close();
    
 }
    else {
        echo "Wrong API Key provided.";
    }
}
else {
    echo "No data posted with HTTP POST.";
}


function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
