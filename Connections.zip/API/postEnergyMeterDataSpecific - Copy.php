<?php

session_cache_limiter('nocache');
header('Expires: ' . gmdate('r', 0));

header('Content-type: application/json');


//echo  "hai"; exit;
require_once('../Connections/ARKAEMS.php'); 
$servername = $hostname_arkaems;

// REPLACE with your Database name
$dbname = $database_arkaems;
// REPLACE with Database user
$username = $username_arkaems;
// REPLACE with Database user password
$password = $password_arkaems;
if(function_exists('date_default_timezone_set')) {
		date_default_timezone_set("Asia/Kolkata");
}


/*$servername = "166.62.10.227";

// REPLACE with your Database name
$dbname = "emslte";
// REPLACE with Database user
$username = "emslte";
// REPLACE with Database user password
$password = "emslte@2020";*/
 
//exit;


// Keep this API Key value to be compatible with the ESP32 code provided in the project page. 
// If you change this value, the ESP32 sketch needs to match

//echo "hai"; exit;
//echo $_GET['jsonValue']; exit;
   //if ($_SERVER["REQUEST_METHOD"] == "POST") {
	if ($_GET['jsonValue']) {
         //$inputJSON = file_get_contents('php://input');
		 $inputJSON = $_GET['jsonValue'];
		 //echo $inputJSON; exit;
         $lastVal=substr($inputJSON,-1);
		 //echo 'Last Value:'.$lastVal;
		 if($lastVal=="]"){
		 $lastChar="";
		 }else{
		 $lastChar="]";
		 }
		 $inputJSON =$inputJSON."".$lastChar;
		 //echo  $inputJSON; 
         $input= json_decode( $inputJSON, true); 
		 //echo  $input; 
		 $elementCount  = count($input);

		 //echo 'Element Count :'.$elementCount; exit;
	//	 echo $inputJSON; exit;
	//$apiKey="R1c6VFJCMTQ1LTIvU0k6U19FTTRNLTEvU01PREVMOlNfRU00TQ==";
 // $api_key = test_input($_POST["api_key"]);
  $apiKey = $input[0]['apiKey'];
     $conn = new mysqli($servername, $username, $password, $dbname);
     mysqli_query($conn,"SET SESSION sql_mode = 'NO_ENGINE_SUBSTITUTION'");
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } 
     $sqlSensor = "SELECT * FROM arka_sensor_master WHERE isActive='1' AND status='1' AND api_key='".$apiKey."'";
    $insSel = $conn->query($sqlSensor);
	
     $result = mysqli_query($conn, $sqlSensor);
	 $sensMasDet = mysqli_fetch_assoc($result);
	 $sensMasDetCount = mysqli_num_rows($result);
	 
	 mysqli_free_result($insSel);
	 mysqli_free_result($result);
	 
	  $cost=$sensMasDet["unit_rate"];
	  $mType=$sensMasDet["feeder_type"];

       
	 //echo "Sensor Master Det Count :".$sensMasDetCount; exit;

       
  if ($sensMasDetCount > 0) {
        
         // Create connection
		   $apikeyDecd= base64_decode($apiKey);
	 
	  $apiDec =explode("/", $apikeyDecd);
	   $gatewayCode=str_replace("GW:","",$apiDec[0]);
	   $sensorCode=str_replace("SI:","",$apiDec[1]);
	   $sensorModel=str_replace("SMODEL:","",$apiDec[2]);
	   

           $jsonDecd= str_replace(array('[', ',]', ']'), '', $input[0]['VR']);
           $str_arr= explode (",", $jsonDecd); 

		   $liuxTimeStamp=$input[0]['TS'];

		   if($liuxTimeStamp !="XXXXXX")
		   {
			   $recordedTimeStamp = date("Y-m-d H:i:s",$input[0]['TS']);
			   $telDate =$input[0]['DT'];
			   $teltonika_date = str_replace('/', '-', $telDate);
			   $teltonikaTimeStamp =  date('Y-m-d H:i:s', strtotime($teltonika_date));
		   }
		   else
		   {
			   $liuxTimeStamp='';
			   $recordedTimeStamp = ''; 
			   $teltonikaTimeStamp='';
		   
		   }
		   
		   
		   
	  echo $selSensorMasterQry = 'SELECT * FROM `sensor_model_master` WHERE model_id = "'.$sensorModel.'" AND status = "1"';"<br/>";  
	 $ExeSensorMasterQry = mysqli_query($conn, $selSensorMasterQry);
	 if (!$ExeSensorMasterQry) {
		die("Query failed: " . mysqli_error($conn));
	}
	
	$rsltSensorMaster = mysqli_fetch_assoc($ExeSensorMasterQry);
	 $sensorModelId= $rsltSensorMaster['sl_no'];
	$sensorModelSegmentCount= $rsltSensorMaster['segment_count'];

	echo "element Count : ". $elementCount."<br/>";
	echo "Segment Model Count : ". $sensorModelSegmentCount."<br/>"; 
	
	
	if($elementCount >= $sensorModelSegmentCount){
		$sRegValue1='';
		$sRegValue='';
	  
		for ($x =0; $x < $elementCount; $x++) {


			$stRegValue = $input[$x]['ST'];
			$vrValue = $input[$x]['VR'];
			//(start_register_parameter_mapping.register_order-1) AS register_order);

			 $selSenModelSegQryFormulaType = 'SELECT arka_sensor_model_segment_details.segment_id,arka_sensor_model_segment_details.start_register_value,start_register_parameter_mapping.parameter_id,start_register_parameter_mapping.formula_type,start_register_parameter_mapping.multiplication_factor,start_register_parameter_mapping.register_order, sensor_model_parameter_master.parameter_name FROM `arka_sensor_model_segment_details`,start_register_parameter_mapping,sensor_model_parameter_master WHERE arka_sensor_model_segment_details.sensor_model_id="'.$sensorModelId.'" AND start_register_value ="'.$stRegValue.'" AND start_register_parameter_mapping.segment_id=arka_sensor_model_segment_details.segment_id AND start_register_parameter_mapping.parameter_id = sensor_model_parameter_master.sl_no AND start_register_parameter_mapping.segment_id = arka_sensor_model_segment_details.segment_id AND arka_sensor_model_segment_details.status="1" AND start_register_parameter_mapping.status="1" ORDER BY register_order';   
			// segment_id | start_register_value | parameter_id formula_type | multiplication_factor | register_order | parameter_name
			// 21 |1 |154 |Multiple |(value1+value2* 65536)*0.01 |13,14 |flow
		   $ExeselSenModelSegQryFormulaType = mysqli_query($conn, $selSenModelSegQryFormulaType);

			foreach ($ExeselSenModelSegQryFormulaType as $sensorModelSegFormulaT) {

				//$regOrder= $sensorModelSeg['register_order'];
				$f_type= $sensorModelSegFormulaT['formula_type'];

						if($f_type == "Multiple"){

							$s_reg_par_map_reg_order = 'start_register_parameter_mapping.register_order';
							
						}else{

							$s_reg_par_map_reg_order = '(start_register_parameter_mapping.register_order -1) AS register_order';
							
						}

				}

			   $selSenModelSegQry = 'SELECT arka_sensor_model_segment_details.segment_id,arka_sensor_model_segment_details.start_register_value,start_register_parameter_mapping.parameter_id,start_register_parameter_mapping.formula_type,start_register_parameter_mapping.multiplication_factor,'.$s_reg_par_map_reg_order.', sensor_model_parameter_master.parameter_name FROM `arka_sensor_model_segment_details`,start_register_parameter_mapping,sensor_model_parameter_master WHERE arka_sensor_model_segment_details.sensor_model_id="'.$sensorModelId.'" AND start_register_value ="'.$stRegValue.'" AND start_register_parameter_mapping.segment_id=arka_sensor_model_segment_details.segment_id AND start_register_parameter_mapping.parameter_id = sensor_model_parameter_master.sl_no AND start_register_parameter_mapping.segment_id = arka_sensor_model_segment_details.segment_id AND arka_sensor_model_segment_details.status="1" AND start_register_parameter_mapping.status="1" ORDER BY register_order';  
              // segment_id | start_register_value | parameter_id formula_type | multiplication_factor | register_order | parameter_name
			  // 21 |1 |154 |Multiple |(value1+value2* 65536)*0.01 |13,14 |flow
			 $ExeSenModelSegQry = mysqli_query($conn, $selSenModelSegQry);
			  if (!$ExeSenModelSegQry) {
			  die("Query failed: " . mysqli_error($conn));
			 	 }
			 $rsltSensorModelSeg = mysqli_fetch_assoc($ExeSenModelSegQry);
			 //echo $rsltSensorModelSeg['parameter_name'];
			 $VrJsonDecd= str_replace(array('[', ',]', ']'), '', $vrValue);
			 $vr_str_arr= explode (",", $VrJsonDecd); 
			 //echo $vr_str_arr[0]; 
			 $vr_str_arr_count= count($vr_str_arr);

			 //echo "VR Str Array Count :".$vr_str_arr_count."<br/>";


			
             
			 
			 for ($i =0; $i < $vr_str_arr_count; $i++) {			
				
					foreach ($ExeSenModelSegQry as $sensorModelSeg) {

						$regOrder= $sensorModelSeg['register_order'];
						$f_type= $sensorModelSeg['formula_type'];
						//echo $f_type."<br/>"; 
						 //echo $regOrder; exit;

						

//$stRegValue == $rsltSensorModelSeg['start_register_value'] && $i == $regOrder
//200==200 && 0 == 0
						if ($stRegValue == $rsltSensorModelSeg['start_register_value'] && $i == $regOrder){

							//echo $stRegValue; exit;
							//$sRegValue .= $sensorModelSeg['parameter_name'].'='.$vr_str_arr[$i].',';
							//eg: In value/100 replace value keyword into actual value in array [23213,....]
                              //echo "I value ".$i; exit;
							  echo $senModelParamQuery = "SELECT sensor_model_parameter_master.*,".$s_reg_par_map_reg_order.",arka_sensor_model_segment_details.start_register_value FROM sensor_model_parameter_master,start_register_parameter_mapping,arka_sensor_model_segment_details WHERE sensor_model_parameter_master.sensor_model_id='".$sensorModelId."' AND start_register_parameter_mapping.segment_id=arka_sensor_model_segment_details.segment_id AND start_register_parameter_mapping.parameter_id=sensor_model_parameter_master.sl_no AND start_register_parameter_mapping.status='1' AND sensor_model_parameter_master.status='1' ORDER BY start_register_parameter_mapping.segment_id,register_order"; exit;
					$senModelParamQueryData = mysqli_query($conn, $senModelParamQuery);
					global $tableField;
					$tableField = '';  // Initialize the global variable
				   while ($senModelParamQueryData1 = mysqli_fetch_assoc($senModelParamQueryData)) {
					   // Now $senModelParamQueryData1 contains one row of data at a time
					   $param = $senModelParamQueryData1["parameter_name"]; // R_VOLTAGE
					   $datat = $senModelParamQueryData1["data_type"]; // VARCHAR
					   $datal = $senModelParamQueryData1["data_length"]; // 255
				   
					   // You can now use $param, $datat, $datal as needed
					   // For example, echo them:
					   //echo "Parameter: $param, Data Type: $datat, Data Length: $datal<br>";
			   
					   global $tableField;    
					   $tableField .=$param.",";
					   //$senModelParamQueryData1["parameter_name"] =
			   
			   
					   //echo  $tableField;  
				   }

							
							  if($f_type == 'Multiple'){

								$mFactorSplit = explode(",",$sensorModelSeg['register_order']);
								//echo $mFactorSplit[0]-1; exit;
								$mFactor_arr_count= count($mFactorSplit);
								//echo $mFactor_arr_count; 
								$mulForm=$sensorModelSeg['multiplication_factor'];
								//echo $mulForm; exit;
								
								for ($r = 1; $r <= $mFactor_arr_count; $r++) {
									// Assuming $arrVal holds the index corresponding to $r in some logic
									$value = 'value' . $r; // The placeholder to be replaced
									$arrVal=$mFactorSplit[$r-1];
									// Ensure $arrVal and $vr_str_arr[$arrVal] are valid
									if (isset($vr_str_arr[$arrVal])) {
										// Replace the 'value$r' placeholder with the corresponding array value
										$mulForm = str_replace($value, $vr_str_arr[$arrVal], $mulForm);
									} else {
										// Handle if $arrVal is not set in the array
										// You could log an error or set a default value
									}
								}
								
									//echo $mulForm; exit;
								  //echo $sRegValue1 .= "'".$vr_str_arr[$i]."',"; 
							}else{
	
								$mulForm = str_replace("value",$vr_str_arr[$i],$sensorModelSeg['multiplication_factor']);
	
							}

							  //echo $mul_factor1;
							//echo $mFactor_arr_count; exit;
							//$mul_factor1 = str_replace("value",$vr_str_arr[$i],$sensorModelSeg['multiplication_factor']);
							//echo $mul_factor1;
							//$mul_factor = $sensorModelSeg['multiplication_factor'];
							//Above value output is 23213/100//232.13
							//$factorOperator = substr($mul_factor1, 0, 1);
							//$remainingCharacters = substr($mul_factor1, 1);
							//$sRegValue1 .= "'".$vr_str_arr[$i]."',";
							//$sRegValue .= "".$vr_str_arr[$i]."$factorOperator".$remainingCharacters.",";
							//$sRegValue .= "$factorOperator".$remainingCharacters.",";
							$sRegValue .= $mulForm.",";
							
							//echo $sRegValue; exit;

					//$sRegValue .= $sensorModelSeg['parameter_name'].':'.$rsltSensorModelSeg['start_register_value'].'['.$i.']'.'='.$vr_str_arr[$i];

					$rsltSensorModelSeg['parameter_name'];
					$rsltSensorModelSeg['start_register_value'];
					$rsltSensorModelSeg['register_order'];
					//echo $sRegValue;

					

					}
             
			      }
				  //$regOrder +=1;
				  
			  }
			 
			 
			  
			
			 
			 
			 



	}
	//echo $sRegValue1."<br/>";
	//echo $sRegValue; 

	//$srSplit = explode(",",$sRegValue);

	$str_last = rtrim($sRegValue,',');
	//$str_last = $sRegValue.replace(/,\s*$/, "");
	//echo $str_last;
	$srSplit = explode(",",$str_last);
	//echo $srSplit[0]; exit;
	$sr_arr_count= count($srSplit);
	//echo ($sr_arr_count);
	//echo "Sreg".$sRegValue."<br/>"; exit;

	    
	//echo  $tableField;  exit;
	

			//echo  $tableField; 
			
			echo"Outside Loop";  
			 $sensorTableName = str_replace("-", "_", $sensorCode);
			 echo $sql= " INSERT INTO $sensorTableName (`company_id`,`branch_id`,`gateway_code`, `sensor_code`,`sensor_name`, `sensor_model`,`feeder_type`,`unit_rate`, $tableField `linux_date_time`,`teltonika_date_time`, `recorded_date_time`,`posted_date_time`, `is_active`, `status`) VALUES ('1','1','".$gatewayCode."','".$sensorCode."','".$sensorModel."','".$sensorModel."','".$mType."', '".$cost."', $sRegValue'".$liuxTimeStamp."','".$input[0]['DT']."','".$teltonikaTimeStamp."', NOW(), '1', '1')"; exit; 


	
}
$insSel = $conn->query($sql);
echo "am outside of condition";
		  
if ($insSel === TRUE) {

	echo $senModelTableQuery = "SELECT * FROM $sensorTableName WHERE sensor_code='".$sensorCode."' AND status='1' ORDER BY slNo DESC LIMIT 0,1"; 
	$senModelTableData = mysqli_query($conn, $senModelTableQuery);
	$senModelTableDataResult = mysqli_fetch_assoc($senModelTableData);

// 	// Get field names
//    $fields = $senModelTableData->fetch_fields();

// foreach ($fields as $field) {
//     echo $field->name . "<br>";
// }
 $KWH = $senModelTableDataResult['KWH'];
//echo $KWH; exit;
	echo "New record created successfully";
} 
else {
	echo "Error: " . $sql . "<br>" . $conn->error;
}       
      
      
       
	  
		/****************     Cron Data Post            **********************/
		$deliverytime = new DateTime(date($teltonikaTimeStamp));
		//echo $teltonikaTimeStamp; 
		//echo $deliverytime->format('H');exit;
		$hour = $deliverytime->format('H');
		$recDate =$deliverytime->format('Y-m-d');
		$hour=intval($hour);
		$currDate=$recDate;
		//$currDate=date('Y-m-d');
		$date2=date_create($currDate);
		date_sub($date2,date_interval_create_from_date_string("1 days"));
		$prevDate=date_format($date2,"Y-m-d");

/*		if ($hour >= 0 && $hour <8) {
			$date=date_create($recDate);
			//$date=date_create(date('Y-m-d'));
			date_sub($date,date_interval_create_from_date_string("1 days"));
			$currDate=date_format($date,"Y-m-d");
			$date2=date_create($currDate);
			date_sub($date2,date_interval_create_from_date_string("1 days"));
			$prevDate=date_format($date2,"Y-m-d");
		} else {
			$currDate=$recDate;
			//$currDate=date('Y-m-d');
			$date2=date_create($currDate);
			date_sub($date2,date_interval_create_from_date_string("1 days"));
			$prevDate=date_format($date2,"Y-m-d");
		}
		*/
		//echo $currDate."Curr Date <br>";
		//echo $prevDate."Prvi Date <br>";
		/******** Current Date Start *********/
		
		echo $selCronData="SELECT * FROM `cron_daily_energy_data` WHERE sensor_code='".$sensorCode."' AND recorded_date='".$currDate."'"; 
		$exeCronSel = mysqli_query($conn, $selCronData);
		$cronDataFet = mysqli_fetch_assoc($exeCronSel);
		$cronDataCount = mysqli_num_rows($exeCronSel);
		mysqli_free_result($exeCronSel);
		
		/******** Current Date End *********/

		/******** Previuos Date Start *********/
		
		$selCronDataYes="SELECT * FROM `cron_daily_energy_data` WHERE sensor_code='".$sensorCode."' AND recorded_date=DATE_SUB('".$currDate."',INTERVAL 1 DAY)";
		$exeCronSelYes = mysqli_query($conn, $selCronDataYes);
		$cronDataFetYes = mysqli_fetch_assoc($exeCronSelYes);
		$cronDataCountYes = mysqli_num_rows($exeCronSelYes);
		mysqli_free_result($exeCronSelYes);
		
		/******** Previuos Date End *********/
		
		if($cronDataCount>0){
		
			/**************** EB Condition *****************/

			if($cronDataFet["start_cum_kwh"]>0){
				if($cronDataCountYes>0 && $cronDataFetYes["end_cum_date"]>0){
					//echo "<br> if";
					$startKWH=$cronDataFetYes["end_cum_kwh"];
					$startDate=$cronDataFetYes["end_cum_date"];

				}else{
					$startKWH=$cronDataFet["start_cum_kwh"];
					$startDate=$cronDataFet["start_cum_date"];
					//echo "<br> else<br>";
				}
				$updateSetVal='';
			}
			else{
				if($cronDataCountYes>0 && $cronDataFetYes["end_cum_date"]>0){
					$startKWH=$cronDataFetYes["end_cum_kwh"];
					$startDate=$cronDataFetYes["end_cum_date"];
					//echo "<br> START KWH >".$startKWH."<br>else> if";
				}else{
					$startKWH=$KWH;
					$startDate=$teltonikaTimeStamp;
					//echo "<br>else> else";
				}
				$updateSetVal='start_cum_kwh="'.$startKWH.'", `start_cum_date`="'.$startDate.'", ';
				//echo $KWH."<br>start: ".$startKWH;

			}
			$endKWH=$KWH;
			$endDate=$teltonikaTimeStamp;
			
			$consuptionKWH=$endKWH-$startKWH;
			if($startKWH > $endKWH){
				$selSensorMasterMaxKwhQry = 'SELECT * FROM `sensor_model_master` WHERE model_id = "'.$sensorModel.'" AND status = "1"';  
				$ExeSensorMasterMaxKwhQry = mysqli_query($conn, $selSensorMasterMaxKwhQry);
				$rsltSensorMasterMaxKwh = mysqli_fetch_assoc($ExeSensorMasterMaxKwhQry);
				$max_kwm_in_meter = $rsltSensorMasterMaxKwh['max_kwh'];
				$consuptionKWH = ($max_kwm_in_meter - $startKWH)+$endKWH;

			}

			//$consuptionKWH=$endKWH-$startKWH;
			$consuptionCost=$consuptionKWH*$cost;
			
			/**************** DG Condition *****************/
			$DG_KWH = '';
			if($sensMasDet['meterMode']=='DG'){
				$DG_KWH = $KWH;
			}

			if($cronDataFet["dg_start_cum_kwh"]>0){
				if($cronDataCountYes>0 && $cronDataFetYes["dg_end_cum_date"]>0){
					//echo "<br> if";
					$startDgKWH=$cronDataFetYes["dg_end_cum_kwh"];
					$startDgDate=$cronDataFetYes["dg_end_cum_date"];

				}else{
					$startDgKWH=$cronDataFet["dg_start_cum_kwh"];
					$startDgDate=$cronDataFet["dg_start_cum_date"];
					//echo "<br> else<br>";
				}
				$updateDgSetVal='';
			}
			else{
				if($cronDataCountYes>0 && $cronDataFetYes["dg_end_cum_date"]>0){
					$startDgKWH=$cronDataFetYes["dg_end_cum_kwh"];
					$startDgDate=$cronDataFetYes["dg_end_cum_date"];
					//echo "<br> START KWH >".$startKWH."<br>else> if";
				}else{
					$startDgKWH=$DG_KWH;
					$startDgDate=$teltonikaTimeStamp;
					//echo "<br>else> else";
				}
				$updateDgSetVal=' dg_start_cum_kwh="'.$startDgKWH.'", `dg_start_cum_date`="'.$startDgDate.'", ';
				//echo $KWH."<br>start: ".$startKWH;

			}
			//echo $KWH."<br>start: ".$startKWH;

						
			$endDgKWH=$DG_KWH;
			$endDgDate=$teltonikaTimeStamp;
			$costDg=$sensMasDet["dg_unit_rate"];
			$consuptionDgKWH=$endDgKWH-$startDgKWH;
			$consuptionDgCost=$consuptionDgKWH*$costDg;

			 $UpdateCronQry='UPDATE `cron_daily_energy_data` SET '.$updateSetVal.' `feeder_type`="'.$sensMasDet["feeder_type"].'", `end_cum_kwh`="'.$endKWH.'",`end_cum_date`="'.$endDate.'", `consuption_kwh`="'.$consuptionKWH.'", `cost`="'.$sensMasDet["unit_rate"].'", `consuption_cost`="'.$consuptionCost.'", dg_end_cum_kwh="'.$endDgKWH.'",`dg_end_cum_date`="'.$endDgDate.'", dg_consuption_kwh="'.$consuptionDgKWH.'", dg_cost="'.$sensMasDet["dg_unit_rate"].'", dg_consuption_cost="'.$consuptionDgCost.'",`posted_date_time`=NOW(),'.$updateDgSetVal.' `created_by`="API" WHERE `company_id`="'.$sensMasDet["company_id"].'" AND `branch_id`="'.$sensMasDet["branch_id"].'" AND `gateway_code`="'.$sensMasDet["gateway_id"].'" AND sensor_code="'.$sensorCode.'" AND `recorded_date`="'.$currDate.'"';   

			$conn->query($UpdateCronQry);
		
		
		}else{
				/***************   EB Condition Starts     ***********************/
				if($cronDataCountYes>0 && $cronDataFetYes["end_cum_date"] >0){
					$startKWH=$cronDataFetYes["end_cum_kwh"];
					$startDate=$cronDataFetYes["end_cum_date"];

				}else{
					$startKWH=$KWH;
					$startDate=$teltonikaTimeStamp;

				}
				$endKWH=$KWH;
				$endDate=$teltonikaTimeStamp;
				$cost=$sensMasDet["unit_rate"];

				$consuptionKWH=$endKWH-$startKWH;
			if($startKWH > $endKWH){
				$selSensorMasterMaxKwhQry = 'SELECT * FROM `sensor_model_master` WHERE model_id = "'.$sensorModel.'" AND status = "1"';  
				$ExeSensorMasterMaxKwhQry = mysqli_query($conn, $selSensorMasterMaxKwhQry);
				$rsltSensorMasterMaxKwh = mysqli_fetch_assoc($ExeSensorMasterMaxKwhQry);
				$max_kwm_in_meter = $rsltSensorMasterMaxKwh['max_kwh'];
				$consuptionKWH = ($max_kwm_in_meter - $startKWH)+$endKWH;

			}

				//$consuptionKWH=$endKWH-$startKWH;
				$consuptionCost=$consuptionKWH*$cost;
				if($consuptionKWH<=0){
				  $consuptionCost=0;  
				}

				/***************   DG Condition Starts     ***********************/

				if($cronDataCountYes>0 && $cronDataFetYes["dg_end_cum_date"] >0){
					$startDgKWH=$cronDataFetYes["dg_end_cum_kwh"];
					$startDgDate=$cronDataFetYes["dg_end_cum_date"];

				}else{
					$startDgKWH=$DG_KWH;
					$startDgDate=$teltonikaTimeStamp;

				}
				$endDgKWH=$DG_KWH;
				$endDgDate=$teltonikaTimeStamp;
				$costDg=$sensMasDet["dg_unit_rate"];
				$consuptionDgKWH=$endDgKWH-$startDgKWH;
				$consuptionDgCost=$consuptionDgKWH*$costDg;
					
					
		
			 $insQueryCron="INSERT INTO cron_daily_energy_data (company_id, branch_id, gateway_code, sensor_code, feeder_type, start_cum_kwh, start_cum_date, end_cum_kwh, end_cum_date, consuption_kwh, cost, consuption_cost, recorded_date, dg_start_cum_kwh, dg_start_cum_date, dg_end_cum_kwh, dg_end_cum_date, dg_consuption_kwh, dg_cost, dg_consuption_cost, posted_date_time, created_by) VALUES('".$sensMasDet["company_id"]."','".$sensMasDet["branch_id"]."','".$sensMasDet["gateway_id"]."','".$sensorCode."','".$sensMasDet["feeder_type"]."','".$startKWH."','".$startDate."','".$endKWH."','".$endDate."','".$consuptionKWH."','".$cost."','".$consuptionCost."','".$currDate."','".$startDgKWH."','".$startDgDate."','".$endDgKWH."','".$endDgDate."','".$consuptionDgKWH."','".$costDg."','".$consuptionDgCost."',NOW(),'Cron') ";
			
			$conn->query($insQueryCron);
		}
		
		//exit;
		
		/****************     Cron Data Post            **********************/
		
		/****************     Cron Hourly Data Post            **********************/

		if($hour==0){
			$prevHour=23;
			$lastHourDate=$currDate;
		}else{
			$prevHour=$hour-1;
			$lastHourDate=$currDate;
		}
			$currHour=$hour;
		
		//echo $currDate."Curr Date <br>";
		//echo $prevDate."Prvi Date <br>";
		/******** Current Date Start *********/
		
		echo $selCronDataHr="SELECT * FROM `cron_hourly_energy_data` WHERE sensor_code='".$sensorCode."' AND recorded_date='".$currDate."' AND hour_data='".$currHour."'"; 
		$exeCronSelHr = mysqli_query($conn, $selCronDataHr);
		$cronDataFetHr = mysqli_fetch_assoc($exeCronSelHr);
		$cronDataCountHr = mysqli_num_rows($exeCronSelHr);
		mysql_free_result($exeCronSelHr);
		
		/******** Current Date End *********/

		/******** Previuos Date Start *********/
		
		$selCronDataYesHr="SELECT * FROM `cron_hourly_energy_data` WHERE sensor_code='".$sensorCode."' AND recorded_date='".$lastHourDate."' AND hour_data='".$prevHour."'";
		$exeCronSelYesHr = mysqli_query($conn, $selCronDataYesHr);
		$cronDataFetYesHr = mysqli_fetch_assoc($exeCronSelYesHr);
		$cronDataCountYesHr = mysqli_num_rows($exeCronSelYesHr);
		mysql_free_result($exeCronSelYesHr);

		
		/******** Previuos Date End *********/
		
		if($cronDataCountHr>0){
		
			/**************** EB Condition *****************/

			if($cronDataFetHr["start_cum_kwh"]>0){
				if($cronDataCountYesHr>0 && $cronDataFetYesHr["end_cum_date"]>0){
					//echo "<br> if";
					$startKWHHr=$cronDataFetYesHr["end_cum_kwh"];
					$startDateHr=$cronDataFetYesHr["end_cum_date"];

				}else{
					$startKWHHr=$cronDataFetHr["start_cum_kwh"];
					$startDateHr=$cronDataFetHr["start_cum_date"];
					//echo "<br> else<br>";
				}
				$updateSetValHr='';
			}
			else{
				if($cronDataCountYesHr>0 && $cronDataFetYesHr["end_cum_date"]>0){
					$startKWHHr=$cronDataFetYesHr["end_cum_kwh"];
					$startDateHr=$cronDataFetYesHr["end_cum_date"];
					//echo "<br> START KWH >".$startKWH."<br>else> if";
				}else{
					$startKWHHr=$KWH;
					$startDateHr=$teltonikaTimeStamp;
					//echo "<br>else> else";
				}
				$updateSetVal='start_cum_kwh="'.$startKWHHr.'", `start_cum_date`="'.$startDateHr.'", ';
				//echo $KWH."<br>start: ".$startKWH;

			}
			$endKWHHr=$KWH;
			$endDateHr=$teltonikaTimeStamp;
			$costHr=$sensMasDet["unit_rate"];

			$consuptionKWHHr=$endKWHHr-$startKWHHr;
			if($startKWHHr > $endKWHHr){
				$selSensorMasterMaxKwhHrQry = 'SELECT * FROM `sensor_model_master` WHERE model_id = "'.$sensorModel.'" AND status = "1"';  
				$ExeSensorMasterMaxKwhHrQry = mysqli_query($conn, $selSensorMasterMaxKwhHrQry);
				$rsltSensorMasterMaxKwhHr = mysqli_fetch_assoc($ExeSensorMasterMaxKwhHrQry);
				$max_kwm_in_meter_Hr = $rsltSensorMasterMaxKwhHr['max_kwh'];
				$consuptionKWHHr = ($max_kwm_in_meter_Hr - $startKWHHr)+$endKWHHr;

			}
			//$consuptionKWHHr=$endKWHHr-$startKWHHr;
			$consuptionCostHr=$consuptionKWHHr*$costHr;
			
			/**************** DG Condition *****************/
			
			if($cronDataFetHr["dg_start_cum_kwh"]>0){
				if($cronDataCountYesHr>0 && $cronDataFetYesHr["dg_end_cum_date"]>0){
					//echo "<br> if";
					$startDgKWHHr=$cronDataFetYesHr["dg_end_cum_kwh"];
					$startDgDateHr=$cronDataFetYesHr["dg_end_cum_date"];

				}else{
					$startDgKWHHr=$cronDataFetHr["dg_start_cum_kwh"];
					$startDgDateHr=$cronDataFetHr["dg_start_cum_date"];
					//echo "<br> else<br>";
				}
				$updateDgSetValHr='';
			}
			else{
				if($cronDataCountYesHr>0 && $cronDataFetYesHr["dg_end_cum_date"]>0){
					$startDgKWHHr=$cronDataFetYesHr["dg_end_cum_kwh"];
					$startDgDateHr=$cronDataFetYesHr["dg_end_cum_date"];
					//echo "<br> START KWH >".$startKWH."<br>else> if";
				}else{
					$startDgKWHHr=$DG_KWH;
					$startDgDateHr=$teltonikaTimeStamp;
					//echo "<br>else> else";
				}
				$updateDgSetValHr=' dg_start_cum_kwh="'.$startDgKWHHr.'", `dg_start_cum_date`="'.$startDgDateHr.'", ';
				//echo $KWH."<br>start: ".$startKWH;

			}
			//echo $KWH."<br>start: ".$startKWH;

						
			$endDgKWHHr=$DG_KWH;
			$endDgDateHr=$teltonikaTimeStamp;
			$costDgHr=$sensMasDet["dg_unit_rate"];
			$consuptionDgKWHHr=$endDgKWHHr-$startDgKWHHr;
			$consuptionDgCostHr=$consuptionDgKWHHr*$costDgHr;

		echo	$UpdateCronQryHr='UPDATE `cron_hourly_energy_data` SET '.$updateSetValHr.' `feeder_type`="'.$sensMasDet["feeder_type"].'", `end_cum_kwh`="'.$endKWHHr.'",`end_cum_date`="'.$endDateHr.'", `consuption_kwh`="'.$consuptionKWHHr.'", `cost`="'.$sensMasDet["unit_rate"].'", `consuption_cost`="'.$consuptionCostHr.'", dg_end_cum_kwh="'.$endDgKWHHr.'",`dg_end_cum_date`="'.$endDgDateHr.'", dg_consuption_kwh="'.$consuptionDgKWHHr.'", dg_cost="'.$sensMasDet["dg_unit_rate"].'", dg_consuption_cost="'.$consuptionDgCostHr.'",`posted_date_time`=NOW(),'.$updateDgSetValHr.' `created_by`="API" WHERE `company_id`="'.$sensMasDet["company_id"].'" AND `branch_id`="'.$sensMasDet["branch_id"].'" AND `gateway_code`="'.$sensMasDet["gateway_id"].'" AND sensor_code="'.$sensorCode.'" AND `recorded_date`="'.$currDate.'" AND hour_data="'.$currHour.'"';   

			$conn->query($UpdateCronQryHr);
		
		
		}else{
				/***************   EB Condition Starts     ***********************/
				if($cronDataCountYesHr>0 && $cronDataFetYesHr["end_cum_date"] >0){
					$startKWHHr=$cronDataFetYesHr["end_cum_kwh"];
					$startDateHr=$cronDataFetYesHr["end_cum_date"];

				}else{
					$startKWHHr=$KWH;
					$startDateHr=$teltonikaTimeStamp;

				}
				$endKWHHr=$KWH;
				$endDateHr=$teltonikaTimeStamp;
				$costHr=$sensMasDet["unit_rate"];
				$consuptionKWHHr=$endKWHHr-$startKWHHr;
				$consuptionCostHr=$consuptionKWHHr*$costHr;

				/***************   DG Condition Starts     ***********************/

				if($cronDataCountYesHr>0 && $cronDataFetYesHr["dg_end_cum_date"] >0){
					$startDgKWHHr=$cronDataFetYesHr["dg_end_cum_kwh"];
					$startDgDateHr=$cronDataFetYesHr["dg_end_cum_date"];

				}else{
					$startDgKWHHr=$DG_KWHHr;
					$startDgDateHr=$teltonikaTimeStamp;

				}
				$endDgKWHHr=$DG_KWHHr;
				$endDgDateHr=$teltonikaTimeStamp;
				$costDgHr=$sensMasDet["dg_unit_rate"];
				$consuptionDgKWHHr=$endDgKWHHr-$startDgKWHHr;
				$consuptionDgCostHr=$consuptionDgKWHHr*$costDgHr;
					
					
		
			echo $insQueryCronHr="INSERT INTO cron_hourly_energy_data (company_id, branch_id, gateway_code, sensor_code, feeder_type, start_cum_kwh, start_cum_date, end_cum_kwh, end_cum_date, consuption_kwh, cost, consuption_cost, recorded_date, hour_data, dg_start_cum_kwh, dg_start_cum_date, dg_end_cum_kwh, dg_end_cum_date, dg_consuption_kwh, dg_cost, dg_consuption_cost, posted_date_time, created_by) VALUES('".$sensMasDet["company_id"]."','".$sensMasDet["branch_id"]."','".$sensMasDet["gateway_id"]."','".$sensorCode."','".$sensMasDet["feeder_type"]."','".$startKWHHr."','".$startDateHr."','".$endKWHHr."','".$endDateHr."','".$consuptionKWHHr."','".$costHr."','".$consuptionCostHr."','".$currDate."','".$currHour."','".$startDgKWHHr."','".$startDgDateHr."','".$endDgKWHHr."','".$endDgDateHr."','".$consuptionDgKWHHr."','".$costDgHr."','".$consuptionDgCostHr."',NOW(),'Cron') ";
			
			$conn->query($insQueryCronHr);
		}
		
		//exit;
		
		/****************     Cron Hourly Data Post            **********************/
		/****************    Only For Overall Main Meter Cron Slot Wise Data            **********************/
		
	/**********************  Slot Wise only for Overall Main Meter ************************/	
		/*******************************************             Mail Trigger  Starts            ****************************************************/
	   $selAlertCont= "SELECT email FROM `arka_alert_contact_master` WHERE email_alert=1 AND is_active=1 AND `company_id`='".$sensMasDet['company_id']."' AND `branch_id`='".$sensMasDet['branch_id']."'";
       $ExeAlertCont = mysqli_query($conn, $selAlertCont);
	   if (mysqli_num_rows($ExeAlertCont) > 0) 
	   {
			 $alertContact='';
			 while($alertCont = mysqli_fetch_assoc($ExeAlertCont)) 
			{
			// Fetch all
			   $alertContact .= $alertCont['email'].",";
			}
		//	$string = rtrim($string, ".");
			$alertEmail= rtrim($alertContact, ",");
			echo $alertEmail." -- EmailId from Table <br>";
       } 
	   
	echo   $selAlertPar= "SELECT * FROM `alert_parameter_mapping` WHERE `sensor_code`='".$sensorCode."'";
       $ExeAlertPar = mysqli_query($conn, $selAlertPar);
	   
	   if (mysqli_num_rows($ExeAlertPar) > 0) 
	   {
	      echo "alert parameter Mapping";
            while($parameter = mysqli_fetch_assoc($ExeAlertPar)) 
			{ 
			 echo $parameter['parameter_name']."-  Parameter Name <br>";
			  echo $parameter['mail_alert_status'];
				$parameterName=$parameter['parameter_name'];
				if($parameter['mail_alert_status']=="Normal")
				{
              echo $selectEnergy= "SELECT ".$parameterName." FROM `energy_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND (".$parameterName." <= '".$parameter['min_alert_value']."' OR ".$parameterName." >= '".$parameter['max_alert_value']."')";
			  $ExeEnergy = mysqli_query($conn, $selectEnergy);
	           $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
				  if($ReadingValue > $parameter['max_alert_value']){
				  $alertStatus='High';
				  $alertValueName='Max Value Reached';
				  }
				  elseif($ReadingValue < $parameter['min_alert_value']){
				  $alertStatus='Low';
				  $alertValueName='Min Value Reached';
				  }
			  }else if($parameter['mail_alert_status']=="High"){
			  $selectEnergy= "SELECT ".$parameterName." FROM `energy_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND (".$parameterName." > '".$parameter['min_alert_value']."' AND ".$parameterName." < '".$parameter['max_alert_value']."')";
			  $ExeEnergy = mysqli_query($conn, $selectEnergy);
			  if (mysqli_num_rows($ExeEnergy) == 0) 
				{
				 $selectEnergy= "SELECT ".$parameterName." FROM `energy_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND ".$parameterName." <= '".$parameter['min_alert_value']."'";
			   $ExeEnergy = mysqli_query($conn, $selectEnergy);
	           $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='Low';
			   $alertValueName='Min Value Reached';
			   
			   }
			   else{
			   
			   $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='Normal';
			   $alertValueName='Normal Value Reached';
			   
			   }
			  }
			  else if($parameter['mail_alert_status']=="Low" ){
			  $selectEnergy= "SELECT ".$parameterName." FROM `energy_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND (".$parameterName." > '".$parameter['min_alert_value']."' AND ".$parameterName." < '".$parameter['max_alert_value']."')";
			  $ExeEnergy = mysqli_query($conn, $selectEnergy);
	          if (mysqli_num_rows($ExeEnergy) == 0) 
				{
				 $selectEnergy= "SELECT ".$parameterName." FROM `energy_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND ".$parameterName." >= '".$parameter['max_alert_value']."'";
			   $ExeEnergy = mysqli_query($conn, $selectEnergy);
	           $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='High';
			   $alertValueName='Max Value Reached';
			   
			   }
			   else{
			   
			   $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='Normal';
			   $alertValueName='Normal Value Reached';
			   
			   }
			  }
			  
			 /* $message .= "Hi!<br><br><br>
	
								<b>Feeder Name</b>      : ".$parameter['feeder_name'].",<br>
								<b>Parameter Name</b>   : ".$parameter['parameter_name'].",<br>
								<b>".$alertValueName."</b>  : ".$ReadingValue.".<br><br><br><br><br>
	
	
								
                                <b>Best regards</b>,<br>
                                <b>Arka Automaations Limited.</b><br>
								";
								
				  $contentData=strip_tags($message);
								
			 $insAlertLog	="INSERT INTO `alert_log_master`(`company_id`, `branch_id`, `sensor_code`, `alert_type`, `parameter_name`, `alert_message`, `send_to`, `alert_status`, `recorded_date_time`, `posted_date_time`) VALUES ('".$sensMasDet['company_id']."','".$sensMasDet['branch_id']."','".$sensorCode."','Mail','".$parameter['parameter_name']."','".$contentData."','".$alertEmail."','".$alertStatus."','".$teltonikaTimeStamp."',DATE_ADD(NOW(),INTERVAL '00:00' HOUR_MINUTE))";		
			 $insLog = $conn->query($insAlertLog);*/
			  
			//echo   $alertStatus." --alert Status <br>".$alertValueName." --alert Value <br>".mysqli_num_rows($ExeEnergy);
			   
			    if (mysqli_num_rows($ExeEnergy) > 0) 
				{
				
			    echo $updateAlertPar= "UPDATE `alert_parameter_mapping` SET mail_alert_status='".$alertStatus."'  WHERE `alert_parameter_id`='".$parameter['alert_parameter_id']."'";
       			 $ExeAlertPar = mysqli_query($conn, $updateAlertPar);
				     echo $ReadingValue."-  Reading Value <br>";
				     echo $alertEmail."-  MailId <br>"; 
				     
			  $selectSensor= "SELECT * FROM `arka_sensor_master` WHERE `sensorCode`='".$parameter['sensor_code']."' AND status='1' AND isActive='1'";
			  $ExeSensor = mysqli_query($conn, $selectSensor);
	          $ExeSensorArr = mysqli_fetch_assoc($ExeSensor);
			  $sensorNameVal = $ExeSensorArr['sensorName'];


$message = '';

				   $message .= "EMS - Alert Message!<br><br><br>
	
								<b>Energy Meter Name</b>      : ".$parameter['feeder_name'].",<br>
								<b>Parameter Name</b>   : ".$parameter['parameter_name'].",<br>
								<b>".$alertValueName."</b>  : ".$ReadingValue.".<br><br><br><br><br>
	
	
								
                                <br>
								";
								
				  $contentData=strip_tags($message);
								
							
			 $insAlertLog	="INSERT INTO `alert_log_master`(`company_id`, `branch_id`, `sensor_code`, `alert_type`, `parameter_name`, `alert_message`, `send_to`, `alert_status`, `recorded_date_time`, `posted_date_time`) VALUES ('".$sensMasDet['company_id']."','".$sensMasDet['branch_id']."','".$sensorCode."','Mail','".$parameter['parameter_name']."','".$contentData."','".$alertEmail."','".$alertStatus."','".$teltonikaTimeStamp."',DATE_ADD(NOW(),INTERVAL '00:00' HOUR_MINUTE))";		
			 $insLog = $conn->query($insAlertLog);
     
        
        if ($insLog === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $insAlertLog . "<br>" . $conn->error;
        }
            	    



				 	
			 }
			   
            }
       } 
	   

//mail("vishalchandran11@gmail.com", "Test Mail", "Test");
	mysqli_free_result($ExeSensor);
	mysqli_free_result($ExeEnergy);
	mysqli_free_result($ExeAlertPar);
	mysqli_free_result($ExeAlertCont);
	mysqli_free_result($resultView);
	mysqli_free_result($result);
	
		/*******************************************             Mail Trigger   End          ****************************************************/
        $conn->close();
    
 }
    else {
        echo "Wrong API Key provided.";
    }

}
else {
    echo "No data posted with HTTP POST.";
}


function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>
