<?php

/*
  Rui Santos
  Complete project details at https://RandomNerdTutorials.com/esp32-esp8266-mysql-database-php/
  
  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files.
  
  The above copyright notice and this permission notice shall be included in all
  copies or substantial portions of the Software.
*/

//namespace PortoContactForm;

session_cache_limiter('nocache');
header('Expires: ' . gmdate('r', 0));

header('Content-type: application/json');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'php/php-mailer/src/PHPMailer.php';
require 'php/php-mailer/src/SMTP.php';
require 'php/php-mailer/src/Exception.php';


require_once('../Connections/ARKAEMS.php'); 
$servername = $hostname_arkaems;

// REPLACE with your Database name
$dbname = $database_arkaems;
// REPLACE with Database user
$username = $username_arkaems;
// REPLACE with Database user password
$password = $password_arkaems;

/*$servername = "166.62.10.227";

// REPLACE with your Database name
$dbname = "emslte";
// REPLACE with Database user
$username = "emslte";
// REPLACE with Database user password
$password = "emslte@2020";*/
 
//exit;


// Keep this API Key value to be compatible with the ESP32 code provided in the project page. 
// If you change this value, the ESP32 sketch needs to match

//echo "hai"; exit;
   if ($_SERVER["REQUEST_METHOD"] == "POST") {
         $inputJSON = file_get_contents('php://input');
         $input= json_decode( $inputJSON, true); 
 // $api_key = test_input($_POST["api_key"]);
     $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } 
   $sqlSensor = "SELECT * FROM arka_sensor_master WHERE isActive='1' AND status='1' AND api_key='".$input[0]['apiKey']."'"; 
    $insSel = $conn->query($sqlSensor);
	
     $result = mysqli_query($conn, $sqlSensor);
	 $sensMasDet = mysqli_fetch_assoc($result);
	 

       
      

       
  if (mysqli_num_rows($result) > 0) {
          
       
        
         // Create connection
		   $apikeyDecd= base64_decode($input[0]['apiKey']);
	 
	  $apiDec =explode("/", $apikeyDecd);
	   $gatewayCode=str_replace("GW:","",$apiDec[0]);
	   $sensorCode=str_replace("SI:","",$apiDec[1]);
	   $sensorModel=str_replace("SMODEL:","",$apiDec[2]);
	   

           $jsonDecd= str_replace(array('[', ',]', ']'), '', $input[0]['VR']);
           $str_arr= explode (",", $jsonDecd); 
		  
          // echo $input[0]['VR']."<br>"; print_r($str_arr); 
           if($sensorModel =='ICD1'){
              //  echo $str_arr[0]."<br>".$str_arr[1]."<br>".$str_arr[2]."<br>".$str_arr[3]."<br>".$str_arr[4]."<br>".$str_arr[5]."<br>".$str_arr[6]."<br>".$str_arr[7]."<br>".$str_arr[8]."<br>".$str_arr[9]."<br>".$str_arr[10]."<br>".$str_arr[11]."<br>";
           /********************   ICD Meter 1 Phase variables   *********************/
           $kWatts= $str_arr[0]/10; //date post in database
           $kwh_msb=$str_arr[1]; //date post in database
           $kwh_lsb=$str_arr[2]-100;  //date post in database
           $type_24_run_hour=$str_arr[3];  //Date Just display Here Not inserted
           $run_hour=$str_arr[4]/100; //date post in database
           $fault_tamper=$str_arr[5];  //Date Just display Here Not inserted
           $pf=$str_arr[6]/100; //date post in database
          $voltage=$str_arr[7]/10; //date post in database
           $line_current=$str_arr[8]/1000; //date post in database
           $neutral_current=$str_arr[9]/1000;  //Date Just display Here Not inserted
           $line_watt=$str_arr[10]/1000;   //Date Just display Here Not inserted
           $neutral_watt=$str_arr[11]/1000;  //Date Just display Here Not inserted
           
           $R_VOLTAGE=$voltage;
           $Y_VOLTAGE='';
           $B_VOLTAGE='';
		   $RY_VOLTAGE='';
		   $YB_VOLTAGE='';
		   $BR_VOLTAGE='';
		   $R_CURRENT=$line_current;
		   $Y_CURRENT='';
		   $B_CURRENT='';
		   $SUM_KVA='';
		   $SUM_KW=$kWatts;
		   $SUM_KVAR='';
		   $SUM_PF=$pf;
		   $FREQUENCY=''; 
		   $KWH_MSB=$kwh_msb;
		   $KWH_LSB=$kwh_lsb;
		   $KWH=$kwh_lsb/100;
		   $METER_TYPE_RUN_HOUR_MSB=$type_24_run_hour;
		   $RUN_HOUR_LSB='';
		   $RUN_HOUR=$run_hour;
		   $IMPORT_EXPORT='';
		   $DG_KWH='';
		   $DG_KVAH='';
		   $DG_Run_Hour='';
		   $DG_Run_Min='';
		   $EB_DG_Status='EB';
           
		  /*  echo"<br>VoltageR:".$R_VOLTAGE;
			echo"<br>Line Current :".$R_VOLTAGE;
			echo"<br>KWH :".$SUM_KW;
			echo"<br>KWH_MSB :".$KWH_MSB;
			echo"<br>KWH_LSB :".$KWH_LSB;
			echo"<br>METER_TYPE_RUN_HOUR_MSB :".$METER_TYPE_RUN_HOUR_MSB;*/
			
			
		  if(isset($input[0]['VR'])){
		       $VR_ARRAY_VALUE=$input[0]['VR'];
		   }
		   else
		   {
		       $VR_ARRAY_VALUE=''; 
		   }

          }
           elseif($sensorModel =='ICD3'){
           /********************   ICD Meter 3 Phase variables   *********************/
           
           
           $R_VOLTAGE=$str_arr[0]/10;  //date post in database
           $Y_VOLTAGE=$str_arr[1]/10; //date post in database  
           $B_VOLTAGE=$str_arr[2]/10; //date post in database
		   $RY_VOLTAGE=$str_arr[3]/10; //date post in database
		   $YB_VOLTAGE=$str_arr[4]/10; //date post in database
		   $BR_VOLTAGE=$str_arr[5]/10; //date post in database
		   $R_CURRENT=$str_arr[6]/10; //date post in database
		   $Y_CURRENT=$str_arr[7]/10; //date post in database
		   $B_CURRENT=$str_arr[8]/10; //date post in database
		   $SUM_KVA=$str_arr[9]/10; //date post in database
		   $SUM_KW=$str_arr[10]/10; //date post in database
		   $SUM_KVAR=$str_arr[11]/10; //date post in database
		   $SUM_PF=$str_arr[12]/1000; //date post in database
		   $FREQUENCY=$str_arr[13]/100;  //date post in database
		   $KWH_MSB=$str_arr[14]/10; //date post in database
		   $KWH_LSB=$str_arr[15]/10; //date post in database
		   $KWH=($KWH_MSB * 65536) + $KWH_LSB;  //date post in database
		   $METER_TYPE_RUN_HOUR_MSB=$str_arr[16];  //date post in database
		   $RUN_HOUR_LSB=$str_arr[17]; //date post in database
		   $RUN_HOUR=($METER_TYPE_RUN_HOUR_MSB * 65536) + $RUN_HOUR_LSB; //date post in database
		   $IMPORT_EXPORT=$str_arr[18]; //date post in database
		   $DG_KWH='';
		   $DG_KVAH='';
		   $DG_Run_Hour='';
		   $DG_Run_Min='';
		   $EB_DG_Status='EB';
           
		   if(isset($input[0]['VR'])){
		       $VR_ARRAY_VALUE=$input[0]['VR']; //date post in database this data from telonika VR parameter in json data
		   }
		   else
		   {
		       $VR_ARRAY_VALUE=''; 
		   }

           }
            elseif($sensorModel =='LMS3'){
           /********************   Elmeasure 3 Phase variables   *********************/
		   
           $watts_total=$str_arr[0]/1000;  //date post in database with calculated data from watts to kilo watts
           $watts_r_phase=$str_arr[1]/1000;  //Date Just display Here Not inserted
           $watts_y_phase=$str_arr[2]/1000;  //Date Just display Here Not inserted
           $watts_b_phase=$str_arr[3]/1000;  //Date Just display Here Not inserted
           $var_total=$str_arr[4]/1000;  //date post in database with calculated data from watts to kilo watts
           $var_r_phase=$str_arr[5]/1000;  //Date Just display Here Not inserted
           $var_y_phase=$str_arr[6]/1000;  //Date Just display Here Not inserted
           $var_b_phase=$str_arr[7]/1000;  //Date Just display Here Not inserted
           $pf_avg_inst=$str_arr[8];  //date post in database 
           $pf_r_phase=$str_arr[9];  //Date Just display Here Not inserted
           $pf_y_phase=$str_arr[10];  //Date Just display Here Not inserted
           $pf_b_phase=$str_arr[11];  //Date Just display Here Not inserted
           $va_total=$str_arr[12]/1000;  //date post in database with calculated data from watts to kilo watts
           $va_r_phase=$str_arr[13]/1000;  //Date Just display Here Not inserted
           $va_y_phase=$str_arr[14]/1000;  //Date Just display Here Not inserted
           $va_b_phase=$str_arr[15]/1000;  //Date Just display Here Not inserted
           $vll_average=$str_arr[16];  //Date Just display Here Not inserted
           $vry_phase=$str_arr[17];  //date post in database
           $vyb_phase=$str_arr[18];  //date post in database
           $vbr_phase=$str_arr[19];  //date post in database
           $vln_average=$str_arr[20];  //Date Just display Here Not inserted
           $v_r_phase=$str_arr[21];  //date post in database
           $v_y_phase=$str_arr[22];  //date post in database
           $v_b_phase=$str_arr[23];  //date post in database
           $current_total=$str_arr[24];  //date post in database
           $current_r_phase=$str_arr[25];  //Date Just display Here Not inserted
           $current_y_phase=$str_arr[26];  //Date Just display Here Not inserted
           $current_b_phase=$str_arr[27];  //Date Just display Here Not inserted
           $frequency=$str_arr[28];  //date post in database
           $wh_received=$str_arr[29]/1000;  //date post in database with calculated data from watts to kilo watts
           $load_hour_received=$str_arr[30];  //date post in database
           
           $R_VOLTAGE=$v_r_phase;
           $Y_VOLTAGE=$v_y_phase;
           $B_VOLTAGE=$v_b_phase;
		   $RY_VOLTAGE=$vry_phase;
		   $YB_VOLTAGE=$vyb_phase;
		   $BR_VOLTAGE=$vbr_phase;
		   $R_CURRENT=$current_r_phase;
		   $Y_CURRENT=$current_y_phase;
		   $B_CURRENT=$current_b_phase;
		   $SUM_KVA=$va_total;
		   $SUM_KW=$watts_total;
		   $SUM_KVAR=$var_total;
		   $SUM_PF=$pf_avg_inst;
		   $FREQUENCY=$frequency; 
		   $KWH_MSB='';
		   $KWH_LSB='';
		   $KWH=$wh_received;
		   $METER_TYPE_RUN_HOUR_MSB='';
		   $RUN_HOUR_LSB='';
		   $RUN_HOUR=$load_hour_received;
		   $IMPORT_EXPORT='';
		   $DG_KWH='';
		   $DG_KVAH='';
		   $DG_Run_Hour='';
		   $DG_Run_Min='';
		   $EB_DG_Status='EB';
           
		   if(isset($input[0]['VR'])){
		       $VR_ARRAY_VALUE=$input[0]['VR'];
		   }
		   else
		   {
		       $VR_ARRAY_VALUE=''; 
		   }

           }
           elseif($sensorModel =='T3DS'){
		   
           /********************   Elmeasure 3 Phase variables   *********************/
		   
           $KW=$str_arr[0]/100;  //date post in database with calculated data from watts to kilo watts
           $Sys_PF=$str_arr[1]/1000;  //Date Just display Here Not inserted
           $Avg_VLL=$str_arr[2]/100;  //Date Just display Here Not inserted
           $Avg_VLN=$str_arr[3]/100;  //Date Just display Here Not inserted
           $Avg_Amps=$str_arr[4]/100;  //date post in database with calculated data from watts to kilo watts
           $EB_KWh=$str_arr[5]/100;  //Date Just display Here Not inserted
           $Hz=$str_arr[6]/100;  //Date Just display Here Not inserted
           $VRY=$str_arr[7]/100;  //Date Just display Here Not inserted
           $VYB=$str_arr[8]/100;  //date post in database 
           $VBR=$str_arr[9]/100;  //Date Just display Here Not inserted
		   $VRN=$str_arr[10]/100;  //Date Just display Here Not inserted
           $VYN=$str_arr[11]/100;  //Date Just display Here Not inserted
           $VBN=$str_arr[12]/100;  //Date Just display Here Not inserted
           $IR=$str_arr[13]/100;  //date post in database with calculated data from watts to kilo watts
           $IY=$str_arr[14]/100;  //Date Just display Here Not inserted
           $IB=$str_arr[15]/100;  //Date Just display Here Not inserted
           $DG_KWH=$str_arr[16]/100;  //Date Just display Here Not inserted
           $On_Hour=$str_arr[17]/1;  //Date Just display Here Not inserted
           $On_Min=$str_arr[18]/1;  //date post in database
           $KVA=$str_arr[19]/100;  //date post in database
           $EB_KVAH=$str_arr[20]/100;  //date post in database
           $EB_Run_Hour=$str_arr[21]/1;  //Date Just display Here Not inserted
           $EB_Run_Min=$str_arr[22]/1;  //date post in database
           $DG_KVAH=$str_arr[23]/100;  //date post in database
           $DG_Run_Hour=$str_arr[24]/1;  //date post in database
           $DG_Run_Min=$str_arr[25]/1;  //date post in database
           $EB_DG_STATUS=$str_arr[26];  //Date Just display Here Not inserted
		   if($EB_DG_STATUS==2)
		   {
		   $EB_DG_STATUS="EB";
		   
		   }else
		   {
		   $EB_DG_STATUS="DG";
		   }
           
           $R_VOLTAGE=$VRN;
           $Y_VOLTAGE=$VYN;
           $B_VOLTAGE=$VRN;
		   $RY_VOLTAGE=$VRY;
		   $YB_VOLTAGE=$VYB;
		   $BR_VOLTAGE=$VBR;
		   $R_CURRENT=$IR;
		   $Y_CURRENT=$IY;
		   $B_CURRENT=$IB;
		   $SUM_KVA=$KVA;
		   $SUM_KW=$KW;
		   $SUM_KVAR='';
		   $SUM_PF=$Sys_PF;
		   $FREQUENCY=''; 
		   $KWH_MSB='';
		   $KWH_LSB='';
		   $KWH=$EB_KWh;
		   $METER_TYPE_RUN_HOUR_MSB='';
		   $RUN_HOUR_LSB='';
		   $RUN_HOUR=$On_Hour;
		   $IMPORT_EXPORT='';
		   $DG_KWH=$DG_KWH;
		   $DG_KVAH=$DG_KVAH;
		   $DG_Run_Hour=$DG_Run_Hour;
		   $DG_Run_Min=$DG_Run_Min;
		   $EB_DG_Status=$EB_DG_STATUS;
           
		   if(isset($input[0]['VR'])){
		       $VR_ARRAY_VALUE=$input[0]['VR'];
		   }
		   else
		   {
		       $VR_ARRAY_VALUE=''; 
		   }

           
		   
		   }elseif($sensorModel =='TE'){
		   
           /********************   Trinity Entity  variables   *********************/
		   //$KW=$str_arr[0]/100;
           $KW=$str_arr[0]/100;  //date post in database with calculated data from watts to kilo watts
		   
		   
           $R_VOLTAGE='';
           $Y_VOLTAGE='';
           $B_VOLTAGE='';
		   $RY_VOLTAGE='';
		   $YB_VOLTAGE='';
		   $BR_VOLTAGE='';
		   $R_CURRENT='';
		   $Y_CURRENT='';
		   $B_CURRENT='';
		   $SUM_KVA='';
		   $SUM_KW='';
		   $SUM_KVAR='';
		   $SUM_PF='';
		   $FREQUENCY=''; 
		   $KWH_MSB='';
		   $KWH_LSB='';
		   $KWH=$KW;
		   $METER_TYPE_RUN_HOUR_MSB='';
		   $RUN_HOUR_LSB='';
		   $RUN_HOUR='';
		   $IMPORT_EXPORT='';
		   $DG_KWH='';
		   $DG_KVAH='';
		   $DG_Run_Hour='';
		   $DG_Run_Min='';
		   $EB_DG_Status='';
           
		   if(isset($input[0]['VR'])){
		       $VR_ARRAY_VALUE=$input[0]['VR'];
		   }
		   else
		   {
		       $VR_ARRAY_VALUE=''; 
		   }

           
		   
		   }elseif($sensorModel =='TPP'){
		   
           /********************   Trinity Power Pro   *********************/
		   
           $System_KVA=$str_arr[0]/100;  //date post in database with calculated data from watts to kilo watts
           $System_KW=$str_arr[1]/100;  //Date Just display Here Not inserted
           $System_KVAR=$str_arr[2]/100;  //Date Just display Here Not inserted
           $System_PF=$str_arr[3]/1000;  //Date Just display Here Not inserted
           $Avg_Vpp=$str_arr[4]/100;  //date post in database with calculated data from watts to kilo watts
           $Avg_Vpn=$str_arr[5]/100;  //Date Just display Here Not inserted
           $Avg_I=$str_arr[6]/100;  //Date Just display Here Not inserted
           $EB_KWh=$str_arr[7]/100;  //Date Just display Here Not inserted
           $EB_KVAh=$str_arr[8]/100;  //date post in database 
           $EB_KVARh=$str_arr[9]/100;  //Date Just display Here Not inserted
		   $Frequency=$str_arr[10]/100;  //Date Just display Here Not inserted
           $Vry=$str_arr[11]/100;  //Date Just display Here Not inserted
           $Vyb=$str_arr[12]/100;  //Date Just display Here Not inserted
           $Vbr=$str_arr[13]/100;  //date post in database with calculated data from watts to kilo watts
           $Vrn=$str_arr[14]/100;  //Date Just display Here Not inserted
           $Vyn=$str_arr[15]/100;  //Date Just display Here Not inserted
           $Vbn=$str_arr[16]/100;  //Date Just display Here Not inserted
           $Ir=$str_arr[17]/100;  //Date Just display Here Not inserted
           $Iy=$str_arr[18]/100;  //date post in database
           $Ib=$str_arr[19]/100;  //date post in database
           $THD_Vr=$str_arr[20]/100;  //date post in database
           $THD_Vy=$str_arr[21]/100;  //Date Just display Here Not inserted
           $THD_Vb=$str_arr[22]/100;  //date post in database
           $THD_Ir=$str_arr[23]/100;  //date post in database
           $THD_Iy=$str_arr[24]/100;  //date post in database
           $THD_Ib=$str_arr[25]/100;  //date post in database
		   
           
           $R_VOLTAGE=$Vrn;
           $Y_VOLTAGE=$Vyn;
           $B_VOLTAGE=$Vbn;
		   $RY_VOLTAGE=$Vry;
		   $YB_VOLTAGE=$Vyb;
		   $BR_VOLTAGE=$Vbr;
		   $R_CURRENT=$Ir;
		   $Y_CURRENT=$Iy;
		   $B_CURRENT=$Ib;
		   $SUM_KVA=$System_KVA;
		   $SUM_KW=$System_KW;
		   $SUM_KVAR=$System_KVAR;
		   $SUM_PF=$System_PF;
		   $FREQUENCY=$Frequency; 
		   $KWH_MSB='';
		   $KWH_LSB='';
		   $KWH=$EB_KWh;
		   $METER_TYPE_RUN_HOUR_MSB='';
		   $RUN_HOUR_LSB='';
		   $RUN_HOUR=$On_Hour;
		   $IMPORT_EXPORT='';
		   $DG_KWH='';
		   $DG_KVAH='';
		   $DG_Run_Hour='';
		   $DG_Run_Min='';
		   $EB_DG_Status='';
           
		   if(isset($input[0]['VR'])){
		       $VR_ARRAY_VALUE=$input[0]['VR'];
		   }
		   else
		   {
		       $VR_ARRAY_VALUE=''; 
		   }

           
		   
		   }
		   elseif($sensorModel =='TEP'){
		   
           /********************   Trinity Expert Pro   *********************/
		   if($input[0]['ST']=="200")
		   {
		    	$firstArraySet=$input[0]['VR'];
		   }
		   elseif($input[1]['ST']=="200")
		   {
				$firstArraySet=$input[1]['VR'];
		   }
		   
		   $jsonDecd= str_replace(array('[', ',]', ']'), '', $firstArraySet);
           $str_arr= explode (",", $jsonDecd); 

		   
           $Vrn=$str_arr[0]/100;  //date post in database 
           $Vyn=$str_arr[1]/100;  //date post in database 
           $Vbn=$str_arr[2]/100;  //date post in database 
           $Avg_Vpn=$str_arr[3]/1000;  //date post in database 
           $Vry=$str_arr[4]/100;  //date post in database 
           $Vyb=$str_arr[5]/100;  //date post in database 
           $Vbr=$str_arr[6]/100;  //date post in database 
           $Avg_Vpp=$str_arr[7]/100;  //date post in database 
           $Ir=$str_arr[8]/100;  //date post in database 
           $Iy=$str_arr[9]/100;  //date post in database 
		   $Ib=$str_arr[10]/100;  //date post in database 
           $Avg_I=$str_arr[11]/100;  //date post in database 
           $Reserve=$str_arr[12];  // Dummy Field Name As Reserve
           $Reserve=$str_arr[13];  // Dummy Field Name As Reserve
           $Reserve=$str_arr[14];  // Dummy Field Name As Reserve
           $Frequency=$str_arr[15]/100;  //date post in database 
           $System_PF=$str_arr[16]/1000;  //date post in database 
           $PF_R=$str_arr[17]/1000;  //date post in database 
           $PF_Y=$str_arr[18]/1000;  //date post in database
           $PF_B=$str_arr[19]/1000;  //date post in database
           $System_KW=$str_arr[20]/100;  //date post in database
           $System_KVAR=$str_arr[21]/100;  //date post in database 
           $System_KVA=$str_arr[22]/100;  //date post in database
           $KW_R=$str_arr[23]/100;  //date post in database
           $KW_Y=$str_arr[24]/100;  //date post in database
           $KW_B=$str_arr[25]/100;  //date post in database
		   $KVAR_R=$str_arr[26]/100;  //date post in database
           $KVAR_Y=$str_arr[27]/100;  //date post in database
           $KVAR_B=$str_arr[28]/100;  //date post in database
		   $KVA_R=$str_arr[29]/100;  //date post in database
           $KVA_Y=$str_arr[30]/100;  //date post in database
           $KVA_B=$str_arr[31]/100;  //date post in database
		   $KW_Rising_Demand=$str_arr[32]/100;  //date post in database
		   $KW_Max_Demand=$str_arr[33]/100;  //date post in database
		   $KVA_Rising_Demand=$str_arr[34]/100;  //date post in database
		   $KVA_Max_Demand=$str_arr[35]/100;  //date post in database
		   $DG_KWh=$str_arr[36]/100;  //date post in database
		   $DG_KVARh=$str_arr[37]/100;  //date post in database
		   $EB_KWh=$str_arr[38]/100;  //date post in database
		   $EB_KVARh=$str_arr[39]/100;  //date post in database
		   $Reserve=$str_arr[40];  //Dummy Field Name As Reserve
		   $DG_KVAh=$str_arr[41]/100;  //date post in database
		   $EB_KVAh=$str_arr[42]/100;  //date post in database
		   $_3rd_HVr=$str_arr[43]/100;  //date post in database
		   $_5th_HVr=$str_arr[44]/100;  //date post in database
		   $_7th_HVr=$str_arr[45]/100;  //date post in database
		   $_9th_HVr=$str_arr[46]/100;  //date post in database
		   $_11th_HVr=$str_arr[47]/100;  //date post in database
		   $_13th_HVr=$str_arr[48]/100;  //date post in database
		   $_15th_HVr=$str_arr[49]/100;  //date post in database
		   
		   if($input[1]['ST']=="300")
		   {
		    	$secondArraySet=$input[1]['VR'];
		   }
		   elseif($input[0]['ST']=="300")
		   {
				$secondArraySet=$input[0]['VR'];
		   }
		   
		   $jsonDecd2= str_replace(array('[', ',]', ']'), '', $secondArraySet);
           $str_arr2= explode (",", $jsonDecd2); 
		   
		   $THD_Vr=$str_arr2[0]/100;  //date post in database
		   $_3rd_HIr=$str_arr2[1]/100;  //date post in database
		   $_5th_HIr=$str_arr2[2]/100;  //date post in database
		   $_7th_HIr=$str_arr2[3]/100;  //date post in database
		   $_9th_HIr=$str_arr2[4]/100;  //date post in database
		   $_11th_HIr=$str_arr2[5]/100;  //date post in database
		   $_13th_HIr=$str_arr2[6]/100;  //date post in database
		   $_15th_HIr=$str_arr2[7]/100;  //date post in database
		   $THD_Ir=$str_arr2[8]/100;  //date post in database
		   $_3rd_HVy=$str_arr2[9]/100;  //date post in database
		   $_5th_HVy=$str_arr2[10]/100;  //date post in database
		   $_7th_HVy=$str_arr2[11]/100;  //date post in database
		   $_9th_HVy=$str_arr2[12]/100;  //date post in database
		   $_11th_HVy=$str_arr2[13]/100;  //date post in database
		   $_13th_HVy=$str_arr2[14]/100;  //date post in database
		   $_15th_HVy=$str_arr2[15]/100;  //date post in database
		   $THD_Vy=$str_arr2[16]/100;  //date post in database
		   $_3rd_HIy=$str_arr2[17]/100;  //date post in database
		   $_5th_HIy=$str_arr2[18]/100;  //date post in database
		   $_7th_HIy=$str_arr2[19]/100;  //date post in database
		   $_9th_HIy=$str_arr2[20]/100;  //date post in database
		   $_11th_HIy=$str_arr2[21]/100;  //date post in database
		   $_13th_HIy=$str_arr2[22]/100;  //date post in database
		   $_15th_HIy=$str_arr2[23]/100;  //date post in database
		   $THD_Iy=$str_arr2[24]/100;  //date post in database
		   $_3rd_HVb=$str_arr2[25]/100;  //date post in database
		   $_5th_HVb=$str_arr2[26]/100;  //date post in database
		   $_7th_HVb=$str_arr2[27]/100;  //date post in database
		   $_9th_HVb=$str_arr2[28]/100;  //date post in database
		   $_11th_HVb=$str_arr2[29]/100;  //date post in database
		   $_13th_HVb=$str_arr2[30]/100;  //date post in database
		   $_15th_HVb=$str_arr2[31]/100;  //date post in database
		   $THD_Vb=$str_arr2[32]/100;  //date post in database
		   $_3rd_HIb=$str_arr2[33]/100;  //date post in database
		   $_5th_HIb=$str_arr2[34]/100;  //date post in database
		   $_7th_HIb=$str_arr2[35]/100;  //date post in database
		   $_9th_HIb=$str_arr2[36]/100;  //date post in database
		   $_11th_HIb=$str_arr2[37]/100;  //date post in database
		   $_13th_HIb=$str_arr2[38]/100;  //date post in database
		   $_15th_HIb=$str_arr2[39]/100;  //date post in database
		   $THD_Ib=$str_arr2[40]/100;  //date post in database
		   $DG_Status=$str_arr2[41]/100;  //date post in database

		   if(isset($input[0]['VR'])){
		       $VR_ARRAY_VALUE=$input[0]['VR'];
		   }
		   else
		   {
		       $VR_ARRAY_VALUE=''; 
		   }

           
		   
		   }
          // $temp_c=$str_arr[0];
          // $temp_f=$str_arr[1];
          // $hum=$str_arr[2];
          $liuxTimeStamp=$input[0]['TS'];
		 
          if($liuxTimeStamp !="XXXXXX")
          {
             
              $recordedTimeStamp = date("Y-m-d H:i:s",$input[0]['TS']);
              $telDate =$input[0]['DT'];
              $teltonika_date = str_replace('/', '-', $telDate);
              $teltonikaTimeStamp =  date('Y-m-d H:i:s', strtotime($teltonika_date));
             
          }
          else
          {
              $liuxTimeStamp='';
              $recordedTimeStamp = ''; 
			  $teltonikaTimeStamp='';
          
          }
           
    // $sql= "INSERT INTO `energy_data_master`(`gateway_code`, `sensor_code`, `sensor_model`,`R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`, `SUM_PF`, `FREQUENCY`, `KWH_MSB`, `KWH_LSB`, `KWH`, `METER_TYPE_RUN_HOUR_MSB`, `RUN_HOUR_LSB`, `RUN_HOUR`, `IMPORT_EXPORT`,`VR_ARRAY_VALUE`,`linux_date_time`,`teltonika_date_time`, `recorded_date_time`, `posted_date_time`) VALUES ('".$gatewayCode."','".$sensorCode."','".$sensorModel."','".$R_VOLTAGE."','".$Y_VOLTAGE."','".$B_VOLTAGE."','".$RY_VOLTAGE."','".$YB_VOLTAGE."','".$BR_VOLTAGE."','".$R_CURRENT."','".$Y_CURRENT."','".$B_CURRENT."','".$SUM_KVA."','".$SUM_KW."','".$SUM_KVAR."','".$SUM_PF."','".$FREQUENCY."','".$KWH_MSB."','".$KWH_LSB."','".$KWH."','".$METER_TYPE_RUN_HOUR_MSB."','".$RUN_HOUR_LSB."','".$RUN_HOUR."','".$IMPORT_EXPORT."','".$inputJSON."','".$liuxTimeStamp."',DATE_ADD('".$teltonikaTimeStamp."',INTERVAL '05:30' HOUR_MINUTE),DATE_ADD(FROM_UNIXTIME('".$liuxTimeStamp."','%Y-%m-%d %h:%i:%s'),INTERVAL '12:30' HOUR_MINUTE), DATE_ADD(NOW(),INTERVAL '12:30' HOUR_MINUTE))";
	
	 if($sensorModel =='TEP'){
	 $sql= " INSERT INTO `energy_data_master`(`gateway_code`, `sensor_code`, `sensor_model`,`R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`, `SUM_PF`, `FREQUENCY`, `KWH`, `DG_KWH`, `DG_KVAH`,`EB_DG_STATUS`, `VR_ARRAY_VALUE`, `AVG_VPN`, `AVG_VPP`, `AVG_I`, `PF_R`, `PF_Y`, `PF_B`, `KW_R`, `KW_Y`, `KW_B`, `KVAR_R`, `KVAR_Y`, `KVAR_B`, `KVA_R`, `KVA_Y`, `KVA_B`, `KW_RISING_DEMAND`, `KW_MAX_DEMAND`, `KVA_RISING_DEMAND`, `KVA_MAX_DEMAND`, `DG_KVARH`, `EB_KWH`, `EB_KVARH`, `EB_KVAH`, `3RD_HVR`, `5TH_HVR`, `7TH_HVR`, `9TH_HVR`, `11TH_HVR`, `13TH_HVR`, `15TH_HVR`, `THD_VR`, `3RD_HIR`, `5TH_HIR`, `7TH_HIR`, `9TH_HIR`, `11TH_HIR`, `13TH_HIR`, `15TH_HIR`, `THD_IR`, `3RD_HVY`, `5TH_HVY`, `7TH_HVY`, `9TH_HVY`, `11TH_HVY`, `13TH_HVY`, `15TH_HVY`, `THD_VY`, `3RD_HIY`, `5TH_HIY`, `7TH_HIY`, `9TH_HIY`, `11TH_HIY`, `13TH_HIY`, `15TH_HIY`, `THD_IY`, `3RD_HVB`, `5TH_HVB`, `7TH_HVB`, `9TH_HVB`, `11TH_HVB`, `13TH_HVB`, `15TH_HVB`, `THD_VB`, `3RD_HIB`, `5TH_HIB`, `7TH_HIB`, `9TH_HIB`, `11TH_HIB`, `13TH_HIB`, `15TH_HIB`, `THD_IB`, `DG_STATUS`, `linux_date_time`, `teltonika_date_time`, `recorded_date_time`, `posted_date_time`) VALUES ('".$gatewayCode."','".$sensorCode."','".$sensorModel."','".$Vrn."','".$Vyn."','".$Vbn."','".$Vry."','".$Vyb."','".$Vbr."','".$Ir."','".$Iy."','".$Ib."','".$System_KVA."','".$System_KW."','".$System_KVAR."','".$System_PF."','".$Frequency."','".$EB_KWh."','".$DG_KWh."','".$DG_KVAh."','".$DG_Status."','".$inputJSON."','".$Avg_Vpn."','".$Avg_Vpp."','".$Avg_I."','".$PF_R."','".$PF_Y."','".$PF_B."','".$KW_R."','".$KW_Y."','".$KW_B."','".$KVAR_R."','".$KVAR_Y."','".$KVAR_B."','".$KVA_R."','".$KVA_Y."','".$KVA_B."','".$KW_Rising_Demand."','".$KW_Max_Demand."','".$KVA_Rising_Demand."','".$KVA_Max_Demand."','".$DG_KVARh."','".$EB_KWh."','".$EB_KVARh."','".$EB_KVAh."','".$_3rd_HVr."','".$_5th_HVr."','".$_7th_HVr."','".$_9th_HVr."','".$_11th_HVr."','".$_13th_HVr."','".$_15th_HVr."','".$THD_Vr."','".$_3rd_HIr."','".$_5th_HIr."','".$_7th_HIr."','".$_9th_HIr."','".$_11th_HIr."','".$_13th_HIr."','".$_15th_HIr."','".$THD_Ir."','".$_3rd_HVy."','".$_5th_HVy."','".$_7th_HVy."','".$_9th_HVy."','".$_11th_HVy."','".$_13th_HVy."','".$_15th_HVy."','".$THD_Vy."','".$_3rd_HIy."','".$_5th_HIy."','".$_7th_HIy."','".$_9th_HIy."','".$_11th_HIy."','".$_13th_HIy."','".$_15th_HIy."','".$THD_Iy."','".$_3rd_HVb."','".$_5th_HVb."','".$_7th_HVb."','".$_9th_HVb."','".$_11th_HVb."','".$_13th_HVb."','".$_15th_HVb."','".$THD_Vb."','".$_3rd_HIb."','".$_5th_HIb."','".$_7th_HIb."','".$_9th_HIb."','".$_11th_HIb."','".$_13th_HIb."','".$_15th_HIb."','".$THD_Ib."','".$DG_Status."','".$liuxTimeStamp."','".$input[0]['DT']."','".$teltonikaTimeStamp."',NOW())";
    }else{
      $sql= "INSERT INTO `energy_data_master`(`gateway_code`, `sensor_code`, `sensor_model`,`R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`, `SUM_PF`, `FREQUENCY`, `KWH_MSB`, `KWH_LSB`, `KWH`, `METER_TYPE_RUN_HOUR_MSB`, `RUN_HOUR_LSB`, `RUN_HOUR`, `IMPORT_EXPORT`, `DG_KWH`, `DG_KVAH`, `DG_RUN_HOUR`, `DG_RUN_MIN`, `EB_DG_STATUS`, `VR_ARRAY_VALUE`,`linux_date_time`,`teltonika_date_time`, `recorded_date_time`, `posted_date_time`) VALUES ('".$gatewayCode."','".$sensorCode."','".$sensorModel."','".$R_VOLTAGE."','".$Y_VOLTAGE."','".$B_VOLTAGE."','".$RY_VOLTAGE."','".$YB_VOLTAGE."','".$BR_VOLTAGE."','".$R_CURRENT."','".$Y_CURRENT."','".$B_CURRENT."','".$SUM_KVA."','".$SUM_KW."','".$SUM_KVAR."','".$SUM_PF."','".$FREQUENCY."','".$KWH_MSB."','".$KWH_LSB."','".$KWH."','".$METER_TYPE_RUN_HOUR_MSB."','".$RUN_HOUR_LSB."','".$RUN_HOUR."','".$IMPORT_EXPORT."','".$DG_KWH."','".$DG_KVAH."','".$DG_Run_Hour."','".$DG_Run_Min."','".$EB_DG_Status."','".$inputJSON."','".$liuxTimeStamp."','".$input[0]['DT']."','".$teltonikaTimeStamp."', NOW())";
	  }
	   
        $insSel = $conn->query($sql);
     
        
        if ($insSel === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
       
	   $selectView= "SELECT * FROM `energy_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."'";
       $resultView = mysqli_query($conn, $selectView);
	   $rowcount=mysqli_num_rows($resultView);
	   if($rowcount==0){
			if($sensorModel =='TEP'){
		 $sql2= " INSERT INTO `energy_data_master_view`(`gateway_code`, `sensor_code`, `sensor_model`,`R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`, `SUM_PF`, `FREQUENCY`, `KWH`, `DG_KWH`, `DG_KVAH`,`EB_DG_STATUS`, `VR_ARRAY_VALUE`, `AVG_VPN`, `AVG_VPP`, `AVG_I`, `PF_R`, `PF_Y`, `PF_B`, `KW_R`, `KW_Y`, `KW_B`, `KVAR_R`, `KVAR_Y`, `KVAR_B`, `KVA_R`, `KVA_Y`, `KVA_B`, `KW_RISING_DEMAND`, `KW_MAX_DEMAND`, `KVA_RISING_DEMAND`, `KVA_MAX_DEMAND`, `DG_KVARH`, `EB_KWH`, `EB_KVARH`, `EB_KVAH`, `3RD_HVR`, `5TH_HVR`, `7TH_HVR`, `9TH_HVR`, `11TH_HVR`, `13TH_HVR`, `15TH_HVR`, `THD_VR`, `3RD_HIR`, `5TH_HIR`, `7TH_HIR`, `9TH_HIR`, `11TH_HIR`, `13TH_HIR`, `15TH_HIR`, `THD_IR`, `3RD_HVY`, `5TH_HVY`, `7TH_HVY`, `9TH_HVY`, `11TH_HVY`, `13TH_HVY`, `15TH_HVY`, `THD_VY`, `3RD_HIY`, `5TH_HIY`, `7TH_HIY`, `9TH_HIY`, `11TH_HIY`, `13TH_HIY`, `15TH_HIY`, `THD_IY`, `3RD_HVB`, `5TH_HVB`, `7TH_HVB`, `9TH_HVB`, `11TH_HVB`, `13TH_HVB`, `15TH_HVB`, `THD_VB`, `3RD_HIB`, `5TH_HIB`, `7TH_HIB`, `9TH_HIB`, `11TH_HIB`, `13TH_HIB`, `15TH_HIB`, `THD_IB`, `DG_STATUS`, `linux_date_time`, `teltonika_date_time`, `recorded_date_time`, `posted_date_time`) VALUES ('".$gatewayCode."','".$sensorCode."','".$sensorModel."','".$Vrn."','".$Vyn."','".$Vbn."','".$Vry."','".$Vyb."','".$Vbr."','".$Ir."','".$Iy."','".$Ib."','".$System_KVA."','".$System_KW."','".$System_KVAR."','".$System_PF."','".$Frequency."','".$EB_KWh."','".$DG_KWh."','".$DG_KVAh."','".$DG_Status."','".$inputJSON."','".$Avg_Vpn."','".$Avg_Vpp."','".$Avg_I."','".$PF_R."','".$PF_Y."','".$PF_B."','".$KW_R."','".$KW_Y."','".$KW_B."','".$KVAR_R."','".$KVAR_Y."','".$KVAR_B."','".$KVA_R."','".$KVA_Y."','".$KVA_B."','".$KW_Rising_Demand."','".$KW_Max_Demand."','".$KVA_Rising_Demand."','".$KVA_Max_Demand."','".$DG_KVARh."','".$EB_KWh."','".$EB_KVARh."','".$EB_KVAh."','".$_3rd_HVr."','".$_5th_HVr."','".$_7th_HVr."','".$_9th_HVr."','".$_11th_HVr."','".$_13th_HVr."','".$_15th_HVr."','".$THD_Vr."','".$_3rd_HIr."','".$_5th_HIr."','".$_7th_HIr."','".$_9th_HIr."','".$_11th_HIr."','".$_13th_HIr."','".$_15th_HIr."','".$THD_Ir."','".$_3rd_HVy."','".$_5th_HVy."','".$_7th_HVy."','".$_9th_HVy."','".$_11th_HVy."','".$_13th_HVy."','".$_15th_HVy."','".$THD_Vy."','".$_3rd_HIy."','".$_5th_HIy."','".$_7th_HIy."','".$_9th_HIy."','".$_11th_HIy."','".$_13th_HIy."','".$_15th_HIy."','".$THD_Iy."','".$_3rd_HVb."','".$_5th_HVb."','".$_7th_HVb."','".$_9th_HVb."','".$_11th_HVb."','".$_13th_HVb."','".$_15th_HVb."','".$THD_Vb."','".$_3rd_HIb."','".$_5th_HIb."','".$_7th_HIb."','".$_9th_HIb."','".$_11th_HIb."','".$_13th_HIb."','".$_15th_HIb."','".$THD_Ib."','".$DG_Status."','".$liuxTimeStamp."','".$input[0]['DT']."','".$teltonikaTimeStamp."',NOW())";
		}else{
				  $sql2= "INSERT INTO `energy_data_master_view`(`gateway_code`, `sensor_code`, `sensor_model`,`R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`, `SUM_PF`, `FREQUENCY`, `KWH_MSB`, `KWH_LSB`, `KWH`, `METER_TYPE_RUN_HOUR_MSB`, `RUN_HOUR_LSB`, `RUN_HOUR`, `IMPORT_EXPORT`, `DG_KWH`, `DG_KVAH`, `DG_RUN_HOUR`, `DG_RUN_MIN`, `EB_DG_STATUS`,`VR_ARRAY_VALUE`,`linux_date_time`,`teltonika_date_time`, `recorded_date_time`, `posted_date_time`) VALUES ('".$gatewayCode."','".$sensorCode."','".$sensorModel."','".$R_VOLTAGE."','".$Y_VOLTAGE."','".$B_VOLTAGE."','".$RY_VOLTAGE."','".$YB_VOLTAGE."','".$BR_VOLTAGE."','".$R_CURRENT."','".$Y_CURRENT."','".$B_CURRENT."','".$SUM_KVA."','".$SUM_KW."','".$SUM_KVAR."','".$SUM_PF."','".$FREQUENCY."','".$KWH_MSB."','".$KWH_LSB."','".$KWH."','".$METER_TYPE_RUN_HOUR_MSB."','".$RUN_HOUR_LSB."','".$RUN_HOUR."','".$IMPORT_EXPORT."','".$DG_KWH."','".$DG_KVAH."','".$DG_Run_Hour."','".$DG_Run_Min."','".$EB_DG_Status."','".$inputJSON."','".$liuxTimeStamp."','".$input[0]['DT']."','".$teltonikaTimeStamp."', NOW())";
				  }
      }else{
		   		if($sensorModel =='TEP')
		  		 {
					 $sql2= " UPDATE `energy_data_master_view` SET `R_VOLTAGE`='".$Vrn."', `Y_VOLTAGE`='".$Vyn."', `B_VOLTAGE`='".$Vbn."', `RY_VOLTAGE`='".$Vry."', `YB_VOLTAGE`='".$Vyb."', `BR_VOLTAGE`='".$Vbr."', `R_CURRENT`='".$Ir."', `Y_CURRENT`='".$Iy."', `B_CURRENT`='".$Ib."', `SUM_KVA`='".$System_KVA."', `SUM_KW`='".$System_KW."', `SUM_KVAR`='".$System_KVAR."', `SUM_PF`='".$System_PF."', `FREQUENCY`='".$Frequency."', `KWH`='".$EB_KWh."', `DG_KWH`='".$DG_KWh."', `DG_KVAH`='".$DG_KVAh."',`EB_DG_STATUS`='".$DG_Status."', `VR_ARRAY_VALUE`='".$inputJSON."', `AVG_VPN`='".$Avg_Vpn."', `AVG_VPP`='".$Avg_Vpp."', `AVG_I`='".$Avg_I."', `PF_R`='".$PF_R."', `PF_Y`='".$PF_Y."', `PF_B`='".$PF_B."', `KW_R`='".$KW_R."', `KW_Y`='".$KW_Y."', `KW_B`='".$KW_B."', `KVAR_R`='".$KVAR_R."', `KVAR_Y`='".$KVAR_Y."', `KVAR_B`='".$KVAR_B."', `KVA_R`='".$KVA_R."', `KVA_Y`='".$KVA_Y."', `KVA_B`='".$KVA_B."', `KW_RISING_DEMAND`='".$KW_Rising_Demand."', `KW_MAX_DEMAND`='".$KW_Max_Demand."', `KVA_RISING_DEMAND`='".$KVA_Rising_Demand."', `KVA_MAX_DEMAND`='".$KVA_Max_Demand."', `DG_KVARH`='".$DG_KVARh."', `EB_KWH`='".$EB_KWh."', `EB_KVARH`='".$EB_KVARh."',`EB_KVAH`='".$EB_KVAh."', `3RD_HVR`='".$_3rd_HVr."', `5TH_HVR`='".$_5th_HVr."', `7TH_HVR`='".$_7th_HVr."', `9TH_HVR`='".$_9th_HVr."', `11TH_HVR`='".$_11th_HVr."', `13TH_HVR`='".$_13th_HVr."', `15TH_HVR`='".$_15th_HVr."', `THD_VR`='".$THD_Vr."', `3RD_HIR`='".$_3rd_HIr."', `5TH_HIR`='".$_5th_HIr."', `7TH_HIR`='".$_7th_HIr."', `9TH_HIR`='".$_9th_HIr."', `11TH_HIR`='".$_11th_HIr."', `13TH_HIR`='".$_13th_HIr."', `15TH_HIR`='".$_15th_HIr."', `THD_IR`='".$THD_Ir."', `3RD_HVY`='".$_3rd_HVy."', `5TH_HVY`='".$_5th_HVy."', `7TH_HVY`='".$_7th_HVy."', `9TH_HVY`='".$_9th_HVy."', `11TH_HVY`='".$_11th_HVy."', `13TH_HVY`='".$_13th_HVy."', `15TH_HVY`='".$_15th_HVy."',`THD_VY`='".$THD_Vy."', `3RD_HIY`='".$_3rd_HIy."', `5TH_HIY`='".$_5th_HIy."', `7TH_HIY`='".$_7th_HIy."', `9TH_HIY`='".$_9th_HIy."', `11TH_HIY`='".$_11th_HIy."', `13TH_HIY`='".$_13th_HIy."', `15TH_HIY`='".$_15th_HIy."', `THD_IY`='".$THD_Iy."', `3RD_HVB`='".$_3rd_HVb."', `5TH_HVB`='".$_5th_HVb."', `7TH_HVB`='".$_7th_HVb."', `9TH_HVB`='".$_9th_HVb."', `11TH_HVB`='".$_11th_HVb."', `13TH_HVB`='".$_13th_HVb."', `15TH_HVB`='".$_15th_HVb."', `THD_VB`='".$THD_Vb."', `3RD_HIB`='".$_3rd_HIb."', `5TH_HIB`='".$_5th_HIb."', `7TH_HIB`= '".$_7th_HIb."',`9TH_HIB`='".$_9th_HIb."', `11TH_HIB`='".$_11th_HIb."', `13TH_HIB`='".$_13th_HIb."', `15TH_HIB`='".$_15th_HIb."', `THD_IB`='".$THD_Ib."', `DG_STATUS`='".$DG_Status."', `linux_date_time`='".$liuxTimeStamp."', `teltonika_date_time`='".$input[0]['DT']."', `recorded_date_time`='".$teltonikaTimeStamp."', `posted_date_time`=NOW()  WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."'";
				}
				else
				{
					  $sql2= "UPDATE `energy_data_master_view` SET `R_VOLTAGE`='".$R_VOLTAGE."',`Y_VOLTAGE`='".$Y_VOLTAGE."',B_VOLTAGE='".$B_VOLTAGE."', `RY_VOLTAGE`='".$RY_VOLTAGE."', `YB_VOLTAGE`='".$YB_VOLTAGE."', `BR_VOLTAGE`='".$BR_VOLTAGE."', `R_CURRENT`='".$R_CURRENT."', `Y_CURRENT`='".$Y_CURRENT."', `B_CURRENT`='".$B_CURRENT."', `SUM_KVA`='".$SUM_KVA."', `SUM_KW`='".$SUM_KW."', `SUM_KVAR`='".$SUM_KVAR."', `SUM_PF`='".$SUM_PF."', `FREQUENCY`='".$FREQUENCY."', `KWH_MSB`='".$KWH_MSB."', `KWH_LSB`='".$KWH_LSB."', `KWH`='".$KWH."', `METER_TYPE_RUN_HOUR_MSB`='".$METER_TYPE_RUN_HOUR_MSB."', `RUN_HOUR_LSB`='".$RUN_HOUR_LSB."', `RUN_HOUR`='".$RUN_HOUR."', `IMPORT_EXPORT`='".$IMPORT_EXPORT."',`DG_KWH`='".$DG_KWH."',`DG_KVAH`='".$DG_KVAH."',`DG_RUN_HOUR`='".$DG_Run_Hour."',`DG_RUN_MIN`='".$DG_Run_Min."',`EB_DG_STATUS`='".$EB_DG_Status."',`VR_ARRAY_VALUE`='".$inputJSON."',`linux_date_time`='".$liuxTimeStamp."',`teltonika_date_time`='".$input[0]['DT']."', `recorded_date_time`='".$teltonikaTimeStamp."', `posted_date_time`=NOW() WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."'";
				}

	  
	  }
        $insSel2 = $conn->query($sql2);
     
        
        if ($insSel2 === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $sql2 . "<br>" . $conn->error;
        }
		
		
		/*******************************************             Mail Trigger  Starts            ****************************************************/
	   $selAlertCont= "SELECT email FROM `arka_alert_contact_master` WHERE email_alert=1 AND is_active=1 AND `company_id`='".$sensMasDet['company_id']."' AND `branch_id`='".$sensMasDet['branch_id']."'";
       $ExeAlertCont = mysqli_query($conn, $selAlertCont);
	   if (mysqli_num_rows($ExeAlertCont) > 0) 
	   {
			 $alertContact='';
			 while($alertCont = mysqli_fetch_assoc($ExeAlertCont)) 
			{
			// Fetch all
			   $alertContact .= $alertCont['email'].",";
			}
		//	$string = rtrim($string, ".");
			$alertEmail= rtrim($alertContact, ",");
			echo $alertEmail." -- EmailId from Table <br>";
       } 
	   
	 echo  $selAlertPar= "SELECT * FROM `alert_parameter_mapping` WHERE `sensor_code`='".$sensorCode."'";
       $ExeAlertPar = mysqli_query($conn, $selAlertPar);
	   
	   if (mysqli_num_rows($ExeAlertPar) > 0) 
	   {
	      echo "alert parameter Mapping";
            while($parameter = mysqli_fetch_assoc($ExeAlertPar)) 
			{ 
			     echo $parameter['parameter_name']."-  Parameter Name <br>";
				$parameterName=$parameter['parameter_name'];
				if($parameter['mail_alert_status']=="Normal")
				{
              echo $selectEnergy= "SELECT ".$parameterName." FROM `energy_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND (".$parameterName." <= '".$parameter['min_alert_value']."' OR ".$parameterName." >= '".$parameter['max_alert_value']."')";
			  $ExeEnergy = mysqli_query($conn, $selectEnergy);
	           $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
				  if($ReadingValue > $parameter['max_alert_value']){
				  $alertStatus='High';
				  $alertValueName='Max Value Reached';
				  }
				  elseif($ReadingValue < $parameter['min_alert_value']){
				  $alertStatus='Low';
				  $alertValueName='Min Value Reached';
				  }
			  }else if($parameter['mail_alert_status']=="High"){
			  $selectEnergy= "SELECT ".$parameterName." FROM `energy_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND (".$parameterName." > '".$parameter['min_alert_value']."' AND ".$parameterName." < '".$parameter['max_alert_value']."')";
			  $ExeEnergy = mysqli_query($conn, $selectEnergy);
			  if (mysqli_num_rows($ExeEnergy) == 0) 
				{
				 $selectEnergy= "SELECT ".$parameterName." FROM `energy_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND ".$parameterName." <= '".$parameter['min_alert_value']."'";
			   $ExeEnergy = mysqli_query($conn, $selectEnergy);
	           $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='Low';
			   $alertValueName='Min Value Reached';
			   
			   }
			   else{
			   
			   $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='Normal';
			   $alertValueName='Normal Value Reached';
			   
			   }
			  }
			  else if($parameter['mail_alert_status']=="Low" ){
			  $selectEnergy= "SELECT ".$parameterName." FROM `energy_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND (".$parameterName." > '".$parameter['min_alert_value']."' AND ".$parameterName." < '".$parameter['max_alert_value']."')";
			  $ExeEnergy = mysqli_query($conn, $selectEnergy);
	          if (mysqli_num_rows($ExeEnergy) == 0) 
				{
				 $selectEnergy= "SELECT ".$parameterName." FROM `energy_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND ".$parameterName." >= '".$parameter['max_alert_value']."'";
			   $ExeEnergy = mysqli_query($conn, $selectEnergy);
	           $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='High';
			   $alertValueName='Max Value Reached';
			   
			   }
			   else{
			   
			   $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='Normal';
			   $alertValueName='Normal Value Reached';
			   
			   }
			  }
			  echo $alertStatus." --alert Status <br>".$alertValueName." --alert Value <br>".mysqli_num_rows($ExeEnergy);
			   
			    if (mysqli_num_rows($ExeEnergy) > 0) 
				{
				
			    echo $updateAlertPar= "UPDATE `alert_parameter_mapping` SET mail_alert_status='".$alertStatus."'  WHERE `alert_parameter_id`='".$parameter['alert_parameter_id']."'";
       			 $ExeAlertPar = mysqli_query($conn, $updateAlertPar);
				     echo $ReadingValue."-  Reading Value <br>";
				     echo $alertEmail."-  MailId <br>"; 
				     
				  // Step 1 - Enter your email address below.
$email = 'aal@arkaautomaations.com';

// If the e-mail is not working, change the debug option to 2 | $debug = 2;
$debug = 0;

// If contact form don't has the subject input change the value of subject here
$subject = 'Parameter Alert';

$message = '';

				   $message .= "Hi!<br><br><br>
	
								<b>Feeder Name</b>      : ".$parameter['feeder_name'].",<br>
								<b>Parameter Name</b>   : ".$parameter['parameter_name'].",<br>
								<b>".$alertValueName."</b>  : ".$ReadingValue.".<br><br><br><br><br>
	
	
								
                                <b>Best regards</b>,<br>
                                <b>Arka Automaations Limited.</b><br>
								";
								
				  $contentData=strip_tags($message);
								
			 $insAlertLog	="INSERT INTO `alert_log_master`(`company_id`, `branch_id`, `sensor_code`, `alert_type`, `parameter_name`, `alert_message`, `send_to`, `alert_status`, `recorded_date_time`, `posted_date_time`) VALUES ('".$sensMasDet['company_id']."','".$sensMasDet['branch_id']."','".$sensorCode."','Mail','".$parameter['parameter_name']."','".$contentData."','".$alertEmail."','".$alertStatus."','".$teltonikaTimeStamp."',DATE_ADD(NOW(),INTERVAL '00:00' HOUR_MINUTE))";		
			 $insLog = $conn->query($insAlertLog);
     
        
        if ($insLog === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $insAlertLog . "<br>" . $conn->error;
        }
            	    
$mail = new PHPMailer(true);

try {

	$mail->SMTPDebug = $debug;                                 // Debug Mode

	// Step 2 (Optional) - If you don't receive the email, try to configure the parameters below:

	$mail->IsSMTP();                                         // Set mailer to use SMTP
	$mail->Host = 'smtpout.asia.secureserver.net';				       // Specify main and backup server
	$mail->SMTPAuth = true;                                  // Enable SMTP authentication
//	$mail->Username = 'info@plumtekerp.in';                    // SMTP username
//	$mail->Password = 'Admin@2020';
//	$mail->Username = 'aal@arkaautomaations.com';                    // SMTP username
//    $mail->Password = 'Arka@2020';// SMTP password
     $mail->Username = 'tpl@tiebarfactory.com';                    // SMTP username
     $mail->Password = 'tpl6k@2020';// SMTP password
	$mail->SMTPAutoTLS = false;                               // Enable encryption, 'ssl' also accepted
	$mail->Port = 80;   								       // TCP port to connect to

//	$mail->AddAddress('vishalchandran11@gmail.com');	 						       // Add another recipient
    
	//  ***************     To Mail Starts  *************************
	$toMailArr =explode(",",$alertEmail);
    $toMailCount = count($toMailArr);
    $mailC=0;
    for($mailC==0; $mailC<$toMailCount; $mailC++){
        $mail->AddAddress($toMailArr[$mailC]);
    }   
	//  *************  To Mail Ends.... ***************************
	 
	//$mail->AddAddress($alertEmail);     // Add a secondary recipient
//	$mail->AddCC('karthikeyan@arkagroup.co.in');          // Add a "Cc" address. 
	//$mail->AddBCC('person4@domain.com', 'Person 4');         // Add a "Bcc" address. 

	// From - Name
	$fromName = 'Arka Automaations Limited';
	$mail->SetFrom($email, $fromName);

	// Repply To
/*	if( isset($_POST['email']) ) {
		$mail->AddReplyTo($_POST['email'], $fromName);
	}*/

	$mail->IsHTML(true);                                       // Set email format to HTML

	$mail->CharSet = 'UTF-8';

	$mail->Subject = $subject;
	$mail->Body    = $message;

	$mail->Send();
	$arrResult = array ('response'=>'success');

} catch (Exception $e) {
	$arrResult = array ('response'=>'error','errorMessage'=>$e->errorMessage());
} catch (\Exception $e) {
	$arrResult = array ('response'=>'error','errorMessage'=>$e->getMessage());
}

		if ($debug == 0) {
	echo json_encode($arrResult);
}	
				 	
			 }
			   
            }
       } 
	   

//mail("vishalchandran11@gmail.com", "Test Mail", "Test");

		/*******************************************             Mail Trigger   End          ****************************************************/
        $conn->close();
    
 }
    else {
        echo "Wrong API Key provided.";
    }

}
else {
    echo "No data posted with HTTP POST.";
}


function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
