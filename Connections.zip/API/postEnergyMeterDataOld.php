<?php


session_cache_limiter('nocache');
header('Expires: ' . gmdate('r', 0));

header('Content-type: application/json');


//echo  "hai"; exit;
require_once('../Connections/ARKAEMS.php'); 
$servername = $hostname_arkaems;

// REPLACE with your Database name
$dbname = $database_arkaems;
// REPLACE with Database user
$username = $username_arkaems;
// REPLACE with Database user password
$password = $password_arkaems;
if(function_exists('date_default_timezone_set')) {
		date_default_timezone_set("Asia/Kolkata");
}


/*$servername = "166.62.10.227";

// REPLACE with your Database name
$dbname = "emslte";
// REPLACE with Database user
$username = "emslte";
// REPLACE with Database user password
$password = "emslte@2020";*/
 
//exit;


// Keep this API Key value to be compatible with the ESP32 code provided in the project page. 
// If you change this value, the ESP32 sketch needs to match

//echo "hai"; exit;
   if ($_SERVER["REQUEST_METHOD"] == "POST") {
         $inputJSON = file_get_contents('php://input');
         $lastVal=substr($inputJSON,-1);
		 //echo $lastVal;
		 if($lastVal=="]"){
		 $lastChar="";
		 }else{
		 $lastChar="]";
		 }
		 $inputJSON =$inputJSON."".$lastChar;
         $input= json_decode( $inputJSON, true); 
		 $elementCount  = count($input);
	//	 echo $inputJSON; exit;
 // $api_key = test_input($_POST["api_key"]);
     $conn = new mysqli($servername, $username, $password, $dbname);
     mysqli_query($conn,"SET SESSION sql_mode = 'NO_ENGINE_SUBSTITUTION'");
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } 
   $sqlSensor = "SELECT * FROM arka_sensor_master WHERE isActive='1' AND status='1' AND api_key='".$input[0]['apiKey']."'"; 
    $insSel = $conn->query($sqlSensor);
	
     $result = mysqli_query($conn, $sqlSensor);
	 $sensMasDet = mysqli_fetch_assoc($result);
	 

       
      

       
  if (mysqli_num_rows($result) > 0) {
          
       
        
         // Create connection
		   $apikeyDecd= base64_decode($input[0]['apiKey']);
	 
	  $apiDec =explode("/", $apikeyDecd);
	   $gatewayCode=str_replace("GW:","",$apiDec[0]);
	   $sensorCode=str_replace("SI:","",$apiDec[1]);
	   $sensorModel=str_replace("SMODEL:","",$apiDec[2]);
	   

           $jsonDecd= str_replace(array('[', ',]', ']'), '', $input[0]['VR']);
           $str_arr= explode (",", $jsonDecd); 
		   
		   $Voltage_DC='';  
           $Current_DC=''; 
           $Watts_DC1=''; 
           $Wh_DC1=''; 
           $Load_Hours_DC1='';  
           $Amps_Hours_DC1=''; 
           $KVAH=''; 
		  
          // echo $input[0]['VR']."<br>"; print_r($str_arr); 
           if($sensorModel =='ICD1'){
              //  echo $str_arr[0]."<br>".$str_arr[1]."<br>".$str_arr[2]."<br>".$str_arr[3]."<br>".$str_arr[4]."<br>".$str_arr[5]."<br>".$str_arr[6]."<br>".$str_arr[7]."<br>".$str_arr[8]."<br>".$str_arr[9]."<br>".$str_arr[10]."<br>".$str_arr[11]."<br>";
           /********************   ICD Meter 1 Phase variables   *********************/
           $kWatts= $str_arr[0]/10; //date post in database
           $kwh_msb=$str_arr[1]; //date post in database
           $kwh_lsb=$str_arr[2]-100;  //date post in database
           $type_24_run_hour=$str_arr[3];  //Date Just display Here Not inserted
           $run_hour=$str_arr[4]/100; //date post in database
           $fault_tamper=$str_arr[5];  //Date Just display Here Not inserted
           $pf=$str_arr[6]/100; //date post in database
          $voltage=$str_arr[7]/10; //date post in database
           $line_current=$str_arr[8]/1000; //date post in database
           $neutral_current=$str_arr[9]/1000;  //Date Just display Here Not inserted
           $line_watt=$str_arr[10]/1000;   //Date Just display Here Not inserted
           $neutral_watt=$str_arr[11]/1000;  //Date Just display Here Not inserted
           
           $R_VOLTAGE=$voltage;
           $Y_VOLTAGE='';
           $B_VOLTAGE='';
		   $RY_VOLTAGE='';
		   $YB_VOLTAGE='';
		   $BR_VOLTAGE='';
		   $R_CURRENT=$line_current;
		   $Y_CURRENT='';
		   $B_CURRENT='';
		   $SUM_KVA='';
		   $SUM_KW=$kWatts;
		   $SUM_KVAR='';
		   $SUM_PF=$pf;
		   $FREQUENCY=''; 
		   $KWH_MSB=$kwh_msb;
		   $KWH_LSB=$kwh_lsb;
		   $KWH=$kwh_lsb/100;
		   $METER_TYPE_RUN_HOUR_MSB=$type_24_run_hour;
		   $RUN_HOUR_LSB='';
		   $RUN_HOUR=$run_hour;
		   $IMPORT_EXPORT='';
		   $DG_KWH='';
		   $DG_KVAH='';
		   $DG_Run_Hour='';
		   $DG_Run_Min='';
		   $EB_DG_Status='EB';
           
		  /*  echo"<br>VoltageR:".$R_VOLTAGE;
			echo"<br>Line Current :".$R_VOLTAGE;
			echo"<br>KWH :".$SUM_KW;
			echo"<br>KWH_MSB :".$KWH_MSB;
			echo"<br>KWH_LSB :".$KWH_LSB;
			echo"<br>METER_TYPE_RUN_HOUR_MSB :".$METER_TYPE_RUN_HOUR_MSB;*/
			
			
		  if(isset($input[0]['VR'])){
		       $VR_ARRAY_VALUE=$input[0]['VR'];
		   }
		   else
		   {
		       $VR_ARRAY_VALUE=''; 
		   }

          }
           elseif($sensorModel =='ICD3'){
           /********************   ICD Meter 3 Phase variables   *********************/
           
           
           $R_VOLTAGE=$str_arr[0]/10;  //date post in database
           $Y_VOLTAGE=$str_arr[1]/10; //date post in database  
           $B_VOLTAGE=$str_arr[2]/10; //date post in database
		   $RY_VOLTAGE=$str_arr[3]/10; //date post in database
		   $YB_VOLTAGE=$str_arr[4]/10; //date post in database
		   $BR_VOLTAGE=$str_arr[5]/10; //date post in database
		   $R_CURRENT=$str_arr[6]/10; //date post in database
		   $Y_CURRENT=$str_arr[7]/10; //date post in database
		   $B_CURRENT=$str_arr[8]/10; //date post in database
		   $SUM_KVA=$str_arr[9]/10; //date post in database
		   $SUM_KW=$str_arr[10]/10; //date post in database
		   $SUM_KVAR=$str_arr[11]/10; //date post in database
		   $SUM_PF=$str_arr[12]/1000; //date post in database
		   $FREQUENCY=$str_arr[13]/100;  //date post in database
		   $KWH_MSB=$str_arr[14]/10; //date post in database
		   $KWH_LSB=$str_arr[15]/10; //date post in database
		   $KWH=($KWH_MSB * 65536) + $KWH_LSB;  //date post in database
		   $METER_TYPE_RUN_HOUR_MSB=$str_arr[16];  //date post in database
		   $RUN_HOUR_LSB=$str_arr[17]; //date post in database
		   $RUN_HOUR=($METER_TYPE_RUN_HOUR_MSB * 65536) + $RUN_HOUR_LSB; //date post in database
		   $IMPORT_EXPORT=$str_arr[18]; //date post in database
		   $DG_KWH='';
		   $DG_KVAH='';
		   $DG_Run_Hour='';
		   $DG_Run_Min='';
		   $EB_DG_Status='EB';
           
		   if(isset($input[0]['VR'])){
		       $VR_ARRAY_VALUE=$input[0]['VR']; //date post in database this data from telonika VR parameter in json data
		   }
		   else
		   {
		       $VR_ARRAY_VALUE=''; 
		   }

           }
            elseif($sensorModel =='LMS3'){
           /********************   Elmeasure 3 Phase variables   *********************/
		   
           $watts_total=$str_arr[0]/1000;  //date post in database with calculated data from watts to kilo watts
           $watts_r_phase=$str_arr[1]/1000;  //Date Just display Here Not inserted
           $watts_y_phase=$str_arr[2]/1000;  //Date Just display Here Not inserted
           $watts_b_phase=$str_arr[3]/1000;  //Date Just display Here Not inserted
           $var_total=$str_arr[4]/1000;  //date post in database with calculated data from watts to kilo watts
           $var_r_phase=$str_arr[5]/1000;  //Date Just display Here Not inserted
           $var_y_phase=$str_arr[6]/1000;  //Date Just display Here Not inserted
           $var_b_phase=$str_arr[7]/1000;  //Date Just display Here Not inserted
           $pf_avg_inst=$str_arr[8];  //date post in database 
           $pf_r_phase=$str_arr[9];  //Date Just display Here Not inserted
           $pf_y_phase=$str_arr[10];  //Date Just display Here Not inserted
           $pf_b_phase=$str_arr[11];  //Date Just display Here Not inserted
           $va_total=$str_arr[12]/1000;  //date post in database with calculated data from watts to kilo watts
           $va_r_phase=$str_arr[13]/1000;  //Date Just display Here Not inserted
           $va_y_phase=$str_arr[14]/1000;  //Date Just display Here Not inserted
           $va_b_phase=$str_arr[15]/1000;  //Date Just display Here Not inserted
           $vll_average=$str_arr[16];  //Date Just display Here Not inserted
           $vry_phase=$str_arr[17];  //date post in database
           $vyb_phase=$str_arr[18];  //date post in database
           $vbr_phase=$str_arr[19];  //date post in database
           $vln_average=$str_arr[20];  //Date Just display Here Not inserted
           $v_r_phase=$str_arr[21];  //date post in database
           $v_y_phase=$str_arr[22];  //date post in database
           $v_b_phase=$str_arr[23];  //date post in database
           $current_total=$str_arr[24];  //date post in database
           $current_r_phase=$str_arr[25];  //Date Just display Here Not inserted
           $current_y_phase=$str_arr[26];  //Date Just display Here Not inserted
           $current_b_phase=$str_arr[27];  //Date Just display Here Not inserted
           $frequency=$str_arr[28];  //date post in database
           $wh_received=$str_arr[29]/1000;  //date post in database with calculated data from watts to kilo watts
           $load_hour_received=$str_arr[30];  //date post in database
           
           $R_VOLTAGE=$v_r_phase;
           $Y_VOLTAGE=$v_y_phase;
           $B_VOLTAGE=$v_b_phase;
		   $RY_VOLTAGE=$vry_phase;
		   $YB_VOLTAGE=$vyb_phase;
		   $BR_VOLTAGE=$vbr_phase;
		   $R_CURRENT=$current_r_phase;
		   $Y_CURRENT=$current_y_phase;
		   $B_CURRENT=$current_b_phase;
		   $SUM_KVA=$va_total;
		   $SUM_KW=$watts_total;
		   $SUM_KVAR=$var_total;
		   $SUM_PF=$pf_avg_inst;
		   $FREQUENCY=$frequency; 
		   $KWH_MSB='';
		   $KWH_LSB='';
		   $KWH=$wh_received;
		   $METER_TYPE_RUN_HOUR_MSB='';
		   $RUN_HOUR_LSB='';
		   $RUN_HOUR=$load_hour_received;
		   $IMPORT_EXPORT='';
		   $DG_KWH='';
		   $DG_KVAH='';
		   $DG_Run_Hour='';
		   $DG_Run_Min='';
		   $EB_DG_Status='EB';
           
		   if(isset($input[0]['VR'])){
		       $VR_ARRAY_VALUE=$input[0]['VR'];
		   }
		   else
		   {
		       $VR_ARRAY_VALUE=''; 
		   }

           }
           elseif($sensorModel =='T3DS'){
		   
           /********************   Elmeasure 3 Phase variables   *********************/
		   
           $KW=$str_arr[0]/100;  //date post in database with calculated data from watts to kilo watts
           $Sys_PF=$str_arr[1]/1000;  //Date Just display Here Not inserted
           $Avg_VLL=$str_arr[2]/100;  //Date Just display Here Not inserted
           $Avg_VLN=$str_arr[3]/100;  //Date Just display Here Not inserted
           $Avg_Amps=$str_arr[4]/100;  //date post in database with calculated data from watts to kilo watts
           $EB_KWh=$str_arr[5]/100;  //Date Just display Here Not inserted
           $Hz=$str_arr[6]/100;  //Date Just display Here Not inserted
           $VRY=$str_arr[7]/100;  //Date Just display Here Not inserted
           $VYB=$str_arr[8]/100;  //date post in database 
           $VBR=$str_arr[9]/100;  //Date Just display Here Not inserted
		   $VRN=$str_arr[10]/100;  //Date Just display Here Not inserted
           $VYN=$str_arr[11]/100;  //Date Just display Here Not inserted
           $VBN=$str_arr[12]/100;  //Date Just display Here Not inserted
           $IR=$str_arr[13]/100;  //date post in database with calculated data from watts to kilo watts
           $IY=$str_arr[14]/100;  //Date Just display Here Not inserted
           $IB=$str_arr[15]/100;  //Date Just display Here Not inserted
           $DG_KWH=$str_arr[16]/100;  //Date Just display Here Not inserted
           $On_Hour=$str_arr[17]/1;  //Date Just display Here Not inserted
           $On_Min=$str_arr[18]/1;  //date post in database
           $KVA=$str_arr[19]/100;  //date post in database
           $EB_KVAH=$str_arr[20]/100;  //date post in database
           $EB_Run_Hour=$str_arr[21]/1;  //Date Just display Here Not inserted
           $EB_Run_Min=$str_arr[22]/1;  //date post in database
           $DG_KVAH=$str_arr[23]/100;  //date post in database
           $DG_Run_Hour=$str_arr[24]/1;  //date post in database
           $DG_Run_Min=$str_arr[25]/1;  //date post in database
           $EB_DG_STATUS=$str_arr[26];  //Date Just display Here Not inserted
		  /* if($EB_DG_STATUS==2)
		   {
		   $EB_DG_STATUS="EB";
		   
		   }else
		   {
		   $EB_DG_STATUS="DG";
		   }
           */
           $R_VOLTAGE=$VRN;
           $Y_VOLTAGE=$VYN;
           $B_VOLTAGE=$VRN;
		   $RY_VOLTAGE=$VRY;
		   $YB_VOLTAGE=$VYB;
		   $BR_VOLTAGE=$VBR;
		   $R_CURRENT=$IR;
		   $Y_CURRENT=$IY;
		   $B_CURRENT=$IB;
		   $SUM_KVA=$KVA;
		   $SUM_KW=$KW;
		   $SUM_KVAR='';
		   $SUM_PF=$Sys_PF;
		   $FREQUENCY=$Hz; 
		   $KWH_MSB='';
		   $KWH_LSB='';
		   $KWH=$EB_KWh;
		   $METER_TYPE_RUN_HOUR_MSB='';
		   $RUN_HOUR_LSB='';
		   $RUN_HOUR=$On_Hour;
		   $IMPORT_EXPORT='';
		   $DG_KWH=$DG_KWH;
		   $DG_KVAH=$DG_KVAH;
		   $DG_Run_Hour=$DG_Run_Hour;
		   $DG_Run_Min=$DG_Run_Min;
		   $EB_DG_Status=$EB_DG_STATUS;
           
		   if(isset($input[0]['VR'])){
		       $VR_ARRAY_VALUE=$input[0]['VR'];
		   }
		   else
		   {
		       $VR_ARRAY_VALUE=''; 
		   }

           
		   
		   }elseif($sensorModel =='TE'){
		   
           /********************   Trinity Entity  variables   *********************/
		   //$KW=$str_arr[0]/100;
           $KW=$str_arr[0]/100;  //date post in database with calculated data from watts to kilo watts
		   
		   
           $R_VOLTAGE='';
           $Y_VOLTAGE='';
           $B_VOLTAGE='';
		   $RY_VOLTAGE='';
		   $YB_VOLTAGE='';
		   $BR_VOLTAGE='';
		   $R_CURRENT='';
		   $Y_CURRENT='';
		   $B_CURRENT='';
		   $SUM_KVA='';
		   $SUM_KW='';
		   $SUM_KVAR='';
		   $SUM_PF='';
		   $FREQUENCY=''; 
		   $KWH_MSB='';
		   $KWH_LSB='';
		   $KWH=$KW;
		   $METER_TYPE_RUN_HOUR_MSB='';
		   $RUN_HOUR_LSB='';
		   $RUN_HOUR='';
		   $IMPORT_EXPORT='';
		   $DG_KWH='';
		   $DG_KVAH='';
		   $DG_Run_Hour='';
		   $DG_Run_Min='';
		   $EB_DG_Status='';
           
		   if(isset($input[0]['VR'])){
		       $VR_ARRAY_VALUE=$input[0]['VR'];
		   }
		   else
		   {
		       $VR_ARRAY_VALUE=''; 
		   }

           
		   
		   }elseif($sensorModel =='TPP'){
		   
           /********************   Trinity Power Pro   *********************/
		   
           $System_KVA=$str_arr[0]/100;  //date post in database with calculated data from watts to kilo watts
           $System_KW=$str_arr[1]/100;  //Date Just display Here Not inserted
           $System_KVAR=$str_arr[2]/100;  //Date Just display Here Not inserted
           $System_PF=$str_arr[3]/1000;  //Date Just display Here Not inserted
           $Avg_Vpp=$str_arr[4]/100;  //date post in database with calculated data from watts to kilo watts
           $Avg_Vpn=$str_arr[5]/100;  //Date Just display Here Not inserted
           $Avg_I=$str_arr[6]/100;  //Date Just display Here Not inserted
           $EB_KWh=$str_arr[7]/100;  //Date Just display Here Not inserted
           $EB_KVAh=$str_arr[8]/100;  //date post in database 
           $EB_KVARh=$str_arr[9]/100;  //Date Just display Here Not inserted
		   $Frequency=$str_arr[10]/100;  //Date Just display Here Not inserted
           $Vry=$str_arr[11]/100;  //Date Just display Here Not inserted
           $Vyb=$str_arr[12]/100;  //Date Just display Here Not inserted
           $Vbr=$str_arr[13]/100;  //date post in database with calculated data from watts to kilo watts
           $Vrn=$str_arr[14]/100;  //Date Just display Here Not inserted
           $Vyn=$str_arr[15]/100;  //Date Just display Here Not inserted
           $Vbn=$str_arr[16]/100;  //Date Just display Here Not inserted
           $Ir=$str_arr[17]/100;  //Date Just display Here Not inserted
           $Iy=$str_arr[18]/100;  //date post in database
           $Ib=$str_arr[19]/100;  //date post in database
           $THD_Vr=$str_arr[20]/100;  //date post in database
           $THD_Vy=$str_arr[21]/100;  //Date Just display Here Not inserted
           $THD_Vb=$str_arr[22]/100;  //date post in database
           $THD_Ir=$str_arr[23]/100;  //date post in database
           $THD_Iy=$str_arr[24]/100;  //date post in database
           $THD_Ib=$str_arr[25]/100;  //date post in database
		   
           
           $R_VOLTAGE=$Vrn;
           $Y_VOLTAGE=$Vyn;
           $B_VOLTAGE=$Vbn;
		   $RY_VOLTAGE=$Vry;
		   $YB_VOLTAGE=$Vyb;
		   $BR_VOLTAGE=$Vbr;
		   $R_CURRENT=$Ir;
		   $Y_CURRENT=$Iy;
		   $B_CURRENT=$Ib;
		   $SUM_KVA=$System_KVA;
		   $SUM_KW=$System_KW;
		   $SUM_KVAR=$System_KVAR;
		   $SUM_PF=$System_PF;
		   $FREQUENCY=$Frequency; 
		   $KWH_MSB='';
		   $KWH_LSB='';
		   $KWH=$EB_KWh;
		   $METER_TYPE_RUN_HOUR_MSB='';
		   $RUN_HOUR_LSB='';
		   $RUN_HOUR=$On_Hour;
		   $IMPORT_EXPORT='';
		   $DG_KWH='';
		   $DG_KVAH='';
		   $DG_Run_Hour='';
		   $DG_Run_Min='';
		   $EB_DG_Status='';
           
		   if(isset($input[0]['VR'])){
		       $VR_ARRAY_VALUE=$input[0]['VR'];
		   }
		   else
		   {
		       $VR_ARRAY_VALUE=''; 
		   }

           
		   
		   }elseif($sensorModel =='TXL'){
		   
           /********************   Trinity Xpert Lite   *********************/
		   
           $KVA=$str_arr[0]/100;  //date post in database with calculated data from watts to kilo watts
           $KW=$str_arr[1]/100;  //Date Just display Here Not inserted
           $KVAR=$str_arr[2]/100;  //Date Just display Here Not inserted
           $PF=$str_arr[3]/1000;  //Date Just display Here Not inserted
           $Avg_Vll=$str_arr[4]/100;  //date post in database with calculated data from watts to kilo watts
           $Avg_Vln=$str_arr[5]/100;  //Date Just display Here Not inserted
           $Avg_amps=$str_arr[6]/100;  //Date Just display Here Not inserted
           $KWh=$str_arr[7]/100;  //Date Just display Here Not inserted
           $KVAh=$str_arr[8]/100;  //date post in database 
           $KVARh=$str_arr[9]/100;  //Date Just display Here Not inserted
		   $Frequency=$str_arr[10]/100;  //Date Just display Here Not inserted
           $Vry=$str_arr[11]/100;  //Date Just display Here Not inserted
           $Vyb=$str_arr[12]/100;  //Date Just display Here Not inserted
           $Vbr=$str_arr[13]/100;  //date post in database with calculated data from watts to kilo watts
           $Vr=$str_arr[14]/100;  //Date Just display Here Not inserted
           $Vy=$str_arr[15]/100;  //Date Just display Here Not inserted
           $Vb=$str_arr[16]/100;  //Date Just display Here Not inserted
           $Ir=$str_arr[17]/100;  //Date Just display Here Not inserted
           $Iy=$str_arr[18]/100;  //date post in database
           $Ib=$str_arr[19]/100;  //date post in database
		   $demand=$str_arr[20]/1;  //date post in database
		   $max_demand=$str_arr[21]/1;  //date post in database
		   $dg_kwh=$str_arr[22]/100;  //date post in database
		   $dg_kvah=$str_arr[23]/100;  //date post in database
		   $dg_kvarh=$str_arr[24]/100;  //date post in database
		   $vr_thd=$str_arr[25]/100;  //date post in database
		   $vy_thd=$str_arr[26]/100;  //date post in database
		   $vb_thd=$str_arr[27]/100;  //date post in database
		   $ir_thd=$str_arr[28]/100;  //date post in database
		   $iy_thd=$str_arr[29]/100;  //date post in database
		   $ib_thd=$str_arr[30]/100;  //date post in database
		   $dg_status=$str_arr[31]/1;  //date post in database
          
		   
           
           $R_VOLTAGE=$Vr;
           $Y_VOLTAGE=$Vy;
           $B_VOLTAGE=$Vb;
		   $RY_VOLTAGE=$Vry;
		   $YB_VOLTAGE=$Vyb;
		   $BR_VOLTAGE=$Vbr;
		   $R_CURRENT=$Ir;
		   $Y_CURRENT=$Iy;
		   $B_CURRENT=$Ib;
		   $SUM_KVA=$KVA;
		   $SUM_KW=$KW;
		   $SUM_KVAR=$KVAR;
		   $SUM_PF=$PF;
		   $FREQUENCY=$Frequency; 
		   $KWH_MSB='';
		   $KWH_LSB='';
		   $KWH=$KWh;
		   $KVAH=$KVAh;
		   $METER_TYPE_RUN_HOUR_MSB='';
		   $RUN_HOUR_LSB='';
		   $RUN_HOUR=$On_Hour;
		   $IMPORT_EXPORT='';
		   $DG_KWH=$dg_kwh;
		   $DG_KVAH=$dg_kvah;
		   $DG_Run_Hour='';
		   $DG_Run_Min='';
		   $EB_DG_Status=$dg_status;
           
		   if(isset($input[0]['VR'])){
		       $VR_ARRAY_VALUE=$input[0]['VR'];
		   }
		   else
		   {
		       $VR_ARRAY_VALUE=''; 
		   }

           
		   
		   }elseif($sensorModel =='TNF'){
		   
		   if($elementCount==5){
           /********************   Trinity NF29   *********************/
		   for ($x =0; $x <= $elementCount; $x++) {
			   if($input[$x]['ST']=='3000'){
					$arrRemoveFirstSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
					$firstSegment= explode (",", $arrRemoveFirstSegment); 
					 $KVA=$firstSegment[0]/100;  //date post in database with calculated data from watts to kilo watts
           $KW=$firstSegment[1]/100;  //Date Just display Here Not inserted
           $KVAR=$firstSegment[2]/100;  //Date Just display Here Not inserted
           $PF=$firstSegment[3]/1000;  //Date Just display Here Not inserted
           $Avg_VLL=$firstSegment[4]/100;  //date post in database with calculated data from watts to kilo watts
           $Avg_VLN=$firstSegment[5]/100;  //Date Just display Here Not inserted
           $Avg_Amps=$firstSegment[6]/100;  //Date Just display Here Not inserted
		   $KVAR_B=$firstSegment[7]/100;  //Date Just display Here Not inserted
				}elseif($input[$x]['ST']=='3030'){
					$arrRemoveSecondSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
					$secondSegment= explode (",", $arrRemoveSecondSegment); 
					  $KWh=$secondSegment[0]/100;  //Date Just display Here Not inserted
           $KVAh=$secondSegment[1]/100;  //date post in database 
           $KVARh=$secondSegment[2]/100;  //Date Just display Here Not inserted
		   $Frequency=$secondSegment[3]/1000;  // HZ value
           $Vry=$secondSegment[4]/100;  //Date Just display Here Not inserted
           $Vr=$secondSegment[5]/100;  //Date Just display Here Not inserted
           $Ir=$secondSegment[6]/100;  //date post in database with calculated data from watts to kilo watts
           $PF_R=$secondSegment[7]/100;  //Date Just display Here Not inserted
				}elseif($input[$x]['ST']=='3060'){
					$arrRemoveThirdSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
					$thirdSegment= explode (",", $arrRemoveThirdSegment); 
					 $Reserved_3060=$thirdSegment[0]/100;  //Date Just display Here Not inserted
           $Reserved_3062=$thirdSegment[1]/100;  //Date Just display Here Not inserted
		   $Reserved_3064=$thirdSegment[2]/100;  //Date Just display Here Not inserted
		   $Reserved_3066=$thirdSegment[3]/1000;  //Date Just display Here Not inserted
		   $Vyb=$thirdSegment[4]/100;  //Date Just display Here Not inserted
		   $Vy=$thirdSegment[5]/100;  //Date Just display Here Not inserted
		   $Iy=$thirdSegment[6]/100;  //Date Just display Here Not inserted
		   $PF_Y=$thirdSegment[7]/100;  //Date Just display Here Not inserted
				}elseif($input[$x]['ST']=='3090'){
					$arrRemoveFourthSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
					$fourthSegment= explode (",", $arrRemoveFourthSegment); 
					 $Reserved_3090=$fourthSegment[0]/100;  //Date Just display Here Not inserted
           $Reserved_3092=$fourthSegment[1]/100;  //Date Just display Here Not inserted
		   $Reserved_3094=$fourthSegment[2]/100;  //Date Just display Here Not inserted
		   $Reserved_3096=$fourthSegment[3]/1000;  //Date Just display Here Not inserted
		   $Vbr=$fourthSegment[4]/100;  //Date Just display Here Not inserted
		   $Vb=$fourthSegment[5]/100;  //Date Just display Here Not inserted
		   $Ib=$fourthSegment[6]/100;  //Date Just display Here Not inserted
		   $PF_B=$fourthSegment[7]/100;  //Date Just display Here Not inserted
				}elseif($input[$x]['ST']=='3120'){
					$arrRemoveFifthSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
					$fifthSegment= explode (",", $arrRemoveFifthSegment); 
					 $KVA_R=$fifthSegment[0]/100;  //date post in database with calculated data from watts to kilo watts
           $KVA_Y=$fifthSegment[1]/100;  //Date Just display Here Not inserted
           $KVA_B=$fifthSegment[2]/100;  //Date Just display Here Not inserted
		   $KW_R=$fifthSegment[3]/1000;  //date post in database with calculated data from watts to kilo watts
           $KW_Y=$fifthSegment[4]/100;  //Date Just display Here Not inserted
           $KW_B=$fifthSegment[5]/100;  //Date Just display Here Not inserted
		   $KVAR_R=$fifthSegment[6]/100;  //date post in database with calculated data from watts to kilo watts
           $KVAR_Y=$fifthSegment[7]/100;  //Date Just display Here Not inserted

				}
		   }
		   print_r($secondSegment); 
		   
          
         
          
		  
		  
          
           
           $R_VOLTAGE=$Vr;
           $Y_VOLTAGE=$Vy;
           $B_VOLTAGE=$Vb;
		   $RY_VOLTAGE=$Vry;
		   $YB_VOLTAGE=$Vyb;
		   $BR_VOLTAGE=$Vbr;
		   $R_CURRENT=$Ir;
		   $Y_CURRENT=$Iy;
		   $B_CURRENT=$Ib;
		   $SUM_KVA=$KVA;
		   $SUM_KW=$KW;
		   $SUM_KVAR=$KVAR;
		   $SUM_PF=$PF;
		   $FREQUENCY=$Frequency; 
		   $KWH_MSB='';
		   $KWH_LSB='';
		   $KWH=$KWh;
		   $METER_TYPE_RUN_HOUR_MSB='';
		   $RUN_HOUR_LSB='';
		   $RUN_HOUR='';
		   $IMPORT_EXPORT='';
		   $DG_KWH='';
		   $DG_KVAH='';
		   $DG_Run_Hour='';
		   $DG_Run_Min='';
		   $EB_DG_Status='';
           
		  

           }else{
		   
		   exit;
		   }
		   
		   }
		   elseif($sensorModel =='TEP'){
		   
           /********************   Trinity Expert Pro   *********************/
		   if($input[0]['ST']=="200")
		   {
		    	$firstArraySet=$input[0]['VR'];
		   }
		   elseif($input[1]['ST']=="200")
		   {
				$firstArraySet=$input[1]['VR'];
		   }
		   
		   $jsonDecd= str_replace(array('[', ',]', ']'), '', $firstArraySet);
           $str_arr= explode (",", $jsonDecd); 
		  
		   
           $Vrn=$str_arr[0]/100;  //date post in database 
           $Vyn=$str_arr[1]/100;  //date post in database 
           $Vbn=$str_arr[2]/100;  //date post in database 
           $Avg_Vpn=$str_arr[3]/1000;  //date post in database 
           $Vry=$str_arr[4]/100;  //date post in database 
           $Vyb=$str_arr[5]/100;  //date post in database 
           $Vbr=$str_arr[6]/100;  //date post in database 
           $Avg_Vpp=$str_arr[7]/100;  //date post in database 
           $Ir=$str_arr[8]/100;  //date post in database 
           $Iy=$str_arr[9]/100;  //date post in database 
		   $Ib=$str_arr[10]/100;  //date post in database 
           $Avg_I=$str_arr[11]/100;  //date post in database 
           $Reserve=$str_arr[12];  // Dummy Field Name As Reserve
           $Reserve=$str_arr[13];  // Dummy Field Name As Reserve
           $Reserve=$str_arr[14];  // Dummy Field Name As Reserve
           $Frequency=$str_arr[15]/100;  //date post in database 
           $System_PF=$str_arr[16]/1000;  //date post in database 
           $PF_R=$str_arr[17]/1000;  //date post in database 
           $PF_Y=$str_arr[18]/1000;  //date post in database
           $PF_B=$str_arr[19]/1000;  //date post in database
           $System_KW=$str_arr[20]/100;  //date post in database
           $System_KVAR=$str_arr[21]/100;  //date post in database 
           $System_KVA=$str_arr[22]/100;  //date post in database
           $KW_R=$str_arr[23]/100;  //date post in database
           $KW_Y=$str_arr[24]/100;  //date post in database
           $KW_B=$str_arr[25]/100;  //date post in database
		   $KVAR_R=$str_arr[26]/100;  //date post in database
           $KVAR_Y=$str_arr[27]/100;  //date post in database
           $KVAR_B=$str_arr[28]/100;  //date post in database
		   $KVA_R=$str_arr[29]/100;  //date post in database
           $KVA_Y=$str_arr[30]/100;  //date post in database
           $KVA_B=$str_arr[31]/100;  //date post in database
		   $KW_Rising_Demand=$str_arr[32]/100;  //date post in database
		   $KW_Max_Demand=$str_arr[33]/100;  //date post in database
		   $KVA_Rising_Demand=$str_arr[34]/100;  //date post in database
		   $KVA_Max_Demand=$str_arr[35]/100;  //date post in database
		   $DG_KWh=$str_arr[36]/100;  //date post in database
		   $DG_KVARh=$str_arr[37]/100;  //date post in database
		   $EB_KWh=$str_arr[38]/100;  //date post in database
		   $EB_KVARh=$str_arr[39]/100;  //date post in database
		   $Reserve=$str_arr[40];  //Dummy Field Name As Reserve
		   $DG_KVAh=$str_arr[41]/100;  //date post in database

		   $EB_KVAh=$str_arr[42]/100;  //date post in database
		   $_3rd_HVr=$str_arr[43]/100;  //date post in database
		   $_5th_HVr=$str_arr[44]/100;  //date post in database
		   $_7th_HVr=$str_arr[45]/100;  //date post in database
		   $_9th_HVr=$str_arr[46]/100;  //date post in database
		   $_11th_HVr=$str_arr[47]/100;  //date post in database
		   $_13th_HVr=$str_arr[48]/100;  //date post in database
		   $_15th_HVr=$str_arr[49]/100;  //date post in database
		   
		   if($input[1]['ST']=="300")
		   {
		    	$secondArraySet=$input[1]['VR'];
		   }
		   elseif($input[0]['ST']=="300")
		   {
				$secondArraySet=$input[0]['VR'];
		   }
		   
		   $jsonDecd2= str_replace(array('[', ',]', ']'), '', $secondArraySet);
           $str_arr2= explode (",", $jsonDecd2); 
		    if($secondArraySet =="" || $firstArraySet=="" ){
		   exit;
		   }
		   $THD_Vr=$str_arr2[0]/100;  //date post in database
		   $_3rd_HIr=$str_arr2[1]/100;  //date post in database
		   $_5th_HIr=$str_arr2[2]/100;  //date post in database
		   $_7th_HIr=$str_arr2[3]/100;  //date post in database
		   $_9th_HIr=$str_arr2[4]/100;  //date post in database
		   $_11th_HIr=$str_arr2[5]/100;  //date post in database
		   $_13th_HIr=$str_arr2[6]/100;  //date post in database
		   $_15th_HIr=$str_arr2[7]/100;  //date post in database
		   $THD_Ir=$str_arr2[8]/100;  //date post in database
		   $_3rd_HVy=$str_arr2[9]/100;  //date post in database
		   $_5th_HVy=$str_arr2[10]/100;  //date post in database
		   $_7th_HVy=$str_arr2[11]/100;  //date post in database
		   $_9th_HVy=$str_arr2[12]/100;  //date post in database
		   $_11th_HVy=$str_arr2[13]/100;  //date post in database
		   $_13th_HVy=$str_arr2[14]/100;  //date post in database
		   $_15th_HVy=$str_arr2[15]/100;  //date post in database
		   $THD_Vy=$str_arr2[16]/100;  //date post in database
		   $_3rd_HIy=$str_arr2[17]/100;  //date post in database
		   $_5th_HIy=$str_arr2[18]/100;  //date post in database
		   $_7th_HIy=$str_arr2[19]/100;  //date post in database
		   $_9th_HIy=$str_arr2[20]/100;  //date post in database
		   $_11th_HIy=$str_arr2[21]/100;  //date post in database
		   $_13th_HIy=$str_arr2[22]/100;  //date post in database
		   $_15th_HIy=$str_arr2[23]/100;  //date post in database
		   $THD_Iy=$str_arr2[24]/100;  //date post in database
		   $_3rd_HVb=$str_arr2[25]/100;  //date post in database
		   $_5th_HVb=$str_arr2[26]/100;  //date post in database
		   $_7th_HVb=$str_arr2[27]/100;  //date post in database
		   $_9th_HVb=$str_arr2[28]/100;  //date post in database
		   $_11th_HVb=$str_arr2[29]/100;  //date post in database
		   $_13th_HVb=$str_arr2[30]/100;  //date post in database
		   $_15th_HVb=$str_arr2[31]/100;  //date post in database
		   $THD_Vb=$str_arr2[32]/100;  //date post in database
		   $_3rd_HIb=$str_arr2[33]/100;  //date post in database
		   $_5th_HIb=$str_arr2[34]/100;  //date post in database
		   $_7th_HIb=$str_arr2[35]/100;  //date post in database
		   $_9th_HIb=$str_arr2[36]/100;  //date post in database
		   $_11th_HIb=$str_arr2[37]/100;  //date post in database
		   $_13th_HIb=$str_arr2[38]/100;  //date post in database
		   $_15th_HIb=$str_arr2[39]/100;  //date post in database
		   $THD_Ib=$str_arr2[40]/100;  //date post in database
		   $DG_Status=$str_arr2[41]/1;  //date post in database

		   if(isset($input[0]['VR'])){
		       $VR_ARRAY_VALUE=$input[0]['VR'];
		   }
		   else
		   {
		       $VR_ARRAY_VALUE=''; 
		   }

           
		   
		   }
		   elseif($sensorModel =='MFM384'){
		   
           /********************  SELEC MFM384 Multifunction meter   *********************/
		   
           $Voltage_V1N=$str_arr[0];  //date post in database with calculated data from watts to kilo watts
           $Voltage_V2N=$str_arr[1];  //Date Just display Here Not inserted
           $Voltage_V3N=$str_arr[2];  //Date Just display Here Not inserted
           $Average_Voltage_LN=$str_arr[3];  //Date Just display Here Not inserted
           $Voltage_V12=$str_arr[4];  //date post in database with calculated data from watts to kilo watts
           $Voltage_V23=$str_arr[5];  //Date Just display Here Not inserted
           $Voltage_V31=$str_arr[6];  //Date Just display Here Not inserted
		   $Average_Voltage_ll=$str_arr[7];  //Date Just display Here Not inserted
           $Current_l1=$str_arr[8];  //Date Just display Here Not inserted
           $Current_l2=$str_arr[9];  //date post in database 
           $Current_l3=$str_arr[10];  //Date Just display Here Not inserted
		   $Average_Current=$str_arr[11];  // HZ value
           $kW1=$str_arr[12];  //Date Just display Here Not inserted
           $kW2=$str_arr[13];  //Date Just display Here Not inserted
           $kW3=$str_arr[14];  //date post in database with calculated data from watts to kilo watts
           $kVA1=$str_arr[15];  //Date Just display Here Not inserted
           $kVA2=$str_arr[16];  //Date Just display Here Not inserted
           $kVA3=$str_arr[17];  //Date Just display Here Not inserted
		   $kVAr1=$str_arr[18];  //Date Just display Here Not inserted
		   $kVAr2=$str_arr[19];  //Date Just display Here Not inserted
		   $kVAr3=$str_arr[20];  //Date Just display Here Not inserted
		   $Total_kW=$str_arr[21];  //Date Just display Here Not inserted
		   $Total_kVA=$str_arr[22];  //Date Just display Here Not inserted
		   $Total_kVAr=$str_arr[23];  //Date Just display Here Not inserted
		   $PF1=$str_arr[24];  //Date Just display Here Not inserted
           $PF2=$str_arr[25];  //Date Just display Here Not inserted
		   $PF3=$str_arr[26];  //Date Just display Here Not inserted
		   $Average_PF=$str_arr[27];  //Date Just display Here Not inserted
		   $Frequency=$str_arr[28];  //Date Just display Here Not inserted
		   $kWh=$str_arr[29];  //Date Just display Here Not inserted
		   $kVAh=$str_arr[30]/100;  //Date Just display Here Not inserted
		   $kVArh=$str_arr[31]/100;  //Date Just display Here Not inserted
		  

          
           
           $R_VOLTAGE=$Voltage_V1N;
           $Y_VOLTAGE=$Voltage_V2N;
           $B_VOLTAGE=$Voltage_V3N;
		   $RY_VOLTAGE=$Voltage_V12;
		   $YB_VOLTAGE=$Voltage_V23;
		   $BR_VOLTAGE=$Voltage_V31;
		   $R_CURRENT=$Current_l1;
		   $Y_CURRENT=$Current_l2;
		   $B_CURRENT=$Current_l3;
		   $SUM_KVA=$Total_kVA;
		   $SUM_KW=$Total_kW;
		   $SUM_KVAR=$Total_kVAr;
		   $SUM_PF=$Average_PF;
		   $FREQUENCY=$Frequency; 
		   $KWH_MSB='';
		   $KWH_LSB='';
		   $KWH=$KWh;
		   $METER_TYPE_RUN_HOUR_MSB='';
		   $RUN_HOUR_LSB='';
		   $RUN_HOUR='';
		   $IMPORT_EXPORT='';
		   $DG_KWH='';
		   $DG_KVAH='';
		   $DG_Run_Hour='';
		   $DG_Run_Min='';
		   $EB_DG_Status='';
           
		   if(isset($input[0]['VR'])){
		       $VR_ARRAY_VALUE=$input[0]['VR'];
		   }
		   else
		   {
		       $VR_ARRAY_VALUE=''; 
		   }

           
		   
		   }
		   elseif($sensorModel =='S_EM4M'){
		   
           /********************   SELEC EM4M   *********************/
		   
           $Voltage_V1N=$str_arr[0];  //date post in database with calculated data from watts to kilo watts
           $Voltage_V2N=$str_arr[1];  //Date Just display Here Not inserted
           $Voltage_V3N=$str_arr[2];  //Date Just display Here Not inserted
           $Average_Voltage_LN=$str_arr[3];  //Date Just display Here Not inserted
           $Voltage_V12=$str_arr[4];  //date post in database with calculated data from watts to kilo watts
           $Voltage_V23=$str_arr[5];  //Date Just display Here Not inserted
           $Voltage_V31=$str_arr[6];  //Date Just display Here Not inserted
		   $Average_Voltage_ll=$str_arr[7];  //Date Just display Here Not inserted
           $Current_l1=$str_arr[8];  //Date Just display Here Not inserted
           $Current_l2=$str_arr[9];  //date post in database 
           $Current_l3=$str_arr[10];  //Date Just display Here Not inserted
		   $Average_Current=$str_arr[11];  // HZ value
           $kW1=$str_arr[12];  //Date Just display Here Not inserted
           $kW2=$str_arr[13];  //Date Just display Here Not inserted
           $kW3=$str_arr[14];  //date post in database with calculated data from watts to kilo watts
		   $kVAr1=$str_arr[15];  //Date Just display Here Not inserted
		   $kVAr2=$str_arr[16];  //Date Just display Here Not inserted
		   $kVAr3=$str_arr[17];  //Date Just display Here Not inserted
           $kVA1=$str_arr[18];  //Date Just display Here Not inserted
           $kVA2=$str_arr[19];  //Date Just display Here Not inserted
           $kVA3=$str_arr[20];  //Date Just display Here Not inserted
		   $Total_kW=$str_arr[21];  //Date Just display Here Not inserted
		   $Total_kVAr=$str_arr[22];  //Date Just display Here Not inserted
		   $Total_kVA=$str_arr[23];  //Date Just display Here Not inserted
		   $PF1=$str_arr[24];  //Date Just display Here Not inserted
           $PF2=$str_arr[25];  //Date Just display Here Not inserted
		   $PF3=$str_arr[26];  //Date Just display Here Not inserted
		   $Average_PF=$str_arr[27];  //Date Just display Here Not inserted
		   $Frequency=$str_arr[28];  //Date Just display Here Not inserted
		   
		   $Total_Net_kWh_mains=$str_arr[29];  // $kWh
		   $Total_Net_kVArh_mains=$str_arr[30];  // $kVArh
		   $Total_Net_kVAh_mains=$str_arr[31];  // $kVAh
		   $Total_Net_kWh_dg=$str_arr[32];  // $kWh_dg
		   $Total_Net_kVArh_dg=$str_arr[33];  // $kVArh_dg
		   $Total_Net_kVAh_dg=$str_arr[34];  // $kVAh_dg
		   
		   $Max_DMD_Active_Power=$str_arr[35];  
		   $Max_DMD_Rective_Power=$str_arr[36];  
		   $Max_DMD_Apparent_Power=$str_arr[37]; 
		   
		   $kWh1_Import=$str_arr[38];  
		   $kWh2_Import=$str_arr[39];  
		   $kWh3_Import=$str_arr[40]; 
		   $kWh1_Export=$str_arr[41];  
		   $kWh2_Export=$str_arr[42];  
		   $kWh3_Export=$str_arr[43]; 
		   $Total_kWh_Import=$str_arr[44];  
		   $Total_kWh_Export=$str_arr[45];
		   
		   $kVArh1_Import=$str_arr[46];  
		   $kVArh2_Import=$str_arr[47];  
		   $kVArh3_Import=$str_arr[48]; 
		   $kVArh1_Export=$str_arr[49];  
		   $kVArh2_Export=$str_arr[50];  
		   $kVArh3_Export=$str_arr[51]; 
		   $Total_kVArh_Import=$str_arr[52];  
		   $Total_kVArh_Export=$str_arr[53];
		   
		   $kVAh_1=$str_arr[54];  
		   $kVAh_2=$str_arr[55];  
		   $kVAh_3=$str_arr[56]; 
           
           $R_VOLTAGE=$Voltage_V1N;
           $Y_VOLTAGE=$Voltage_V2N;
           $B_VOLTAGE=$Voltage_V3N;
		   $RY_VOLTAGE=$Voltage_V12;
		   $YB_VOLTAGE=$Voltage_V23;
		   $BR_VOLTAGE=$Voltage_V31;
		   $R_CURRENT=$Current_l1;
		   $Y_CURRENT=$Current_l2;
		   $B_CURRENT=$Current_l3;
		   $SUM_KVA=$Total_kVA;
		   $SUM_KW=$Total_kW;
		   $SUM_KVAR=$Total_kVAr;
		   $SUM_PF=$Average_PF;
		   $FREQUENCY=$Frequency; 
		   $KWH_MSB='';
		   $KWH_LSB='';
		   $KWH=$KWh;
		   $METER_TYPE_RUN_HOUR_MSB='';
		   $RUN_HOUR_LSB='';
		   $RUN_HOUR='';
		   $IMPORT_EXPORT='';
		   $DG_KWH='';
		   $DG_KVAH='';
		   $DG_Run_Hour='';
		   $DG_Run_Min='';
		   $EB_DG_Status='';
           
		   if(isset($input[0]['VR'])){
		       $VR_ARRAY_VALUE=$input[0]['VR'];
		   }
		   else
		   {
		       $VR_ARRAY_VALUE=''; 
		   }

           
		   
		   }
		    elseif($sensorModel =='EDC'){
		   
           /********************   Elmeasure DC Meter   *********************/
		   
           $Voltage_DC=$str_arr[0];  //date post in database with calculated data from watts to kilo watts
           $Current_DC=$str_arr[1];  //Date Just display Here Not inserted
           $Watts_DC1=$str_arr[2];  //Date Just display Here Not inserted
           $Wh_DC1=$str_arr[3];  //Date Just display Here Not inserted
           $Load_Hours_DC1=$str_arr[4];  //date post in database with calculated data from watts to kilo watts
           $Amps_Hours_DC1=$str_arr[5];  //Date Just display Here Not inserted
           
           
           $R_VOLTAGE='';
           $Y_VOLTAGE='';
           $B_VOLTAGE='';
		   $RY_VOLTAGE='';
		   $YB_VOLTAGE='';
		   $BR_VOLTAGE='';
		   $R_CURRENT='';
		   $Y_CURRENT='';
		   $B_CURRENT='';
		   $SUM_KVA='';
		   $SUM_KW='';
		   $SUM_KVAR='';
		   $SUM_PF='';
		   $FREQUENCY=''; 
		   $KWH_MSB='';
		   $KWH_LSB='';
		   $KWH=$KWh;
		   $METER_TYPE_RUN_HOUR_MSB='';
		   $RUN_HOUR_LSB='';
		   $RUN_HOUR='';
		   $IMPORT_EXPORT='';
		   $DG_KWH='';
		   $DG_KVAH='';
		   $DG_Run_Hour='';
		   $DG_Run_Min='';
		   $EB_DG_Status='';
		   $Voltage_DC='';
           $Current_DC1='';
           $Watts_DC1='';
		   $Wh_DC1='';
		   $Load_Hours_DC1='';
		   $Amps_Hours_DC1='';
           
		   if(isset($input[0]['VR'])){
		       $VR_ARRAY_VALUE=$input[0]['VR'];
		   }
		   else
		   {
		       $VR_ARRAY_VALUE=''; 
		   }

           
		   
		   }
		   		     elseif($sensorModel =='EM6400'){
           /********************   SCHNIDER ELECTRIC (EM6400)   *********************/
		   
           $Va_apparent_power=$str_arr[0];  //date post in database with calculated data from watts to kilo watts
		   $kva=$Va_apparent_power/1000; 
		   $W_active_power=$str_arr[1];  //date post in database with calculated data from watts to kilo watts
		   $kw=$W_active_power/1000; 
		   $Var_reactive_power=$str_arr[2];  //date post in database with calculated data from watts to kilo watts
		   $kVar=$Var_reactive_power/1000; 
		   $pf_avg_pf=$str_arr[3];
		   $Vll_line_avg_voltage=$str_arr[4];
		   $Vln_neutral_voltage=$str_arr[5];
		   $A_avg_current=$str_arr[6];
		   $F_frequency=$str_arr[7];
		   $VA1_apparent_power=$str_arr[8];
		   $W1_active_power=$str_arr[9];
		   $Var1_reactive_power=$str_arr[10];
		   $PF1_pf=$str_arr[11];
		   $V12_voltage=$str_arr[12];
		   $V1_voltage=$str_arr[13];
		   $A1_current=$str_arr[14];
		   $VA2_apparent_power=$str_arr[15];
		   $W2_active_power=$str_arr[16];
		   $Var2_reactive_power=$str_arr[17];
		   $PF2_pf=$str_arr[18];
		   $V23_voltage=$str_arr[19];
		   $V2_voltage=$str_arr[20];
		   $A2_current=$str_arr[21];
		   $VA3_apparent_power=$str_arr[22];
		   $W3_active_power=$str_arr[23];
		   $Var3_reactive_power=$str_arr[24];
		   $PF3_pf=$str_arr[25];
		   $V31_voltage=$str_arr[26];
		   $V3_voltage=$str_arr[27];
		   $A3_current=$str_arr[28];
		   /*******************************/
 $Fwd_vah=$str_arr[29];
		  // $Fwd_kvah=$Fwd_vah/1000;
		   $Fwd_wh=$str_arr[30];
		   $Fwd_kwh=$Fwd_wh/1000;
		   $Fwd_varh_inductive=$str_arr[31];
		 //  $Fwd_kvarh_inductive=$Fwd_varh_inductive/1000;
		   $Fwd_varh_capacitive=$str_arr[32];
		 //  $Fwd_kvarh_capacitive=$Fwd_varh_capacitive/1000;
		   $Rev_vah=$str_arr[33];
		 //  $Rev_kvah=$Rev_vah/1000;
		   $Rev_wh=$str_arr[34];
		  // $Rev_kwh=$Rev_wh/1000;
		   $Rev_varh_inductive=$str_arr[35];
		//   $Rev_kvarh_inductive=$Rev_varh_inductive/1000;
		   $Rev_varh_capacitive=$str_arr[36];
		//   $Rev_kvarh_capacitive=$Rev_varh_capacitive/1000;
		   $Present_demand=$str_arr[37];
		   $Rising_demand=$str_arr[38];
		   $Max_md=$str_arr[39];
		   $Max_dm_occurrence_time=$str_arr[40];
		   $On_hrs=$str_arr[41];
		   $Fwdrun_secs=$str_arr[42];
		   $Revrun_secs=$str_arr[43];
		   $Intr_number_of_power_interruption=$str_arr[44];
		   $percent_v1_voltage_thd=$str_arr[45];
		   $percent_v2_voltage_thd=$str_arr[46];
		   $percent_v3_voltage_thd=$str_arr[47];
		   $percent_v4_voltage_thd=$str_arr[48];
		   $percent_v5_voltage_thd=$str_arr[49];
			
           
           $R_VOLTAGE=$V1_voltage;
           $Y_VOLTAGE=$V2_voltage;
           $B_VOLTAGE=$V3_voltage;
		   $RY_VOLTAGE=$V12_voltage;
		   $YB_VOLTAGE=$V23_voltage;
		   $BR_VOLTAGE=$V31_voltage;
		   $R_CURRENT=$A1_current;
		   $Y_CURRENT=$A2_current;
		   $B_CURRENT=$A3_current;
		   $SUM_KVA=$kva;
		   $SUM_KW=$kw;
		   $SUM_KVAR=$kVar;
		   $SUM_PF=$pf_avg_pf;
		   $FREQUENCY=$F_frequency; 
		   $KWH_MSB='';
		   $KWH_LSB='';
		   $KWH=$Fwd_kwh;
		   $METER_TYPE_RUN_HOUR_MSB='';
		   $RUN_HOUR_LSB='';
		   $RUN_HOUR='';
		   $IMPORT_EXPORT='';
		   $DG_KWH='';
		   $DG_KVAH='';
		   $DG_Run_Hour='';
		   $DG_Run_Min='';
		   $EB_DG_Status='EB';
           
		   if(isset($input[0]['VR'])){
		       $VR_ARRAY_VALUE=$input[0]['VR'];
		   }
		   else
		   {
		       $VR_ARRAY_VALUE=''; 
		   }

           }
            elseif($sensorModel =='SE100'){
           /********************   SECURE ELITE 100 (SE100)   *********************/
		     
		   if($elementCount>=2){
           /********************   SECURE ELITE 100 (SE100)   *********************/
		   for ($x =0; $x < $elementCount; $x++) {
			   if($input[$x]['ST']=='100'){
					$arrRemoveFirstSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
					$firstSegment= explode (",", $arrRemoveFirstSegment); 
		   
           $V1_Voltage=$firstSegment[0];  //date post in database with calculated data from watts to kilo watts
		   $V2_Voltage=$firstSegment[1]; 
		   $V3_Voltage=$firstSegment[2];  //date post in database with calculated data from watts to kilo watts
		   $V_avg_Voltage=$firstSegment[3]; 
		   $V12_Voltage=$firstSegment[4];  //date post in database with calculated data from watts to kilo watts
		   $V23_Voltage=$firstSegment[5]; 
		   $V31_Voltage=$firstSegment[6];
		   $L1_Current=$firstSegment[7];
		   $L2_Current=$firstSegment[8];
		   $L3_Current=$firstSegment[9];
		   $LN_Current=$firstSegment[10];
		   $Reserved1=$firstSegment[11];
		   $Reserved2=$firstSegment[12];
		   $Reserved3=$firstSegment[13];
		   $Reserved4=$firstSegment[14];
		   $Reserved5=$firstSegment[15];
		   $Reserved6=$firstSegment[16];
		   $Phase1=$firstSegment[17];
		   $Phase2=$firstSegment[18];
		   $Phase3=$firstSegment[19];
		   $Phase_avg_PF=$firstSegment[20];
		   $R_Phase_Active_Power=$firstSegment[21];
		   $Y_Phase_Active_Power=$firstSegment[22];
		   $B_Phase_Active_Power=$firstSegment[23];
		   $Three_Phase_Active_Power=$firstSegment[24];
		   $R_Phase_Reactive_Power=$firstSegment[25];
		   $Y_Phase_Reactive_Power=$firstSegment[26];
		   $B_Phase_Reactive_Power=$firstSegment[27];
		   $Three_Phase_Reactive_Power=$firstSegment[28];
		   $R_Phase_Apparent_Power=$firstSegment[29];
		   $Y_Phase_Apparent_Power=$firstSegment[30];
		   $B_Phase_Apparent_Power=$firstSegment[31];
		   $Three_Phase_Apparent_Power=$firstSegment[32];
		   $R_Angle_Phase=$firstSegment[33];
		   $Y_Angle_Phase=$firstSegment[34];
		   $B_Angle_Phase=$firstSegment[35];
		   $Frequency_Hz=$firstSegment[36];
		   $Reserved7=$firstSegment[37];
		   $Reserved8=$firstSegment[38];
		   $R_Phase_Voltage_THD=$firstSegment[39];
		   $Y_Phase_Voltage_THD=$firstSegment[40];
		   $B_Phase_Voltage_THD=$firstSegment[41];
		   $R_Phase_Current_THD=$firstSegment[42];
		   $Y_Phase_Current_THD=$firstSegment[43];
		   $B_Phase_Current_THD=$firstSegment[44];
		   /*******************************/

			} elseif($input[$x]['ST']=='200'){
					$arrRemoveSecondSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
					$secondSegment= explode (",", $arrRemoveSecondSegment); 
					
		   $Active_Total_Import=$secondSegment[0];  //date post in database with calculated data from watts to kilo watts
		   $Active_Total_Export=$secondSegment[1]; 
		   $Active_NET=$secondSegment[2];  //date post in database with calculated data from watts to kilo watts
		   $Reserved9=$secondSegment[3]; 
		   $Reserved10=$secondSegment[4];  //date post in database with calculated data from watts to kilo watts
		   $Reserved11=$secondSegment[5]; 
		   $Reserved12=$secondSegment[6];
		   $Reserved13=$secondSegment[7];
		   $Apparent_Active_Import=$secondSegment[8];
		   $Apparent_Active_Export=$secondSegment[9];
		   $Reactive_Import=$secondSegment[10];
		   $Reactive_Export=$secondSegment[11];
		   $Active_Forwarded=$secondSegment[12];
		   $Apparent_Forwarded=$secondSegment[13];
		   $Reactive_Lag_Forwarded=$secondSegment[14];
		   $Reactive_Lead_Forwarded=$secondSegment[15];
		   $Active_Gross_Import=$secondSegment[16];
		   $Active_Gross_Export=$secondSegment[17];
					
					}
           }
           $R_VOLTAGE=$V1_Voltage;
           $Y_VOLTAGE=$V2_Voltage;
           $B_VOLTAGE=$V3_Voltage;
		   $RY_VOLTAGE=$V12_Voltage;
		   $YB_VOLTAGE=$V23_Voltage;
		   $BR_VOLTAGE=$V31_Voltage;
		   $R_CURRENT=$L1_Current;
		   $Y_CURRENT=$L2_Current;
		   $B_CURRENT=$L3_Current;
		   $SUM_KVA=$Three_Phase_Apparent_Power/1000;
		   $SUM_KW=$Three_Phase_Active_Power/1000;
		   $SUM_KVAR=$Three_Phase_Reactive_Power/1000;
		   $SUM_PF=$Phase_avg_PF;
		   $FREQUENCY=$Frequency_Hz; 
		   $KWH_MSB='';
		   $KWH_LSB='';
		   $KWH=$Active_Total_Import/1000;
		   $METER_TYPE_RUN_HOUR_MSB='';
		   $RUN_HOUR_LSB='';
		   $RUN_HOUR='';
		   $IMPORT_EXPORT=$Active_NET;
		   $DG_KWH='';
		   $DG_KVAH='';
		   $DG_Run_Hour='';
		   $DG_Run_Min='';
		   $EB_DG_Status='EB';
          // echo $KWH."< kwh value<br> "; 
			   if(isset($input[0]['VR'])){
				   $VR_ARRAY_VALUE=$input[0]['VR'];
			   }
			   else
			   {
				   $VR_ARRAY_VALUE=''; 
			   }

           }
		   else{
			exit;
		   }
          }

          // $temp_c=$str_arr[0];
          // $temp_f=$str_arr[1];
          // $hum=$str_arr[2];
          
          
               $liuxTimeStamp=$input[0]['TS'];
           
		 
          if($liuxTimeStamp !="XXXXXX")
          {
              $recordedTimeStamp = date("Y-m-d H:i:s",$input[0]['TS']);
              $telDate =$input[0]['DT'];
              $teltonika_date = str_replace('/', '-', $telDate);
              $teltonikaTimeStamp =  date('Y-m-d H:i:s', strtotime($teltonika_date));
          }
          else
          {
              $liuxTimeStamp='';
              $recordedTimeStamp = ''; 
			  $teltonikaTimeStamp='';
          
          }
           
    // $sql= "INSERT INTO `energy_data_master`(`gateway_code`, `sensor_code`, `sensor_model`,`R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`, `SUM_PF`, `FREQUENCY`, `KWH_MSB`, `KWH_LSB`, `KWH`, `METER_TYPE_RUN_HOUR_MSB`, `RUN_HOUR_LSB`, `RUN_HOUR`, `IMPORT_EXPORT`,`VR_ARRAY_VALUE`,`linux_date_time`,`teltonika_date_time`, `recorded_date_time`, `posted_date_time`) VALUES ('".$gatewayCode."','".$sensorCode."','".$sensorModel."','".$R_VOLTAGE."','".$Y_VOLTAGE."','".$B_VOLTAGE."','".$RY_VOLTAGE."','".$YB_VOLTAGE."','".$BR_VOLTAGE."','".$R_CURRENT."','".$Y_CURRENT."','".$B_CURRENT."','".$SUM_KVA."','".$SUM_KW."','".$SUM_KVAR."','".$SUM_PF."','".$FREQUENCY."','".$KWH_MSB."','".$KWH_LSB."','".$KWH."','".$METER_TYPE_RUN_HOUR_MSB."','".$RUN_HOUR_LSB."','".$RUN_HOUR."','".$IMPORT_EXPORT."','".$inputJSON."','".$liuxTimeStamp."',DATE_ADD('".$teltonikaTimeStamp."',INTERVAL '05:30' HOUR_MINUTE),DATE_ADD(FROM_UNIXTIME('".$liuxTimeStamp."','%Y-%m-%d %h:%i:%s'),INTERVAL '12:30' HOUR_MINUTE), DATE_ADD(NOW(),INTERVAL '12:30' HOUR_MINUTE))";
	
	 if($sensorModel =='TEP'){
	 $sql= " INSERT INTO `energy_data_master`(`gateway_code`, `sensor_code`, `sensor_model`,`R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`, `SUM_PF`, `FREQUENCY`, `KWH`,`KVAH`, `DG_KWH`, `DG_KVAH`,`EB_DG_STATUS`, `VR_ARRAY_VALUE`, `AVG_VPN`, `AVG_VPP`, `AVG_I`, `PF_R`, `PF_Y`, `PF_B`, `KW_R`, `KW_Y`, `KW_B`, `KVAR_R`, `KVAR_Y`, `KVAR_B`, `KVA_R`, `KVA_Y`, `KVA_B`, `KW_RISING_DEMAND`, `KW_MAX_DEMAND`, `KVA_RISING_DEMAND`, `KVA_MAX_DEMAND`, `DG_KVARH`, `EB_KWH`, `EB_KVARH`, `EB_KVAH`, `3RD_HVR`, `5TH_HVR`, `7TH_HVR`, `9TH_HVR`, `11TH_HVR`, `13TH_HVR`, `15TH_HVR`, `THD_VR`, `3RD_HIR`, `5TH_HIR`, `7TH_HIR`, `9TH_HIR`, `11TH_HIR`, `13TH_HIR`, `15TH_HIR`, `THD_IR`, `3RD_HVY`, `5TH_HVY`, `7TH_HVY`, `9TH_HVY`, `11TH_HVY`, `13TH_HVY`, `15TH_HVY`, `THD_VY`, `3RD_HIY`, `5TH_HIY`, `7TH_HIY`, `9TH_HIY`, `11TH_HIY`, `13TH_HIY`, `15TH_HIY`, `THD_IY`, `3RD_HVB`, `5TH_HVB`, `7TH_HVB`, `9TH_HVB`, `11TH_HVB`, `13TH_HVB`, `15TH_HVB`, `THD_VB`, `3RD_HIB`, `5TH_HIB`, `7TH_HIB`, `9TH_HIB`, `11TH_HIB`, `13TH_HIB`, `15TH_HIB`, `THD_IB`, `DG_STATUS`, `linux_date_time`, `teltonika_date_time`, `recorded_date_time`, `posted_date_time`) VALUES ('".$gatewayCode."','".$sensorCode."','".$sensorModel."','".$Vrn."','".$Vyn."','".$Vbn."','".$Vry."','".$Vyb."','".$Vbr."','".$Ir."','".$Iy."','".$Ib."','".$System_KVA."','".$System_KW."','".$System_KVAR."','".$System_PF."','".$Frequency."','".$EB_KWh."','".$KVAh."','".$DG_KWh."','".$DG_KVAh."','".$DG_Status."','".$inputJSON."','".$Avg_Vpn."','".$Avg_Vpp."','".$Avg_I."','".$PF_R."','".$PF_Y."','".$PF_B."','".$KW_R."','".$KW_Y."','".$KW_B."','".$KVAR_R."','".$KVAR_Y."','".$KVAR_B."','".$KVA_R."','".$KVA_Y."','".$KVA_B."','".$KW_Rising_Demand."','".$KW_Max_Demand."','".$KVA_Rising_Demand."','".$KVA_Max_Demand."','".$DG_KVARh."','".$EB_KWh."','".$EB_KVARh."','".$EB_KVAh."','".$_3rd_HVr."','".$_5th_HVr."','".$_7th_HVr."','".$_9th_HVr."','".$_11th_HVr."','".$_13th_HVr."','".$_15th_HVr."','".$THD_Vr."','".$_3rd_HIr."','".$_5th_HIr."','".$_7th_HIr."','".$_9th_HIr."','".$_11th_HIr."','".$_13th_HIr."','".$_15th_HIr."','".$THD_Ir."','".$_3rd_HVy."','".$_5th_HVy."','".$_7th_HVy."','".$_9th_HVy."','".$_11th_HVy."','".$_13th_HVy."','".$_15th_HVy."','".$THD_Vy."','".$_3rd_HIy."','".$_5th_HIy."','".$_7th_HIy."','".$_9th_HIy."','".$_11th_HIy."','".$_13th_HIy."','".$_15th_HIy."','".$THD_Iy."','".$_3rd_HVb."','".$_5th_HVb."','".$_7th_HVb."','".$_9th_HVb."','".$_11th_HVb."','".$_13th_HVb."','".$_15th_HVb."','".$THD_Vb."','".$_3rd_HIb."','".$_5th_HIb."','".$_7th_HIb."','".$_9th_HIb."','".$_11th_HIb."','".$_13th_HIb."','".$_15th_HIb."','".$THD_Ib."','".$DG_Status."','".$liuxTimeStamp."','".$input[0]['DT']."','".$teltonikaTimeStamp."',NOW())";
    }else{
       $sql= "INSERT INTO `energy_data_master`(`gateway_code`, `sensor_code`, `sensor_model`,`R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`, `SUM_PF`, `FREQUENCY`, `KWH_MSB`, `KWH_LSB`, `KWH`, `EB_KVAH`,`METER_TYPE_RUN_HOUR_MSB`, `RUN_HOUR_LSB`, `RUN_HOUR`, `IMPORT_EXPORT`, `DG_KWH`, `DG_KVAH`, `DG_RUN_HOUR`, `DG_RUN_MIN`, `EB_DG_STATUS`,`Voltage_DC`,`Current_DC1`,`Watts_DC1`,`Wh_DC1`,`Load_Hours_DC1`,`Amps_Hours_DC1`,`VR_ARRAY_VALUE`,`linux_date_time`,`teltonika_date_time`, `recorded_date_time`, `posted_date_time`) VALUES ('".$gatewayCode."','".$sensorCode."','".$sensorModel."','".$R_VOLTAGE."','".$Y_VOLTAGE."','".$B_VOLTAGE."','".$RY_VOLTAGE."','".$YB_VOLTAGE."','".$BR_VOLTAGE."','".$R_CURRENT."','".$Y_CURRENT."','".$B_CURRENT."','".$SUM_KVA."','".$SUM_KW."','".$SUM_KVAR."','".$SUM_PF."','".$FREQUENCY."','".$KWH_MSB."','".$KWH_LSB."','".$KWH."','".$KVAh."','".$METER_TYPE_RUN_HOUR_MSB."','".$RUN_HOUR_LSB."','".$RUN_HOUR."','".$IMPORT_EXPORT."','".$DG_KWH."','".$DG_KVAH."','".$DG_Run_Hour."','".$DG_Run_Min."','".$EB_DG_Status."','".$Voltage_DC."','".$Current_DC1."','".$Watts_DC1."','".$Wh_DC1."','".$Load_Hours_DC1."','".$Amps_Hours_DC1."','".$inputJSON."','".$liuxTimeStamp."','".$input[0]['DT']."','".$teltonikaTimeStamp."', NOW())";
	  }
	   
        $insSel = $conn->query($sql);
     
        
        if ($insSel === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
       
	   $selectView= "SELECT * FROM `energy_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."'";
       $resultView = mysqli_query($conn, $selectView);
	   $rowcount=mysqli_num_rows($resultView);
	   if($rowcount==0){

			if($sensorModel =='TEP'){
		 $sql2= " INSERT INTO `energy_data_master_view`(`gateway_code`, `sensor_code`, `sensor_model`,`R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`, `SUM_PF`, `FREQUENCY`, `KWH`,`KVAH`, `DG_KWH`, `DG_KVAH`,`EB_DG_STATUS`, `VR_ARRAY_VALUE`, `AVG_VPN`, `AVG_VPP`, `AVG_I`, `PF_R`, `PF_Y`, `PF_B`, `KW_R`, `KW_Y`, `KW_B`, `KVAR_R`, `KVAR_Y`, `KVAR_B`, `KVA_R`, `KVA_Y`, `KVA_B`, `KW_RISING_DEMAND`, `KW_MAX_DEMAND`, `KVA_RISING_DEMAND`, `KVA_MAX_DEMAND`, `DG_KVARH`, `EB_KWH`, `EB_KVARH`, `EB_KVAH`, `3RD_HVR`, `5TH_HVR`, `7TH_HVR`, `9TH_HVR`, `11TH_HVR`, `13TH_HVR`, `15TH_HVR`, `THD_VR`, `3RD_HIR`, `5TH_HIR`, `7TH_HIR`, `9TH_HIR`, `11TH_HIR`, `13TH_HIR`, `15TH_HIR`, `THD_IR`, `3RD_HVY`, `5TH_HVY`, `7TH_HVY`, `9TH_HVY`, `11TH_HVY`, `13TH_HVY`, `15TH_HVY`, `THD_VY`, `3RD_HIY`, `5TH_HIY`, `7TH_HIY`, `9TH_HIY`, `11TH_HIY`, `13TH_HIY`, `15TH_HIY`, `THD_IY`, `3RD_HVB`, `5TH_HVB`, `7TH_HVB`, `9TH_HVB`, `11TH_HVB`, `13TH_HVB`, `15TH_HVB`, `THD_VB`, `3RD_HIB`, `5TH_HIB`, `7TH_HIB`, `9TH_HIB`, `11TH_HIB`, `13TH_HIB`, `15TH_HIB`, `THD_IB`, `DG_STATUS`, `linux_date_time`, `teltonika_date_time`, `recorded_date_time`, `posted_date_time`) VALUES ('".$gatewayCode."','".$sensorCode."','".$sensorModel."','".$Vrn."','".$Vyn."','".$Vbn."','".$Vry."','".$Vyb."','".$Vbr."','".$Ir."','".$Iy."','".$Ib."','".$System_KVA."','".$System_KW."','".$System_KVAR."','".$System_PF."','".$Frequency."','".$EB_KWh."','".$KVAh."','".$DG_KWh."','".$DG_KVAh."','".$DG_Status."','".$inputJSON."','".$Avg_Vpn."','".$Avg_Vpp."','".$Avg_I."','".$PF_R."','".$PF_Y."','".$PF_B."','".$KW_R."','".$KW_Y."','".$KW_B."','".$KVAR_R."','".$KVAR_Y."','".$KVAR_B."','".$KVA_R."','".$KVA_Y."','".$KVA_B."','".$KW_Rising_Demand."','".$KW_Max_Demand."','".$KVA_Rising_Demand."','".$KVA_Max_Demand."','".$DG_KVARh."','".$EB_KWh."','".$EB_KVARh."','".$EB_KVAh."','".$_3rd_HVr."','".$_5th_HVr."','".$_7th_HVr."','".$_9th_HVr."','".$_11th_HVr."','".$_13th_HVr."','".$_15th_HVr."','".$THD_Vr."','".$_3rd_HIr."','".$_5th_HIr."','".$_7th_HIr."','".$_9th_HIr."','".$_11th_HIr."','".$_13th_HIr."','".$_15th_HIr."','".$THD_Ir."','".$_3rd_HVy."','".$_5th_HVy."','".$_7th_HVy."','".$_9th_HVy."','".$_11th_HVy."','".$_13th_HVy."','".$_15th_HVy."','".$THD_Vy."','".$_3rd_HIy."','".$_5th_HIy."','".$_7th_HIy."','".$_9th_HIy."','".$_11th_HIy."','".$_13th_HIy."','".$_15th_HIy."','".$THD_Iy."','".$_3rd_HVb."','".$_5th_HVb."','".$_7th_HVb."','".$_9th_HVb."','".$_11th_HVb."','".$_13th_HVb."','".$_15th_HVb."','".$THD_Vb."','".$_3rd_HIb."','".$_5th_HIb."','".$_7th_HIb."','".$_9th_HIb."','".$_11th_HIb."','".$_13th_HIb."','".$_15th_HIb."','".$THD_Ib."','".$DG_Status."','".$liuxTimeStamp."','".$input[0]['DT']."','".$teltonikaTimeStamp."',NOW())";
		}else{
				   $sql2= "INSERT INTO `energy_data_master_view`(`gateway_code`, `sensor_code`, `sensor_model`,`R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`, `SUM_PF`, `FREQUENCY`, `KWH_MSB`, `KWH_LSB`, `KWH`, `KVAH`,`METER_TYPE_RUN_HOUR_MSB`, `RUN_HOUR_LSB`, `RUN_HOUR`, `IMPORT_EXPORT`, `DG_KWH`, `DG_KVAH`, `DG_RUN_HOUR`, `DG_RUN_MIN`, `EB_DG_STATUS`,`Voltage_DC`,`Current_DC1`,`Watts_DC1`,`Wh_DC1`,`Load_Hours_DC1`,`Amps_Hours_DC1`,`VR_ARRAY_VALUE`,`linux_date_time`,`teltonika_date_time`, `recorded_date_time`, `posted_date_time`) VALUES ('".$gatewayCode."','".$sensorCode."','".$sensorModel."','".$R_VOLTAGE."','".$Y_VOLTAGE."','".$B_VOLTAGE."','".$RY_VOLTAGE."','".$YB_VOLTAGE."','".$BR_VOLTAGE."','".$R_CURRENT."','".$Y_CURRENT."','".$B_CURRENT."','".$SUM_KVA."','".$SUM_KW."','".$SUM_KVAR."','".$SUM_PF."','".$FREQUENCY."','".$KWH_MSB."','".$KWH_LSB."','".$KWH."','".$KVAh."','".$METER_TYPE_RUN_HOUR_MSB."','".$RUN_HOUR_LSB."','".$RUN_HOUR."','".$IMPORT_EXPORT."','".$DG_KWH."','".$DG_KVAH."','".$DG_Run_Hour."','".$DG_Run_Min."','".$EB_DG_Status."','".$Voltage_DC."','".$Current_DC1."','".$Watts_DC1."','".$Wh_DC1."','".$Load_Hours_DC1."','".$Amps_Hours_DC1."','".$inputJSON."','".$liuxTimeStamp."','".$input[0]['DT']."','".$teltonikaTimeStamp."', NOW())";
				  }
      }else{
		   		if($sensorModel =='TEP')
		  		 {
					 $sql2= " UPDATE `energy_data_master_view` SET `R_VOLTAGE`='".$Vrn."', `Y_VOLTAGE`='".$Vyn."', `B_VOLTAGE`='".$Vbn."', `RY_VOLTAGE`='".$Vry."', `YB_VOLTAGE`='".$Vyb."', `BR_VOLTAGE`='".$Vbr."', `R_CURRENT`='".$Ir."', `Y_CURRENT`='".$Iy."', `B_CURRENT`='".$Ib."', `SUM_KVA`='".$System_KVA."', `SUM_KW`='".$System_KW."', `SUM_KVAR`='".$System_KVAR."', `SUM_PF`='".$System_PF."', `FREQUENCY`='".$Frequency."', `KWH`='".$EB_KWh."',`KVAH`='".$KVAh."', `DG_KWH`='".$DG_KWh."', `DG_KVAH`='".$DG_KVAh."',`EB_DG_STATUS`='".$DG_Status."', `VR_ARRAY_VALUE`='".$inputJSON."', `AVG_VPN`='".$Avg_Vpn."', `AVG_VPP`='".$Avg_Vpp."', `AVG_I`='".$Avg_I."', `PF_R`='".$PF_R."', `PF_Y`='".$PF_Y."', `PF_B`='".$PF_B."', `KW_R`='".$KW_R."', `KW_Y`='".$KW_Y."', `KW_B`='".$KW_B."', `KVAR_R`='".$KVAR_R."', `KVAR_Y`='".$KVAR_Y."', `KVAR_B`='".$KVAR_B."', `KVA_R`='".$KVA_R."', `KVA_Y`='".$KVA_Y."', `KVA_B`='".$KVA_B."', `KW_RISING_DEMAND`='".$KW_Rising_Demand."', `KW_MAX_DEMAND`='".$KW_Max_Demand."', `KVA_RISING_DEMAND`='".$KVA_Rising_Demand."', `KVA_MAX_DEMAND`='".$KVA_Max_Demand."', `DG_KVARH`='".$DG_KVARh."', `EB_KWH`='".$EB_KWh."', `EB_KVARH`='".$EB_KVARh."',`EB_KVAH`='".$EB_KVAh."', `3RD_HVR`='".$_3rd_HVr."', `5TH_HVR`='".$_5th_HVr."', `7TH_HVR`='".$_7th_HVr."', `9TH_HVR`='".$_9th_HVr."', `11TH_HVR`='".$_11th_HVr."', `13TH_HVR`='".$_13th_HVr."', `15TH_HVR`='".$_15th_HVr."', `THD_VR`='".$THD_Vr."', `3RD_HIR`='".$_3rd_HIr."', `5TH_HIR`='".$_5th_HIr."', `7TH_HIR`='".$_7th_HIr."', `9TH_HIR`='".$_9th_HIr."', `11TH_HIR`='".$_11th_HIr."', `13TH_HIR`='".$_13th_HIr."', `15TH_HIR`='".$_15th_HIr."', `THD_IR`='".$THD_Ir."', `3RD_HVY`='".$_3rd_HVy."', `5TH_HVY`='".$_5th_HVy."', `7TH_HVY`='".$_7th_HVy."', `9TH_HVY`='".$_9th_HVy."', `11TH_HVY`='".$_11th_HVy."', `13TH_HVY`='".$_13th_HVy."', `15TH_HVY`='".$_15th_HVy."',`THD_VY`='".$THD_Vy."', `3RD_HIY`='".$_3rd_HIy."', `5TH_HIY`='".$_5th_HIy."', `7TH_HIY`='".$_7th_HIy."', `9TH_HIY`='".$_9th_HIy."', `11TH_HIY`='".$_11th_HIy."', `13TH_HIY`='".$_13th_HIy."', `15TH_HIY`='".$_15th_HIy."', `THD_IY`='".$THD_Iy."', `3RD_HVB`='".$_3rd_HVb."', `5TH_HVB`='".$_5th_HVb."', `7TH_HVB`='".$_7th_HVb."', `9TH_HVB`='".$_9th_HVb."', `11TH_HVB`='".$_11th_HVb."', `13TH_HVB`='".$_13th_HVb."', `15TH_HVB`='".$_15th_HVb."', `THD_VB`='".$THD_Vb."', `3RD_HIB`='".$_3rd_HIb."', `5TH_HIB`='".$_5th_HIb."', `7TH_HIB`= '".$_7th_HIb."',`9TH_HIB`='".$_9th_HIb."', `11TH_HIB`='".$_11th_HIb."', `13TH_HIB`='".$_13th_HIb."', `15TH_HIB`='".$_15th_HIb."', `THD_IB`='".$THD_Ib."', `DG_STATUS`='".$DG_Status."', `linux_date_time`='".$liuxTimeStamp."', `teltonika_date_time`='".$input[0]['DT']."', `recorded_date_time`='".$teltonikaTimeStamp."', `posted_date_time`=NOW()  WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."'";
				}
				else
				{
					  $sql2= "UPDATE `energy_data_master_view` SET `R_VOLTAGE`='".$R_VOLTAGE."',`Y_VOLTAGE`='".$Y_VOLTAGE."',B_VOLTAGE='".$B_VOLTAGE."', `RY_VOLTAGE`='".$RY_VOLTAGE."', `YB_VOLTAGE`='".$YB_VOLTAGE."', `BR_VOLTAGE`='".$BR_VOLTAGE."', `R_CURRENT`='".$R_CURRENT."', `Y_CURRENT`='".$Y_CURRENT."', `B_CURRENT`='".$B_CURRENT."', `SUM_KVA`='".$SUM_KVA."', `SUM_KW`='".$SUM_KW."', `SUM_KVAR`='".$SUM_KVAR."', `SUM_PF`='".$SUM_PF."', `FREQUENCY`='".$FREQUENCY."', `KWH_MSB`='".$KWH_MSB."', `KWH_LSB`='".$KWH_LSB."', `KWH`='".$KWH."', `KVAH`='".$KVAh."',`METER_TYPE_RUN_HOUR_MSB`='".$METER_TYPE_RUN_HOUR_MSB."', `RUN_HOUR_LSB`='".$RUN_HOUR_LSB."', `RUN_HOUR`='".$RUN_HOUR."', `IMPORT_EXPORT`='".$IMPORT_EXPORT."',`DG_KWH`='".$DG_KWH."',`DG_KVAH`='".$DG_KVAH."',`DG_RUN_HOUR`='".$DG_Run_Hour."',`DG_RUN_MIN`='".$DG_Run_Min."',`EB_DG_STATUS`='".$EB_DG_Status."',Voltage_DC='".$Voltage_DC."',Current_DC1='".$Current_DC1."',Watts_DC1='".$Watts_DC1."',Wh_DC1='".$Wh_DC1."',Load_Hours_DC1='".$Load_Hours_DC1."',Amps_Hours_DC1='".$Amps_Hours_DC1."',`VR_ARRAY_VALUE`='".$inputJSON."',`linux_date_time`='".$liuxTimeStamp."',`teltonika_date_time`='".$input[0]['DT']."', `recorded_date_time`='".$teltonikaTimeStamp."', `posted_date_time`=NOW() WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."'";
				}

	  
	  }
        $insSel2 = $conn->query($sql2);
     
        
        if ($insSel2 === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $sql2 . "<br>" . $conn->error;
        }
				/****************     Cron Data Post            **********************/
		$deliverytime = new DateTime(date($teltonikaTimeStamp));
		//echo $teltonikaTimeStamp; 
		//echo $deliverytime->format('H');exit;
		$hour = $deliverytime->format('H');
		$hour=intval($hour);
		if ($hour >= 0 && $hour <8) {
			$date=date_create(date('Y-m-d'));
			date_sub($date,date_interval_create_from_date_string("1 days"));
			$currDate=date_format($date,"Y-m-d");
			$date2=date_create($currDate);
			date_sub($date2,date_interval_create_from_date_string("1 days"));
			$prevDate=date_format($date2,"Y-m-d");
		} else {
			
			$currDate=date('Y-m-d');
			$date2=date_create($currDate);
			date_sub($date2,date_interval_create_from_date_string("1 days"));
			$prevDate=date_format($date2,"Y-m-d");
		}
		
		/******************    Cron Hourly Report Starts      *******************/
		
		if($hour >= 0 && $hour <1){
		$hourname='12 AM to 01 AM';
		
		}
		elseif($hour >= 1 && $hour <2){
		$hourname='01 AM to 02 AM';
		}
		elseif($hour >= 2 && $hour <3){
		$hourname='02 AM to 03 AM';
		}
		elseif($hour >= 3 && $hour <4){
		$hourname='03 AM to 04 AM';
		}
		elseif($hour >= 4 && $hour <5){
		$hourname='04 AM to 05 AM';
		}
		elseif($hour >= 5 && $hour <6){
		$hourname='05 AM to 06 AM';
		}
		elseif($hour >= 6 && $hour <7){
		$hourname='06 AM to 07 AM';
		}
		elseif($hour >= 7 && $hour <8){
		$hourname='07 AM to 08 AM';
		}
		elseif($hour >= 8 && $hour <9){
		$hourname='08 AM to 09 AM';
		}
		elseif($hour >= 9 && $hour <10){
		$hourname='09 AM to 10 AM';
		}
		elseif($hour >= 10 && $hour <11){
		$hourname='10 AM to 11 AM';
		}
		elseif($hour >= 11 && $hour <12){
		$hourname='11 AM to 12 PM';
		}
		elseif($hour >= 12 && $hour <13){
		$hourname='12 PM to 01 PM';
		}
		elseif($hour >= 13 && $hour <14){
		$hourname='01 PM to 02 PM';
		}
		elseif($hour >= 14 && $hour <15){
		$hourname='02 PM to 03 PM';
		}
		elseif($hour >= 15 && $hour <16){
		$hourname='03 PM to 04 PM';
		}
		elseif($hour >= 16 && $hour <17){
		$hourname='04 PM to 05 PM';
		}
		elseif($hour >= 17 && $hour <18){
		$hourname='05 PM to 06 PM';
		}
		elseif($hour >= 18 && $hour <19){
		$hourname='06 PM to 07 PM';
		}
		elseif($hour >= 19 && $hour <20){
		$hourname='07 PM to 08 PM';
		}
		elseif($hour >= 20 && $hour <21){
		$hourname='08 PM to 09 PM';
		}
		elseif($hour >= 21 && $hour <22){
		$hourname='09 PM to 10 PM';
		}
		elseif($hour >= 22 && $hour <23){
		$hourname='10 PM to 11 PM';
		}
		elseif($hour >= 23 && $hour <0){
		$hourname='11 PM to 12 AM';
		}
		
		/******************    Cron Hourly Report Starts      *******************/
		
		//echo $currDate."Curr Date <br>";
		//echo $prevDate."Prvi Date <br>";
		/******** Current Date Start *********/
		
		$selCronData="SELECT * FROM `cron_daily_energy_data` WHERE sensor_code='".$sensorCode."' AND recorded_date='".$currDate."'";
		$exeCronSel = mysqli_query($conn, $selCronData);
		$cronDataFet = mysqli_fetch_assoc($exeCronSel);
		$cronDataCount = mysqli_num_rows($exeCronSel);
		
		/******** Current Date End *********/

		/******** Previuos Date Start *********/
		
		$selCronDataYes="SELECT * FROM `cron_daily_energy_data` WHERE sensor_code='".$sensorCode."' AND recorded_date=DATE_SUB('".$currDate."',INTERVAL 1 DAY)";
		$exeCronSelYes = mysqli_query($conn, $selCronDataYes);
		$cronDataFetYes = mysqli_fetch_assoc($exeCronSelYes);
		$cronDataCountYes = mysqli_num_rows($exeCronSelYes);
		
		/******** Previuos Date End *********/
		
		if($cronDataCount>0){
		
			/**************** EB Condition *****************/

			if($cronDataFet["start_cum_kwh"]>0){
				if($cronDataCountYes>0 && $cronDataFetYes["end_cum_date"]>0){
					//echo "<br> if";
					$startKWH=$cronDataFetYes["end_cum_kwh"];
					$startDate=$cronDataFetYes["end_cum_date"];

				}else{
					$startKWH=$cronDataFet["start_cum_kwh"];
					$startDate=$cronDataFet["start_cum_date"];
					//echo "<br> else<br>";
				}
				$updateSetVal='';
			}
			else{
				if($cronDataCountYes>0 && $cronDataFetYes["end_cum_date"]>0){
					$startKWH=$cronDataFetYes["end_cum_kwh"];
					$startDate=$cronDataFetYes["end_cum_date"];
					//echo "<br> START KWH >".$startKWH."<br>else> if";
				}else{
					$startKWH=$KWH;
					$startDate=$teltonikaTimeStamp;
					//echo "<br>else> else";
				}
				$updateSetVal='start_cum_kwh="'.$startKWH.'", `start_cum_date`="'.$startDate.'", ';
				//echo $KWH."<br>start: ".$startKWH;

			}
			$endKWH=$KWH;
			$endDate=$teltonikaTimeStamp;
			$cost=$sensMasDet["unit_rate"];
			$consuptionKWH=$endKWH-$startKWH;
			$consuptionCost=$consuptionKWH*$cost;
			
			/**************** DG Condition *****************/
			if($cronDataFet["dg_start_cum_kwh"]>0){
				if($cronDataCountYes>0 && $cronDataFetYes["dg_end_cum_date"]>0){
					//echo "<br> if";
					$startDgKWH=$cronDataFetYes["dg_end_cum_kwh"];
					$startDgDate=$cronDataFetYes["dg_end_cum_date"];

				}else{
					$startDgKWH=$cronDataFet["dg_start_cum_kwh"];
					$startDgDate=$cronDataFet["dg_start_cum_date"];
					//echo "<br> else<br>";
				}
				$updateDgSetVal='';
			}
			else{
				if($cronDataCountYes>0 && $cronDataFetYes["dg_end_cum_date"]>0){
					$startDgKWH=$cronDataFetYes["dg_end_cum_kwh"];
					$startDgDate=$cronDataFetYes["dg_end_cum_date"];
					//echo "<br> START KWH >".$startKWH."<br>else> if";
				}else{
					$startDgKWH=$DG_KWH;
					$startDgDate=$teltonikaTimeStamp;
					//echo "<br>else> else";
				}
				$updateDgSetVal=' dg_start_cum_kwh="'.$startDgKWH.'", `dg_start_cum_date`="'.$startDgDate.'", ';
				//echo $KWH."<br>start: ".$startKWH;

			}
			//echo $KWH."<br>start: ".$startKWH;

						
			$endDgKWH=$DG_KWH;
			$endDgDate=$teltonikaTimeStamp;
			$costDg=$sensMasDet["dg_unit_rate"];
			$consuptionDgKWH=$endDgKWH-$startDgKWH;
			$consuptionDgCost=$consuptionDgKWH*$costDg;

			$UpdateCronQry='UPDATE `cron_daily_energy_data` SET '.$updateSetVal.' `feeder_type`="'.$sensMasDet["feeder_type"].'", `end_cum_kwh`="'.$endKWH.'",`end_cum_date`="'.$endDate.'", `consuption_kwh`="'.$consuptionKWH.'", `cost`="'.$sensMasDet["unit_rate"].'", `consuption_cost`="'.$consuptionCost.'", dg_end_cum_kwh="'.$endDgKWH.'",`dg_end_cum_date`="'.$endDgDate.'", dg_consuption_kwh="'.$consuptionDgKWH.'", dg_cost="'.$sensMasDet["dg_unit_rate"].'", dg_consuption_cost="'.$consuptionDgCost.'",`posted_date_time`=NOW(),'.$updateDgSetVal.' `created_by`="API" WHERE `company_id`="'.$sensMasDet["company_id"].'" AND `branch_id`="'.$sensMasDet["branch_id"].'" AND `gateway_code`="'.$sensMasDet["gateway_id"].'" AND sensor_code="'.$sensorCode.'" AND `recorded_date`="'.$currDate.'"';   

			$conn->query($UpdateCronQry);
		
		
		}else{
				/***************   EB Condition Starts     ***********************/
				if($cronDataCountYes>0 && $cronDataFetYes["end_cum_date"] >0){
					$startKWH=$cronDataFetYes["end_cum_kwh"];
					$startDate=$cronDataFetYes["end_cum_date"];

				}else{
					$startKWH=$KWH;
					$startDate=$teltonikaTimeStamp;

				}
				$endKWH=$KWH;
				$endDate=$teltonikaTimeStamp;
				$cost=$sensMasDet["unit_rate"];
				$consuptionKWH=$endKWH-$startKWH;
				$consuptionCost=$consuptionKWH*$cost;

				/***************   DG Condition Starts     ***********************/

				if($cronDataCountYes>0 && $cronDataFetYes["dg_end_cum_date"] >0){
					$startDgKWH=$cronDataFetYes["dg_end_cum_kwh"];
					$startDgDate=$cronDataFetYes["dg_end_cum_date"];

				}else{
					$startDgKWH=$DG_KWH;
					$startDgDate=$teltonikaTimeStamp;

				}
				$endDgKWH=$DG_KWH;
				$endDgDate=$teltonikaTimeStamp;
				$costDg=$sensMasDet["dg_unit_rate"];
				$consuptionDgKWH=$endDgKWH-$startDgKWH;
				$consuptionDgCost=$consuptionDgKWH*$costDg;
					
					
		
			 $insQueryCron="INSERT INTO cron_daily_energy_data (company_id, branch_id, gateway_code, sensor_code, feeder_type, start_cum_kwh, start_cum_date, end_cum_kwh, end_cum_date, consuption_kwh, cost, consuption_cost, recorded_date, dg_start_cum_kwh, dg_start_cum_date, dg_end_cum_kwh, dg_end_cum_date, dg_consuption_kwh, dg_cost, dg_consuption_cost, posted_date_time, created_by) VALUES('".$sensMasDet["company_id"]."','".$sensMasDet["branch_id"]."','".$sensMasDet["gateway_id"]."','".$sensorCode."','".$sensMasDet["feeder_type"]."','".$startKWH."','".$startDate."','".$endKWH."','".$endDate."','".$consuptionKWH."','".$cost."','".$consuptionCost."','".$currDate."','".$startDgKWH."','".$startDgDate."','".$endDgKWH."','".$endDgDate."','".$consuptionDgKWH."','".$costDg."','".$consuptionDgCost."',NOW(),'Cron') ";
			
			$conn->query($insQueryCron);
		}
		
		//exit;
		
		/****************     Cron Data Post            **********************/
		

		
		/*******************************************             Mail Trigger  Starts            ****************************************************/
	   $selAlertCont= "SELECT email FROM `arka_alert_contact_master` WHERE email_alert=1 AND is_active=1 AND `company_id`='".$sensMasDet['company_id']."' AND `branch_id`='".$sensMasDet['branch_id']."'";
       $ExeAlertCont = mysqli_query($conn, $selAlertCont);
	   if (mysqli_num_rows($ExeAlertCont) > 0) 
	   {
			 $alertContact='';
			 while($alertCont = mysqli_fetch_assoc($ExeAlertCont)) 
			{
			// Fetch all
			   $alertContact .= $alertCont['email'].",";
			}
		//	$string = rtrim($string, ".");
			$alertEmail= rtrim($alertContact, ",");
			echo $alertEmail." -- EmailId from Table <br>";
       } 
	   
	echo   $selAlertPar= "SELECT * FROM `alert_parameter_mapping` WHERE `sensor_code`='".$sensorCode."'";
       $ExeAlertPar = mysqli_query($conn, $selAlertPar);
	   
	   if (mysqli_num_rows($ExeAlertPar) > 0) 
	   {
	      echo "alert parameter Mapping";
            while($parameter = mysqli_fetch_assoc($ExeAlertPar)) 
			{ 
			 echo $parameter['parameter_name']."-  Parameter Name <br>";
			  echo $parameter['mail_alert_status'];
				$parameterName=$parameter['parameter_name'];
				if($parameter['mail_alert_status']=="Normal")
				{
              echo $selectEnergy= "SELECT ".$parameterName." FROM `energy_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND (".$parameterName." <= '".$parameter['min_alert_value']."' OR ".$parameterName." >= '".$parameter['max_alert_value']."')";
			  $ExeEnergy = mysqli_query($conn, $selectEnergy);
	           $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
				  if($ReadingValue > $parameter['max_alert_value']){
				  $alertStatus='High';
				  $alertValueName='Max Value Reached';
				  }
				  elseif($ReadingValue < $parameter['min_alert_value']){
				  $alertStatus='Low';
				  $alertValueName='Min Value Reached';
				  }
			  }else if($parameter['mail_alert_status']=="High"){
			  $selectEnergy= "SELECT ".$parameterName." FROM `energy_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND (".$parameterName." > '".$parameter['min_alert_value']."' AND ".$parameterName." < '".$parameter['max_alert_value']."')";
			  $ExeEnergy = mysqli_query($conn, $selectEnergy);
			  if (mysqli_num_rows($ExeEnergy) == 0) 
				{
				 $selectEnergy= "SELECT ".$parameterName." FROM `energy_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND ".$parameterName." <= '".$parameter['min_alert_value']."'";
			   $ExeEnergy = mysqli_query($conn, $selectEnergy);
	           $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='Low';
			   $alertValueName='Min Value Reached';
			   
			   }
			   else{
			   
			   $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='Normal';
			   $alertValueName='Normal Value Reached';
			   
			   }
			  }
			  else if($parameter['mail_alert_status']=="Low" ){
			  $selectEnergy= "SELECT ".$parameterName." FROM `energy_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND (".$parameterName." > '".$parameter['min_alert_value']."' AND ".$parameterName." < '".$parameter['max_alert_value']."')";
			  $ExeEnergy = mysqli_query($conn, $selectEnergy);
	          if (mysqli_num_rows($ExeEnergy) == 0) 
				{
				 $selectEnergy= "SELECT ".$parameterName." FROM `energy_data_master_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND ".$parameterName." >= '".$parameter['max_alert_value']."'";
			   $ExeEnergy = mysqli_query($conn, $selectEnergy);
	           $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='High';
			   $alertValueName='Max Value Reached';
			   
			   }
			   else{
			   
			   $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='Normal';
			   $alertValueName='Normal Value Reached';
			   
			   }
			  }
			  
			 /* $message .= "Hi!<br><br><br>
	
								<b>Feeder Name</b>      : ".$parameter['feeder_name'].",<br>
								<b>Parameter Name</b>   : ".$parameter['parameter_name'].",<br>
								<b>".$alertValueName."</b>  : ".$ReadingValue.".<br><br><br><br><br>
	
	
								
                                <b>Best regards</b>,<br>
                                <b>Arka Automaations Limited.</b><br>
								";
								
				  $contentData=strip_tags($message);
								
			 $insAlertLog	="INSERT INTO `alert_log_master`(`company_id`, `branch_id`, `sensor_code`, `alert_type`, `parameter_name`, `alert_message`, `send_to`, `alert_status`, `recorded_date_time`, `posted_date_time`) VALUES ('".$sensMasDet['company_id']."','".$sensMasDet['branch_id']."','".$sensorCode."','Mail','".$parameter['parameter_name']."','".$contentData."','".$alertEmail."','".$alertStatus."','".$teltonikaTimeStamp."',DATE_ADD(NOW(),INTERVAL '00:00' HOUR_MINUTE))";		
			 $insLog = $conn->query($insAlertLog);*/
			  
			//echo   $alertStatus." --alert Status <br>".$alertValueName." --alert Value <br>".mysqli_num_rows($ExeEnergy);
			   
			    if (mysqli_num_rows($ExeEnergy) > 0) 
				{
				
			    echo $updateAlertPar= "UPDATE `alert_parameter_mapping` SET mail_alert_status='".$alertStatus."'  WHERE `alert_parameter_id`='".$parameter['alert_parameter_id']."'";
       			 $ExeAlertPar = mysqli_query($conn, $updateAlertPar);
				     echo $ReadingValue."-  Reading Value <br>";
				     echo $alertEmail."-  MailId <br>"; 
				     
			  $selectSensor= "SELECT * FROM `arka_sensor_master` WHERE `sensorCode`='".$parameter['sensor_code']."' AND status='1' AND isActive='1'";
			  $ExeSensor = mysqli_query($conn, $selectSensor);
	          $ExeSensorArr = mysqli_fetch_assoc($ExeSensor);
			  $sensorNameVal = $ExeSensorArr['sensorName'];


$message = '';

				   $message .= "EMS - Alert Message!<br><br><br>
	
								<b>Energy Meter Name</b>      : ".$parameter['feeder_name'].",<br>
								<b>Parameter Name</b>   : ".$parameter['parameter_name'].",<br>
								<b>".$alertValueName."</b>  : ".$ReadingValue.".<br><br><br><br><br>
	
	
								
                                <br>
								";
								
				  $contentData=strip_tags($message);
								
							
			 $insAlertLog	="INSERT INTO `alert_log_master`(`company_id`, `branch_id`, `sensor_code`, `alert_type`, `parameter_name`, `alert_message`, `send_to`, `alert_status`, `recorded_date_time`, `posted_date_time`) VALUES ('".$sensMasDet['company_id']."','".$sensMasDet['branch_id']."','".$sensorCode."','Mail','".$parameter['parameter_name']."','".$contentData."','".$alertEmail."','".$alertStatus."','".$teltonikaTimeStamp."',DATE_ADD(NOW(),INTERVAL '00:00' HOUR_MINUTE))";		
			 $insLog = $conn->query($insAlertLog);
     
        
        if ($insLog === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $insAlertLog . "<br>" . $conn->error;
        }
            	    



				 	
			 }
			   
            }
       } 
	   

//mail("vishalchandran11@gmail.com", "Test Mail", "Test");
	mysqli_free_result($ExeSensor);
	mysqli_free_result($ExeEnergy);
	mysqli_free_result($ExeAlertPar);
	mysqli_free_result($ExeAlertCont);
	mysqli_free_result($resultView);
	mysqli_free_result($result);
	
		/*******************************************             Mail Trigger   End          ****************************************************/
        $conn->close();
    
 }
    else {
        echo "Wrong API Key provided.";
    }

}
else {
    echo "No data posted with HTTP POST.";
}


function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>
