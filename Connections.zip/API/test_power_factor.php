<?php
/*
  Rui Santos
  Complete project details at https://RandomNerdTutorials.com/esp32-esp8266-mysql-database-php/
  
  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files.
  
  The above copyright notice and this permission notice shall be included in all
  copies or substantial portions of the Software.
*/
	 header('Access-Control-Allow-Origin: *'); 
    header("Access-Control-Allow-Credentials: true");
    header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
    header('Access-Control-Max-Age: 1000');
    header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');

require_once('../Connections/ARKAEMS.php'); 
$servername = $hostname_arkaems;

// REPLACE with your Database name
$dbname = $database_arkaems;
// REPLACE with Database user
$username = $username_arkaems;
// REPLACE with Database user password
$password = $password_arkaems;
 
//exit;


// Keep this API Key value to be compatible with the ESP32 code provided in the project page. 
// If you change this value, the ESP32 sketch needs to match
//$api_key_value = "arkatemp1001";

//$api_key= $sensor = $location = $value1 = "";


    
   if ($_SERVER["REQUEST_METHOD"] == "POST") {



$inputJSON = file_get_contents('php://input');
// echo  $inputJSON; exit;
//  $input= json_decode( $inputJSON, true); 
$inputJSON2 = str_replace("-nan","0.000",$inputJSON);
$input= json_decode($inputJSON2, true);
$elementCount  = count($input);
$conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } 
    $sqlSensor = "SELECT * FROM arka_sensor_master WHERE isActive='1' AND status='1' AND api_key='".$input[0]['apiKey']."'"; 
    $insSel = $conn->query($sqlSensor);
	
     $result = mysqli_query($conn, $sqlSensor);
	 $sensMasDet = mysqli_fetch_assoc($result);
	  $apikeyDecd= base64_decode($input[0]['apiKey']);
	 
	   $apiDec =explode("/", $apikeyDecd);
	   $gatewayCode=str_replace("GW:","",$apiDec[0]);
	   $sensorCode=str_replace("SI:","",$apiDec[1]);
	   $sensorModel=str_replace("SMODEL:","",$apiDec[2]);
	   
  if (mysqli_num_rows($result) > 0) {	 
	for ($x =0; $x <= $elementCount; $x++) {
	echo $input[$x]['ST']; 
	if($input[$x]['ST']=='1'){ echo "First Segment";
			$arrRemoveFirstSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$firstSegment= explode (",", $arrRemoveFirstSegment); 
			//echo $firstSegment[0]; exit;
			$voltage_l1_n=$firstSegment[0]; // Required
			$voltage_l2_n=$firstSegment[1]; // Required
			$voltage_l3_n=$firstSegment[2]; // Required
			$voltage_l4_n=$firstSegment[3]; // Required
			$voltage_l1_l2=$firstSegment[4]; // Required
			$voltage_l2_l3=$firstSegment[5]; // Required
			$voltage_l3_l1=$firstSegment[6]; // Required
			$current_l1=$firstSegment[7]; // Required
			$current_l2=$firstSegment[8]; // Required
			$current_l3=$firstSegment[9]; // Required
			$current_l4=$firstSegment[10]; //  Not Required
			$neutral_current=$firstSegment[11]; // (l1+l2+l3) Not Required
			$compensation_current_l1=$firstSegment[12]; //  Not Required
			$compensation_current_l2=$firstSegment[13]; //  Not Required
			$compensation_current_l3=$firstSegment[14]; //  Not Required
			$compensation_current_l4=$firstSegment[15]; //  Not Required
			$measured_frequency=$firstSegment[16]; //  Required
			$active_power_l1_n=$firstSegment[17]; //  Required
			$active_power_l2_n=$firstSegment[18]; //  Required
			$active_power_l3_n=$firstSegment[19]; //  Required
			$active_power_l4_n=$firstSegment[20]; // Not Required
			$total_import_active_power=$firstSegment[21]; //  Required
			$total_export_active_power=$firstSegment[22]; //  Required
			$total_active_power=$firstSegment[23]; //  Required
			$reactive_power_l1=$firstSegment[24]; //  Required
			$reactive_power_l2=$firstSegment[25]; //  Required
			$reactive_power_l3=$firstSegment[26]; //  Required
			$reactive_power_l4=$firstSegment[27]; //  Required
			$quadrant_1_total_reactive_power=$firstSegment[28]; //  Not Required
			$quadrant_2_total_reactive_power=$firstSegment[29]; //  Not Required
			$quadrant_3_total_reactive_power=$firstSegment[30]; //  Not Required
			$quadrant_4_total_reactive_power=$firstSegment[31]; //  Not Required
			$total_reactive_power=$firstSegment[32]; //  Required
			$apparent_power_l1_n=$firstSegment[33]; //  Required
			$apparent_power_l2_n=$firstSegment[34]; //  Required
			$apparent_power_l3_n=$firstSegment[35]; //  Required
			$apparent_power_l4_n=$firstSegment[36]; //  Required
			$total_import_apparent_power=$firstSegment[37]; // Not Required
			$total_export_apparent_power=$firstSegment[38]; // Not Required
			$total_apparent_power=$firstSegment[39]; //  Not Required
			$compensation_active_power_l1_n=$firstSegment[40]; //  Not Required
			$compensation_active_power_l2_n=$firstSegment[41]; //  Not Required
			$compensation_active_power_l3_n=$firstSegment[42]; //  Not Required
			$compensation_active_power_l4_n=$firstSegment[43]; // Not Required
			$compensation_total_import_active_power=$firstSegment[44]; //  Not Required
			$compensation_total_export_active_power=$firstSegment[45]; //  Not Required
			$compensation_total_active_power=$firstSegment[46]; //  Not Required
			$compensation_reactive_power_l1=$firstSegment[47]; //  Not Required
			$compensation_reactive_power_l2=$firstSegment[48]; //  Not Required
			$compensation_reactive_power_l3=$firstSegment[49]; //  Not Required
			$compensation_reactive_power_l4=$firstSegment[50]; //  Not Required
		
		}
		elseif($input[$x]['ST']=='126')
		{
			$arrRemoveSecondSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$secondSegment= explode (",", $arrRemoveSecondSegment); 
			
			$power_factor_l1=$secondSegment[0]; // Required
			$power_factor_l2=$secondSegment[1]; // Required
			$power_factor_l3=$secondSegment[2]; // Required
			$power_factor_l4=$secondSegment[3]; // Required
			$power_factor_total_import=$secondSegment[4]; // Required
			$power_factor_total_export=$secondSegment[5]; // Not Required
			$total_power_factor=$secondSegment[6]; // Not Required
			$cosphi_l1=$secondSegment[7]; // Required
			$cosphi_l2=$secondSegment[8]; // Required
			$cosphi_l3=$secondSegment[9]; // Required
			$cosphi_l4=$secondSegment[10]; //  Not Required
			$cosphi_total_import=$secondSegment[11]; //  Not Required
			$cosphi_total_export=$secondSegment[12]; //  Not Required
			$total_cosphi=$secondSegment[13]; //  Not Required
		
		}
		elseif($input[$x]['ST']=='10241')
		{
			$arrRemoveThirdSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$thirdSegment= explode (",", $arrRemoveThirdSegment); 
			$step1_actual_steps_value=abs($thirdSegment[0]); // Required
			
		}
		elseif($input[$x]['ST']=='10260')
		{
			$arrRemoveFourthSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$fourthSegment= explode (",", $arrRemoveFourthSegment); 
			$step2_actual_steps_value=abs($fourthSegment[0]); // Required
			
		}
		elseif($input[$x]['ST']=='10279')
		{
			$arrRemoveFifthSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$fifthSegment= explode (",", $arrRemoveFifthSegment); 
			$step3_actual_steps_value=abs($fifthSegment[0]); // Required
			
		}
		elseif($input[$x]['ST']=='10298')
		{
			$arrRemoveSixthSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$sixthSegment= explode (",", $arrRemoveSixthSegment); 
			$step4_actual_steps_value=abs($sixthSegment[0]); // Required
		}
		elseif($input[$x]['ST']=='10317')
		{
			$arrRemoveSevenSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$sevenSegment= explode (",", $arrRemoveSevenSegment); 
			$step5_actual_steps_value=abs($sevenSegment[0]); // Required
		}
		elseif($input[$x]['ST']=='10336')
		{
			$arrRemoveEightSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$eightSegment= explode (",", $arrRemoveEightSegment); 
			$step6_actual_steps_value=abs($eightSegment[0]); // Required
		}
		elseif($input[$x]['ST']=='10355')
		{
			$arrRemoveNineSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$nineSegment= explode (",", $arrRemoveNineSegment); 
			$step7_actual_steps_value=abs($nineSegment[0]); // Required
		}elseif($input[$x]['ST']=='10374')
		{
			$arrRemoveTenSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$tenSegment= explode (",", $arrRemoveTenSegment); 
			$step8_actual_steps_value=abs($tenSegment[0]); // Required
		}elseif($input[$x]['ST']=='10393')
		{
			$arrRemoveElevenSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$elevenSegment= explode (",", $arrRemoveElevenSegment); 
			$step9_actual_steps_value=abs($elevenSegment[0]); // Required
		}elseif($input[$x]['ST']=='10412')
		{
			$arrRemoveTwelveSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$twelveSegment= explode (",", $arrRemoveTwelveSegment); 
			$step10_actual_steps_value=abs($twelveSegment[0]); // Required
		}elseif($input[$x]['ST']=='10431')
		{
			$arrRemoveThirteenSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$thirteenSegment= explode (",", $arrRemoveThirteenSegment); 
			$step11_actual_steps_value=abs($thirteenSegment[0]); // Required
		}elseif($input[$x]['ST']=='10450')
		{
			$arrRemoveFourteenSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$fourteenSegment= explode (",", $arrRemoveFourteenSegment); 
			$step12_actual_steps_value=abs($fourteenSegment[0]); // Required
		}elseif($input[$x]['ST']=='10469')
		{
			$arrRemoveFifteenSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$fifteenSegment= explode (",", $arrRemoveFifteenSegment); 
			$step13_actual_steps_value=abs($fifteenSegment[0]); // Required
		}elseif($input[$x]['ST']=='10488')
		{
			$arrRemoveSixteenSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$sixteenSegment= explode (",", $arrRemoveSixteenSegment); 
			$step14_actual_steps_value=abs($sixteenSegment[0]); // Required
		}elseif($input[$x]['ST']=='10507')
		{
			$arrRemoveSeventeenSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$seventeenSegment= explode (",", $arrRemoveSeventeenSegment); 
			$step15_actual_steps_value=abs($sixthSegment[0]); // Required
		}elseif($input[$x]['ST']=='10526')
		{
			$arrRemoveEighteenSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$eighteenSegment= explode (",", $arrRemoveEighteenSegment); 
			$step16_actual_steps_value=abs($eighteenSegment[0]); // Required
		}elseif($input[$x]['ST']=='10545')
		{
			$arrRemoveNinteenSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$ninteenSegment= explode (",", $arrRemoveNinteenSegment); 
			$step17_actual_steps_value=abs($ninteenSegment[0]); // Required
		}elseif($input[$x]['ST']=='10564')
		{
			$arrRemoveTwentySegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$twentySegment= explode (",", $arrRemoveTwentySegment); 
			$step18_actual_steps_value=abs($twentySegment[0]); // Required
		}elseif($input[$x]['ST']=='10583')
		{
			$arrRemoveTwentyoneSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$twentyoneSegment= explode (",", $arrRemoveTwentyoneSegment); 
			$step19_actual_steps_value=abs($twentyoneSegment[0]); // Required
		}elseif($input[$x]['ST']=='10602')
		{
			$arrRemoveTwentytwoSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$twentytwoSegment= explode (",", $arrRemoveTwentytwoSegment); 
			$step20_actual_steps_value=abs($twentytwoSegment[0]); // Required
		}
	
}
  $liuxTimeStamp=$input[0]['TS'];
           
		 
          if($liuxTimeStamp !="XXXXXX")
          {
              $recordedTimeStamp = date("Y-m-d H:i:s",$input[0]['TS']);
              $telDate =$input[0]['DT'];
              $teltonika_date = str_replace('/', '-', $telDate);
              $teltonikaTimeStamp =  date('Y-m-d H:i:s', strtotime($teltonika_date));
          }
          else
          {
              $liuxTimeStamp='';
              $recordedTimeStamp = ''; 
			  $teltonikaTimeStamp='';
          
          }
// echo  $inputJSON;
echo $voltage_l1_n; 
if(isset($arrRemoveFirstSegment) && isset($arrRemoveSecondSegment)){
    echo "Segment Inside"; exit;
 echo $insertQry="INSERT INTO `power_factor_energy_data` (`gateway_code`, `sensor_code`, `sensor_model`, `voltage_l1_n`, `voltage_l2_n`, `voltage_l3_n`, `voltage_l4_n`, `voltage_l1_l2`, `voltage_l2_l3`, `voltage_l3_l1`, `current_l1`, `current_l2`, `current_l3`, `measured_frequency`, `active_power_l1_n`, `active_power_l2_n`, `active_power_l3_n`, `total_import_active_power`, `total_export_active_power`, `total_active_power`, `reactive_power_l1`, `reactive_power_l2`, `reactive_power_l3`, `reactive_power_l4`, `total_reactive_power`, `apparent_power_l1_n`, `apparent_power_l2_n`, `apparent_power_l3_n`, `apparent_power_l4_n`, `power_factor_l1`, `power_factor_l2`, `power_factor_l3`, `power_factor_l4`, `power_factor_total_import`, `cospi_l1`, `cospi_l2`, `cospi_l3`, `cospi_total_import`, `step1_actual_steps_value`, `step2_actual_steps_value`, `step3_actual_steps_value`, `step4_actual_steps_value`, `step5_actual_steps_value`, `step6_actual_steps_value`, `step7_actual_steps_value`, `step8_actual_steps_value`, `step9_actual_steps_value`, `step10_actual_steps_value`, `step11_actual_steps_value`, `step12_actual_steps_value`, `step13_actual_steps_value`, `step14_actual_steps_value`, `step15_actual_steps_value`, `step16_actual_steps_value`, `step17_actual_steps_value`, `step18_actual_steps_value`, `step19_actual_steps_value`, `step20_actual_steps_value`, `VR_ARRAY_VALUE`, `linux_date_time`, `teltonika_date_time`, `recorded_date_time`, `posted_date_time`) VALUES ('".$gatewayCode."', '".$sensorCode."', '".$sensorModel."', '".$voltage_l1_n."','".$voltage_l2_n."','".$voltage_l3_n."','".$voltage_l4_n."','".$voltage_l1_l2."','".$voltage_l2_l3."','".$voltage_l3_l1."','".$current_l1."','".$current_l2."','".$current_l3."','".$measured_frequency."','".$active_power_l1_n."','".$active_power_l2_n."','".$active_power_l3_n."','".$total_import_active_power."','".$total_export_active_power."','".$total_active_power."','".$reactive_power_l1."','".$reactive_power_l2."','".$reactive_power_l3."','".$reactive_power_l4."','".$total_reactive_power."','".$apparent_power_l1_n."','".$apparent_power_l2_n."','".$apparent_power_l3_n."','".$apparent_power_l4_n."','".$power_factor_l1."','".$power_factor_l2."','".$power_factor_l3."','".$power_factor_l4."','".$power_factor_total_import."','".$cospi_l1."','".$cospi_l2."','".$cospi_l3."','".$cospi_total_import."','".$step1_actual_steps_value."','".$step2_actual_steps_value."','".$step3_actual_steps_value."','".$step4_actual_steps_value."','".$step5_actual_steps_value."','".$step6_actual_steps_value."','".$step7_actual_steps_value."','".$step8_actual_steps_value."','".$step9_actual_steps_value."','".$step10_actual_steps_value."','".$step11_actual_steps_value."','".$step12_actual_steps_value."','".$step13_actual_steps_value."','".$step14_actual_steps_value."','".$step15_actual_steps_value."','".$step16_actual_steps_value."','".$step17_actual_steps_value."','".$step18_actual_steps_value."','".$step19_actual_steps_value."','".$step20_actual_steps_value."','".$inputJSON2."','".$liuxTimeStamp."','".$telDate."','".$teltonikaTimeStamp."',NOW())"; 


  $insExec = $conn->query($insertQry);
     
        
        if ($insExec === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $insertQry . "<br>" . $conn->error;
        }


 	   $selectView= "SELECT * FROM `power_factor_energy_data_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."'";
       $resultView = mysqli_query($conn, $selectView);
	   $rowcount=mysqli_num_rows($resultView);
	   if($rowcount==0){
			
		 $sql2="INSERT INTO `power_factor_energy_data_view` (`gateway_code`, `sensor_code`, `sensor_model`, `voltage_l1_n`, `voltage_l2_n`, `voltage_l3_n`, `voltage_l4_n`, `voltage_l1_l2`, `voltage_l2_l3`, `voltage_l3_l1`, `current_l1`, `current_l2`, `current_l3`, `measured_frequency`, `active_power_l1_n`, `active_power_l2_n`, `active_power_l3_n`, `total_import_active_power`, `total_export_active_power`, `total_active_power`, `reactive_power_l1`, `reactive_power_l2`, `reactive_power_l3`, `reactive_power_l4`, `total_reactive_power`, `apparent_power_l1_n`, `apparent_power_l2_n`, `apparent_power_l3_n`, `apparent_power_l4_n`, `power_factor_l1`, `power_factor_l2`, `power_factor_l3`, `power_factor_l4`, `power_factor_total_import`, `cospi_l1`, `cospi_l2`, `cospi_l3`, `cospi_total_import`, `step1_actual_steps_value`, `step2_actual_steps_value`, `step3_actual_steps_value`, `step4_actual_steps_value`, `step5_actual_steps_value`, `step6_actual_steps_value`, `step7_actual_steps_value`, `step8_actual_steps_value`, `step9_actual_steps_value`, `step10_actual_steps_value`, `step11_actual_steps_value`, `step12_actual_steps_value`, `step13_actual_steps_value`, `step14_actual_steps_value`, `step15_actual_steps_value`, `step16_actual_steps_value`, `step17_actual_steps_value`, `step18_actual_steps_value`, `step19_actual_steps_value`, `step20_actual_steps_value`, `VR_ARRAY_VALUE`, `linux_date_time`, `teltonika_date_time`, `recorded_date_time`, `posted_date_time`) VALUES ('".$gatewayCode."', '".$sensorCode."', '".$sensorModel."', '".$voltage_l1_n."','".$voltage_l2_n."','".$voltage_l3_n."','".$voltage_l4_n."','".$voltage_l1_l2."','".$voltage_l2_l3."','".$voltage_l3_l1."','".$current_l1."','".$current_l2."','".$current_l3."','".$measured_frequency."','".$active_power_l1_n."','".$active_power_l2_n."','".$active_power_l3_n."','".$total_import_active_power."','".$total_export_active_power."','".$total_active_power."','".$reactive_power_l1."','".$reactive_power_l2."','".$reactive_power_l3."','".$reactive_power_l4."','".$total_reactive_power."','".$apparent_power_l1_n."','".$apparent_power_l2_n."','".$apparent_power_l3_n."','".$apparent_power_l4_n."','".$power_factor_l1."','".$power_factor_l2."','".$power_factor_l3."','".$power_factor_l4."','".$power_factor_total_import."','".$cospi_l1."','".$cospi_l2."','".$cospi_l3."','".$cospi_total_import."','".$step1_actual_steps_value."','".$step2_actual_steps_value."','".$step3_actual_steps_value."','".$step4_actual_steps_value."','".$step5_actual_steps_value."','".$step6_actual_steps_value."','".$step7_actual_steps_value."','".$step8_actual_steps_value."','".$step9_actual_steps_value."','".$step10_actual_steps_value."','".$step11_actual_steps_value."','".$step12_actual_steps_value."','".$step13_actual_steps_value."','".$step14_actual_steps_value."','".$step15_actual_steps_value."','".$step16_actual_steps_value."','".$step17_actual_steps_value."','".$step18_actual_steps_value."','".$step19_actual_steps_value."','".$step20_actual_steps_value."','".$inputJSON2."','".$liuxTimeStamp."','".$telDate."','".$teltonikaTimeStamp."',NOW())";
		
      }else{
		   		
					 $sql2= " UPDATE `power_factor_energy_data_view` SET `gateway_code`='".$gatewayCode."', `sensor_code`='".$sensorCode."', `sensor_model`='".$sensorModel."', `voltage_l1_n`='".$voltage_l1_n."', `voltage_l2_n`='".$voltage_l2_n."', `voltage_l3_n`='".$voltage_l3_n."',`voltage_l4_n`='".$voltage_l4_n."', `voltage_l1_l2`='".$voltage_l1_l2."', `voltage_l2_l3`='".$voltage_l2_l3."', `voltage_l3_l1`='".$voltage_l3_l1."', `current_l1`='".$current_l1."', `current_l2`='".$current_l2."', `current_l3`='".$current_l3."', `measured_frequency`='".$measured_frequency."',`active_power_l1_n`='".$active_power_l1_n."', `active_power_l2_n`='".$active_power_l2_n."', `active_power_l3_n`='".$active_power_l3_n."', `total_import_active_power`='".$total_import_active_power."', `total_export_active_power`='".$total_export_active_power."', `total_active_power`='".$total_active_power."', `reactive_power_l1`='".$reactive_power_l1."', `reactive_power_l2`='".$reactive_power_l2."', `reactive_power_l3`='".$reactive_power_l3."', `reactive_power_l4`='".$reactive_power_l4."', `total_reactive_power`='".$total_reactive_power."', `apparent_power_l1_n`='".$apparent_power_l1_n."', `apparent_power_l2_n`='".$apparent_power_l2_n."', `apparent_power_l3_n`= '".$apparent_power_l3_n."',`apparent_power_l4_n`='".$apparent_power_l4_n."', `power_factor_l1`='".$power_factor_l1."', `power_factor_l2`='".$power_factor_l2."', `power_factor_l3`='".$power_factor_l3."', `power_factor_l4`='".$power_factor_l4."', `power_factor_total_import`='".$power_factor_total_import."', `cospi_l1`='".$cospi_l1."', `cospi_l2`='".$cospi_l2."', `cospi_l3`='".$cospi_l3."', `cospi_total_import`='".$cospi_total_import."', `step1_actual_steps_value`='".$step1_actual_steps_value."', `step2_actual_steps_value`='".$step2_actual_steps_value."', `step3_actual_steps_value`='".$step3_actual_steps_value."', `step4_actual_steps_value`='".$step4_actual_steps_value."', `step5_actual_steps_value`='".$step5_actual_steps_value."', `step6_actual_steps_value`='".$step6_actual_steps_value."', `step7_actual_steps_value`='".$step7_actual_steps_value."', `step8_actual_steps_value`='".$step8_actual_steps_value."', `step9_actual_steps_value`='".$step9_actual_steps_value."', `step10_actual_steps_value`='".$step10_actual_steps_value."', `step11_actual_steps_value`='".$step11_actual_steps_value."', `step12_actual_steps_value`='".$step12_actual_steps_value."', `step13_actual_steps_value`='".$step13_actual_steps_value."',`step14_actual_steps_value`='".$step14_actual_steps_value."', `step15_actual_steps_value`='".$step15_actual_steps_value."', `step16_actual_steps_value`='".$step16_actual_steps_value."', `step17_actual_steps_value`='".$step17_actual_steps_value."', `step18_actual_steps_value`='".$step18_actual_steps_value."',`step19_actual_steps_value`='".$step19_actual_steps_value."', `step20_actual_steps_value`='".$step20_actual_steps_value."', `VR_ARRAY_VALUE`='".$inputJSON2."', `linux_date_time`='".$liuxTimeStamp."', `teltonika_date_time`='".$telDate."', `recorded_date_time`='".$teltonikaTimeStamp."', `posted_date_time`=NOW() WHERE `sensor_code`='".$sensorCode."'";
				

	  
	  }
        $insSel2 = $conn->query($sql2);
     
        
        if ($insSel2 === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $sql2 . "<br>" . $conn->error;
        }
}
}


     
}
else {
    echo "No data posted with HTTP POST.";
}


function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>
