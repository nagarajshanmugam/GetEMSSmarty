<?php
$servername = "166.62.10.227";
// REPLACE with your Database name
$dbname = "emslte";
// REPLACE with Database user
$username = "emslte";
// REPLACE with Database user password
$password = "emslte@2020";

       
     if(isset($_GET['apiKey'])){   
         // Create connection
	   $apikeyDecd= base64_decode($_GET['apiKey']);
	 
	   $apiDec =explode("/", $apikeyDecd);
	   $gatewayCode=str_replace("GW:","",$apiDec[0]);
	   $sensorCode=str_replace("SI:","",$apiDec[1]);
	   $sensorModel=str_replace("SMODEL:","",$apiDec[2]);
	   
	   $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } 
     $sqlParm = "SELECT feeder_name,parameter_name,min_alert_value,max_alert_value FROM alert_parameter_mapping WHERE sensor_code='".$sensorCode."' AND gateway_code='".$gatewayCode."'";
   // $selParmExe = $conn->query($sqlParm);
	
     $result = mysqli_query($conn, $sqlParm);
     
    // $rows = array();
    $row='';
    //$rows="Test,0.00,0.00|";
    while($r = mysqli_fetch_assoc($result)) {
     // $rows[] = $r;
     
     $rows.= $r["parameter_name"].','.$r["min_alert_value"].','.$r["max_alert_value"]."|";
      
    }
echo trim($rows,"|");
    //echo json_encode($rows);

 }

?>