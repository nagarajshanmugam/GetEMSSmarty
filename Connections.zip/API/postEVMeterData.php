<?php

/*
  Rui Santos
  Complete project details at https://RandomNerdTutorials.com/esp32-esp8266-mysql-database-php/
  
  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files.
  
  The above copyright notice and this permission notice shall be included in all
  copies or substantial portions of the Software.
*/

//namespace PortoContactForm;

session_cache_limiter('nocache');
header('Expires: ' . gmdate('r', 0));

header('Content-type: application/json');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'php/php-mailer/src/PHPMailer.php';
require 'php/php-mailer/src/SMTP.php';
require 'php/php-mailer/src/Exception.php';

require_once('../Connections/ARKAEMS.php'); 
$servername = $hostname_arkaems;

// REPLACE with your Database name
$dbname = $database_arkaems;
// REPLACE with Database user
$username = $username_arkaems;
// REPLACE with Database user password
$password = $password_arkaems;
 
//exit;


// Keep this API Key value to be compatible with the ESP32 code provided in the project page. 
// If you change this value, the ESP32 sketch needs to match


   if ($_SERVER["REQUEST_METHOD"] == "POST") {
         $inputJSON = file_get_contents('php://input');
         $input= json_decode( $inputJSON, true); 
 // $api_key = test_input($_POST["api_key"]);
     $conn = new mysqli($servername, $username, $password, $dbname);
     mysqli_query($conn,"SET SESSION sql_mode = 'NO_ENGINE_SUBSTITUTION'");
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } 
    $sqlSensor = "SELECT * FROM arka_sensor_master WHERE segmentName='Electric Vehicle' AND isActive='1' AND status='1' AND api_key='".$input[0]['apiKey']."'";
    $insSel = $conn->query($sqlSensor);
	
     $result = mysqli_query($conn, $sqlSensor);
	 $sensMasDet = mysqli_fetch_assoc($result);
	 
       $companyId= $sensMasDet["company_id"];
	   $branchId= $sensMasDet["branch_id"];
      

       
  if (mysqli_num_rows($result) > 0) {
          
       
        
         // Create connection
		   $apikeyDecd= base64_decode($input[0]['apiKey']);
	 
	  $apiDec =explode("/", $apikeyDecd);
	   $gatewayCode=str_replace("GW:","",$apiDec[0]);
	   $sensorCode=str_replace("SI:","",$apiDec[1]);
	   $sensorModel=str_replace("SMODEL:","",$apiDec[2]);
	   
           $jsonDecd= str_replace(array('[', ',]', ']'), '', $input[0]['VR']);

           $str_arr= explode (",", $jsonDecd); 
          // echo $input[0]['VR']."<br>"; print_r($str_arr); 
           if($sensorModel =='EVDC'){
           /********************   ICD Meter 1 Phase variables   *********************/
           $kwh_ch1= $str_arr[0]; //date post in database
           $amps_ch1=$str_arr[1]; //date post in database
           $kwh_ch2=$str_arr[2];  //date post in database
           $amps_ch2=$str_arr[3];  //date post in database
           $kwh_ch3=$str_arr[4]; //date post in database
           $amps_ch3=$str_arr[5];  //date post in database
           $kwh_ch4=$str_arr[6]; //date post in database
           $amps_ch4=$str_arr[7]; //date post in database
           $bus_voltage=$str_arr[8]; //date post in database
           $kw_ch1=$str_arr[9];  //date post in database
           $kw_ch2=$str_arr[10];   //date post in database
           $kw_ch3=$str_arr[11];  //date post in database
           $kw_ch4=$str_arr[12];//date post in database
           
           
           
		

          }
          
          $liuxTimeStamp=$input[0]['TS'];
		 
          if($liuxTimeStamp !="XXXXXX")
          {
             
              $recordedTimeStamp = date("Y-m-d H:i:s",$input[0]['TS']);
              $telDate =$input[0]['DT'];
              $teltonika_date = str_replace('/', '-', $telDate);
              $teltonikaTimeStamp =  date('Y-m-d H:i:s', strtotime($teltonika_date));
             
          }
          else
          {
              $liuxTimeStamp='';
              $recordedTimeStamp = ''; 

			  $teltonikaTimeStamp='';
          
          }
           
       $sql= "INSERT INTO `ev_meter_data`(`company_id`, `branch_id`,`gateway_code`, `sensor_code`, `sensor_model`,`kwh_ch1`, `amps_ch1`, `kwh_ch2`, `amps_ch2`, `kwh_ch3`, `amps_ch3`, `kwh_ch4`, `amps_ch4`, `bus_voltage`, `kw_ch1`, `kw_ch2`, `kw_ch3`, `kw_ch4`, `json_data`,`teltonika_date_time`,`linux_timestamp`, `recorded_date_time`, `posted_date_time`) VALUES ('".$companyId."','".$branchId."','".$gatewayCode."','".$sensorCode."','".$sensorModel."','".$kwh_ch1."','".$amps_ch1."','".$kwh_ch2."','".$amps_ch2."','".$kwh_ch3."','".$amps_ch3."','".$kwh_ch4."','".$amps_ch4."','".$bus_voltage."','".$kw_ch1."','".$kw_ch2."','".$kw_ch3."','".$kw_ch4."','".$inputJSON."','".$liuxTimeStamp."','".$input[0]['DT']."','".$teltonikaTimeStamp."', DATE_ADD(NOW(),INTERVAL '00:00' HOUR_MINUTE))";
      
        $insSel = $conn->query($sql);
     
        
        if ($insSel === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
       
	   echo $selectView= "SELECT * FROM `ev_meter_data_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."'";
       $resultView = mysqli_query($conn, $selectView);
	   $rowcount=mysqli_num_rows($resultView);
	   if($rowcount==0){
	          $sql2= "INSERT INTO `ev_meter_data_view`(`company_id`, `branch_id`,`gateway_code`, `sensor_code`, `sensor_model`,`kwh_ch1`, `amps_ch1`, `kwh_ch2`, `amps_ch2`, `kwh_ch3`, `amps_ch3`, `kwh_ch4`, `amps_ch4`, `bus_voltage`, `kw_ch1`, `kw_ch2`, `kw_ch3`, `kw_ch4`, `json_data`,`teltonika_date_time`,`linux_timestamp`, `recorded_date_time`, `posted_date_time`) VALUES ('".$companyId."','".$branchId."','".$gatewayCode."','".$sensorCode."','".$sensorModel."','".$kwh_ch1."','".$amps_ch1."','".$kwh_ch2."','".$amps_ch2."','".$kwh_ch3."','".$amps_ch3."','".$kwh_ch4."','".$amps_ch4."','".$bus_voltage."','".$kw_ch1."','".$kw_ch2."','".$kw_ch3."','".$kw_ch4."','".$inputJSON."','".$liuxTimeStamp."','".$input[0]['DT']."','".$teltonikaTimeStamp."', DATE_ADD(NOW(),INTERVAL '00:00' HOUR_MINUTE))";
      }else{
	  	          $sql2= "UPDATE `ev_meter_data_view` SET `kwh_ch1`='".$kwh_ch1."',`amps_ch1`='".$amps_ch1."',kwh_ch2='".$kwh_ch2."', `amps_ch2`='".$amps_ch2."', `kwh_ch3`='".$kwh_ch3."', `amps_ch3`='".$amps_ch3."', `kwh_ch4`='".$kwh_ch4."', `amps_ch4`='".$amps_ch4."', `bus_voltage`='".$bus_voltage."', `kw_ch1`='".$kw_ch1."', `kw_ch2`='".$kw_ch2."', `kw_ch3`='".$kw_ch3."', `kw_ch4`='".$kw_ch4."',`json_data`='".$inputJSON."',`teltonika_date_time`='".$input[0]['DT']."',`linux_timestamp`='".$liuxTimeStamp."', `recorded_date_time`='".$teltonikaTimeStamp."', `posted_date_time`=DATE_ADD(NOW(),INTERVAL '00:00' HOUR_MINUTE) WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."'";

	  
	  }
        $insSel2 = $conn->query($sql2);
     
        
        if ($insSel2 === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $sql2 . "<br>" . $conn->error;
        }
		
		
        $conn->close();
    
 }
    else {
        echo "Wrong API Key provided.";
    }

}
else {
    echo "No data posted with HTTP POST.";
}


function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
