<?php 
header('Access-Control-Allow-Origin: *'); 
    header("Access-Control-Allow-Credentials: true");
    header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
    header('Access-Control-Max-Age: 1000');
    header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');
    
    
    
$jsonData='[{"employee_name":"Vishal", "employee_salary":"50,000", "employee_age":"28"},{"employee_name":"nagaraj", "employee_salary":"150,000", "employee_age":"35"},{"employee_name":"Vishal", "employee_salary":"50,000", "employee_age":"28"},{"employee_name":"nagaraj", "employee_salary":"150,000", "employee_age":"35"},{"employee_name":"Vishal", "employee_salary":"50,000", "employee_age":"28"},{"employee_name":"nagaraj", "employee_salary":"150,000", "employee_age":"35"},{"employee_name":"Vishal", "employee_salary":"50,000", "employee_age":"28"},{"employee_name":"nagaraj", "employee_salary":"150,000", "employee_age":"35"}]';
$json2 = json_encode(json_decode($jsonData), JSON_PRETTY_PRINT);
echo $json2;
?>