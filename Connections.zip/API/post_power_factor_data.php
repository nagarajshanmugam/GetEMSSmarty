<?php
/*
  Rui Santos
  Complete project details at https://RandomNerdTutorials.com/esp32-esp8266-mysql-database-php/
  
  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files.
  
  The above copyright notice and this permission notice shall be included in all
  copies or substantial portions of the Software.
*/
	 header('Access-Control-Allow-Origin: *'); 
    header("Access-Control-Allow-Credentials: true");
    header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
    header('Access-Control-Max-Age: 1000');
    header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'php/php-mailer/src/PHPMailer.php';
require 'php/php-mailer/src/SMTP.php';
require 'php/php-mailer/src/Exception.php';

require_once('../Connections/ARKAEMS.php'); 
$servername = $hostname_arkaems;

// REPLACE with your Database name
$dbname = $database_arkaems;
// REPLACE with Database user
$username = $username_arkaems;
// REPLACE with Database user password
$password = $password_arkaems;
 
//exit;


// Keep this API Key value to be compatible with the ESP32 code provided in the project page. 
// If you change this value, the ESP32 sketch needs to match
//$api_key_value = "arkatemp1001";

//$api_key= $sensor = $location = $value1 = "";


    
   if ($_SERVER["REQUEST_METHOD"] == "POST") {



$inputJSON = file_get_contents('php://input');
// echo  $inputJSON; exit;
//  $input= json_decode( $inputJSON, true); 
$inputJSON2 = str_replace("-nan","0.000",$inputJSON);
$input= json_decode($inputJSON2, true);
$elementCount  = count($input);
$conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } 
    $sqlSensor = "SELECT * FROM arka_sensor_master WHERE isActive='1' AND status='1' AND api_key='".$input[0]['apiKey']."'"; 
    $insSel = $conn->query($sqlSensor);
	
     $result = mysqli_query($conn, $sqlSensor);
	 $sensMasDet = mysqli_fetch_assoc($result);
	  $apikeyDecd= base64_decode($input[0]['apiKey']);
	 
	   $apiDec =explode("/", $apikeyDecd);
	   $gatewayCode=str_replace("GW:","",$apiDec[0]);
	   $sensorCode=str_replace("SI:","",$apiDec[1]);
	   $sensorModel=str_replace("SMODEL:","",$apiDec[2]);
	   
  if (mysqli_num_rows($result) > 0) {	 
	for ($x =0; $x <= $elementCount; $x++) {
	echo $input[$x]['ST']; 
	if($input[$x]['ST']=='1'){ echo "First Segment";
			$arrRemoveFirstSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$firstSegment= explode (",", $arrRemoveFirstSegment); 
			//echo $firstSegment[0]; exit;
			$voltage_l1_n=$firstSegment[0]; // Required
			$voltage_l2_n=$firstSegment[1]; // Required
			$voltage_l3_n=$firstSegment[2]; // Required
			$voltage_l4_n=$firstSegment[3]; // Required
			$voltage_l1_l2=$firstSegment[4]; // Required
			$voltage_l2_l3=$firstSegment[5]; // Required
			$voltage_l3_l1=$firstSegment[6]; // Required
			$current_l1=$firstSegment[7]; // Required
			$current_l2=$firstSegment[8]; // Required
			$current_l3=$firstSegment[9]; // Required
			$current_l4=$firstSegment[10]; //  Not Required
			$neutral_current=$firstSegment[11]; // (l1+l2+l3) Not Required
			$compensation_current_l1=$firstSegment[12]; //  Not Required
			$compensation_current_l2=$firstSegment[13]; //  Not Required
			$compensation_current_l3=$firstSegment[14]; //  Not Required
			$compensation_current_l4=$firstSegment[15]; //  Not Required
			$measured_frequency=$firstSegment[16]; //  Required
			$active_power_l1_n=$firstSegment[17]; //  Required
			$active_power_l2_n=$firstSegment[18]; //  Required
			$active_power_l3_n=$firstSegment[19]; //  Required
			$active_power_l4_n=$firstSegment[20]; // Not Required
			$total_import_active_power=$firstSegment[21]; //  Required
			$total_export_active_power=$firstSegment[22]; //  Required
			$total_active_power=$firstSegment[23]; //  Required
			$reactive_power_l1=$firstSegment[24]; //  Required
			$reactive_power_l2=$firstSegment[25]; //  Required
			$reactive_power_l3=$firstSegment[26]; //  Required
			$reactive_power_l4=$firstSegment[27]; //  Required
			$quadrant_1_total_reactive_power=$firstSegment[28]; //  Not Required
			$quadrant_2_total_reactive_power=$firstSegment[29]; //  Not Required
			$quadrant_3_total_reactive_power=$firstSegment[30]; //  Not Required
			$quadrant_4_total_reactive_power=$firstSegment[31]; //  Not Required
			$total_reactive_power=$firstSegment[32]; //  Required
			$apparent_power_l1_n=$firstSegment[33]; //  Required
			$apparent_power_l2_n=$firstSegment[34]; //  Required
			$apparent_power_l3_n=$firstSegment[35]; //  Required
			$apparent_power_l4_n=$firstSegment[36]; //  Required
			$total_import_apparent_power=$firstSegment[37]; // Not Required
			$total_export_apparent_power=$firstSegment[38]; // Not Required
			$total_apparent_power=$firstSegment[39]; //  Not Required
			$compensation_active_power_l1_n=$firstSegment[40]; //  Not Required
			$compensation_active_power_l2_n=$firstSegment[41]; //  Not Required
			$compensation_active_power_l3_n=$firstSegment[42]; //  Not Required
			$compensation_active_power_l4_n=$firstSegment[43]; // Not Required
			$compensation_total_import_active_power=$firstSegment[44]; //  Not Required
			$compensation_total_export_active_power=$firstSegment[45]; //  Not Required
			$compensation_total_active_power=$firstSegment[46]; //  Not Required
			$compensation_reactive_power_l1=$firstSegment[47]; //  Not Required
			$compensation_reactive_power_l2=$firstSegment[48]; //  Not Required
			$compensation_reactive_power_l3=$firstSegment[49]; //  Not Required
			$compensation_reactive_power_l4=$firstSegment[50]; //  Not Required
		
		}
		elseif($input[$x]['ST']=='126')
		{
			$arrRemoveSecondSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$secondSegment= explode (",", $arrRemoveSecondSegment); 
			
			$power_factor_l1=$secondSegment[0]; // Required
			$power_factor_l2=$secondSegment[1]; // Required
			$power_factor_l3=$secondSegment[2]; // Required
			$power_factor_l4=$secondSegment[3]; // Required
			$power_factor_total_import=$secondSegment[4]; // Required
			$power_factor_total_export=$secondSegment[5]; // Not Required
			$total_power_factor=$secondSegment[6]; // Not Required
			$cosphi_l1=$secondSegment[7]; // Required
			$cosphi_l2=$secondSegment[8]; // Required
			$cosphi_l3=$secondSegment[9]; // Required
			$cosphi_l4=$secondSegment[10]; //  Not Required
			$cosphi_total_import=$secondSegment[11]; //  Not Required
			$cosphi_total_export=$secondSegment[12]; //  Not Required
			$total_cosphi=$secondSegment[13]; //  Not Required
		
		}
		elseif($input[$x]['ST']=='10241')
		{
			$arrRemoveThirdSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$thirdSegment= explode (",", $arrRemoveThirdSegment); 
			$step1_actual_steps_value=abs($thirdSegment[0]); // Required
			
		}
		elseif($input[$x]['ST']=='10260')
		{
			$arrRemoveFourthSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$fourthSegment= explode (",", $arrRemoveFourthSegment); 
			$step2_actual_steps_value=abs($fourthSegment[0]); // Required
			
		}
		elseif($input[$x]['ST']=='10279')
		{
			$arrRemoveFifthSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$fifthSegment= explode (",", $arrRemoveFifthSegment); 
			$step3_actual_steps_value=abs($fifthSegment[0]); // Required
			
		}
		elseif($input[$x]['ST']=='10298')
		{
			$arrRemoveSixthSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$sixthSegment= explode (",", $arrRemoveSixthSegment); 
			$step4_actual_steps_value=abs($sixthSegment[0]); // Required
		}
		elseif($input[$x]['ST']=='10317')
		{
			$arrRemoveSevenSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$sevenSegment= explode (",", $arrRemoveSevenSegment); 
			$step5_actual_steps_value=abs($sevenSegment[0]); // Required
		}
		elseif($input[$x]['ST']=='10336')
		{
			$arrRemoveEightSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$eightSegment= explode (",", $arrRemoveEightSegment); 
			$step6_actual_steps_value=abs($eightSegment[0]); // Required
		}
		elseif($input[$x]['ST']=='10355')
		{
			$arrRemoveNineSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$nineSegment= explode (",", $arrRemoveNineSegment); 
			$step7_actual_steps_value=abs($nineSegment[0]); // Required
		}elseif($input[$x]['ST']=='10374')
		{
			$arrRemoveTenSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$tenSegment= explode (",", $arrRemoveTenSegment); 
			$step8_actual_steps_value=abs($tenSegment[0]); // Required
		}elseif($input[$x]['ST']=='10393')
		{
			$arrRemoveElevenSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$elevenSegment= explode (",", $arrRemoveElevenSegment); 
			$step9_actual_steps_value=abs($elevenSegment[0]); // Required
		}elseif($input[$x]['ST']=='10412')
		{
			$arrRemoveTwelveSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$twelveSegment= explode (",", $arrRemoveTwelveSegment); 
			$step10_actual_steps_value=abs($twelveSegment[0]); // Required
		}elseif($input[$x]['ST']=='10431')
		{
			$arrRemoveThirteenSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$thirteenSegment= explode (",", $arrRemoveThirteenSegment); 
			$step11_actual_steps_value=abs($thirteenSegment[0]); // Required
		}elseif($input[$x]['ST']=='10450')
		{
			$arrRemoveFourteenSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$fourteenSegment= explode (",", $arrRemoveFourteenSegment); 
			$step12_actual_steps_value=abs($fourteenSegment[0]); // Required
		}elseif($input[$x]['ST']=='10469')
		{
			$arrRemoveFifteenSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$fifteenSegment= explode (",", $arrRemoveFifteenSegment); 
			$step13_actual_steps_value=abs($fifteenSegment[0]); // Required
		}elseif($input[$x]['ST']=='10488')
		{
			$arrRemoveSixteenSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$sixteenSegment= explode (",", $arrRemoveSixteenSegment); 
			$step14_actual_steps_value=abs($sixteenSegment[0]); // Required
		}elseif($input[$x]['ST']=='10507')
		{
			$arrRemoveSeventeenSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$seventeenSegment= explode (",", $arrRemoveSeventeenSegment); 
			$step15_actual_steps_value=abs($sixthSegment[0]); // Required
		}elseif($input[$x]['ST']=='10526')
		{
			$arrRemoveEighteenSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$eighteenSegment= explode (",", $arrRemoveEighteenSegment); 
			$step16_actual_steps_value=abs($eighteenSegment[0]); // Required
		}elseif($input[$x]['ST']=='10545')
		{
			$arrRemoveNinteenSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$ninteenSegment= explode (",", $arrRemoveNinteenSegment); 
			$step17_actual_steps_value=abs($ninteenSegment[0]); // Required
		}elseif($input[$x]['ST']=='10564')
		{
			$arrRemoveTwentySegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$twentySegment= explode (",", $arrRemoveTwentySegment); 
			$step18_actual_steps_value=abs($twentySegment[0]); // Required
		}elseif($input[$x]['ST']=='10583')
		{
			$arrRemoveTwentyoneSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$twentyoneSegment= explode (",", $arrRemoveTwentyoneSegment); 
			$step19_actual_steps_value=abs($twentyoneSegment[0]); // Required
		}elseif($input[$x]['ST']=='10602')
		{
			$arrRemoveTwentytwoSegment= str_replace(array('[', ',]', ']'), '', $input[$x]['VR']);
			$twentytwoSegment= explode (",", $arrRemoveTwentytwoSegment); 
			$step20_actual_steps_value=abs($twentytwoSegment[0]); // Required
		}
	
}
  $liuxTimeStamp=$input[0]['TS'];
           
		 
          if($liuxTimeStamp !="XXXXXX")
          {
              $recordedTimeStamp = date("Y-m-d H:i:s",$input[0]['TS']);
              $telDate =$input[0]['DT'];
              $teltonika_date = str_replace('/', '-', $telDate);
              $teltonikaTimeStamp =  date('Y-m-d H:i:s', strtotime($teltonika_date));
          }
          else
          {
              $liuxTimeStamp='';
              $recordedTimeStamp = ''; 
			  $teltonikaTimeStamp='';
          
          }
// echo  $inputJSON;
echo $voltage_l1_n; 
if(isset($arrRemoveFirstSegment) && isset($arrRemoveSecondSegment)){
 echo $insertQry="INSERT INTO `power_factor_energy_data` (`gateway_code`, `sensor_code`, `sensor_model`, `voltage_l1_n`, `voltage_l2_n`, `voltage_l3_n`, `voltage_l4_n`, `voltage_l1_l2`, `voltage_l2_l3`, `voltage_l3_l1`, `current_l1`, `current_l2`, `current_l3`, `measured_frequency`, `active_power_l1_n`, `active_power_l2_n`, `active_power_l3_n`, `total_import_active_power`, `total_export_active_power`, `total_active_power`, `reactive_power_l1`, `reactive_power_l2`, `reactive_power_l3`, `reactive_power_l4`, `total_reactive_power`, `apparent_power_l1_n`, `apparent_power_l2_n`, `apparent_power_l3_n`, `apparent_power_l4_n`, `power_factor_l1`, `power_factor_l2`, `power_factor_l3`, `power_factor_l4`, `power_factor_total_import`, `cospi_l1`, `cospi_l2`, `cospi_l3`, `cospi_total_import`, `step1_actual_steps_value`, `step2_actual_steps_value`, `step3_actual_steps_value`, `step4_actual_steps_value`, `step5_actual_steps_value`, `step6_actual_steps_value`, `step7_actual_steps_value`, `step8_actual_steps_value`, `step9_actual_steps_value`, `step10_actual_steps_value`, `step11_actual_steps_value`, `step12_actual_steps_value`, `step13_actual_steps_value`, `step14_actual_steps_value`, `step15_actual_steps_value`, `step16_actual_steps_value`, `step17_actual_steps_value`, `step18_actual_steps_value`, `step19_actual_steps_value`, `step20_actual_steps_value`, `VR_ARRAY_VALUE`, `linux_date_time`, `teltonika_date_time`, `recorded_date_time`, `posted_date_time`) VALUES ('".$gatewayCode."', '".$sensorCode."', '".$sensorModel."', '".$voltage_l1_n."','".$voltage_l2_n."','".$voltage_l3_n."','".$voltage_l4_n."','".$voltage_l1_l2."','".$voltage_l2_l3."','".$voltage_l3_l1."','".$current_l1."','".$current_l2."','".$current_l3."','".$measured_frequency."','".$active_power_l1_n."','".$active_power_l2_n."','".$active_power_l3_n."','".$total_import_active_power."','".$total_export_active_power."','".$total_active_power."','".$reactive_power_l1."','".$reactive_power_l2."','".$reactive_power_l3."','".$reactive_power_l4."','".$total_reactive_power."','".$apparent_power_l1_n."','".$apparent_power_l2_n."','".$apparent_power_l3_n."','".$apparent_power_l4_n."','".$power_factor_l1."','".$power_factor_l2."','".$power_factor_l3."','".$power_factor_l4."','".$power_factor_total_import."','".$cospi_l1."','".$cospi_l2."','".$cospi_l3."','".$cospi_total_import."','".$step1_actual_steps_value."','".$step2_actual_steps_value."','".$step3_actual_steps_value."','".$step4_actual_steps_value."','".$step5_actual_steps_value."','".$step6_actual_steps_value."','".$step7_actual_steps_value."','".$step8_actual_steps_value."','".$step9_actual_steps_value."','".$step10_actual_steps_value."','".$step11_actual_steps_value."','".$step12_actual_steps_value."','".$step13_actual_steps_value."','".$step14_actual_steps_value."','".$step15_actual_steps_value."','".$step16_actual_steps_value."','".$step17_actual_steps_value."','".$step18_actual_steps_value."','".$step19_actual_steps_value."','".$step20_actual_steps_value."','".$inputJSON2."','".$liuxTimeStamp."','".$telDate."','".$teltonikaTimeStamp."',NOW())"; 


  $insExec = $conn->query($insertQry);
     
        
        if ($insExec === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $insertQry . "<br>" . $conn->error;
        }


 	   $selectView= "SELECT * FROM `power_factor_energy_data_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."'";
       $resultView = mysqli_query($conn, $selectView);
	   $rowcount=mysqli_num_rows($resultView);
	   if($rowcount==0){
			
		 $sql2="INSERT INTO `power_factor_energy_data_view` (`gateway_code`, `sensor_code`, `sensor_model`, `voltage_l1_n`, `voltage_l2_n`, `voltage_l3_n`, `voltage_l4_n`, `voltage_l1_l2`, `voltage_l2_l3`, `voltage_l3_l1`, `current_l1`, `current_l2`, `current_l3`, `measured_frequency`, `active_power_l1_n`, `active_power_l2_n`, `active_power_l3_n`, `total_import_active_power`, `total_export_active_power`, `total_active_power`, `reactive_power_l1`, `reactive_power_l2`, `reactive_power_l3`, `reactive_power_l4`, `total_reactive_power`, `apparent_power_l1_n`, `apparent_power_l2_n`, `apparent_power_l3_n`, `apparent_power_l4_n`, `power_factor_l1`, `power_factor_l2`, `power_factor_l3`, `power_factor_l4`, `power_factor_total_import`, `cospi_l1`, `cospi_l2`, `cospi_l3`, `cospi_total_import`, `step1_actual_steps_value`, `step2_actual_steps_value`, `step3_actual_steps_value`, `step4_actual_steps_value`, `step5_actual_steps_value`, `step6_actual_steps_value`, `step7_actual_steps_value`, `step8_actual_steps_value`, `step9_actual_steps_value`, `step10_actual_steps_value`, `step11_actual_steps_value`, `step12_actual_steps_value`, `step13_actual_steps_value`, `step14_actual_steps_value`, `step15_actual_steps_value`, `step16_actual_steps_value`, `step17_actual_steps_value`, `step18_actual_steps_value`, `step19_actual_steps_value`, `step20_actual_steps_value`, `VR_ARRAY_VALUE`, `linux_date_time`, `teltonika_date_time`, `recorded_date_time`, `posted_date_time`) VALUES ('".$gatewayCode."', '".$sensorCode."', '".$sensorModel."', '".$voltage_l1_n."','".$voltage_l2_n."','".$voltage_l3_n."','".$voltage_l4_n."','".$voltage_l1_l2."','".$voltage_l2_l3."','".$voltage_l3_l1."','".$current_l1."','".$current_l2."','".$current_l3."','".$measured_frequency."','".$active_power_l1_n."','".$active_power_l2_n."','".$active_power_l3_n."','".$total_import_active_power."','".$total_export_active_power."','".$total_active_power."','".$reactive_power_l1."','".$reactive_power_l2."','".$reactive_power_l3."','".$reactive_power_l4."','".$total_reactive_power."','".$apparent_power_l1_n."','".$apparent_power_l2_n."','".$apparent_power_l3_n."','".$apparent_power_l4_n."','".$power_factor_l1."','".$power_factor_l2."','".$power_factor_l3."','".$power_factor_l4."','".$power_factor_total_import."','".$cospi_l1."','".$cospi_l2."','".$cospi_l3."','".$cospi_total_import."','".$step1_actual_steps_value."','".$step2_actual_steps_value."','".$step3_actual_steps_value."','".$step4_actual_steps_value."','".$step5_actual_steps_value."','".$step6_actual_steps_value."','".$step7_actual_steps_value."','".$step8_actual_steps_value."','".$step9_actual_steps_value."','".$step10_actual_steps_value."','".$step11_actual_steps_value."','".$step12_actual_steps_value."','".$step13_actual_steps_value."','".$step14_actual_steps_value."','".$step15_actual_steps_value."','".$step16_actual_steps_value."','".$step17_actual_steps_value."','".$step18_actual_steps_value."','".$step19_actual_steps_value."','".$step20_actual_steps_value."','".$inputJSON2."','".$liuxTimeStamp."','".$telDate."','".$teltonikaTimeStamp."',NOW())";
		
      }else{
		   		
					 $sql2= " UPDATE `power_factor_energy_data_view` SET `gateway_code`='".$gatewayCode."', `sensor_code`='".$sensorCode."', `sensor_model`='".$sensorModel."', `voltage_l1_n`='".$voltage_l1_n."', `voltage_l2_n`='".$voltage_l2_n."', `voltage_l3_n`='".$voltage_l3_n."',`voltage_l4_n`='".$voltage_l4_n."', `voltage_l1_l2`='".$voltage_l1_l2."', `voltage_l2_l3`='".$voltage_l2_l3."', `voltage_l3_l1`='".$voltage_l3_l1."', `current_l1`='".$current_l1."', `current_l2`='".$current_l2."', `current_l3`='".$current_l3."', `measured_frequency`='".$measured_frequency."',`active_power_l1_n`='".$active_power_l1_n."', `active_power_l2_n`='".$active_power_l2_n."', `active_power_l3_n`='".$active_power_l3_n."', `total_import_active_power`='".$total_import_active_power."', `total_export_active_power`='".$total_export_active_power."', `total_active_power`='".$total_active_power."', `reactive_power_l1`='".$reactive_power_l1."', `reactive_power_l2`='".$reactive_power_l2."', `reactive_power_l3`='".$reactive_power_l3."', `reactive_power_l4`='".$reactive_power_l4."', `total_reactive_power`='".$total_reactive_power."', `apparent_power_l1_n`='".$apparent_power_l1_n."', `apparent_power_l2_n`='".$apparent_power_l2_n."', `apparent_power_l3_n`= '".$apparent_power_l3_n."',`apparent_power_l4_n`='".$apparent_power_l4_n."', `power_factor_l1`='".$power_factor_l1."', `power_factor_l2`='".$power_factor_l2."', `power_factor_l3`='".$power_factor_l3."', `power_factor_l4`='".$power_factor_l4."', `power_factor_total_import`='".$power_factor_total_import."', `cospi_l1`='".$cospi_l1."', `cospi_l2`='".$cospi_l2."', `cospi_l3`='".$cospi_l3."', `cospi_total_import`='".$cospi_total_import."', `step1_actual_steps_value`='".$step1_actual_steps_value."', `step2_actual_steps_value`='".$step2_actual_steps_value."', `step3_actual_steps_value`='".$step3_actual_steps_value."', `step4_actual_steps_value`='".$step4_actual_steps_value."', `step5_actual_steps_value`='".$step5_actual_steps_value."', `step6_actual_steps_value`='".$step6_actual_steps_value."', `step7_actual_steps_value`='".$step7_actual_steps_value."', `step8_actual_steps_value`='".$step8_actual_steps_value."', `step9_actual_steps_value`='".$step9_actual_steps_value."', `step10_actual_steps_value`='".$step10_actual_steps_value."', `step11_actual_steps_value`='".$step11_actual_steps_value."', `step12_actual_steps_value`='".$step12_actual_steps_value."', `step13_actual_steps_value`='".$step13_actual_steps_value."',`step14_actual_steps_value`='".$step14_actual_steps_value."', `step15_actual_steps_value`='".$step15_actual_steps_value."', `step16_actual_steps_value`='".$step16_actual_steps_value."', `step17_actual_steps_value`='".$step17_actual_steps_value."', `step18_actual_steps_value`='".$step18_actual_steps_value."',`step19_actual_steps_value`='".$step19_actual_steps_value."', `step20_actual_steps_value`='".$step20_actual_steps_value."', `VR_ARRAY_VALUE`='".$inputJSON2."', `linux_date_time`='".$liuxTimeStamp."', `teltonika_date_time`='".$telDate."', `recorded_date_time`='".$teltonikaTimeStamp."', `posted_date_time`=NOW() WHERE `sensor_code`='".$sensorCode."'";
				

	  
	  }
        $insSel2 = $conn->query($sql2);
     
        
        if ($insSel2 === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $sql2 . "<br>" . $conn->error;
        }
        
        
        
        /*******************************************             Mail Trigger  Starts            ****************************************************/
	   $selAlertCont= "SELECT email FROM `arka_alert_contact_master` WHERE email_alert=1 AND is_active=1 AND `company_id`='".$sensMasDet['company_id']."' AND `branch_id`='".$sensMasDet['branch_id']."'";
       $ExeAlertCont = mysqli_query($conn, $selAlertCont);
	   if (mysqli_num_rows($ExeAlertCont) > 0) 
	   {
			 $alertContact='';
			 while($alertCont = mysqli_fetch_assoc($ExeAlertCont)) 
			{
			// Fetch all
			   $alertContact .= $alertCont['email'].",";
			}
		//	$string = rtrim($string, ".");
			$alertEmail= rtrim($alertContact, ",");
			echo $alertEmail." -- EmailId from Table <br>";
       } 
	   
	   $selAlertPar= "SELECT * FROM `alert_parameter_mapping` WHERE `sensor_code`='".$sensorCode."'";
       $ExeAlertPar = mysqli_query($conn, $selAlertPar);
	   
	   if (mysqli_num_rows($ExeAlertPar) > 0) 
	   {
	      echo "alert parameter Mapping";
            while($parameter = mysqli_fetch_assoc($ExeAlertPar)) 
			{ 
			 echo $parameter['parameter_name']."-  Parameter Name <br>";
			  echo $parameter['mail_alert_status'];
				$parameterName=$parameter['parameter_name'];
				if($parameter['mail_alert_status']=="Normal")
				{
              echo $selectEnergy= "SELECT ".$parameterName." FROM `power_factor_energy_data_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND (".$parameterName." <= '".$parameter['min_alert_value']."' OR ".$parameterName." >= '".$parameter['max_alert_value']."')";
			  $ExeEnergy = mysqli_query($conn, $selectEnergy);
	           $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
				  if($ReadingValue > $parameter['max_alert_value']){
				  $alertStatus='High';
				  $alertValueName='Max Value Reached';
				  }
				  elseif($ReadingValue < $parameter['min_alert_value']){
				  $alertStatus='Low';
				  $alertValueName='Min Value Reached';
				  }
			  }else if($parameter['mail_alert_status']=="High"){
			  $selectEnergy= "SELECT ".$parameterName." FROM `power_factor_energy_data_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND (".$parameterName." > '".$parameter['min_alert_value']."' AND ".$parameterName." < '".$parameter['max_alert_value']."')";
			  $ExeEnergy = mysqli_query($conn, $selectEnergy);
			  if (mysqli_num_rows($ExeEnergy) == 0) 
				{
				 $selectEnergy= "SELECT ".$parameterName." FROM `power_factor_energy_data_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND ".$parameterName." <= '".$parameter['min_alert_value']."'";
			   $ExeEnergy = mysqli_query($conn, $selectEnergy);
	           $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='Low';
			   $alertValueName='Min Value Reached';
			   
			   }
			   else{
			   
			   $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='Normal';
			   $alertValueName='Normal Value Reached';
			   
			   }
			  }
			  else if($parameter['mail_alert_status']=="Low" ){
			  $selectEnergy= "SELECT ".$parameterName." FROM `power_factor_energy_data_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND (".$parameterName." > '".$parameter['min_alert_value']."' AND ".$parameterName." < '".$parameter['max_alert_value']."')";
			  $ExeEnergy = mysqli_query($conn, $selectEnergy);
	          if (mysqli_num_rows($ExeEnergy) == 0) 
				{
				 $selectEnergy= "SELECT ".$parameterName." FROM `power_factor_energy_data_view` WHERE `gateway_code`='".$gatewayCode."' AND `sensor_code`='".$sensorCode."' AND ".$parameterName." >= '".$parameter['max_alert_value']."'";
			   $ExeEnergy = mysqli_query($conn, $selectEnergy);
	           $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='High';
			   $alertValueName='Max Value Reached';
			   
			   }
			   else{
			   
			   $rsltEnergy = mysqli_fetch_assoc($ExeEnergy);
			   $ReadingValue= $rsltEnergy[$parameterName];
			   $alertStatus='Normal';
			   $alertValueName='Normal Value Reached';
			   
			   }
			  }
			  
			 /* $message .= "Hi!<br><br><br>
	
								<b>Feeder Name</b>      : ".$parameter['feeder_name'].",<br>
								<b>Parameter Name</b>   : ".$parameter['parameter_name'].",<br>
								<b>".$alertValueName."</b>  : ".$ReadingValue.".<br><br><br><br><br>
	
	
								
                                <b>Best regards</b>,<br>
                                <b>Arka Automaations Limited.</b><br>
								";
								
				  $contentData=strip_tags($message);
								
			 $insAlertLog	="INSERT INTO `alert_log_master`(`company_id`, `branch_id`, `sensor_code`, `alert_type`, `parameter_name`, `alert_message`, `send_to`, `alert_status`, `recorded_date_time`, `posted_date_time`) VALUES ('".$sensMasDet['company_id']."','".$sensMasDet['branch_id']."','".$sensorCode."','Mail','".$parameter['parameter_name']."','".$contentData."','".$alertEmail."','".$alertStatus."','".$teltonikaTimeStamp."',DATE_ADD(NOW(),INTERVAL '00:00' HOUR_MINUTE))";		
			 $insLog = $conn->query($insAlertLog);*/
			  
			echo   $alertStatus." --alert Status <br>".$alertValueName." --alert Value <br>".mysqli_num_rows($ExeEnergy);
			   
			    if (mysqli_num_rows($ExeEnergy) > 0) 
				{
				
			    echo $updateAlertPar= "UPDATE `alert_parameter_mapping` SET mail_alert_status='".$alertStatus."'  WHERE `alert_parameter_id`='".$parameter['alert_parameter_id']."'";
       			 $ExeAlertPar = mysqli_query($conn, $updateAlertPar);
				     echo $ReadingValue."-  Reading Value <br>";
				     echo $alertEmail."-  MailId <br>"; 
				     
				     $selectSensor= "SELECT * FROM `arka_sensor_master` WHERE `sensorCode`='".$parameter['sensor_code']."' AND status='1' AND isActive='1'";
			   $ExeSensor = mysqli_query($conn, $selectSensor);
	           $ExeSensorArr = mysqli_fetch_assoc($ExeSensor);
			  $sensorNameVal = $ExeSensorArr['sensorName'];
				     
				  // Step 1 - Enter your email address below.
$email = 'aal@arkaautomaations.com';

// If the e-mail is not working, change the debug option to 2 | $debug = 2;
$debug = 0;

// If contact form don't has the subject input change the value of subject here
//$subject = 'Parameter Alert';
$subject = $parameter['feeder_name'];
$message = '';

				   $message .= "ARKA EMS - Alert Message!<br><br><br>
	
								<b>Feeder Name</b>      : ".$parameter['feeder_name'].",<br>
								<b>Parameter Name</b>   : ".$parameter['parameter_name'].",<br>
								<b>".$alertValueName."</b>  : ".$ReadingValue.".<br><br><br><br><br>
	
	
								
                                <br>
								";
								
				  $contentData=strip_tags($message);
								
							
			 $insAlertLog	="INSERT INTO `alert_log_master`(`company_id`, `branch_id`, `sensor_code`, `alert_type`, `parameter_name`, `alert_message`, `send_to`, `alert_status`, `recorded_date_time`, `posted_date_time`) VALUES ('".$sensMasDet['company_id']."','".$sensMasDet['branch_id']."','".$sensorCode."','Mail','".$parameter['parameter_name']."','".$contentData."','".$alertEmail."','".$alertStatus."','".$teltonikaTimeStamp."',DATE_ADD(NOW(),INTERVAL '00:00' HOUR_MINUTE))";		
			 $insLog = $conn->query($insAlertLog);
     
        
        if ($insLog === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $insAlertLog . "<br>" . $conn->error;
        }
            	    
$mail = new PHPMailer(true);

try {
if($alertStatus<>"Normal")
{
	$mail->SMTPDebug = $debug;                                 // Debug Mode

	// Step 2 (Optional) - If you don't receive the email, try to configure the parameters below:

	$mail->IsSMTP();                                         // Set mailer to use SMTP
	$mail->Host = 'smtpout.asia.secureserver.net';				       // Specify main and backup server
	$mail->SMTPAuth = true;                                  // Enable SMTP authentication
//	$mail->Username = 'info@plumtekerp.in';                    // SMTP username
//	$mail->Password = 'Admin@2020';
//	$mail->Username = 'aal@arkaautomaations.com';                    // SMTP username
//  $mail->Password = 'Arka@2020';// SMTP password
     $mail->Username = 'tpl@tiebarfactory.com';                    // SMTP username
   //  $mail->Password = 'tpl6k@2020';// SMTP password
     $mail->Password = 'tpl@tiebar';
	$mail->SMTPAutoTLS = false;                               // Enable encryption, 'ssl' also accepted
	$mail->Port = 80;   								       // TCP port to connect to

//	$mail->AddAddress('vishalchandran11@gmail.com');	 						       // Add another recipient
    
	//  ***************     To Mail Starts  *************************
	$toMailArr =explode(",",$alertEmail);
    $toMailCount = count($toMailArr);
    $mailC=0;
    for($mailC==0; $mailC<$toMailCount; $mailC++){
        $mail->AddAddress($toMailArr[$mailC]);
    }   
	//  *************  To Mail Ends.... ***************************
	 
	//$mail->AddAddress($alertEmail);     // Add a secondary recipient
//	$mail->AddCC('karthikeyan@arkagroup.co.in');          // Add a "Cc" address. 
	//$mail->AddBCC('person4@domain.com', 'Person 4');         // Add a "Bcc" address. 

	// From - Name
	$fromName = 'Arka Automaations Limited';
	$mail->SetFrom($email, $fromName);

	// Repply To
/*	if( isset($_POST['email']) ) {
		$mail->AddReplyTo($_POST['email'], $fromName);
	}*/

	$mail->IsHTML(true);                                       // Set email format to HTML

	$mail->CharSet = 'UTF-8';

	$mail->Subject = $subject;
	$mail->Body    = $message;

	$mail->Send();
	$arrResult = array ('response'=>'success');
}
} catch (Exception $e) {
	$arrResult = array ('response'=>'error','errorMessage'=>$e->errorMessage());
} catch (\Exception $e) {
	$arrResult = array ('response'=>'error','errorMessage'=>$e->getMessage());
}


$selAlertCont= "SELECT mobile FROM `arka_alert_contact_master` WHERE sms_alert=1 AND is_active=1 AND `company_id`='".$sensMasDet['company_id']."' AND `branch_id`='".$sensMasDet['branch_id']."'";
       $ExeAlertCont = mysqli_query($conn, $selAlertCont);
	   
	    $selBranchCont= "SELECT branch_name FROM `arka_branch_master` WHERE record_status=1 AND is_active=1 AND `company_id`='".$sensMasDet['company_id']."' AND `sl_no`='".$sensMasDet['branch_id']."'";
       $ExeBranchCont = mysqli_query($conn, $selBranchCont);
	   $BranchCont = mysqli_fetch_assoc($ExeBranchCont);
	   
	   if (mysqli_num_rows($ExeAlertCont) > 0) 
	   {
			 $alertContact='';
			 while($alertCont = mysqli_fetch_assoc($ExeAlertCont)) 
			{
			// Fetch all
			   $alertContact .= $alertCont['mobile'].",";
			   
								$apiKey = urlencode('bdv8P3QD1RM-00HgVBfsXFz4FiL7WN35p7HCcrGj1M');
// Message details
//$numbers = urlencode('919884422723'); //Mobile number on which you want to send message
$numbers = urlencode($alertContact);
$sender = urlencode('AALIOT');
/*$message = rawurlencode('Device Code : dev1001,
Installed at : Guindy,
 R_Voltagr : 100, 
at 08/11/2021 10:58:00'); */
$teltonikaTimeStamp = str_replace('-', '/', $teltonikaTimeStamp);
$teltonikaTimeStamp =  date('H:i d/m/Y', strtotime($teltonika_date));
$devId=$parameter['feeder_name'];
$area=$BranchCont['branch_name'];
$datVar=$parameter['parameter_name'];
$datVal=$ReadingValue.' - '.$alertValueName;
$datTime=$teltonikaTimeStamp;

/*$devId='dev1001';
$area='Guindy';
$datVar='R_Voltagr';
$datVal='100';
$datTime='08/11/2021 17:35:00';*/

$message = rawurlencode('Device Code : '.$devId.',
Installed at : '.$area.',
 '.$datVar.' : '.$datVal.', 
at '.$datTime.'');

// Prepare data for POST request
$data = 'apikey=' . $apiKey . '&numbers=' . $numbers . "&sender=" . $sender . "&message=" . $message;
// Send the GET request with cURL
$ch = curl_init('https://api.textlocal.in/send/?' . $data);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);
// Process your response here
echo $response;
			}
			}

		if ($debug == 0) {
	echo json_encode($arrResult);
}	
				 	
			 }
			   
            }
       } 
	   
/*******************************************             Mail Trigger   End          ****************************************************/
}
}


     
}
else {
    echo "No data posted with HTTP POST.";
}


function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>
