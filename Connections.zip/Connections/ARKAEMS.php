<?php

/*$hostname_arkaems = "localhost";
$database_arkaems = "smart_ems";
$username_arkaems = "root";
$password_arkaems = "";
*/


$hostname_arkaems = "148.66.130.228";
$database_arkaems = "greatelephanttec_ems";
$username_arkaems = "greatelephanttec_ems_user";
$password_arkaems = "GetEms@2025";

$arkaerp = mysql_connect($hostname_arkaems, $username_arkaems, $password_arkaems) or trigger_error(mysql_error(),E_USER_ERROR);

?>
