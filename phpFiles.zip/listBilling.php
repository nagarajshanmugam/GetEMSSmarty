<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.CronData.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";
	
		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objStaff -> GetCompanyName();		
		$objCronData = new CronData();
		//$objCronData -> ListBillingMonthly($objArray);
		if(isset($_POST['branchName']))
		{
			$objCronData -> ListBillingMonthly($objArray);
		}
		if(isset($_GET['branchId']))
		{
			$objCronData -> ListBillingMonthly($objArray);
		}
		if($_SESSION['branch_id'] <> '0')
		{
			$objCronData -> ListBillingMonthly($objArray);
		}
		$objCronData -> sensorList($objArray);
		$objCronData -> GetBranchName($objArray);
		$objCronData -> GetGatewayName($objArray);
		$objCronData -> ListBranch($objArray);
		
		if(isset($_GET['MId']) && isset($_GET['CId']) && isset($_GET['BId']))
		{   
			$objCronData->CreateInvoice($_GET['MId'],$_GET['CId'],$_GET['BId']);
		}
		if(isset($_GET['succs_msg_for_del']))
		{
			$objSmarty->assign('SuccessMessage', 'Record Deleted Successfully');
		}
		if(isset($_GET['success_msg_for_update']))
		{
			$objSmarty->assign('SuccessMessage', 'Record Updated Successfully');
		}
		if(isset($_GET['success_msg_for_insert']))
		{
			$objSmarty->assign('SuccessMessage', 'Record Created Successfully');
		}
	
	
		$objSmarty->assign('IncludeTpl', 'listBilling.tpl');
		$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Billing List');
		$objSmarty->assign('robots','index,follow');
		$objSmarty->assign('key_word','');
		$objSmarty->assign('generator','');
		$objSmarty->assign('document-state','dynamic');
		$objSmarty->assign('address',$config['SiteGlobalPath']);
		
		/*Display page*/
		$objSmarty->assign('LeftTpl', 'left.tpl');
		$objSmarty->display('pagetemplate.tpl');

?>