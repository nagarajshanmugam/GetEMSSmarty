<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.ReportsMgmt.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";
	
		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objStaff -> GetCompanyName();
		$objReportsMgmt = new ReportsMgmt();
		$objReportsMgmt -> SensorList($objArray);
		$objReportsMgmt -> BranchList($objArray);
		$objReportsMgmt -> ShiftTimeList();
		$objReportsMgmt -> ShiftList();
		$objSmarty->assign('sensorName', $_POST['sensorName']);
		$objSmarty->assign('yesterday', strtotime('-1 day'));
		/*command by 01-06-2021*/
	    /*$objReportsMgmt -> ShiftWiseReports($objArray);*/
    	/*command by 01-06-2021*/
		if(isset($_POST['sensorName']))
		{
			$objReportsMgmt -> ShiftWiseReports($_POST['sensorName']);
		}
		$objReportsMgmt -> GetGatewayName($objArray);
		if(isset($_GET['succs_msg_for_del']))
		{
			$objSmarty->assign('SuccessMessage', 'Record Deleted Successfully');
		}
		if(isset($_GET['success_msg_for_update']))
		{
			$objSmarty->assign('SuccessMessage', 'Record Updated Successfully');
		}
		if(isset($_GET['success_msg_for_insert']))
		{
			$objSmarty->assign('SuccessMessage', 'Record Created Successfully');
		}
	
		$objSmarty->assign('IncludeTpl', 'shiftWiseReports.tpl');
		$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Shift Wise Reports');
		$objSmarty->assign('robots','index,follow');
		$objSmarty->assign('key_word','');
		$objSmarty->assign('generator','');
		$objSmarty->assign('document-state','dynamic');
		$objSmarty->assign('address',$config['SiteGlobalPath']);
		
		
		/*Display page*/
		$objSmarty->assign('LeftTpl', 'left.tpl');
		$objSmarty->display('pagetemplate.tpl');

?>