<?php
/**
 * PHPExcel
 *
 * Copyright (C) 2006 - 2013 PHPExcel
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @category   PHPExcel
 * @package    PHPExcel
 * @copyright  Copyright (c) 2006 - 2013 PHPExcel (http://www.codeplex.com/PHPExcel)
 * @license    http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt	LGPL
 * @version    1.7.9, 2013-06-02
 */

/** Error reporting */
error_reporting(E_ALL);

/** Include PHPExcel */

require('includes/common.php');
require_once('./Connections/ARKAEMS.php');
require_once dirname(__FILE__) . '/Classes/PHPExcel.php';


// Create new PHPExcel object
//echo date('H:i:s') , " Create new PHPExcel object" , EOL;
$objPHPExcel = new PHPExcel();

// Set document properties
//echo date('H:i:s') , " Set document properties" , EOL;
$objPHPExcel->getProperties()->setCreator("Arka Automaations Ltd")
							 ->setLastModifiedBy("Arka Automaations Ltd")
							 ->setTitle("Office 2007 XLSX Test Document")
							 ->setSubject("Office 2007 XLSX Test Document")
							 ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
							 ->setKeywords("office 2007 openxml php")
							 ->setCategory("Test result file");



// Create a first sheet, representing sales data
//echo date('H:i:s') , " Add some data" , EOL;

// ********************************************Get Url Data ********************************************************
// echo $_GET['fromDate']; exit;
$fromDate=$_GET['fromDate'];
$toDate=$_GET['toDate'];
$sensorCode =$_GET['sensorCode'];
if($_GET['sensorCode']=='EM6400-1' || $_GET['sensorCode']=='EM6400-2'){
	$whrsens='(`sensorCode`="EM6400-1" OR `sensorCode`="EM6400-2")';
	$selSens='SELECT GROUP_CONCAT(sensorName) AS sensorNames, arka_sensor_master.* FROM arka_sensor_master WHERE (`sensorCode`="EM6400-1" OR `sensorCode`="EM6400-2") GROUP BY branch_id';
}else{
	$whrsens='`sensorCode`="'.$_GET["sensorCode"].'"';
	$selSens='SELECT sensorName AS sensorNames, arka_sensor_master.* FROM arka_sensor_master WHERE `sensorCode`="'.$_GET["sensorCode"].'" ';
}

$sensQry = mysql_query($selSens, $arkaerp) or die(mysql_error());
$sensData = mysql_fetch_assoc($sensQry);
//print_r( $sensData); exit;
$selShift = 'SELECT * from arka_branch_shift_master WHERE is_active="1" AND  status="1" AND company_id="'.$sensData["company_id"].'" AND branch_id="'.$sensData["branch_id"].'" GROUP BY shift_name ORDER BY shift_master_id' ;  
$shiftQry = mysql_query($selShift, $arkaerp) or die(mysql_error());
$ListShiftCount = mysql_num_rows($shiftQry);


$fdate = date("d-M-Y", strtotime($_GET['fromDate'])); 
$tdate = date("d-M-Y", strtotime($_GET['toDate'])); 

$objPHPExcel->setActiveSheetIndex(0);
$objPHPExcel->getActiveSheet()->mergeCells('A3:M3');
$objPHPExcel->getActiveSheet()->setCellValue('A3', 'Production Report Shift Wise  From:  '.$fdate.'  - To:  '.$tdate);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFont()->setSize(18);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFill()->getStartColor()->setARGB('FF1E90FF');

$objPHPExcel->getActiveSheet()->mergeCells('A1:B1');
$objPHPExcel->getActiveSheet()->setCellValue('A1', '');
$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->mergeCells('C1:D1');
$objPHPExcel->getActiveSheet()->setCellValue('C1', '');
$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('C1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->mergeCells('D1:E1');
$objPHPExcel->getActiveSheet()->setCellValue('D1', '');
$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('D1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('G1', '');
$objPHPExcel->getActiveSheet()->getStyle('G1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setSize(12);

	 
	 $selCom='SELECT * FROM arka_company_master WHERE slNo="'.$sensData["company_id"].'"';
	 $compExe = mysql_query($selCom, $arkaerp) or die(mysql_error());
	 $resComp = mysql_fetch_assoc($compExe);
	 
	 $selBranch='SELECT * FROM arka_branch_master WHERE sl_no="'.$sensData["branch_id"].'"';
	 $branchExe = mysql_query($selBranch, $arkaerp) or die(mysql_error());
	 $resBranch = mysql_fetch_assoc($branchExe);
	
	$companyName = $resComp['companyName'];
	$branchName = $resBranch['branch_name'];

	$sensorName = $sensData['sensorNames'];
	//echo $row1['unit_rate']; exit;
	
//$objPHPExcel->getActiveSheet()->mergeCells('A4:B4');
$objPHPExcel->getActiveSheet()->setCellValue('A4', 'Branch :');
$objPHPExcel->getActiveSheet()->getStyle('A4')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A4')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('B4', $branchName);
$objPHPExcel->getActiveSheet()->getStyle('B4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('B4')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('G4', 'Energy Meter :');
$objPHPExcel->getActiveSheet()->getStyle('G4')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('G4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('G4')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->mergeCells('H4:I4');
$objPHPExcel->getActiveSheet()->setCellValue('H4', $sensorName);
$objPHPExcel->getActiveSheet()->getStyle('H4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('H4')->getFont()->setSize(12);


			$objPHPExcel->getActiveSheet()->mergeCells('A5:A6');
			$objPHPExcel->getActiveSheet()->setCellValue('A5', 'Date');

			$objPHPExcel->getActiveSheet()->mergeCells('B5:D5');
			$objPHPExcel->getActiveSheet()->setCellValue('B5', 'Shift-1');
			$objPHPExcel->getActiveSheet()->setCellValue('B6', 'Production');
			$objPHPExcel->getActiveSheet()->setCellValue('C6', 'KWH');
			$objPHPExcel->getActiveSheet()->setCellValue('D6', 'Cost');
			
			$objPHPExcel->getActiveSheet()->mergeCells('E5:G5');
			$objPHPExcel->getActiveSheet()->setCellValue('E5', 'Shift-2');
			$objPHPExcel->getActiveSheet()->setCellValue('E6', 'Production');
			$objPHPExcel->getActiveSheet()->setCellValue('F6', 'KWH');
			$objPHPExcel->getActiveSheet()->setCellValue('G6', 'Cost');
			
			$objPHPExcel->getActiveSheet()->mergeCells('H5:J5');
			$objPHPExcel->getActiveSheet()->setCellValue('H5', 'Shift-3');
			$objPHPExcel->getActiveSheet()->setCellValue('H6', 'Production');
			$objPHPExcel->getActiveSheet()->setCellValue('I6', 'KWH');
			$objPHPExcel->getActiveSheet()->setCellValue('J6', 'Cost');
			
			$objPHPExcel->getActiveSheet()->mergeCells('K5:K6');
			$objPHPExcel->getActiveSheet()->setCellValue('K5', 'Total Production');
			
			$objPHPExcel->getActiveSheet()->mergeCells('L5:L6');
			$objPHPExcel->getActiveSheet()->setCellValue('L5', 'Total KWH');
			
			$objPHPExcel->getActiveSheet()->mergeCells('M5:M6');
			$objPHPExcel->getActiveSheet()->setCellValue('M5', 'Total Cost');
			
			

			
			mysql_select_db($database_arkaems, $arkaerp);

			if($sensData["branch_id"]=='0')
			{
				$whrCl='AND company_id="'.$sensData["company_id"].'"';
			}
			else{
				$whrCl='AND company_id="'.$sensData["company_id"].'" AND branch_id="'.$sensData["branch_id"].'"';
			}
			
			if($fromDate=='' && $toDate=='')
			{
				$whereClause='recorded_date BETWEEN  DATE_FORMAT(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE), "%Y-%m-01") AND DATE_FORMAT(DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE), "%Y-%m-%d")';
			}
			else
			{
				$whereClause='recorded_date BETWEEN  "'.$fromDate.'" AND "'.$toDate.'"';
			}
			
			if($_GET['sensorCode']=='EM6400-1' || $_GET['sensorCode']=='EM6400-2'){
			$sensCond='(`sensor_code`="EM6400-1" OR `sensor_code`="EM6400-2")';
			}else{
			$sensCond='`sensor_code`="'.$_GET['sensorCode'].'"';
			}
		$shiftCond;
		$selCon;
		$c='A';
		$sh=0;
		while( $row = mysql_fetch_array($shiftQry) ){
		if($sh==0){
		$parStart="firstShift";
		}
		if($sh==1){
		$parStart="secondShift";
		}
		if($sh==2){
		$parStart="thirdShift";
		}
		if($sh==3){
		$parStart="fourthShift";
		}
	  
		$selCon .=''.$c.'.`sensor_code` AS sensor_code, '.$c.'.`recorded_date` AS recorded_date, '.$c.'.consuption_kwh AS '.$parStart.'KWH,'.$c.'.consuption_cost AS '.$parStart.'Cost,'.$c.'.production AS '.$parStart.'Production,';
		
		$shiftCond .='(SELECT cron_daily_shift_wise_data.`sensor_code` AS sensor_code,SUM(cron_daily_shift_wise_data.`consuption_kwh`) AS consuption_kwh, SUM(cron_daily_shift_wise_data.`consuption_cost`) AS consuption_cost,cron_daily_shift_wise_data.recorded_date,SUM(cron_daily_shift_wise_data.`production`) AS production
		FROM cron_daily_shift_wise_data WHERE '.$whereClause.' AND shift_master_id="'.$row['shift_master_id'].'" AND '.$sensCond.' GROUP BY recorded_date) AS '.$c.',';
		
		$c++;
		$sh++;
		}
		
		$feilds11= rtrim($selCon, ",");
		$tabeles11= rtrim($shiftCond, ",");
	
	
		$SelQuery = 'SELECT '.$feilds11.' FROM '.$tabeles11.' WHERE  A.recorded_date=B.recorded_date AND B.recorded_date=C.recorded_date AND C.recorded_date=A.recorded_date GROUP BY A.`recorded_date` ORDER BY A.`recorded_date` DESC';
		 $resultProd = mysql_query($SelQuery, $arkaerp) or die(mysql_error());
	     $resComp = mysql_fetch_assoc($compExe);
		
		
		
$loop =7;
while( $row2 = mysql_fetch_array($resultProd) ) {
    
   

	
 
    
    $recDate = $row2['recorded_date'];  
    $recordDate = date("d-M-Y", strtotime($recDate)); 
	
	$tProd =$row2['firstShiftProduction'] + $row2['secondShiftProduction'] + $row2['thirdShiftProduction'];
    $tkwh =$row2['firstShiftKWH'] + $row2['secondShiftKWH'] + $row2['thirdShiftKWH'];
    $tcost =$row2['firstShiftCost'] + $row2['secondShiftCost'] + $row2['thirdShiftCost'] ;
	
	$tFrShProd= $tFrShProd + $row2['firstShiftProduction'];
	$tSeShProd= $tSeShProd + $row2['secondShiftProduction'];
	$tThShProd= $tThShProd + $row2['thirdShiftProduction'];
	
	$tFrShProd= $tFrShProd + $row2['firstShiftProduction'];
	$tSeShProd= $tSeShProd + $row2['secondShiftProduction'];
	$tThShProd= $tThShProd + $row2['thirdShiftProduction'];
	
	$tFrShKWH= $tFrShKWH + $row2['firstShiftKWH'];
	$tSeShKWH= $tSeShKWH + $row2['secondShiftKWH'];
	$tThShKWH= $tThShKWH + $row2['thirdShiftKWH'];
	
	$tFrShCost= $tFrShCost + $row2['firstShiftCost'];
	$tSeShCost= $tSeShCost + $row2['secondShiftCost'];
	$tThShCost= $tThShCost + $row2['thirdShiftCost'];
	
	$total_tProd=$total_tProd + $tProd;
	$total_tkwh=$total_tkwh + $tkwh;
	$total_tcost=$total_tcost + $tcost;
	
	
	
							$objPHPExcel->getActiveSheet()->setCellValue('A' . $loop, $recordDate);
							$objPHPExcel->getActiveSheet()->setCellValue('B' . $loop, round($row2['firstShiftProduction'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('C' . $loop, round($row2['firstShiftKWH'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('D' . $loop, round($row2['firstShiftCost'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('E' . $loop, round($row2['secondShiftProduction'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('F' . $loop, round($row2['secondShiftKWH'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('G' . $loop, round($row2['secondShiftCost'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('H' . $loop, round($row2['thirdShiftProduction'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('I' . $loop, round($row2['thirdShiftKWH'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('J' . $loop, round($row2['thirdShiftCost'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('K' . $loop, round($tProd,2));
							$objPHPExcel->getActiveSheet()->setCellValue('L' . $loop, round($tkwh,2));
							$objPHPExcel->getActiveSheet()->setCellValue('M' . $loop, round($tcost,2));
							$loop = $loop+1;
						}
			$objPHPExcel->getActiveSheet()->setCellValue('A' . $loop, 'Total ');
            $objPHPExcel->getActiveSheet()->getStyle('A' . $loop)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
			$objPHPExcel->getActiveSheet()->setCellValue('B' . $loop, $tFrShProd);
			$objPHPExcel->getActiveSheet()->getStyle('B' . $loop)->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->setCellValue('C' . $loop, $tFrShKWH);
			$objPHPExcel->getActiveSheet()->getStyle('C' . $loop)->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->setCellValue('D' . $loop, $tFrShCost);
			$objPHPExcel->getActiveSheet()->getStyle('D' . $loop)->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->setCellValue('E' . $loop, $tSeShProd);
			$objPHPExcel->getActiveSheet()->getStyle('E' . $loop)->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->setCellValue('F' . $loop, $tSeShKWH);
			$objPHPExcel->getActiveSheet()->getStyle('F' . $loop)->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->setCellValue('G' . $loop, $tSeShCost);
			$objPHPExcel->getActiveSheet()->getStyle('G' . $loop)->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->setCellValue('H' . $loop, $tThShProd);
			$objPHPExcel->getActiveSheet()->getStyle('H' . $loop)->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->setCellValue('I' . $loop, $tThShKWH);
			$objPHPExcel->getActiveSheet()->getStyle('I' . $loop)->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->setCellValue('J' . $loop, $tThShCost);
			$objPHPExcel->getActiveSheet()->getStyle('J' . $loop)->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->setCellValue('K' . $loop, $total_tProd);
			$objPHPExcel->getActiveSheet()->getStyle('K' . $loop)->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->setCellValue('L' . $loop, $total_tkwh);
			$objPHPExcel->getActiveSheet()->getStyle('L' . $loop)->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->setCellValue('M' . $loop, $total_tcost);
			$objPHPExcel->getActiveSheet()->getStyle('M' . $loop)->getFont()->setBold(true);
					


$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setAutoSize(true);





$objPHPExcel->getActiveSheet()->getStyle('G3')->getFont()->setSize(14);
$objPHPExcel->getActiveSheet()->getStyle('G3')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('B5')->getAlignment()->setShrinkToFit(true);

// Set thin black border outline around column
//echo date('H:i:s') , " Set thin black border outline around column" , EOL;
$styleThinBlackBorderOutline = array(
	'borders' => array(
		'outline' => array(
			'style' => PHPExcel_Style_Border::BORDER_THIN,
			'color' => array('argb' => 'FF000000'),
		),
	),
);
$objPHPExcel->getActiveSheet()->getStyle('A5:M'.$loop)->applyFromArray($styleThinBlackBorderOutline);




// Set thick brown border outline around "Total"
//echo date('H:i:s') , " Set thick brown border outline around Total" , EOL;
$styleThickBrownBorderOutline = array(
	'borders' => array(
		'outline' => array(
			'style' => PHPExcel_Style_Border::BORDER_THICK,
			'color' => array('argb' => 'FF993300'),
		),
	),
);
//$objPHPExcel->getActiveSheet()->getStyle('D13:E13')->applyFromArray($styleThickBrownBorderOutline);

// Set fills

//echo date('H:i:s') , " Set fills" , EOL;
$objPHPExcel->getActiveSheet()->getStyle('A5:M5')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A5:M5')->getFill()->getStartColor()->setARGB('FFFF8C00');
$objPHPExcel->getActiveSheet()->getStyle('A6:M6')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A6:M6')->getFill()->getStartColor()->setARGB('FFFF8C00');
$objPHPExcel->getActiveSheet()->getStyle('A4:M4')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A4:M4')->getFill()->getStartColor()->setARGB('FF5F9EA0');
// Set style for header row using alternative method
//echo date('H:i:s') , " Set style for header row using alternative method" , EOL;

$objPHPExcel->getActiveSheet()->getStyle('A5')->applyFromArray(
		array(
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
			),
			'borders' => array(
				'left'     => array(
 					'style' => PHPExcel_Style_Border::BORDER_THIN
 				)
			)
		)
);

$objPHPExcel->getActiveSheet()->getStyle('B5')->applyFromArray(
		array(
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
			)
		)
);

$objPHPExcel->getActiveSheet()->getStyle('L5')->applyFromArray(
		array(
			'borders' => array(
				'right'     => array(
 					'style' => PHPExcel_Style_Border::BORDER_THIN
 				)
			)
		)
);

// Unprotect a cell
//echo date('H:i:s') , " Unprotect a cell" , EOL;
$objPHPExcel->getActiveSheet()->getStyle('B1')->getProtection()->setLocked(PHPExcel_Style_Protection::PROTECTION_UNPROTECTED);

// Add a hyperlink to the sheet
$loop =$loop+2;
//echo date('H:i:s') , " Add a hyperlink to the sheet" , EOL;
$objPHPExcel->getActiveSheet()->setCellValue('B' . $loop, '');
$objPHPExcel->getActiveSheet()->getCell('B'  . $loop)->getHyperlink()->setUrl('https://emslte.arkaautomaations.com');
$objPHPExcel->getActiveSheet()->getCell('B' . $loop)->getHyperlink()->setTooltip('Navigate to website');
$objPHPExcel->getActiveSheet()->getStyle('B' . $loop)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
$loop =$loop+1;
$objPHPExcel->getActiveSheet()->setCellValue('B'  . $loop, '');
//$objPHPExcel->getActiveSheet()->getCell('B' . $loop)->getHyperlink()->setUrl("sheet://'Terms and conditions'!A1");
//$objPHPExcel->getActiveSheet()->getCell('B'  . $loop)->getHyperlink()->setTooltip('Review terms and conditions');
$objPHPExcel->getActiveSheet()->getStyle('B' . $loop)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);


// Play around with inserting and removing rows and columns
//echo date('H:i:s') , " Play around with inserting and removing rows and columns" , EOL;
$objPHPExcel->getActiveSheet()->insertNewRowBefore(6, 10);
$objPHPExcel->getActiveSheet()->removeRow(6, 10);
$objPHPExcel->getActiveSheet()->insertNewColumnBefore('E', 5);
$objPHPExcel->getActiveSheet()->removeColumn('E', 5);

// Set header and footer. When no different headers for odd/even are used, odd header is assumed.
//echo date('H:i:s') , " Set header/footer" , EOL;
$objPHPExcel->getActiveSheet()->getHeaderFooter()->setOddHeader('&L&BInvoice&RPrinted on &D');
$objPHPExcel->getActiveSheet()->getHeaderFooter()->setOddFooter('&L&B' . $objPHPExcel->getProperties()->getTitle() . '&RPage &P of &N');

// Set page orientation and size
//echo date('H:i:s') , " Set page orientation and size" , EOL;
$objPHPExcel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
$objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);

// Rename first worksheet
//echo date('H:i:s') , " Rename first worksheet" , EOL;
$objPHPExcel->getActiveSheet()->setTitle('Production Report Shift Wise');
