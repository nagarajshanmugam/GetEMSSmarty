<?php
include('config.php');
date_default_timezone_set('Asia/Kolkata');
$hostname_arkaerp = $config['DBHost'];
$database_arkaerp = $config['DBName'];
$username_arkaerp = $config['DBUser'];
$password_arkaerp = $config['DBPassword'];
$arkaerp = mysql_connect($hostname_arkaerp, $username_arkaerp, $password_arkaerp,$database_arkaerp) or trigger_error(mysql_error(),E_USER_ERROR);

mysql_select_db($database_arkaerp,$arkaerp);
$cid=$_REQUEST['cid'];
$bid=$_REQUEST['bid'];
//echo $cid;
if($cid != '')
{
$comId = base64_decode($_REQUEST['cid']);
}	
else
{
$comId = $_SESSION['CustomerId'];
}
if($bid != '')
{
$branchId = base64_decode($_REQUEST['bid']);
}	
else
{
$branchId = $_SESSION['branch_id'];
}
$parent_id=base64_decode($_REQUEST['parentid']);
function secondsToDhmss($seconds) {
//$seconds = Number($seconds);
$d = floor($seconds / (3600*24));
$h = floor($seconds % (3600*24) / 3600);
$m = floor($seconds % 3600 / 60);
$s = floor($seconds % 60);

if($d > 0 )
{
if( $d == 1)
{
$dDisplay = $d .' day, ';
}
else
{
$dDisplay = $d .' days, ';
}
}
else
{
$dDisplay = '';
}
if($h > 0 )
{
if( $h == 1)
{
$hDisplay = $h .' hrs, ';
}
else
{
$hDisplay = $h .' hrs, ';
}
}
else
{
$hDisplay = '';
}
if($m > 0 )
{
if( $m == 1)
{
$mDisplay = $m .' min, ';
}
else
{
$mDisplay = $m ." min's, ";
}
}
else
{
$mDisplay = '';
}
if($s > 0 )
{
if( $s == 1)
{
$sDisplay = $s .' sec ';
}
else
{
$sDisplay = $s ." sec's ";
}
}
else
{
$sDisplay = '';
}
$res=  $dDisplay .' '. $hDisplay .' '. $mDisplay .' '. $sDisplay;
echo $res;
 }
?>   
<link rel="stylesheet" href="plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
<script src="plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<script type="text/javascript">
  $("input[data-bootstrap-switch]").each(function(){
      $(this).bootstrapSwitch('state', $(this).prop('checked'));
    });
	</script>
	
			       <table id="example" class="table table-bordered table-hover">
                <thead>
                <tr>
    			  <th class="slNo" rowspan="2" >#</th>
                  <th class="name" rowspan="2">Place Of Installation</th>
                  <th class="gate" rowspan="2">Gateway</th>
				   <th class="status" rowspan="2">Status</th>
                  <th  colspan="2" class="code" >Today</th>
                  <th class="action" rowspan="2">Date Time</th>
                  <th class="last" rowspan="2">Last Comm</th>
                  
          
                </tr>
                <tr>
    			 
                  <th class="cost" >KWH</th>
                  <th class="cost" >Cost</th>
                  
                </tr>
                </thead>			                  <tbody>

							  <?php
						
		
         $sql = 'SELECT energy_data_master_view.*,arka_sensor_master.*,(arka_sensor_master.kw_max_value/5) AS KW_INT, arka_sensor_master.sensorName AS feeder_name, DATEDIFF(now(), recorded_date_time) AS days,TIMESTAMPDIFF(MINUTE, recorded_date_time, NOW()) AS mins,TIMESTAMPDIFF(SECOND, recorded_date_time, NOW()) AS secs FROM energy_data_master_view,arka_sensor_master WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.parent_id="'.$parent_id.'" AND arka_sensor_master.sensorCode=energy_data_master_view.sensor_code AND arka_sensor_master.gateway_id=energy_data_master_view.gateway_code '; 
	     $source=mysql_query($sql);//echo $sql;
	       
	    	$selQryC = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,sensor_code FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND DATE(recorded_date)=DATE(now()) AND MONTH(recorded_date)=MONTH(now()) AND YEAR(recorded_date)=YEAR(now()) AND cron_daily_energy_data.feeder_type="Sub Meter" GROUP BY sensor_code';      
		$source1=mysql_query($selQryC);//echo $selQryC;
      //  $step1=mysql_fetch_array($source1);
        
		$SelQuery='SELECT max(ping_log_id) AS ping_log_id, max(gateway_code) AS gateway_code,max(gateway_date_time) AS gateway_date_time FROM `gateway_ping_log` GROUP BY gateway_code ORDER BY ping_log_id';
	      $source2=mysql_query($SelQuery);
		 //$step2=mysql_fetch_array($source2);
							   
                               
                               
							   
								$i=1;	
								while($step=mysql_fetch_array($source))
								{
							
							 $selQry = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,arka_sensor_master.feeder_type,arka_sensor_master.sensorCode AS sensor_code,arka_sensor_master.parent_id FROM `cron_daily_energy_data`,arka_sensor_master WHERE arka_sensor_master.parent_id="'.$parent_id.'" AND arka_sensor_master.sensorCode=cron_daily_energy_data.sensor_code AND  cron_daily_energy_data.company_id="'.$comId.'" AND cron_daily_energy_data.branch_id="'.$branchId.'" AND DATE(recorded_date)=DATE(now()) AND MONTH(recorded_date)=MONTH(now()) AND YEAR(recorded_date)=YEAR(now()) AND cron_daily_energy_data.feeder_type="Sub Meter" '; 
                                $source3=mysql_query($selQry);
                                $step3=mysql_fetch_array($source3);
                                
                                 $selQry = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND DATE(recorded_date)=DATE(now()) AND MONTH(recorded_date)=MONTH(now()) AND YEAR(recorded_date)=YEAR(now()) AND feeder_type="Main Meter" AND gateway_code="'.$step['gateway_id'].'" AND sensor_code="'.$step['sensorCode'].'" '; 
                                 $source4=mysql_query($selQry);
                                 $step4=mysql_fetch_array($source4);
							
							$pid=$step['slNo'];
							    ?>
                                  <tr>
                 <td><?php echo $i;?></td>
				  <td><a href="meterDashboard.php?companyId=<?php echo base64_encode($comId);?>&branchId=<?php echo base64_encode($branchId);?>&sensorCode=<?php echo base64_encode($step['sensor_code']);?>&gatewayCode=<?php echo base64_encode($step['gateway_code']);?>"><span style="color:#000000;text-decoration:underline;" title="Meter Details"><?php echo $step['feeder_name'];?></span></a>&ensp; &ensp;<?php if($step['feeder_type'] == "Main Meter"){ ?><a href="subdashboard.php?parent_id=<?php echo  base64_encode($pid);?>&companyId=<?php echo base64_encode($comId);?>&branchId=<?php echo base64_encode($branchId); ?>"><i class="fa fa-sitemap" aria-hidden="true" title="Submeter List"></i></a><?php } ?></td>
                 <td ><?php echo $step['gateway_code'];?></td>
                <td >
                <?php
                 	while($step2=mysql_fetch_array($source2))
					{
					   $currDate=  date("Y-m-d H:i:s", strtotime("-30 seconds"));
					   $currDate1=  date("Y-m-d H:i:s", strtotime("-120 seconds"));
                 if($step2['gateway_code']<> "YMN-1" &&  $step2['gateway_code'] == $step['gateway_code'] && $step2['gateway_date_time'] >= $currDate)
                 { $tog=1; ?>
                <img  src="./images/on.png">
                 <?php   
                 }
                 elseif($step2['gateway_code']<> "YMN-1" && $step2['gateway_code'] == $step['gateway_code'] && $step2['gateway_date_time'] < $currDate)
                 { 
                     $tog=1;
                 ?>
                 <img  src="./images/off.png">
                 <?php
              	}
              	
              	if($step2['gateway_code']== "YMN-1" && $step2['gateway_code'] == $step['gateway_code'] && $step2['gateway_date_time'] >= $currDate1)
                 { $tog=1; ?>
                <img  src="./images/on.png">
                 <?php   
                 }
                 elseif($step2['gateway_code']== "YMN-1" && $step2['gateway_code'] == $step['gateway_code'] && $step2['gateway_date_time'] < $currDate1)
                 { $tog=1;
                 ?>
                 <img  src="./images/off.png">
                 <?php
              	}
              	
					}
					
					if($tog==''){
					   
					    ?>
					    <img  src="./images/off.png">
				<?php	    
					}
              	?>
              	</td>
                 <?php 
                 
                 $selQryC = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,sensor_code FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND DATE(recorded_date)=DATE(now()) AND MONTH(recorded_date)=MONTH(now()) AND YEAR(recorded_date)=YEAR(now()) AND gateway_code="'.$step['gateway_id'].'" AND feeder_type="Sub Meter"  GROUP BY sensor_code';	       
		$source1=mysql_query($selQryC);//echo $selQryC;
                 if (mysql_num_rows($source1) > 0)
                 {
                 	while($step1=mysql_fetch_array($source1))
					{
					$tkwh = $tkwh+$step1['TOTAL_KWH'];
                    $tcost=$tcost+$step1['cost'];
                 if($step1['sensor_code'] == $step['sensorCode'])
                 { ?>
                 <td align="right"><?php echo $step1['TOTAL_KWH'];?></td>
                 <td align="right"><?php  echo $step1['cost'];?></td>
              <?php   
                     
                 }
              	}
                 }
                 else
                 {
                     ?>
                     <td align="right"><?php echo '0.00';?></td>
                 <td align="right"><?php  echo '0.00';?></td>
                 <?php
                 }
              	?>
			   <td><?php echo date("d-M-Y h:i:s A", strtotime($step['recorded_date_time']));?></td>
                 <td><?php echo secondsToDhmss($step['secs']);echo " ";echo "ago";?></td>
                   
                                 </tr>
			                    	<?php 
                                 $i=$i+1;
								
								}
									?>
									
        					

								
			                  </tbody>
			                  <tr>
			                      <?php 
	     $sql = 'SELECT energy_data_master_view.*,arka_sensor_master.*,(arka_sensor_master.kw_max_value/5) AS KW_INT, arka_sensor_master.sensorName AS feeder_name, DATEDIFF(now(), recorded_date_time) AS days,TIMESTAMPDIFF(MINUTE, recorded_date_time, NOW()) AS mins,TIMESTAMPDIFF(SECOND, recorded_date_time, NOW()) AS secs FROM energy_data_master_view,arka_sensor_master WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.parent_id="'.$parent_id.'" AND arka_sensor_master.sensorCode=energy_data_master_view.sensor_code AND arka_sensor_master.gateway_id=energy_data_master_view.gateway_code '; 
	     $source=mysql_query($sql);//echo $sql;
	     
	     $sql = 'SELECT energy_data_master_view.*,arka_sensor_master.*,(arka_sensor_master.kw_max_value/5) AS KW_INT, arka_sensor_master.sensorName AS feeder_name, DATEDIFF(now(), recorded_date_time) AS days,TIMESTAMPDIFF(MINUTE, recorded_date_time, NOW()) AS mins,TIMESTAMPDIFF(SECOND, recorded_date_time, NOW()) AS secs FROM energy_data_master_view,arka_sensor_master WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.parent_id="'.$parent_id.'" AND arka_sensor_master.sensorCode=energy_data_master_view.sensor_code AND arka_sensor_master.gateway_id=energy_data_master_view.gateway_code '; 
	     $source=mysql_query($sql);//echo $sql;
	     $step=mysql_fetch_assoc($source);
	     $selQryC = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,sensor_code FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND DATE(recorded_date)=DATE(now()) AND MONTH(recorded_date)=MONTH(now()) AND YEAR(recorded_date)=YEAR(now()) AND cron_daily_energy_data.feeder_type="Sub Meter" GROUP BY sensor_code';      
		 $source1=mysql_query($selQryC);//echo $selQryC;
      //  $step1=mysql_fetch_array($source1);
        
		$SelQuery='SELECT max(ping_log_id) AS ping_log_id, max(gateway_code) AS gateway_code,max(gateway_date_time) AS gateway_date_time FROM `gateway_ping_log` GROUP BY gateway_code ORDER BY ping_log_id';
	    $source2=mysql_query($SelQuery);
	      
	    $sql5 = 'SELECT energy_data_master_view.*,arka_sensor_master.*,(arka_sensor_master.kw_max_value/5) AS KW_INT, arka_sensor_master.sensorName AS feeder_name, DATEDIFF(now(), recorded_date_time) AS days,TIMESTAMPDIFF(MINUTE, recorded_date_time, NOW()) AS mins,TIMESTAMPDIFF(SECOND, recorded_date_time, NOW()) AS secs FROM energy_data_master_view,arka_sensor_master WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.slNo="'.$parent_id.'" AND arka_sensor_master.sensorCode=energy_data_master_view.sensor_code AND arka_sensor_master.gateway_id=energy_data_master_view.gateway_code '; 
	    $source5=mysql_query($sql5);
		$step5=mysql_fetch_array($source5);
		
		 $selQry = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,arka_sensor_master.feeder_type,arka_sensor_master.sensorCode AS sensor_code,arka_sensor_master.parent_id FROM `cron_daily_energy_data`,arka_sensor_master WHERE arka_sensor_master.parent_id="'.$parent_id.'" AND arka_sensor_master.sensorCode=cron_daily_energy_data.sensor_code AND  cron_daily_energy_data.company_id="'.$comId.'" AND cron_daily_energy_data.branch_id="'.$branchId.'" AND DATE(recorded_date)=DATE(now()) AND MONTH(recorded_date)=MONTH(now()) AND YEAR(recorded_date)=YEAR(now()) AND cron_daily_energy_data.feeder_type="Sub Meter" '; 
                                $source3=mysql_query($selQry);
                                $step3=mysql_fetch_array($source3);
                                
                                 $selQry = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND DATE(recorded_date)=DATE(now()) AND MONTH(recorded_date)=MONTH(now()) AND YEAR(recorded_date)=YEAR(now()) AND feeder_type="Main Meter" AND gateway_code="'.$step5['gateway_id'].'" AND sensor_code="'.$step5['sensorCode'].'" '; 
                                 $source4=mysql_query($selQry);
                                 $step4=mysql_fetch_array($source4);
		
		         $kwh =$step4['TOTAL_KWH']-$step3['TOTAL_KWH'];
                 $cost=$step4['cost']-$step3['cost'];
                 $tkwh=$tkwh+$kwh;
                 $tcost=$tcost+$cost;
                 ?>
                    <td><?php echo $i;?></td>
                    <td>Others</td>
                    <td><?php echo $step5['gateway_code'];?></td>
                    <!--<td><img  src="./images/off.png"></td>-->
                    <td >
                <?php
                 	while($step2=mysql_fetch_array($source2))
					{
					    
					   $currDate=  date("Y-m-d H:i:s", strtotime("-30 seconds"));
					   $currDate1=  date("Y-m-d H:i:s", strtotime("-120 seconds"));
					   
					   
					   
                 if($step2['gateway_code']<> "YMN-1" && $step2['gateway_code'] == $step['gateway_code'] && $step2['gateway_date_time'] >= $currDate)
                 { $tog=1; ?>
                <img  src="./images/on.png">
                 <?php   
                 }
                  elseif($step2['gateway_code']<> "YMN-1" && $step2['gateway_code'] == $step['gateway_code'] && $step2['gateway_date_time'] < $currDate)
                
                 { 
                     $tog=1;
                 ?>
                 <img  src="./images/off.png">
                 <?php
              	}
              	
              	
              		if($step2['gateway_code']== "YMN-1" && $step2['gateway_code'] == $step['gateway_code'] && $step2['gateway_date_time'] >= $currDate1)
                 { $tog=1; ?>
                <img  src="./images/on.png">
                 <?php   
                 }
                 elseif($step2['gateway_code']== "YMN-1" && $step2['gateway_code'] == $step['gateway_code'] && $step2['gateway_date_time'] < $currDate1)
                 { $tog=1;
                 ?>
                 <img  src="./images/off.png">
                 <?php
              	}
              	
					}
					
					if($tog==''){
					   
					    ?>
					    <img  src="./images/off.png">
				<?php	    
					}
              	?>
              	</td>
                    <td align="right"><?php echo $step4['TOTAL_KWH']-$step3['TOTAL_KWH'];?></td>
                    <td align="right"><?php echo $step4['cost']-$step3['cost'];?></td>
                    <td><?php echo date("d-M-Y h:i:s A", strtotime($step5['recorded_date_time']));?></td>
                    <td><?php echo secondsToDhmss($step5['secs']);echo " ";echo "ago";?></td>
                     
                    </tr>
                    <tr>
                    <td colspan="4" style="text-align:right;"><b>Total</b></td>
                    <td style="text-align:right;"><b><?php echo number_format($tkwh, 2, '.', '');?></b></td>
                     <td style="text-align:right;"><b><?php echo number_format($tcost, 2, '.', '');?></b></td>
                    <td colspan="2"></td>
                    </tr>
			                </table>

<style>
 .slNo
 {
 width:3%;
 }
 .name
 {
 width:18%;
 }
 .gate
 {
 width:10%;
 }
 .status
 {
 width:5%;
 }
 .code
 {
 width:10%;
 }
 .cost
 {
 width:5%;
 }
 .action
 {
 width:15%;
 }
 .last
 {
 width:11%;
 }
 .uline
 {
 text-decoration:underline;
 }
 </style>




			     