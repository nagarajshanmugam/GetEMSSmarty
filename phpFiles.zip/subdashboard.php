<?php
   require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.Dashboard.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";	
	
    $objStaff		= new Staff();
    $objStaff->RolesLists();
	$objStaff->GetCompanyName();
	$objDashBoard	= new Dashboard();
    $objDashBoard->ListDashboardTest();
	$objDashBoard->GetDashboardDetails();
    $objDashBoard->GetCostKwhAllForSubDashboard();
    $objDashBoard->GetCostKwhAllSubMeter();
	//$objDashBoard->GetSubDashboard();
	$objDashBoard->GetSegmentsList();

    $objDashBoard->DashGetSubDashboard();
	$objSmarty->assign('dateSec', strtotime('-30 Seconds'));
	$objSmarty->assign('dateSec1', strtotime('-900 Seconds'));
  	$objSmarty->assign('IncludeTpl', 'subdashboard.tpl');

  
  $objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Condition Monitoring Systems');
  $objSmarty->assign('robots','index,follow');
  $objSmarty->assign('key_word','');
  $objSmarty->assign('generator','');
  $objSmarty->assign('author','rsureshit@hotmail.com');
  $objSmarty->assign('document-state','dynamic');
  $objSmarty->assign('address',$config['SiteGlobalPath']); 
  $objSmarty->assign('LeftTpl', 'left.tpl');
  $objSmarty->display('pagetemplate.tpl');
?>