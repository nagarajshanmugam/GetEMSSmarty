<?php

	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.SensorMaster.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";
	
		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objStaff -> GetCompanyName($objArray);
		$objSensorMaster	= new SensorMaster();
		$objSensorMaster -> GetSensorModelName();
		$objSensorMaster -> ListDataType($objArray);
		$objSensorMaster -> ListSensorParameterList($objArray);
		$objSensorMaster -> ListSensor($objArray);
		$objSensorMaster -> ListEditView($objArray);
		$objSensorMaster -> ListCompany($objArray);
		$objSensorMaster -> GetGatewayName($objArray);
		$objSensorMaster -> Platform();
		
		
		if(isset($_POST['hdAction']) && !isset($_GET['Update']))
		{
			
			$objSensorMaster -> InsertSensorModelParameter($_POST);
		}
		if(isset($_GET['Update']) && isset($_GET['sl_no'])){
			$objSensorMaster -> EditSensorModelParameterView($_GET);
		}
		if(isset($_POST['hdAction']) && isset($_GET['Update']))
		{
			$objSensorMaster ->EditSensorModelParameter($_POST);
		}

		if(isset($_GET['success_msg_for_insert']))
		{
			$objSmarty->assign('SuccessMessage', 'New Record Created Successfully');
		} 
		
		if(isset($_GET['success_msg_for_update']))
		{
			$objSmarty->assign('ErrorMessage', 'Record Updated Successfully');
		} 
		if(isset($_GET['ErrorMessage']))
		{
			$objSmarty->assign('ErrorMessage', 'Parameter Already Exist');
		} 
	
		$objSmarty->assign('IncludeTpl', 'addEditSensorModelParameter.tpl');
		$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Sensor Model Reg');
		$objSmarty->assign('robots','index,follow');
		$objSmarty->assign('key_word','');
		$objSmarty->assign('generator','');
		$objSmarty->assign('document-state','dynamic');
		$objSmarty->assign('address',$config['SiteGlobalPath']);
		
		
		/*Display page*/
		$objSmarty->assign('LeftTpl', 'left.tpl');
		$objSmarty->display('pagetemplate.tpl');

?>