<?php 
include('config.php');
$hostname_arkaerp = $config['DBHost'];
$database_arkaerp = $config['DBName'];
$username_arkaerp = $config['DBUser'];
$password_arkaerp = $config['DBPassword'];
$arkaerp = mysql_connect($hostname_arkaerp, $username_arkaerp, $password_arkaerp,$database_arkaerp) or trigger_error(mysql_error(),E_USER_ERROR);
mysql_select_db($database_arkaerp,$arkaerp);
$branchid = 0;

if(isset($_REQUEST['branch']))
{
$branchid = mysql_real_escape_string($_REQUEST['branch']); // department id
}
if(isset($_REQUEST['company']))
{
$companyid = mysql_real_escape_string($_REQUEST['company']); // department id
}
$users_arr = array();

if($branchid > 0){

$sensorSel = "SELECT groupId,groupName FROM gateway_group_mapping WHERE status='1' AND isActive='1' AND companyId='".$companyid."' AND branchId='".$branchid."' GROUP BY groupName";//echo $sensorSel;
$sensorList = mysql_query($sensorSel,$arkaerp);

}
else
{
$sensorSel = "SELECT groupId,groupName FROM gateway_group_mapping WHERE status='1' AND isActive='1' AND companyId='".$companyid."' GROUP BY groupName";//echo $sensorSel;
$sensorList = mysql_query($sensorSel,$arkaerp);

}

   while( $row = mysql_fetch_array($sensorList) ){
      $slNo = $row['groupId'];
      $groupName = $row['groupName'];
      $users_arr[] = array("id" => $slNo, "name" => $groupName);
   }

// encoding array to json format
echo json_encode($users_arr);