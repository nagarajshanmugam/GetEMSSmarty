<?php 
include('config.php');

$hostname = $config['DBHost'];
$database = $config['DBName'];
$username = $config['DBUser'];
$password = $config['DBPassword'];

$conn = mysql_connect($hostname, $username, $password,$database) or trigger_error(mysql_error(),E_USER_ERROR);
mysql_select_db($database,$conn);

$sensorCode =$_GET['sensor_code'];
$recordedDate =$_GET['recorded_date'];
$companyId =$_GET['company_id'];
$branchId =$_GET['branch_id'];
$invoiceId =$_GET['invoice_no'];
/*$sensorCode =$_POST['sensor_code'];
$recordedDate =$_POST['recorded_date'];
*/ 

$x=explode("-",$recordedDate);
$mon=$x[0];
$yr=$x[1];

//$selQry='SELECT cron_monthly_energy_data.*, feeder_master.feeder_name, feeder_master.billing_module, feeder_master.contact_person, feeder_master.contact_no, feeder_master.email_id FROM `cron_monthly_energy_data`,feeder_master WHERE cron_monthly_energy_data.sensor_code="'.$sensorCode.'" AND MONTH(cron_monthly_energy_data.recorded_date)=MONTH("'.$recordedDate.'") AND YEAR(cron_monthly_energy_data.recorded_date)=YEAR("'.$recordedDate.'") AND cron_monthly_energy_data.sensor_code=feeder_master.sensor_code ORDER BY feeder_master.feeder_name DESC';echo $selQry;
$selQry='SELECT cron_monthly_energy_data.*, feeder_master.feeder_name, feeder_master.billing_module, feeder_master.contact_person, feeder_master.contact_no, feeder_master.email_id FROM `cron_monthly_energy_data`,feeder_master WHERE cron_monthly_energy_data.sensor_code="'.$sensorCode.'" AND MONTH(cron_monthly_energy_data.recorded_date)="'.$mon.'" AND YEAR(cron_monthly_energy_data.recorded_date)="'.$yr.'" AND cron_monthly_energy_data.sensor_code=feeder_master.sensor_code ORDER BY feeder_master.feeder_name DESC';//echo $selQry;

//$selQry='SELECT * FROM cron_monthly_energy_data';
$ExecSelQry=mysql_query($selQry);//echo $ExecSelQry;
$ExecSelQry2=mysql_query($selQry);
$row2=mysql_fetch_assoc($ExecSelQry2);

$compSel='SELECT * FROM arka_company_master WHERE slNo="'.$companyId.'"';
$ExecCompany=mysql_query($compSel);
$compDet=mysql_fetch_assoc($ExecCompany);

$compSel='SELECT * FROM invoice_master WHERE invoice_master_id="'.$invoiceId.'" AND status="1"';
$InvDetails=mysql_query($compSel);
$InvDet=mysql_fetch_assoc($InvDetails);

$sdate = "01-".''.$InvDet["bill_month"];
$startDate=date("01-M-Y",strtotime($sdate));
$endDate=date("t-M-Y", strtotime($startDate));
$invoiceDate=date("t-M-Y");
$dueDate=date("t-M-Y", strtotime($invoiceDate. ' + 5 days'));

/****************   Number To Words Function Starts   ***************/
function no_to_words($no)
{   
 $words = array('0'=> '' ,'1'=> 'One' ,'2'=> 'Two' ,'3' => 'Three','4' => 'Four','5' => 'Five','6' => 'Six','7' => 'Seven','8' => 'Eight','9' => 'Nine','10' => 'Ten','11' => 'Eleven','12' => 'Twelve','13' => 'Thirteen','14' => 'Fouteen','15' => 'Fifteen','16' => 'Sixteen','17' => 'Seventeen','18' => 'Eighteen','19' => 'Nineteen','20' => 'Twenty','30' => 'Thirty','40' => 'Fourty','50' => 'Fifty','60' => 'Sixty','70' => 'Seventy','80' => 'Eighty','90' => 'Ninty','100' => 'Hundred and ','1000' => 'Thousand','100000' => 'Lakh','10000000' => 'Crore');
    if($no == 0)
        return ' ';
    else {
	$novalue='';
	$highno=$no;
	$remainno=0;
	$value=100;
	$value1=1000;       
            while($no>=100)    {
                if(($value <= $no) &&($no  < $value1))    {
                $novalue=$words["$value"];
                $highno = (int)($no/$value);
                $remainno = $no % $value;
                break;
                }
                $value= $value1;
                $value1 = $value * 100;
            }       
          if(array_key_exists("$highno",$words))
              return $words["$highno"]." ".$novalue." ".no_to_words($remainno);
          else {
             $unit=$highno%10;
             $ten =(int)($highno/10)*10;            
             return $words["$ten"]." ".$words["$unit"]." ".$novalue." ".no_to_words($remainno);
           }
    }
}

function includecomma1old($c)
{
$x=$c;
$lx = strlen($x);
$lastThree = substr($x,$lx-2);
$lastThree = str_replace("/\./g","",$lastThree);

$lt = strlen($lastThree);

if($lt == 1)
{
$lastThree = $lastThree+'0';
$otherNumbers = substr($x,0,$lx-2);
}
else
{
$otherNumbers = substr($x,0,$lx-3);
}
$ol = strlen($otherNumbers);
$otherNumbers1 = substr($otherNumbers,$ol-3);
$otherNumbers2 = substr($otherNumbers,0,$ol-3);

if($otherNumbers2 != '')
$otherNumbers1 = ',' . $otherNumbers1;
$lastThree = '.' . $lastThree;
$res =  str_replace("/\B(?=(\d{2})+(?!\d))/g",",",$otherNumbers2) . $otherNumbers1 . $lastThree;
return $res;
//var res = res+'.00';
}
function includecomma1($c)
{

$x=round($c);
$x=(string)$x;
$l = strlen($x);
if($l > 3)
{
$lastThree =  substr($x, $l-3);//echo $lastThree;echo "<br />";
$otherNumbers =substr($x,0,$l-3);
//echo $otherNumbers;echo "<br />";
if($otherNumbers != '')
{
$lastThree = ',' . $lastThree;//echo $lastThree;echo "<br />";echo $otherNumbers;echo "<br />";
//$res = str_replace("/\B(?=(\d{2})+(?!\d))/g",",",$otherNumbers);//echo $res;echo "<br />";
$res =preg_replace("/\B(?=(\d{2})+(?!\d))/i", ',', $otherNumbers);
$res = $res.$lastThree;//echo $res;echo "<br />";
$res = $res.'.00';
}
else
{
$res=$lastThree.'.00';
}
}
else
{
$res=$x.'.00'; 
}
return $res;
}
/****************   Number To Words Function Ends   ***************/
//echo no_to_words(12345401);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="./plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="./dist/css/adminlte.min.css">
  <script src="./webPagePDF/jquery.min.js"></script>


<script src="./webPagePDF/html2canvas.js"></script>
<script src="./webPagePDF/jspdf.debug.js"></script>

</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  

  <!-- Content Wrapper. Contains page content -->

    <!-- Content Header (Page header) -->
    


    <section class="content">
      <div class="container-fluid">
	  <div class="row">
	  
	  </div>
        <div class="row">
		
          <div class="col-12">
            


            <!-- Main content -->
            <div class="invoice p-3 mb-3">
                <input type="hidden" id="quoteNumber" name="quoteNumber" value="<?php echo $InvDet["Invoice_no"];echo "_";echo $row2["contact_person"];?>">
			<br><br><br><br>
              <!-- title row -->
              <!--<div class="row">
                <div class="col-12">
                  <h4>
                    <i class="fas fa-globe"></i> AdminLTE, Inc.
                    <small class="float-right">Date: 2/10/2014</small>
                  </h4>
                </div>
               
              </div>-->
              <!-- info row -->
              <div class="row invoice-info">
			  <div class="col-sm-3 invoice-col" style="margin-top:50PX">
                    <!--<i class="fas fa-globe" ></i> AdminLTE, Inc. (Company Logo)-->
					<?php if ($compDet["companyLogo"]<>''){?><img src="./images/CompanyLogo/<?php echo $compDet["companyLogo"];?>"> <?php } else{ ?><i class="fas fa-globe" ></i>(Company Logo)<?php }?>
                </div>
                <div class="col-sm-3 invoice-col" style="font-size:20px">
                  From
                  <address>
                    <strong><?php if ($compDet["companyName"]<>''){echo $compDet["companyName"];} else{ echo "Company Name Not Available";}?>,</strong><br>
                    <?php if ($compDet["address"]<>''){echo $compDet["address"];} else{ echo "Address Not Available";}?><br>
                    <?php if ($compDet["area"]<>''){echo $compDet["area"];} else{ echo "area Not Available";}?>, <?php if ($compDet["city"]<>''){echo $compDet["city"];} ?> - <?php if ($compDet["pincode"]<>''){echo $compDet["pincode"];} ?><br>
                    Phone: <?php if ($compDet["phone"]<>''){echo $compDet["phone"];} else{ echo "phone Not Available";}?><br>
                    Email: <?php if ($compDet["email"]<>''){echo $compDet["email"];} else{ echo "Mail ID Not Available";}?>
                  </address>
                </div>
                <!-- /.col -->
                <div class="col-sm-3 invoice-col" style="font-size:20px">
                  To
                  <address>
                    <strong><?php if ($row2["contact_person"]<>''){echo $row2["contact_person"];} else{ echo "";}?></strong><br>
                    <?php if ($row2["feeder_name"]<>''){echo $row2["feeder_name"];} else{ echo "";}?><br>
                    
                    Phone: <?php if ($row2["contact_no"]<>''){echo $row2["contact_no"];} else{ echo "";}?><br>
                    Email: <?php if ($row2["email_id"]<>''){echo $row2["email_id"];} else{ echo "";}?>
                  </address>
                </div>
                <!-- /.col -->
                <div class="col-sm-3 invoice-col" style="font-size:20px">
                  <b>Invoice No: <?php echo $InvDet["Invoice_no"]; ?></b><br>
				  <b>Invoice Date:</b> <?php echo date('d-M-Y', strtotime($InvDet["invoice_date"]));?><br>
                  
                  <b>Payment Due:</b> <?php echo $dueDate;?><br>
                  <!--<b>Account:</b> 968-34567-->
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->
			  
			  <br>
              <!-- Table row -->
              <div class="row">
                <div class="col-12 table-responsive">
                  <table class="table table-bordered table-striped" style="font-size:20px">
                    <thead>
					 <tr>
                      <th colspan="7"> <center> <h3>Power Consuption for the period <?php echo $startDate;?> To <?php echo $endDate;?></h3></center></th>
                      
                    </tr>
                    <tr>
                      <th>#</th>
                       <th>Feeder Name</th>
                      <th>Start Kwh</th>
                      <th>End Kwh</th>
                      <th>Total Kwh </th>
					  <th>Unit Rate</th>
                      <th>Total Cost</th>
                    </tr>
                    </thead>
                    <tbody>
					<?php $i=0; $consCost=0;$consKwh=0; 
	$consKwh = $InvDet['end_kwh'] - $InvDet['start_kwh']; ?>
  <?php  $skwh = $InvDet['start_kwh'];$ekwh = $InvDet['end_kwh'];$iamt = $InvDet['invoice_amount'];?>
                <tr>
                      <td><?php $i=$i+1; echo $i; ?></td>
                      <td><?php  echo $InvDet['feeder_name']; ?></td>
                      <td id="{$i}" align="right"><?php echo includecomma1($skwh);?></td>
                      <td align="right"><?php echo includecomma1($ekwh);?></td>
					  <td align="right"><?php echo includecomma1($consKwh);?></td>
					  <td align="right"><?php  echo $InvDet['unit_price']; ?></td>
                      <td align="right"><?php $consCost=$consCost+$InvDet['invoice_amount']; $InvDet['invoice_amount']; ?><?php echo includecomma1($iamt);?></td>
                    </tr>
				
				    
                    
                    </tbody>
                  </table>
                </div>
                <!-- /.col -->
              </div>
<br>
<br>
<br>              <!-- /.row -->
<div class="row">

                <div class="col-12">
                  <h4>
                     
                    <small class="float-left">Total Amount   &ensp;&ensp;&ensp;&ensp;&ensp;&ensp; : &ensp;&ensp;&ensp;   <B>Rs. <?php echo includecomma1(round($consCost));?>/-</B></small>
                  </h4>
                </div>
				<div class="col-12">
                  <h4>
                     
                    <small class="float-left">Amount In Words  &ensp;&ensp;&ensp;  : &ensp;&ensp;&ensp;   <B><?php echo "Rupees";echo " "; echo no_to_words(round($consCost));?> Only.</B></small>
                  </h4>
                </div>
               <br>
			   <br>
			   <br>
			   <br>
			   <br>
			   <br>
			   <br>
			   <div class="col-12">
                  <h4>
                     
                    <small class="float-right"><b>Authorized Signature</B></small>
<br>
<br>
<br> 
<br>
<br>
<br> 
<br>
<br>
<br> 
                  </h4>
                </div>
             
                <!-- accepted payments column -->
                <div class="col-8">
                  <!--<p class="lead">Payment Methods:</p>
                  <img src="./dist/img/credit/visa.png" alt="Visa">
                  <img src="./dist/img/credit/mastercard.png" alt="Mastercard">
                  <img src="./dist/img/credit/american-express.png" alt="American Express">
                  <img src="./dist/img/credit/paypal2.png" alt="Paypal">

                  <p class="text-muted well well-sm shadow-none" style="margin-top: 10px;">
                    Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles, weebly ning heekya handango imeem
                    plugg
                    dopplr jibjab, movity jajah plickers sifteo edmodo ifttt zimbra.
                  </p>-->
                </div>
                <!-- /.col -->
				
                <!--            
				SUB TOTAL DIV STARTS
				<div class="col-4">

                  <div class="table-responsive">
                    <table class="table">
                      <tr>
                        <th style="width:50%">Subtotal:</th>
                        <td align="right">Rs. <?php//  echo round($consCost,2); ?></td>
                      </tr>
                      <tr>
                        <th>Tax (9.3%)</th>
                        <td align="right">Rs. <?php// $tax=($consCost*9.3)/100; echo round($tax,2); ?></td>
                      </tr>
                     
                      <tr>
                        <th>Total:</th>
                        <td align="right">Rs. <?php// $tot=$consCost+$tax; echo round($tot,2); ?></td>
                      </tr>
                    </table>
                  </div>
                </div>
				                
				SUB TOTAL DIV ENDS				-->
                <!-- /.col -->
              </div>
              
              <!-- /.row -->

              <!-- this row will not appear when printing -->
              
            </div>
            <!-- /.invoice -->
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->

  <!-- /.content-wrapper -->
  

  <!-- Control Sidebar -->
 
  <!-- /.control-sidebar -->
</div>
</body>
<!-- ./wrapper -->
<script>
let doc = new jsPDF('p','pt','a4');
doc.addHTML(document.body,function() {
     var pdfname = document.getElementById("quoteNumber").value;
    doc.save('' + pdfname + '.pdf');
});
</script>
<!-- jQuery -->
<script src="./plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="./plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="./dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="./dist/js/demo.js"></script>
</body>
</html>
