<?php 
	$hostname_arkaems = "localhost";
	$database_arkaems = "univa_ems";
	$username_arkaems = "root";
	$password_arkaems = "@dmin987";
	$arkaerp = mysql_connect($hostname_arkaems, $username_arkaems, $password_arkaems) or trigger_error(mysql_error(),E_USER_ERROR);
	mysql_select_db($database_arkaems, $arkaerp) or die(mysql_error());
	//mysql_query( "SET SESSION sql_mode = 'NO_ENGINE_SUBSTITUTION'",$arkaerp);
	if(function_exists('date_default_timezone_set')) {
		date_default_timezone_set("Asia/Kolkata");
	}

	if($username_arkaems != 'root')
	{
		$nowDate= 'DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE)';
	}
	else{
		$nowDate= 'NOW()';
	}
	if(isset($_POST['sensor_code']))
	{
		$whCond="arka_sensor_master.sensorCode='".$_POST['sensor_code']."' AND arka_sensor_master.segmentName='Energy Meter' AND gateway_id='TRB245-2'  ";
	}
	else
	{
		$whCond="arka_sensor_master.segmentName='Energy Meter' AND gateway_id='TRB245-2' ";
	}
	//	$sensorSel = "SELECT arka_sensor_master.* FROM arka_sensor_master WHERE arka_sensor_master.status='1' AND arka_sensor_master.isActive='1' AND ".$whCond." AND arka_sensor_master.sensorCode='EM6400-2'";
		$sensorSel = "SELECT arka_sensor_master.* FROM arka_sensor_master WHERE arka_sensor_master.status='1' AND arka_sensor_master.isActive='1' AND ".$whCond." ";
		$sensorList = mysql_query($sensorSel,$arkaerp);
		$sensorList2 = mysql_query($sensorSel,$arkaerp);
		$machine = mysql_num_rows($sensorList);			
	  /******************************************     Query Starts for:   Insert every date of the month start                ***************/		
		$cronDateSel = "SELECT * FROM cron_daily_energy_data WHERE DATE(recorded_date)=DATE(".$nowDate.") AND MONTH(recorded_date)=MONTH(".$nowDate.") AND YEAR(recorded_date)=YEAR(".$nowDate.")";
		$dateList = mysql_query($cronDateSel,$arkaerp);
		$dateCount = mysql_num_rows($dateList);			
	if($dateCount=='0'){
	/**********************First DATE***************/
		$first1 = "SELECT CAST(DATE_FORMAT(".$nowDate.",'%y-%m-01') AS DATE) AS FT";
		$firstday = mysql_query($first1,$arkaerp);
		$first = mysql_num_rows($firstday);
		$fstday=mysql_fetch_array($firstday);	
	/**********************LAST DATE***************/
		$sql1 = "SELECT DAY(LAST_DAY(".$nowDate.")) AS LastDay";
		$LastDay = mysql_query($sql1,$arkaerp);
		$count1 = mysql_num_rows($LastDay);
		$day=mysql_fetch_array($LastDay);
	
	while($rows=mysql_fetch_array($sensorList))
	{
		echo $rows['sensorCode'];
		$i=0;
	for($d=1;$d<=$day['LastDay'];$d++)
	{		
		$date= "SELECT DATE_ADD(DATE('".$fstday['FT']."'),INTERVAL '".$i."' DAY) AS DT";
		$date1 = mysql_query($date,$arkaerp);					
		$da=mysql_fetch_array($date1);
		$sql = "SELECT * FROM cron_daily_energy_data WHERE recorded_date='".$da['DT']."' AND sensor_code='".$rows['sensorCode']."'";
		$Day = mysql_query($sql,$arkaerp);
		$count = mysql_num_rows($Day);
	if($count=="0")
	{
			$Insert= "INSERT INTO cron_daily_energy_data (company_id,branch_id,gateway_code,sensor_code,recorded_date) VALUES ('".$rows['company_id']."','".$rows['branch_id']."','".$rows['gateway_id']."','".$rows['sensorCode']."','".$da['DT']."')";
			 mysql_query($Insert,$arkaerp);	
			$i++;
	}
	else
	{		
	}
	}
	}  
	}
	/*****************************************     Query Ends for:  Insert every date of the month start    *****************************************/	
	/*****************************************     Query Starts for:  lastday KWH and Cost    *****************************************/	
	while($rows2=mysql_fetch_array($sensorList2))
	{
	if(isset($_POST['recorded_date']))
	{
			$ydate1 = date("Y-m-d 08:00:00",strtotime(trim(addslashes($_POST['recorded_date']))));
			$ydate2 = date("Y-m-d",strtotime(trim(addslashes($_POST['recorded_date']))));
		
			$ydate=date_create($ydate2);
			date_add($ydate,date_interval_create_from_date_string("1 days"));
			$ydate2=date_format($ydate,"Y-m-d 07:59:59");
			
			$yesDay= ' AND ( recorded_date_time BETWEEN "'.$ydate1.'" AND "'.$ydate2.'")';
			
			$dbydateF=date_create($ydate1);
			date_sub($dbydateF,date_interval_create_from_date_string("1 days"));
			$dbydate1=date_format($dbydateF,"Y-m-d H:i:s");
			
			$dbydateS=date_create($ydate2);
			date_sub($dbydateS,date_interval_create_from_date_string("1 days"));
			$dbydate2=date_format($dbydateS,"Y-m-d H:i:s");
			
			$dayBefYesDay=' AND ( recorded_date_time BETWEEN "'.$dbydate1.'" AND "'.$dbydate2.'")';
			
			$userName =$_POST['userName'];
			$manualUpdate=1;
	}
	else
	{
	
		$ydateF=date_create(date('Y-m-d'));
		date_sub($ydateF,date_interval_create_from_date_string("1 days"));
		
		$ydate1=date_format($ydateF,"Y-m-d 08:00:00");
		$ydate2=date('Y-m-d 07:59:59');
		$yesDay= ' AND ( recorded_date_time BETWEEN "'.$ydate1.'" AND "'.$ydate2.'")';
		
		$dbydateF=date_create($ydate1);
		date_sub($dbydateF,date_interval_create_from_date_string("1 days"));
		$dbydate1=date_format($dbydateF,"Y-m-d H:i:s");
		
		$dbydateS=date_create($ydate2);
		date_sub($dbydateS,date_interval_create_from_date_string("1 days"));
		$dbydate2=date_format($dbydateS,"Y-m-d H:i:s");
		
		$dayBefYesDay=' AND ( recorded_date_time BETWEEN "'.$dbydate1.'" AND "'.$dbydate2.'")';

		//$yesDay='DATE(DATE_SUB('.$nowDate.',INTERVAL "1" DAY))';
		//$dayBefYesDay='DATE(DATE_SUB('.$nowDate.',INTERVAL "2" DAY))';
		$userName='Cron';
		$manualUpdate=0;
	}
	
			$updateDate=$ydate1; // this date only for shift cron data

		$selYes='SELECT * FROM energy_data_master WHERE `gateway_code`="'.$rows2["gateway_id"].'" AND `sensor_code`="'.$rows2["sensorCode"].'" AND `recorded_date_time` IN (SELECT MAX(`recorded_date_time`) FROM energy_data_master WHERE `gateway_code`="'.$rows2["gateway_id"].'" AND `sensor_code`="'.$rows2["sensorCode"].'" '.$dayBefYesDay.' ) ';
		$daybeforeData = mysql_query($selYes,$arkaerp);
		$dayBeforeYesterday = mysql_num_rows($daybeforeData);		
	if($dayBeforeYesterday >='1')
	{
		$yesDay=$yesDay;
		$dayBefYesDay=$dayBefYesDay;
		$max_min="MAX";
	}
	else
	{
		$yesDay=$yesDay;
		$dayBefYesDay=$yesDay;
		$max_min="MIN";
	}
	
		$selQry = 'SELECT A.KWH AS Yesterday,A.DG_KWH AS DG_Yesterday,B.KWH AS Today,B.DG_KWH AS DG_Today,A.recorded_date_time AS Min_Date,B.recorded_date_time AS Max_date,DATE(B.recorded_date_time) AS recorded_date,A.unit_rate AS unit_rate,(B.KWH-A.KWH)AS TOTAL_KWH ,(B.DG_KWH-A.DG_KWH)AS TOTAL_DG_KWH ,(B.KWH-A.KWH)*A.unit_rate AS cost,(B.DG_KWH-A.DG_KWH)*A.unit_rate AS dg_cost FROM (SELECT energy_data_master.KWH,energy_data_master.DG_KWH,energy_data_master.recorded_date_time,arka_sensor_master.unit_rate FROM `energy_data_master`,arka_sensor_master WHERE energy_data_master.sensor_code=arka_sensor_master.sensorCode AND arka_sensor_master.company_id="'.$rows2["company_id"].'" AND arka_sensor_master.branch_id="'.$rows2["branch_id"].'"  AND energy_data_master.`gateway_code`="'.$rows2["gateway_id"].'" AND energy_data_master.`sensor_code`="'.$rows2["sensorCode"].'" AND energy_data_master.`recorded_date_time` IN (SELECT '.$max_min.'(`recorded_date_time`) FROM energy_data_master WHERE energy_data_master.`gateway_code`="'.$rows2["gateway_id"].'" AND energy_data_master.`sensor_code`="'.$rows2["sensorCode"].'" '.$dayBefYesDay.' )) AS A ,(SELECT energy_data_master.KWH,energy_data_master.DG_KWH,energy_data_master.recorded_date_time,arka_sensor_master.unit_rate FROM `energy_data_master`,arka_sensor_master WHERE energy_data_master.sensor_code=arka_sensor_master.sensorCode AND arka_sensor_master.company_id="'.$rows2["company_id"].'" AND arka_sensor_master.branch_id="'.$rows2["branch_id"].'" AND energy_data_master.`gateway_code`="'.$rows2["gateway_id"].'" AND energy_data_master.`sensor_code`="'.$rows2["sensorCode"].'" AND`recorded_date_time` IN (SELECT MAX(`recorded_date_time`) FROM energy_data_master WHERE energy_data_master.`gateway_code`="'.$rows2["gateway_id"].'" AND energy_data_master.`sensor_code`="'.$rows2["sensorCode"].'" '.$yesDay.' )) AS B';
		$selectEnergyData = mysql_query($selQry,$arkaerp);
		$energyData2 = mysql_num_rows($selectEnergyData);
	while ($energyData = mysql_fetch_assoc($selectEnergyData))
	 {
		$InsQry='UPDATE `cron_daily_energy_data` SET `start_cum_kwh`="'.$energyData["Yesterday"].'",`dg_start_cum_kwh`="'.$energyData["DG_Yesterday"].'", `feeder_type`="'.$rows2["feeder_type"].'", `end_cum_kwh`="'.$energyData["Today"].'", `dg_end_cum_kwh`="'.$energyData["DG_Today"].'", `start_cum_date`="'.$energyData["Min_Date"].'",`dg_start_cum_date`="'.$energyData["Min_Date"].'", `end_cum_date`="'.$energyData["Max_date"].'",`dg_end_cum_date`="'.$energyData["Max_date"].'", `consuption_kwh`="'.$energyData["TOTAL_KWH"].'",`dg_consuption_kwh`="'.$energyData["TOTAL_DG_KWH"].'", `cost`="'.$energyData["unit_rate"].'",`dg_cost`="'.$energyData["unit_rate"].'", `consuption_cost`="'.$energyData["cost"].'",`dg_consuption_cost`="'.$energyData["dg_cost"].'",`posted_date_time`='.$nowDate.', `created_by`="'.$userName.'", `manual_update`="'.$manualUpdate.'" WHERE `company_id`="'.$rows2["company_id"].'" AND `branch_id`="'.$rows2["branch_id"].'" AND `gateway_code`="'.$rows2["gateway_id"].'" AND sensor_code="'.$rows2["sensorCode"].'" AND `recorded_date`="'.$updateDate.'"'; 
		mysql_query($InsQry,$arkaerp);
		echo "Cron Runs Sucessfully";
	}
	}
	/*****************************************     Query Starts for:  lastday KWH and Cost    *****************************************/	
		$InsertCronLog= "INSERT INTO cron_run_log (cron_name) VALUES ('cronEnergyMeterData_iot1.php')";
		mysql_query($InsertCronLog,$arkaerp);	
		
	mysql_free_result($sensorList);	
	mysql_free_result($sensorList2);	
	mysql_free_result($dateList);	
	mysql_free_result($firstday);
	mysql_free_result($LastDay);
	mysql_free_result($date1);
	mysql_free_result($Day);
	mysql_free_result($daybeforeData);	
	mysql_free_result($selectEnergyData);
	mysql_close($arkaerp);	
	
	
	
	
?>

