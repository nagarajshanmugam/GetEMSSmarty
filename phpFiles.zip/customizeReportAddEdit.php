<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.ReportsMgmt.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";
	
		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objStaff -> GetCompanyName();
		$objReportsMgmt		= new ReportsMgmt();
        $objReportsMgmt ->GetSensorName();
        $objReportsMgmt ->BranchListNew($objArray);
		if(isset($_POST['hdAction']) && !isset($_GET['Update']))
		{
			$objReportsMgmt ->InsertCustomizeReport($_POST);
		}
		if(isset($_GET['slNo']))
		{
			$objReportsMgmt->CustomizeReportEditView($objArray);
		}
       if(isset($_GET['Update']) && isset($_GET['slNo']) && isset($_POST['hdAction']))
		{
			$objReportsMgmt -> UpdateCustomizeReport($_POST);
		}
		if(isset($_GET['success_msg_for_insert']))
		{
			$objSmarty->assign('ErrorMessage', 'New Record Created Successfully');
		}
        if(isset($_GET['success_msg_for_update']))
		{
			$objSmarty->assign('SuccessMessage', 'Record Updated Successfully');
		} 
			$objSmarty->assign('IncludeTpl', 'customizeReportAddEdit.tpl');
			$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Location Reg');
			$objSmarty->assign('robots','index,follow');
			$objSmarty->assign('key_word','');
			$objSmarty->assign('generator','');
			$objSmarty->assign('document-state','dynamic');
			$objSmarty->assign('address',$config['SiteGlobalPath']);

			/*Display page*/
			$objSmarty->assign('LeftTpl', 'left.tpl');
			$objSmarty->display('pagetemplate.tpl');

?>