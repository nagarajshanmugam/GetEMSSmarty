<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.GatewayGroup.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";
	
		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objStaff -> GetCompanyName();
		$objGatewayGroup		= new GatewayGroup();
		$objGatewayGroup -> GetGatewayName();
		if(isset($_POST['hdAction']) && !isset($_GET['Update']))
		{
		$objGatewayGroup -> InsertGatewayGroup($_POST);
		}
		$objGatewayGroup -> ListEditView($objArray);
		if(isset($_GET['Update']) && isset($_GET['groupName'])){
		$objGatewayGroup -> EditBranch($_POST);
		}
	
		$objSmarty->assign('IncludeTpl', 'gatewayGroupAddEdit.tpl');
		$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Location Reg');
		$objSmarty->assign('robots','index,follow');
		$objSmarty->assign('key_word','');
		$objSmarty->assign('generator','');
		$objSmarty->assign('document-state','dynamic');
		$objSmarty->assign('address',$config['SiteGlobalPath']);
				
		/*Display page*/
		$objSmarty->assign('LeftTpl', 'left.tpl');
		$objSmarty->display('pagetemplate.tpl');

?>