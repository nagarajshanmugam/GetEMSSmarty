<?php 
	require_once "./includes/common.php";
	require_once $config['SiteClassPath']."class.Staff.php";
	
	$objStaff	= new Staff();
	if(isset($_POST['hdAction']))
	{
		$objStaff->chkStaffLogin($_POST);
	}
	if(isset($_SESSION['USER_GROUP']))
	{
		if($_SESSION['USER_GROUP'] =='Super Admin'){
			Redirect("companyList.php");
		}
		elseif($_SESSION['USER_GROUP'] =='Dashboard User'){
				Redirect("temperature_temperatureDashboard.php");
		}
		elseif($_SESSION['USER_GROUP'] =='Company Admin' || $_SESSION['USER_GROUP'] =='Subros Company Admin'){
		if($_SESSION["platformCode"]==5){
			Redirect("heinn_dashboard.php");
			}else{
			Redirect("companyDashboard.php");
			}
		}
		elseif($_SESSION['USER_GROUP'] =='Branch Admin' ){
			if($_SESSION["platformCode"]==1){
			Redirect("dashboard.php");
			}
			elseif($_SESSION["platformCode"]==3){
			Redirect("temperature_temperatureDashboard.php");
			}
			elseif($_SESSION["platformCode"]==5){
			Redirect("heinn_dashboard.php");
			}
			else{
			
			Redirect("dashboard.php");
			}
		}
		elseif($_SESSION['USER_GROUP'] =='Branch User' ){
			if($_SESSION["platformCode"]==1){
			    if($_SESSION["COMPANY_ID"]==8){
			        
			    Redirect("meterDashboard.php?companyId=OA==&branchId=OQ==&sensorCode=VE5GLTE=&gatewayCode=VFJCMjQ1LTM=");
			    }else{
				Redirect("dashboard.php");
			    }
			}
			elseif($_SESSION["platformCode"]==3){
				Redirect("temperature_temperatureDashboard.php");
			}elseif($_SESSION["platformCode"]==5){
			Redirect("heinn_dashboard.php");
			}
			else{
				Redirect("dashboard.php");
			}
		}
		elseif($_SESSION['USER_GROUP'] =='Heinn Admin'){
			
			Redirect("heinn_dashboard.php");
			
		}
	elseif($_SESSION['USER_GROUP'] =='Subros Branch Admin' || $_SESSION['USER_GROUP'] =='Subros Branch User')
	{
		Redirect("meterDashboard.php?companyId=Nw==&branchId=OA==&sensorCode=UkdBMjBTLTE=&gatewayCode=VFJCMTQ1LTU=");
	}
	elseif($_SESSION['USER_GROUP'] =='Suguna Branch Admin' || $_SESSION['USER_GROUP'] =='Suguna Branch User')
	{
		Redirect("dashboard.php");
	}
	}
	if(!isset($_POST["emailId"]))
	{
		if(basename($_SERVER['PHP_SELF'])!="index.php")
		{
			Redirect("index.php");
		}
	}
	$Onload="document.stafflogin.email.focus();";
	$objSmarty->assign("Onload", $Onload);
	$objSmarty->display("index.tpl");
?>