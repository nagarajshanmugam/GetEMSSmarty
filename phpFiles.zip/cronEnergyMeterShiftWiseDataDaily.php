<?php 
//	require_once('./Connections/ARKAEMS.php'); 
	$hostname_arkaems = "localhost";
	$database_arkaems = "univa_ems";
	$username_arkaems = "root";
	$password_arkaems = "@dmin987";
$arkaerp = mysql_connect($hostname_arkaems, $username_arkaems, $password_arkaems) or trigger_error(mysql_error(),E_USER_ERROR);
      mysql_select_db($database_arkaems, $arkaerp) or die(mysql_error());
      mysql_query( "SET SESSION sql_mode = 'NO_ENGINE_SUBSTITUTION'",$arkaerp);
	/**********   Now Date cloud and local condition Start           **************/
	if($username_arkaems != 'root')
	{
		$nowDate= 'DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE)';
	}
	else{
		$nowDate= 'NOW()';
	}
	
	/**********   Now Date cloud and local condition Ends           **************/
	/**********   Sensor List Select Query Starts            **************/
	if($_POST['sensor_code']<> '')
	{
		$whCond="arka_sensor_master.sensorCode='".$_POST['sensor_code']."' AND arka_sensor_master.segmentName='Energy Meter'";
	}
	else
	{
		$whCond="arka_sensor_master.segmentName='Energy Meter'";
	}
	$sensorSel = "SELECT arka_sensor_master.*,arka_sensor_master.feeder_type,arka_sensor_master.slNo AS feeder_master_id, arka_sensor_master.unit_rate, arka_sensor_master.unit_rate AS feeder_unit_rate  FROM arka_sensor_master WHERE arka_sensor_master.status='1' AND arka_sensor_master.isActive='1' AND ".$whCond."";
	$sensorList = mysql_query($sensorSel,$arkaerp);
	$machine = mysql_num_rows($sensorList);	
	/**********   Sensor List Select Query Ends            **************/
		
    /******************************************  Sensors in loop starts                ***************/		

	while($rows=mysql_fetch_array($sensorList))
	{
		
		$sqlShiftMas = "SELECT * FROM arka_branch_shift_master WHERE company_id='".$rows['company_id']."' AND branch_id='".$rows['branch_id']."' AND is_active='1' AND status='1'";
		$ShiftMasDat = mysql_query($sqlShiftMas,$arkaerp);
		
        /******************************************    Shift Master  loop starts    *****************************************/	
			
		while($shiftMas=mysql_fetch_array($ShiftMasDat))
		{  
			
			if(isset($_GET['recorded_date']))
			{
				$yesDay='DATE("'.$_GET['recorded_date'].'")'; //  this is posted date for manual cron runs
				$userName =$_GET['userName'];                 //  Session User Name
				$manualUpdate=1;                               //  Cron Status cron Manually runs means status is 1
			}
			else
			{
				$yesDay='DATE(DATE_SUB('.$nowDate.',INTERVAL "1" DAY))'; //  this is Yesterday date for cron runs Automattically
				$userName='Cron';                                        //  Cron is a user name if cron runs Automattically
				$manualUpdate=0;                                         //  Cron Status cron Automattically runs means status is 0
			}
			
			$fromDateTime='CONCAT('.$yesDay.' , " '.$shiftMas['start_time'].'")';       //  Shift  From Date Time
			$toDateTime='CONCAT('.$yesDay.' , " '.$shiftMas['end_time'].'")';           //  Shift  to Date Time
			
			/*********   if $yesDay variable same date but we need end date as next day date of $yesDay  if $shiftMas['end_time'] is equal to '00:00:00'            ********/
		//	if($shiftMas['end_time']== '00:00:00'){
			if($shiftMas['start_time'] > $shiftMas['end_time']){
				$endDateTime='DATE_ADD('.$toDateTime.',INTERVAL "1" DAY)'; 
			}
			else
			{
				$endDateTime=$toDateTime;
			}
			/*****************/
		
			 $sql = 'SELECT * FROM cron_daily_shift_wise_data WHERE from_date_time='.$fromDateTime.' AND to_date_time='.$endDateTime.' AND recorded_date='.$yesDay.' AND sensor_code="'.$rows["sensorCode"].'" AND shift_master_id="'.$shiftMas["shift_master_id"].'"';
			$Day = mysql_query($sql,$arkaerp) or die(mysql_error());
			$count = mysql_num_rows($Day);
			if($count=="0")
			{
			
				$selQry1 = 'SELECT A.KWH AS MIN_KWH, B.KWH AS MAX_KWH, (B.KWH - A.KWH) AS totalKWH , A.recorded_date_time AS MIN_DATE_TIME, B.recorded_date_time AS MAX_DATE_TIME FROM ( SELECT * FROM `energy_data_master` WHERE `gateway_code`="'.$rows["gateway_id"].'" AND `sensor_code`="'.$rows["sensorCode"].'" AND `recorded_date_time` BETWEEN '.$fromDateTime.' AND '.$endDateTime.'   ORDER BY recorded_date_time ASC LIMIT 0,1) AS A ,( SELECT * FROM `energy_data_master` WHERE `gateway_code`="'.$rows["gateway_id"].'" AND `sensor_code`="'.$rows["sensorCode"].'" AND `recorded_date_time` BETWEEN '.$fromDateTime.' AND '.$endDateTime.'   ORDER BY recorded_date_time DESC LIMIT 0,1) AS B '; 
				$selectEnergyData1 = mysql_query($selQry1,$arkaerp) or die(mysql_error());
			$countShift = mysql_num_rows($selectEnergyData1);
				if($countShift=="0"){
				$minKWH='';
				$maxKWH='';
				$totalKWHConsuption= 0;
				
				}else{
				$energyData1 = mysql_fetch_assoc($selectEnergyData1) or die(mysql_error());
				$minKWH=$energyData1["MIN_KWH"];
				$maxKWH=$energyData1["MAX_KWH"];
				$totalKWHConsuption= $energyData1["totalKWH"];
				
				}
				
			//echo	$selQry2 = 'SELECT * FROM `energy_data_master` WHERE `gateway_code`="'.$rows["gateway_id"].'" AND `sensor_code`="'.$rows["sensorCode"].'" AND `recorded_date_time` BETWEEN "2020-12-02 00:00:00" AND "2020-12-02 08:00:00"  ORDER BY recorded_date_time DESC LIMIT 0,1'; 
			//	$selectEnergyData2 = mysql_query($selQry2,$arkaerp) or die(mysql_error());
			//	$energyData2 = mysql_fetch_assoc($selectEnergyData2) or die(mysql_error());
				
				
				//$minKWH=$energyData1["KWH"];
				//$maxKWH=$energyData2["KWH"];
				//$minRecordedDateTime=$energyData1["recorded_date_time"];
				//$maxRecordedDateTime=$energyData2["recorded_date_time"];
				//$recordedDate=$energyData2["recorded_date"];
				$unitRate=$rows["feeder_unit_rate"];
				//$totalKWHConsuption= $maxKWH - $minKWH;
				$totalCost= $energyData1["totalKWH"] * $unitRate;

			    $Insert = "INSERT INTO cron_daily_shift_wise_data (company_id,branch_id,feeder_master_id,sensor_code,feeder_type,feeder_unit_rate,shift_master_id,shift_name,from_date_time,to_date_time,recorded_date,start_cum_kwh,end_cum_kwh,consuption_kwh,cost,consuption_cost,cron_run_date_time,created_by,cron_status) VALUES ('".$rows['company_id']."','".$rows['branch_id']."','".$rows['feeder_master_id']."','".$rows['sensorCode']."','".$rows['feeder_type']."','".$rows['unit_rate']."','".$shiftMas['shift_master_id']."','".$shiftMas['shift_name']."',".$fromDateTime.",".$endDateTime.",".$yesDay.",'".$minKWH."','".$maxKWH."','".$totalKWHConsuption."','".$unitRate."','".$totalCost."',".$nowDate.",'".$userName."','".$manualUpdate."')"; 
			    mysql_query($Insert,$arkaerp) or die(mysql_error());	
			echo "Inserted";echo"<br>";
			}
			else
			{
			echo "Already Exits";echo"<br>";					
			
			}
		}
		/******************************************    Shift Master  loop Ends    *****************************************/	

		
	}  
	/******************************************  Sensors in loop Ends                ***************/
	
	
mysql_close($arkaerp);
?>

