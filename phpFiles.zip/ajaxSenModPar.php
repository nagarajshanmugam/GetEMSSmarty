<?php
   require('includes/common.php');
   	include_once $config['SiteClassPath']."class.SensorMaster.php";
    $objSensorMaster	= new SensorMaster();
 
		
	if(isset($_POST['platType']) && isset($_POST['sl_no']) && isset($_POST['left']))
	{ 
       $objSensorMaster->GetSensorModelParameter($_POST['platType'],$_POST['sl_no']);		
	}	
	if(isset($_POST['platType']) && isset($_POST['sl_no']) && isset($_POST['right']))
	{ 
       $objSensorMaster->AssignedParameter($_POST['platType'],$_POST['sl_no']);		
	}	

?>