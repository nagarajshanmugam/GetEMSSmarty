<?php
/**
 * PHPExcel
 *
 * Copyright (C) 2006 - 2013 PHPExcel
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @category   PHPExcel
 * @package    PHPExcel
 * @copyright  Copyright (c) 2006 - 2013 PHPExcel (http://www.codeplex.com/PHPExcel)
 * @license    http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt	LGPL
 * @version    1.7.9, 2013-06-02
 */

/** Error reporting */
error_reporting(E_ALL);

/** Include PHPExcel */

require('includes/common.php');
require_once('./Connections/ARKAEMS.php');
require_once dirname(__FILE__) . '/Classes/PHPExcel.php';


// Create new PHPExcel object
//echo date('H:i:s') , " Create new PHPExcel object" , EOL;
$objPHPExcel = new PHPExcel();

// Set document properties
//echo date('H:i:s') , " Set document properties" , EOL;
$objPHPExcel->getProperties()->setCreator("Arka Automaations Ltd")
							 ->setLastModifiedBy("Arka Automaations Ltd")
							 ->setTitle("Office 2007 XLSX Test Document")
							 ->setSubject("Office 2007 XLSX Test Document")
							 ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
							 ->setKeywords("office 2007 openxml php")
							 ->setCategory("Test result file");



// Create a first sheet, representing sales data
//echo date('H:i:s') , " Add some data" , EOL;

// ********************************************Get Url Data ********************************************************
 //echo $macid;
$sensorCode = base64_decode($_GET['sensorCode']);


$fdate = date("d-M-Y", strtotime($_GET['date1'])); 

$objPHPExcel->setActiveSheetIndex(0);
$objPHPExcel->getActiveSheet()->mergeCells('A3:G3');
$objPHPExcel->getActiveSheet()->setCellValue('A3', 'Hourly Report');
$objPHPExcel->getActiveSheet()->getStyle('A3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFont()->setSize(18);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFill()->getStartColor()->setARGB('FF1E90FF');

$objPHPExcel->getActiveSheet()->mergeCells('A1:B1');
$objPHPExcel->getActiveSheet()->setCellValue('A1', ' Date:');
$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('C1', $fdate);
$objPHPExcel->getActiveSheet()->getStyle('C1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->mergeCells('D1:E1');
$objPHPExcel->getActiveSheet()->setCellValue('D1', '');
$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('D1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('G1', '');
$objPHPExcel->getActiveSheet()->getStyle('G1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setSize(12);

 $selYes='SELECT energy_data_master.*,arka_sensor_master.sensorName,arka_sensor_master.unit_rate,arka_sensor_master.company_id,arka_sensor_master.branch_id FROM energy_data_master,arka_sensor_master WHERE energy_data_master.`sensor_code`="'.$_GET["sensorCode"].'" AND energy_data_master.sensor_code=arka_sensor_master.sensorCode AND energy_data_master.`recorded_date_time` IN (SELECT MAX(`recorded_date_time`) FROM energy_data_master WHERE `sensor_code`="'.$_GET["sensorCode"].'" AND DATE(`recorded_date_time`)="'.$_GET["date1"].'" )  ';
			
	$recset1 = mysql_query($selYes, $arkaerp) or die(mysql_error());
	$row1 = mysql_fetch_assoc($recset1);
	 
	 $selCom='SELECT * FROM arka_company_master WHERE slNo="'.$row1["company_id"].'"';
	 $compExe = mysql_query($selCom, $arkaerp) or die(mysql_error());
	 $resComp = mysql_fetch_assoc($compExe);
	 $selBranch='SELECT * FROM arka_branch_master WHERE sl_no="'.$row1["branch_id"].'"';
	 $branchExe = mysql_query($selBranch, $arkaerp) or die(mysql_error());
	 $resBranch = mysql_fetch_assoc($branchExe);
	
	$companyName = $resComp['companyName'];
	$branchName = $resBranch['branch_name'];

	$sensorName = $row1['sensorName'];
	//echo $row1['unit_rate']; exit;
	
$objPHPExcel->getActiveSheet()->mergeCells('A4:B4');
$objPHPExcel->getActiveSheet()->setCellValue('A4', 'Branch :');
$objPHPExcel->getActiveSheet()->getStyle('A4')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A4')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('C4', $branchName);
$objPHPExcel->getActiveSheet()->getStyle('C4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('C4')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('D4', 'Place Of installation :');
$objPHPExcel->getActiveSheet()->getStyle('D4')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('D4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D4')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->mergeCells('E4:F4');
$objPHPExcel->getActiveSheet()->setCellValue('E4', $sensorName);
$objPHPExcel->getActiveSheet()->getStyle('E4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('E4')->getFont()->setSize(12);



			$objPHPExcel->getActiveSheet()->setCellValue('A5', 'Start Date Time');
			$objPHPExcel->getActiveSheet()->setCellValue('B5', 'End Date Time');
			$objPHPExcel->getActiveSheet()->setCellValue('C5', 'Start Kwh');
			$objPHPExcel->getActiveSheet()->setCellValue('D5', 'End Kwh');
			$objPHPExcel->getActiveSheet()->setCellValue('E5', 'Total Kwh');
			$objPHPExcel->getActiveSheet()->setCellValue('F5', 'Unit Rate');
			$objPHPExcel->getActiveSheet()->setCellValue('G5', 'Total Cost');

			
			mysql_select_db($database_arkaems, $arkaerp);

$selQry = 'SELECT FLOOR(UNIX_TIMESTAMP(DATE_ADD(recorded_date_time, INTERVAL 30 MINUTE))/(60 * 60)) AS timekey, "'.$row1["unit_rate"].'" AS unit_rate, MIN(recorded_date_time) AS start_date_time, MAX(recorded_date_time) AS end_date_time, (MAX(energy_data_master.KWH)-MIN(energy_data_master.KWH)) AS consuption_kwh,MAX(energy_data_master.KWH) AS end_cum_kwh,MIN(energy_data_master.KWH) AS start_cum_kwh, ((MAX(energy_data_master.KWH)-MIN(energy_data_master.KWH)) * '.$row1["unit_rate"].') AS consuption_cost FROM energy_data_master WHERE sensor_code="'.$row1["sensor_code"].'" AND DATE(recorded_date_time)="'.$_GET["date1"].'" GROUP BY timekey';
		$mt2 = mysql_query($selQry, $arkaerp) or die(mysql_error());
//$recNumRow= mysql_num_rows($query_rs1);
	
$loop =6;
while( $row2 = mysql_fetch_array($mt2) ) {
    
   

	
 
    
    $startDate = $row2['start_date_time'];  
    $startDateTime = date("d-M-Y h:i A", strtotime($startDate)); 
	$endDate = $row2['end_date_time'];  
    $endDateTime = date("d-M-Y h:i A", strtotime($endDate));
    $tkwh =$tkwh + $row2['consuption_kwh'];
    $tcost =$tcost + $row2['consuption_cost'];
	
							$objPHPExcel->getActiveSheet()->setCellValue('A' . $loop, $startDateTime);
							$objPHPExcel->getActiveSheet()->setCellValue('B' . $loop, $endDateTime);
							$objPHPExcel->getActiveSheet()->setCellValue('C' . $loop, round($row2['start_cum_kwh'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('D' . $loop, round($row2['end_cum_kwh'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('E' . $loop, round($row2['consuption_kwh'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('F' . $loop, round($row2['cost'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('G' . $loop, round($row2['consuption_cost'],2));
							$loop = $loop+1;
						}
			$objPHPExcel->getActiveSheet()->setCellValue('D' . $loop, 'Total Kwh');
            $objPHPExcel->getActiveSheet()->getStyle('D' . $loop)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
			$objPHPExcel->getActiveSheet()->setCellValue('E' . $loop, $tkwh);
			$objPHPExcel->getActiveSheet()->setCellValue('F' . $loop, 'Total Cost');
            $objPHPExcel->getActiveSheet()->getStyle('F' . $loop)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
			$objPHPExcel->getActiveSheet()->setCellValue('G' . $loop, $tcost);
			
					


$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setAutoSize(true);





$objPHPExcel->getActiveSheet()->getStyle('G3')->getFont()->setSize(14);
$objPHPExcel->getActiveSheet()->getStyle('G3')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('B5')->getAlignment()->setShrinkToFit(true);

// Set thin black border outline around column
//echo date('H:i:s') , " Set thin black border outline around column" , EOL;
$styleThinBlackBorderOutline = array(
	'borders' => array(
		'outline' => array(
			'style' => PHPExcel_Style_Border::BORDER_THIN,
			'color' => array('argb' => 'FF000000'),
		),
	),
);
$objPHPExcel->getActiveSheet()->getStyle('A5:G'.$loop)->applyFromArray($styleThinBlackBorderOutline);


// Set thick brown border outline around "Total"
//echo date('H:i:s') , " Set thick brown border outline around Total" , EOL;
$styleThickBrownBorderOutline = array(
	'borders' => array(
		'outline' => array(
			'style' => PHPExcel_Style_Border::BORDER_THICK,
			'color' => array('argb' => 'FF993300'),
		),
	),
);
//$objPHPExcel->getActiveSheet()->getStyle('D13:E13')->applyFromArray($styleThickBrownBorderOutline);

// Set fills

//echo date('H:i:s') , " Set fills" , EOL;
$objPHPExcel->getActiveSheet()->getStyle('A5:G5')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A5:G5')->getFill()->getStartColor()->setARGB('FFFF8C00');
$objPHPExcel->getActiveSheet()->getStyle('A4:G4')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A4:G4')->getFill()->getStartColor()->setARGB('FF5F9EA0');
// Set style for header row using alternative method
//echo date('H:i:s') , " Set style for header row using alternative method" , EOL;

$objPHPExcel->getActiveSheet()->getStyle('A5')->applyFromArray(
		array(
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
			),
			'borders' => array(
				'left'     => array(
 					'style' => PHPExcel_Style_Border::BORDER_THIN
 				)
			)
		)
);

$objPHPExcel->getActiveSheet()->getStyle('B5')->applyFromArray(
		array(
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
			)
		)
);

$objPHPExcel->getActiveSheet()->getStyle('L5')->applyFromArray(
		array(
			'borders' => array(
				'right'     => array(
 					'style' => PHPExcel_Style_Border::BORDER_THIN
 				)
			)
		)
);

// Unprotect a cell
//echo date('H:i:s') , " Unprotect a cell" , EOL;
$objPHPExcel->getActiveSheet()->getStyle('B1')->getProtection()->setLocked(PHPExcel_Style_Protection::PROTECTION_UNPROTECTED);

// Add a hyperlink to the sheet
$loop =$loop+2;
//echo date('H:i:s') , " Add a hyperlink to the sheet" , EOL;
$objPHPExcel->getActiveSheet()->setCellValue('B' . $loop, '');
$objPHPExcel->getActiveSheet()->getCell('B'  . $loop)->getHyperlink()->setUrl('https://ems.arkaautomaations.com');
$objPHPExcel->getActiveSheet()->getCell('B' . $loop)->getHyperlink()->setTooltip('Navigate to website');
$objPHPExcel->getActiveSheet()->getStyle('B' . $loop)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
$loop =$loop+1;
$objPHPExcel->getActiveSheet()->setCellValue('B'  . $loop, '');
//$objPHPExcel->getActiveSheet()->getCell('B' . $loop)->getHyperlink()->setUrl("sheet://'Terms and conditions'!A1");
//$objPHPExcel->getActiveSheet()->getCell('B'  . $loop)->getHyperlink()->setTooltip('Review terms and conditions');
$objPHPExcel->getActiveSheet()->getStyle('B' . $loop)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);


// Play around with inserting and removing rows and columns
//echo date('H:i:s') , " Play around with inserting and removing rows and columns" , EOL;
$objPHPExcel->getActiveSheet()->insertNewRowBefore(6, 10);
$objPHPExcel->getActiveSheet()->removeRow(6, 10);
$objPHPExcel->getActiveSheet()->insertNewColumnBefore('E', 5);
$objPHPExcel->getActiveSheet()->removeColumn('E', 5);

// Set header and footer. When no different headers for odd/even are used, odd header is assumed.
//echo date('H:i:s') , " Set header/footer" , EOL;
$objPHPExcel->getActiveSheet()->getHeaderFooter()->setOddHeader('&L&BInvoice&RPrinted on &D');
$objPHPExcel->getActiveSheet()->getHeaderFooter()->setOddFooter('&L&B' . $objPHPExcel->getProperties()->getTitle() . '&RPage &P of &N');

// Set page orientation and size
//echo date('H:i:s') , " Set page orientation and size" , EOL;
$objPHPExcel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
$objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);

// Rename first worksheet
//echo date('H:i:s') , " Rename first worksheet" , EOL;
$objPHPExcel->getActiveSheet()->setTitle('Hourly Report');
