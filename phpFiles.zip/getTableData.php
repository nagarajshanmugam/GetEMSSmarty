<?php
include('config.php');
session_start();
date_default_timezone_set('Asia/Kolkata');
session_start();
$hostname_arkaerp = $config['DBHost'];
$database_arkaerp = $config['DBName'];
$username_arkaerp = $config['DBUser'];
$password_arkaerp = $config['DBPassword'];
$arkaerp = mysql_connect($hostname_arkaerp, $username_arkaerp, $password_arkaerp,$database_arkaerp) or trigger_error(mysql_error(),E_USER_ERROR);

mysql_select_db($database_arkaerp,$arkaerp);
$cid=$_REQUEST['cid'];
$bid=$_REQUEST['bid'];
//echo $cid;
if($cid != '')
{
$comId = base64_decode($_REQUEST['cid']);
}	
else
{
$comId = $_SESSION['CustomerId'];
}
if($bid != '')
{
$branchId = base64_decode($_REQUEST['bid']);
}	
else
{
$branchId = $_SESSION['branch_id'];
}

function secondsToDhmss($seconds) {
//$seconds = Number($seconds);
$d = floor($seconds / (3600*24));
$h = floor($seconds % (3600*24) / 3600);
$m = floor($seconds % 3600 / 60);
$s = floor($seconds % 60);

if($d > 0 )
{
if( $d == 1)
{
$dDisplay = $d .' day, ';
}
else
{
$dDisplay = $d .' days, ';
}
}
else
{
$dDisplay = '';
}
if($h > 0 )
{
if( $h == 1)
{
$hDisplay = $h .' hrs, ';
}
else
{
$hDisplay = $h .' hrs, ';
}
}
else
{
$hDisplay = '';
}
if($m > 0 )
{
if( $m == 1)
{
$mDisplay = $m .' min, ';
}
else
{
$mDisplay = $m ." min's, ";
}
}
else
{
$mDisplay = '';
}
if($s > 0 )
{
if( $s == 1)
{
$sDisplay = $s .' sec ';
}
else
{
$sDisplay = $s ." sec's ";
}
}
else
{
$sDisplay = '';
}
$res=  $dDisplay .' '. $hDisplay .' '. $mDisplay .' '. $sDisplay;
echo $res;
 }
?>   
<link rel="stylesheet" href="plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
<script src="plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<script type="text/javascript">
  $("input[data-bootstrap-switch]").each(function(){
      $(this).bootstrapSwitch('state', $(this).prop('checked'));
    });
	</script>
	
			       <table id="example" class="table table-bordered table-hover">
                <thead>
                <tr>
    			  <th class="slNo" rowspan="3" >#</th>
                  <th class="name" rowspan="3">Place Of Installation</th>
                  <th class="gate" rowspan="3">Gateway</th>
				   <th class="status" rowspan="3">Status</th>
                  <th  colspan="4" class="code" >Today</th>
                  <th class="action" rowspan="3">Date Time</th>
                  <th class="last" rowspan="3">Last Comm</th>
                  
          
                </tr>
                 <tr>
                    <th class="cost" colspan="2">EB</th>
                  <th class="cost" colspan="2">DG</th>
                </tr>
                <tr>
    			 
                  <th class="cost" >KWH</th>
                  <th class="cost" >Cost</th>
                   <th class="cost" >KWH</th>
                  <th class="cost" >Cost</th>
               
                 
                  
                </tr>
                </thead>			                  <tbody>

							  <?php
						
		 $sql = 'SELECT energy_data_master_view.*,arka_sensor_master.*,(arka_sensor_master.kw_max_value/5) AS KW_INT, arka_sensor_master.sensorName AS feeder_name,TIMESTAMPDIFF(SECOND, recorded_date_time, NOW()) AS secs FROM energy_data_master_view,arka_sensor_master WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.sensorCode=energy_data_master_view.sensor_code AND arka_sensor_master.feeder_type="Main Meter"  '; 
	     $source=mysql_query($sql);//echo $sql;
	       
	   
      //  $step1=mysql_fetch_array($source1);
        
		
		 //$step2=mysql_fetch_array($source2);
							   
							   
								$i=1;	
								while($step=mysql_fetch_array($source))
								{
							
							$pid=$step['slNo'];
							    ?>
                                  <tr>
                 <td><?php echo $i;?></td><?php
                 $SelQuery = 'SELECT * FROM `arka_sensor_master` WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.feeder_type="Sub Meter" GROUP BY sensorCode';
                  $source6=mysql_query($SelQuery);//echo $SelQuery;
                 	?>
				  <td><a href="meterDashboard.php?companyId=<?php echo base64_encode($comId);?>&branchId=<?php echo base64_encode($branchId);?>&sensorCode=<?php echo base64_encode($step['sensor_code']);?>&gatewayCode=<?php echo base64_encode($step['gateway_code']);?>" style="color:#000000;text-decoration:underline;" title="Meter Details"><?php echo $step['feeder_name'];?></a>&ensp;&ensp;<?php while($step6=mysql_fetch_array($source6))
					{  if($step['feeder_type'] == "Main Meter" && $step['slNo'] == $step6['parent_id']){ ?><a href="subdashboard.php?parent_id=<?php echo  base64_encode($pid);?>&companyId=<?php echo base64_encode($comId);?>&branchId=<?php echo base64_encode($branchId); ?>"><i class="fa fa-sitemap" aria-hidden="true" title="Submeter List"></i></a><?php } ?><?php } ?></td>
                 <td ><?php echo $step['gateway_code'];?></td>
                <td >
                <?php $tog='';
                $SelQuery = 'SELECT max(ping_log_id) AS ping_log_id, max(gateway_code) AS gateway_code,max(gateway_date_time) AS gateway_date_time FROM `gateway_ping_log` GROUP BY gateway_code ORDER BY ping_log_id';
	      $source2=mysql_query($SelQuery);//echo $SelQuery;
                 	while($step2=mysql_fetch_array($source2))
					{ 
					  $currDate=  date("Y-m-d H:i:s", strtotime("-30 seconds"));
					  $currDate1=  date("Y-m-d H:i:s", strtotime("-120 seconds"));
                 if($step2['gateway_code']<> "YMN-1" && $step2['gateway_code'] == $step['gateway_code'] && $step2['gateway_date_time'] >= $currDate)
                 { $tog=1; ?>
                <img  src="./images/on.png">
                 <?php   
                 }
                 elseif($step2['gateway_code']<> "YMN-1" && $step2['gateway_code'] == $step['gateway_code'] && $step2['gateway_date_time'] < $currDate)
                 { $tog=1;
                 ?>
                 <img  src="./images/off.png">
                 <?php
              	}
              	
              	 if($step2['gateway_code']== "YMN-1" && $step2['gateway_code'] == $step['gateway_code'] && $step2['gateway_date_time'] >= $currDate1)
                 { $tog=1; ?>
                <img  src="./images/on.png">
                 <?php   
                 }
                 elseif($step2['gateway_code']== "YMN-1" && $step2['gateway_code'] == $step['gateway_code'] && $step2['gateway_date_time'] < $currDate1)
                 { $tog=1;
                 ?>
                 <img  src="./images/off.png">
                 <?php
              	}
              	
					}
					
					if($tog==''){ 
					    ?>
					    <img  src="./images/off.png">
				<?php	    
					}
              	?>
              	</td>
                 <?php 
                  $selQryC = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost,sensor_code FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND DATE(recorded_date)=DATE(now()) AND MONTH(recorded_date)=MONTH(now()) AND YEAR(recorded_date)=YEAR(now()) GROUP BY sensor_code';	       
		$source1=mysql_query($selQryC);//echo $selQryC;
                 	while($step1=mysql_fetch_array($source1))
					{
                 if($step1['sensor_code'] == $step['sensorCode'])
                 { ?>
                 <td align="right"><?php if(isset($step1['TOTAL_KWH'])){ echo $step1['TOTAL_KWH'];} else{echo 0.00;}?></td>
                 <td align="right"><?php  if(isset($step1['cost'])){echo $step1['cost'];} else{echo 0.00;} ?></td>
                 <td align="right"><?php if(isset($step1['dg_TOTAL_KWH'])){ echo $step1['dg_TOTAL_KWH'];} else{echo 0.00;}?></td>
                 <td align="right"><?php  if(isset($step1['dg_cost'])){echo $step1['dg_cost'];} else{echo 0.00;} ?></td>
              <?php   
                     
                 }
              	}
              	?>
			  <td><?php echo date("d-M-Y h:i:s A", strtotime($step['recorded_date_time']));?></td>
                 <td><?php echo secondsToDhmss($step['secs']);echo " ";echo "ago";?></td>
                    
                                 </tr>
			                    	<?php 
                                 $i=$i+1;
								
								}
								
								
								 $sql = 'SELECT power_factor_energy_data_view.*,arka_sensor_master.*,arka_sensor_master.sensorName AS feeder_name,(arka_sensor_master.kw_max_value/5) AS KW_INT,TIMESTAMPDIFF(SECOND, recorded_date_time, NOW()) AS secs FROM power_factor_energy_data_view,arka_sensor_master WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.sensorCode=power_factor_energy_data_view.sensor_code  AND arka_sensor_master.feeder_type="Main Meter"  '; 
	     $source=mysql_query($sql);//echo $sql;
	       
	   
      //  $step1=mysql_fetch_array($source1);
        
		
		 //$step2=mysql_fetch_array($source2);
							   
							   
								$i=1;	
								while($step=mysql_fetch_array($source))
								{
							
							$pid=$step['slNo'];
							    ?>
                                  <tr>
                 <td><?php echo $i;?></td><?php
                 $SelQuery = 'SELECT * FROM `arka_sensor_master` WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.feeder_type="Sub Meter" GROUP BY sensorCode';
                  $source6=mysql_query($SelQuery);//echo $SelQuery;
                 	?>
				  <td><a href="meterDashboard.php?companyId=<?php echo base64_encode($comId);?>&branchId=<?php echo base64_encode($branchId);?>&sensorCode=<?php echo base64_encode($step['sensor_code']);?>&gatewayCode=<?php echo base64_encode($step['gateway_code']);?>" style="color:#000000;text-decoration:underline;" title="Meter Details"><?php echo $step['feeder_name'];?></a>&ensp;&ensp;<?php while($step6=mysql_fetch_array($source6))
					{  if($step['feeder_type'] == "Main Meter" && $step['slNo'] == $step6['parent_id']){ ?><a href="subdashboard.php?parent_id=<?php echo  base64_encode($pid);?>&companyId=<?php echo base64_encode($comId);?>&branchId=<?php echo base64_encode($branchId); ?>"><i class="fa fa-sitemap" aria-hidden="true" title="Submeter List"></i></a><?php } ?><?php } ?></td>
                 <td ><?php echo $step['gateway_code'];?></td>
                <td >
                <?php $tog='';
                $SelQuery = 'SELECT max(ping_log_id) AS ping_log_id, max(gateway_code) AS gateway_code,max(gateway_date_time) AS gateway_date_time FROM `gateway_ping_log` GROUP BY gateway_code ORDER BY ping_log_id';
	      $source2=mysql_query($SelQuery);//echo $SelQuery;
                 	while($step2=mysql_fetch_array($source2))
					{ 
					  $currDate=  date("Y-m-d H:i:s", strtotime("-30 seconds"));
					  $currDate1=  date("Y-m-d H:i:s", strtotime("-120 seconds"));
                 if($step2['gateway_code']<> "YMN-1" && $step2['gateway_code'] == $step['gateway_code'] && $step2['gateway_date_time'] >= $currDate)
                 { $tog=1; ?>
                <img  src="./images/on.png">
                 <?php   
                 }
                 elseif($step2['gateway_code']<> "YMN-1" && $step2['gateway_code'] == $step['gateway_code'] && $step2['gateway_date_time'] < $currDate)
                 { $tog=1;
                 ?>
                 <img  src="./images/off.png">
                 <?php
              	}
              	
              	 if($step2['gateway_code']== "YMN-1" && $step2['gateway_code'] == $step['gateway_code'] && $step2['gateway_date_time'] >= $currDate1)
                 { $tog=1; ?>
                <img  src="./images/on.png">
                 <?php   
                 }
                 elseif($step2['gateway_code']== "YMN-1" && $step2['gateway_code'] == $step['gateway_code'] && $step2['gateway_date_time'] < $currDate1)
                 { $tog=1;
                 ?>
                 <img  src="./images/off.png">
                 <?php
              	}
              	
					}
					
					if($tog==''){ 
					    ?>
					    <img  src="./images/off.png">
				<?php	    
					}
              	?>
              	</td>
                 <?php 
                  $selQryC = 'SELECT SUM(`consuption_kwh`) AS TOTAL_KWH ,SUM(`consuption_cost`) AS cost,SUM(`dg_consuption_kwh`) AS dg_TOTAL_KWH ,SUM(`dg_consuption_cost`) AS dg_cost,sensor_code FROM `cron_daily_energy_data` WHERE company_id="'.$comId.'" AND branch_id="'.$branchId.'" AND DATE(recorded_date)=DATE(now()) AND MONTH(recorded_date)=MONTH(now()) AND YEAR(recorded_date)=YEAR(now()) GROUP BY sensor_code';	       
		$source1=mysql_query($selQryC);//echo $selQryC;
		$rowcount=mysql_num_rows($source1);
                 	if($rowcount <> '0')
                 	{
                 	while($step1=mysql_fetch_array($source1))
					{
                 if($step1['sensor_code'] == $step['sensorCode'])
                 { ?>
                 <td align="right"><?php if(isset($step1['TOTAL_KWH'])){ echo $step1['TOTAL_KWH'];} else{echo 0.00;}?></td>
                 <td align="right"><?php  if(isset($step1['cost'])){echo $step1['cost'];} else{echo 0.00;} ?></td>
                 <td align="right"><?php if(isset($step1['dg_TOTAL_KWH'])){ echo $step1['dg_TOTAL_KWH'];} else{echo 0.00;}?></td>
                 <td align="right"><?php  if(isset($step1['dg_cost'])){echo $step1['dg_cost'];} else{echo 0.00;} ?></td>
              <?php   
                     
                 }
					}
                 	}
                 else
                 { ?>
                   <td align="right">0.00</td>  
                   <td align="right">0.00</td> 
                   <td align="right">0.00</td> 
                   <td align="right">0.00</td> <?php
                 }
              	?>
			  <td><?php echo date("d-M-Y h:i:s A", strtotime($step['recorded_date_time']));?></td>
                 <td><?php echo secondsToDhmss($step['secs']);echo " ";echo "ago";?></td>
                    
                                 </tr>
			                    	<?php 
                                 $i=$i+1;
								
								}
								
									?>
									
        					

								
			                  </tbody>
			                </table>

 <style>
 .slNo
 {
 width:3%;
 }
 .name
 {
 width:18%;
 }
 .gate
 {
 width:10%;
 }
 .status
 {
 width:5%;
 }
 .code
 {
 width:10%;
 }
 .cost
 {
 width:5%;
 }
 .action
 {
 width:15%;
 }
  .last
 {
 width:11%;
 }
 .uline
 {
 text-decoration:underline;
 }
 </style>




			     
