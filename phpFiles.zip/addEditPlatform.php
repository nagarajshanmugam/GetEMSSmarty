<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.Platform.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";

	$objStaff		= new Staff();
	$objStaff -> GetCompanyName($objArray);
	$objStaff->RolesLists();
	$objPlatform		= new Platform();	
	
	if(isset($_POST['hdAction']) && !isset($_GET['Update'])){
		$objPlatform -> InsertPlatform($_POST);
	}
	if(isset($_GET['Update']) && isset($_GET['slNo']))
	{
		$objPlatform -> ListEditView($objArray);
	}
	if(isset($_GET['Update']) && isset($_GET['slNo']) && isset($_POST['hdAction']))
	{
		$objPlatform -> EditPlatform($_POST);
	}
	
	$objSmarty->assign('IncludeTpl', 'addEditPlatform.tpl');
	$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Platform Reg');
	$objSmarty->assign('robots','index,follow');
	$objSmarty->assign('key_word','');
	$objSmarty->assign('generator','');
	$objSmarty->assign('document-state','dynamic');
	$objSmarty->assign('address',$config['SiteGlobalPath']);
		
	/*Display page*/
	$objSmarty->assign('LeftTpl', 'left.tpl');
	$objSmarty->display('pagetemplate.tpl');

?>