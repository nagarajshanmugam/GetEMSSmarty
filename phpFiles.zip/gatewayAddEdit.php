<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.Gateway.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";
	
		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objStaff -> GetCompanyName($objArray);
		$objGateway		= new Gateway();
		$objGateway -> ListAlertGateway($_POST);
		$objGateway -> ListModelMas();
		if(isset($_POST['hdAction']) && !isset($_GET['Update']))
		{
			$objGateway -> InsertGateway($_POST);
		}
			$objGateway -> ListEditView($objArray);
		if(isset($_GET['Update']) && isset($_GET['gateway_id']))
		{
			$objGateway -> EditGateway($_POST);
		}
	
		$objSmarty->assign('IncludeTpl', 'gatewayAddEdit.tpl');
		$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Location Reg');
		$objSmarty->assign('robots','index,follow');
		$objSmarty->assign('key_word','');
		$objSmarty->assign('generator','');
		$objSmarty->assign('document-state','dynamic');
		$objSmarty->assign('address',$config['SiteGlobalPath']);		
		
		/*Display page*/
		$objSmarty->assign('LeftTpl', 'left.tpl');
		$objSmarty->display('pagetemplate.tpl');

?>