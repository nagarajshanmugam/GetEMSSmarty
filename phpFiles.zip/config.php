<?php 
/*   Global Variables   */
if(!defined('DS'))
define('DS',DIRECTORY_SEPARATOR);

if(!defined("_MAINSITEPATH_"))
define("_MAINSITEPATH_",dirname(__FILE__).DS);

//$config['SiteGlobalPath']		= "";
$config['SiteGlobalPath']		= "https://greatelephanttech.com/ems/";
$config['SiteLocalPath']		= _MAINSITEPATH_ ;
$config['SiteClassPath']		= $config['SiteLocalPath'].'includes'.DS.'classes'.DS;
$config['CompanyImageUpload']	= $config['SiteLocalPath'].'images'.DS.'CompanyLogo'.DS;
$config['CompanyImageSmallUpload']	= $config['SiteLocalPath'].'images'.DS.'CompanyLogoSmall'.DS;
$config['UserImageUpload']	= $config['SiteLocalPath'].'images'.DS.'UserImages'.DS;
$config['SiteLink']				= "<a href='".$config['SiteGlobalPath']."'>arkaautomaations.com</a>";
$config['SiteTitle']	  	= "Arka EMS";
$config['SiteMail']			= "aal@arkaautomaations.com";
$config['AdminMail']		= "aal@arkaautomaations.com";
$config['SiteName']			= "";
$config['DBPrefix']			= "arka_";

if(isset($_SESSION['COMPANY_ID']))
{
	$config['COMPANY_ID']=$_SESSION['COMPANY_ID'];
	$config['branch_id']=$_SESSION['branch_id'];
	$config['USER_GROUP']=$_SESSION['USER_GROUP'];
	$config['UserName']=$_SESSION['UserName'];
	$config['USER_GROUP']=$_SESSION['USER_GROUP'];
	$config['User_ID']=$_SESSION['User_ID'];
	$config['DESIGNATION']=$_SESSION['DESIGNATION'];
	$config['Mobile']=$_SESSION['Mobile'];
	$config['Email']=$_SESSION['Email'];
	$config['Phone']=$_SESSION['Phone'];
	$config['CDate']=$_SESSION['CDate'];
	$config['Department']=$_SESSION['Department'];
	$config['Area']=$_SESSION['Area'];
	$config['Extension']=$_SESSION['Extension'];			
}
if(isset($_COOKIE['COMPANY_ID']))
{
	$config['COMPANY_ID']=$_COOKIE['COMPANY_ID'];
	$config['branch_id']=$_COOKIE['branch_id'];
	$config['USER_GROUP']=$_COOKIE['USER_GROUP'];
	$config['UserName']=$_COOKIE['UserName'];
	$config['USER_GROUP']=$_COOKIE['USER_GROUP'];
	$config['User_ID']=$_COOKIE['User_ID'];
	$config['DESIGNATION']=$_COOKIE['DESIGNATION'];
	$config['Mobile']=$_COOKIE['Mobile'];
	$config['Email']=$_COOKIE['Email'];
	$config['Phone']=$_COOKIE['Phone'];
	$config['CDate']=$_COOKIE['CDate'];
	$config['Department']=$_COOKIE['Department'];
	$config['Area']=$_COOKIE['Area'];
	$config['Extension']=$_COOKIE['Extension'];	
}
//Local Database Variables   
/*
$config['DBHost']		= "localhost";
$config['DBUser']		= "root";
$config['DBPassword']	= "";
$config['DBName']		= "smart_ems";

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_DATABASE', 'smart_ems'); 
*/

//Local Database Variables   
 
$config['DBHost']		= "148.66.130.228";
$config['DBUser']		= "greatelephanttec_ems_user";
$config['DBPassword']	= "GetEms@2025";
$config['DBName']		= "greatelephanttec_ems"; 

define('DB_HOST', '148.66.130.228');
define('DB_USER', 'greatelephanttec_ems_user');
define('DB_PASSWORD', 'GetEms@2025');
define('DB_DATABASE', 'greatelephanttec_ems');




?>
