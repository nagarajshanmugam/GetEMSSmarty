<?php 

date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$currDateTime=date('d-m-Y H:i:s');

$list=array();
$month = $mon;
$year = $year;

for($d=1; $d<=31; $d++)
{
    $time=mktime(12, 0, 0, $month, $d, $year);          
    if (date('m', $time)==$month)       
        $list[]=date('d', $time);
}
/*echo "<pre>";
print_r($list);*/
$totalDays = (count($list));
/*echo $totalDays;
echo "</pre>";*/

/*for($d=0; $d<=$totalDays; $d++){
$i = 'A';
echo ++$i;
}


echo $mon."<br>". $year; exit;*/
/**
 * PHPExcel
 *
 * Copyright (C) 2006 - 2013 PHPExcel
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @category   PHPExcel
 * @package    PHPExcel
 * @copyright  Copyright (c) 2006 - 2013 PHPExcel (http://www.codeplex.com/PHPExcel)
 * @license    http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt	LGPL
 * @version    1.7.9, 2013-06-02
 */

/** Error reporting */
error_reporting(E_ALL);

/** Include PHPExcel */

require('includes/common.php');
require_once('./Connections/ARKAEMS.php');
require_once dirname(__FILE__) . '/Classes/PHPExcel.php';


// Create new PHPExcel object
//echo date('H:i:s') , " Create new PHPExcel object" , EOL;
$objPHPExcel = new PHPExcel();

// Set document properties
//echo date('H:i:s') , " Set document properties" , EOL;
$objPHPExcel->getProperties()->setCreator("Arka Automaations Ltd")
							 ->setLastModifiedBy("Arka Automaations Ltd")
							 ->setTitle("Office 2007 XLSX Test Document")
							 ->setSubject("Office 2007 XLSX Test Document")
							 ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
							 ->setKeywords("office 2007 openxml php")
							 ->setCategory("Test result file");



// Create a first sheet, representing sales data
//echo date('H:i:s') , " Add some data" , EOL;

// ********************************************Get Url Data ********************************************************
 //echo $macid;

$tbl = 'arka_';

mysql_select_db($database_arkaems, $arkaerp);

$objPHPExcel->setActiveSheetIndex(0);
$objPHPExcel->getActiveSheet()->mergeCells('A3:AH3');
$objPHPExcel->getActiveSheet()->setCellValue('A3', $fMonth.' - Daily Report  - '. $_SESSION['CompanyName'].' -  '.$currDateTime );
$objPHPExcel->getActiveSheet()->getStyle('A3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFont()->setSize(18);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFill()->getStartColor()->setARGB('FF1E90FF');

/*$objPHPExcel->getActiveSheet()->setCellValue('A1', ' From Date:');
$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('B1', date('d-M-Y', strtotime($_GET['fromDate'])));
$objPHPExcel->getActiveSheet()->getStyle('B1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('E1', 'To Date :');
$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('E1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('F1', date('d-M-Y', strtotime($_GET['toDate'])));
$objPHPExcel->getActiveSheet()->getStyle('F1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setSize(12);*/
$objPHPExcel->getActiveSheet()->mergeCells('A4:E4');
$objPHPExcel->getActiveSheet()->setCellValue('A4', '');
$objPHPExcel->getActiveSheet()->getStyle('A4')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A4')->getFont()->setSize(16);
//$objPHPExcel->getActiveSheet()->mergeCells('H4:Z4');
$objPHPExcel->getActiveSheet()->setCellValue('H4', '');
$objPHPExcel->getActiveSheet()->getStyle('H4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('H4')->getFont()->setSize(16);

$objPHPExcel->getActiveSheet()->setCellValue('C4', '');
$objPHPExcel->getActiveSheet()->getStyle('C4')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('C4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('C4')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('D4', '');
$objPHPExcel->getActiveSheet()->getStyle('D4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D4')->getFont()->setSize(12);
/*
$objPHPExcel->getActiveSheet()->setCellValue('E4', 'Gateway Name :');
$objPHPExcel->getActiveSheet()->getStyle('E4')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('E4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('E4')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('F4', $row['groupName']);
$objPHPExcel->getActiveSheet()->getStyle('F4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('F4')->getFont()->setSize(12);*/


/*for($d=0; $d<=$totalDays; $d++){
$x = 'A';
$x++;
echo $x; 

}*/
$SelQry = 'SELECT DAY(LAST_DAY("'.$year.'-'.$month.'-01")) AS last';  
$SenMas = mysql_query($SelQry, $arkaerp) or die(mysql_error());
$row = mysql_fetch_assoc($SenMas);
$dayCount=$row["last"];
//print_r($row);
//echo $row["last"];

		$objPHPExcel->getActiveSheet()->setCellValue('A5', '#');
		$objPHPExcel->getActiveSheet()->setCellValue('B5', 'Energy Meter Name');

$x = 'C';
for($i=1;$i<=$row["last"]; $i++){
//echo "hai"; exit;
	 $SelQry2 = 'SELECT DATE_FORMAT("'.$year.'-'.$month.'-'.$i.'","%a") AS DAYN';  
	$SenMas2 = mysql_query($SelQry2, $arkaerp) or die(mysql_error());
	$row2 = mysql_fetch_assoc($SenMas2);

		$objPHPExcel->getActiveSheet()->setCellValue($x.'5', $i." -".$row2["DAYN"]);
	
	$x++;
$x=$x;


}
$objPHPExcel->getActiveSheet()->setCellValue('AH5', 'Sensor Wise Total KWH');


if($_GET['companyId'] <> '')
{
$comId = $_GET['companyId'];
}	
else
{
$comId = $_SESSION['CustomerId'];
}
if($_GET['branchName'] <> '')
{
$branchId = $_GET['branchName'];
}	
else
{
$branchId = $_SESSION['branch_id'];
}

 $SelQuerySen = 'SELECT  * FROM arka_sensor_master WHERE branch_id="'.$_GET['branchId'].'" AND company_id="'.$_GET['companyId'].'" ORDER BY slNo';  
$SenMas = mysql_query($SelQuerySen, $arkaerp) or die(mysql_error());
//echo(mysql_num_rows($SenMas));

//echo $row1['sensorCode'];

 
//$repName1 = mysql_num_rows($repName);
//echo $repName1; exit;
//$row = mysql_fetch_assoc($repName);

	/*$recset = mysql_query($SelQuery, $arkaerp) or die(mysql_error());
$loop =6;$i=1;*/
$loop =6;$i=1;
$sensorLoop=$loop;
				

 
/*$objPHPExcel->getActiveSheet()->setCellValue('A' . $loop, $i);
$objPHPExcel->getActiveSheet()->setCellValue('B6', 'SENS1');
$objPHPExcel->getActiveSheet()->setCellValue('B7', 'SENS2');
$objPHPExcel->getActiveSheet()->setCellValue('B8', 'SENS3');
*/								$c_val_tot=0.00;
								$d_val_tot=0.00;
								$e_val_tot=0.00;
								$f_val_tot=0.00;
								$g_val_tot=0.00;
								$h_val_tot=0.00;
								$i_val_tot=0.00;
								$j_val_tot=0.00;
								$k_val_tot=0.00;
								$l_val_tot=0.00;
								$m_val_tot=0.00;
								$n_val_tot=0.00;
								$o_val_tot=0.00;
								$p_val_tot=0.00;
								$q_val_tot=0.00;
								$r_val_tot=0.00;
								$s_val_tot=0.00;
								$t_val_tot=0.00;
								$u_val_tot=0.00;
								$v_val_tot=0.00;
								$w_val_tot=0.00;
								$x_val_tot=0.00;
								$y_val_tot=0.00;
								$z_val_tot=0.00;
								$aa_val_tot=0.00;
								$ab_val_tot=0.00;
								$ac_val_tot=0.00;
								$ad_val_tot=0.00;
								$ae_val_tot=0.00;
								$af_val_tot=0.00;
								$ag_val_tot=0.00;
								$totalRow_tot=0.00;
							while($row1 = mysql_fetch_assoc($SenMas)){
								//	echo $sensorLoop;	exit;	
								 $SelQuery = 'SELECT `cron_daily_energy_data`.*,DAY(`cron_daily_energy_data`.recorded_date) AS DayNumber FROM  `cron_daily_energy_data` WHERE sensor_code="'.$row1["sensorCode"].'" AND MONTH(recorded_date)="'.$month.'" AND YEAR(recorded_date)="'.$year.'" AND feeder_type!=""  ';  
$repName = mysql_query($SelQuery, $arkaerp) or die(mysql_error());
								
								$objPHPExcel->getActiveSheet()->setCellValue('A' . $loop, $i);
								$objPHPExcel->getActiveSheet()->setCellValue('B' . $sensorLoop , $row1['sensorName']);
								$sensorLoop=intval($sensorLoop)+1;
								$c_val=0.00;
								$d_val=0.00;
								$e_val=0.00;
								$f_val=0.00;
								$g_val=0.00;
								$h_val=0.00;
								$i_val=0.00;
								$j_val=0.00;
								$k_val=0.00;
								$l_val=0.00;
								$m_val=0.00;
								$n_val=0.00;
								$o_val=0.00;
								$p_val=0.00;
								$q_val=0.00;
								$r_val=0.00;
								$s_val=0.00;
								$t_val=0.00;
								$u_val=0.00;
								$v_val=0.00;
								$w_val=0.00;
								$x_val=0.00;
								$y_val=0.00;
								$z_val=0.00;
								$aa_val=0.00;
								$ab_val=0.00;
								$ac_val=0.00;
								$ad_val=0.00;
								$ae_val=0.00;
								$af_val=0.00;
								$ag_val=0.00;
								$totalRow=0.00;
								while($row = mysql_fetch_array($repName)) {
								if($row1['sensorCode']==$row['sensor_code']){
									if($row['DayNumber']=='1' ){
										$c_val=$row['consuption_kwh'];
										$c_val_tot=$c_val_tot+$c_val;
									}
									if($row['DayNumber']=='2' ){
										$d_val=$row['consuption_kwh'];
										$d_val_tot=$d_val_tot+$d_val;
									}
									if($row['DayNumber']=='3' ){
										$e_val=$row['consuption_kwh'];
										$e_val_tot=$e_val_tot+$e_val;
									}
									if($row['DayNumber']=='4' ){
										$f_val=$row['consuption_kwh'];
										$f_val_tot=$f_val_tot+$f_val;
									}
									if($row['DayNumber']=='5' ){
										$g_val=$row['consuption_kwh'];
										$g_val_tot=$g_val_tot+$g_val;
									}
									if($row['DayNumber']=='6' ){
										$h_val=$row['consuption_kwh'];
										$g_val_tot=$g_val_tot+$g_val;
									}
									if($row['DayNumber']=='7' ){
										$i_val=$row['consuption_kwh'];
										$i_val_tot=$i_val_tot+$i_val;
									}
									if($row['DayNumber']=='8' ){
										$j_val=$row['consuption_kwh'];
										$j_val_tot=$j_val_tot+$j_val;
									}
									if($row['DayNumber']=='9' ){
										$k_val=$row['consuption_kwh'];
										$k_val_tot=$k_val_tot+$k_val;
									}
									if($row['DayNumber']=='10' ){
										$l_val=$row['consuption_kwh'];
										$l_val_tot=$l_val_tot+$l_val;
									}
									if($row['DayNumber']=='11' ){
										$m_val=$row['consuption_kwh'];
										$m_val_tot=$m_val_tot+$m_val;
									}
									if($row['DayNumber']=='12' ){
										$n_val=$row['consuption_kwh'];
										$n_val_tot=$n_val_tot+$n_val;
									}
									if($row['DayNumber']=='13' ){
										$o_val=$row['consuption_kwh'];
										$o_val_tot=$o_val_tot+$o_val;
									}
									if($row['DayNumber']=='14' ){
										$p_val=$row['consuption_kwh'];
										$p_val_tot=$p_val_tot+$p_val;
									}
									if($row['DayNumber']=='15' ){
										$q_val=$row['consuption_kwh'];
										$q_val_tot=$q_val_tot+$q_val;
									}
									if($row['DayNumber']=='16' ){
										$r_val=$row['consuption_kwh'];
										$r_val_tot=$r_val_tot+$r_val;
									}
									if($row['DayNumber']=='17' ){
										$s_val=$row['consuption_kwh'];
										$s_val_tot=$s_val_tot+$s_val;
									}
									if($row['DayNumber']=='18' ){
										$t_val=$row['consuption_kwh'];
										$t_val_tot=$t_val_tot+$t_val;
									}
									if($row['DayNumber']=='19' ){
										$u_val=$row['consuption_kwh'];
										$u_val_tot=$u_val_tot+$u_val;
									}
									if($row['DayNumber']=='20' ){
										$v_val=$row['consuption_kwh'];
										$v_val_tot=$v_val_tot+$v_val;
									}
									if($row['DayNumber']=='21' ){
										$w_val=$row['consuption_kwh'];
										$w_val_tot=$w_val_tot+$w_val;
									}
									if($row['DayNumber']=='22' ){
										$x_val=$row['consuption_kwh'];
										$x_val_tot=$x_val_tot+$x_val;
									}
									if($row['DayNumber']=='23' ){
										$y_val=$row['consuption_kwh'];
										$y_val_tot=$y_val_tot+$y_val;
									}
									if($row['DayNumber']=='24' ){
										$z_val=$row['consuption_kwh'];
										$z_val_tot=$z_val_tot+$z_val;
									}
									if($row['DayNumber']=='25' ){
										$aa_val=$row['consuption_kwh'];
										$aa_val_tot=$aa_val_tot+$aa_val;
									}
									if($row['DayNumber']=='26' ){
										$ab_val=$row['consuption_kwh'];
										$ab_val_tot=$ab_val_tot+$ab_val;
									}
									if($row['DayNumber']=='27' ){
										$ac_val=$row['consuption_kwh'];
										$ac_val_tot=$ac_val_tot+$ac_val;
									}
									if($row['DayNumber']=='28' && $dayCount<='28'){
										$ad_val=$row['consuption_kwh'];
										$ad_val_tot=$ad_val_tot+$ad_val;
									}
									if($row['DayNumber']=='29' && $dayCount<='29'){
										$ae_val=$row['consuption_kwh'];
										$ae_val_tot=$ae_val_tot+$ae_val;
									}
									if($row['DayNumber']=='30' && $dayCount<='30' ){
										$af_val=$row['consuption_kwh'];
										$af_val_tot=$af_val_tot+$af_val;
									}
									if($row['DayNumber']=='31' && $dayCount<='31'){
										$ag_val=$row['consuption_kwh'];
										$ag_val_tot=$ag_val_tot+$ag_val;
									}
									$totalRow=$totalRow+$row['consuption_kwh'];
									
								}
							}
								$totalRow_tot=$totalRow_tot+$totalRow;
								
								$objPHPExcel->getActiveSheet()->setCellValue('C' . $loop, $c_val);
								$objPHPExcel->getActiveSheet()->setCellValue('D' . $loop, $d_val);
								$objPHPExcel->getActiveSheet()->setCellValue('E' . $loop, $e_val);
								$objPHPExcel->getActiveSheet()->setCellValue('F' . $loop, $f_val);
								$objPHPExcel->getActiveSheet()->setCellValue('G' . $loop, $g_val);
								$objPHPExcel->getActiveSheet()->setCellValue('H' . $loop, $h_val);
								$objPHPExcel->getActiveSheet()->setCellValue('I' . $loop, $i_val);
								$objPHPExcel->getActiveSheet()->setCellValue('J' . $loop, $j_val);
								$objPHPExcel->getActiveSheet()->setCellValue('K' . $loop, $k_val);
								$objPHPExcel->getActiveSheet()->setCellValue('L' . $loop, $l_val);
								$objPHPExcel->getActiveSheet()->setCellValue('M' . $loop, $m_val);
								$objPHPExcel->getActiveSheet()->setCellValue('N' . $loop, $n_val);   
								$objPHPExcel->getActiveSheet()->setCellValue('O' . $loop, $o_val);
								$objPHPExcel->getActiveSheet()->setCellValue('P' . $loop, $p_val);
								$objPHPExcel->getActiveSheet()->setCellValue('Q' . $loop, $q_val);
								$objPHPExcel->getActiveSheet()->setCellValue('R' . $loop, $r_val);
								$objPHPExcel->getActiveSheet()->setCellValue('S' . $loop, $s_val);
								$objPHPExcel->getActiveSheet()->setCellValue('T' . $loop, $t_val);
								$objPHPExcel->getActiveSheet()->setCellValue('U' . $loop, $u_val);
								$objPHPExcel->getActiveSheet()->setCellValue('V' . $loop, $v_val);
								$objPHPExcel->getActiveSheet()->setCellValue('W' . $loop, $w_val);
								$objPHPExcel->getActiveSheet()->setCellValue('X' . $loop, $x_val);
								$objPHPExcel->getActiveSheet()->setCellValue('Y' . $loop, $y_val);
								$objPHPExcel->getActiveSheet()->setCellValue('Z' . $loop, $z_val);
								$objPHPExcel->getActiveSheet()->setCellValue('AA' . $loop, $aa_val);
								$objPHPExcel->getActiveSheet()->setCellValue('AB' . $loop, $ab_val);
								$objPHPExcel->getActiveSheet()->setCellValue('AC' . $loop, $ac_val);
								if($dayCount>="28"){
								$objPHPExcel->getActiveSheet()->setCellValue('AD' . $loop, $ad_val);
								}
								if($dayCount>="29"){
								$objPHPExcel->getActiveSheet()->setCellValue('AE' . $loop, $ae_val);
								}
								if($dayCount>="30"){
								$objPHPExcel->getActiveSheet()->setCellValue('AF' . $loop, $af_val);
								}
								if($dayCount=="31"){
								$objPHPExcel->getActiveSheet()->setCellValue('AG' . $loop, $ag_val);
								}
								
								
								$objPHPExcel->getActiveSheet()->setCellValue('AH' . $loop, $totalRow);

							$loop = $loop+1;
							$i=$i+1;
							
						}
						$loop=$loop+1;
						        $objPHPExcel->getActiveSheet()->setCellValue('B' . $loop, "Day Wise Total Kwh");
							    $objPHPExcel->getActiveSheet()->setCellValue('C' . $loop, $c_val_tot);
								$objPHPExcel->getActiveSheet()->setCellValue('D' . $loop, $d_val_tot);
								$objPHPExcel->getActiveSheet()->setCellValue('E' . $loop, $e_val_tot);
								$objPHPExcel->getActiveSheet()->setCellValue('F' . $loop, $f_val_tot);
								$objPHPExcel->getActiveSheet()->setCellValue('G' . $loop, $g_val_tot);
								$objPHPExcel->getActiveSheet()->setCellValue('H' . $loop, $h_val_tot);
								$objPHPExcel->getActiveSheet()->setCellValue('I' . $loop, $i_val_tot);
								$objPHPExcel->getActiveSheet()->setCellValue('J' . $loop, $j_val_tot);
								$objPHPExcel->getActiveSheet()->setCellValue('K' . $loop, $k_val_tot);
								$objPHPExcel->getActiveSheet()->setCellValue('L' . $loop, $l_val_tot);
								$objPHPExcel->getActiveSheet()->setCellValue('M' . $loop, $m_val_tot);
								$objPHPExcel->getActiveSheet()->setCellValue('N' . $loop, $n_val_tot);   
								$objPHPExcel->getActiveSheet()->setCellValue('O' . $loop, $o_val_tot);
								$objPHPExcel->getActiveSheet()->setCellValue('P' . $loop, $p_val_tot);
								$objPHPExcel->getActiveSheet()->setCellValue('Q' . $loop, $q_val_tot);
								$objPHPExcel->getActiveSheet()->setCellValue('R' . $loop, $r_val_tot);
								$objPHPExcel->getActiveSheet()->setCellValue('S' . $loop, $s_val_tot);
								$objPHPExcel->getActiveSheet()->setCellValue('T' . $loop, $t_val_tot);
								$objPHPExcel->getActiveSheet()->setCellValue('U' . $loop, $u_val_tot);
								$objPHPExcel->getActiveSheet()->setCellValue('V' . $loop, $v_val_tot);
								$objPHPExcel->getActiveSheet()->setCellValue('W' . $loop, $w_val_tot);
								$objPHPExcel->getActiveSheet()->setCellValue('X' . $loop, $x_val_tot);
								$objPHPExcel->getActiveSheet()->setCellValue('Y' . $loop, $y_val_tot);
								$objPHPExcel->getActiveSheet()->setCellValue('Z' . $loop, $z_val_tot);
								$objPHPExcel->getActiveSheet()->setCellValue('AA' . $loop, $aa_val_tot);
								$objPHPExcel->getActiveSheet()->setCellValue('AB' . $loop, $ab_val_tot);
								$objPHPExcel->getActiveSheet()->setCellValue('AC' . $loop, $ac_val_tot);

								if($dayCount>="28"){
								$objPHPExcel->getActiveSheet()->setCellValue('AD' . $loop, $ad_val_tot);
								}
								if($dayCount>="29"){
								$objPHPExcel->getActiveSheet()->setCellValue('AE' . $loop, $ae_val_tot);
								}
								if($dayCount>="30"){
								$objPHPExcel->getActiveSheet()->setCellValue('AF' . $loop, $af_val_tot);
								}
								if($dayCount>="31"){
								$objPHPExcel->getActiveSheet()->setCellValue('AG' . $loop, $ag_val_tot);;
								}
								
								$objPHPExcel->getActiveSheet()->setCellValue('AH' . $loop, $totalRow_tot);
						
							//$objPHPExcel->getActiveSheet()->setCellValue('B' . $sensorLoop, 'Total KWH');
							
							
						
			 /*	$objPHPExcel->getActiveSheet()->setCellValue('A' . $loop, '');
                $objPHPExcel->getActiveSheet()->setCellValue('B' . $loop, Total);
                $objPHPExcel->getActiveSheet()->getStyle('B' . $loop)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
                $objPHPExcel->getActiveSheet()->setCellValue('C' . $loop, round($startTKWH,2));
                $objPHPExcel->getActiveSheet()->setCellValue('D' . $loop, round($endTKWH,2));
                $objPHPExcel->getActiveSheet()->setCellValue('E' . $loop, round($conTKWH,2));
                $objPHPExcel->getActiveSheet()->setCellValue('F' . $loop, round($conTCOST,2));*/
			
					


$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('S')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('T')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('U')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('V')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('W')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('X')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('Y')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('Z')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('AA')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('AB')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('AC')->setAutoSize(true);
if($dayCount>="28"){
$objPHPExcel->getActiveSheet()->getColumnDimension('AD')->setAutoSize(true);
}
if($dayCount>="29"){
$objPHPExcel->getActiveSheet()->getColumnDimension('AE')->setAutoSize(true);
}
if($dayCount>="30"){
$objPHPExcel->getActiveSheet()->getColumnDimension('AF')->setAutoSize(true);
}
if($dayCount>="31"){
$objPHPExcel->getActiveSheet()->getColumnDimension('AG')->setAutoSize(true);
}

$objPHPExcel->getActiveSheet()->getColumnDimension('AH')->setAutoSize(true);

$objPHPExcel->getActiveSheet()->getStyle('G3')->getFont()->setSize(14);
$objPHPExcel->getActiveSheet()->getStyle('G3')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('B5')->getAlignment()->setShrinkToFit(true);

// Set thin black border outline around column
//echo date('H:i:s') , " Set thin black border outline around column" , EOL;
$styleThinBlackBorderOutline = array(
	'borders' => array(
		'outline' => array(
			'style' => PHPExcel_Style_Border::BORDER_THIN,
			'color' => array('argb' => 'FF000000'),
		),
	),
);
$objPHPExcel->getActiveSheet()->getStyle('A5:AH5'.$loop)->applyFromArray($styleThinBlackBorderOutline);


// Set thick brown border outline around "Total"
//echo date('H:i:s') , " Set thick brown border outline around Total" , EOL;
$styleThickBrownBorderOutline = array(
	'borders' => array(
		'outline' => array(
			'style' => PHPExcel_Style_Border::BORDER_THICK,
			'color' => array('argb' => 'FF993300'),
		),
	),
);
//$objPHPExcel->getActiveSheet()->getStyle('D13:E13')->applyFromArray($styleThickBrownBorderOutline);

// Set fills

//echo date('H:i:s') , " Set fills" , EOL;
$objPHPExcel->getActiveSheet()->getStyle('A5:AH5')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A5:AH5')->getFill()->getStartColor()->setARGB('FFFF8C00');
$objPHPExcel->getActiveSheet()->getStyle('A4:AH4')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A4:AH4')->getFill()->getStartColor()->setARGB('FF5F9EA0');
// Set style for header row using alternative method
//echo date('H:i:s') , " Set style for header row using alternative method" , EOL;

$objPHPExcel->getActiveSheet()->getStyle('A5')->applyFromArray(
		array(
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
			),
			'borders' => array(
				'left'     => array(
 					'style' => PHPExcel_Style_Border::BORDER_THIN
 				)
			)
		)
);

$objPHPExcel->getActiveSheet()->getStyle('B5')->applyFromArray(
		array(
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
			)
		)
);

$objPHPExcel->getActiveSheet()->getStyle('L5')->applyFromArray(
		array(
			'borders' => array(
				'right'     => array(
 					'style' => PHPExcel_Style_Border::BORDER_THIN
 				)
			)
		)
);

// Unprotect a cell
//echo date('H:i:s') , " Unprotect a cell" , EOL;
$objPHPExcel->getActiveSheet()->getStyle('B1')->getProtection()->setLocked(PHPExcel_Style_Protection::PROTECTION_UNPROTECTED);

// Add a hyperlink to the sheet
$loop =$loop+2;
//echo date('H:i:s') , " Add a hyperlink to the sheet" , EOL;
$objPHPExcel->getActiveSheet()->setCellValue('B' . $loop, '');
$objPHPExcel->getActiveSheet()->getCell('B'  . $loop)->getHyperlink()->setUrl('https://emslte.arkaautomaations.com');
$objPHPExcel->getActiveSheet()->getCell('B' . $loop)->getHyperlink()->setTooltip('Navigate to website');
$objPHPExcel->getActiveSheet()->getStyle('B' . $loop)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
$loop =$loop+1;
$objPHPExcel->getActiveSheet()->setCellValue('B'  . $loop, '');
//$objPHPExcel->getActiveSheet()->getCell('B' . $loop)->getHyperlink()->setUrl("sheet://'Terms and conditions'!A1");
//$objPHPExcel->getActiveSheet()->getCell('B'  . $loop)->getHyperlink()->setTooltip('Review terms and conditions');
$objPHPExcel->getActiveSheet()->getStyle('B' . $loop)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);


// Play around with inserting and removing rows and columns
//echo date('H:i:s') , " Play around with inserting and removing rows and columns" , EOL;
$objPHPExcel->getActiveSheet()->insertNewRowBefore(6, 10);
$objPHPExcel->getActiveSheet()->removeRow(6, 10);
$objPHPExcel->getActiveSheet()->insertNewColumnBefore('E', 5);
$objPHPExcel->getActiveSheet()->removeColumn('E', 5);

// Set header and footer. When no different headers for odd/even are used, odd header is assumed.
//echo date('H:i:s') , " Set header/footer" , EOL;
$objPHPExcel->getActiveSheet()->getHeaderFooter()->setOddHeader('&L&BInvoice&RPrinted on &D');
$objPHPExcel->getActiveSheet()->getHeaderFooter()->setOddFooter('&L&B' . $objPHPExcel->getProperties()->getTitle() . '&RPage &P of &N');

// Set page orientation and size
//echo date('H:i:s') , " Set page orientation and size" , EOL;
$objPHPExcel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
$objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);

// Rename first worksheet
//echo date('H:i:s') , " Rename first worksheet" , EOL;
$objPHPExcel->getActiveSheet()->setTitle('Daily Report');
