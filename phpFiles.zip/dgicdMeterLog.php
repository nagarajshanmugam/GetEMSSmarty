<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.Dashboard.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";	
	
		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objStaff->GetCompanyName();
		$objDashBoard	= new Dashboard();
		$objDashBoard->GetSegmentsList();
		$objDashBoard->GetDGIcdLog();
		
		$objSmarty->assign('IncludeTpl', 'dgicdMeterLog.tpl');
		$objSmarty->assign('getFromDate', $_POST['date1']);
		$objSmarty->assign('getToDate',$_POST['date2']);
		$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- ARKA RMS');
		$objSmarty->assign('robots','index,follow');
		$objSmarty->assign('key_word','');
		$objSmarty->assign('generator','');
		$objSmarty->assign('author','rsureshit@hotmail.com');
		$objSmarty->assign('document-state','dynamic');
		$objSmarty->assign('address',$config['SiteGlobalPath']); 
	
		$objSmarty->assign('IncludeJS', 
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/jquery/jquery.min.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/jquery-ui/jquery-ui.min.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/bootstrap/js/bootstrap.bundle.min.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/select2/js/select2.full.min.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/moment/moment.min.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/daterangepicker/daterangepicker.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/chart.js/Chart.min.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/sparklines/sparkline.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/jqvmap/jquery.vmap.min.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/jqvmap/maps/jquery.vmap.usa.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/jquery-knob/jquery.knob.min.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/datatables/jquery.dataTables.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/summernote/summernote-bs4.min.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/sweetalert2/sweetalert2.min.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/toastr/toastr.min.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'dist/js/adminlte.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'dist/js/pages/dashboard.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'dist/js/demo.js"></script>');
		
		
		$objSmarty->assign('IncludeCSS', 
		'<link rel="stylesheet" href="' . $config['SiteGlobalPath'] . 'plugins/fontawesome-free/css/all.min.css">'. "\n" .
		'<link rel="stylesheet" href="' . $config['SiteGlobalPath'] . 'dist/css/ionicons.min.css">'. "\n" .
		'<link rel="stylesheet" href="' . $config['SiteGlobalPath'] . 'plugins/select2/css/select2.min.css">'. "\n" .
		'<link rel="stylesheet" href="' . $config['SiteGlobalPath'] . 'plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">'. "\n" .
		'<link rel="stylesheet" href="' . $config['SiteGlobalPath'] . 'plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">'. "\n" .
		'<link rel="stylesheet" href="' . $config['SiteGlobalPath'] . 'plugins/icheck-bootstrap/icheck-bootstrap.min.css">'. "\n" .
		'<link rel="stylesheet" href="' . $config['SiteGlobalPath'] . 'plugins/datatables-bs4/css/dataTables.bootstrap4.css">'. "\n" .
		'<link rel="stylesheet" href="' . $config['SiteGlobalPath'] . 'plugins/jqvmap/jqvmap.min.css">'. "\n" .
		'<link rel="stylesheet" href="' . $config['SiteGlobalPath'] . 'dist/css/adminlte.min.css">'. "\n" .
		'<link rel="stylesheet" href="' . $config['SiteGlobalPath'] . 'plugins/overlayScrollbars/css/OverlayScrollbars.min.css">'. "\n" .
		'<link rel="stylesheet" href="' . $config['SiteGlobalPath'] . 'plugins/daterangepicker/daterangepicker.css">'. "\n" .
		'<link rel="stylesheet" href="' . $config['SiteGlobalPath'] . 'plugins/summernote/summernote-bs4.css">'. "\n" .
		'<link rel="stylesheet" href="' . $config['SiteGlobalPath'] . 'plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">'. "\n" .
		'<link rel="stylesheet" href="' . $config['SiteGlobalPath'] . 'plugins/toastr/toastr.min.css">'. "\n" .
		'<link href="' . $config['SiteGlobalPath'] . 'dist/css/fontsgoogleapis.css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">'. "\n" .
		'<link rel="stylesheet" href="' . $config['SiteGlobalPath'] . 'dist/css/styleems.css">');
		
		/*Display page*/
		$objSmarty->display('pagetemplate.tpl');
?>