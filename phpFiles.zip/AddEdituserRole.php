<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.UserRoles.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";	
	
		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objStaff -> GetCompanyName($objArray);
		$objUserRoles	= new UserRoles();
		$objUserRoles->ParentMenuList();
		if(isset($_POST['hdAction']) && !isset($_GET['Update']))
		{
			$objUserRoles->InsertUserRole($_POST);
		}
		if(isset($_GET['Update']) && isset($_GET['roleId']) && isset($_POST['hdAction']))
		{
			$objUserRoles->EditUserRole($_POST);
		}
		if(isset($_GET['roleId']))
		{
			$objUserRoles->RoleDetailview($_GET['roleId']);
		}
		if(isset($_GET['success_msg_for_insert']))
		{
			$objSmarty->assign('ErrorMessage', 'New Record Created Successfully');
		} 
		if(isset($_GET['success_msg_for_update']))
		{
			$objSmarty->assign('ErrorMessage', 'Record Updated Successfully');
		} 
	
		$objSmarty->assign('IncludeTpl', 'AddEdituserRole.tpl');
		$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- ARKA RMS');
		$objSmarty->assign('robots','index,follow');
		$objSmarty->assign('key_word','');
		$objSmarty->assign('generator','');
		$objSmarty->assign('author','rsureshit@hotmail.com');
		$objSmarty->assign('document-state','dynamic');
		$objSmarty->assign('address',$config['SiteGlobalPath']); 
		
		/*Display page*/
		$objSmarty->assign('LeftTpl', 'left.tpl');
		$objSmarty->display('pagetemplate.tpl');
?>