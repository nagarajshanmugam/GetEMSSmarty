<?php
		require('includes/common.php');
		include_once $config['SiteClassPath']."class.Staff.php";
		include_once $config['SiteClassPath']."class.User.php";
		include_once $config['SiteClassPath']."class.split_page_results.php";	
		
		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objUser	= new User();
		$objUser->ListUserGroup($objArray);
		$objUser -> GetCompanyName($objArray);
		
		if(isset($_GET['Update']) && isset($_GET['userId']))
		{
		   $objUser->UserEditView($_GET['userId']);
		}
		if(isset($_GET['Update']) && isset($_GET['userId']) && isset($_POST['hdAction']))
		{
		   $objUser ->EditUser($_POST,$_FILES);
		}
		if(isset($_GET['success_msg_for_insert']))
		{
		   $objSmarty->assign('ErrorMessage', 'New Record Created Successfully');
		} 
		if(isset($_GET['success_msg_for_update']))
		{
		   $objSmarty->assign('ErrorMessage', 'Record Updated Successfully');
		} 
		
		
		$objSmarty->assign('IncludeTpl', 'AddEdituser.tpl');
		$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- ARKA RMS');
		$objSmarty->assign('robots','index,follow');
		$objSmarty->assign('key_word','');
		$objSmarty->assign('generator','');
		$objSmarty->assign('author','rsureshit@hotmail.com');
		$objSmarty->assign('document-state','dynamic');
		$objSmarty->assign('address',$config['SiteGlobalPath']); 
		$objSmarty->assign('LeftTpl', 'left.tpl');
		$objSmarty->display('pagetemplate.tpl');
?>