<?php
ini_set('memory_limit', '1024M');
ini_set('max_execution_time', 0); // Set to 0 to remove the execution time limit

$hostname_arkaems = "localhost";
$database_arkaems = "univa_ems";
$username_arkaems = "root";
$password_arkaems = "";

$arkaerp = new mysqli($hostname_arkaems, $username_arkaems, $password_arkaems, $database_arkaems);
if ($arkaerp->connect_error) {
    die("Connection failed: " . $arkaerp->connect_error);
}

$limit = 1500; // Number of rows to fetch per batch
$offset = 0;

do {
    $energySensorSel = "SELECT * FROM energy_data_master LIMIT $limit OFFSET $offset";
    $result = $arkaerp->query($energySensorSel);

    if ($result && $result->num_rows > 0) {
        while ($energyData = $result->fetch_assoc()) {
            $sensorCode = $energyData['sensor_code'];
            $sensorCodeTable = str_replace("-", "_", $sensorCode);

            // Check if table exists
            $selTableQry = "SELECT TABLE_NAME AS sensorTable FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = ? AND TABLE_SCHEMA = ?";
            $stmt = $arkaerp->prepare($selTableQry);
            $stmt->bind_param('ss', $sensorCodeTable, $database_arkaems);
            $stmt->execute();
            $collections = $stmt->get_result();
            $collectionExists = $collections->num_rows > 0;
            $stmt->close();

            if (!$collectionExists) {
                // Fetch specific sensor data
                $specificSensorSql = "SELECT sensorCode, sensorModel FROM arka_sensor_master WHERE sensorCode = ? AND status = '1'";
                $stmt = $arkaerp->prepare($specificSensorSql);
                $stmt->bind_param('s', $sensorCode);
                $stmt->execute();
                $specificSensorData1 = $stmt->get_result();
                $specificSensorData = $specificSensorData1->fetch_assoc();
                $specificSensorDataCount = $specificSensorData1->num_rows;
                $stmt->close();

                if ($specificSensorDataCount > 0) {
                    $modelId = $specificSensorData['sensorModel'];
                    $senModelQuery = "SELECT sl_no FROM sensor_model_master WHERE model_id = ? AND status = '1'";
                    $stmt = $arkaerp->prepare($senModelQuery);
                    $stmt->bind_param('s', $modelId);
                    $stmt->execute();
                    $senModelQueryData1 = $stmt->get_result();
                    $senModelQueryData = $senModelQueryData1->fetch_assoc();
                    $senModelId = $senModelQueryData['sl_no'];
                    $stmt->close();

                    $senModelParamQuery = "SELECT * FROM sensor_model_parameter_master WHERE sensor_model_id = ? AND status = '1' ORDER BY priority";
                    $stmt = $arkaerp->prepare($senModelParamQuery);
                    $stmt->bind_param('i', $senModelId);
                    $stmt->execute();
                    $senModelParamQueryData = $stmt->get_result();
                    $tableField = '';
                    while ($senModelParam = $senModelParamQueryData->fetch_assoc()) {
                        $param = $senModelParam["parameter_name"];
                        $datat = $senModelParam["data_type"];
                        $datal = $senModelParam["data_length"];
                        if ($datal == '') {
                            $tableField .= "$param $datat,";
                        } else {
                            $tableField .= "$param $datat($datal),";
                        }
                    }
                    $stmt->close();

                    $tableField = rtrim($tableField, ',');

                    $specificSensorCode = str_replace("-", "_", $specificSensorData["sensorCode"]);
                    $new_table = $specificSensorCode;
                    $insertNewTableSql = "CREATE TABLE $new_table (
                        slNo INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                        company_id int(6) NOT NULL,
                        branch_id int(6) NOT NULL,
                        gateway_code varchar(155) NOT NULL,
                        sensor_code varchar(155) NOT NULL,
                        sensor_name varchar(155) NOT NULL,
                        sensor_model varchar(155) NOT NULL,
                        feeder_type varchar(155) NOT NULL,
                        unit_rate float(11,2) NOT NULL,
                        $tableField,
                        linux_date_time varchar(55) NOT NULL,
                        teltonika_date_time varchar(55) NOT NULL,
                        recorded_date_time DATETIME,
                        M_TIMESTAMP TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                        is_active int(6) DEFAULT 1 NOT NULL,
                        status int(6) DEFAULT 1 NOT NULL
                    )";

                    if ($arkaerp->query($insertNewTableSql) === TRUE) {
                        echo "$new_table created successfully";
                    } else {
                        echo "Error creating table: " . $arkaerp->error;
                    }
                }
            }

            // Insert data into the new table
            $insertQuery = "INSERT INTO $sensorCodeTable (
                gateway_code, sensor_code, sensor_model, R_VOLTAGE, Y_VOLTAGE, B_VOLTAGE, RY_VOLTAGE, YB_VOLTAGE, BR_VOLTAGE,
                R_CURRENT, Y_CURRENT, B_CURRENT, SUM_KVA, SUM_KW, SUM_KVAR, SUM_PF, FREQUENCY, KWH_MSB, KWH_LSB, KWH, KVAH,
                linux_date_time, teltonika_date_time, recorded_date_time, is_active, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 1)";
            $stmt = $arkaerp->prepare($insertQuery);
            $stmt->bind_param('ssssssssssssssssssssssss',
                $energyData['gateway_code'], $energyData['sensor_code'], $energyData['sensor_model'],
                $energyData['R_VOLTAGE'], $energyData['Y_VOLTAGE'], $energyData['B_VOLTAGE'], $energyData['RY_VOLTAGE'], $energyData['YB_VOLTAGE'], $energyData['BR_VOLTAGE'],
                $energyData['R_CURRENT'], $energyData['Y_CURRENT'], $energyData['B_CURRENT'], $energyData['SUM_KVA'], $energyData['SUM_KW'], $energyData['SUM_KVAR'], $energyData['SUM_PF'],
                $energyData['FREQUENCY'], $energyData['KWH_MSB'], $energyData['KWH_LSB'], $energyData['KWH'], $energyData['KVAH'],
                $energyData['linux_date_time'], $energyData['teltonika_date_time'], $energyData['recorded_date_time']
            );
            if ($stmt->execute() === FALSE) {
                echo "Error inserting data: " . $stmt->error;
            }
            $stmt->close();
        }
        $offset += $limit; // Move to the next batch
    } else {
        break; // Exit loop if no more records
    }
} while (true);

$arkaerp->close();
?>
