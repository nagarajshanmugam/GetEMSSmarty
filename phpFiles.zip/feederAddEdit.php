<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.SensorMaster.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";
	
		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objStaff -> GetCompanyName($objArray);
		$objSensorMaster	= new SensorMaster();
		$objSensorMaster -> ListFeeder($objArray);
		$objSensorMaster -> ListEditView($objArray);
		$objSensorMaster -> ListCompany($objArray);
		$objSensorMaster -> ListSensorModel();
		$objSensorMaster -> ListPlatform();
		$objSensorMaster -> GetGatewayName($objArray);
		$objSensorMaster -> ListSensorModelPlatform();
		
		
	/*	if(isset($_POST['hdAction']) && !isset($_GET['Update']))
		{
			$objSensorMaster -> InsertFeederForm($_POST);
		}*/
		if(isset($_GET['Update']) && isset($_GET['sl_no'])){
			$objSensorMaster -> EditViewFeederForm($_GET['sl_no']);
		}
		if(isset($_GET['Update']) && isset($_POST['hdAction'])){		
			$objSensorMaster -> EditFeederForm($_POST);
		}
	
		$objSmarty->assign('IncludeTpl', 'feederAddEdit.tpl');
		$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'-Feeder Edit');
		$objSmarty->assign('robots','index,follow');
		$objSmarty->assign('key_word','');
		$objSmarty->assign('generator','');
		$objSmarty->assign('document-state','dynamic');
		$objSmarty->assign('address',$config['SiteGlobalPath']);
		
		/*Display page*/
		//$objSmarty->assign('HeaderTpl', 'header.tpl');
		$objSmarty->assign('LeftTpl', 'left.tpl');
		//$objSmarty->assign('FooterTpl', 'footer.tpl');  
		$objSmarty->display('pagetemplate.tpl');

?>