<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.Production.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";	
	
		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objStaff -> GetCompanyName($objArray);
		$objProduction	= new Production();
		$objProduction->ListSensor($objArray);
		
		if(isset($_GET['sensorCode']))
		{
		
			$objProduction->productionDate($_GET['sensorCode']);
		}
		if(isset($_GET['sensorCode']) && isset($_GET['prodDate']))
		{
			$objProduction->productionShift($_GET['sensorCode'],$_GET['prodDate']);
		}
		
		if(isset($_POST['hdAction']) && !isset($_GET['Update']))
		{
			$objProduction->productionForm($_POST);
		}
		
		if(isset($_GET['success_msg_for_insert']))
		{
			$objSmarty->assign('SuccessMessage', 'Production Updated Successfully');
		} 
		
		$objSmarty->assign('IncludeTpl', 'AddEditProduction.tpl');
		$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'-');
		$objSmarty->assign('robots','index,follow');
		$objSmarty->assign('key_word','');
		$objSmarty->assign('generator','');
		$objSmarty->assign('author','aal@arkaautomaations.com');
		$objSmarty->assign('document-state','dynamic');
		$objSmarty->assign('address',$config['SiteGlobalPath']); 
		
		/*Display page*/
		$objSmarty->assign('LeftTpl', 'left.tpl');
		$objSmarty->display('pagetemplate.tpl');
?>