<?php 
include('config.php');
$hostname_arkaerp = $config['DBHost'];
$database_arkaerp = $config['DBName'];
$username_arkaerp = $config['DBUser'];
$password_arkaerp = $config['DBPassword'];
$arkaerp = mysqli_connect($hostname_arkaerp, $username_arkaerp, $password_arkaerp,$database_arkaerp) or trigger_error(mysqli_error(),E_USER_ERROR);
mysqli_select_db($arkaerp, $database_arkaerp);
$branchid = 0;

if(isset($_POST['branch']))
{
$branchid = mysqli_real_escape_string($arkaerp,$_POST['branch']); // department id
}

$users_arr = array();

if($branchid > 0){

 $sensorSel = "SELECT arka_sensor_master.slNo,arka_sensor_master.sensorName,arka_sensor_master.sensorCode FROM arka_sensor_master,alert_log_master WHERE arka_sensor_master.status='1' AND arka_sensor_master.segmentName='Energy Meter' AND  alert_log_master.sensor_code=arka_sensor_master.sensorCode AND arka_sensor_master.isActive='1' AND arka_sensor_master.branch_id='".$branchid."'";//echo $sensorSel;
$sensorList = mysqli_query($arkaerp, $sensorSel);

   while( $row = mysqli_fetch_array($sensorList) ){
      $slNo = $row['slNo'];
      $sensorName = $row['sensorName'];
      $sensorCode = $row['sensorCode'];
      $users_arr[] = array("id" => $sensorCode, "name" => $sensorName);
   }
}
// encoding array to json format
echo json_encode($users_arr);