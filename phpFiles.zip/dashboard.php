<?php

require('includes/common.php');

include_once $config['SiteClassPath']."class.Staff.php";
include_once $config['SiteClassPath']."class.Dashboard.php";
include_once $config['SiteClassPath']."class.split_page_results.php";	

$objStaff		= new Staff();
$objStaff->RolesLists();

$objStaff->GetCompanyName();
$objDashBoard	= new Dashboard();
$objDashBoard->DashOverallData();
$objDashBoard->DashMultiBarChart();
$objDashBoard->DashCurrMonthDailygraph(); // this function for Current Month  cost bar chart
$objDashBoard->DashMultilinegraph(); // this function for cost bar chart
$objDashBoard->DashListDashboardEM();
$objDashBoard->DashListGateway();



$objDashBoard->GetDashboardDetails();
$objDashBoard->listGateway();
$objDashBoard->GetCostKwhAll();
//$objDashBoard->GetCostKwhAll();
$objDashBoard->ListDashboardTest();
$objDashBoard->GetSegmentsList();
$objDashBoard->currMonthDailygraph(); // this function for Current Month  cost bar chart
$objDashBoard->Multilinegraph(); // this function for cost bar chart
$objDashBoard->MultiBarChart();
$objDashBoard->IncidentLog();
//$objDashBoard->energyMetersCount();
$objDashBoard->specificEnergyMetersCount();
$dateSec = strtotime('-120 seconds');
$dateSec1 = strtotime('-120 seconds');
$objSmarty->assign('dateSec', strtotime('-120 Seconds'));
$objSmarty->assign('dateSec1', strtotime('-120 Seconds'));
//echo "Date Sec: ".$dateSec."<br>";
//echo "Date Time: ".date('Y-m-d H:i:s', $dateSec);
//exit;
$objSmarty->assign('IncludeTpl', 'dashboard.tpl');
$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Condition Monitoring Systems');
$objSmarty->assign('robots','index,follow');
$objSmarty->assign('key_word','');
$objSmarty->assign('generator','');
$objSmarty->assign('author','aal@arkaautomaations.com');
$objSmarty->assign('document-state','dynamic');
$objSmarty->assign('address',$config['SiteGlobalPath']); 
$objSmarty->assign('LeftTpl', 'left.tpl');
$objSmarty->display('pagetemplate.tpl');
?>