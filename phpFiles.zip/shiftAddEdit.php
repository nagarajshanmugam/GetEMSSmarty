<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.ShiftMaster.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";
	
		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objStaff -> GetCompanyName();
		$objShiftMaster		= new ShiftMaster();
		$objShiftMaster -> GetBranchName($objArray);
		if(isset($_POST['hdAction']) && !isset($_GET['Update']))
		{
			$objShiftMaster -> InsertShiftmaster($_POST);
		}
			$objShiftMaster -> ListEditView($objArray);
		if(isset($_GET['Update']) && isset($_GET['shift_master_id'])){
			$objShiftMaster -> EditShiftmaster($_POST);
		}
		
		$objSmarty->assign('IncludeTpl', 'shiftAddEdit.tpl');
		$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Shift Reg');
		$objSmarty->assign('robots','index,follow');
		$objSmarty->assign('key_word','');
		$objSmarty->assign('generator','');
		$objSmarty->assign('document-state','dynamic');
		$objSmarty->assign('address',$config['SiteGlobalPath']);
		
		/*Display page*/
		$objSmarty->assign('LeftTpl', 'left.tpl');
		$objSmarty->display('pagetemplate.tpl');

?>