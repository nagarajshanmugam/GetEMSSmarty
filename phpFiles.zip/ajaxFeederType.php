<?php
   require('includes/common.php');
	//include_once $config['SiteClassPath']."class.Staff.php";
   	include_once $config['SiteClassPath']."class.SensorMaster.php";
	
	
    //include_once $config['SiteClassPath']."class.split_page_results.php";	
	
	//$objStaff		= new Staff();
	//$objStaff->RolesLists();
	
    $objSensorMaster	= new SensorMaster();
 
		
	if(isset($_POST['feedType']))
	{ 
	
        $objSensorMaster->ListFeederType($_POST['feedType'],$_POST['branchId']);		
	}
	
	

?>