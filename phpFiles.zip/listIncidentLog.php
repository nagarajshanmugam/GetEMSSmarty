<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.ReportsMgmt.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";
	
		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objStaff -> GetCompanyName();
		$objReportsMgmt = new ReportsMgmt();
	    /* command 01-06-2021
		$objReportsMgmt -> ListIncidentLog($objArray);
    	*/
		$objReportsMgmt -> SensorList($objArray);
		$objReportsMgmt -> BranchList($objArray);
		$objReportsMgmt -> GetGatewayName($objArray);
		$objSmarty->assign('sensorName', $_POST['sensorName']);
		$objSmarty->assign('yesterday', strtotime('-1 day'));
		$objReportsMgmt -> ListIncidentLog($_POST['sensorName']);
	
		if(isset($_GET['succs_msg_for_del']))
		{
			$objSmarty->assign('SuccessMessage', 'Record Deleted Successfully');
		}
		if(isset($_GET['success_msg_for_update']))
		{
			$objSmarty->assign('SuccessMessage', 'Record Updated Successfully');
		}
		if(isset($_GET['success_msg_for_insert']))
		{
			$objSmarty->assign('SuccessMessage', 'Record Created Successfully');
		}
	
	
	$objSmarty->assign('IncludeTpl', 'listIncidentLog.tpl');
	$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- List Incident Log');
	$objSmarty->assign('robots','index,follow');
	$objSmarty->assign('key_word','');
	$objSmarty->assign('generator','');
	//$objSmarty->assign('author','rsureshit@hotmail.com');
	$objSmarty->assign('document-state','dynamic');
	$objSmarty->assign('address',$config['SiteGlobalPath']);
	
	
	/*$objSmarty->assign('IncludeJS', 
	'<script src="' . $config['SiteGlobalPath'] . 'plugins/jquery/jquery.min.js"></script>'. "\n" .
	'<script src="' . $config['SiteGlobalPath'] . 'plugins/bootstrap/js/bootstrap.bundle.min.js"></script>'. "\n" .
	'<script src="' . $config['SiteGlobalPath'] . 'dist/js/adminlte.min.js"></script>'. "\n" .
	'<script src="' . $config['SiteGlobalPath'] . 'dist/js/demo.js"></script>'); 
	
	$objSmarty->assign('IncludeCSS', 
	'<link href="' . $config['SiteGlobalPath'] . 'plugins/fontawesome-free/css/all.min.css" rel="stylesheet">'. "\n" .
	'<link href="' . $config['SiteGlobalPath'] . 'dist/css/adminlte.min.css" rel="stylesheet">'. "\n" .
	'<link href="' . $config['SiteGlobalPath'] . '/dist/css/ionicons.min.css" rel="stylesheet">'. "\n" .
	'<link href="' . $config['SiteGlobalPath'] . '/dist/css/fontsgoogleapis.css" rel="stylesheet">'); */
	
	
	
	
	
	
	
	
	
	/*Display page*/
	//$objSmarty->assign('HeaderTpl', 'header.tpl');
	$objSmarty->assign('LeftTpl', 'left.tpl');
	//$objSmarty->assign('FooterTpl', 'footer.tpl');  
	$objSmarty->display('pagetemplate.tpl');

?>