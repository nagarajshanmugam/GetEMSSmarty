<?php
require('includes/common.php');
include_once $config['SiteClassPath']."class.Staff.php";
include_once $config['SiteClassPath']."class.Dashboard.php";
include_once $config['SiteClassPath']."class.split_page_results.php";	

$objStaff		= new Staff();
$objStaff->RolesLists();
$objStaff->GetCompanyName();
$objDashBoard	= new Dashboard();
/*$objDashBoard->GetDashboardDetails();
$objDashBoard->GetCostKwhAll();
$objDashBoard->ListDashboardTest();
$objDashBoard->GetSegmentsList();
$objDashBoard->Multilinegraph();
$objDashBoard->MultiBarChart();
$objDashBoard->IncidentLog();*/
$objSmarty->assign('dateSec', strtotime('-30 Seconds'));
$objSmarty->assign('dateSec1', strtotime('-120 Seconds'));
$objSmarty->assign('IncludeTpl', 'ac_acDashboard.tpl');
$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Condition Monitoring Systems');
$objSmarty->assign('robots','index,follow');
$objSmarty->assign('key_word','');
$objSmarty->assign('generator','');
$objSmarty->assign('author','rsureshit@hotmail.com');
$objSmarty->assign('document-state','dynamic');
$objSmarty->assign('address',$config['SiteGlobalPath']); 
$objSmarty->assign('LeftTpl', 'left.tpl');
$objSmarty->display('pagetemplate.tpl');
?>