<?php
   require('includes/common.php');

   	include_once $config['SiteClassPath']."class.LocationMaster.php";
	
    $objLocationMaster	= new LocationMaster();
 
		
	if(isset($_POST['postsensorVal'],$_POST['locMas']))
	{ 
	
        $objLocationMaster->AjaxLocationSensorCheck($_POST['postsensorVal'],$_POST['locMas']);		
	}
	
	

?>