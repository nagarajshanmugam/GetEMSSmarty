<?php
   require('includes/common.php');

   	include_once $config['SiteClassPath']."class.SensorMaster.php";
	
    $objSensorMaster	= new SensorMaster();
 
		
	if(isset($_POST['platform']))
	{ 
	
        $objSensorMaster->AjaxListSensorModel($_POST['platform']);		
	}
	
	

?>