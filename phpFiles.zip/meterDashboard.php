<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.Dashboard.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";	
	
		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objDashBoard	= new Dashboard();
		$objDashBoard->GetDashboardDetails();// this function for header bread crums data
		$objDashBoard->GetDashCostKwhSingle();
		$objDashBoard->GetSpecificFeederList();
		$objDashBoard->DashCurrMonthDailygraph(); // this function for Current Month  cost bar chart
		$objDashBoard->DashHourlyDatagraph(); // this function for Today Hourly data chart
		$objDashBoard->DashGetBarGraph();
		


		//$objDashBoard->GetFeederList();
		//$objDashBoard->GetCostKwhSingle();
		//$objDashBoard->GetBarGraph();
		//$objDashBoard->currMonthDailygraph(); // this function for Current Month  cost bar chart
		//$objDashBoard->hourlyDatagraph(); // this function for Today Hourly data chart
		$senMod =  explode("-",base64_decode($_GET['sensorCode'])); 
		//echo $senMod[0]; exit;
		
		
		if($senMod[0]=="TE"){
		$objSmarty->assign('IncludeTpl', 'meterDashboardT_entity.tpl');
		}
		else if($senMod[0]=="TEP"){
		//$objSmarty->assign('IncludeTpl', 'meterDashboard_expert_pro.tpl');
		$objSmarty->assign('IncludeTpl', 'meterDashboard.tpl');
		}else if($senMod[0]=="RGA20S"){
		$objSmarty->assign('IncludeTpl', 'powermeterDashboard.tpl');
		}else{
		$objSmarty->assign('IncludeTpl', 'meterDashboard.tpl');
		}
		$objSmarty->assign('dateSec', strtotime('-30 Seconds'));
		$objSmarty->assign('dateSec1', strtotime('-120 Seconds'));
		$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Dashboard');
		$objSmarty->assign('robots','index,follow');
		$objSmarty->assign('key_word','');
		$objSmarty->assign('generator','');
		$objSmarty->assign('author','rsureshit@hotmail.com');
		$objSmarty->assign('document-state','dynamic');
		$objSmarty->assign('address',$config['SiteGlobalPath']); 
	
		
		/*Display page*/
		$objSmarty->assign('LeftTpl', 'left.tpl');
		$objSmarty->display('pagetemplate.tpl');
?>