<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.Dashboard.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";	
	
		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objDashBoard	= new Dashboard();
		$objDashBoard->GetDashboardDetails();// this function for header bread crums data
		$objDashBoard->GetFeederList();
		$objDashBoard->GetCostKwhSingle();
		$objDashBoard->GetBarGraph();
		$senMod =  explode("-",base64_decode($_GET['sensorCode'])); 
		
	
		$objSmarty->assign('IncludeTpl', 'temperatureDashboard.tpl');
		
		$objSmarty->assign('dateSec', strtotime('-30 Seconds'));
		$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Dashboard');
		$objSmarty->assign('robots','index,follow');
		$objSmarty->assign('key_word','');
		$objSmarty->assign('generator','');
		$objSmarty->assign('author','rsureshit@hotmail.com');
		$objSmarty->assign('document-state','dynamic');
		$objSmarty->assign('address',$config['SiteGlobalPath']); 
	
		
		/*Display page*/
		$objSmarty->assign('LeftTpl', 'left.tpl');
		$objSmarty->display('pagetemplate.tpl');
?>