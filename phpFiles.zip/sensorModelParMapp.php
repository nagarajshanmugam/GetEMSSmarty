<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.SensorMaster.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";	
	
		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objStaff -> GetCompanyName($objArray);
		$objSensorMaster	= new SensorMaster();
		$objSensorMaster->GetPlatformList($objArray);
		$objSensorMaster->ParameterDetailView($objArray);
		
		if(isset($_POST["hdAction"]))
		{
			$objSensorMaster->InsertsensorModelMapping($_POST);
		}
		
		if(isset($_GET['success_msg_for_insert']))
		{
			$objSmarty->assign('SuccessMessage', 'New Record Created Successfully');
		} 
		
		if(isset($_GET['success_msg_for_update']))
		{
			$objSmarty->assign('ErrorMessage', 'Record Updated Successfully');
		} 
	
		$objSmarty->assign('IncludeTpl', 'sensorModelParMapp.tpl');
		$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- ARKA RMS');
		$objSmarty->assign('robots','index,follow');
		$objSmarty->assign('key_word','');
		$objSmarty->assign('generator','');
		$objSmarty->assign('author','rsureshit@hotmail.com');
		$objSmarty->assign('document-state','dynamic');
		$objSmarty->assign('address',$config['SiteGlobalPath']); 
		
		/*Display page*/
		$objSmarty->assign('LeftTpl', 'left.tpl');
		$objSmarty->display('pagetemplate.tpl');
?>