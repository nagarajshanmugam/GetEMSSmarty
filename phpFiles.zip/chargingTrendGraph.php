<?php 
	require_once('Connections/ARKAEMS.php');
	$gatewayCode ="TRB145-3";
	$sensorCode ="EVDC-1";
	date_default_timezone_set('Asia/Kolkata'); $currentTime = date( 'H:i', time () ); 
 ?>
	
	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>Untitled Document</title>
	</head>
	<script src="amcharts/amcharts.js"></script>
	<script src="amcharts/serial.js"></script>
	<script src="amcharts/themes/light.js"></script>
	<style type="text/css">
	#chartdiv {
	width	: 100%;
	height	: 500px;
	}
	</style>
	<link rel="stylesheet" type="text/css" href="css/datepickier_main.css">
	<link rel="stylesheet" href="./codebase/dhtmlxcalendar.css" type="text/css">
	<link rel="stylesheet" href="./codebase/dhtmlxcalendar_dhx_skyblue.css" type="text/css"> 
	<link rel="stylesheet" href="./codebase/skins/dhtmlxmessage_dhx_skyblue.css" type="text/css">
	<script> 
	$(function(date) {
	$( "#date" ).datepicker({
		altField: "#date",
		altFormat: "yy-mm-dd"
	});
	});
	</script> 
	<?php
	if(isset($_POST['date1']) && isset($_POST['date2']))
	{
		$date1 = $_POST['date1'];
		$date2 = $_POST['date2'];
		$yaxis_par ="amps_ch1";
		mysql_select_db($database_arkaems, $arkaerp);
		$query_rs1 =  "SELECT amps_ch1,recorded_date_time AS TM FROM ev_meter_data WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND (DATE(recorded_date_time) BETWEEN '".$date1."' AND '".$date2."') ORDER BY TM ASC";
		$rs1 = mysql_query($query_rs1, $arkaerp) or die(mysql_error());
		$totalRows_rs1 = mysql_num_rows($rs1);	
	
	}
	else
	{
		$yaxis_par ="amps_ch1";
		mysql_select_db($database_arkaems, $arkaerp);
		$query_rs1 = "SELECT amps_ch1,recorded_date_time AS TM FROM ev_meter_data WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND DATE(recorded_date_time) = DATE(CONVERT_TZ(NOW(),'+00:00' ,'+12:30')) ORDER BY TM ASC";
		$rs1 = mysql_query($query_rs1, $arkaerp) or die(mysql_error());
		$totalRows_rs1 = mysql_num_rows($rs1);
	}
		$splVar=array($yaxis_par);
		$arrData = array();
	while($row1=mysql_fetch_array($rs1))
	{
		$orgDate = $row1["TM"];  
		$GDate = date("d-M-Y h:i A", strtotime($orgDate));
		array_push($arrData, array(
		"amps_ch1" => $row1["amps_ch1"],
		"tm" => $GDate
		));
	}
		$ChartData = json_encode($arrData);
	?>
	<script type="text/javascript" src="./dhtmlxMessage/codebase/dhtmlxcalendar.js" ></script>
	<script type="text/javascript" src="./codebase/dhtmlxcalendar.js"></script>
	<script type="text/javascript" src="./codebase/dhtmlxcommon.js"></script>
	<script type="text/javascript">
	// dhtml Calendar
	function formvalidate()
	{
	var date1,date2;
		date1=document.getElementById("date1").value;
		date2=document.getElementById("date2").value;
	if(date1=="" || date2=="")
	{
		alert("Please Specify Date");
		return false;
	}
	}	
	</script>
	<script>
		var myCalendar;
	function doOnLoad() {
		var date1;
		date1=new Date();
		myCalendar = new dhtmlXCalendarObject(["date1"]);
		myCalendar = new dhtmlXCalendarObject(["date2"]);
	}	
	//calendar closed
	</script>
	<script>
	var disp = <?php echo $ChartData; ?>;
	var chart = AmCharts.makeChart("chartdiv", {
	"type": "serial",
	"theme": "light",
	"marginTop":0,
	"marginRight": 80,
	"dataProvider": disp,
	"valueAxes": [{
	"axisAlpha": 0,
	"position": "left"
	}],
	"graphs": [{
	"id":"g1",
	"balloonText": "TM :[[category]]<br><b><span style='font-size:14px;'> Amps  : [[value]]</span></b>",
	"bullet": "round",
	"bulletSize": 2,         
	"lineColor": "#d1655d",
	"lineThickness": 1,
	"negativeLineColor": "#637bb6",
	"type": "smoothedLine",
	"valueField": "amps_ch1"
	}],
	"chartCursor": {
	"categoryBalloonDateFormat": "YYYY  ",
	"cursorAlpha": 0,
	"valueLineEnabled":true,
	"valueLineBalloonEnabled":true,
	"valueLineAlpha":0.5,
	"labelRotation": 90,
	"fullWidth":true
	},
	"categoryField": "tm",
	"chartScrollbar": {
	"graph":"g1",
	"gridAlpha":0,
	"color":"#888888",
	"scrollbarHeight":55,
	"backgroundAlpha":0,
	"selectedBackgroundAlpha":0.1,
	"selectedBackgroundColor":"#888888",
	"graphFillAlpha":0,
	"autoGridCount":false,
	"selectedGraphFillAlpha":0,
	"graphLineAlpha":0.2,
	"graphLineColor":"#c2c2c2",
	"selectedGraphLineColor":"#888888",
	"selectedGraphLineAlpha":1
	},
	"categoryAxis": {
	"parseDates": false,
	"minorGridAlpha": 0.1,
	"labelRotation": 90,
	"minorGridEnabled": true
	},
	
	"export": {
	"enabled": true
	}
	});
	</script>
		<head>
		<title>Trend Curve </title>
		<meta charset="utf-8">
		<meta name = "format-detection" content = "telephone=no" />
		<link rel="icon" href="images/favicon.ico" type="image/x-icon">
		<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
		<link rel="stylesheet" type="text/css" media="screen" href="css/jqtransform.css">																			
		</head>
		<body onLoad="doOnLoad();">
			<div class="wrapper">
			<form method="POST" name="dataraange">
			<p>
			<strong><span class="style17">From Date :</span> &nbsp;&nbsp;&nbsp;</strong>
				<input type="date" size="15" id="date1" name="date1" autocomplete="OFF"  value="<?php if(isset($_POST['date1']))
			{ echo $_POST['date1']; }else{ echo date('Y-m-d'); } ?>"/>
			&nbsp;&nbsp;&nbsp;
			<strong><span class="style17">To Date :</span> &nbsp;&nbsp;&nbsp;</strong> 
				<input type="date" size="15" id="date2" name="date2" autocomplete="OFF"  value="<?php if(isset($_POST['date2']))
			{ echo $_POST['date2']; }else{ echo date('Y-m-d'); } ?>"/>
			&nbsp;&nbsp;&nbsp;
				<input name="submit" type="submit" onClick="formvalidate();" value="Submit"/>
			</p>
			<br /><?php if(!isset($_POST['date1']) && !isset($_POST['date2'])){ ?>
			<h4>Charging Trend Graph For The Current Date:</h4>
			<?php }?>
			<?php if(isset($_POST['date1']) && isset($_POST['date2'])){ ?>
			<center>	 <table width="50%" border="0" >
			<tr >
			<th colspan="6" bgcolor="#009999" style="color:#FFFFFF" scope="row" ><span class="style3"> Charging Trend Graph From &nbsp;&nbsp;
			<?php 
			if(@$_POST['date1'] && (@$_POST['date2']))
			{ 
			$GDate1 = date("d-M-Y", strtotime($date1));
			echo $GDate1;
			} ?>&nbsp;&nbsp;To &nbsp;&nbsp;<?php 
			if(@$_POST['date1'] && (@$_POST['date2']))
			{ 
			$GDate2 = date("d-M-Y", strtotime($date2));
			echo $GDate2;
			} ?></span></th>
			</tr></table></center>
			<?php } ?>
			<div id="chartdiv" style="height:500px; width:100%;">
			</div>		
			<div class="clear"></div>
			</div>														
		</body>
	</html>
