<?php
   require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.EnergyGroup.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";	
	
    $objStaff		= new Staff();
    $objStaff->RolesLists();
	$objStaff -> GetCompanyName($objArray);
	$objEnergyGroup	= new EnergyGroup();
	$objEnergyGroup->ListEnergyGroup($_POST);
	if(isset($_POST['table_search']))
	{
		$objEnergyGroup->ListEnergyGroup($_POST);
	}
	if(isset($_GET['success_msg_for_insert']))
    {
		$objSmarty->assign('SuccessMessage', 'New Record Created Successfully');
    } 
	if(isset($_GET['success_msg_for_update']))
    {
		$objSmarty->assign('SuccessMessage', 'Record Updated Successfully');
    } 
	if(isset($_GET['gId']))
	{   
		$objEnergyGroup->DeleteMaster($_GET['gId']);
	}
	if(isset($_GET['succs_msg_for_del']))
    {
		$objSmarty->assign('SuccessMessage', 'Record Deleted Successfully');
    } 
  $objSmarty->assign('IncludeTpl', 'energyMeterGroupList.tpl');
  $objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- ARKA RMS');
  $objSmarty->assign('robots','index,follow');
  $objSmarty->assign('key_word','');
  $objSmarty->assign('generator','');
  $objSmarty->assign('author','rsureshit@hotmail.com');
  $objSmarty->assign('document-state','dynamic');
  $objSmarty->assign('address',$config['SiteGlobalPath']); 
 
  /*Display page*/
  $objSmarty->assign('LeftTpl', 'left.tpl');
  //$objSmarty->assign('HeaderTpl', 'header.tpl'); 	
  //$objSmarty->assign('FooterTpl', 'footer.tpl');  
  $objSmarty->display('pagetemplate.tpl');
?>