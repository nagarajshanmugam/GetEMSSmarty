<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.Platform.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";
	
		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objStaff -> GetCompanyName($objArray);
		$objPlatform		= new Platform();
		$objPlatform -> GetPlatformList($objArray);
		if(isset($_POST['hdAction']) && !isset($_GET['Update']))
		{
			$objPlatform->InsertPlatformSegment($_POST);
		}
		if(isset($_GET['Update']) && isset($_GET['groupId']) && isset($_POST['hdAction']))
		{
			$objPlatform->UpdatePlatformSegment($_POST);
		}
		if(isset($_GET['success_msg_for_insert']))
		{
			$objSmarty->assign('SuccessMessage', 'New Record Created Successfully');
		} 
		if(isset($_GET['success_msg_for_update']))
		{
			$objSmarty->assign('ErrorMessage', 'Record Updated Successfully');
		} 
	
		$objSmarty->assign('IncludeTpl', 'PlatformAdd.tpl');
		$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Location Reg');
		$objSmarty->assign('robots','index,follow');
		$objSmarty->assign('key_word','');
		$objSmarty->assign('generator','');
		//$objSmarty->assign('author','rsureshit@hotmail.com');
		$objSmarty->assign('document-state','dynamic');
		$objSmarty->assign('address',$config['SiteGlobalPath']);
		
		/*Display page*/
		$objSmarty->assign('LeftTpl', 'left.tpl');
		$objSmarty->display('pagetemplate.tpl');

?>