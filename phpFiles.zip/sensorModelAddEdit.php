<?php

	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.SensorMaster.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";
	
		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objStaff -> GetCompanyName($objArray);
		$objSensorMaster	= new SensorMaster();
		$objSensorMaster -> ListSensor($objArray);
		$objSensorMaster -> ListEditView($objArray);
		$objSensorMaster -> ListCompany($objArray);
		$objSensorMaster -> GetGatewayName($objArray);
		$objSensorMaster -> Platform();
		
		
		if(isset($_POST['hdAction']) && !isset($_GET['Update']))
		{
			
			//print_r($_POST);
			//echo "am before insert"; exit;
			$objSensorMaster -> InsertSensorModel($_POST);
		}
		if(isset($_GET['Update']) && isset($_GET['sl_no'])){
			$objSensorMaster -> EditSensorModelView($_GET['sl_no']);
			$objSensorMaster -> GetSensorModelSegment($_GET['sl_no']);
		}
		
		if(isset($_POST['hdAction']) && isset($_GET['Update']))
		{
			//echo "am before update"; exit;
			$objSensorMaster ->EditSensorModel($_POST);
		}
	
		$objSmarty->assign('IncludeTpl', 'sensorModelAddEdit.tpl');
		$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Sensor Model Reg');
		$objSmarty->assign('robots','index,follow');
		$objSmarty->assign('key_word','');
		$objSmarty->assign('generator','');
		$objSmarty->assign('document-state','dynamic');
		$objSmarty->assign('address',$config['SiteGlobalPath']);
		
		
		/*Display page*/
		$objSmarty->assign('LeftTpl', 'left.tpl');
		$objSmarty->display('pagetemplate.tpl');

?>