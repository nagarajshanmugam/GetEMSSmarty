<?php

require('includes/common.php');

include_once $config['SiteClassPath']."class.Staff.php";
include_once $config['SiteClassPath']."class.Dashboard.php";
include_once $config['SiteClassPath']."class.split_page_results.php";	

$objStaff		= new Staff();
$objStaff->RolesLists();

$objStaff->GetCompanyName();
$objDashBoard	= new Dashboard();
$objDashBoard->DashPlatformMapingList();
$objDashBoard->DashOverallData();
//$objDashBoard->recentIncidentLog();

/*$objDashBoard->DashTotalEnergy();
$objDashBoard->DashGridEnergy();
$objDashBoard->DashDGEnergy();
$objDashBoard->DashSolarEnergy();
$objDashBoard->DashThisMonthGridEnergy();
$objDashBoard->DashThisMonthDGEnergy();
$objDashBoard->DashThisMonthSolarEnergy();
$objDashBoard->DashFreshWater();
$objDashBoard->DashDistilledWater();
$objDashBoard->DashOutdoorTemp(); */
//$objDashBoard->GetDashboardDetails();
//$objDashBoard->GetCostKwhAll();
//$objDashBoard->ListDashboardTest();

//$objDashBoard->GetSegmentsList();
//$objDashBoard->currMonthDailygraph(); // this function for Current Month  cost bar chart
//$objDashBoard->Multilinegraph();      // this function for cost bar chart
//$objDashBoard->MultiBarChart();
//$objDashBoard->IncidentLog();

$objSmarty->assign('dateSec', strtotime('-30 Seconds'));
$objSmarty->assign('dateSec1', strtotime('-120 Seconds'));
//$objSmarty->assign('IncludeTpl', 'utility_dashboard2.tpl');
$objSmarty->assign('IncludeTpl', 'utility_dashboard3.tpl');
$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Condition Monitoring Systems');
$objSmarty->assign('robots','index,follow');
$objSmarty->assign('key_word','');
$objSmarty->assign('generator','');
$objSmarty->assign('author','arkaautomaations.com');
$objSmarty->assign('document-state','dynamic');
$objSmarty->assign('address',$config['SiteGlobalPath']); 
$objSmarty->assign('LeftTpl', 'left.tpl');
$objSmarty->display('pagetemplate.tpl');
?>