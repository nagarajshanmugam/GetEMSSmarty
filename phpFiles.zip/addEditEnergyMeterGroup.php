<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.EnergyGroup.php";
	include_once $config['SiteClassPath']."class.ContactMaster.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";	

	$objStaff		= new Staff();
	$objStaff->RolesLists();
	$objStaff -> GetCompanyName($objArray);
	$objEnergyGroup	= new EnergyGroup();
	$objContactMaster		= new ContactMaster();
	$objEnergyGroup->SensorList($objArray);
	
	if(isset($_POST['hdAction']) && !isset($_GET['Update']))
	{
		$objEnergyGroup->InsertEnergyMeterGroup($_POST);
	}
	$objEnergyGroup->GroupDetailview($_GET['groupId']);
	if(isset($_GET['Update']) && isset($_GET['groupId']) && isset($_POST['hdAction']))
	{
		$objEnergyGroup->UpdateEnergyMeterGroup($_POST);
	}
	if(isset($_GET['success_msg_for_insert']))
	{
		$objSmarty->assign('SuccessMessage', 'New Record Created Successfully');
	} 
	
	if(isset($_GET['success_msg_for_update']))
	{
		$objSmarty->assign('ErrorMessage', 'Record Updated Successfully');
	} 
	if(isset($_GET['duplicate']))
	{
		$objSmarty->assign('ErrorMessage', 'Energy Meter Group Name Already Existing');
	} 
	$objSmarty->assign('IncludeTpl', 'addEditEnergyMeterGroup.tpl');
	$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- ARKA RMS');
	$objSmarty->assign('robots','index,follow');
	$objSmarty->assign('key_word','');
	$objSmarty->assign('generator','');
	$objSmarty->assign('author','rsureshit@hotmail.com');
	$objSmarty->assign('document-state','dynamic');
	$objSmarty->assign('address',$config['SiteGlobalPath']); 
	
	/*Display page*/
	$objSmarty->assign('LeftTpl', 'left.tpl');
	$objSmarty->display('pagetemplate.tpl');
?>