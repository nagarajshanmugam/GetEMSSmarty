<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.temperature_Dashboard.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";	
	
		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objStaff->GetCompanyName();
		$objtemperature_DashBoard	= new temperature_Dashboard();
		$objtemperature_DashBoard->GetDashboardDetails();
		$objtemperature_DashBoard->GetTemperatureSensor();
        $objtemperature_DashBoard->GetLineGraph();
		$objSmarty->assign('dateSec', strtotime('-60 Seconds'));
		$objSmarty->assign('headervariable', 'Temperature');
		$objSmarty->assign('IncludeTpl', 'DashboardTemperatureOld.tpl');
		$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Condition Monitoring Systems');
		$objSmarty->assign('robots','index,follow');
		$objSmarty->assign('key_word','');
		$objSmarty->assign('generator','');
		$objSmarty->assign('author','aal@arkaautomaations.com');
		$objSmarty->assign('document-state','dynamic');
		$objSmarty->assign('address',$config['SiteGlobalPath']); 
	
		/*Display page*/
		$objSmarty->assign('LeftTpl', 'left.tpl');
		$objSmarty->display('pagetemplate.tpl');
?>