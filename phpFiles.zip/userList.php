<?php
		require('includes/common.php');
		include_once $config['SiteClassPath']."class.Staff.php";
		include_once $config['SiteClassPath']."class.User.php";
		include_once $config['SiteClassPath']."class.split_page_results.php";	

		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objStaff -> GetCompanyName($objArray);
		$objUser	= new User();
		$objUser->ListUser($objArray);
		$objUser->GetUserCount($objArray);
		

	if(isset($_POST['table_search']))
	{
		$objUser->ListUser($_POST);
	}
	if(isset($_GET['success_msg_for_insert']))
	{
		$objSmarty->assign('SuccessMessage', 'New Record Created Successfully');
	} 
	if(isset($_GET['success_msg_for_update']))
	{
		$objSmarty->assign('SuccessMessage', 'Record Updated Successfully');
	} 
	if(isset($_GET['userId']))
	{   
		$objUser->DeleteMaster($_GET['userId']);
	}
	if(isset($_GET['succs_msg_for_del']))
	{
		$objSmarty->assign('SuccessMessage', 'Record Deleted Successfully');
	} 
	
		$com =base64_encode($_SESSION['CustomerId']);
		$objSmarty->assign('company_id',$com );
		$objSmarty->assign('IncludeTpl', 'userList.tpl');
		$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- ARKA RMS');
		$objSmarty->assign('robots','index,follow');
		$objSmarty->assign('key_word','');
		$objSmarty->assign('generator','');
		$objSmarty->assign('author','rsureshit@hotmail.com');
		$objSmarty->assign('document-state','dynamic');
		$objSmarty->assign('address',$config['SiteGlobalPath']); 
		$objSmarty->assign('LeftTpl', 'left.tpl');
		$objSmarty->display('pagetemplate.tpl');
?>