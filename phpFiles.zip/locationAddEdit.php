<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.LocationMaster.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";

	$objStaff		= new Staff();
	$objStaff -> GetCompanyName($objArray);
	$objStaff->RolesLists();
	$objLocationMaster		= new LocationMaster();	
	$objLocationMaster -> ListSensor($objArray);
	$objLocationMaster -> ListGateway($objArray);
	$objLocationMaster -> ListBranch($objArray);
	$objLocationMaster -> ListEditView($objArray);
	
	if(isset($_POST['hdAction']) && !isset($_GET['Update'])){

		//echo"am in create"; exit;
		$objLocationMaster -> InsertLocationMaster($_POST);
	}
	if(isset($_GET['Update']) && isset($_GET['locId']))
	{
		$objLocationMaster -> ListEditView($objArray);
	}
	if(isset($_GET['Update']) && isset($_GET['locId']) && isset($_POST['hdAction']))
	{
		$objLocationMaster -> EditLocationMaster($_POST);
	}
	
	$objSmarty->assign('IncludeTpl', 'locationAddEdit.tpl');
	$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Location Reg');
	$objSmarty->assign('robots','index,follow');
	$objSmarty->assign('key_word','');
	$objSmarty->assign('generator','');
	$objSmarty->assign('document-state','dynamic');
	$objSmarty->assign('address',$config['SiteGlobalPath']);
		
	/*Display page*/
	$objSmarty->assign('LeftTpl', 'left.tpl');
	$objSmarty->display('pagetemplate.tpl');

?>