<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.SensorMaster.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";
	
		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objStaff -> GetCompanyName($objArray);
		$objSensorMaster	= new SensorMaster();
		$objSensorMaster -> ListCompany($objArray);
		$objSensorMaster -> GetGatewayName($objArray);
		$objSensorMaster -> EditViewFeederForm($objArray);
		if(isset($_POST['hdAction']))
		{ 
			$objSensorMaster -> InsertAlertParameter($_POST);
		}
		if(isset($_POST['hdAction2']) && isset($_GET['Delete']))
		{ 
			$objSensorMaster -> DeleteAlertParameter($_GET['Delete']);
		}
		if(isset($_GET['Update']) && isset($_GET['sl_no'])){
			$objSensorMaster -> EditViewFeederForm($_GET['sl_no']);
		}
		if(isset($_GET['Update']) && isset($_POST['hdAction'])){
			$objSensorMaster -> EditFeederForm($_POST);
		}
		if(isset($_GET['succs_msg_for_del'])){
			$objSmarty->assign('SuccessMessage', 'Alert Parameter Deleted Successfully');
		}	
		if(isset($_GET['success_msg_for_insert']))
		{
			$objSmarty->assign('SuccessMessage', 'Alert Parameter Created Successfully');
		} 
	
	
		$objSmarty->assign('IncludeTpl', 'feederAlertParameter.tpl');
		$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Alert Parameter');
		$objSmarty->assign('robots','index,follow');
		$objSmarty->assign('key_word','');
		$objSmarty->assign('generator','');
		$objSmarty->assign('document-state','dynamic');
		$objSmarty->assign('address',$config['SiteGlobalPath']);
		
		
		/*Display page*/
		$objSmarty->assign('LeftTpl', 'left.tpl');
		$objSmarty->display('pagetemplate.tpl');

?>