<?php

	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.ModbusMaster.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";
	
		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objStaff -> GetCompanyName($objArray);
		$objModbusMaster	= new ModbusMaster();
		$objModbusMaster -> ListSensorModel($objArray);
		
		
		
		if(isset($_POST['hdAction']) && !isset($_GET['Update']))
		{
			
			//print_r($_POST);
			//echo "am before insert"; exit;
			$objModbusMaster -> InsertSensorModel($_POST);
		}
		if(isset($_GET['Update']) && isset($_GET['sl_no'])){
			$objModbusMaster -> EditSensorModelView($_GET['sl_no']);
			$objModbusMaster -> GetSensorModelSegment($_GET['sl_no']);
		}
		
		if(isset($_POST['hdAction']) && isset($_GET['Update']))
		{
			//echo "am before update"; exit;
			$objModbusMaster ->EditSensorModel($_POST);
		}
	
		$objSmarty->assign('IncludeTpl', 'modbusConfiguration.tpl');
		$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Sensor Model Reg');
		$objSmarty->assign('robots','index,follow');
		$objSmarty->assign('key_word','');
		$objSmarty->assign('generator','');
		$objSmarty->assign('document-state','dynamic');
		$objSmarty->assign('address',$config['SiteGlobalPath']);
		
		
		/*Display page*/
		$objSmarty->assign('LeftTpl', 'left.tpl');
		$objSmarty->display('pagetemplate.tpl');

?>