<?php
include('config.php');
/**
 * PHPExcel
 *
 * Copyright (C) 2006 - 2013 PHPExcel
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @category   PHPExcel
 * @package    PHPExcel
 * @copyright  Copyright (c) 2006 - 2013 PHPExcel (http://www.codeplex.com/PHPExcel)
 * @license    http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt	LGPL
 * @version    1.7.9, 2013-06-02
 */

/** Error reporting */
error_reporting(E_ALL);
$hostname_arkaerp = $config['DBHost'];
$database_arkaerp = $config['DBName'];
$username_arkaerp = $config['DBUser'];
$password_arkaerp = $config['DBPassword'];
$arkaerp = mysqli_connect(
    $hostname_arkaerp,
    $username_arkaerp,
    $password_arkaerp
);

if (!$arkaerp) {
    die("Connection failed: " . mysqli_connect_error());
}

mysqli_select_db($arkaerp, $database_arkaerp);

/** Include PHPExcel */

require('includes/common.php');
require_once('./Connections/ARKAEMS.php');
require_once dirname(__FILE__) . '/Classes/PHPExcel.php';


// Create new PHPExcel object
//echo date('H:i:s') , " Create new PHPExcel object" , EOL;
$objPHPExcel = new PHPExcel();

// Set document properties
//echo date('H:i:s') , " Set document properties" , EOL;
$objPHPExcel->getProperties()->setCreator("Arka Automaations Ltd")
							 ->setLastModifiedBy("Arka Automaations Ltd")
							 ->setTitle("Office 2007 XLSX Test Document")
							 ->setSubject("Office 2007 XLSX Test Document")
							 ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
							 ->setKeywords("office 2007 openxml php")
							 ->setCategory("Test result file");



// Create a first sheet, representing sales data
//echo date('H:i:s') , " Add some data" , EOL;

// ********************************************Get Url Data ********************************************************
$gatewayCode = base64_decode($_GET['gatewayCode']);
$sensorCode = base64_decode($_GET['sensorCode']);
$comId = base64_decode($_GET['companyId']);
$branchId = base64_decode($_GET['branchId']);
						
		
              $SelCompanyQuery = 'SELECT companyCode FROM arka_company_master WHERE slNo="'.$comId.'" AND status="1"';   
            $companySource=mysql_query($SelCompanyQuery);//echo $SelCompanyQuery;
            $companyRow = mysql_fetch_array($companySource);
		        $comCode = $companyRow['companyCode'];

		 $SelBranchQuery = 'SELECT branch_id FROM arka_branch_master WHERE sl_no="'.$branchId.'" AND record_status="1"';  
     $branchSource=mysql_query($SelBranchQuery);//echo $SelBranchQuery;
            $branchRow = mysql_fetch_array($branchSource);
		        $branchCode = $branchRow['branch_id'];
		//echo "Company Code".$comCode."<br>";
		//echo "Branch Code".$branchCode."<br>"; 
		

		   $SelPlatformMapQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';  
        $platformSource=mysql_query($SelPlatformMapQuery);//echo $SelPlatformMapQuery;
        $platformRow = mysql_fetch_array($platformSource);
        $platformCode = $platformRow['segmentCode'];

			$TempPF = "Temperature";

			$SelTempPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$TempPF.'" AND status="1"';  
       $tempPlatformSource=mysql_query($SelTempPlatformQuery);//echo $SelTempPlatformQuery;
        $tempPlatformRow = mysql_fetch_array($tempPlatformSource);
        $tempSegCode = $tempPlatformRow['segmentCode'];
        $tempSegId = $tempPlatformRow['slNo'];

		
		$dailyTableTemp = $comCode."_".$branchCode."_".$tempSegCode."_cron_daily";

        //echo $dailyTableTemp; exit;
			$selQryIotTemp = 'SELECT * FROM `arka_iot_platform` WHERE segmentName="Temperature" AND status="1"';
       $iotTempSource=mysql_query($selQryIotTemp);//echo $selQryIotTemp;
        $iotTempRow = mysql_fetch_array($iotTempSource);
		    $tempIotId = $iotTempRow['slNo'];
	    
      //echo $tempIotId; exit;


	/*echo"<br><br> selQryS: "; echo */    
		$selQryTemp = 'SELECT arka_sensor_master.*,sensor_model_master.TemHum FROM `arka_sensor_master`,sensor_model_master WHERE arka_sensor_master.isActive=1 AND sensor_model_master.platform_id="3" AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.sensorCode="'.$sensorCode.'" GROUP BY arka_sensor_master.sensorCode';
		//echo $selQryTemp; exit;
     $TempQrySource=mysql_query($selQryTemp);//echo $selQryTemp;
       $TempList = array();

while ($tempDetail = mysql_fetch_assoc($TempQrySource))
{
    $result = array();
    $SelSpecificQuery = "";
    $DBSensorTableName = "";

    $feederName      = $tempDetail['sensorName'];
    $gatewayCode     = $tempDetail['gateway_id'];
    $sensorCode      = $tempDetail['sensorCode'];
    $sensorCodeTable = str_replace("-", "_", $sensorCode);

    // Get Sensor Model
    $selModelQry = 'SELECT sl_no, model_id
                    FROM sensor_model_master
                    WHERE model_id = (
                        SELECT sensorModel
                        FROM arka_sensor_master
                        WHERE sensorCode="'.$sensorCode.'"
                        AND company_id="'.$comId.'"
                        AND branch_id="'.$branchId.'"
                        AND status="1"
                    )
                    AND status="1"';

    $modelResult = mysql_query($selModelQry);

    $senModelId = "";
    if($modelResult && mysql_num_rows($modelResult) > 0)
    {
        $modelRow = mysql_fetch_assoc($modelResult);
        $senModelId = $modelRow['sl_no'];
    }

    // Find Sensor Table
    $selTableQry = 'SELECT TABLE_NAME
                    FROM INFORMATION_SCHEMA.TABLES
                    WHERE TABLE_NAME LIKE "'.$comCode.'_'.$branchCode.'\_%_'.$sensorCodeTable.'"';

    $tableResult = mysql_query($selTableQry);

    if($tableResult && mysql_num_rows($tableResult) > 0)
    {
        $tableRow = mysql_fetch_assoc($tableResult);
        $sensorTableName = $tableRow['TABLE_NAME'];

        // Check Recent Data
        $selOffQry = 'SELECT *
                      FROM '.$database_arkaerp.'.'.$sensorTableName.'
                      WHERE status="1"
                      AND sensor_code="'.$sensorCode.'"
                      AND posted_date_time >= DATE_SUB(NOW(), INTERVAL 10 MINUTE)
                      ORDER BY slNo DESC
                      LIMIT 1';

        $offResult = mysql_query($selOffQry);

        $DBSensorTableName = $database_arkaerp.'.'.$sensorTableName;

        $SelSpecificQuery = '
            SELECT
                '.$DBSensorTableName.'.posted_date_time,
                '.$DBSensorTableName.'.sensor_code,
                '.$DBSensorTableName.'.gateway_code,
                '.$DBSensorTableName.'.sensor_model,
                '.$DBSensorTableName.'.temperature_c,
                '.$DBSensorTableName.'.temperature_f,
                '.$DBSensorTableName.'.humidity,
                '.$DBSensorTableName.'.posted_date_time AS TZ,
                arka_sensor_master.sensorName AS feeder_name,
                arka_sensor_master.slNo,
                arka_sensor_master.feeder_type,
                arka_sensor_master.company_id,
                arka_sensor_master.branch_id,
                TIMESTAMPDIFF(SECOND, '.$DBSensorTableName.'.posted_date_time, NOW()) AS secs,
                sensor_model_master.TemHum
            FROM '.$DBSensorTableName.',
                 arka_sensor_master,
                 sensor_model_master
            WHERE '.$DBSensorTableName.'.gateway_code = arka_sensor_master.gateway_id
            AND '.$DBSensorTableName.'.sensor_code = arka_sensor_master.sensorCode
            AND arka_sensor_master.company_id="'.$comId.'"
            AND arka_sensor_master.branch_id="'.$branchId.'"
            AND arka_sensor_master.isActive="1"
            AND arka_sensor_master.status="1"
            AND '.$DBSensorTableName.'.status="1"
            AND sensor_model_master.model_id = arka_sensor_master.sensorModel
            ORDER BY '.$DBSensorTableName.'.slNo DESC
            LIMIT 1';

        $specificResult = mysql_query($SelSpecificQuery);

        if($specificResult && mysql_num_rows($specificResult) > 0)
        {
            while($row = mysql_fetch_assoc($specificResult))
            {
                $row['sensor_table'] = $DBSensorTableName;
                $result[] = $row;
            }
        }
    }

    if(!empty($result))
    {
        $TempList[] = $result[0];
    }
    else
    {
        $TempList[] = array(
            'posted_date_time' => '',
            'sensor_code'      => $sensorCode,
            'gateway_code'     => $gatewayCode,
            'sensor_model'     => $tempDetail['sensorModel'],
            'temperature_c'    => '',
            'temperature_f'    => '',
            'humidity'         => '',
            'TZ'               => '',
            'feeder_name'      => $feederName,
            'slNo'             => $tempDetail['slNo'],
            'feeder_type'      => $tempDetail['feeder_type'],
            'company_id'       => $comId,
            'branch_id'        => $branchId,
            'secs'             => '',
            'TemHum'           => $tempDetail['TemHum'],
            'sensor_table'     => $DBSensorTableName
        );
    }
}
//  echo "<pre>";
//  print_r($TempList);
//  echo "</pre>";
//  exit;




$fromDate = $_GET['from'];  
$fDate = date("d-M-Y", strtotime($fromDate)); 
$f1Date = date("Y-m-d", strtotime($fromDate));

$toDate = $_GET['to'];  
$tDate = date("d-M-Y", strtotime($toDate)); 
$t1Date = date("Y-m-d", strtotime($toDate)); 

$objPHPExcel->setActiveSheetIndex(0);
$objPHPExcel->getActiveSheet()->mergeCells('A3:E3');
$objPHPExcel->getActiveSheet()->setCellValue('A3', 'Temperature Log Report');
$objPHPExcel->getActiveSheet()->getStyle('A3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFont()->setSize(18);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFill()->getStartColor()->setARGB('FF1E90FF');

$objPHPExcel->getActiveSheet()->setCellValue('A1', 'From Date :'.$fDate);
$objPHPExcel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('B1', 'To Date :'.$tDate);
$objPHPExcel->getActiveSheet()->getStyle('B1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('C1', 'Gateway Code :'.$gatewayCode);
$objPHPExcel->getActiveSheet()->getStyle('C1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('D1', 'Sensor Code :'.$sensorCode);
$objPHPExcel->getActiveSheet()->getStyle('D1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setSize(12);

			$objPHPExcel->getActiveSheet()->setCellValue('A5', '#');
			$objPHPExcel->getActiveSheet()->setCellValue('B5', 'Date Time');
			$objPHPExcel->getActiveSheet()->setCellValue('C5', 'Temperature Celsius');
			$objPHPExcel->getActiveSheet()->setCellValue('D5', 'Temperature Fahrenheit');
			$objPHPExcel->getActiveSheet()->setCellValue('E5', 'Humidity');
			
$date1 =$_GET['from'];

if($_GET['from'] != '' && $_GET['to'] != '')
{	
mysql_select_db($database_arkaems, $arkaerp);

 $query_rs1 = 'SELECT posted_date_time,posted_date_time AS M_TIMESTAMP,'.$DBSensorTableName.'.gateway_code,'.$DBSensorTableName.'.sensor_code,'.$DBSensorTableName.'.temperature_c,'.$DBSensorTableName.'.temperature_f,'.$DBSensorTableName.'.humidity FROM '.$DBSensorTableName.' WHERE gateway_code="'.$gatewayCode.'" AND sensor_code="'.$sensorCode.'" AND DATE(posted_date_time) BETWEEN "'.$f1Date.'" AND "'.$t1Date.'" GROUP BY M_TIMESTAMP ORDER BY slNo DESC'; 
$rs1 = mysql_query($query_rs1, $arkaerp) or die(mysql_error());
$totalRows_rs1 = mysql_num_rows($rs1);
}
else
{	
mysql_select_db($database_arkaems, $arkaerp);

 $query_rs1 = 'SELECT posted_date_time,posted_date_time AS M_TIMESTAMP,'.$DBSensorTableName.'.gateway_code,'.$DBSensorTableName.'.sensor_code,'.$DBSensorTableName.'.temperature_c,'.$DBSensorTableName.'.temperature_f,'.$DBSensorTableName.'.humidity FROM '.$DBSensorTableName.' WHERE gateway_code="'.$gatewayCode.'" AND sensor_code="'.$sensorCode.'" AND DATE(posted_date_time)=DATE(NOW()) ORDER BY slNo DESC'; 
$rs1 = mysql_query($query_rs1, $arkaerp) or die(mysql_error());
$totalRows_rs1 = mysql_num_rows($rs1);
}

	
$loop =6;
while( $row2 = mysql_fetch_array($rs1) ) {


	
							$objPHPExcel->getActiveSheet()->setCellValue('A' . $loop, $loop-5);
							$objPHPExcel->getActiveSheet()->setCellValue('B' . $loop, date("d-M-Y H:i", strtotime($row2['M_TIMESTAMP'])));
							$objPHPExcel->getActiveSheet()->setCellValue('C' . $loop, $row2['temperature_c']);
							$objPHPExcel->getActiveSheet()->setCellValue('D' . $loop, $row2['temperature_f']);
							$objPHPExcel->getActiveSheet()->setCellValue('E' . $loop, $row2['humidity']);
							
							$loop = $loop+1;

						}

$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);




$objPHPExcel->getActiveSheet()->getStyle('G3')->getFont()->setSize(14);
$objPHPExcel->getActiveSheet()->getStyle('G3')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('B5')->getAlignment()->setShrinkToFit(true);

// Set thin black border outline around column
$styleThinBlackBorderOutline = array(
	'borders' => array(
		'outline' => array(
			'style' => PHPExcel_Style_Border::BORDER_THIN,
			'color' => array('argb' => 'FF000000'),
		),
	),
);
$objPHPExcel->getActiveSheet()->getStyle('A5:E'.$loop)->applyFromArray($styleThinBlackBorderOutline);

// Set thick brown border outline around "Total"
$styleThickBrownBorderOutline = array(
	'borders' => array(
		'outline' => array(
			'style' => PHPExcel_Style_Border::BORDER_THICK,
			'color' => array('argb' => 'FF993300'),
		),
	),
);

// Set fills
$objPHPExcel->getActiveSheet()->getStyle('A5:E5')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A5:E5')->getFill()->getStartColor()->setARGB('FFFF8C00');
$objPHPExcel->getActiveSheet()->getStyle('A4:E4')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A4:E4')->getFill()->getStartColor()->setARGB('FF5F9EA0');
// Set style for header row using alternative method


$objPHPExcel->getActiveSheet()->getStyle('A5')->applyFromArray(
		array(
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
			),
			'borders' => array(
				'left'     => array(
 					'style' => PHPExcel_Style_Border::BORDER_THIN
 				)
			)
		)
);

$objPHPExcel->getActiveSheet()->getStyle('B5')->applyFromArray(
		array(
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
			)
		)
);

$objPHPExcel->getActiveSheet()->getStyle('E5')->applyFromArray(
		array(
			'borders' => array(
				'right'     => array(
 					'style' => PHPExcel_Style_Border::BORDER_THIN
 				)
			)
		)
);

// Unprotect a cell
$objPHPExcel->getActiveSheet()->getStyle('B1')->getProtection()->setLocked(PHPExcel_Style_Protection::PROTECTION_UNPROTECTED);
// Add a hyperlink to the sheet
$loop =$loop+2;
$objPHPExcel->getActiveSheet()->setCellValue('B' . $loop, 'ARKA');
$objPHPExcel->getActiveSheet()->getCell('B'  . $loop)->getHyperlink()->setUrl('http://ems.greatelephanttech.com');
$objPHPExcel->getActiveSheet()->getCell('B' . $loop)->getHyperlink()->setTooltip('Navigate to website');
$objPHPExcel->getActiveSheet()->getStyle('B' . $loop)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
$loop =$loop+1;
$objPHPExcel->getActiveSheet()->setCellValue('B'  . $loop, 'Confidential');
$objPHPExcel->getActiveSheet()->getStyle('B' . $loop)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);

$objPHPExcel->getActiveSheet()->insertNewRowBefore(6, 10);
$objPHPExcel->getActiveSheet()->removeRow(6, 10);
$objPHPExcel->getActiveSheet()->insertNewColumnBefore('E', 5);
$objPHPExcel->getActiveSheet()->removeColumn('E', 5);
$objPHPExcel->getActiveSheet()->getHeaderFooter()->setOddHeader('&L&BInvoice&RPrinted on &D');
$objPHPExcel->getActiveSheet()->getHeaderFooter()->setOddFooter('&L&B' . $objPHPExcel->getProperties()->getTitle() . '&RPage &P of &N');

$objPHPExcel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
$objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);

$objPHPExcel->getActiveSheet()->setTitle('Temperature Log Report');
