<?php 
	$hostname_arkaems = "localhost";
	$database_arkaems = "univa_ems";
	$username_arkaems = "root";
	$password_arkaems = "@dmin987";
	$arkaerp = mysql_connect($hostname_arkaems, $username_arkaems, $password_arkaems) or trigger_error(mysql_error(),E_USER_ERROR);
	mysql_select_db($database_arkaems, $arkaerp) or die(mysql_error());
	mysql_query( "SET SESSION sql_mode = 'NO_ENGINE_SUBSTITUTION'",$arkaerp);
	
	if($username_arkaems != 'root')
	{
		$nowDate= 'DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE)';
	}
	else{
		$nowDate= 'NOW()';
	}
	if(isset($_POST['sensor_code']))
	{
		$whCond="arka_sensor_master.sensorCode='".$_POST['sensor_code']."' AND arka_sensor_master.segmentName='Energy Meter' ";
	}
	else
	{
		$whCond="arka_sensor_master.segmentName='Energy Meter' ";
	}
	//	$sensorSel = "SELECT arka_sensor_master.* FROM arka_sensor_master WHERE arka_sensor_master.status='1' AND arka_sensor_master.isActive='1' AND ".$whCond." AND arka_sensor_master.sensorCode='EM6400-2'";
		$sensorSel = "SELECT energy_solar_meter_data_master_view.sensor_code,arka_sensor_master.* FROM arka_sensor_master,energy_solar_meter_data_master_view WHERE arka_sensor_master.status='1' AND arka_sensor_master.isActive='1' AND energy_solar_meter_data_master_view.sensor_code=arka_sensor_master.sensorCode AND ".$whCond." ";
		$sensorList = mysql_query($sensorSel,$arkaerp);
		$sensorList2 = mysql_query($sensorSel,$arkaerp);
		$machine = mysql_num_rows($sensorList);			
	

	/*****************************************     Query Starts for:  lastday KWH and Cost    *****************************************/	
	while($rows2=mysql_fetch_array($sensorList2))
	{
	if(isset($_POST['recorded_date']))
	{
		$yesDay='DATE("'.$_POST['recorded_date'].'")';
		$dayBefYesDay='DATE(DATE_SUB("'.$_POST['recorded_date'].'",INTERVAL "1" DAY))';
		$userName =$_POST['userName'];
		$manualUpdate=1;
	}
	else
	{
		$yesDay='DATE(DATE_SUB('.$nowDate.',INTERVAL "1" DAY))';
		$dayBefYesDay='DATE(DATE_SUB('.$nowDate.',INTERVAL "2" DAY))';
		$userName='Cron';
		$manualUpdate=0;
	}
 		$selYes='SELECT * FROM energy_solar_meter_data_master WHERE `gateway_code`="'.$rows2["gateway_id"].'" AND `sensor_code`="'.$rows2["sensorCode"].'" AND `recorded_date_time` IN (SELECT MAX(`recorded_date_time`) FROM energy_solar_meter_data_master WHERE `gateway_code`="'.$rows2["gateway_id"].'" AND `sensor_code`="'.$rows2["sensorCode"].'" AND DATE(`recorded_date_time`)='.$dayBefYesDay.' ) ';
		$daybeforeData = mysql_query($selYes,$arkaerp);
		$dayBeforeYesterday = mysql_num_rows($daybeforeData);		
	if($dayBeforeYesterday >='1')
	{
		$yesDay=$yesDay;
		$dayBefYesDay=$dayBefYesDay;
		$max_min="MAX";
	}
	else
	{
		$yesDay=$yesDay;
		$dayBefYesDay=$yesDay;
		$max_min="MIN";
	}
	
echo		$selQry = 'SELECT A.KWH AS Yesterday,A.DG_KWH AS DG_Yesterday,B.KWH AS Today,B.DG_KWH AS DG_Today,A.recorded_date_time AS Min_Date,B.recorded_date_time AS Max_date,DATE(B.recorded_date_time) AS recorded_date,A.unit_rate AS unit_rate,(B.KWH-A.KWH)AS TOTAL_KWH ,(B.DG_KWH-A.DG_KWH)AS TOTAL_DG_KWH ,(B.KWH-A.KWH)*A.unit_rate AS cost,(B.DG_KWH-A.DG_KWH)*A.unit_rate AS dg_cost FROM (SELECT energy_solar_meter_data_master.KWH,energy_solar_meter_data_master.DG_KWH,energy_solar_meter_data_master.recorded_date_time,arka_sensor_master.unit_rate FROM `energy_solar_meter_data_master`,arka_sensor_master WHERE energy_solar_meter_data_master.sensor_code=arka_sensor_master.sensorCode AND arka_sensor_master.company_id="'.$rows2["company_id"].'" AND arka_sensor_master.branch_id="'.$rows2["branch_id"].'"  AND energy_solar_meter_data_master.`gateway_code`="'.$rows2["gateway_id"].'" AND energy_solar_meter_data_master.`sensor_code`="'.$rows2["sensorCode"].'" AND energy_solar_meter_data_master.`recorded_date_time` IN (SELECT '.$max_min.'(`recorded_date_time`) FROM energy_solar_meter_data_master WHERE energy_solar_meter_data_master.`gateway_code`="'.$rows2["gateway_id"].'" AND energy_solar_meter_data_master.`sensor_code`="'.$rows2["sensorCode"].'" AND DATE(`recorded_date_time`)='.$dayBefYesDay.' )) AS A ,(SELECT energy_solar_meter_data_master.KWH,energy_solar_meter_data_master.DG_KWH,energy_solar_meter_data_master.recorded_date_time,arka_sensor_master.unit_rate FROM `energy_solar_meter_data_master`,arka_sensor_master WHERE energy_solar_meter_data_master.sensor_code=arka_sensor_master.sensorCode AND arka_sensor_master.company_id="'.$rows2["company_id"].'" AND arka_sensor_master.branch_id="'.$rows2["branch_id"].'" AND energy_solar_meter_data_master.`gateway_code`="'.$rows2["gateway_id"].'" AND energy_solar_meter_data_master.`sensor_code`="'.$rows2["sensorCode"].'" AND`recorded_date_time` IN (SELECT MAX(`recorded_date_time`) FROM energy_solar_meter_data_master WHERE energy_solar_meter_data_master.`gateway_code`="'.$rows2["gateway_id"].'" AND energy_solar_meter_data_master.`sensor_code`="'.$rows2["sensorCode"].'" AND DATE(`recorded_date_time`)='.$yesDay.' )) AS B';
exit;		$selectEnergyData = mysql_query($selQry,$arkaerp);
		$energyData2 = mysql_num_rows($selectEnergyData);
	while ($energyData = mysql_fetch_assoc($selectEnergyData))
	 {
	echo	$InsQry='UPDATE `cron_daily_energy_data` SET `start_cum_kwh`="'.$energyData["Yesterday"].'",`dg_start_cum_kwh`="'.$energyData["DG_Yesterday"].'", `feeder_type`="'.$rows2["feeder_type"].'", `end_cum_kwh`="'.$energyData["Today"].'", `dg_end_cum_kwh`="'.$energyData["DG_Today"].'", `start_cum_date`="'.$energyData["Min_Date"].'",`dg_start_cum_date`="'.$energyData["Min_Date"].'", `end_cum_date`="'.$energyData["Max_date"].'",`dg_end_cum_date`="'.$energyData["Max_date"].'", `consuption_kwh`="'.$energyData["TOTAL_KWH"].'",`dg_consuption_kwh`="'.$energyData["TOTAL_DG_KWH"].'", `cost`="'.$energyData["unit_rate"].'",`dg_cost`="'.$energyData["unit_rate"].'", `consuption_cost`="'.$energyData["cost"].'",`dg_consuption_cost`="'.$energyData["dg_cost"].'",`posted_date_time`='.$nowDate.', `created_by`="'.$userName.'", `manual_update`="'.$manualUpdate.'" WHERE `company_id`="'.$rows2["company_id"].'" AND `branch_id`="'.$rows2["branch_id"].'" AND `gateway_code`="'.$rows2["gateway_id"].'" AND sensor_code="'.$rows2["sensorCode"].'" AND `recorded_date`="'.$energyData["recorded_date"].'"'; 
	exit;	mysql_query($InsQry,$arkaerp);
		echo "Cron Runs Sucessfully";
	}
	}
	/*****************************************     Query Starts for:  lastday KWH and Cost    *****************************************/	
		$InsertCronLog= "INSERT INTO cron_run_log (cron_name) VALUES ('cronSolarMeterData.php')";
		mysql_query($InsertCronLog,$arkaerp);		
	
	
	
?>

