<?php
require('includes/common.php');
include_once $config['SiteClassPath']."class.Staff.php";
include_once $config['SiteClassPath']."class.Heinn_Dashboard.php";
include_once $config['SiteClassPath']."class.split_page_results.php";	

$objStaff		= new Staff();
$objStaff->RolesLists();
$objStaff->GetCompanyName();
$objHeinn_Dashboard	= new Heinn_Dashboard();
$objHeinn_Dashboard->heinnDashboardLive();
$objHeinn_Dashboard->IncidentLog();

$objSmarty->assign('IncludeTpl', 'heinn_dashboard.tpl');
$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Condition Monitoring Systems');
$objSmarty->assign('robots','index,follow');
$objSmarty->assign('key_word','');
$objSmarty->assign('generator','');
$objSmarty->assign('author','rsureshit@hotmail.com');
$objSmarty->assign('document-state','dynamic');
$objSmarty->assign('address',$config['SiteGlobalPath']); 
$objSmarty->assign('LeftTpl', 'left.tpl');
$objSmarty->display('pagetemplate.tpl');
?>