<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.Branch.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";
	
		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objStaff -> GetCompanyName();
		$objBranch		= new Branch();
		if($_SESSION['USER_GROUP'] =='Branch Admin' && isset($_POST['hdAction']))
		{
			$objBranch ->EditBranchName($_POST);
		}
        if(isset($_GET['branchId'])|| isset($_SESSION['branch_id']))
		{
			$objBranch->BranchEditView($objArray);
		}
        if(isset($_GET['success_msg_for_update']))
		{
			$objSmarty->assign('SuccessMessage', 'Record Updated Successfully');
		} 
			$objSmarty->assign('IncludeTpl', 'branchAddEditUpdate.tpl');
			$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Location Reg');
			$objSmarty->assign('robots','index,follow');
			$objSmarty->assign('key_word','');
			$objSmarty->assign('generator','');
			$objSmarty->assign('document-state','dynamic');
			$objSmarty->assign('address',$config['SiteGlobalPath']);

			/*Display page*/
			$objSmarty->assign('LeftTpl', 'left.tpl');
			$objSmarty->display('pagetemplate.tpl');

?>