<?php

require('includes/common.php');
require_once('./Connections/ARKAEMS.php');
mysql_select_db($database_arkaems, $arkaerp);

$SelQry = 'SELECT DAY(LAST_DAY("2023-01-11")) AS last';  
$SenMas = mysql_query($SelQry, $arkaerp) or die(mysql_error());
$row = mysql_fetch_assoc($SenMas);
//print_r($row);
//echo $row["last"];
$x = 'A';
for($i=1;$i<=$row["last"]; $i++){
//echo "hai"; exit;
	 $SelQry2 = 'SELECT DATE_FORMAT("2023-01-'.$i.'","%a") AS DAYN';  
	$SenMas2 = mysql_query($SelQry2, $arkaerp) or die(mysql_error());
	$row2 = mysql_fetch_assoc($SenMas2);
	//echo  $i." -".$row2["DAYN"]."-".$x."<br>";
	if($i==1){
		$objPHPExcel->getActiveSheet()->setCellValue($x.'5', '#');
	}elseif($i==2){
		$objPHPExcel->getActiveSheet()->setCellValue($x.'5', 'SensorName');
	}else{
		$objPHPExcel->getActiveSheet()->setCellValue($x.'5', $i." -".$row2["DAYN"]);
	}
	
	$x++;
$x=$x;


}





?>