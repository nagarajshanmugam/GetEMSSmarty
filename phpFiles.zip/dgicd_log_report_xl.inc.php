<?php
/**
 * PHPExcel
 *
 * Copyright (C) 2006 - 2013 PHPExcel
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @category   PHPExcel
 * @package    PHPExcel
 * @copyright  Copyright (c) 2006 - 2013 PHPExcel (http://www.codeplex.com/PHPExcel)
 * @license    http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt	LGPL
 * @version    1.7.9, 2013-06-02
 */

/** Error reporting */
error_reporting(E_ALL);

/** Include PHPExcel */

require('includes/common.php');
require_once('./Connections/ARKAEMS.php');
require_once dirname(__FILE__) . '/Classes/PHPExcel.php';


// Create new PHPExcel object
//echo date('H:i:s') , " Create new PHPExcel object" , EOL;
$objPHPExcel = new PHPExcel();

// Set document properties
//echo date('H:i:s') , " Set document properties" , EOL;
$objPHPExcel->getProperties()->setCreator("Arka Automaations Ltd")
							 ->setLastModifiedBy("Arka Automaations Ltd")
							 ->setTitle("Office 2007 XLSX Test Document")
							 ->setSubject("Office 2007 XLSX Test Document")
							 ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
							 ->setKeywords("office 2007 openxml php")
							 ->setCategory("Test result file");



// Create a first sheet, representing sales data
//echo date('H:i:s') , " Add some data" , EOL;

// ********************************************Get Url Data ********************************************************
 //echo $macid;
$gatewayCode = base64_decode($_GET['gatewayCode']);
$sensorCode = base64_decode($_GET['sensorCode']);


$objPHPExcel->setActiveSheetIndex(0);
$objPHPExcel->getActiveSheet()->mergeCells('A3:O3');
$objPHPExcel->getActiveSheet()->setCellValue('A3', 'DG Meter Log Report');
$objPHPExcel->getActiveSheet()->getStyle('A3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFont()->setSize(18);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFill()->getStartColor()->setARGB('FF1E90FF');

$objPHPExcel->getActiveSheet()->mergeCells('A1:B1');
$objPHPExcel->getActiveSheet()->setCellValue('A1', ' From Date:');
$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->mergeCells('C1:D1');
$objPHPExcel->getActiveSheet()->setCellValue('C1', date('d-M-Y', strtotime($_GET['date1'])));
$objPHPExcel->getActiveSheet()->getStyle('C1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->mergeCells('F1:G1');
$objPHPExcel->getActiveSheet()->setCellValue('F1', 'To Date :');
$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('F1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->mergeCells('H1:I1');
$objPHPExcel->getActiveSheet()->setCellValue('H1', date('d-M-Y', strtotime($_GET['date2'])));
$objPHPExcel->getActiveSheet()->getStyle('H1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->mergeCells('J1:K1');
$objPHPExcel->getActiveSheet()->setCellValue('J1', '');
$objPHPExcel->getActiveSheet()->getStyle('J1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setSize(12);






	$query1 = 'SELECT arka_company_master.companyName,arka_branch_master.branch_name,arka_sensor_master.gateway_id,arka_sensor_master.sensorCode,arka_sensor_master.sensorModel,arka_sensor_master.sensorName FROM arka_company_master,arka_branch_master,arka_sensor_master WHERE arka_sensor_master.gateway_id="'.base64_decode($_GET["gatewayCode"]).'" AND arka_sensor_master.sensorCode="'.base64_decode($_GET["sensorCode"]).'" AND arka_sensor_master.company_id=arka_company_master.slNo AND arka_branch_master.company_id=arka_sensor_master.company_id AND arka_branch_master.company_id=arka_company_master.slNo AND arka_branch_master.sl_no=arka_sensor_master.branch_id';
	$recset1 = mysql_query($query1, $arkaerp) or die(mysql_error());
	$row1 = mysql_fetch_assoc($recset1);
	$companyName = $row1['companyName'];
	$branchName = $row1['branch_name'];
	$gatewayCode2 = $row1['gateway_id'];
	$sensorCode2 = $row1['sensorCode'];
	$sensorName = $row1['sensorName'];
	
	//$objPHPExcel->getActiveSheet()->mergeCells('A4:M4');
$objPHPExcel->getActiveSheet()->mergeCells('A4:B4');
$objPHPExcel->getActiveSheet()->setCellValue('A4', 'Branch :');
$objPHPExcel->getActiveSheet()->getStyle('A4')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A4')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->mergeCells('C4:D4');
$objPHPExcel->getActiveSheet()->setCellValue('C4', $branchName);
$objPHPExcel->getActiveSheet()->getStyle('C4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('C4')->getFont()->setSize(12);

//$objPHPExcel->getActiveSheet()->mergeCells('F4');
$objPHPExcel->getActiveSheet()->setCellValue('F4', 'Place Of installation :');
$objPHPExcel->getActiveSheet()->getStyle('F4')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('F4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('F4')->getFont()->setSize(12);

//$objPHPExcel->getActiveSheet()->mergeCells('G4:I4');
$objPHPExcel->getActiveSheet()->setCellValue('G4', $sensorName);
$objPHPExcel->getActiveSheet()->getStyle('G4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('G4')->getFont()->setSize(12);

/*$objPHPExcel->getActiveSheet()->mergeCells('J4:K4');
$objPHPExcel->getActiveSheet()->setCellValue('J4', 'Location');
$objPHPExcel->getActiveSheet()->getStyle('J4')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('J4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('J4')->getFont()->setSize(12);
*/
//$objPHPExcel->getActiveSheet()->mergeCells('H4:I4');
$objPHPExcel->getActiveSheet()->setCellValue('H4', $lno);
$objPHPExcel->getActiveSheet()->getStyle('H4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('H4')->getFont()->setSize(12);







			$objPHPExcel->getActiveSheet()->setCellValue('A5', 'DATE TIME');
			$objPHPExcel->getActiveSheet()->setCellValue('B5', 'VR');
			$objPHPExcel->getActiveSheet()->setCellValue('C5', 'VY');
			$objPHPExcel->getActiveSheet()->setCellValue('D5', 'VB');
			$objPHPExcel->getActiveSheet()->setCellValue('E5', 'VRY');
			$objPHPExcel->getActiveSheet()->setCellValue('F5', 'VYB');
			$objPHPExcel->getActiveSheet()->setCellValue('G5', 'VBR');
			$objPHPExcel->getActiveSheet()->setCellValue('H5', 'IR');
			$objPHPExcel->getActiveSheet()->setCellValue('I5', 'IY');
			$objPHPExcel->getActiveSheet()->setCellValue('J5', 'IB');
			$objPHPExcel->getActiveSheet()->setCellValue('K5', 'KVA');
			$objPHPExcel->getActiveSheet()->setCellValue('L5', 'KW');
        	$objPHPExcel->getActiveSheet()->setCellValue('M5', 'KVAR');
			$objPHPExcel->getActiveSheet()->setCellValue('N5', 'PF');
		    $objPHPExcel->getActiveSheet()->setCellValue('O5', 'KWH');
			
			mysql_select_db($database_arkaems, $arkaerp);

if(isset($_GET['date1']) && isset($_GET['date2']))
		{
		   $date1 = date("Y-m-d",strtotime($_GET['date1']));
		   $date2 = date("Y-m-d",strtotime($_GET['date2']));
		   
			//mysql_select_db($database_arkaems, $arkaerp);
		$query_rs1 =  "SELECT recorded_date_time AS TM,`METER_ID`, `R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`,`DG_KVAH`, `DG_KWH`, `DG_KVARH`, `SUM_PF`, `FREQUENCY`, `KWH_MSB`, `KWH_LSB`, `KWH`, `METER_TYPE_RUN_HOUR_MSB`, `RUN_HOUR_LSB`, `RUN_HOUR`, `IMPORT_EXPORT` FROM energy_data_master WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND EB_DG_STATUS='1' AND (DATE(recorded_date_time) BETWEEN '".$date1."' AND '".$date2."') ORDER BY TM DESC";
		
		}
		else
		{
		//	mysql_select_db($database_arkaems, $arkaerp);
			$query_rs1 = "SELECT recorded_date_time AS TM,`METER_ID`, `R_VOLTAGE`, `Y_VOLTAGE`, `B_VOLTAGE`, `RY_VOLTAGE`, `YB_VOLTAGE`, `BR_VOLTAGE`, `R_CURRENT`, `Y_CURRENT`, `B_CURRENT`, `SUM_KVA`, `SUM_KW`, `SUM_KVAR`,`DG_KVAH`, `DG_KWH`, `DG_KVARH`, `SUM_PF`, `FREQUENCY`, `KWH_MSB`, `KWH_LSB`, `KWH`, `METER_TYPE_RUN_HOUR_MSB`, `RUN_HOUR_LSB`, `RUN_HOUR`, `IMPORT_EXPORT` FROM energy_data_master WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND EB_DG_STATUS='1' AND DATE(recorded_date_time) = DATE(CONVERT_TZ(NOW(),'+00:00' ,'+00:00'))  ORDER BY TM DESC";
		}
		$mt2 = mysql_query($query_rs1, $arkaerp) or die(mysql_error());
//$recNumRow= mysql_num_rows($query_rs1);
	
$loop =6;
while( $row2 = mysql_fetch_array($mt2) ) {
    
    
/*************************    PF  Conditions    By Vishal on 11th Dec 2019       ***********************/	
	if($row2['SUM_PF']< 1)
	{
	$avgPF=$row2['SUM_PF'];
	}elseif(($row2['SUM_PF'] >= 1) && ($row2['SUM_PF'] < 2))
	{
	//$spExp= explode(".",$row2['AVG_PF']);
	//echo $spExp[1];
	//$avgPF= "-.".$spExp[1];
		$avgPF= "-0.99";
	}
	elseif($row2['SUM_PF'] >=2)
	{
	$avgPF= "1.00";
	}

/*****************************************************/
/*	$imp =$imp + $row2['SUM_KVA'];
	$exp =$exp + $row2['SUM_KW'];
	$g1k =$g1k + $row2['SUM_KVAR'];
	$g2k =$g2k + $PF;
	*/
	$g3k =$g3k + $row2['KWH'];
  //  echo $newDate;

    
    $orgDate = $row2['TM'];  
    $newDate = date("d-M-Y h:i A", strtotime($orgDate));  

	
							$objPHPExcel->getActiveSheet()->setCellValue('A' . $loop, $newDate);
							$objPHPExcel->getActiveSheet()->setCellValue('B' . $loop, round($row2['R_VOLTAGE'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('C' . $loop, round($row2['Y_VOLTAGE'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('D' . $loop, round($row2['B_VOLTAGE'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('E' . $loop, round($row2['RY_VOLTAGE'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('F' . $loop, round($row2['YB_VOLTAGE'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('G' . $loop, round($row2['BR_VOLTAGE'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('H' . $loop, round($row2['R_CURRENT'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('I' . $loop, round($row2['Y_CURRENT'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('J' . $loop, round($row2['B_CURRENT'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('K' . $loop, $row2['DG_KVAH']);
							$objPHPExcel->getActiveSheet()->setCellValue('L' . $loop, $row2['DG_KWH']);
							$objPHPExcel->getActiveSheet()->setCellValue('M' . $loop, round($row2['DG_KVARH'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('N' . $loop, round($avgPF,2));
							$objPHPExcel->getActiveSheet()->setCellValue('O' . $loop, round($row2['KWH'],2));
							
							$loop = $loop+1;

						}
			 	$objPHPExcel->getActiveSheet()->setCellValue('k' . $loop, Total);
		  /*  $objPHPExcel->getActiveSheet()->setCellValue('B' . $loop, $imp);
			$objPHPExcel->getActiveSheet()->setCellValue('C' . $loop, $exp);
			$objPHPExcel->getActiveSheet()->setCellValue('D' . $loop, $g1k);
			$objPHPExcel->getActiveSheet()->setCellValue('E' . $loop, $g2k);  */
			$objPHPExcel->getActiveSheet()->setCellValue('O' . $loop, $g3k);
			
					


$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setAutoSize(true);




$objPHPExcel->getActiveSheet()->getStyle('G3')->getFont()->setSize(14);
$objPHPExcel->getActiveSheet()->getStyle('G3')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('B5')->getAlignment()->setShrinkToFit(true);

// Set thin black border outline around column
//echo date('H:i:s') , " Set thin black border outline around column" , EOL;
$styleThinBlackBorderOutline = array(
	'borders' => array(
		'outline' => array(
			'style' => PHPExcel_Style_Border::BORDER_THIN,
			'color' => array('argb' => 'FF000000'),
		),
	),
);
$objPHPExcel->getActiveSheet()->getStyle('A5:O'.$loop)->applyFromArray($styleThinBlackBorderOutline);


// Set thick brown border outline around "Total"
//echo date('H:i:s') , " Set thick brown border outline around Total" , EOL;
$styleThickBrownBorderOutline = array(
	'borders' => array(
		'outline' => array(
			'style' => PHPExcel_Style_Border::BORDER_THICK,
			'color' => array('argb' => 'FF993300'),
		),
	),
);
//$objPHPExcel->getActiveSheet()->getStyle('D13:E13')->applyFromArray($styleThickBrownBorderOutline);

// Set fills

//echo date('H:i:s') , " Set fills" , EOL;
$objPHPExcel->getActiveSheet()->getStyle('A5:O5')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A5:O5')->getFill()->getStartColor()->setARGB('FFFF8C00');
$objPHPExcel->getActiveSheet()->getStyle('A4:O4')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A4:O4')->getFill()->getStartColor()->setARGB('FF5F9EA0');
// Set style for header row using alternative method
//echo date('H:i:s') , " Set style for header row using alternative method" , EOL;

$objPHPExcel->getActiveSheet()->getStyle('A5')->applyFromArray(
		array(
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
			),
			'borders' => array(
				'left'     => array(
 					'style' => PHPExcel_Style_Border::BORDER_THIN
 				)
			)
		)
);

$objPHPExcel->getActiveSheet()->getStyle('B5')->applyFromArray(
		array(
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
			)
		)
);

$objPHPExcel->getActiveSheet()->getStyle('L5')->applyFromArray(
		array(
			'borders' => array(
				'right'     => array(
 					'style' => PHPExcel_Style_Border::BORDER_THIN
 				)
			)
		)
);

// Unprotect a cell
//echo date('H:i:s') , " Unprotect a cell" , EOL;
$objPHPExcel->getActiveSheet()->getStyle('B1')->getProtection()->setLocked(PHPExcel_Style_Protection::PROTECTION_UNPROTECTED);

// Add a hyperlink to the sheet
$loop =$loop+2;
//echo date('H:i:s') , " Add a hyperlink to the sheet" , EOL;
$objPHPExcel->getActiveSheet()->setCellValue('B' . $loop, 'ARKA');
$objPHPExcel->getActiveSheet()->getCell('B'  . $loop)->getHyperlink()->setUrl('http://ems.arkaautomaations.com');
$objPHPExcel->getActiveSheet()->getCell('B' . $loop)->getHyperlink()->setTooltip('Navigate to website');
$objPHPExcel->getActiveSheet()->getStyle('B' . $loop)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
$loop =$loop+1;
$objPHPExcel->getActiveSheet()->setCellValue('B'  . $loop, 'Confidential');
//$objPHPExcel->getActiveSheet()->getCell('B' . $loop)->getHyperlink()->setUrl("sheet://'Terms and conditions'!A1");
//$objPHPExcel->getActiveSheet()->getCell('B'  . $loop)->getHyperlink()->setTooltip('Review terms and conditions');
$objPHPExcel->getActiveSheet()->getStyle('B' . $loop)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);


// Play around with inserting and removing rows and columns
//echo date('H:i:s') , " Play around with inserting and removing rows and columns" , EOL;
$objPHPExcel->getActiveSheet()->insertNewRowBefore(6, 10);
$objPHPExcel->getActiveSheet()->removeRow(6, 10);
$objPHPExcel->getActiveSheet()->insertNewColumnBefore('E', 5);
$objPHPExcel->getActiveSheet()->removeColumn('E', 5);

// Set header and footer. When no different headers for odd/even are used, odd header is assumed.
//echo date('H:i:s') , " Set header/footer" , EOL;
$objPHPExcel->getActiveSheet()->getHeaderFooter()->setOddHeader('&L&BInvoice&RPrinted on &D');
$objPHPExcel->getActiveSheet()->getHeaderFooter()->setOddFooter('&L&B' . $objPHPExcel->getProperties()->getTitle() . '&RPage &P of &N');

// Set page orientation and size
//echo date('H:i:s') , " Set page orientation and size" , EOL;
$objPHPExcel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
$objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);

// Rename first worksheet
//echo date('H:i:s') , " Rename first worksheet" , EOL;
$objPHPExcel->getActiveSheet()->setTitle('Meter Log Report');
