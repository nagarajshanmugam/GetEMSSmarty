<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.Branch.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";
	
		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objStaff -> GetCompanyName();
		$objBranch		= new Branch();
		if(isset($_POST['hdAction']) && !isset($_GET['Update']))
		{
			$objBranch -> InsertBranch($_POST);
		}
			$objBranch -> ListEditView($objArray);
		if(isset($_GET['Update']) && isset($_GET['branch_id']))
		{
			$objBranch -> EditBranch($_POST);
		}
			$objSmarty->assign('IncludeTpl', 'branchAddEdit.tpl');
			$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Location Reg');
			$objSmarty->assign('robots','index,follow');
			$objSmarty->assign('key_word','');
			$objSmarty->assign('generator','');
			$objSmarty->assign('document-state','dynamic');
			$objSmarty->assign('address',$config['SiteGlobalPath']);

			/*Display page*/
			$objSmarty->assign('LeftTpl', 'left.tpl');
			$objSmarty->display('pagetemplate.tpl');

?>