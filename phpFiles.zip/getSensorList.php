
<?php
include('config.php');
session_start();
$hostname_arkaerp = $config['DBHost'];
$database_arkaerp = $config['DBName'];
$username_arkaerp = $config['DBUser'];
$password_arkaerp = $config['DBPassword'];
$arkaerp = mysql_connect($hostname_arkaerp, $username_arkaerp, $password_arkaerp,$database_arkaerp) or trigger_error(mysql_error(),E_USER_ERROR);
mysql_select_db($database_arkaerp,$arkaerp);
$branchName=$_REQUEST['branchName'];
$companyId=$_REQUEST['companyId'];
$slNoReport=$_REQUEST['slNoReport'];
?>
       <?php                 
     if($companyId <> '')
	{
		$comId = $companyId;
	}	
	else
	{
		$comId = $_SESSION['CustomerId'];
	}
	
	$SelQuery1 = mysql_query('SELECT * from arka_branch_master WHERE record_status="1" AND is_active="1" AND sl_no="'.$branchName.'" AND company_id="'.$comId.'"');  
	
                
                      
								while($row1=mysql_fetch_array($SelQuery1))
								{?>
                              <label for="exampleInputlocationName">Branch - <?php echo $row1['branch_name'];?></label>
                             <div class="row a">
                           <?php  $SelQuery2 = mysql_query('SELECT * FROM  `arka_sensor_master` WHERE company_id="'.$comId.'" AND branch_id="'.$branchName.'" AND status="1" AND isActive="1" AND segmentName="Energy Meter"');  
                             while($row2=mysql_fetch_array($SelQuery2))
								{
                             if($row1['sl_no'] == $row2['branch_id'])
                             {
                             $row2sno = $row2['slNo'];
                            $SelQuery3 = mysql_query('SELECT * FROM `arka_customize_report_mapping` WHERE reportName="'.$slNoReport.'" AND status="1" GROUP BY sensorName'); 
                              $sensorId='';
                             while($row3=mysql_fetch_array($SelQuery3))
						    {
				            if($row3['sensorName'] == $row2['slNo'])
                            {
				            $sensorId .=$row3['sensorName'];
                            $sensorName=$row2['sensorName'];
                           } }?>
                           <div class="form-group col-md-3">
                            <div class="custom-control custom-checkbox">
                            <input class="custom-control-input" type="checkbox" id="sensorName[<?php echo $row2['slNo'];?>]"  name="sensorName" tabindex="8"  value="<?php echo $row2['slNo'];?>"  <?php if($sensorId == $row2sno) { ?> checked="checked" <?php } ?> >
							<label for="sensorName[<?php echo $row2['slNo'];?>]" class="custom-control-label"><?php echo $row2['sensorName'];?></label>
                            </div>
                            </div>
                            <?php
                           
                            }
                            } ?>
                            </div> <br>
                        <?php    } ?>
			     
	<style type="text/css">
	div.a {
  border: 1px solid black;
/*  outline: 1px solid black;*/
  border-radius: 10px;
  padding:6px;
}
</style>

