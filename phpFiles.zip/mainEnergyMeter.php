<?php
   require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.EnergyGroup.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";	
	
    $objStaff		= new Staff();
    $objStaff->RolesLists();
	$objStaff->GetCompanyName();
	$objEnergyGroup	= new EnergyGroup();
	//$objEnergyGroup->GetDashboardDetails();
  //  $objEnergyGroup->GetCostKwhAllForSubDashboard();
   // $objEnergyGroup->GetCostKwhAllSubMeter();
	$objEnergyGroup->GetMainMeterDashboard();
	//$objEnergyGroup->GetSegmentsList();
	$objSmarty->assign('dateSec', strtotime('-30 Seconds'));
	$objSmarty->assign('dateSec1', strtotime('-120 Seconds'));
  	$objSmarty->assign('IncludeTpl', 'mainEnergyMeter.tpl');

  
  $objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Condition Monitoring Systems');
  $objSmarty->assign('robots','index,follow');
  $objSmarty->assign('key_word','');
  $objSmarty->assign('generator','');
  $objSmarty->assign('author','aal@arkaautomaations.com');
  $objSmarty->assign('document-state','dynamic');
  $objSmarty->assign('address',$config['SiteGlobalPath']); 
  $objSmarty->assign('LeftTpl', 'left.tpl');
  $objSmarty->display('pagetemplate.tpl');
?>