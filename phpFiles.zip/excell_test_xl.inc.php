<?php
/**
 * PHPExcel
 *
 * Copyright (C) 2006 - 2013 PHPExcel
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @category   PHPExcel
 * @package    PHPExcel
 * @copyright  Copyright (c) 2006 - 2013 PHPExcel (http://www.codeplex.com/PHPExcel)
 * @license    http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt	LGPL
 * @version    1.7.9, 2013-06-02
 */

/** Error reporting */
//error_reporting(E_ALL);

/** Include PHPExcel */

require('includes/common.php');
require_once('./Connections/ARKAEMS.php');
require_once dirname(__FILE__) . '/Classes/PHPExcel.php';


// Create new PHPExcel object
//echo date('H:i:s') , " Create new PHPExcel object" , EOL;
$objPHPExcel = new PHPExcel();

// Set document properties
//echo date('H:i:s') , " Set document properties" , EOL;
$objPHPExcel->getProperties()->setCreator("Arka Automaations Ltd")
							 ->setLastModifiedBy("Arka Automaations Ltd")
							 ->setTitle("Office 2007 XLSX Test Document")
							 ->setSubject("Office 2007 XLSX Test Document")
							 ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
							 ->setKeywords("office 2007 openxml php")
							 ->setCategory("Test result file");



// Create a first sheet, representing sales data
//echo date('H:i:s') , " Add some data" , EOL;

// ********************************************Get Url Data ********************************************************
 //echo $macid;
$branchName = $_GET['branchName'];
$companyId = $_GET['companyId'];
$shiftName = $_GET['shiftName'];
$fromDate = $_GET['fromDate'];
$toDate = $_GET['toDate'];
$slNo = $_GET['slNo'];
$tbl = 'arka_';

mysql_select_db($database_arkaems, $arkaerp);
mysql_query( "SET SESSION sql_mode = 'NO_ENGINE_SUBSTITUTION'",$arkaerp);


$objPHPExcel->setActiveSheetIndex(0);
$objPHPExcel->getActiveSheet()->mergeCells('A3:F3');
$objPHPExcel->getActiveSheet()->setCellValue('A3', 'Customized Report');
$objPHPExcel->getActiveSheet()->getStyle('A3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFont()->setSize(18);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFill()->getStartColor()->setARGB('FF1E90FF');

$objPHPExcel->getActiveSheet()->setCellValue('A1', ' From Date:');
$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('B1', date('d-M-Y', strtotime($_GET['fromDate'])));
$objPHPExcel->getActiveSheet()->getStyle('B1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('E1', 'To Date :');
$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('E1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('F1', date('d-M-Y', strtotime($_GET['toDate'])));
$objPHPExcel->getActiveSheet()->getStyle('F1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('A4', 'Company : ');
$objPHPExcel->getActiveSheet()->getStyle('A4')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A4')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('B4', $row1['companyName']);
$objPHPExcel->getActiveSheet()->getStyle('B4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('B4')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('C4', 'Branch : ');
$objPHPExcel->getActiveSheet()->getStyle('C4')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('C4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('C4')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('D4', $row2['branch_name']);
$objPHPExcel->getActiveSheet()->getStyle('D4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D4')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('E4', 'Report Name :');
$objPHPExcel->getActiveSheet()->getStyle('E4')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('E4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('E4')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('F4', $row['reportName']);
$objPHPExcel->getActiveSheet()->getStyle('F4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('F4')->getFont()->setSize(12);


$objPHPExcel->getActiveSheet()->setCellValue('A5', '#');
$objPHPExcel->getActiveSheet()->setCellValue('B5', 'Sensor Name');
$objPHPExcel->getActiveSheet()->setCellValue('C5', 'Start KWH');
$objPHPExcel->getActiveSheet()->setCellValue('D5', 'End KWH');
$objPHPExcel->getActiveSheet()->setCellValue('E5', 'Total KWH');
$objPHPExcel->getActiveSheet()->setCellValue('F5', 'Total Cost');
    



$SelQuery= "SELECT 'sensor1' AS sensorName, '100' AS start_cum_kwh,'150' AS end_cum_kwh,'10' AS ccost";
$recset = mysql_query($SelQuery, $arkaerp) or die(mysql_error());
$loop =6;$i=1;
while( $row2 = mysql_fetch_array($recset) ) {
 $ckwh=$row2['end_cum_kwh']-$row2['start_cum_kwh'];
    $startTKWH=$startTKWH+$row2['start_cum_kwh'];
					$endTKWH=$endTKWH+$row2['end_cum_kwh'];
					$conTKWH=$conTKWH+$ckwh;
					$conTCOST=$conTCOST+$row2['ccost'];

	
							$objPHPExcel->getActiveSheet()->setCellValue('A' . $loop, $i);
							$objPHPExcel->getActiveSheet()->setCellValue('B' . $loop, $row2['sensorName']);
							$objPHPExcel->getActiveSheet()->setCellValue('C' . $loop, round($row2['start_cum_kwh'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('D' . $loop, round($row2['end_cum_kwh'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('E' . $loop, round($ckwh,2));
							$objPHPExcel->getActiveSheet()->setCellValue('F' . $loop, round($row2['ccost'],2));
							$loop = $loop+1;
$i++;
						}
			 	/*$objPHPExcel->getActiveSheet()->setCellValue('A' . $loop, '');
                $objPHPExcel->getActiveSheet()->setCellValue('B' . $loop, Total);
                $objPHPExcel->getActiveSheet()->getStyle('B' . $loop)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
                $objPHPExcel->getActiveSheet()->setCellValue('C' . $loop, round($startTKWH,2));
                $objPHPExcel->getActiveSheet()->setCellValue('D' . $loop, round($endTKWH,2));
                $objPHPExcel->getActiveSheet()->setCellValue('E' . $loop, round($conTKWH,2));
                $objPHPExcel->getActiveSheet()->setCellValue('F' . $loop, round($conTCOST,2));*/
			
					


$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);

$objPHPExcel->getActiveSheet()->getStyle('G3')->getFont()->setSize(14);
$objPHPExcel->getActiveSheet()->getStyle('G3')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('B5')->getAlignment()->setShrinkToFit(true);

// Set thin black border outline around column
//echo date('H:i:s') , " Set thin black border outline around column" , EOL;
$styleThinBlackBorderOutline = array(
	'borders' => array(
		'outline' => array(
			'style' => PHPExcel_Style_Border::BORDER_THIN,
			'color' => array('argb' => 'FF000000'),
		),
	),
);
$objPHPExcel->getActiveSheet()->getStyle('A5:F'.$loop)->applyFromArray($styleThinBlackBorderOutline);


// Set thick brown border outline around "Total"
//echo date('H:i:s') , " Set thick brown border outline around Total" , EOL;
$styleThickBrownBorderOutline = array(
	'borders' => array(
		'outline' => array(
			'style' => PHPExcel_Style_Border::BORDER_THICK,
			'color' => array('argb' => 'FF993300'),
		),
	),
);
//$objPHPExcel->getActiveSheet()->getStyle('D13:E13')->applyFromArray($styleThickBrownBorderOutline);

// Set fills

//echo date('H:i:s') , " Set fills" , EOL;
$objPHPExcel->getActiveSheet()->getStyle('A5:F5')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A5:F5')->getFill()->getStartColor()->setARGB('FFFF8C00');
$objPHPExcel->getActiveSheet()->getStyle('A4:F4')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A4:F4')->getFill()->getStartColor()->setARGB('FF5F9EA0');
// Set style for header row using alternative method
//echo date('H:i:s') , " Set style for header row using alternative method" , EOL;

$objPHPExcel->getActiveSheet()->getStyle('A5')->applyFromArray(
		array(
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
			),
			'borders' => array(
				'left'     => array(
 					'style' => PHPExcel_Style_Border::BORDER_THIN
 				)
			)
		)
);

$objPHPExcel->getActiveSheet()->getStyle('B5')->applyFromArray(
		array(
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
			)
		)
);

$objPHPExcel->getActiveSheet()->getStyle('L5')->applyFromArray(
		array(
			'borders' => array(
				'right'     => array(
 					'style' => PHPExcel_Style_Border::BORDER_THIN
 				)
			)
		)
);

// Unprotect a cell
//echo date('H:i:s') , " Unprotect a cell" , EOL;
$objPHPExcel->getActiveSheet()->getStyle('B1')->getProtection()->setLocked(PHPExcel_Style_Protection::PROTECTION_UNPROTECTED);

// Add a hyperlink to the sheet
$loop =$loop+2;
//echo date('H:i:s') , " Add a hyperlink to the sheet" , EOL;
$objPHPExcel->getActiveSheet()->setCellValue('B' . $loop, '');
$objPHPExcel->getActiveSheet()->getCell('B'  . $loop)->getHyperlink()->setUrl('http://ems.arkaautomaations.com');
$objPHPExcel->getActiveSheet()->getCell('B' . $loop)->getHyperlink()->setTooltip('Navigate to website');
$objPHPExcel->getActiveSheet()->getStyle('B' . $loop)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
$loop =$loop+1;
$objPHPExcel->getActiveSheet()->setCellValue('B'  . $loop, '');
//$objPHPExcel->getActiveSheet()->getCell('B' . $loop)->getHyperlink()->setUrl("sheet://'Terms and conditions'!A1");
//$objPHPExcel->getActiveSheet()->getCell('B'  . $loop)->getHyperlink()->setTooltip('Review terms and conditions');
$objPHPExcel->getActiveSheet()->getStyle('B' . $loop)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);


// Play around with inserting and removing rows and columns
//echo date('H:i:s') , " Play around with inserting and removing rows and columns" , EOL;
$objPHPExcel->getActiveSheet()->insertNewRowBefore(6, 10);
$objPHPExcel->getActiveSheet()->removeRow(6, 10);
$objPHPExcel->getActiveSheet()->insertNewColumnBefore('E', 5);
$objPHPExcel->getActiveSheet()->removeColumn('E', 5);

// Set header and footer. When no different headers for odd/even are used, odd header is assumed.
//echo date('H:i:s') , " Set header/footer" , EOL;
$objPHPExcel->getActiveSheet()->getHeaderFooter()->setOddHeader('&L&BInvoice&RPrinted on &D');
$objPHPExcel->getActiveSheet()->getHeaderFooter()->setOddFooter('&L&B' . $objPHPExcel->getProperties()->getTitle() . '&RPage &P of &N');

// Set page orientation and size
//echo date('H:i:s') , " Set page orientation and size" , EOL;
$objPHPExcel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
$objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);

// Rename first worksheet
//echo date('H:i:s') , " Rename first worksheet" , EOL;
$objPHPExcel->getActiveSheet()->setTitle('Meter Log Report');
