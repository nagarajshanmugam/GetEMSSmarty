<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.Company.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";	
	
		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objStaff -> GetCompanyName($objArray);
		$objStaff->chkStaffLogin($objArray);
		$objCompany	= new Company();
		

		if($_SESSION['USER_GROUP'] =='Company Admin' && isset($_POST['hdAction']))
		{
		//echo  "hai"; exit;
			$objCompany ->CompanyUpdate($_POST,$_FILES);
		}
		if(isset($_GET['companyId'])|| isset($_SESSION['COMPANY_ID']))
		{
			$objCompany->CompanyEditView($objArray);
		}
		
		if(isset($_GET['success_msg_for_update']))
		{
			$objSmarty->assign('SuccessMessage', 'Record Updated Successfully');
		} 
		$objSmarty->assign('IncludeTpl', 'AddEditcompanyUpdate.tpl');
		$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- ARKA RMS');
		$objSmarty->assign('robots','index,follow');
		$objSmarty->assign('key_word','');
		$objSmarty->assign('generator','');
		$objSmarty->assign('author','rsureshit@hotmail.com');
		$objSmarty->assign('document-state','dynamic');
		$objSmarty->assign('address',$config['SiteGlobalPath']); 
		
		
		/*Display page*/
		$objSmarty->assign('LeftTpl', 'left.tpl');
		$objSmarty->display('pagetemplate.tpl');
?>