<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.SensorMaster.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";
	
		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objStaff -> GetCompanyName();
		$objSensorMaster		= new SensorMaster();
		$objSensorMaster -> ListCapacitorValue($objArray);
		if(isset($_GET['companyId'])){
			$objSensorMaster -> ListCapacitorValue($objArray);
		}
		if(isset($_GET['update'])){
			$objSensorMaster -> InsertCapacitorValue($_POST);
		}
		if(isset($_POST['hdAction']))
	{
	$objSensorMaster -> UpdateCapacitorValue($_POST);
	}

		if(isset($_GET['success_msg_for_update']))
		{
			$objSmarty->assign('SuccessMessage', 'Record Updated Successfully');
		}
		if(isset($_GET['success_msg_for_insert']))
		{
			$objSmarty->assign('SuccessMessage', 'Record Created Successfully');
		}
	
	
		$objSmarty->assign('IncludeTpl', 'capacityList.tpl');
		$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Location Reg');
		$objSmarty->assign('robots','index,follow');
		$objSmarty->assign('key_word','');
		$objSmarty->assign('generator','');
		$objSmarty->assign('document-state','dynamic');
		$objSmarty->assign('address',$config['SiteGlobalPath']);
		
		
		/*Display page*/
		$objSmarty->assign('LeftTpl', 'left.tpl');
		$objSmarty->display('pagetemplate.tpl');

?>