<?php

/*
  Rui Santos
  Complete project details at https://RandomNerdTutorials.com/esp32-esp8266-mysql-database-php/
  
  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files.
  
  The above copyright notice and this permission notice shall be included in all
  copies or substantial portions of the Software.
*/
	 header('Access-Control-Allow-Origin: *'); 
    header("Access-Control-Allow-Credentials: true");
    header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
    header('Access-Control-Max-Age: 1000');
    header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');


$servername = "148.66.130.228";

// REPLACE with your Database name
$dbname = "greatelephanttec_ems";
// REPLACE with Database user
$username = "greatelephanttec_ems_user";
// REPLACE with Database user password
$password = "GetEms@2025";
 
//exit;


// Keep this API Key value to be compatible with the ESP32 code provided in the project page. 
// If you change this value, the ESP32 sketch needs to match
//$api_key_value = "arkatemp1001";

//$api_key= $sensor = $location = $value1 = "";


    
   if ($_SERVER["REQUEST_METHOD"] == "POST") {
     $inputJSON = file_get_contents('php://input');
         $input= json_decode( $inputJSON, true); 
       //  print_r($input);
         
         // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } 
   //
     $sql = "INSERT INTO teltonika_json_data(json_data) VALUES ('".$inputJSON."')";
        $insSel = $conn->query($sql);
        if($inSel)
        {
             echo "Data Inserted Successfully.";
        }
     
}
else {
		$conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } 
		date_default_timezone_set('Asia/Kolkata');
		$date = date('d-m-y h:i:s');
		$jsonErr='[{"status":"No data posted with HTTP POST","Time":"'.$date.'"}]';
		 $sql = "INSERT INTO teltonika_json_data(json_data) VALUES ('".$jsonErr."')";
        $insSel = $conn->query($sql);
    echo "No data posted with HTTP POST.";
}


function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
