<?php
    require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.Company.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";	
	
    $objStaff		= new Staff();
    $objStaff->RolesLists();
    $objCompany	= new Company();
	$objCompany->ListCompany($_POST);
	

	if(isset($_POST['table_search']))
	{
	   $objCompany->ListCompany($_POST);
	}

	if(isset($_GET['success_msg_for_insert']))
    {
       $objSmarty->assign('SuccessMessage', 'New Record Created Successfully');
    } 

	if(isset($_GET['success_msg_for_update']))
    {
       $objSmarty->assign('SuccessMessage', 'Record Updated Successfully');
    } 

	if(isset($_GET['cId']))
	{   
       $objCompany->DeleteMaster($_GET['cId']);
	}

	if(isset($_GET['succs_msg_for_del']))
    {
       $objSmarty->assign('SuccessMessage', 'Record Deleted Successfully');
    } 
	
    $objSmarty->assign('IncludeTpl', 'companyList.tpl');
	$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- ARKA EMS');
	$objSmarty->assign('robots','index,follow');
	$objSmarty->assign('key_word','');
	$objSmarty->assign('generator','');
	$objSmarty->assign('author','rsureshit@hotmail.com');
	$objSmarty->assign('document-state','dynamic');
	$objSmarty->assign('address',$config['SiteGlobalPath']); 
	$objSmarty->assign('LeftTpl', 'left.tpl');
	$objSmarty->display('pagetemplate.tpl');

?>