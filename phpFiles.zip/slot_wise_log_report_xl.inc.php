<?php

/** Error reporting */
error_reporting(E_ALL);

/** Include PHPExcel */

require('includes/common.php');
require_once('./Connections/ARKAEMS.php');
require_once dirname(__FILE__) . '/Classes/PHPExcel.php';


// Create new PHPExcel object
//echo date('H:i:s') , " Create new PHPExcel object" , EOL;
$objPHPExcel = new PHPExcel();

// Set document properties
//echo date('H:i:s') , " Set document properties" , EOL;
$objPHPExcel->getProperties()->setCreator("Arka Automaations Ltd")
							 ->setLastModifiedBy("Arka Automaations Ltd")
							 ->setTitle("Office 2007 XLSX Test Document")
							 ->setSubject("Office 2007 XLSX Test Document")
							 ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
							 ->setKeywords("office 2007 openxml php")
							 ->setCategory("Test result file");



// Create a first sheet, representing sales data
//echo date('H:i:s') , " Add some data" , EOL;

// ********************************************Get Url Data ********************************************************
 //echo $macid;
$gatewayCode = base64_decode($_GET['gatewayCode']);
$sensorCode = base64_decode($_GET['sensorCode']);


$fdate = date("d-M-Y", strtotime($_GET['date1'])); 
$tdate = date("d-M-Y", strtotime($_GET['date2'])); 

$objPHPExcel->setActiveSheetIndex(0);
$objPHPExcel->getActiveSheet()->mergeCells('A3:F3');
$objPHPExcel->getActiveSheet()->setCellValue('A3', 'Slot Wise Log Report');
$objPHPExcel->getActiveSheet()->getStyle('A3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFont()->setSize(18);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFill()->getStartColor()->setARGB('FF1E90FF');

$objPHPExcel->getActiveSheet()->mergeCells('A1:B1');
$objPHPExcel->getActiveSheet()->setCellValue('A1', ' From Date:');
$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('C1', $fdate);
$objPHPExcel->getActiveSheet()->getStyle('C1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->mergeCells('D1:E1');
$objPHPExcel->getActiveSheet()->setCellValue('D1', 'To Date :');
$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('D1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('F1', $tdate);
$objPHPExcel->getActiveSheet()->getStyle('F1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setSize(12);

	$query1 = 'SELECT arka_company_master.companyName,arka_branch_master.branch_name,arka_sensor_master.gateway_id,arka_sensor_master.sensorCode,arka_sensor_master.sensorModel,arka_sensor_master.sensorName FROM arka_company_master,arka_branch_master,arka_sensor_master WHERE arka_sensor_master.gateway_id="'.base64_decode($_GET["gatewayCode"]).'" AND arka_sensor_master.sensorCode="'.base64_decode($_GET["sensorCode"]).'" AND arka_sensor_master.company_id=arka_company_master.slNo AND arka_branch_master.company_id=arka_sensor_master.company_id AND arka_branch_master.company_id=arka_company_master.slNo AND arka_branch_master.sl_no=arka_sensor_master.branch_id';
	$recset1 = mysql_query($query1, $arkaerp) or die(mysql_error());
	$row1 = mysql_fetch_assoc($recset1);
	$companyName = $row1['companyName'];
	$branchName = $row1['branch_name'];
	$gatewayCode2 = $row1['gateway_id'];
	$sensorCode2 = $row1['sensorCode'];
	$sensorName = $row1['sensorName'];
	
$objPHPExcel->getActiveSheet()->mergeCells('A4:B4');
$objPHPExcel->getActiveSheet()->setCellValue('A4', 'Branch :');
$objPHPExcel->getActiveSheet()->getStyle('A4')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A4')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('C4', $branchName);
$objPHPExcel->getActiveSheet()->getStyle('C4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('C4')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('D4', 'Place Of installation :');
$objPHPExcel->getActiveSheet()->getStyle('D4')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('D4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D4')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->mergeCells('E4:F4');
$objPHPExcel->getActiveSheet()->setCellValue('E4', $sensorName);
$objPHPExcel->getActiveSheet()->getStyle('E4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('E4')->getFont()->setSize(12);



			$objPHPExcel->getActiveSheet()->setCellValue('A5', 'Date');
			$objPHPExcel->getActiveSheet()->setCellValue('B5', 'C1 Kwh');
			$objPHPExcel->getActiveSheet()->setCellValue('C5', 'C2 Kwh');
			$objPHPExcel->getActiveSheet()->setCellValue('D5', 'C3 Kwh');
			$objPHPExcel->getActiveSheet()->setCellValue('E5', 'C4 Kwh');
			$objPHPExcel->getActiveSheet()->setCellValue('F5', 'Cumulative Kwh');

			
			mysql_select_db($database_arkaems, $arkaerp);

if(isset($_GET['date1']) && isset($_GET['date2']))
		{
		   $date1 = $_GET['date1'];
		   $date2 = $_GET['date2'];
		   $date1 = date("Y-m-d", strtotime($_GET['date1'])); 
           $date2 = date("Y-m-d", strtotime($_GET['date2'])); 
           
			//mysql_select_db($database_arkaems, $arkaerp);
		$query_rs1 =  "SELECT * FROM  cron_slot_wise_energy_data WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."'  AND recorded_date < NOW() AND (DATE(recorded_date) BETWEEN '".$date1."' AND '".$date2."') ORDER BY recorded_date DESC";
		
		}
		else
		{
		//	mysql_select_db($database_arkaems, $arkaerp);
			$query_rs1 = "SELECT * FROM  cron_slot_wise_energy_data WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND MONTH(recorded_date) = MONTH(NOW()) AND recorded_date <= DATE(NOW())  ORDER BY recorded_date DESC";
		}
       
		$mt2 = mysql_query($query_rs1, $arkaerp) or die(mysql_error());
//$recNumRow= mysql_num_rows($query_rs1);
	$sumC1KWH =0;
	$sumC2KWH =0;
	$C3KWH =0;
	$sumC3KWH =0;
	$sumC4KWH = 0;
	$cumKWH =0;
	$SumCumKWH =0;

$loop =6;
while( $row2 = mysql_fetch_array($mt2) ) {
    
   

	
 
    
    $orgDate = $row2['recorded_date'];  
    $newDate = date("d-M-Y", strtotime($orgDate)); 
	$sumC1KWH = $sumC1KWH+ $row2['c1_consuption_kwh'];
	$sumC2KWH = $sumC2KWH+$row2['c2_consuption_kwh'];
	$C3KWH = $row2['c3_1_consuption_kwh']+$row2['c3_2_consuption_kwh'];
	$sumC3KWH = $sumC3KWH+$C3KWH;
	$sumC4KWH = $sumC4KWH+$row2['c4_consuption_kwh'];
	$cumKWH =$row2['c1_consuption_kwh']+$row2['c2_consuption_kwh']+$C3KWH+$row2['c4_consuption_kwh'];
	$SumCumKWH =$SumCumKWH+$cumKWH;

	
							$objPHPExcel->getActiveSheet()->setCellValue('A' . $loop, $newDate);
							$objPHPExcel->getActiveSheet()->setCellValue('B' . $loop, round($row2['c1_consuption_kwh'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('C' . $loop, round($row2['c2_consuption_kwh'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('D' . $loop, round($C3KWH,2));
							$objPHPExcel->getActiveSheet()->setCellValue('E' . $loop, round($row2['c4_consuption_kwh'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('F' . $loop, round($cumKWH,2));
							$loop = $loop+1;
						}
			$objPHPExcel->getActiveSheet()->setCellValue('A' . $loop, 'Cumulative Kwh');
            $objPHPExcel->getActiveSheet()->getStyle('A' . $loop)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
			$objPHPExcel->getActiveSheet()->setCellValue('B' . $loop, $sumC1KWH);
			$objPHPExcel->getActiveSheet()->setCellValue('C' . $loop, $sumC2KWH);
			$objPHPExcel->getActiveSheet()->setCellValue('D' . $loop, $sumC3KWH);
			$objPHPExcel->getActiveSheet()->setCellValue('E' . $loop, $sumC4KWH);
			$objPHPExcel->getActiveSheet()->setCellValue('F' . $loop, $SumCumKWH);


			
					


$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);




$objPHPExcel->getActiveSheet()->getStyle('G3')->getFont()->setSize(14);
$objPHPExcel->getActiveSheet()->getStyle('G3')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('B5')->getAlignment()->setShrinkToFit(true);

// Set thin black border outline around column
//echo date('H:i:s') , " Set thin black border outline around column" , EOL;
$styleThinBlackBorderOutline = array(
	'borders' => array(
		'outline' => array(
			'style' => PHPExcel_Style_Border::BORDER_THIN,
			'color' => array('argb' => 'FF000000'),
		),
	),
);
$objPHPExcel->getActiveSheet()->getStyle('A5:F'.$loop)->applyFromArray($styleThinBlackBorderOutline);


// Set thick brown border outline around "Total"
//echo date('H:i:s') , " Set thick brown border outline around Total" , EOL;
$styleThickBrownBorderOutline = array(
	'borders' => array(
		'outline' => array(
			'style' => PHPExcel_Style_Border::BORDER_THICK,
			'color' => array('argb' => 'FF993300'),
		),
	),
);
//$objPHPExcel->getActiveSheet()->getStyle('D13:E13')->applyFromArray($styleThickBrownBorderOutline);

// Set fills

//echo date('H:i:s') , " Set fills" , EOL;
$objPHPExcel->getActiveSheet()->getStyle('A5:F5')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A5:F5')->getFill()->getStartColor()->setARGB('FFFF8C00');
$objPHPExcel->getActiveSheet()->getStyle('A4:F4')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A4:F4')->getFill()->getStartColor()->setARGB('FF5F9EA0');
// Set style for header row using alternative method
//echo date('H:i:s') , " Set style for header row using alternative method" , EOL;

$objPHPExcel->getActiveSheet()->getStyle('A5')->applyFromArray(
		array(
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
			),
			'borders' => array(
				'left'     => array(
 					'style' => PHPExcel_Style_Border::BORDER_THIN
 				)
			)
		)
);

$objPHPExcel->getActiveSheet()->getStyle('B5')->applyFromArray(
		array(
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
			)
		)
);

$objPHPExcel->getActiveSheet()->getStyle('L5')->applyFromArray(
		array(
			'borders' => array(
				'right'     => array(
 					'style' => PHPExcel_Style_Border::BORDER_THIN
 				)
			)
		)
);

// Unprotect a cell
//echo date('H:i:s') , " Unprotect a cell" , EOL;
$objPHPExcel->getActiveSheet()->getStyle('B1')->getProtection()->setLocked(PHPExcel_Style_Protection::PROTECTION_UNPROTECTED);

// Add a hyperlink to the sheet
$loop =$loop+2;
//echo date('H:i:s') , " Add a hyperlink to the sheet" , EOL;
$objPHPExcel->getActiveSheet()->setCellValue('B' . $loop, '');
$objPHPExcel->getActiveSheet()->getCell('B'  . $loop)->getHyperlink()->setUrl('http://ems.arkaautomaations.com');
$objPHPExcel->getActiveSheet()->getCell('B' . $loop)->getHyperlink()->setTooltip('Navigate to website');
$objPHPExcel->getActiveSheet()->getStyle('B' . $loop)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
$loop =$loop+1;
$objPHPExcel->getActiveSheet()->setCellValue('B'  . $loop, '');
//$objPHPExcel->getActiveSheet()->getCell('B' . $loop)->getHyperlink()->setUrl("sheet://'Terms and conditions'!A1");
//$objPHPExcel->getActiveSheet()->getCell('B'  . $loop)->getHyperlink()->setTooltip('Review terms and conditions');
$objPHPExcel->getActiveSheet()->getStyle('B' . $loop)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);


// Play around with inserting and removing rows and columns
//echo date('H:i:s') , " Play around with inserting and removing rows and columns" , EOL;
$objPHPExcel->getActiveSheet()->insertNewRowBefore(6, 10);
$objPHPExcel->getActiveSheet()->removeRow(6, 10);
$objPHPExcel->getActiveSheet()->insertNewColumnBefore('E', 5);
$objPHPExcel->getActiveSheet()->removeColumn('E', 5);

// Set header and footer. When no different headers for odd/even are used, odd header is assumed.
//echo date('H:i:s') , " Set header/footer" , EOL;
$objPHPExcel->getActiveSheet()->getHeaderFooter()->setOddHeader('&L&BInvoice&RPrinted on &D');
$objPHPExcel->getActiveSheet()->getHeaderFooter()->setOddFooter('&L&B' . $objPHPExcel->getProperties()->getTitle() . '&RPage &P of &N');

// Set page orientation and size
//echo date('H:i:s') , " Set page orientation and size" , EOL;
$objPHPExcel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
$objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);

// Rename first worksheet
//echo date('H:i:s') , " Rename first worksheet" , EOL;
$objPHPExcel->getActiveSheet()->setTitle('Meter Log Report');
