<!DOCTYPE html>
<html>
<body>

<form id="jsonForm">
  Json Input: <input type="text" id="jsonValue" value='[{"ID":"2","apiKey":"R1c6REVWOTU1LTEvU0k6REVWNjQzNS0xL1NNT0RFTDpERVY2NDM1" ,"ST":"100","TS":"1679549217","DT":"06/06/2025 10:56:57","VR":"[23404,23177,23202,23261,40340,40165,40362,40289,24044,23072,23749,23621,0,0,0,5002,854,484,1508,516,8293,5037,9703,2726,2720,2846,4925,4614,4725,5627,5347,5510,0,0,8100,12400,0,0,20753848,5965794,0,0,22068337,140,210,130,50,20,10,20]"},{"ID":"2","apiKey":"R1c6REVWOTU1LTEvU0k6REVWNjQzNS0xL1NNT0RFTDpERVY2NDM1" ,"ST":"200","TS":"1679549218","DT":"06/06/2025 10:56:58","VR":"[350,300,210,300,85,120,40,10,510,130,250,130,30,70,70,20,350,150,220,260,60,110,10,30,420,110,250,150,40,100,50,10,360,60,170,220,50,130,80,0,350,0]"}]'>

  <button type="submit">Submit</button>
</form>

<script>
document.getElementById("jsonForm").addEventListener("submit", function(event){
    event.preventDefault(); // Prevent the form from submitting the traditional way

    var jsonValue = document.getElementById("jsonValue").value;
    var encodedJson = encodeURIComponent(jsonValue);

    // Redirect with JSON data as a query parameter
    window.location.href = 'http://localhost/emsTest/API/postEnergyMeterDataSpecific.php?jsonValue=' + encodedJson;
});
</script>

</body>
</html>
