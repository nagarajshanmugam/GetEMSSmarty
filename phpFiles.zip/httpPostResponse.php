<!DOCTYPE html>
<html>
<body>

<form id="jsonForm">
  Json Input: <input type="text" id="jsonValue" value='[{"ID":"30","apiKey":"R1c6VFJCMTQ1LTQvU0k6RlQzNjAtMS9TTU9ERUw6RlQzNjA=" ,"ST":"1","TS":"1773122025","DT":"10/03/2026 11:23:45","VR":"[2305,352,0,51395,58,0,0,0,0,2,2,32768,0,0,55198,587,0,0,0,0]"}]'>
  <button type="submit">Submit Now</button>
</form>

<script>
function processAndSendJson() {
    const input = document.getElementById("jsonValue").value;
    let jsonData;

    try {
        jsonData = JSON.parse(input.replace(/\\\"/g, '"'));
    } catch (e) {
        alert("Invalid JSON format!");
        return;
    }

    jsonData.forEach(obj => {
        let vrArray = JSON.parse(obj.VR);
        vrArray = vrArray.map(val => val + 20); // This line for incrementing 20 for all values in each submit action
        vrArray = vrArray.map(val => val);
        obj.VR = JSON.stringify(vrArray);
    });

    const finalJson = JSON.stringify(jsonData);

   // ✅ Update the input field so next run uses updated data
    document.getElementById("jsonValue").value = finalJson;

    // Send JSON using AJAX POST
    fetch('https://ems.greatelephanttech.com/API/postEnergyMeterDataSpecific.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: 'jsonValue=' + encodeURIComponent(finalJson)
    })
    .then(response => response.text())
    .then(result => {
        alert("Response: " + result); // Or redirect if needed
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

document.getElementById("jsonForm").addEventListener("submit", function(event){
    event.preventDefault();
    processAndSendJson();
});

// Auto-run every 1 minute
setInterval(processAndSendJson, 60000);
</script>

</body>
</html>
