<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.gatewayModel.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";
	
		$objStaff		= new Staff();
		$objStaff -> GetCompanyName($objArray);
		$objStaff->RolesLists();
		$objgatewayModel		= new gatewayModel();		
		
		if(isset($_POST['hdAction']) && !isset($_GET['Update'])){
			$objgatewayModel -> InsertGatewayModel($_POST);
		}
		if(isset($_GET['Update']) && isset($_GET['slNo']))
		{
			$objgatewayModel -> ListEditView($objArray);
		}
		if(isset($_GET['Update']) && isset($_GET['slNo']) && isset($_POST['hdAction']))
		{
			$objgatewayModel -> EditGatewayModel($_POST);
		}
		
		$objSmarty->assign('IncludeTpl', 'addEditGatewayModel.tpl');
		$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Gateway Model Reg');
		$objSmarty->assign('robots','index,follow');
		$objSmarty->assign('key_word','');
		$objSmarty->assign('generator','');
		$objSmarty->assign('document-state','dynamic');
		$objSmarty->assign('address',$config['SiteGlobalPath']);
		
		/*Display page*/
		$objSmarty->assign('LeftTpl', 'left.tpl');
		$objSmarty->display('pagetemplate.tpl');

?>