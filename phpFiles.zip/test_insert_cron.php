<?php

/*
  Rui Santos
  Complete project details at https://RandomNerdTutorials.com/esp32-esp8266-mysql-database-php/
  
  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files.
  
  The above copyright notice and this permission notice shall be included in all
  copies or substantial portions of the Software.
*/
	 header('Access-Control-Allow-Origin: *'); 
    header("Access-Control-Allow-Credentials: true");
    header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
    header('Access-Control-Max-Age: 1000');
    header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');

//require_once('./Connections/ARKAEMS.php'); 
$servername = "148.66.130.228";

// REPLACE with your Database name
$dbname = "univa_ems";
// REPLACE with Database user
$username = "univa_ems_user";
// REPLACE with Database user password
$password = "Un!v@2022";
 
//exit;


// Keep this API Key value to be compatible with the ESP32 code provided in the project page. 
// If you change this value, the ESP32 sketch needs to match
//$api_key_value = "arkatemp1001";

//$api_key= $sensor = $location = $value1 = "";
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

    
  
   echo  $sql = "INSERT INTO test_table(test_name) VALUES ('Cron Test')";
        $insSel = $conn->query($sql);
        if($inSel)
        {
             echo "Data Inserted Successfully.";
        }
     

?>