<?php
require('includes/common.php');
	
 	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.CronData.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";
	
	$objStaff		= new Staff();
	$objStaff->RolesLists();
	$objStaff -> GetCompanyName();
	$objCronData = new CronData();
	/***command by shanmugakani**/
//	$objCronData -> GetCompanyName();

	$objCronData -> ListInvoice($objArray);
	if(isset($_GET['gId']) && isset($_GET['CId']) && isset($_GET['BId']))
	{   
	$objCronData->ListInvoice($_GET['gId'],$_GET['CId'],$_GET['BId']);
	}
	$objCronData -> sensorList($objArray);
	$objCronData -> GetBranchName($objArray);
	$objCronData -> GetGatewayName($objArray);
	
	if(isset($_GET['MId']) && isset($_GET['CId']) && isset($_GET['BId']))
	{   
	$objCronData->CreateInvoice($_GET['MId'],$_GET['CId'],$_GET['BId']);
	}
	
	if(isset($_GET['succs_msg_for_del']))
    {
    $objSmarty->assign('SuccessMessage', 'Record Deleted Successfully');
    }
    if(isset($_GET['success_msg_for_update']))
    {
    $objSmarty->assign('SuccessMessage', 'Record Updated Successfully');
    }
	if(isset($_GET['success_msg_for_insert']))
    {
    $objSmarty->assign('SuccessMessage', 'Record Created Successfully');
    }
    if(isset($_GET['dId']))
	{   
	$objCronData->DeleteInvoiceMaster($_GET['dId']);
	}
	
	$objSmarty->assign('IncludeTpl', 'listInvoice.tpl');
	$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Billing List');
	$objSmarty->assign('robots','index,follow');
	$objSmarty->assign('key_word','');
	$objSmarty->assign('generator','');
	//$objSmarty->assign('author','rsureshit@hotmail.com');
	$objSmarty->assign('document-state','dynamic');
	$objSmarty->assign('address',$config['SiteGlobalPath']);
	
 
 /*$objSmarty->assign('IncludeJS', 
    '<script src="' . $config['SiteGlobalPath'] . 'plugins/jquery/jquery.min.js"></script>'. "\n" .
    '<script src="' . $config['SiteGlobalPath'] . 'plugins/bootstrap/js/bootstrap.bundle.min.js"></script>'. "\n" .
    '<script src="' . $config['SiteGlobalPath'] . 'dist/js/adminlte.min.js"></script>'. "\n" .
    '<script src="' . $config['SiteGlobalPath'] . 'dist/js/demo.js"></script>'); 
 
  $objSmarty->assign('IncludeCSS', 
    '<link href="' . $config['SiteGlobalPath'] . 'plugins/fontawesome-free/css/all.min.css" rel="stylesheet">'. "\n" .
    '<link href="' . $config['SiteGlobalPath'] . 'dist/css/adminlte.min.css" rel="stylesheet">'. "\n" .
    '<link href="' . $config['SiteGlobalPath'] . '/dist/css/ionicons.min.css" rel="stylesheet">'. "\n" .
    '<link href="' . $config['SiteGlobalPath'] . '/dist/css/fontsgoogleapis.css" rel="stylesheet">'); */
 
 
 
 
 
 
 
 
 
 /*Display page*/
  //$objSmarty->assign('HeaderTpl', 'header.tpl');
   $objSmarty->assign('LeftTpl', 'left.tpl');
  //$objSmarty->assign('FooterTpl', 'footer.tpl');  
  $objSmarty->display('pagetemplate.tpl');

?>