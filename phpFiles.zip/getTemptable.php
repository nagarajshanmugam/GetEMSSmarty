<?php
include('config.php');
session_start();
date_default_timezone_set('Asia/Kolkata');
$hostname_arkaerp = $config['DBHost'];
$database_arkaerp = $config['DBName'];
$username_arkaerp = $config['DBUser'];
$password_arkaerp = $config['DBPassword'];
$arkaerp = mysql_connect($hostname_arkaerp, $username_arkaerp, $password_arkaerp,$database_arkaerp) or trigger_error(mysql_error(),E_USER_ERROR);

mysql_select_db($database_arkaerp,$arkaerp);
$cid=$_REQUEST['cid'];
$bid=$_REQUEST['bid'];
//echo $cid;
if($cid != '')
{
$comId = base64_decode($_REQUEST['cid']);
}	
else
{
$comId = $_SESSION['CustomerId'];
}
if($bid != '')
{
$branchId = base64_decode($_REQUEST['bid']);
}	
else
{
$branchId = $_SESSION['branch_id'];
}

function secondsToDhmss($seconds) {
//$seconds = Number($seconds);
$d = floor($seconds / (3600*24));
$h = floor($seconds % (3600*24) / 3600);
$m = floor($seconds % 3600 / 60);
$s = floor($seconds % 60);

if($d > 0 )
{
if( $d == 1)
{
$dDisplay = $d .' day, ';
}
else
{
$dDisplay = $d .' days, ';
}
}
else
{
$dDisplay = '';
}
if($h > 0 )
{
if( $h == 1)
{
$hDisplay = $h .' hrs, ';
}
else
{
$hDisplay = $h .' hrs, ';
}
}
else
{
$hDisplay = '';
}
if($m > 0 )
{
if( $m == 1)
{
$mDisplay = $m .' min, ';
}
else
{
$mDisplay = $m ." min's, ";
}
}
else
{
$mDisplay = '';
}
if($s > 0 )
{
if( $s == 1)
{
$sDisplay = $s .' sec ';
}
else
{
$sDisplay = $s ." sec's ";
}
}
else
{
$sDisplay = '';
}
//$res= 'Last Updated'.$dDisplay .' '. $hDisplay .' '. $mDisplay .' '. $sDisplay;
$res= $dDisplay .' '. $hDisplay .' '. $mDisplay .' '. $sDisplay;
echo $res;
 }
?>   
<link rel="stylesheet" href="plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
<script src="plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<script type="text/javascript">
  $("input[data-bootstrap-switch]").each(function(){
      $(this).bootstrapSwitch('state', $(this).prop('checked'));
    });
	</script>
	
			       <table id="example" class="table table-bordered table-hover">
                <thead>
                <tr>
    			  <th class="slNo" rowspan="2" >#</th>
                  <th class="name" rowspan="2">Place Of Installation</th>
                  <th class="gate" rowspan="2">Gateway</th>
				   <!--<th class="status" rowspan="2">Status</th>-->
                  <th  colspan="2" class="code" >Temperature</th>
                   <th  class="status" rowspan="2">Humidity</th>
                  <th class="action" rowspan="2">Date Time</th>
                  <th class="last" rowspan="2">Last Comm</th>
                  
          
                </tr>
                <tr>
    			 
                  <th class="cost">&deg; C</th>
                  <th class="cost" >&deg; F</th>
                  
                </tr>
                </thead>			                  <tbody>

							  <?php
						
		
             $SelCompanyQuery = 'SELECT companyCode FROM arka_company_master WHERE slNo="'.$comId.'" AND status="1"';   
            $companySource=mysql_query($SelCompanyQuery);//echo $SelCompanyQuery;
            $companyRow = mysql_fetch_array($companySource);
		        $comCode = $companyRow['companyCode'];

		$SelBranchQuery = 'SELECT branch_id FROM arka_branch_master WHERE sl_no="'.$branchId.'" AND record_status="1"';  
     $branchSource=mysql_query($SelBranchQuery);//echo $SelBranchQuery;
            $branchRow = mysql_fetch_array($branchSource);
		        $branchCode = $branchRow['branch_id'];
		//echo "Company Code".$comCode."<br>";
		//echo "Branch Code".$branchCode."<br>"; 
		

		   $SelPlatformMapQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';  
        $platformSource=mysql_query($SelPlatformMapQuery);//echo $SelPlatformMapQuery;
        $platformRow = mysql_fetch_array($platformSource);
        $platformCode = $platformRow['segmentCode'];

			$TempPF = "Temperature";

			$SelTempPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$TempPF.'" AND status="1"';  
       $tempPlatformSource=mysql_query($SelTempPlatformQuery);//echo $SelTempPlatformQuery;
        $tempPlatformRow = mysql_fetch_array($tempPlatformSource);
        $tempSegCode = $tempPlatformRow['segmentCode'];
        $tempSegId = $tempPlatformRow['slNo'];

		
		$dailyTableTemp = $comCode."_".$branchCode."_".$tempSegCode."_cron_daily";

        //echo $dailyTableTemp; exit;
			$selQryIotTemp = 'SELECT * FROM `arka_iot_platform` WHERE segmentName="Temperature" AND status="1"';
       $iotTempSource=mysql_query($selQryIotTemp);//echo $selQryIotTemp;
        $iotTempRow = mysql_fetch_array($iotTempSource);
		    $tempIotId = $iotTempRow['slNo'];
	    
      //echo $tempIotId; exit;


	/*echo"<br><br> selQryS: "; echo */    
		$selQryTemp = 'SELECT arka_sensor_master.*,sensor_model_master.TemHum FROM `arka_sensor_master`,sensor_model_master WHERE arka_sensor_master.isActive=1 AND sensor_model_master.platform_id="3" AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.sensorModel="MD02" GROUP BY arka_sensor_master.sensorCode';
		//echo $selQryTemp; exit;
     $TempQrySource=mysql_query($selQryTemp);//echo $selQryTemp;
       $TempList = array();

while ($tempDetail = mysql_fetch_assoc($TempQrySource))
{
    $result = array();
    $SelSpecificQuery = "";
    $DBSensorTableName = "";

    $feederName      = $tempDetail['sensorName'];
    $gatewayCode     = $tempDetail['gateway_id'];
    $sensorCode      = $tempDetail['sensorCode'];
    $sensorCodeTable = str_replace("-", "_", $sensorCode);

    // Get Sensor Model
    $selModelQry = 'SELECT sl_no, model_id
                    FROM sensor_model_master
                    WHERE model_id = (
                        SELECT sensorModel
                        FROM arka_sensor_master
                        WHERE sensorCode="'.$sensorCode.'"
                        AND company_id="'.$comId.'"
                        AND branch_id="'.$branchId.'"
                        AND status="1"
                    )
                    AND status="1"';

    $modelResult = mysql_query($selModelQry);

    $senModelId = "";
    if($modelResult && mysql_num_rows($modelResult) > 0)
    {
        $modelRow = mysql_fetch_assoc($modelResult);
        $senModelId = $modelRow['sl_no'];
    }

    // Find Sensor Table
    $selTableQry = 'SELECT TABLE_NAME
                    FROM INFORMATION_SCHEMA.TABLES
                    WHERE TABLE_NAME LIKE "'.$comCode.'_'.$branchCode.'\_%_'.$sensorCodeTable.'"';

    $tableResult = mysql_query($selTableQry);

    if($tableResult && mysql_num_rows($tableResult) > 0)
    {
        $tableRow = mysql_fetch_assoc($tableResult);
        $sensorTableName = $tableRow['TABLE_NAME'];

        // Check Recent Data
        $selOffQry = 'SELECT *
                      FROM '.$database_arkaerp.'.'.$sensorTableName.'
                      WHERE status="1"
                      AND sensor_code="'.$sensorCode.'"
                      AND posted_date_time >= DATE_SUB(NOW(), INTERVAL 10 MINUTE)
                      ORDER BY slNo DESC
                      LIMIT 1';

        $offResult = mysql_query($selOffQry);

        $DBSensorTableName = $database_arkaerp.'.'.$sensorTableName;

        $SelSpecificQuery = '
            SELECT
                '.$DBSensorTableName.'.posted_date_time,
                '.$DBSensorTableName.'.sensor_code,
                '.$DBSensorTableName.'.gateway_code,
                '.$DBSensorTableName.'.sensor_model,
                '.$DBSensorTableName.'.temperature_c,
                '.$DBSensorTableName.'.temperature_f,
                '.$DBSensorTableName.'.humidity,
                '.$DBSensorTableName.'.posted_date_time AS TZ,
                arka_sensor_master.sensorName AS feeder_name,
                arka_sensor_master.slNo,
                arka_sensor_master.feeder_type,
                arka_sensor_master.company_id,
                arka_sensor_master.branch_id,
                TIMESTAMPDIFF(SECOND, '.$DBSensorTableName.'.posted_date_time, NOW()) AS secs,
                sensor_model_master.TemHum
            FROM '.$DBSensorTableName.',
                 arka_sensor_master,
                 sensor_model_master
            WHERE '.$DBSensorTableName.'.gateway_code = arka_sensor_master.gateway_id
            AND '.$DBSensorTableName.'.sensor_code = arka_sensor_master.sensorCode
            AND arka_sensor_master.company_id="'.$comId.'"
            AND arka_sensor_master.branch_id="'.$branchId.'"
            AND arka_sensor_master.isActive="1"
            AND arka_sensor_master.status="1"
            AND '.$DBSensorTableName.'.status="1"
            AND sensor_model_master.model_id = arka_sensor_master.sensorModel
            ORDER BY '.$DBSensorTableName.'.slNo DESC
            LIMIT 1';

        $specificResult = mysql_query($SelSpecificQuery);

        if($specificResult && mysql_num_rows($specificResult) > 0)
        {
            while($row = mysql_fetch_assoc($specificResult))
            {
                $row['sensor_table'] = $DBSensorTableName;
                $result[] = $row;
            }
        }
    }

    if(!empty($result))
    {
        $TempList[] = $result[0];
    }
    else
    {
        $TempList[] = array(
            'posted_date_time' => '',
            'sensor_code'      => $sensorCode,
            'gateway_code'     => $gatewayCode,
            'sensor_model'     => $tempDetail['sensorModel'],
            'temperature_c'    => '',
            'temperature_f'    => '',
            'humidity'         => '',
            'TZ'               => '',
            'feeder_name'      => $feederName,
            'slNo'             => $tempDetail['slNo'],
            'feeder_type'      => $tempDetail['feeder_type'],
            'company_id'       => $comId,
            'branch_id'        => $branchId,
            'secs'             => '',
            'TemHum'           => $tempDetail['TemHum'],
            'sensor_table'     => $DBSensorTableName
        );
    }
}
// echo "<pre>";
// print_r($TempList);
// echo "</pre>";



$i=1;	
								foreach($TempList as $step)
{
							
							$pid=$step['slNo'];
							    ?>
                                  <tr>
                 <td><?php echo $i;?></td><?php
                 $SelQuery = 'SELECT * FROM `arka_sensor_master` WHERE arka_sensor_master.isActive=1 AND arka_sensor_master.company_id="'.$comId.'" AND arka_sensor_master.branch_id="'.$branchId.'" AND arka_sensor_master.feeder_type="Sub Meter" GROUP BY sensorCode';
                  $source6=mysql_query($SelQuery);//echo $SelQuery;
                 	?>
				  <td><a href="DashboardTemperature.php?companyId=<?php echo base64_encode($comId);?>&branchId=<?php echo base64_encode($branchId);?>&sensorCode=<?php echo base64_encode($step['sensor_code']);?>&gatewayCode=<?php echo base64_encode($step['gateway_code']);?>" style="color:#000000;text-decoration:underline;" title="Meter Details"><?php echo $step['feeder_name'];?></a>&ensp;&ensp;<?php while($step6=mysql_fetch_array($source6))
					{  if($step['feeder_type'] == "Main Meter" && $step['slNo'] == $step6['parent_id']){ ?><a href="subdashboard.php?parent_id=<?php echo  base64_encode($pid);?>&companyId=<?php echo base64_encode($comId);?>&branchId=<?php echo base64_encode($branchId); ?>"><i class="fa fa-sitemap" aria-hidden="true" title="Submeter List"></i></a><?php } ?><?php } ?></td>
                 <td ><?php echo $step['gateway_code'];?></td>
                
				<?php if($step['TemHum'] == "Both") {?>
                <td align="right"><?php echo (!empty($step['temperature_c'])) ? $step['temperature_c'] : '-'; ?></td>
                    <td align="right"><?php echo (!empty($step['temperature_f'])) ? $step['temperature_f'] : '-'; ?></td>
                    <td align="right"><?php echo $step['humidity'];?></td>
            <?php }elseif($step['TemHum'] == "Temperature"){ ?>
			       <td align="right"><?php echo (!empty($step['temperature_c'])) ? $step['temperature_c'] : '-'; ?></td>
                    <td align="right"><?php echo (!empty($step['temperature_f'])) ? $step['temperature_f'] : '-'; ?></td>
                    <td align="right"><?php echo '-';?></td>
			<?php }elseif($step['TemHum'] == "Humidity"){ ?>
			               <td align="right"><?php echo '-';?></td>
                    <td align="right"><?php echo '-';?></td>
                    <td align="right"><?php echo (!empty($step['humidity'])) ? $step['humidity'] : '-'; ?></td>
			  <?php }?>
			  <td><?php echo (!empty($step['posted_date_time']) && $step['posted_date_time'] != '0000-00-00 00:00:00')
        ? date("d-M-Y h:i:s A", strtotime($step['posted_date_time']))
        : '-';?></td>
                 <td><?php echo secondsToDhmss($step['secs']);echo " ";echo "ago";?></td>
                    
                                 </tr>
			                    	<?php 
                                 $i=$i+1;
								
								}

                
									?>
									
        					

								
			                  </tbody>
			                </table>

 <style>
 .slNo
 {
 width:3%;
 }
 .name
 {
 width:18%;
 }
 .gate
 {
 width:10%;
 }
 .status
 {
 width:5%;
 }
 .code
 {
 width:10%;
 }
 .cost
 {
 width:5%;
 }
 .action
 {
 width:15%;
 }
  .last
 {
 width:11%;
 }
 .uline
 {
 text-decoration:underline;
 }
 </style>




			     