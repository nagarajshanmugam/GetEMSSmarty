<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.LocationMaster.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";
	
		$objStaff		= new Staff();
		$objStaff -> GetCompanyName($objArray);
		$objLocationMaster		= new LocationMaster();
		$objStaff->RolesLists();
		$objLocationMaster -> ListLocation($objArray);
		$objLocationMaster -> ListBranch($objArray);
		
		
		if(isset($_GET['locId']))
		{   
			$objLocationMaster->DeleteLocationMaster($_GET['locId']);
		}
		if(isset($_GET['succs_msg_for_del']))
		{
			$objSmarty->assign('SuccessMessage', 'Record Deleted Successfully');
		}
		if(isset($_GET['success_msg_for_update']))
		{
			$objSmarty->assign('SuccessMessage', 'Record Updated Successfully');
		}
		if(isset($_GET['success_msg_for_insert']))
		{
			$objSmarty->assign('SuccessMessage', 'Record Created Successfully');
		}
	
		$objSmarty->assign('IncludeTpl', 'locationList.tpl');
		$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Location Reg');
		$objSmarty->assign('robots','index,follow');
		$objSmarty->assign('key_word','');
		$objSmarty->assign('generator','');
		$objSmarty->assign('document-state','dynamic');
		$objSmarty->assign('address',$config['SiteGlobalPath']);

		/*Display page*/
		$objSmarty->assign('LeftTpl', 'left.tpl');
		$objSmarty->display('pagetemplate.tpl');
	
?>