<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.SensorMaster.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";
	
		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objStaff -> GetCompanyName();
		$objSensorMaster	= new SensorMaster();
		$objSensorMaster -> ListSensor($objArray);
		$objSensorMaster -> ListEditView($objArray);
		$objSensorMaster -> ListCompany($objArray);
		$objSensorMaster -> ListSensorModel();
		$objSensorMaster -> ListPlatform();
		$objSensorMaster -> GetGatewayName($objArray);
		//$objSensorMaster -> GetBranchName($objArray);
		$objSensorMaster -> ListFeederForm($objArray);
		
		if(isset($_POST['hdAction']) && !isset($_GET['Update']))
		{
		$objSensorMaster -> InsertSensor($_POST);
		}
		if(isset($_GET['Update']) && isset($_GET['sensor_id']) && isset($_POST['hdAction'])){
		$objSensorMaster -> EditSensor($_POST);
		}
	
		$objSmarty->assign('IncludeTpl', 'sensorMasterAddEdit.tpl');
		$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Location Reg');
		$objSmarty->assign('robots','index,follow');
		$objSmarty->assign('key_word','');
		$objSmarty->assign('generator','');
		$objSmarty->assign('document-state','dynamic');
		$objSmarty->assign('address',$config['SiteGlobalPath']);
		
		
		/*Display page*/
		$objSmarty->assign('LeftTpl', 'left.tpl');
		$objSmarty->display('pagetemplate.tpl');

?>