<?php 
include('config.php');
$hostname_arkaerp = $config['DBHost'];
$database_arkaerp = $config['DBName'];
$username_arkaerp = $config['DBUser'];
$password_arkaerp = $config['DBPassword'];
$tbl = $config['DBPrefix'];
$arkaerp = mysql_connect($hostname_arkaerp, $username_arkaerp, $password_arkaerp,$database_arkaerp) or trigger_error(mysql_error(),E_USER_ERROR);
mysql_select_db($database_arkaerp,$arkaerp);
$branchid = 0;

if(isset($_REQUEST['branch']))
{
$branchid = mysql_real_escape_string($_REQUEST['branch']); // department id
}
if(isset($_REQUEST['company']))
{
$companyid = mysql_real_escape_string($_REQUEST['company']); // department id
}

$users_arr = array();

if($branchid > 0){

$sensorSel = "SELECT shift_master_id,shift_name,start_time,end_time FROM ".$tbl."branch_shift_master WHERE status='1' AND is_active='1' AND company_id='".$companyid."' AND branch_id='".$branchid."'";//echo $sensorSel;
$sensorList = mysql_query($sensorSel,$arkaerp);
}
else
{
$sensorSel = "SELECT shift_master_id,shift_name,start_time,end_time FROM ".$tbl."branch_shift_master WHERE status='1' AND is_active='1' AND company_id='".$companyid."'";//echo $sensorSel;
$sensorList = mysql_query($sensorSel,$arkaerp);
}
   while( $row = mysql_fetch_array($sensorList) ){
      $slNo = $row['shift_master_id'];
      $shiftName = $row['shift_name'];
      $starttime = $row['start_time'];
      $endtime = $row['end_time'];
      $users_arr[] = array("id" => $slNo, "name" => $shiftName, "stime" => $starttime, "etime" => $endtime);
   }
// encoding array to json format
echo json_encode($users_arr);