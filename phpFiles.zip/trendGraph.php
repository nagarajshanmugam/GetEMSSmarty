<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.Dashboard.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";	
	
		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objStaff->GetCompanyName();
		$objDashBoard	= new Dashboard();
		//$objDashBoard->GetSegmentsList();
        //$objDashBoard->GetTemperature();
		
		$objSmarty->assign('fdate', $_POST['date1']);
		$objSmarty->assign('tdate', $_POST['date2']);
		$senMod =  explode("-",base64_decode($_GET['sensorCode'])); 
		
		if($senMod[0]=="RGA20S"){
		$objDashBoard->GetPowerMeterLogGraph();
		}
		else
		{
		//$objDashBoard->GetMeterLogGraph();
		//$objDashBoard->GetSpecificMeterLogGraph();
		$objDashBoard->DashGetSpecificMeterLogGraph();
		}
		$objSmarty->assign('IncludeTpl','trendGraph.tpl');
		$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- ARKA RMS');
		$objSmarty->assign('robots','index,follow');
		$objSmarty->assign('key_word','');
		$objSmarty->assign('generator','');
		$objSmarty->assign('document-state','dynamic');
		$objSmarty->assign('address',$config['SiteGlobalPath']); 
		
		$objSmarty->assign('IncludeJS', 
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/jquery/jquery.min.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/jquery-ui/jquery-ui.min.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/bootstrap/js/bootstrap.bundle.min.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/chart.js/Chart.min.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/sparklines/sparkline.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/jqvmap/jquery.vmap.min.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/jqvmap/maps/jquery.vmap.usa.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/jquery-knob/jquery.knob.min.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/moment/moment.min.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/daterangepicker/daterangepicker.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/summernote/summernote-bs4.min.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'dist/js/adminlte.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'dist/js/pages/dashboard.js"></script>'. "\n" .
		'<script src="' . $config['SiteGlobalPath'] . 'dist/js/demo.js"></script>');
		
		$objSmarty->assign('IncludeCSS', 
		'<link rel="stylesheet" href="' . $config['SiteGlobalPath'] . 'plugins/fontawesome-free/css/all.min.css">'. "\n" .
		'<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">'. "\n" .
		'<link rel="stylesheet" href="' . $config['SiteGlobalPath'] . 'plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">'. "\n" .
		'<link rel="stylesheet" href="' . $config['SiteGlobalPath'] . 'plugins/icheck-bootstrap/icheck-bootstrap.min.css">'. "\n" .
		'<link rel="stylesheet" href="' . $config['SiteGlobalPath'] . 'plugins/jqvmap/jqvmap.min.css">'. "\n" .
		'<link rel="stylesheet" href="' . $config['SiteGlobalPath'] . 'dist/css/adminlte.min.css">'. "\n" .
		'<link rel="stylesheet" href="' . $config['SiteGlobalPath'] . 'plugins/overlayScrollbars/css/OverlayScrollbars.min.css">'. "\n" .
		'<link rel="stylesheet" href="' . $config['SiteGlobalPath'] . 'plugins/daterangepicker/daterangepicker.css">'. "\n" .
		'<link rel="stylesheet" href="' . $config['SiteGlobalPath'] . 'plugins/summernote/summernote-bs4.css">'. "\n" .
		'<link rel="stylesheet" href="' . $config['SiteGlobalPath'] . 'dist/css/styleems.css">'. "\n" .
		'<link rel="stylesheet" href="' . $config['SiteGlobalPath'] . 'dist/css/fontsgoogleapis.css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">'. "\n" .
		'<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">');
		
		/*Display page*/
		$objSmarty->display('pagetemplate.tpl');
?>