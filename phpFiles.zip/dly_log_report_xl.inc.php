<?php

/** Error reporting */
error_reporting(E_ALL);

/** Include PHPExcel */

require('includes/common.php');
require_once('./Connections/ARKAEMS.php');
require_once dirname(__FILE__) . '/Classes/PHPExcel.php';


// Create new PHPExcel object
//echo date('H:i:s') , " Create new PHPExcel object" , EOL;
$objPHPExcel = new PHPExcel();

// Set document properties
//echo date('H:i:s') , " Set document properties" , EOL;
$objPHPExcel->getProperties()->setCreator("Arka Automaations Ltd")
							 ->setLastModifiedBy("Arka Automaations Ltd")
							 ->setTitle("Office 2007 XLSX Test Document")
							 ->setSubject("Office 2007 XLSX Test Document")
							 ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
							 ->setKeywords("office 2007 openxml php")
							 ->setCategory("Test result file");



// Create a first sheet, representing sales data
//echo date('H:i:s') , " Add some data" , EOL;

// ********************************************Get Url Data ********************************************************
 //echo $macid;
$gatewayCode = base64_decode($_GET['gatewayCode']);
$sensorCode = base64_decode($_GET['sensorCode']);
$nowDate= "NOW()";

$fdate = date("d-M-Y", strtotime($_GET['date1'])); 
$tdate = date("d-M-Y", strtotime($_GET['date2'])); 

$objPHPExcel->setActiveSheetIndex(0);
$objPHPExcel->getActiveSheet()->mergeCells('A3:F3');
$objPHPExcel->getActiveSheet()->setCellValue('A3', 'Daily Log Report');
$objPHPExcel->getActiveSheet()->getStyle('A3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFont()->setSize(18);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A3')->getFill()->getStartColor()->setARGB('FF1E90FF');

$objPHPExcel->getActiveSheet()->mergeCells('A1:B1');
$objPHPExcel->getActiveSheet()->setCellValue('A1', ' From Date:');
$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('C1', $fdate);
$objPHPExcel->getActiveSheet()->getStyle('C1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->mergeCells('D1:E1');
$objPHPExcel->getActiveSheet()->setCellValue('D1', 'To Date :');
$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('D1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('F1', $tdate);
$objPHPExcel->getActiveSheet()->getStyle('F1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setSize(12);

	$query1 = 'SELECT arka_company_master.companyName,arka_company_master.slNo,arka_branch_master.branch_name,arka_branch_master.sl_no,arka_sensor_master.gateway_id,arka_sensor_master.sensorCode,arka_sensor_master.sensorModel,arka_sensor_master.sensorName FROM arka_company_master,arka_branch_master,arka_sensor_master WHERE arka_sensor_master.gateway_id="'.base64_decode($_GET["gatewayCode"]).'" AND arka_sensor_master.sensorCode="'.base64_decode($_GET["sensorCode"]).'" AND arka_sensor_master.company_id=arka_company_master.slNo AND arka_branch_master.company_id=arka_sensor_master.company_id AND arka_branch_master.company_id=arka_company_master.slNo AND arka_branch_master.sl_no=arka_sensor_master.branch_id';
	$recset1 = mysql_query($query1, $arkaerp) or die(mysql_error());
	$row1 = mysql_fetch_assoc($recset1);
	$companyName = $row1['companyName'];
	$branchName = $row1['branch_name'];
	$gatewayCode2 = $row1['gateway_id'];
	$sensorCode2 = $row1['sensorCode'];
	$sensorName = $row1['sensorName'];
	$comId= $row1['slNo'];
	$branchId=$row1['sl_no'];
	
$objPHPExcel->getActiveSheet()->mergeCells('A4:B4');
$objPHPExcel->getActiveSheet()->setCellValue('A4', 'Branch :');
$objPHPExcel->getActiveSheet()->getStyle('A4')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A4')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('C4', $branchName);
$objPHPExcel->getActiveSheet()->getStyle('C4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('C4')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->setCellValue('D4', 'Place Of installation :');
$objPHPExcel->getActiveSheet()->getStyle('D4')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('D4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D4')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->mergeCells('E4:F4');
$objPHPExcel->getActiveSheet()->setCellValue('E4', $sensorName);
$objPHPExcel->getActiveSheet()->getStyle('E4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('E4')->getFont()->setSize(12);



			$objPHPExcel->getActiveSheet()->setCellValue('A5', 'Date');
			$objPHPExcel->getActiveSheet()->setCellValue('B5', 'Start Kwh');
			$objPHPExcel->getActiveSheet()->setCellValue('C5', 'End Kwh');
			$objPHPExcel->getActiveSheet()->setCellValue('D5', 'Total Kwh');
			$objPHPExcel->getActiveSheet()->setCellValue('E5', 'Unit Rate');
			$objPHPExcel->getActiveSheet()->setCellValue('F5', 'Total Cost');

			
			mysql_select_db($database_arkaems, $arkaerp);

/*** start query excel ***/
$nowDate= "NOW()";

		$ConfigDBName = $config['DBName'];
		//echo $ConfigDBName; exit;
		 $SelCompanyQuery = 'SELECT companyCode FROM arka_company_master WHERE slNo="'.$comId.'" AND status="1"';  
		$SelCompanyQueryView = mysql_query($SelCompanyQuery, $arkaerp) or die(mysql_error());
	$SelcomCode = mysql_fetch_assoc($SelCompanyQueryView); 
	 $comCode=$SelcomCode['companyCode'];

		 $SelBranchQuery = 'SELECT branch_id FROM arka_branch_master WHERE sl_no="'.$branchId.'" AND record_status="1"';  
		$SelBranchQueryView = mysql_query($SelBranchQuery, $arkaerp);
		$SelbranchCode = mysql_fetch_assoc($SelBranchQueryView);
		$branchCode =$SelbranchCode['branch_id'];
		//echo "Company Code".$comCode."<br>";
		//echo "Branch Code".$branchCode."<br>"; 

		/*  $SelPlatformMapQuery = 'SELECT segmentCode FROM arka_platform_mapping WHERE companyName="'.$comId.'" AND branch_id="'.$branchId.'" AND status="1"';  
			$ListPlatformMapView = $this->ExecuteQuery($SelPlatformMapQuery, 'select');*/

			$energyPF = "Energy Meter";
		    $solarPF = "Solar Inverter";
			$TempPF = "Temperature";

/****************************************                Today Total Energy   Start ********************************************/
		$SelEnergyPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$energyPF.'" AND status="1"';  
		$SelListEnergyPlatformView = mysql_query($SelEnergyPlatformQuery, $arkaerp);
$ListEnergyPlatformView = mysql_fetch_assoc($SelListEnergyPlatformView);
		$energySegCode = $ListEnergyPlatformView['segmentCode'];
		$energySegId = $ListEnergyPlatformView['slNo'];
	//	$objSmarty->assign('energySegId', $energySegId);	


		$SelSolarPlatformQuery = 'SELECT segmentCode,slNo FROM arka_iot_platform WHERE segmentName="'.$solarPF.'" AND status="1"';  
		$SelListSolarPlatformView = mysql_query($SelSolarPlatformQuery,  $arkaerp);
		$ListSolarPlatformView = mysql_fetch_assoc($SelListSolarPlatformView);
        $solarSegId = $ListSolarPlatformView['slNo'];
		$solarSegCode = $ListSolarPlatformView['segmentCode'];

		$SelMonthQuerys = "SELECT DATE_FORMAT(CURDATE(), '%b') AS month_short_code, YEAR(CURDATE()) AS current_year";
		$SelMonthData = mysql_query($SelMonthQuerys, $arkaerp);
		$SelmonthShortCode = mysql_fetch_assoc($SelMonthData);
		$monthShortCode=$SelmonthShortCode['month_short_code']; // JAN, FEB...
		$yearShortCode = $SelmonthShortCode['current_year'];

//echo "Month Short Code".$monthShortCode; exit;

		$dailyTableEB = $comCode."_".$branchCode."_".$energySegCode."_cron_daily";
		$dailyTableSolar = $comCode."_".$branchCode."_".$solarSegCode."_cron_daily";
	    $hourlyTable = $comCode."_".$branchCode."_".$energySegCode."_cron_hourly_".$monthShortCode."_".$yearShortCode;  
		
if(isset($_GET['date1']) && isset($_GET['date2']))
		{
		   $date1 = $_GET['date1'];
		   $date2 = $_GET['date2'];
		   $date1 = date("Y-m-d", strtotime($_GET['date1'])); 
           $date2 = date("Y-m-d", strtotime($_GET['date2'])); 
     //  echo "if"; exit;   
		  	$query_rs1 =  "SELECT $dailyTableEB.*,FORMAT($dailyTableEB.start_kwh, 2) AS startCumKwh, FORMAT($dailyTableEB.end_kwh, 2) AS endCumKwh, FORMAT($dailyTableEB.consuption_kwh, 2) AS conKwh, FORMAT($dailyTableEB.consuption_cost, 2) AS cos FROM $dailyTableEB WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND recorded_date < ".$nowDate." AND  (DATE(recorded_date) BETWEEN '".$date1."' AND '".$date2."') ORDER BY recorded_date DESC";
	}
	
			//mysql_select_db($database_arkaems, $arkaerp);
	/*	$query_rs1 =  "SELECT * FROM  cron_daily_energy_data WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."'  AND recorded_date < NOW() AND (DATE(recorded_date) BETWEEN '".$date1."' AND '".$date2."') ORDER BY recorded_date DESC";
		
		}
		else
		{
		//	mysql_select_db($database_arkaems, $arkaerp);
			$query_rs1 = "SELECT * FROM  cron_daily_energy_data WHERE gateway_code='".$gatewayCode."' AND sensor_code='".$sensorCode."' AND MONTH(recorded_date) = MONTH(NOW()) AND recorded_date <= DATE(NOW())  ORDER BY recorded_date DESC";
		}*/
/*** end query excel ***/       
		$mt2 = mysql_query($query_rs1, $arkaerp) or die(mysql_error());
//$recNumRow= mysql_num_rows($query_rs1);
	
$loop =6;
while( $row2 = mysql_fetch_array($mt2) ) {
    
   

	
 
    
    $orgDate = $row2['recorded_date'];  
    $newDate = date("d-M-Y h:i A", strtotime($orgDate)); 
    $tkwh =$tkwh + $row2['consuption_kwh'];
    $tcost =$tcost + $row2['consuption_cost'];
	
							$objPHPExcel->getActiveSheet()->setCellValue('A' . $loop, $newDate);
							$objPHPExcel->getActiveSheet()->setCellValue('B' . $loop, round($row2['start_kwh'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('C' . $loop, round($row2['end_kwh'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('D' . $loop, round($row2['consuption_kwh'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('E' . $loop, round($row2['consuption_cost'],2));
							$objPHPExcel->getActiveSheet()->setCellValue('F' . $loop, round($row2['consuption_cost'],2));
							$loop = $loop+1;
						}
			$objPHPExcel->getActiveSheet()->setCellValue('C' . $loop, 'Total Kwh');
            $objPHPExcel->getActiveSheet()->getStyle('C' . $loop)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
			$objPHPExcel->getActiveSheet()->setCellValue('D' . $loop, $tkwh);
			$objPHPExcel->getActiveSheet()->setCellValue('E' . $loop, 'Total Cost');
            $objPHPExcel->getActiveSheet()->getStyle('E' . $loop)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
			$objPHPExcel->getActiveSheet()->setCellValue('F' . $loop, $tcost);
			
					


$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);




$objPHPExcel->getActiveSheet()->getStyle('G3')->getFont()->setSize(14);
$objPHPExcel->getActiveSheet()->getStyle('G3')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('B5')->getAlignment()->setShrinkToFit(true);

// Set thin black border outline around column
//echo date('H:i:s') , " Set thin black border outline around column" , EOL;
$styleThinBlackBorderOutline = array(
	'borders' => array(
		'outline' => array(
			'style' => PHPExcel_Style_Border::BORDER_THIN,
			'color' => array('argb' => 'FF000000'),
		),
	),
);
$objPHPExcel->getActiveSheet()->getStyle('A5:F'.$loop)->applyFromArray($styleThinBlackBorderOutline);


// Set thick brown border outline around "Total"
//echo date('H:i:s') , " Set thick brown border outline around Total" , EOL;
$styleThickBrownBorderOutline = array(
	'borders' => array(
		'outline' => array(
			'style' => PHPExcel_Style_Border::BORDER_THICK,
			'color' => array('argb' => 'FF993300'),
		),
	),
);
//$objPHPExcel->getActiveSheet()->getStyle('D13:E13')->applyFromArray($styleThickBrownBorderOutline);

// Set fills

//echo date('H:i:s') , " Set fills" , EOL;
$objPHPExcel->getActiveSheet()->getStyle('A5:F5')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A5:F5')->getFill()->getStartColor()->setARGB('FFFF8C00');
$objPHPExcel->getActiveSheet()->getStyle('A4:F4')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A4:F4')->getFill()->getStartColor()->setARGB('FF5F9EA0');
// Set style for header row using alternative method
//echo date('H:i:s') , " Set style for header row using alternative method" , EOL;

$objPHPExcel->getActiveSheet()->getStyle('A5')->applyFromArray(
		array(
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
			),
			'borders' => array(
				'left'     => array(
 					'style' => PHPExcel_Style_Border::BORDER_THIN
 				)
			)
		)
);

$objPHPExcel->getActiveSheet()->getStyle('B5')->applyFromArray(
		array(
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
			)
		)
);

$objPHPExcel->getActiveSheet()->getStyle('L5')->applyFromArray(
		array(
			'borders' => array(
				'right'     => array(
 					'style' => PHPExcel_Style_Border::BORDER_THIN
 				)
			)
		)
);

// Unprotect a cell
//echo date('H:i:s') , " Unprotect a cell" , EOL;
$objPHPExcel->getActiveSheet()->getStyle('B1')->getProtection()->setLocked(PHPExcel_Style_Protection::PROTECTION_UNPROTECTED);

// Add a hyperlink to the sheet
$loop =$loop+2;
//echo date('H:i:s') , " Add a hyperlink to the sheet" , EOL;
$objPHPExcel->getActiveSheet()->setCellValue('B' . $loop, '');
$objPHPExcel->getActiveSheet()->getCell('B'  . $loop)->getHyperlink()->setUrl('http://ems.arkaautomaations.com');
$objPHPExcel->getActiveSheet()->getCell('B' . $loop)->getHyperlink()->setTooltip('Navigate to website');
$objPHPExcel->getActiveSheet()->getStyle('B' . $loop)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
$loop =$loop+1;
$objPHPExcel->getActiveSheet()->setCellValue('B'  . $loop, '');
//$objPHPExcel->getActiveSheet()->getCell('B' . $loop)->getHyperlink()->setUrl("sheet://'Terms and conditions'!A1");
//$objPHPExcel->getActiveSheet()->getCell('B'  . $loop)->getHyperlink()->setTooltip('Review terms and conditions');
$objPHPExcel->getActiveSheet()->getStyle('B' . $loop)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);


// Play around with inserting and removing rows and columns
//echo date('H:i:s') , " Play around with inserting and removing rows and columns" , EOL;
$objPHPExcel->getActiveSheet()->insertNewRowBefore(6, 10);
$objPHPExcel->getActiveSheet()->removeRow(6, 10);
$objPHPExcel->getActiveSheet()->insertNewColumnBefore('E', 5);
$objPHPExcel->getActiveSheet()->removeColumn('E', 5);

// Set header and footer. When no different headers for odd/even are used, odd header is assumed.
//echo date('H:i:s') , " Set header/footer" , EOL;
$objPHPExcel->getActiveSheet()->getHeaderFooter()->setOddHeader('&L&BInvoice&RPrinted on &D');
$objPHPExcel->getActiveSheet()->getHeaderFooter()->setOddFooter('&L&B' . $objPHPExcel->getProperties()->getTitle() . '&RPage &P of &N');

// Set page orientation and size
//echo date('H:i:s') , " Set page orientation and size" , EOL;
$objPHPExcel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
$objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);

// Rename first worksheet
//echo date('H:i:s') , " Rename first worksheet" , EOL;
$objPHPExcel->getActiveSheet()->setTitle('Meter Log Report');
