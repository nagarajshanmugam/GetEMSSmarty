<?php
	require('includes/common.php');
	include_once $config['SiteClassPath']."class.Staff.php";
	include_once $config['SiteClassPath']."class.ContactMaster.php";
	include_once $config['SiteClassPath']."class.split_page_results.php";
	
		$objStaff		= new Staff();
		$objStaff->RolesLists();
		$objStaff -> GetCompanyName($objArray);
		$objContactMaster		= new ContactMaster();
		if(isset($_POST['hdAction']) && !isset($_GET['Update'])){
			$objContactMaster -> InsertContact($_POST);
		}
		if(isset($_GET['Update']) && isset($_GET['person_name'])){
		    $objContactMaster -> ListEditView($objArray);
			$objContactMaster -> EditContactMaster($_POST);
		}
	
		$objSmarty->assign('IncludeTpl', 'contactMasterAddEdit.tpl');
		$objSmarty->assign('OverallSiteTitle', $config['SiteTitle'].'- Location Reg');
		$objSmarty->assign('robots','index,follow');
		$objSmarty->assign('key_word','');
		$objSmarty->assign('generator','');
		$objSmarty->assign('document-state','dynamic');
		$objSmarty->assign('address',$config['SiteGlobalPath']);
		
		
		/*Display page*/
		$objSmarty->assign('LeftTpl', 'left.tpl');
		$objSmarty->display('pagetemplate.tpl');

?>