<?php 
	$hostname_arkaems = "148.66.130.228";
	$database_arkaems = "univa_ems";
	$username_arkaems = "univa_ems_user";
	$password_arkaems = "Un!v@2022";
	$arkaerp = mysql_connect($hostname_arkaems, $username_arkaems, $password_arkaems) or trigger_error(mysql_error(),E_USER_ERROR);
	mysql_select_db($database_arkaems, $arkaerp) or die(mysql_error());
	mysql_query( "SET SESSION sql_mode = 'NO_ENGINE_SUBSTITUTION'",$arkaerp);
	
	if($username_arkaems != 'root')
	{
		$nowDate= 'DATE_ADD(NOW(),INTERVAL "00:00" HOUR_MINUTE)';
	}
	else{
		$nowDate= 'NOW()';
	}
	if(isset($_POST['sensor_code']))
	{
		$whCond="arka_sensor_master.sensorCode='".$_POST['sensor_code']."' AND arka_sensor_master.segmentName='Energy Meter' ";
	}
	else
	{
		$whCond="arka_sensor_master.segmentName='Energy Meter'";
	}

	 	$sensorSel = "SELECT arka_sensor_master.*,arka_sensor_master.feeder_type FROM arka_sensor_master WHERE arka_sensor_master.status='1' AND arka_sensor_master.isActive='1' AND ".$whCond." ";
		$sensorList = mysql_query($sensorSel,$arkaerp);
		$sensorList2 = mysql_query($sensorSel,$arkaerp);
	//	print_r($sensorList2);
	
		$machine = mysql_num_rows($sensorList);	
				
		$cronDateSel = "SELECT * FROM cron_monthly_energy_data WHERE MONTH(recorded_date)=MONTH(".$nowDate.") AND YEAR(recorded_date)=YEAR(".$nowDate.")";
		$dateList = mysql_query($cronDateSel,$arkaerp);
		$dateCount = mysql_num_rows($dateList);	
		
	if($dateCount=='0'){
	/**********************First Month***************/
		$first1 = "SELECT CAST(DATE_FORMAT(".$nowDate.",'%y-01-01') AS DATE) AS FT";
		$firstday = mysql_query($first1,$arkaerp);
		$first = mysql_num_rows($firstday);
		$fstday=mysql_fetch_array($firstday);
		echo "FIRSTDAY:" .$fstday['FT']."<br>";
	
	/**********************LAST Month***************/
		$lastMonth=12;
    	while($rows=mysql_fetch_array($sensorList))
    	{
    		echo $rows['sensorCode'];
    		$i=0;
        	for($d=1;$d<=$lastMonth;$d++)
        	{		
        		$date= "SELECT DATE_ADD(DATE('".$fstday['FT']."'),INTERVAL '".$i."' MONTH) AS DT";
        		$date1 = mysql_query($date,$arkaerp);					
        		$da=mysql_fetch_array($date1);
        		$sql = "SELECT * FROM cron_monthly_energy_data WHERE recorded_date='".$da['DT']."' AND sensor_code='".$rows['sensorCode']."'";
        		$Day = mysql_query($sql,$arkaerp);
        		$count = mysql_num_rows($Day);
            	if($count=="0")
            	{
            		$Insert= "INSERT INTO cron_monthly_energy_data (company_id,branch_id,gateway_code,sensor_code,feeder_type,recorded_date) VALUES ('".$rows['company_id']."','".$rows['branch_id']."','".$rows['gateway_id']."','".$rows['sensorCode']."','".$rows['feeder_type']."','".$da['DT']."')";
            		 mysql_query($Insert,$arkaerp);	
            		$i++;
            	}
            	else
            	{		
            	}
        	}
    	}  
	}
	/*****************************************     Query Ends for:  Insert every date of the month start    *****************************************/	
	/***************************************     Query Starts for:  lastday KWH and Cost    *****************************************/	
	while($rows2=mysql_fetch_array($sensorList2))
	{
    	if(isset($_POST['recorded_date']))
    	{
    		$passMonth='MONTH("'.$_POST['recorded_date'].'")';
    		$passYear='YEAR("'.$_POST['recorded_date'].'")';
    		$userName =$_POST['userName'];
    		$manualUpdate=1;
    	}
    	else
    	{
    		$passMonth='MONTH(DATE_SUB('.$nowDate.',INTERVAL "1" DAY))';
    		$passYear='YEAR(DATE_SUB('.$nowDate.',INTERVAL "1" DAY))';
    		$userName='Cron';
    		$manualUpdate=0;
    	}
 	$selQry = 'SELECT company_id,branch_id,gateway_code,sensor_code,feeder_type,recorded_date,MIN(start_cum_kwh) AS start_kwh,MIN(dg_start_cum_kwh) AS dg_start_kwh,MAX(end_cum_kwh) AS end_kwh,MAX(dg_end_cum_kwh) AS dg_end_kwh,cost AS unit_rate,dg_cost AS dg_unit_rate,(MAX(end_cum_kwh) - MIN(start_cum_kwh)) AS TOTAL_KWH, (MAX(dg_end_cum_kwh) - MIN(dg_start_cum_kwh)) AS TOTAL_DG_KWH,((MAX(end_cum_kwh) - MIN(start_cum_kwh)) * cost) AS consuption_cost,((MAX(dg_end_cum_kwh) - MIN(dg_start_cum_kwh)) * dg_cost) AS dg_consuption_cost FROM cron_daily_energy_data WHERE `gateway_code`="'.$rows2["gateway_id"].'" AND `sensor_code`="'.$rows2["sensorCode"].'" AND MONTH(`recorded_date`) ='.$passMonth.' AND  YEAR(`recorded_date`) ='.$passYear.'  AND start_cum_kwh !="0.00" AND end_cum_kwh !="0.00"';
		$selectEnergyData = mysql_query($selQry,$arkaerp);
		$energyData2 = mysql_num_rows($selectEnergyData);
    	while ($energyData = mysql_fetch_assoc($selectEnergyData))
    	 {
    	   //  echo "inside";
    	$InsQry='UPDATE `cron_monthly_energy_data` SET `feeder_type`="'.$rows2["feeder_type"].'",`start_kwh`="'.$energyData["start_kwh"].'",`dg_start_cum_kwh`="'.$energyData["dg_start_kwh"].'",`end_kwh`="'.$energyData["end_kwh"].'",`dg_end_cum_kwh`="'.$energyData["dg_end_kwh"].'",`unit_rate`="'.$energyData["unit_rate"].'",`dg_cost`="'.$energyData["dg_unit_rate"].'", `consuption_kwh`="'.$energyData["TOTAL_KWH"].'",`dg_consuption_kwh`="'.$energyData["TOTAL_DG_KWH"].'",`consuption_cost`="'.$energyData["consuption_cost"].'",`dg_consuption_cost`="'.$energyData["dg_consuption_cost"].'",`posted_date_time`='.$nowDate.', `created_by`="'.$userName.'", `manual_update`="'.$manualUpdate.'" WHERE `company_id`="'.$rows2["company_id"].'" AND `branch_id`="'.$rows2["branch_id"].'" AND `gateway_code`="'.$rows2["gateway_id"].'" AND sensor_code="'.$rows2["sensorCode"].'" AND MONTH(`recorded_date`)=MONTH("'.$energyData["recorded_date"].'") AND YEAR(`recorded_date`)=YEAR("'.$energyData["recorded_date"].'")'; 
   	mysql_query($InsQry,$arkaerp);
    	echo "Cron Runs Sucessfully";
    	}
	}
	/*****************************************     Query Starts for:  lastday KWH and Cost    *****************************************/
	$InsertCronLog= "INSERT INTO cron_run_log (cron_name) VALUES ('cronEnergyMeterDataMonthly.php')";
	mysql_query($InsertCronLog,$arkaerp);	
	
	mysql_free_result($sensorList);	
	mysql_free_result($sensorList2);	
	mysql_free_result($dateList);	
	mysql_free_result($firstday);
	mysql_free_result($LastDay);
	mysql_free_result($date1);
	mysql_free_result($Day);
	mysql_free_result($daybeforeData);	
	mysql_free_result($selectEnergyData);
	mysql_close($arkaerp);	
	
	
?>

